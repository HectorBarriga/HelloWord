#!/bin/bash
#############################################################################
# Filename:    CSDRH.sh
# Revision:    $Revision: 0.1.0 $
# Author:      Hector Barriga
#
# Jiras:
# CO Scripts:  COSC-xx
# CO Internal: COIT-xx
#
# This sh script is to generate Classify Stats Detailed records that will be shopped by Filbeat to Elastic Search for reporting
#
# Copyright (c) CSG International 2024
# Author: Hector Barriga
#
# All rights reserved.
# This document contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or
# in part is expressly prohibited, except as may be specifically
# authorized by prior written agreement or permission of Tango Telecom.
##############################################################################
# version 0.1.0 - First versionA
#
##############################################################################

#---------------------------------------------------------------
# Flags
#---------------------------------------------------------------
while getopts p:f:d:t:h option;
do
        case $option in
                p) STATS_DIR=$OPTARG;;
                f) STATS_FILE_PREFIX=$OPTARG;;
                d) STATS_DATE=$OPTARG;;
                t) STATS_TIME=$OPTARG;;
                h) echo -e "
        Usage: CSDR.sh
        This sh script is to generate Classify Stats Detailed records that will be shopped by Filbeat to Elastic Search for reporting
        Copyright (c) CSG International 2024

               Options:
               -p <path/directory       Classify Stats File's path

               -f <file prefix>         Classify Stats File prefix

               -d <date>                Process Classify Stats File for the date
                                        Default = Today

               -t <time>                Process Classify Stats for that time
                                        Default: Last 5 mins

               -h <help>                Show help

               e.g. ./clusterNetTest.sh -d /tango/logs/stats/local/TCAP_STATISTICS/ -f tcap-0
               Converts all /tango/logs/stats/local/TCAP_STATISTICS/tcap-0* classify stats files into CSDR files
              ";help="true";;
        esac
done

#---------------------------------------------------------------
# Subroutines
#---------------------------------------------------------------

if [ "$help" ==  "true" ];then
        echo ""
else

#---------------------------------------------------------------
# Set Initial variables
#---------------------------------------------------------------
DIR=$(echo "`dirname $0`")
HOST_NAME=$(hostname)
CSDR_DIR=$STATS_DIR/CSDR
#---------------------------------------------------------------
# Main
#---------------------------------------------------------------

if [ ! -d $CSDR_DIR ];then
        mkdir $CSDR_DIR
fi

if [ -z $STATS_DATE ];then
        STATS_DATE=$( perl -e '@d=localtime time(); printf "%4d-%02d-%02d\n", $d[5]+1900,$d[4]+1,$d[3]')
fi

statsFileName=$STATS_FILE_PREFIX-$HOST_NAME-$STATS_DATE
statsDirFile=$STATS_DIR/$statsFileName.stats

if [ -z $STATS_TIME ];then
        getFileTime=$(tail -2 $statsDirFile | grep '__END' | cut -d, -f5)
        statsProcessName=$(tail -2 $statsDirFile | grep '__END' | cut -d, -f2,3)
        getCsdrMainFields=$(tail -2 $statsDirFile | grep -v '__END')
else
        getFileTime=$STATS_TIME
        statsProcessName=$(grep -B1 "__END.*$STATS_DATE,$STATS_TIME" $statsDirFile | grep '__END' | cut -d, -f2,3)
        getCsdrMainFields=$(grep -B1 "__END.*$STATS_DATE,$STATS_TIME" $statsDirFile | grep -v '__END')
fi

getCsdrLastTime=$(echo $getFileTime | sed 's/-/:/g')
csdr=$statsProcessName,$STATS_DATE,$getCsdrLastTime,$getCsdrMainFields
echo $csdr > $CSDR_DIR/$statsFileName-$getFileTime.csdr




fi