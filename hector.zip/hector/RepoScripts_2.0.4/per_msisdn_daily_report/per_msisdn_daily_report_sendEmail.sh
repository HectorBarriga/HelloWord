#!/bin/bash
dateNoForma=$(date -d yesterday +%Y" "%b" "%d)
year==$(date -d yesterday +%Y)
DATE=`date -d yesterday +%Y%m%d`

while getopts t:h option;
do
        case $option in
                t) mailRcpt=$OPTARG;;
                h) echo "
        Usage: per_msisdn_daily_report_sendEmail.sh

               Options:

               -h <help>                Show help

               -t <mailRcpt>            List of mail Receipts

               "; h="true";;
        esac
done

if [ "$h" != "true" ];then
        listMailTo=(`echo ${mailRcpt} | sed 's/,/ /g'`)
        listMailToLength=${#listMailTo[@]}
        echo "<h3>[Telefonica Vivo] Daily MCM Report $dateNoForma</h3>" > /tango/data/reporting_scripts/per_opco/vivo/$DATE/per_msisdn_daily_report_sendEmail_$DATE.txt
        zip_Files=$(ls -altr /tango/data/reporting_scripts/per_opco/vivo/$DATE/*.zip | awk '{print $9}')
        while read in
        do
                echo "<table cellpadding=\"8\" style=\"white-space:nowrap;border:1px solid black;border-collapse:collapse\">" >> /tango/data/reporting_scripts/per_opco/vivo/$DATE/per_msisdn_daily_report_sendEmail_$DATE.txt
                report=$(echo "$in" | cut -d'.' -f1 | rev | cut -d'/' -f1 | rev)
                reportAttached1="/tango/data/reporting_scripts/per_opco/vivo/$DATE/daily_mcm_report_per_msisdn_counters_$DATE"".csv.zip"
                reportAttached2="/tango/data/reporting_scripts/per_opco/vivo/$DATE/daily_mcm_report_per_msisdn_per_country_$DATE"".csv.zip"
                reportAttached3="/tango/data/reporting_scripts/per_opco/vivo/$DATE/daily_mcm_report_per_msisdn_per_country_purchased_plans_$DATE"".csv.zip"
                reportAttached4="/tango/data/reporting_scripts/per_opco/vivo/$DATE/daily_mcm_report_per_msisdn_country_network_plan_$DATE"".csv.zip"
                reportAttached5="/tango/data/reporting_scripts/per_opco/vivo/$DATE/daily_mcm_report_per_msisdn_captiveportal_plan_renewal_$DATE"".csv.zip"
                reportAttached6="/tango/data/reporting_scripts/per_opco/vivo/$DATE/daily_mcm_report_per_country_network_$DATE"".csv.zip"
                if [ "$in" == $reportAttached1 ] || [ "$in" == $reportAttached2 ] || [ "$in" == $reportAttached3 ] || [ "$in" == $reportAttached4 ] || [ "$in" == $reportAttached5 ] || [ "$in" == $reportAttached6 ];then
                        data=" Please find the report attached"
                else
                        data=$(zcat $in)
                fi
                if [ "$in" == $reportAttached5 ] || [ "$in" == $reportAttached2 ];then
                        echo "<tr><th align=\"left\"; bgcolor='#00FF00'>$report</th></tr>" >> /tango/data/reporting_scripts/per_opco/vivo/$DATE/per_msisdn_daily_report_sendEmail_$DATE.txt
                else
                        echo "<tr><th align=\"left\"; bgcolor='#ccddff'>$report</th></tr>" >> /tango/data/reporting_scripts/per_opco/vivo/$DATE/per_msisdn_daily_report_sendEmail_$DATE.txt
                fi
                echo "<tr><td>$data</td></tr>" >> /tango/data/reporting_scripts/per_opco/vivo/$DATE/per_msisdn_daily_report_sendEmail_$DATE.txt
                echo "" >> /tango/data/reporting_scripts/per_opco/vivo/$DATE/per_msisdn_daily_report_sendEmail_$DATE.txt
                echo "</table>" >> /tango/data/reporting_scripts/per_opco/vivo/$DATE/per_msisdn_daily_report_sendEmail_$DATE.txt
        done <<< "$zip_Files"

        for (( j=0;j<$listMailToLength;j++))
        do
                /tango/scripts/Generic/tools/sendMail_SMTPS.pl -A /tango/data/reporting_scripts/per_opco/vivo/$DATE/daily_mcm_report_per_msisdn_captiveportal_plan_renewal_$DATE.csv.zip,/tango/data/reporting_scripts/per_opco/vivo/$DATE/daily_mcm_report_per_msisdn_per_country_$DATE.csv.zip,/tango/data/reporting_scripts/per_opco/vivo/$DATE/daily_mcm_report_per_country_network_$DATE.csv.zip,/tango/data/reporting_scripts/per_opco/vivo/$DATE/daily_mcm_report_per_msisdn_counters_$DATE.csv.zip,/tango/data/reporting_scripts/per_opco/vivo/$DATE/daily_mcm_report_per_msisdn_per_country_purchased_plans_$DATE.csv.zip,/tango/data/reporting_scripts/per_opco/vivo/$DATE/daily_mcm_report_per_msisdn_country_network_plan_$DATE.csv.zip -f no-reply-mcm.businesssolutions@telefonica.com  -t ${listMailTo[$j]} -n no-reply-mcm.businesssolutions@telefonica.com -s "Daily MCM Report $year" -x smtp.office365.com -U no-reply-mcm.businesssolutions@telefonica.com -P Gmtu_2019 -a "cat /tango/data/reporting_scripts/per_opco/vivo/$DATE/per_msisdn_daily_report_sendEmail_$DATE.txt" -v
        done
fi