#!/bin/bash
echo "`tput setaf 3`============ 1. tar /etc/ /root and /usr directories under /hector_temporal ============`tput sgr0`"
cd /etc/
tar -cvf etc_back.tar *
mv etc_back.tar /hector_temporal
cd /root
tar -cvf root_back.tar *
mv root_back.tar /hector_temporal
cd /usr
tar -cvf usr_back.tar *
mv usr_back.tar /hector_temporal
cd /hector_temporal
echo "`tput setaf 3`============ Done ============`tput sgr0`"
echo "`tput setaf 3`============ 2. Install ksh package needed by system_info_v10.sh ============`tput sgr0`"
rm -fr /var/cache/yum/*
yum clean all
subscription-manager clean
yum -y install ksh-20120801-254.el8.x86_64.rpm
echo "`tput setaf 3`============ Done ============`tput sgr0`"
echo "`tput setaf 3`============ 3. Check Pre-Installation ============`tput sgr0`"
/hector_temporal/system_info_v10.sh
echo "`tput setaf 3`============ Done ============`tput sgr0`"
echo "`tput setaf 3`============ 4. Check current repo under /etc/yum.repos.d/. Run yum list and check it works ok `tput sgr0`"
ls -altr /etc/yum.repos.d/
yum list
echo "`tput setaf 3`============ Done ============`tput sgr0`"
echo ""
echo ""
groupOperatorID=$(cat /etc/group | grep operator | grep 501 | wc -l)
groupReadOnlyID=$(cat /etc/group | grep readonly | grep 502 | wc -l)
echo "`tput setaf 3`============ 5. Check and if needed, modify \"operator\" group ID in order for common ansible playbook to work ok`tput sgr0`"
if [ "$groupOperatorID" -eq 0 ];then
        groupmod -g 501 operator
fi
grep 501 /etc/group
echo "`tput setaf 3`============ Done ============`tput sgr0`"
echo "`tput setaf 3`============ 6. Check and if needed, modify \"readonly\" group ID in order for common ansible playbook to work ok`tput sgr0`"
if [ "$groupReadOnlyID" -eq 0 ];then
        groupmod -g 502 readonly
fi
grep 502 /etc/group
echo "`tput setaf 3`============ Done ============`tput sgr0`"
echo "`tput setaf 2`============ 7. Open C:\Users\barhec02\OneDrive - CSG Systems Inc\Documents\TANGO\MANUALS\DevOps\ANSIBLE\How to Install and Prepare ANSIBLE master server and common iAX_Platform playbook.txt
and Fllow steps 5.2 iAX-Platform installation ============`tput sgr0`"
echo ""