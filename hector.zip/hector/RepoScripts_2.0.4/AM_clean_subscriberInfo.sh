#!/bin/bash
databaseServer=localhost
if [ -z "$1" ];then
        echo -e "`tput setaf 1`Sorry, you must add msisdn and activity_name after wsms_truncate;\nExample: wsms_truncate 5511942383794 location`tput sgr0`\""
elif [ ! -z "$1" ] && [ -z "$2" ];then
        echo -e "`tput setaf 1`Sorry, you must add activity_name after msisdn [location, subscriberInfo, SUBSCRIBER_LOCATION, SUBSCRIBER_DEBOUNCE_LOCATION or ALL(default)] ;\nExample: wsms_truncate 5511942383794 location`tput sgr0`\""
elif [ ! -z "$1" ] && [ "$2" == "location" -o "$2" == "SUBSCRIBER_LOCATION" -o "$2" == "SUBSCRIBER_DEBOUNCE_LOCATION" -o "$2" == "subscriberInfo" ];then
        echo "`tput setaf 3`ssh $databaseServer \"mysql -u root -e 'delete from activity_meter.activity where msisdn = \\\"$1\\\" and activity_name = \\\"$2\\\";'\"`tput sgr0`"
        ssh $databaseServer "mysql -u root -e 'delete from activity_meter.activity where msisdn = \"$1\" and activity_name = \"$2\";'"
elif [ ! -z "$1" ] && [ "$2" == "ALL" ];then
        echo "`tput setaf 3`ssh $databaseServer \"mysql -u root -e 'delete from activity_meter.activity where msisdn = \\\"$1\\\";'\"`tput sgr0`"
        ssh $databaseServer "mysql -u root -e 'delete from activity_meter.activity where msisdn = \"$1\";'"
fi