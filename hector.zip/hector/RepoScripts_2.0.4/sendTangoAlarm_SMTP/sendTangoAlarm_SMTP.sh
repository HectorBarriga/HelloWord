##############################################################################
# Filename:    sendTangoAlarm_SMTP.sh
# Author:      Hector Barriga
#
# Jiras:
# CO Scripts:  COSC-131
#
# This script is to email Tango SW alarms via SMTP
#
# Requirements 1 (Recommended to avoid spamming):
# 1. Email Tango SW alarms via SMTP server to a list of email addresses
# 2. If script or machine or SMTP server is not running, there will not be emails. That does not necessary mean there are not alarms. So, script has # to send "keepalived" emails daily to notify script is alived.
# 3. Configuration is via cfg file
# 4. Alarm name will be in the email's body* with the following format: <Application name ><Severity><Alert Code/Id> e.g. Eg : PCRF_Critical_0
# 5. Each alarm has to be notified only once per day to avoid spamming. Example, a process could be bouncing every min. Script will be sending emails # every min for same alarms.
# 6. Alarm notification should specify whether alarm is still active or alarm was active and has been cleared/cancelled
#
# Requirements 2 (These were used in CSG Unitel instead of above requirments 1):
# 1. Script must send 1 email per alarm
# 2. Subject has to have the following format <Application name ><Severity><Alert Code/Id> . Example: PCRF_Critical_0 <<<<<< Note <severity> was # requested to be removed
# 3. If cluster generates same alarm several times per day, script will still send email for each one
# 4. Script will not send and email when the alarm has been cleared/cancelled
# 5. Script will have the option to send "keepalived" emails daily to notify script or machine is alived.
#
# This sh script is mainly used for Tango  CO internal  monitoring
# Copyright (c) CSG 2024
#
# All rights reserved.
# This document contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or
# in part is expressly prohibited, except as may be specifically
# authorized by prior written agreement or permission of Tango Telecom.
##############################################################################
# version 0.1.0 - First version
# version 0.1.1 - Fixing bugs
# version 0.2.0 - Add option to send email per alarm
# version 0.3.0 - Add logs and SMTP error code in mail's body. Use alarm Desc instead of alarmID in sujbect
# version 0.3.2 - Include machine's name in subject
# version 0.3.4 - Use className in the Source as Application Name in subject
# version 0.3.5 - Remove <severity> from subject
# version 2.2.0 - Improve script to make it suitable for Zain Sudan. It also includes Alarm Cancellations
version=2.0.1
##############################################################################

# Initial parameters
DIR=$(echo "`dirname $0`")
config_file=$DIR/sendTangoAlarm_SMTP.cfg
hostname=$(hostname)
todayExt=$(perl -e '@d=localtime time(); printf "%4d%02d%02d\n", $d[5]+1900,$d[4]+1,$d[3]')
timenow=$(perl -e '@d=localtime time(); printf "%4d%02d%02d %02d:%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1]')
HH=$(perl -e '@d=localtime time(); printf "%02d\n", $d[2]')
DD=$(perl -e '@d=localtime time(); printf "%02d\n", $d[3]')
hour=$(perl -e '@d=localtime time(); printf "[%02d:%02d:%02d]\n", $d[2],$d[1],$d[0]')
dday=$(date +%b)
red=`tput setaf 1`
green=`tput setaf 2`
yellow=`tput setaf 3`
blue=`tput setaf 4`
reset=`tput sgr0`
lightblue=`tput setaf 6`
pink=`tput setaf 5`
bold=`tput bold`
italic=`tput sitm`

# Flags and Mode
while getopts hv option;
do
        case $option in
                v) verbose="true";;
                h) echo "
        Usage: sendTangoAlarm_SMTP.sh
        Filename:    sendTangoAlarm_SMTP.sh
        Author:      Hector Barriga

        Jiras:
        CO Scripts:  COSC-131

        This sh script is toemail when a Tango Alarm is triggered
        Copyright (c) CSGI 2024

        All rights reserved.
        This document contains confidential and proprietary information of
        Tango Telecom and any reproduction, disclosure, or use in whole or
        in part is expressly prohibited, except as may be specifically
        authorized by prior written agreement or permission of Tango Telecom.


               Configuration:

               $DIR/sendTangoAlarm_SMTP.cfg

               Options:

               -h <help>                Show help
               -v <verbose>             To display (in blue) tests done by the script such as curls, telnet, etc.

               e.g. ./healthcheck.sh -v
                    It displays script results in case you wish to run them manually

               "; h="true";;
        esac
done
if [ "$h" != "true" ];then

#---------------
# SubRoutines
#---------------

printLog()
{
if [ ! -d $LoggingDir ];then mkdir $LoggingDir;fi
newlogFile=$(echo $LoggingFile | cut -d. -f1)
logExt=$(echo $LoggingFile | cut -d. -f2)
if [ "$1" == "cleanlog" ];then
        echo -e "$2" >> $LoggingDir/$newlogFile.$todayExt.$logExt
else
        echo -e "[ $timenow ] $1 $2" >> $LoggingDir/$newlogFile.$todayExt.$logExt
fi
}

housekeeping()
{
if [ ! -f $HK_purgeFilesScript ];then
        echo -e $red"\nSorry, HK_purgeFiles script $HK_purgeFilesScript does not exit. You must install it andconfigure it in $DIR/sendTangoAlarm_SMTP.cfg, bye\n"$reset
        exit
fi
$HK_purgeFilesScript $DIR/.temp/ 0
}

checkTmpDirFile()
{
if [ ! -d $DIR/.temp/ ];then mkdir $DIR/.temp/;fi
if [ ! -f $DIR/.temp/registry_sendTangoAlarm_SMTP_$todayExt ];then touch $DIR/.temp/registry_sendTangoAlarm_SMTP_$todayExt;fi
if [ ! -d $LoggingDir ];then mkdir $LoggingDir;fi
}

getParameters()
{
oldIFS="$IFS"
IFS=":"
while read name value
do
    eval $name="$value"
done < $DIR/.temp/config
IFS="$oldIFS"
}

getGeneralParameters()
{
sed -n '/\[General]/,/\[/p' $DIR/sendTangoAlarm_SMTP.cfg | cut -d# -f1 | awk  '!/\[General]/ && !/\[/' | tr -d " \t\r" | sed '/^$/d' | awk '/Site/ || /ApplicationName/ || /AlarmDir/ || /AlarmFile/ || /EmailColor/ || /EmailPerAlarm/ || /SendKeepalive/ || /LoggingDir/ || /LoggingFile/ || /HK_purgeFilesScript/ || /ReportCancelledAlarms/ || /UseHTMLFormat/ || /DelayEmailSubmit/' | sed "s/=/:/g" > $DIR/.temp/config
getParameters
BlackListAlarmID=$(sed -n '/\[General]/,/\[/p' $DIR/sendTangoAlarm_SMTP.cfg | grep 'BlackList Alarm ID' | cut -d# -f1 | awk  '!/\[General]/ && !/\[/' | sed '/^$/d' | awk '/BlackList Alarm ID/' | sed "s/BlackList Alarm ID = //g" | awk '{$1=$1}1')
if [ "$verbose" == "true" ];then echo -e ""$yellow"\n================================================================================================\n Config Parameters\n================================================================================================"$reset$bold"\nFile = $DIR/sendTangoAlarm_SMTP.cfg\n"$reset"[Generic] Site = $Site\n[Generic] ApplicationName = $ApplicationName\n[Generic] Alarm Dir = $AlarmDir\n[Generic] Alarm File = $AlarmFile\n[Generic] Email Color = $EmailColor\n[Generic] HK_purgeFiles Script = $HK_purgeFilesScript\n[Generic] Email Per Alarm = $EmailPerAlarm\n[Generic] Send Keepalive = $SendKeepalive\n[Generic] Logging Dir = $LoggingDir\n[Generic] Logging File = $LoggingFile\n[Generic] Report Cancelled Alarms = $ReportCancelledAlarms\n[Generic] Use HTML Format = $UseHTMLFormat\n[Generic] BlackListAlarmID = $BlackListAlarmID\n[Generic] Delay Email Submit= $DelayEmailSubmit";fi
if [ ! -z "$ApplicationName" ];then
        ApplicationName=":$ApplicationName"
fi
printLog "cleanlog" "---------------------- START ----------------------"
printLog "[Get Config Parameters]" "$DIR/sendTangoAlarm_SMTP.cfg"
}

getSMTPParameters()
{
sed -n '/\[SMTP]/,/\[/p' $DIR/sendTangoAlarm_SMTP.cfg | awk  '!/\[SMTP]/ && !/\[/' | tr -d " \t\r" | awk '/MailFrom/ || /ListEmailTo/ || /SMTPServerIP/ || /sendMailPerlScript/' | cut -d"#" -f1 | sed "s/=/:/g" > $DIR/.temp/config
getParameters
if [ "$verbose" == "true" ];then echo -e "[SMTP] Mail From = $MailFrom\n[SMTP] List Mail To = $ListEmailTo\n[SMTP] SMTP Server IP = $SMTPServerIP\n[SMTP] sendMail Perl Script = $sendMailPerlScript";fi
}

sendEmail()
{
if [ ! -f $sendMailPerlScript ];then
        echo -e $red"\nSorry, sendMail.pl script $sendMailPerlScript does not exit. You must install it andconfigure it in $DIR/sendTangoAlarm_SMTP.cfg, bye\n"$reset
        exit
fi

ncatFile=$(nc -w1 -vz $SMTPServerIP 25 > $DIR/.temp/ncat 2>&1)
ncat=$(grep TIMEOUT $DIR/.temp/ncat | wc -l)
if [ "$ncat" -ne 0  ];then
        if [ "$verbose" == "true" ];then echo "$red[FAILED]"$reset" There is not connection to SMTP server $SMTPServerIP" ;fi
        printLog "[FAILED]" "There is not connection to SMTP server $SMTPServerIP"
fi
listMailTo=(`echo ${ListEmailTo} | sed 's/,/ /g'`)
listMailToLength=${#listMailTo[@]}
if [ "$verbose" == "true" ];then echo -e ""$yellow"\n================================================================================================\n Send Email\n================================================================================================"$reset"";fi
for (( j=0;j<$listMailToLength;j++))
do
        if [ "$verbose" == "true" ];then echo $yellow"$sendMailPerlScript -f $MailFrom  -t ${listMailTo[$j]} -n $MailFrom -s \"[$Site$ApplicationName] $ApplicationName Alarms\" -x $SMTPServerIP -a \"cat $DIR/.temp/email\" -v"$reset ;fi
        printLog "[SEND EMAIL]" "$sendMailPerlScript -f $MailFrom  -t ${listMailTo[$j]} -n $MailFrom -s \"[$Site$ApplicationName] $ApplicationName Alarms\" -x $SMTPServerIP -a \"cat $DIR/.temp/email\" -v"
        if [ "$verbose" == "true" ];then echo "$yellow[SLEEP]"$reset" Delay of $DelayEmailSubmit seconds before I sent the email" ;fi
        printLog "[SLEEP]" "Delay of $DelayEmailSubmit seconds before I sent the email"
        sleep $DelayEmailSubmit
        $sendMailPerlScript -f $MailFrom  -t ${listMailTo[$j]} -n $MailFrom -s "[$Site$ApplicationName] $ApplicationName Alarms" -x $SMTPServerIP -a "cat $DIR/.temp/email" -v
done
}

checkBlacklist()
{
resetAllONalarms=$1
filteredONalarms=$1
if [[ "$BlackListAlarmID" =~ "all" ]] || [[ "$BlackListAlarmID" =~ "All" ]];then
        printLog "[ALARM]" "ALL alarms are BLACKLISTED. There will not be any report to be sent."
        if [ "$verbose" == "true" ];then echo -e "["$red"ALARM"$reset"] ["$lightblue"There will not be any report to be sent"$reset"] ALL alarms are Blacklisted.";fi
        filteredONalarms=""
else
        #alarmIDsBlacklistedArray=(`echo ${BlackListAlarmID} | sed 's/,/ /g'`)
        OIFS="$IFS"
        IFS=',' alarmIDsBlacklistedArray=($BlackListAlarmID)
        IFS="$OIFS"
        alarmIDsBlacklistedArrayLength=${#alarmIDsBlacklistedArray[@]}
        for (( j=0;j<$alarmIDsBlacklistedArrayLength;j++))
        do
                while  read ONAlarmList
                do
                        getIDAlarm=$(echo $ONAlarmList | cut -d, -f1 | cut -d"=" -f2 | tr -d '[[:space:]]')
                        if [ "${alarmIDsBlacklistedArray[$j]}" == "$getIDAlarm" ];then
                                printLog "[ALARM]" "Alarm ID \"$getIDAlarm\" is BLACKLISTED. Report is not to be sent. This alarm is ON: $ONAlarmList"
                                if [ "$verbose" == "true" ];then echo -e "["$red"ALARM"$reset"] ["$lightblue"BLACKLISTED - Report is NOT to be sent"$reset"] Alarm ID $getIDAlarm is Blacklisted. This alarm is ON:"$bold"\n---\n$ONAlarmList\n---\n"$reset;fi
                                filteredONalarms=$(echo "$resetAllONalarms" | egrep -v  "${alarmIDsBlacklistedArray[$j]}")
                        elif [[ "$ONAlarmList" == *"${alarmIDsBlacklistedArray[$j]}"* ]];then
                                printLog "[ALARM]" "Alarm containing \"${alarmIDsBlacklistedArray[$j]}\" is BLACKLISTED. Report is not to be sent. This alarm is ON: $ONAlarmList"
                                if [ "$verbose" == "true" ];then echo -e "["$red"ALARM"$reset"] ["$lightblue"BLACKLISTED - Report is NOT to be sent"$reset"] ${alarmIDsBlacklistedArray[$j]} string is Blacklisted. This alarm is ON:"$bold"\n---\n$ONAlarmList\n---\n"$reset;fi
                                filteredONalarms=$(echo "$resetAllONalarms" | egrep -v  "${alarmIDsBlacklistedArray[$j]}")
                        else
                                filteredONalarms=$resetAllONalarms
                        fi
                        resetAllONalarms=$filteredONalarms
                done <<< "$1"
        done
fi
}

buildEmailFile()
{
if [ "$verbose" == "true" ] && [ "$tangoAlarmTitleAlreadySent" != "yes" ];then echo -e ""$yellow"\n================================================================================================\n Tango Alarms\n================================================================================================"$reset"";tangoAlarmTitleAlreadySent="yes";fi
if [ "$1" == "alarm" ] && [ "$UseHTMLFormat" == "yes" -o "$UseHTMLFormat" == "Yes" -o "$UseHTMLFormat" == "true" -o "$UseHTMLFormat" == "True" ];then
        if [ "$verbose" == "true" ];then echo -e "["$red"ALARM"$reset"] ["$lightblue"Sending"$reset"] $6"$bold"\n---\n$4 $8\n$7\n---\n"$reset;fi
        printLog "[ALARM]" "$6.  Build HTML email to send \"$7\" \"$4 $8\""
        echo "<table cellpadding=\"2\" style=\"white-space:wrap;border:2px solid black;border-collapse:collapse\">" >> $DIR/.temp/email
        if [ "$EmailColor" == "yes" ] || [ "$EmailColor" == "Yes" ] || [ "$EmailColor" == "True" ] || [ "$EmailColor" == "true" ];then
                echo "<tr cellpadding=\"2\" style=\"white-space:wrap;border:1px solid black;border-collapse:collapse\" bgcolor='$5'><th align=\"left\">[$7] $hostname<td>$6</td></th></tr>" >> $DIR/.temp/email
        else
                echo "<tr cellpadding=\"2\" style=\"white-space:wrap;border:1px solid black;border-collapse:collapse\" bgcolor='#ffffff'><th align=\"left\">[$7] $hostname<td>$6</td></th></tr>" >> $DIR/.temp/email
        fi
        echo "<tr><td style='width: 800px'><br>$4<br><br>$2<br>$3</td></tr>" >> $DIR/.temp/email
        echo "</table>" >> $DIR/.temp/email
        echo "<br>" >> $DIR/.temp/email
elif [ "$1" == "notAlarm" ] && [ "$UseHTMLFormat" == "yes" -o "$UseHTMLFormat" == "Yes" -o "$UseHTMLFormat" == "true" -o "$UseHTMLFormat" == "True" ];then
        if [ "$verbose" == "true" ];then echo -e "["$green"NO ALARMS"$reset"] There are not Active Alarms OK\n";fi
        echo "<table cellpadding=\"2\" style=\"white-space:wrap;border:2px solid black;border-collapse:collapse\">" >> $DIR/.temp/email
        if [ "$EmailColor" == "yes" ] || [ "$EmailColor" == "Yes" ] || [ "$EmailColor" == "True" ] || [ "$EmailColor" == "true" ];then
                echo "<tr cellpadding=\"2\" style=\"white-space:wrap;border:1px solid black;border-collapse:collapse\" bgcolor='#3cb371'><th align=\"left\">[NO ALARMS] $hostname<td style='width: 30px'>OK</td></th></tr>" >> $DIR/.temp/email
        else
                echo "<tr cellpadding=\"2\" style=\"white-space:wrap;border:1px solid black;border-collapse:collapse\" bgcolor='#ffffff'><th align=\"left\">[NO ALARMS] $hostname<td style='width: 30px'>OK</td></th></tr>" >> $DIR/.temp/email
        fi
        echo "<tr><td style='width: 400px'><br>$2<br><br></td></tr>" >> $DIR/.temp/email
        echo "</table>" >> $DIR/.temp/email
        echo "<br>" >> $DIR/.temp/email
elif [ "$1" == "alarm" ] && [ "$UseHTMLFormat" == "no" -o "$UseHTMLFormat" == "No" -o "$UseHTMLFormat" == "false" -o "$UseHTMLFormat" == "False" ];then
        if [ "$verbose" == "true" ];then echo -e "["$red"ALARM"$reset"] ["$lightblue"Sending"$reset"] $6"$bold"\n---\n$4 $8\n$7\n---\n"$reset;fi
        printLog "[ALARM]" "$6. Build Text email to send \"$7\" \"$4 $8\""
        bodyOnText=$(echo "$2" | cut -d'<' -f1)
        bodyOffText=$(echo "$3" | cut -d'<' -f1)
        echo -e "[$6] [$hostname] = $7\n~~~\n$8\n~~~\n" >> $DIR/.temp/email
        echo -e "$4\n----------------------------------------------------------\n$bodyOnText $bodyOffText\n----------------------------------------------------------\n\n\n" >> $DIR/.temp/email
elif [ "$1" == "notAlarm" ] && [ "$UseHTMLFormat" == "no" -o "$UseHTMLFormat" == "No" -o "$UseHTMLFormat" == "false" -o "$UseHTMLFormat" == "False" ];then
        if [ "$verbose" == "true" ];then echo -e "["$green"NO ALARMS"$reset"] There are not Active Alarms OK\n";fi
        echo "[NO ALARMS] $hostname" >> $DIR/.temp/email
        echo "$2" >> $DIR/.temp/email
fi
}

handleAlarms()
{
echo "" > $DIR/.temp/email
getAllONalarms=$(grep "ON," $AlarmDir/$AlarmFile | sort -u)
checkBlacklist "$getAllONalarms"
getAllOFFalarms=$(grep "OFF," $AlarmDir/$AlarmFile | cut -d"(" -f1 | sort -u)
countAllONalarms=$(echo "$filteredONalarms" | grep "ON," | wc -l)
countAllOFFalarms=$(grep "OFF," $AlarmDir/$AlarmFile | wc -l)
if [ "$countAllONalarms" -ne 0 ];then
        while  read getONalarm
        do
                getAlarmText=$(grep "$getONalarm" $AlarmDir/$AlarmFile | tail -1 | cut -d, -f4 | cut -c 2- | sed 's/ *$//')
                getAlarmTextTrimPIDs=$(echo "$getAlarmText" | cut -d"(" -f1 | sed 's/ *$//')
                registry=$(grep "$getAlarmTextTrimPIDs" $DIR/.temp/registry_sendTangoAlarm_SMTP_$todayExt | grep ON | wc -l)
                if [ "$registry" -eq 0 ];then
                        getAlarmId=$(grep "$getONalarm" $AlarmDir/$AlarmFile | tail -1 | cut -d, -f1 | cut -c 2-)
                        countONalarms=$(grep "ON," $AlarmDir/$AlarmFile | grep "$getAlarmText" | wc -l)
                        countOFFalarms=$(grep "OFF," $AlarmDir/$AlarmFile | cut -d"(" -f1 | grep "$getAlarmText" | wc -l)
                        if [ $countONalarms -ne $countOFFalarms ];then
                                echo "$hour $getONalarm" >> $DIR/.temp/registry_sendTangoAlarm_SMTP_$todayExt
                                title="Check $AlarmDir/$AlarmFile This alarm is activated:"
                                bodyOn=$(grep -A1 -B2 "ON,.*$getAlarmText" $AlarmDir/$AlarmFile | tail -n 4 | sed  's/$/<br>/')
                                summary=$(echo "$bodyOn" | grep Details | cut -d, -f4 | cut -d"<" -f1)
                                applicationName=$(echo "$bodyOn" | grep Source | cut -d"/" -f2)
                                severity=$(echo "$bodyOn" | grep Details | cut -d, -f3 | awk '{if($1==0){print "Critical"}else if($1==1){print "Major"}else{print "Minor"}}')
                                alarmID=$(echo "$bodyOn" | grep Details | cut -d, -f1 | cut -d"=" -f2 | tr -d '[[:space:]]')
                                buildEmailFile "alarm" "$bodyOn" "$bodyOff" "$title" "#ff0000" "Alarm Active" $applicationName"_"$severity"_"$alarmID "$summary"
                                sendEmailFlag="yes"
                        fi
                        if [ "$EmailPerAlarm" == "yes" ] || [ "$EmailPerAlarm" == "Yes" ] || [ "$EmailPerAlarm" == "True" ] || [ "$EmailPerAlarm" == "true" ];then
                                if [ "$sendEmailFlag" == "yes" ];then
                                        sendEmail
                                        tangoAlarmTitleAlreadySent="no"
                                        sendEmailFlag="no"
                                        echo "" > $DIR/.temp/email
                                fi
                        fi
                else
                        if [ "$verbose" == "true" ];then echo -e "["$red"ALARM"$reset"] ["$pink"Already Sent Today"$reset"] Check $AlarmDir/$AlarmFile This alarm is activated:"$bold"\n---\n$getAlarmText\n---\n"$reset;fi
                        printLog "[ALARM Already Sent Today]" "This alarm is activated: \"$getAlarmText\". Check $AlarmDir/$AlarmFile"
                        sendEmailFlag=no
                fi
        done <<< "$filteredONalarms"
        if [ "$countAllOFFalarms" -ne 0 ];then
                while  read getOFFalarm
                do
                        getAlarmText=$(grep "$getOFFalarm" $AlarmDir/$AlarmFile | tail -1 | cut -d, -f4 | cut -c 2- | sed 's/ *$//')
                        getAlarmTextTrimPIDs=$(echo "$getAlarmText" | cut -d"(" -f1 | sed 's/ *$//')
                        registry=$(grep "$getAlarmTextTrimPIDs" $DIR/.temp/registry_sendTangoAlarm_SMTP_$todayExt | grep OFF | wc -l)
                        if [ "$registry" -eq 0 ];then
                                getAlarmId=$(grep "$getOFFalarm" $AlarmDir/$AlarmFile | tail -1 | cut -d, -f1 | cut -c 2-)
                                countONalarms=$(grep "ON," $AlarmDir/$AlarmFile | grep "$getAlarmText" | wc -l)
                                countOFFalarms=$(grep "OFF," $AlarmDir/$AlarmFile | cut -d"(" -f1 | grep "$getAlarmText" | wc -l)
                                if [ $countONalarms -eq $countOFFalarms ];then
                                        if [ "$ReportCancelledAlarms" == "yes" ] || [ "$ReportCancelledAlarms" == "Yes" ] || [ "$ReportCancelledAlarms" == "True" ] || [ "$ReportCancelledAlarms" == "true" ];then
                                                echo "$hour $getOFFalarm" >> $DIR/.temp/registry_sendTangoAlarm_SMTP_$todayExt
                                                title="Check $AlarmDir/$AlarmFile This alarm was activated and cancelled afterwards:"
                                                bodyOff=$(grep -A1 -B2 "OFF,.*$getAlarmText" $AlarmDir/$AlarmFile | tail -n 4 | sed  's/$/<br>/')
                                                summary=$(echo "$bodyOff" | grep Details | cut -d, -f4 | cut -d"<" -f1)
                                                applicationName=$(echo "$bodyOff" | grep Source | cut -d"/" -f2)
                                                severity=$(echo "$bodyOff" | grep Details | cut -d, -f3 | awk '{if($1==0){print "Critical"}else if($1==1){print "Major"}else{print "Minor"}}')
                                                alarmID=$(echo "$bodyOff" | grep Details | cut -d, -f1 | cut -d"=" -f2 | tr -d '[[:space:]]')
                                                bodyOn=$(grep -A1 -B2 "ON,.*$getAlarmText" $AlarmDir/$AlarmFile | tail -n 4 | sed  's/$/<br>/')
                                                buildEmailFile "alarm" "$bodyOn" "$bodyOff" "$title" "#3cb371" "Alarm Cancelled" $applicationName"_"$severity"_"$alarmID "$summary"
                                                sendEmailFlag="yes"
                                        else
                                                title="Check $AlarmDir/$AlarmFile This alarm was activated and cancelled afterwards:"
                                                bodyOff=$(grep -A1 -B2 "OFF,.*$getAlarmText" $AlarmDir/$AlarmFile | tail -n 4 | sed  's/$/<br>/')
                                                summary=$(echo "$bodyOff" | grep Details | cut -d, -f4 | cut -d"<" -f1)
                                                applicationName=$(echo "$bodyOff" | grep Source | cut -d"/" -f2)
                                                severity=$(echo "$bodyOff" | grep Details | cut -d, -f3 | awk '{if($1==0){print "Critical"}else if($1==1){print "Major"}else{print "Minor"}}')
                                                alarmID=$(echo "$bodyOff" | grep Details | cut -d, -f1 | cut -d"=" -f2 | tr -d '[[:space:]]')
                                                bodyOn=$(grep -A1 -B2 "ON,.*$getAlarmText" $AlarmDir/$AlarmFile | tail -n 4 | sed  's/$/<br>/')
                                                if [ "$verbose" == "true" ];then echo -e "["$green"ALARM"$reset"] ["$lightblue"Cancelled"$reset"] "$bold"\n---\n$title $summary\n$applicationName"_"$severity"_"$alarmID\n---\n"$reset;fi
                                                printLog "[ALARM Cancelled]" "Email not to be sent. Check $DIR/sendTangoAlarm_SMTP.cfg \"$title\" \"$summary\""
                                                sendEmailFlag="no"
                                        fi
                                fi
                                if [ "$EmailPerAlarm" == "yes" ] || [ "$EmailPerAlarm" == "Yes" ] || [ "$EmailPerAlarm" == "True" ] || [ "$EmailPerAlarm" == "true" ];then
                                        if [ "$sendEmailFlag" == "yes" ];then
                                                sendEmail
                                                tangoAlarmTitleAlreadySent="no"
                                                sendEmailFlag="no"
                                                echo "" > $DIR/.temp/email
                                        fi
                                fi
                        else
                                if [ "$verbose" == "true" ];then echo -e "["$green"ALARM CANCELLED"$reset"] ["$pink"Already Sent Today"$reset"] Check $AlarmDir/$AlarmFile This alarm This alarm was activated and cancelled afterwards:"$bold"\n---\n$getAlarmText\n---\n"$reset;fi
                                printLog "[ALARM Cancelled]" "Email not to be sent. Check $DIR/sendTangoAlarm_SMTP.cfg \"$title\" \"$summary\""
                                sendEmailFlag=no
                        fi
                done <<< "$getAllOFFalarms"
        fi
elif [ "$SendKeepalive" == "yes" ] || [ "$SendKeepalive" == "Yes" ] || [ "$SendKeepalive" == "True" ] || [ "$SendKeepalive" == "true" ];then
        buildEmailFile "notAlarm" "Overall Alarms: There are currently not alarms activated"
        registry=$(grep "Overall Alarms: There are currently not alarms activated" $DIR/.temp/registry_sendTangoAlarm_SMTP_$todayExt | wc -l)
        if [ "$registry" -eq 0 ];then
                if [ "$verbose" == "true" ];then echo -e "["$green"OK"$reset"]  ["$lightblue"Sending"$reset"] "$bold"Overall Alarms:"$reset" There are currently not alarms activated\n";fi
                printLog "[KEEPALIVED Sending]" "There are currently not alarms activated"
                echo "$hour Overall Alarms: There are currently not alarms activated" >> $DIR/.temp/registry_sendTangoAlarm_SMTP_$todayExt
                sendEmailFlag=yes
        else
                if [ "$verbose" == "true" ];then echo -e "["$green"OK"$reset"] ["$pink"Already Sent Today"$reset"] "$bold"Overall Alarms:"$reset" There are currently not alarms activated\n";fi
                printLog "[KEEPALIVED already sent today]" "There are currently not alarms activated"
                sendEmailFlag=no
        fi
else
        if [ "$verbose" == "true" ];then echo -e "["$green"OK"$reset"]  ["$lightblue"Sending"$reset"] "$bold"Overall Alarms:"$reset" There are currently not alarms activated\n";fi
        printLog "[OK]" "There are currently not alarms activated"
fi
}

#-------------------
#  Main
#-------------------

# get Config Paramenters from ./sendTangoAlarm_SMTP.cfg
checkTmpDirFile
getGeneralParameters
getSMTPParameters
housekeeping

# Alarms
handleAlarms
if [ "$sendEmailFlag" == "yes" ];then
        sendEmail
        if [ "$verbose" == "true" ];then echo -e $green"\nComplete!\n"$reset;fi
fi

printLog "cleanlog" "----------------------- END -----------------------"

fi