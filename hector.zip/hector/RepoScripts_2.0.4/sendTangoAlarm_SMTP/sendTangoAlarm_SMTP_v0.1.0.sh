#!/bin/bash
##############################################################################
# Filename:    sendTangoAlarm_SMTP.sh
# Revision:    0.1.0
# Author:      Hector Barriga
#
# Jiras:
# CO Scripts:  COSC-131
#
# This script is to email Tango SW alarms via SMTP
#
# This sh script is mainly used for Tango  CO internal  monitoring
# Copyright (c) CSG Tango 2021
#
# All rights reserved.
# This document contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or
# in part is expressly prohibited, except as may be specifically
# authorized by prior written agreement or permission of Tango Telecom.
##############################################################################
# version 0.1.0 - First version
version="0.1.0"
#
##############################################################################

# Initial parameters
DIR=$(echo "`dirname $0`")
config_file=$DIR/sendTangoAlarm_SMTP.cfg
hostname=$(hostname)
todayExt=$(perl -e '@d=localtime time(); printf "%4d%02d%02d\n", $d[5]+1900,$d[4]+1,$d[3]')
HH=$(perl -e '@d=localtime time(); printf "%02d\n", $d[2]')
DD=$(perl -e '@d=localtime time(); printf "%02d\n", $d[3]')
hour=$(perl -e '@d=localtime time(); printf "[%02d:%02d:%02d]\n", $d[2],$d[1],$d[0]')
dday=$(date +%b)
red=`tput setaf 1`
green=`tput setaf 2`
yellow=`tput setaf 3`
blue=`tput setaf 4`
reset=`tput sgr0`
lightblue=`tput setaf 6`
pink=`tput setaf 5`
bold=`tput bold`
italic=`tput sitm`

# Flags and Mode
while getopts hv option;
do
        case $option in
                v) verbose="true";;
                h) echo "
        Usage: sendTangoAlarm_SMTP.sh
        Filename:    sendTangoAlarm_SMTP.sh
        Revision:    0.1.0
        Author:      Hector Barriga

        Jiras:
        CO Scripts:  COSC-131

        This sh script is to email when a Tango Alarm is triggered
        Copyright (c) Tango Telecom 2021

        All rights reserved.
        This document contains confidential and proprietary information of
        Tango Telecom and any reproduction, disclosure, or use in whole or
        in part is expressly prohibited, except as may be specifically
        authorized by prior written agreement or permission of Tango Telecom.


               Configuration:

               $DIR/sendTangoAlarm_SMTP.cfg

               Options:

               -h <help>                Show help
               -v <verbose>             To display (in blue) tests done by the script such as curls, telnet, etc.

               e.g. ./healthcheck.sh -v
                    It displays script results in case you wish to run them manually

               "; h="true";;
        esac
done
if [ "$h" != "true" ];then

#---------------
# SubRoutines
#---------------
housekeeping()
{
if [ ! -f $HK_purgeFilesScript ];then
        echo -e $red"\nSorry, HK_purgeFiles script $HK_purgeFilesScript does not exit. You must install it and configure it in $DIR/sendTangoAlarm_SMTP.cfg, bye\n"$reset
        exit
fi
$HK_purgeFilesScript $DIR/temp/ 0
}

checkTmpDirFile()
{
if [ ! -d $DIR/temp/ ];then mkdir $DIR/temp/;fi
if [ ! -f $DIR/temp/.registry_sendTangoAlarm_SMTP_$todayExt ];then touch $DIR/temp/.registry_sendTangoAlarm_SMTP_$todayExt;fi
}

getParameters()
{
oldIFS="$IFS"
IFS=":"
while read name value
do
    eval $name="$value"
done < $DIR/temp/.email
IFS="$oldIFS"
}

getGeneralParameters()
{
sed -n '/\[General]/,/\[/p' $DIR/sendTangoAlarm_SMTP.cfg | awk  '!/\[General]/ && !/\[/' | tr -d " \t\r" | awk '/Site/ || /Cluster/ || /AlarmDir/ || /AlarmFile/ || /EmailColor/ || /HK_purgeFilesScript/' | cut -d"#" -f1 | sed "s/=/:/g" > $DIR/temp/.email
getParameters
if [ "$verbose" == "true" ];then echo -e ""$yellow"\n================================================================================================\n Config Parameters\n================================================================================================"$reset$bold"\nFile = $DIR/sendTangoAlarm_SMTP.cfg\n"$reset"[Generic] Site = $Site\n[Generic] Cluster = $Cluster\n[Generic] Alarm Dir = $AlarmDir\n[Generic] Alarm File = $AlarmFile\n[Generic] Email Color = $EmailColor\n[Generic] HK_purgeFiles Script = $HK_purgeFilesScript";fi
}

getSMTPParameters()
{
sed -n '/\[SMTP]/,/\[/p' $DIR/sendTangoAlarm_SMTP.cfg | awk  '!/\[SMTP]/ && !/\[/' | tr -d " \t\r" | awk '/MailFrom/ || /ListEmailTo/ || /SMTPServerIP/ || /sendMailPerlScript/' | cut -d"#" -f1 | sed "s/=/:/g" > $DIR/temp/.email
getParameters
if [ "$verbose" == "true" ];then echo -e "[SMTP] Mail From = $MailFrom\n[SMTP] List Mail To = $ListEmailTo\n[SMTP] SMTP Server IP = $SMTPServerIP\n[SMTP] sendMail Perl Script = $sendMailPerlScript";fi
}

sendEmail()
{
if [ ! -f $sendMailPerlScript ];then
        echo -e $red"\nSorry, sendMail.pl script $sendMailPerlScript does not exit. You must install it and configure it in $DIR/sendTangoAlarm_SMTP.cfg, bye\n"$reset
        exit
fi
listMailTo=(`echo ${ListEmailTo} | sed 's/,/ /g'`)
listMailToLength=${#listMailTo[@]}
if [ "$verbose" == "true" ];then echo -e ""$yellow"\n================================================================================================\n Send Email\n================================================================================================"$reset"";fi
for (( j=0;j<$listMailToLength;j++))
do
        if [ "$verbose" == "true" ];then echo $yellow"$sendMailPerlScript -f $MailFrom  -t ${listMailTo[$j]} -n $MailFrom -s \"[$Site] $Cluster Alarms\" -x $SMTPServerIP -a \"cat $DIR/temp/.email\" -v"$reset ;fi
        $sendMailPerlScript -f $MailFrom  -t ${listMailTo[$j]} -n $MailFrom -s "[$Site] $Cluster Alarms" -x $SMTPServerIP -a "cat $DIR/temp/.email" -v
done
}

buildHtmlEmailFile()
{
if [ "$1" == "alarm" ];then
        echo "<table cellpadding=\"2\" style=\"white-space:wrap;border:2px solid black;border-collapse:collapse\">" >> $DIR/temp/.email
        if [ "$EmailColor" == "yes" ] || [ "$EmailColor" == "Yes" ] || [ "$EmailColor" == "True" ] || [ "$EmailColor" == "true" ];then
                echo "<tr cellpadding=\"2\" style=\"white-space:wrap;border:1px solid black;border-collapse:collapse\" bgcolor='$5'><th align=\"left\">[$7] $hostname<td>$6</td></th></tr>" >> $DIR/temp/.email
        else
                echo "<tr cellpadding=\"2\" style=\"white-space:wrap;border:1px solid black;border-collapse:collapse\" bgcolor='#ffffff'><th align=\"left\">[$7] $hostname<td>$6</td></th></tr>" >> $DIR/temp/.email
        fi
        echo "<tr><td style='width: 800px'><br>$4<br><br>$2<br>$3</td></tr>" >> $DIR/temp/.email
        echo "</table>" >> $DIR/temp/.email
        echo "<br>" >> $DIR/temp/.email
elif [ "$1" == "notAlarm" ];then
        echo "<table cellpadding=\"2\" style=\"white-space:wrap;border:2px solid black;border-collapse:collapse\">" >> $DIR/temp/.email
        if [ "$EmailColor" == "yes" ] || [ "$EmailColor" == "Yes" ] || [ "$EmailColor" == "True" ] || [ "$EmailColor" == "true" ];then
                echo "<tr cellpadding=\"2\" style=\"white-space:wrap;border:1px solid black;border-collapse:collapse\" bgcolor='#3cb371'><th align=\"left\">[NO ALARMS] $hostname<td style='width: 30px'>OK</td></th></tr>" >> $DIR/temp/.email
        else
                echo "<tr cellpadding=\"2\" style=\"white-space:wrap;border:1px solid black;border-collapse:collapse\" bgcolor='#ffffff'><th align=\"left\">[NO ALARMS] $hostname<td style='width: 30px'>OK</td></th></tr>" >> $DIR/temp/.email
        fi
        echo "<tr><td style='width: 400px'><br>$2<br><br></td></tr>" >> $DIR/temp/.email
        echo "</table>" >> $DIR/temp/.email
        echo "<br>" >> $DIR/temp/.email
fi
}

getAlarms()
{
echo "" > $DIR/temp/.email
if [ "$verbose" == "true" ];then echo -e ""$yellow"\n================================================================================================\n Tango Alarms\n================================================================================================"$reset"";fi
getAllONalarms=$(grep "ON," /tango/logs/aeh/alarm.log | cut -d"(" -f1 | sort -u)
countAllONalarms=$(grep "ON," /tango/logs/aeh/alarm.log | wc -l)
if [ "$countAllONalarms" -ne 0 ];then
        while  read getONalarm
        do
                getAlarmText=$(grep "$getONalarm" /tango/logs/aeh/alarm.log | tail -1 | cut -d, -f4 | cut -c 2- | sed 's/ *$//')
                getAlarmTextTrimPIDs=$(echo "$getAlarmText" | cut -d"(" -f1 | sed 's/ *$//')
                registry=$(grep "$getAlarmTextTrimPIDs" $DIR/temp/.registry_sendTangoAlarm_SMTP_$todayExt | wc -l)
                if [ "$registry" -eq 0 ];then
                        echo "$hour $getONalarm" >> $DIR/temp/.registry_sendTangoAlarm_SMTP_$todayExt
                        getAlarmId=$(grep "$getONalarm" /tango/logs/aeh/alarm.log | tail -1 | cut -d, -f1 | cut -c 2-)
                        countONalarms=$(grep "ON," /tango/logs/aeh/alarm.log | grep "$getONalarm" | wc -l)
                        countOFFalarms=$(grep "OFF," /tango/logs/aeh/alarm.log | cut -d"(" -f1 | grep "$getAlarmText" | wc -l)
                        if [ $countONalarms -ne $countOFFalarms ];then
                                title="Check /tango/logs/aeh/alarm.log This alarm is activated:"
                                bodyOn=$(grep -A1 -B2 "ON,.*$getAlarmText" /tango/logs/aeh/alarm.log | tail -n 4 | sed  's/$/<br>/')
                                applicationName=$(echo "$bodyOn" | grep Source | cut -d"/" -f2)
                                severity=$(echo "$bodyOn" | grep Details | cut -d, -f3 | awk '{if($1==0){print "Critical"}else if($1==1){print "Major"}else{print "Minor"}}')
                                alarmID=$(echo "$bodyOn" | grep Details | cut -d, -f1 | cut -d"=" -f2 | tr -d '[[:space:]]')
                                buildHtmlEmailFile "alarm" "$bodyOn" "$bodyOff" "$title" "#ff0000" "Alarm Active" $applicationName"_"$severity"_"$alarmID
                        else
                                title="Check /tango/logs/aeh/alarm.log This alarm was activated and cancelled afterwards:"
                                bodyOn=$(grep -A1 -B2 "ON,.*$getAlarmText" /tango/logs/aeh/alarm.log | tail -n 4 | sed  's/$/<br>/')
                                applicationName=$(echo "$bodyOn" | grep Source | cut -d"/" -f2)
                                severity=$(echo "$bodyOn" | grep Details | cut -d, -f3 | awk '{if($1==0){print "Critical"}else if($1==1){print "Major"}else{print "Minor"}}')
                                alarmID=$(echo "$bodyOn" | grep Details | cut -d, -f1 | cut -d"=" -f2 | tr -d '[[:space:]]')
                                bodyOff=$(grep -A1 -B2 "OFF,.*$getAlarmText" /tango/logs/aeh/alarm.log | tail -n 4 | sed  's/$/<br>/')
                                buildHtmlEmailFile "alarm" "$bodyOn" "$bodyOff" "$title" "#3cb371" "Alarm Cancelled" $applicationName"_"$severity"_"$alarmID
                        fi
                        if [ "$verbose" == "true" ];then echo -e "["$red"ALARM"$reset"] ["$lightblue"Sending"$reset"] $title"$bold"\n---\n$getAlarmText\n---\n"$reset;fi
                        alreadySent=yes
                else
                        if [ "$verbose" == "true" ];then echo -e "["$red"ALARM"$reset"] ["$pink"Already Sent Today"$reset"] $title"$bold"\n---\n$getAlarmText\n---\n"$reset;fi
                        alreadySent=no
                fi
        done <<< "$getAllONalarms"
else
        buildHtmlEmailFile "notAlarm" "Overall Alarms: There are not any activated"
        registry=$(grep "Overall Alarms: There are not any activated" $DIR/temp/.registry_sendTangoAlarm_SMTP_$todayExt | wc -l)
        if [ "$registry" -eq 0 ];then
                if [ "$verbose" == "true" ];then echo -e "["$green"OK"$reset"]  ["$lightblue"Sending"$reset"] "$bold"Overall Alarms:"$reset" There are not any activated\n";fi
                echo "$hour Overall Alarms: There are not any activated" >> $DIR/temp/.registry_sendTangoAlarm_SMTP_$todayExt
                alreadySent=yes
        else
                if [ "$verbose" == "true" ];then echo -e "["$green"OK"$reset"] ["$pink"Already Sent Today"$reset"] "$bold"Overall Alarms:"$reset" There are not any activated\n";fi
                alreadySent=no
        fi
fi
}

#-------------------
#  Main
#-------------------

# get Config Paramenters from ./sendTangoAlarm_SMTP.cfg
checkTmpDirFile
getGeneralParameters
getSMTPParameters
housekeeping

# Alarms
getAlarms
if [ "$alreadySent" == "yes" ];then
        sendEmail
        if [ "$verbose" == "true" ];then echo -e $green"\nComplete!\n"$reset;fi
fi



fi