#!/usr/bin/perl

#########################################
##This script is to unzip gz files in a certain directory
##
##./unzipAllFiles <directory where the files are>
## Jira: COSC-130
##
###########################################
#
# CK: 2/11/2017 - add send OAM alarm if no .gz file is available on each run
# CK: 13/11/2017 - Telefonica SNMP server requires a / appended to the source name
# CK: 15/11/2017 - add send AEHC external alarm
# HB: 01/03/2021 - Add scp to Business Connect RTE3/RTE4 and remove unzip.lock if it is last created 20 mins ago
# HB: 29/04/2021 - Introduce BC delay
#
###########################################
# Version 2.2
#
use Tango::Alarm::SendAlarmOmAgent;
use File::stat;
use Time::Local;
my $OM_AGENT_PORT=10181;
my $ENABLE_SEND_ALARM = 1;
my $VIRTUAL_IP = "192.168.98.103";
my $alarmHistoryFile = ".unzipFiles_AlarmHistory.txt";

# Additional Configuration
# Append a / to the hostname for alarm sending through SNMP traps
# 0 - NO
# 1 - YES
my $appendSlashToHostname = 1;

###########################################

my $secToSleep=120; # seconds to sleep between copys
my $secToSleep_BC=60; # seconds to sleep between transfer to RTE3/RTE4

my $ipCmd = "/usr/sbin/ip";
#my $ipCmd = "/sbin/ip";
my $grepCmd = "/usr/bin/grep";
#my $grepCmd = "/bin/grep";
#my $lsCmd = "/bin/ls";
my $lsCmd = "/usr/bin/ls";
#my $gzipCmd = "/bin/gzip";
my $gzipCmd = "/usr/bin/gzip";
#my $rmCmd = "/bin/rm";
my $rmCmd = "/usr/bin/rm";
#my $cpCmd = "/bin/cp";
my $cpCmd = "/usr/bin/cp";
my $scpCmd = "/usr/bin/scp";

my $lockFile="/tmp/unzip.lock";

#Check if lock file exsists
#       # yes -> exit
        # no -> continue
#
#

if(-e $lockFile)
{
        my @ABC = (stat($lockFile));
        my $FileTimeSinceLastCreated = time() - $ABC['File::stat'][9];
        if ($FileTimeSinceLastCreated < 60)
        {
                print("lock file exists. There is a process running already!!\n");
                exit(1);
        }
        else
        {
                print ("$lockFile was last created more than 20 mins ago. This is very suspicions. Machine could have rebooted and script could not remove it automatically. I will remove it now just in case\n");
                `$rmCmd $lockFile`;
        }
}
else
{
        print("No lock file...continue\n");
}

open(FH_LOCK,">",$lockFile) or die("cant create lock file $!");

my $directoryToLook=$ARGV[0];
my $copyFilesToDir=$ARGV[1];
my $copyFilesToDir2="";
chomp($directoryToLook);
chomp($copyFilesToDir);
print "Search for $directoryToLook\n";
my $pattern=$directoryToLook."\/\*\.gz";
my @files =`$lsCmd $pattern`;

if(($#files+1)<1)
{
        print "No files found... exiting\n";
        `$rmCmd $lockFile`;
        exit;
}

foreach (@files)
{
        $gzippedDirFile=$_;
        chomp($gzippedDirFile);
        print("File $gzippedDirFile\n");
        @uncompressedFile = split /\./, $gzippedDirFile;
        `$gzipCmd -d -f $gzippedDirFile`;
        `$cpCmd -n $uncompressedFile[0] $copyFilesToDir`;
}

#if there is a second directory to copy to
#3rd Argument is the secondary Directory
if (($#ARGV + 1)==3 or ($#ARGV + 1)==5)
{
        sleep ($secToSleep);
        $copyFilesToDir2=$ARGV[2];
        @uncompressedFile = ();
        foreach (@files)
        {
                $gzippedDirFile=$_;
                chomp($gzippedDirFile);
                @uncompressedFile = split /\./, $gzippedDirFile;
                @gzippedFile = split "/", $uncompressedFile[0];
                print "Copy $copyFilesToDir/$gzippedFile[-1] to secondary DIR $copyFilesToDir2\n";
                `$cpCmd -n $copyFilesToDir/$gzippedFile[-1] $copyFilesToDir2`;
        }
}
else
{
        print "No Copy to secondary Dir\n";
}

if (($#ARGV + 1)==5)
{

# If there is a third directory and a remote VIRTUAL_IP to transfer feedfile to
# 4th Argument is the the tertiary Directory
        sleep ($secToSleep_BC);
        $copyFilesToDir3=$ARGV[3];
        $REMOTE_VIRTUAL_IP=$ARGV[4];
        @uncompressedFile = ();
        foreach (@files)
        {
                $gzippedDirFile=$_;
                chomp($gzippedDirFile);
                @uncompressedFile = split /\./, $gzippedDirFile;
                @gzippedFile = split "/", $uncompressedFile[0];
                print "SCP Transfer $copyFilesToDir/$gzippedFile[-1] TO $REMOTE_VIRTUAL_IP DIR $copyFilesToDir3\n";
                `$scpCmd $copyFilesToDir/$gzippedFile[-1] $REMOTE_VIRTUAL_IP:$copyFilesToDir3`;
        }
}
else
{
        print "No Copy to third remote Dir\n";
}



# Start of new block added on 2/11/2017 -> COSC-97
if ( $ENABLE_SEND_ALARM == 1 )
{
  unless (-e $alarmHistoryFile)
  {
     open(FH_IHIST,">",$alarmHistoryFile) or die("Unable to create alarm history file $!");
     print FH_IHIST "OFF";
     close(FH_IHIST);
  }

  open(FH_OHIST, '<', $alarmHistoryFile) or die "Unable to open alarm history file $!";
  my $lastAlarmStatus = <FH_OHIST>;
  close(FH_OHIST);

  my $isActiveNode = checkForActiveNode(); # check if virtual IP exists. If not,skip sending alarm.
  if ( $isActiveNode == 1 )
  {
     if ( $lastAlarmStatus ne "ON" and $#files == -1 ) # if the array is empty, the index, $#files is -1
     {
        processAlarm("ON");
        open(FH_ON,">",$alarmHistoryFile) or die("Unable to create alarm history file $!");
        print FH_ON "ON";
        close(FH_ON);
     }
     elsif ( $lastAlarmStatus ne "OFF" and $#files >= 0 ) # if the array is not empty, the index is larger or equal to 0
     {
        processAlarm("OFF");
        open(FH_OFF,">",$alarmHistoryFile) or die("Unable to create alarm history file $!");
        print FH_OFF "OFF";
        close(FH_OFF);
     }
  }
  # Updated on 8/11/2017 - To clear active alarm when the node is not an active node. -> COSC-97
  elsif ( $lastAlarmStatus eq "ON" and $isActiveNode == 0 )
  {
     # This is no longer an active node. Clear the active alarm
     processAlarm("OFF");
     open(FH_OFF,">",$alarmHistoryFile) or die("Unable to create alarm history file $!");
     print FH_OFF "OFF";
     close(FH_OFF);

  }
  # End of new block added on 8/11/2017
}
# End of new block added on 2/11/2017

`$rmCmd $lockFile`;

# Start of sub routines added on 2/11/2017 -> COSC-97
sub processAlarm()
{
   my $alarmState = shift;
   chomp($alarmState);
   my $alarmObj=Tango::Alarm::SendAlarmOmAgent->new($OM_AGENT_PORT);
   my $hostname=`hostname`;
   chomp($hostname);
   # Added on 13/11/2017
   my $epochtime = time;
   my $shostname = $hostname;
   if ($appendSlashToHostname)
   {
      $shostname = $hostname."\/";
   }
   # End of 13/11/2017 update
   if ($alarmState eq "ON")
   {
     $alarmObj->sendAlarm(123,500,1,1,"TDR file from passive probe system is not received in Tango RTE",$shostname);
     sleep(3);
     $alarmObj->raiseExternalAlarm("TDR file not received",1,1,$epochtime,$epochtime,"UTC","RTE",$hostname,"OM_agent","OM_agent/0","TDR file from passive probe system is not received in Tango RTE");
   }
   else
   {
     $alarmObj->sendAlarm(123,500,0,1,"TDR file from passive probe system is not received in Tango RTE",$shostname);
     sleep(3);
     $alarmObj->clearExternalAlarm("TDR file not received",1,$epochtime,"UTC","RTE",$hostname,"OM_agent","OM_agent/0");
   }
}

sub checkForActiveNode()
{
   if ( `$ipCmd addr list | $grepCmd $VIRTUAL_IP` )
   {
      return 1;
   }
   else
   {
      return 0;
   }
}
# End of sub routines added on 2/11/2017