#!/bin/bash

DIR=$(echo "`dirname $0`")

#---------------------------------------------------------------
# Flags
#---------------------------------------------------------------

#---------------------------------------------------------------
# Subroutines
#---------------------------------------------------------------
help()
{
echo -e "
Usage: sp_Call_Purge_PMCSAlarmsEvents.sh

This sh is to purge old PMCS alarms and events

        Copyright (c) CSG 2025

                Options:

                -d <days>                  To purge alarms and events that are older than x days ago

                -h      <help>


Example: sp_Call_Purge_PMCSAlarmsEvents -d 30
It will purge alarms and events older than 30 days ago

PREREQUISITE:
You must create the following MySQL Stored Procedure before using this script. Run the following lines from MySQL command line

---------------------------------------------------------------------------------------------------
USE pmcsdb
DROP PROCEDURE IF EXISTS sp_Call_Purge_PMCSAlarmsEvents;
delimiter //
CREATE PROCEDURE \`sp_Call_Purge_PMCSAlarmsEvents\`(IN in_days int(32), OUT out_P0 varchar(64))
BEGIN
SET in_days = in_days - 1;
SET @old_date = (SELECT CURRENT_DATE - INTERVAL in_days DAY);
DELETE FROM alarm_log WHERE created_time < @old_date;
DELETE FROM event_log WHERE created_time < @old_date;
SET out_P0 = CONCAT('Records older than ',in_days,' have been purged');
END//
delimiter ;
---------------------------------------------------------------------------------------------------

"
}


while getopts  d:h option;
do
        case $option in
                d) days=$OPTARG;;
                h) help="true";;
        esac
done

if [ "$help" == "true" ] || [ -z "$1" ];then
        help
elif [ -z "$days" ] || ! [[ "$days" =~ [^a-zA-Z] ]];then
        echo "`tput setaf 1`Sorry, flag -d cannot be empty or alphanumeric, bye`tput sgr0`"
        help
else
        echo "use pmcsdb;call sp_Call_Purge_PMCSAlarmsEvents('$days',@A);" | mysql -u root
fi