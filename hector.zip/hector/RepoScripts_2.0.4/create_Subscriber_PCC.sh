#!/bin/bash
#

#Initial parameters
defmsisdn=353872958622
yellow=`tput setaf 3`
green=`tput setaf 2`
reset=`tput sgr0`

#subroutines

mainMenu()
{
echo "${green}
-----------------------------------
Main Menu

1) GET subscriber
2) POST new subscriber
3) GET subscriber plans (Same as SI SD uses - SRT_GET_PLANS)
4) DELETE subscriber
5) GET Subscriber PlanDefinitions (Create them via GUI)
6) POST PlanDefinition to subscriber
q) exit
-----------------------------------${reset}
"
}

getsubscriber()
{
echo "
-----------------------------------

RUNNING:
curl -i -X GET -H \"Content-Type: application/json\" -H \"Accept: application/json\" http://localhost:8080/spcm-rest-ws/pcc/spcm/subscribers/$msisdn

RESPONSE:"
curl -i -X GET -H "Content-Type: application/json" -H "Accept: application/json" http://localhost:8080/spcm-rest-ws/pcc/spcm/subscribers/$msisdn
echo "
-----------------------------------
"
}

postsubscriber()
{

echo "
-----------------------------------

RUNNING:
curl -i -X POST -H \"Content-Type: application/json\" -H \"Accept: application/json\"   -d '{\"msisdn\": '$msisdn',\"imsi\": '$msisdn',\"paymentType\": \"prepaid\",\"class\": \"SClass_Hector\",\"locale\": \"en\",\"status\": \"active\"}' http://localhost:8080/spcm-rest-ws/pcc/spcm/subscribers

RESPONSE:"
curl -i -X POST -H "Content-Type: application/json" -H "Accept: application/json"   -d '{"msisdn": '$msisdn',"imsi": '$msisdn',"paymentType": "prepaid","class": "SClass_Hector","locale": "en","status": "active"}' http://localhost:8080/spcm-rest-ws/pcc/spcm/subscribers
echo -n "
-----------------------------------

${yellow}Do you want to ADD an existing Plan Definitions? [y] > ${reset}"
read addpd
if [ -z "$addpd" ] || [ "$addpd" == "y" ]; then
  getsubscriberpd
  echo -n "${yellow}Enter Plan Definition Name > ${reset}"
  read plandefname
  postsubscriberpd
fi

}

getsubscriberplans()
{

echo "
-----------------------------------

RUNNING:
curl -i -X GET -H \"Content-Type: application/json\" -H \"Accept: application/json\" http://localhost:8080/spcm-rest-ws/pcc/spcm/subscribers/$msisdn/plans

RESPONSE:"
curl -i -X GET -H "Content-Type: application/json" -H "Accept: application/json" http://localhost:8080/spcm-rest-ws/pcc/spcm/subscribers/$msisdn/plans
echo "
-----------------------------------
"
}

deletesubscriber()
{

echo "
-----------------------------------

RUNNING:
curl -i -X DELETE -H \"Content-Type: application/json\" -H \"Accept: application/json\" http://localhost:8080/spcm-rest-ws/pcc/spcm/subscribers/$msisdn

RESPONSE:"
curl -i -X DELETE -H "Content-Type: application/json" -H "Accept: application/json" http://localhost:8080/spcm-rest-ws/pcc/spcm/subscribers/$msisdn
echo "
-----------------------------------
"
}

getsubscriberplandefinitions()
{

echo "
-----------------------------------

RUNNING:
curl -i -X GET -H \"Content-Type: application/json\" -H \"Accept: application/json\" http://localhost:8080/spcm-rest-ws/pcc/spcm/subscribers/$msisdn/planDefinitions

RESPONSE:"
curl -i -X GET -H "Content-Type: application/json" -H "Accept: application/json" http://localhost:8080/spcm-rest-ws/pcc/spcm/subscribers/$msisdn/planDefinitions
echo -n "
-----------------------------------
${yellow}Do you want to add a Plan Definition into a subscriber? [y] > ${reset}"
read confirmation
if [ "$confirmation" == "y" ] || [ -z "$confirmation" ]; then
  postsubscriberplandefinition
fi
}

getsubscriberpd()
{
echo "
-----------------------------------

RUNNING:
curl -i -X GET -H \"Content-Type: application/json\" -H \"Accept: application/json\" http://localhost:8080/spcm-rest-ws/pcc/spcm/subscribers/$msisdn/planDefinitions

RESPONSE:"
curl -i -X GET -H "Content-Type: application/json" -H "Accept: application/json" http://localhost:8080/spcm-rest-ws/pcc/spcm/subscribers/$msisdn/planDefinitions
echo "
-----------------------------------
"
}

postsubscriberpd()
{
echo "
-----------------------------------

RUNNING:
curl -i -X POST -H \"Content-Type: application/json\" -H \"Accept: application/vnd.com.tango.pcc.v1+json\"   -d '{\"planDefinition\": {\"name\": '$plandefname'}}' http://192.168.1.13:8080/spcm-rest-ws/pcc/spcm/subscribers/$msisdn/plans

RESPONSE:"
curl -i -X POST -H "Content-Type: application/json" -H "Accept: application/vnd.com.tango.pcc.v1+json"   -d '{"planDefinition": {"name": "'"$plandefname"'"}}' http://192.168.1.13:8080/spcm-rest-ws/pcc/spcm/subscribers/$msisdn/plans
echo "
-----------------------------------
"
}

postsubscriberplandefinition()
{
getsubscriberpd
echo -n "${yellow}Enter Plan Definition Name > ${reset}"
read plandefname
postsubscriberpd
}


# Main()

if [ -z "$1" ]; then
  echo -n "
${yellow}Enter msisdn [Default $defmsisdn] > ${reset}"
        read msisdn
        if [ -z "$msisdn" ];then
          msisdn=$defmsisdn
        fi
fi

while(true)
do
  mainMenu
  echo -n "${yellow}Enter Option [Default Opt 1] > ${reset}"
  read mainmenuopt
  case $mainmenuopt in
   1) getsubscriber;;
   2) postsubscriber;;
   3) getsubscriberplans;;
   4) deletesubscriber;;
   5) getsubscriberplandefinitions;;
   6) postsubscriberplandefinition;;
   q|quit|exit) break;;
  esac
done