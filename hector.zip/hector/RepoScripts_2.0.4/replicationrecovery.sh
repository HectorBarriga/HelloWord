#!/bin/bash
#############################################################################
# Filename:    replicationrecovery.sh
# Revision:    $Revision: 0.1.0 $
# Author:      Hector Barriga
#
# This sh script displays the commands that should be run to recover database
# replication for DRC and DRCM databases
#
# Copyright (c) Tango Telecom 2016
# Author: Hector Barriga
#
# All rights reserved.
# This document contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or
# in part is expressly prohibited, except as may be specifically
# authorized by prior written agreement or permission of Tango Telecom.
##############################################################################
# version 0.1.0 - First version
# version 0.2.0 - Add flag "-t" for replication tests
# version 0.2.0 - Add advice to shutdown tango processes if SPCM is running
# version 0.2.2 - Add MySQL_IPM restart
# version 0.2.3 - Protect master databases if wrong configurations
version=0.2.3
#
##############################################################################

#---------------------------------------------------------------
# Configurations
#---------------------------------------------------------------
mysqlmasterhost="tangoI"
mysqlslavehost="tangoJ"
mysqluser="root"
mysqlpw="t3il3achum"
perconaServer="false"
mysql_ipm="true"
mysql_ipm_file="/tango/scripts/MYSQL_IPM/MYSQL_IPM.pl"
mysql_ipm_config_file="/tango/scripts/MYSQL_IPM/MYSQL_IPM.cfg"
rootPassword="type alias sur"

#---------------------------------------------------------------
# Set Initial variables
#---------------------------------------------------------------
namehost=$(hostname)
if [ "$namehost" == $mysqlmasterhost ];then
        getMasterNameHost=$(hostname)
else
        getMasterNameHost=$(ssh $mysqlmasterhost "hostname")
fi
if [ "$namehost" == $getMasterNameHost ];then
        echo -e "\n`tput setaf 1`DANGEROUS, replicationrecovery.sh has the WRONG master configured in parameter mysqlmasterhost=$mysqlmasterhost . Set the CORRECT master. Note you fix replication on SLAVE server. So if you are fixing on this server $namehost, it MUST NOT be the master. It is dangerous, you can drop the master server's databases :(  `tput sgr0` Bye\n"
        exit
fi
whichmysql=$(which mysql)
isPWinMyCnf=$(cat /etc/my.cnf | egrep -v "#" | grep $mysqlpw | egrep -v grep)
if [ ! -z "$isPWinMyCnf" ];then
        gomysql=$(echo "$whichmysql -u$mysqluser")
        gomysqlslave=$(echo "$whichmysql -u$mysqluser -h $mysqlslavehost")
        gomysqlmaster=$(echo "$whichmysql -u$mysqluser -h $mysqlmasterhost")
else
        gomysql=$(echo "$whichmysql -u$mysqluser -p$mysqlpw")
        gomysqlslave=$(echo "$whichmysql -u$mysqluser -p$mysqlpw -h $mysqlslavehost")
        gomysqlmaster=$(echo "$whichmysql -u$mysqluser -p$mysqlpw -h $mysqlmasterhost")
fi

#---------------------------------------------------------------
# Flags
#---------------------------------------------------------------
while getopts th option;
do
        case $option in
                t) test="true";;
                h) echo -e "
        Usage: replicationrecovery.sh
        version: $version

        This sh script displays the commands that should be run to recover database
        replication for DRC and DRCM databases. Besides, it can also test replication
        is working ok
        `tput setaf 1`NOTE: Commands will NOT be run by script. You need to copy and run them manually`tput sgr0`

        Copyright (c) Tango Telecom 2018

               Options:

               -t <test>                To test replication is working ok

               -h <help>                Show help

               e.g. ./clusterNetTest.sh
               This will only display the commands that should be run to recover replication

               e.g. ./clusterNetTest.sh -t
               This will only test replicaiton  ";help="true";;
        esac
done

#---------------------------------------------------------------
# Subroutines
#---------------------------------------------------------------

getReplicationDB()
{
mysqlbin=$(echo "show master status;" | $gomysqlmaster | egrep -v File | awk '{print $1}')
mysqlpos=$(echo "show master status;" | $gomysqlmaster | egrep -v File | awk '{print $2}')
if [ "$perconaServer" == "true" ];then
        mysqldb=$(echo "show databases;" | $gomysqlmaster | egrep -v sys | egrep -v Database | egrep -v mysql | egrep -v information_schema | egrep -v performance_schema | xargs | sed -e 's/ /,/g')
else
        mysqldb=$(echo "show master status;" | $gomysqlmaster | egrep -v File | awk '{print $3}')
fi
mysqldbarray=(`echo $mysqldb | sed 's/,/\n/g'`)
mysqldbarraylength=${#mysqldbarray[@]}
echo "# DEBUG: getReplicationDB"
i=0
for (( i=0;i<$mysqldbarraylength;i++))
do
        echo "# DEBUG: "${mysqldbarray[$i]}
done
}

stopMysqlIPM()
{
mysql_ipm_file_temp=$(echo "$mysql_ipm_file"".temp")
echo "mv $mysql_ipm_file $mysql_ipm_file_temp;"
echo "rm /tango/logs/.MYSQL_IPM.pl.disable /tango/logs/.MYSQL_IPM.pl.lock;"
MySQL_IPM_int=$(cat /tango/scripts/MYSQL_IPM/MYSQL_IPM.cfg | grep logicalIpAddress | cut -d"#" -f1 | sed '/^\s*$/d' | cut -d, -f2 | tr -d ' ')
echo "su root"
echo "`tput setaf 2`$rootPassword `tput sgr0`"
echo "ifconfig $MySQL_IPM_int:0 down"
echo "`tput setaf 3`ssh $mysqlmasterhost and repeat above steps!!!`tput sgr0`"
echo "ssh root@$mysqlmasterhost"
echo "`tput setaf 2`$rootPassword `tput sgr0`"
echo "`tput setaf 3`exit and go back to $mysqlslavehost!!!`tput sgr0`"
echo "echo \"drop database ipmdb;\" | $gomysqlmaster;"
echo "echo \"drop database ipmdb;\" | $gomysqlslave;"
}

startMysqlIPM()
{
mysql_ipm_file_temp=$(echo "$mysql_ipm_file"".temp")
echo "mv $mysql_ipm_file_temp $mysql_ipm_file;"
echo "ssh $mysqlmasterhost \"mv $mysql_ipm_file_temp $mysql_ipm_file;\""
echo "sed -i '/mysqlUptime/c mysqlUptime                  = 1m' $mysql_ipm_config_file;"
echo -e "\n#`tput setaf 1`WAIT UNTIL VIP IS SET UP AND ROLLBACK $mysql_ipm_config_file JUST RUN THIS COMMAND ON MASTER NODE:`tput sgr0`\nsed -i '/mysqlUptime/c mysqlUptime                  = 10m' $mysql_ipm_config_file;\n"
}

stoptomkilltom()
{
echo "`tput setaf 3`# NOTE IF SPCM IS RUNNING HERE!!!!!! Stop tomcat on master node !!!`tput sgr0`"
echo "`tput setaf 3`# NOTE IF SPCM IS RUNNING HERE !!!!!! Stop tango processes via lm on both machiens !!!`tput sgr0`"
echo "stoptom;"
echo "killtom;"
echo "lm;"
}

locktables()
{
echo "echo \"FLUSH TABLES WITH READ LOCK;\" | $gomysqlslave;"
echo "master_status -h $mysqlmasterhost;"
echo "echo \"FLUSH TABLES WITH READ LOCK;\" | $gomysqlmaster;"
}

backupDBslave()
{
i=0
mysqldbarraylength=${#mysqldbarray[@]}
for (( i=0;i<$mysqldbarraylength;i++))
do
        if [ ! -z "$isPWinMyCnf" ];then
                echo "mysqldump ${mysqldbarray[$i]} -u $mysqluser --routines -h $mysqlmasterhost > $dir/replicationrecovery_${mysqldbarray[$i]}_$mysqlmasterhost.dump;"
        else
                echo "mysqldump ${mysqldbarray[$i]} -u $mysqluser --routines -p$mysqlpw -h $mysqlmasterhost > $dir/replicationrecovery_${mysqldbarray[$i]}_$mysqlmasterhost.dump;"
        fi
done
i=0
for (( i=0;i<$mysqldbarraylength;i++))
do
        if [ ! -z "$isPWinMyCnf" ];then
                echo "mysqldump ${mysqldbarray[$i]} -u $mysqluser --routines -h $mysqlslavehost > $dir/replicationrecovery_${mysqldbarray[$i]}_$mysqlslavehost.dump;"
        else
                echo "mysqldump ${mysqldbarray[$i]} -u $mysqluser --routines -p$mysqlpw -h $mysqlslavehost > $dir/replicationrecovery_${mysqldbarray[$i]}_$mysqlslavehost.dump;"
        fi
done
}

dropAndCreateReplicationDBonSlave()
{
mysqldbarraylength=${#mysqldbarray[@]}
i=0
for (( i=0;i<$mysqldbarraylength;i++))
do
        echo "echo \"drop database ${mysqldbarray[$i]};\" | $gomysqlslave;"
        echo "echo \"create database ${mysqldbarray[$i]};\" | $gomysqlslave;"
done
}

recoverDumps()
{
mysqldbarraylength=${#mysqldbarray[@]}
i=0
for (( i=0;i<$mysqldbarraylength;i++))
do
        echo "$gomysqlslave  ${mysqldbarray[$i]} < $dir/replicationrecovery_${mysqldbarray[$i]}_$mysqlmasterhost.dump;"
done
}

startreplication()
{
echo "echo \"STOP SLAVE;\" | $gomysqlmaster;"
echo "echo \"STOP SLAVE;CHANGE MASTER TO MASTER_HOST='$mysqlmasterhost', MASTER_USER='$mysqluser', MASTER_PASSWORD='$mysqlpw', MASTER_LOG_FILE='$mysqlbin', MASTER_LOG_POS=$mysqlpos;START SLAVE;\" | $gomysqlslave;"
}

unlocktables()
{
echo "echo \"UNLOCK TABLES;\" | $gomysqlslave;"
echo "echo \"UNLOCK TABLES;\" | $gomysqlmaster;"
}

startom()
{
echo "`tput setaf 3`# NOTE IF SPCM IS RUNNING HERE !!!!!! Start tango processes via lm on both machiens !!!`tput sgr0`"
echo "`tput setaf 3`# NOTE IF SPCM IS RUNNING HERE!!!!!! Start tomcat on master node !!!`tput sgr0`"
echo "lm;"
echo "startom;"
}

testReplication()
{
echo "`tput setaf 3`#---------------------- START ---------------------------`tput sgr0`"
isThereTestDB=$(echo "show databases;" | $gomysqlmaster | grep testreplication)
getSlave_IO_RunningOnMaster=$(echo "show slave status\G;" | $gomysqlmaster | grep Slave_IO_Running | cut -d":" -f2 | tr -d " ")
getSlave_SQL_RunningOnMaster=$(echo "show slave status\G;" | $gomysqlmaster | grep Slave_SQL_Running | egrep -v State | cut -d":" -f2 | tr -d " ")
getSlave_IO_RunningOnSlave=$(echo "show slave status\G;" | $gomysqlslave | grep Slave_IO_Running | cut -d":" -f2 | tr -d " ")
getSlave_SQL_RunningOnSlave=$(echo "show slave status\G;" | $gomysqlslave | grep Slave_SQL_Running | egrep -v State | cut -d":" -f2 | tr -d " ")

if [ "$getSlave_IO_RunningOnSlave" == "Yes" ] && [ "$getSlave_SQL_RunningOnSlave" == "Yes" ];then
        echo "`tput setaf 2`$mysqlslavehost is the SLAVE (as per \"show slave status\")`tput sgr0`"
elif [ "$getSlave_IO_RunningOnMaster" == "Yes" ] && [ "$getSlave_SQL_RunningOnMaster" == "Yes" ];then
        echo "`tput setaf 2`$mysqlmasterhost is the SLAVE (Remote machine!!! - No $mysqlslavehost !!!)`tput sgr0`"
        oldMysqlmasterhost=$mysqlmasterhost
        mysqlmasterhost=$mysqlslavehost
        mysqlslavehost=$oldMysqlmasterhost
        gomysqlslave=$(echo "$whichmysql -u$mysqluser -p$mysqlpw" -h $mysqlslavehost)
        gomysqlmaster=$(echo "$whichmysql -u$mysqluser -p$mysqlpw" -h $mysqlmasterhost)
else
        replicationbroken="true"
fi

if [ -z "$isThereTestDB" ];then
        echo -e "`tput setaf 1`Sorry, \"testreplication\" database doesn't exist on master machine $mysqlslavehost, hence it is not replicating. I need it to test replication.\nCreate it, add it in my.cnf in \"binlog-do-db\" and restart mysql on both machines. Bye\n`tput sgr0`"
elif [ "$replicationbroken" == "true" ];then
        echo -e "`tput setaf 1`Replication is broken!!! Run \"./replicationrecovery.sh\" to fix it. Bye\n`tput sgr0`"
else
        getLastRec=$(echo "use testreplication;select name from test_table order by id desc limit 1;" | $gomysqlmaster | egrep -v name | cut -d"-" -f1 | tr -s " " | rev | cut -c 1-2 | rev)
        pNewRec=$(echo "$getLastRec + 1" | bc)
        newRec=$(printf %02d $pNewRec)
        echo "insert into testreplication.test_table (name) values ('testvalue$newRec-Replicating from $mysqlmasterhost to $mysqlslavehost');" | $gomysqlmaster
        echo "`tput setaf 3`Inserting new record in \"testreplication.test_table\" in master machine $mysqlmasterhost ..."
        echo "mysql[$mysqlmasterhost]> insert into testreplication.test_table (name) values ('testvalue$newRec-Replicating from $mysqlmasterhost to $mysqlslavehost');`tput sgr0`"
        getNewRecMaster=$(echo "use testreplication;select name from test_table order by id desc limit 1;" | $gomysqlmaster | egrep -v name)
        getNewRecSlave=$(echo "use testreplication;select name from test_table order by id desc limit 1;" | $gomysqlslave | egrep -v name)
        echo "`tput setaf 3`#--------------------------------------------------------`tput sgr0`"
        if [ "$getNewRecMaster" == "$getNewRecSlave" ];then
                echo "`tput setaf 2`Replication is working OK"
                echo "`tput sgr0`echo \"use testreplication;select name from test_table;\" | $gomysqlmaster"
                echo "`tput sgr0`echo \"use testreplication;select name from test_table;\" | $gomysqlslave"
        else
                echo -e "`tput setaf 1`Replication is broken!!! Run \"./replicationrecovery.sh\" to fix it.`tput sgr0`"
                echo "`tput sgr0`echo \"use testreplication;select name from test_table;\" | $gomysqlmaster"
                echo "`tput sgr0`echo \"use testreplication;select name from test_table;\" | $gomysqlslave"
        fi
        echo "`tput setaf 3`#------------------- FINISHED ---------------------------`tput sgr0`"
fi
}


if [ "$help" ==  "true" ];then
        echo ""
else
#---------------------------------------------------------------
# Script
# main()
#---------------------------------------------------------------
    if [ "$test" != "true" ];then
        echo "`tput setaf 3`#---------------------- START ---------------------------`tput sgr0`"
        echo "`tput setaf 2`#
#            Welcome to replicationrecovery.sh
#                   version: $version
#
# This sh script displays the commands that should be run to recover database
# replication for DRC and DRCM databases. Besides, it can also test replication
# is working ok
# `tput setaf 1`NOTE: Commands will NOT be run by script. You need to copy and run them manually`tput setaf 2`
#
# Copyright (c) Tango Telecom 2018
#
# Options:
#
# -t <test>                To test replication is working ok
# -h <help>                Show help
#
# e.g. ./replicationrecovery.sh
# This will only display the commands that should be run to recover replication
#
# e.g. ./replicationrecovery.sh -t
# This will only test replication
#`tput sgr0`"
        echo "`tput setaf 3`#--------------------------------------------------------`tput sgr0`"
        echo -n "Enter directory in where you want to dump DBs > "
        read dir
        if [ -z "$dir" ];then
                dir=$(pwd)
        elif [ "$dir" == "hector" ];then
                dir="/tango/logs/COSTAFF/hector"
        else
                lastChar=${dir: -1}
                if [ "${dir: -1}" == "/" ];then
                        dir=$(echo $dir | rev | cut -c 2- | rev)
                fi
        fi
        echo "cd $dir;"
        echo "`tput setaf 3`#----------- Get Databases to be replicated--------------`tput sgr0`"
        getReplicationDB
        echo "`tput setaf 3`#-----------Stop data being inserted into DBs------------`tput sgr0`"
        stoptomkilltom
        locktables
        if [ "$mysql_ipm" == "true" ];then
                echo "`tput setaf 3`#------------------- Stop MYSQL_IPM ---------------------`tput sgr0`"
                stopMysqlIPM
        fi
        echo "`tput setaf 3`#---------Dump (Export) DBs from both Machines-----------`tput sgr0`"
        backupDBslave
        echo "`tput setaf 3`#---------Drop and reCreate DBs On Slave node------------`tput sgr0`"
        dropAndCreateReplicationDBonSlave
        echo "`tput setaf 3`#-------Restore (Import) Master DBs into Slave-----------`tput sgr0`"
        recoverDumps
        echo "`tput setaf 3`#-----------------Activate Replication-------------------`tput sgr0`"
        startreplication
        if [ "$mysql_ipm" == "true" ];then
                echo "`tput setaf 3`#------------------- Start MYSQL_IPM ---------------------`tput sgr0`"
                startMysqlIPM
        fi
        echo "`tput setaf 3`#--------Resume data being inserted into DBs-------------`tput sgr0`"
        unlocktables
        startom
        echo "`tput setaf 3`#--------------------Check Status------------------------`tput sgr0`"
        echo "slave_status;"
        echo "slave_status -h $mysqlmasterhost;"
        echo "`tput setaf 3`#------------------- FINISHED ---------------------------`tput sgr0`"
        echo -e "`tput setaf 2`\nDo you want to test replication is ok just run replicationrecovery.sh -t\n`tput sgr0`"
     else
        testReplication
     fi
fi
cd $dir
exec bash