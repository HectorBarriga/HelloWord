#!/bin/bash
today=$(perl -e '@d=localtime time()-86400; printf "%4d%02d%02d %02d%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1]')
if [ "$2" == "createPolicy" ];then
        echo "-------------------- REQUEST: --------------------"
        echo -e "`tput setaf 3`\033[1mCREATE POLICY `tput sgr0`"
        echo "`tput setaf 3`curl -D headers.txt -k -H \"Content-Type: application/json\" -X POST -d @$1/create-policy.json https://sutl023:8080/npcf-smpolicycontrol/v1/sm-policies | jq;cat headers.txt`tput sgr0`"
        echo "-------------------- RESPONSE: -------------------"
        curl -D $1/headers.txt -k -H "Content-Type: application/json" -X POST -d @$1/create-policy.json https://sutl023:8080/npcf-smpolicycontrol/v1/sm-policies | jq;
        echo "-------------------- HEADER RESP: ----------------"
        cat $1/headers.txt | sed '/^[[:space:]]*$/d'
        echo "--------------------------------------------------"
        logLocation=$(cat $1/headers.txt | grep location | cut -d" " -f2)
        echo "[$today] $logLocation" >> $1/.pcf_locations
elif [ "$2" == "updatePolicy" ];then
        dos2unix $1/.pcf_locations
        echo "----------------- LIST LOCATIONS: ----------------"
        echo "`tput setaf 5`"
        cat $1/.pcf_locations
        getLastLocation=$(tail -1 $1/.pcf_locations | cut -d"]" -f2)
        echo -e -n "`tput setaf 3`\nEnter URL Location [Default = Last Location`tput setaf 5`$getLastLocation`tput setaf 3`] > `tput sgr0`"
        read readLastLocation
        if [ -z "$readLastLocation" ];then
                readLastLocation=$getLastLocation
        fi
        echo "-------------------- REQUEST: --------------------"
        echo -e "`tput setaf 3`\033[1mUPDATE POLICY `tput sgr0`"
        echo "`tput setaf 3`curl -D headers.txt -k -H \"Content-Type: application/json\" -X POST -d @$1/update-policy.json $readLastLocation/update | jq;cat headers.txt`tput sgr0`"
        echo "-------------------- RESPONSE: -------------------"
        curl -D $1/headers.txt -k -H "Content-Type: application/json" -X POST -d @$1/update-policy.json $readLastLocation/update | jq;
        echo "-------------------- HEADER RESP: ----------------"
        cat $1/headers.txt | sed '/^[[:space:]]*$/d'
        echo "--------------------------------------------------"
elif [ "$2" == "deletePolicy" ];then
        dos2unix $1/.pcf_locations
        echo "----------------- LIST LOCATIONS: ----------------"
        echo "`tput setaf 5`"
        cat $1/.pcf_locations
        getLastLocation=$(tail -1 $1/.pcf_locations | cut -d"]" -f2)
        echo -e -n "`tput setaf 3`\nEnter URL Location [Default = Last Location`tput setaf 5`$getLastLocation`tput setaf 3`] > `tput sgr0`"
        read readLastLocation
        if [ -z "$readLastLocation" ];then
                readLastLocation=$getLastLocation
        fi
        echo "-------------------- REQUEST: --------------------"
        echo -e "`tput setaf 3`\033[1mDELETE POLICY `tput sgr0`"
        echo "`tput setaf 3`curl -D headers.txt -k -H \"Content-Type: application/json\" -X POST -d @$1/delete-policy.json $readLastLocation/delete | jq;cat headers.txt`tput sgr0`"
        echo "-------------------- RESPONSE: -------------------"
        curl -D $1/headers.txt -k -H "Content-Type: application/json" -X POST -d @$1/delete-policy.json $readLastLocation/delete | jq;
        echo "-------------------- HEADER RESP: ----------------"
        cat $1/headers.txt | sed '/^[[:space:]]*$/d'
        echo "--------------------------------------------------"
fi