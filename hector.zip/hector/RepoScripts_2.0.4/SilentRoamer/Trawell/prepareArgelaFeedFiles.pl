#!/usr/bin/perl
##############################################################################
# Filename:    prepareArgelaFeedFiles.pl
# Revision:    $Revision: 1.0.0 $
# Author:      Hector Barriga
#
# CO Scripts:  COSC-128
#
# This perl script is to move TurkTelekom Argela feedfiles in a certain directory after a configurable trigger delay interval.
# The purpose of this trigger delay interval is for Logstash NOT to trigger SIBB for a while and then it gives the chance to subscriber to
# get cached in the Activity Meter by a PDP Context CDR. It means that if a PDP context CDR is generated (So subs is not a Silent Roamer anymore),
# filebeed-Logstash inserts the PDP Context record into Activity Meter and then SIBB will not trigger the Silent Roamer event
#
# Copyright (c) Tango Telecom 2019
#
# All rights reserved.
# This document contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or
# in part is expressly prohibited, except as may be specifically
# authorized by prior written agreement or permission of Tango Telecom.
##############################################################################
# version 1.0.0 - First version
##############################################################################

use Getopt::Std;
use Tango::Alarm::SendAlarmOmAgent;

my $TRIGGER_DELAY=60; # seconds to sleep between copys
my @scriptPath = split '/', $0;
my $scriptName = $scriptPath[$#scriptPath];
my $scriptCanonicalName = (split/\./,$scriptName)[0];
$0 =~ m/(.+)[\/\\](.+)$/;
my $scriptRelativePath=$1;
my $scriptTmpFile = $scriptRelativePath."/.tmp";

# Alarm Handler Confirutaions
my $OM_AGENT_PORT=10181;
my $ENABLE_SEND_ALARM = 1;
my $VIRTUAL_IP = "10.248.99.24";
my $alarmHistoryFile = "/home/tango/scripts/Generic/tools/.unzipFiles_AlarmHistory";
# Additional Configuration
# Append a / to the hostname for alarm sending through SNMP traps
# 0 - NO | 1 - YES
my $appendSlashToHostname = 1;

#########################################################################
# Lets not upset the machine.. ;)
setpriority(0,0,10);

#checkForRoot();
#################################### VERSION ############################
my $VERSION = "1.0.0";
my $subVersion = "\n$scriptName Script version $VERSION \n";
   $subVersion .= "Copyright by Tango Telecom 2019 (c)\n";
   $subVersion .= "All rights reserved.\n\n\n";

#########################################################################
# GENERAL PARAMETERS
my $VERBOSE_FLAG =1;
my $DEBUG_FILE = "$scriptCanonicalName"."_".getLocalDateForFile().".log";
my $DEBUG_LOGDIR = "/tango/logs/$scriptCanonicalName";
my $CMD_FIND = `which find`;
chomp($CMD_FIND);
my $CMD_MOVE = `which mv`;
chomp($CMD_MOVE);
my $CMD_TOUCH = `which touch`;
chomp($CMD_TOUCH);
my $CMD_IP = "/usr/sbin/ip";
my $CMD_GREP = `which grep`;
chomp($CMD_GREP);


#########################################################################
# Flags
getopts( "i:f:d:s:t:hv" );

$DEBUG_LOGDIR = $opt_l if ( defined( $opt_l) );
my $DEBUG_LOGFILE = "$DEBUG_LOGDIR/$DEBUG_FILE";
`mkdir $DEBUG_LOGDIR` if ( ! -d $DEBUG_LOGDIR);

if (!defined( $opt_d) || !defined( $opt_s) || !defined( $opt_i) || !defined( $opt_f))
{
    printLog("Flags -d, -s, -f and -i are mandatory\n") if !defined($opt_h);
    usage();
    exit 0;
}

main();
exit(0);

sub main
{
        $TRIGGER_DELAY = $opt_t if ( defined( $opt_t) );
        sleep($TRIGGER_DELAY);
        $VERBOSE_FLAG = 1 if ( defined( $opt_v) );
        $SOURCE_DIR = $opt_s if ( defined( $opt_s) );
        $DEST_DIR = $opt_d if ( defined( $opt_d) );
        $FILE_PREFIX = $opt_f if ( defined( $opt_f) );
        $FILE_HOLD_BEFORE_MINS = $opt_i if ( defined( $opt_i) );
        printLog("[ERROR] $SOURCE_DIR does not exist") if ( ! -d "$SOURCE_DIR");
        exit if ( ! -d "$SOURCE_DIR");
        printLog("[ERROR] $DEST_DIR does not exist, Bye") if ( ! -d "$DEST_DIR");
        exit if ( ! -d "$DEST_DIR");

        alarmHandler();
        moveFiles();
}

sub alarmHandler
{
        if ( $ENABLE_SEND_ALARM == 1 )
        {
                  unless (-e $alarmHistoryFile)
                  {
                             open(FH_IHIST,">",$alarmHistoryFile) or die("Unable to create alarm history file $!");
                             print FH_IHIST "OFF";
                             close(FH_IHIST);
                  }

                  open(FH_OHIST, '<', $alarmHistoryFile) or die "Unable to open alarm history file $!";
                  my $lastAlarmStatus = <FH_OHIST>;
                  close(FH_OHIST);
                  my $isActiveNode = checkForActiveNode(); # check if virtual IP exists. If not,skip sending alarm.

                  my $cmd = "$CMD_FIND $SOURCE_DIR -type f -cmin +0 -name $FILE_PREFIX*";
                  my @getFiles = `$cmd`;

                  if ( $isActiveNode == 1 )
                  {
                             if ( $lastAlarmStatus ne "ON" and $#getFiles == -1 ) # if the array is empty, the index, $#areThereFiles is -1
                             {
                                        processAlarm("ON");
                                        open(FH_ON,">",$alarmHistoryFile) or die("Unable to create alarm history file $!");
                                        print FH_ON "ON";
                                        close(FH_ON);
                             }
                             elsif ( $lastAlarmStatus ne "OFF" and $#getFiles >= 0 ) # if the array is not empty, the index is larger or equal to 0
                             {
                                        processAlarm("OFF");
                                        open(FH_OFF,">",$alarmHistoryFile) or die("Unable to create alarm history file $!");
                                        print FH_OFF "OFF";
                                        close(FH_OFF);
                             }
                  }
                  elsif ( $lastAlarmStatus eq "ON" and $isActiveNode == 0 )
                  {
                             # This is no longer an active node. Clear the active alarm
                             processAlarm("OFF");
                             open(FH_OFF,">",$alarmHistoryFile) or die("Unable to create alarm history file $!");
                             print FH_OFF "OFF";
                             close(FH_OFF);
                  }
        }
}

sub processAlarm()
{
           my $alarmState = shift;
           chomp($alarmState);
           my $alarmObj=Tango::Alarm::SendAlarmOmAgent->new($OM_AGENT_PORT);
           my $hostname=`hostname`;
           chomp($hostname);
           # Added on 13/11/2017
           my $epochtime = time;
           my $shostname = $hostname;
           if ($appendSlashToHostname)
           {
              $shostname = $hostname."\/";
           }
           if ($alarmState eq "ON")
           {
             $alarmObj->sendAlarm(123,500,1,1,"TDR file from Argela probe system is not received in Tango RTE",$shostname);
             sleep(3);
             $alarmObj->raiseExternalAlarm("TDR file not received",1,1,$epochtime,$epochtime,"Istanbul","RTE",$hostname,"OM_agent","OM_agent/0","TDR file from Argela probe system is not received in Tango RTE");
             printLog("[ALARM ON] \"TDR file not received\",1,1,$epochtime,$epochtime,\"Istanbul\",\"RTE\",$hostname,\"OM_agent\",\"OM_agent/0\",\"TDR file from Argela probe system is not received in Tango RTE\"");
           }
           else
           {
             $alarmObj->sendAlarm(123,500,0,1,"TDR file from Argela probe system is not received in Tango RTE",$shostname);
             sleep(3);
             $alarmObj->clearExternalAlarm("TDR file not received",1,$epochtime,"Istanbul","RTE",$hostname,"OM_agent","OM_agent/0");
             printLog("[ALARM OFF] \"TDR file not received\",1,$epochtime,\"Istanbul\",\"RTE\",$hostname,\"OM_agent\",\"OM_agent/0\"");
           }
}

sub checkForActiveNode()
{
   if ( `$CMD_IP addr list | $CMD_GREP $VIRTUAL_IP` )
   {
      return 1;
   }
   else
   {
      return 0;
   }
}

sub moveFiles
{
        my $cmd = "$CMD_FIND $SOURCE_DIR -type f -cmin +$FILE_HOLD_BEFORE_MINS -name $FILE_PREFIX*";
        printLog("Getting Files... $cmd");
        my @getFiles = `$cmd`;
        foreach my $foundFile (@getFiles)
        {
                chomp($foundFile);
                printLog( "Moving and touching ....   $CMD_MOVE $foundFile $DEST_DIR" );
                `$CMD_TOUCH $foundFile`;
                `$CMD_MOVE $foundFile $DEST_DIR`;
        }
        return;
}

sub printLog
{
   my $msg = shift;
   my $DATE = getLocalDate();
   my $TIME = getLocalTime();
   my $msg_header = '[' . $DATE . ' ' . $TIME . ']';

   if (open(FH_printDebug,">>$DEBUG_LOGFILE"))
   {
        print FH_printDebug $msg_header, $msg, "\n";
        print "$msg_header $msg \n" if ($VERBOSE_FLAG);
        close (FH_printDebug);
   }
   else
   {
     die "printLog :: Can't append to debug file (Maybe script is not running as tango user) \"$DEBUG_LOGFILE\"";
   }
}

sub getLocalTime
{
  my $sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst;
  ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
  my $local_time = sprintf "%02d:%02d:%02d", $hour, $min, $sec;
  return $local_time;
}

sub getLocalDate
{
   my $sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst;
  ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
  $year = $year + 1900;
  $mon += 1;
  my $local_date = sprintf "%02d%02d%04d", $mday, $mon, $year;
  return $local_date;
}

sub getLocalDateForFile {
   my $sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst;
  ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
  $year = $year + 1900;
  $mon += 1;
  my $local_date_f = sprintf "%04d%02d%02d", $year, $mon, $mday;
  return $local_date_f;
}

##################################################################################################################################
sub usage
{
    my $getBashrcPerl5lib = `grep PERL5LIB /home/tango/.bashrc | wc -l`;
    printLog("[WARNING] export PERL5LIB=\$PERL5LIB:/tango/scripts/tangoPerlLib/lib is missing in /home/tango/.bashrc") if ( $getBashrcPerl5lib == "0");

    print <<EO_USAGE;

Usage: $scriptName
Jira: COSC-128
Version: $VERSION


        MANDATORY
        -d <SOURCE_DIR> Path of the folder where feefiles are to be copied FROM. It should be directory where Argela server drops the feedfiles to
        -s <DEST_DIR> Path of the folder where feedfiles are to be copied TO. It should be FILEBEAT_TRIGGERING_PATH (Check /etc/sysconfile/filebeat)
        -f <FILE_PREFIX> Prefix of the files to be copied
        -i <FILE_HOLD_BEFORE_MINS> Number of Minutes to tell script HOW OLD the last files should be copied from SOURCE_DIR into DEST_DIR

        OPTIONAL
        -v Displays the verbose debug entries
        -t <TRIGGER_DELAY> Time in seconds for script to start. [Default = 0secs]


        EXAMPLE
        1.  /home/tango/scripts/Generic/tools/prepareArgelaFeedFiles.pl -s /tango/data/silentroamer/fileload/ -f TDR-ARGELA -d /tango/data/silentroamer/fileload/ready/ -i 1800 -t 60
        Script will starts actually running after 60 mins. Then it will move all files /tango/data/silentroamer/fileload/TDR-ARGELA* older than 30 mins into /tango/data/silentroamer/fileload/ready/ folder


EO_USAGE
}

sub help
{
    print <<EO_HELP;

Help for script $scriptname (c) Tango Telecom 2019


EO_HELP

    usage();
}