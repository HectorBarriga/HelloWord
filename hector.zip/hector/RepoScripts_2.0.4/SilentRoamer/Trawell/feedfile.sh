#!/bin/bash
#############################################################################
# Filename:    feedfile.sh
#
# This sh script is to run End-To-End tests for Silent Roamer Telefonica
#
# Copyright (c) Tango Telecom 2017
# Author: Hector Barriga
#
# All rights reserved.
# This document contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or
# in part is expressly prohibited, except as may be specifically
# authorized by prior written agreement or permission of Tango Telecom.
##############################################################################
# version 0.1.0 - First version
# version 0.1.2 - Add multitenancy
# version 0.1.3 - Add Offer Acceptance
version=0.1.3
#
##############################################################################

#---------------------------------------------------------------
# Configurations
#---------------------------------------------------------------
mysqlmasterhost="mblshadpdbt00"
mysqluser="root"
mysqlpw="t3il3achum"
logstashMachine=mblshasrappt00
spcmMachine=mblshadpappt00

#subroutines

showfeedfile()
{
columnnames=$(echo "MSISDN,Date_and_time")
file=$(cat $1 | grep $msisdnorig)
ofile=$(cat $1 | grep $msisdnorig | paste -sd' ')
echo ""
echo "`tput setaf 5`CDR:"
echo "`tput setaf 3`$file"
echo "`tput sgr0`"
echo "`tput setaf 5`List of Fields:`tput sgr0`"
c=0
IFS=","
for i in $ofile
do
        if [ "$c" == "2" ];then
                c=0
                echo ""
        fi
        d=$((c+1))
        getColumnname=$(echo "$columnnames" | cut -d, -f"$d")
        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-1s \033[0;39m\n' $c. $getColumnname "=" $i
        let ++c
done
echo ""
}

showSIcdrs()
{
if [ ! -d "/tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp" ];then
        mkdir /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp
fi
echo "------------------------------------------------------------------------------------------------------------------"
echo "`tput setaf 3`cp /tango/data/cdr/active_SI.cdr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SI_tangoTBC.cdr`tput sgr0`"
echo "`tput setaf 3`scp tangoD:/tango/data/cdr/active_SI.cdr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SI_tangoD.cdr`tput sgr0`"
cp /tango/data/cdr/active_SI.cdr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SI_tangoTBC.cdr
scp tangoD:/tango/data/cdr/active_SI.cdr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SI_tangoD.cdr
ls -altr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SI*
sessionIdSiCdrs=$(cat  /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SI* | grep "$msisdnin" | tail -1 | cut -d, -f6)
timeSiCdrs=$(cat  /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SI* | grep "$sessionIdSiCdrs" | tail -1 | cut -d, -f5)
echo "`tput setaf 3`cat  /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SI* | grep $msisdnin | egrep $sessionIdSiCdrs`tput sgr0`"
sicdrs=$(cat  /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SI* | grep $msisdnin | egrep "$sessionIdSiCdrs")
if [ -z "$sicdrs" ];then
        echo ""
        echo "`tput setaf 1`No SI CDRs!!!`tput setaf 5` It seems CDR didnt pass the filters as per trigger_generator.cfg.
Very likely \"`tput setaf 1`Current EPOCH time in Hex\"`tput setaf 5` is too old"
        echo "HOWEVER!!! check:
    1. offset time is not OK. It means Start_Date_and_time and End_Date_and_time are TOO old (See feedfile CDRs first 2 fields)
    2 SI SD is available for VPLMN=$fvisitplmn
    3. active_SI.cdr may have rolled over, check /tango/data/cdr/ussd_si/
    4. trigger_generator.cfg is not configured properly`tput sgr0`"
        echo ""
else
        /tango/logs/COSTAFF/hector/sh_scripts/SI_tool/SI_tool.pl -p $sessionIdSiCdrs
fi
}

showUNScdrs()
{
echo "------------------------------------------------------------------------------------------------------------------"
echo "`tput setaf 3`cp /tango/data/cdr/active_UNS_SMS.cdr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_UNS_SMS_tangoTBC.cdr`tput sgr0`"
echo "`tput setaf 3`scp tangoD:/tango/data/cdr/active_UNS_SMS.cdr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_UNS_SMS_tangoD.cdr`tput sgr0`"
cp /tango/data/cdr/active_UNS_SMS.cdr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_UNS_SMS_tangoTBC.cdr
scp tangoD:/tango/data/cdr/active_UNS_SMS.cdr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_UNS_SMS_tangoD.cdr
ls -altr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_UNS_SMS*
echo "`tput setaf 3`cat /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_UNS_SMS* | grep $msisdnorig | egrep \"$timeSiCdrs\"`tput sgr0`"
IsThereunsCDRs=$(cat /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_UNS_SMS* | grep "$msisdnorig" | egrep "$timeSiCdrs" | tail -2)
unsCDRs=$(cat /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_UNS_SMS* | grep "$msisdnorig" | egrep "$timeSiCdrs" | tail -2)
if [ -z "$IsThereunsCDRs" ];then
        echo ""
        echo -e "`tput setaf 1`No CDRs!!!`tput setaf 5` It seems NO SMS was sent to subscriber. Either:\n   1. Subscriber must have received it already\n   2. There is not Campaign configured in PMUI for VPLMN=$fvisitplmn \n   3. active_UNS_SMS.cdr file rolled over\n   4. UNS is not running or something`tput sgr0`"
        echo ""
else
        echo "$unsCDRs"
fi
}

showSOMcdrs()
{
echo "------------------------------------------------------------------------------------------------------------------"
echo "`tput setaf 3`cp /tango/data/cdr/active_SOM.cdr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SOM_tangoTBC.cdr`tput sgr0`"
echo "`tput setaf 3`scp tangoD:/tango/data/cdr/active_SOM.cdr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SOM_tangoD.cdr`tput sgr0`"
cp /tango/data/cdr/active_SOM.cdr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SOM_tangoTBC.cdr
scp tangoD:/tango/data/cdr/active_SOM.cdr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SOM_tangoD.cdr
ls -altr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SOM*
echo "`tput setaf 3`cat /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SOM* | grep $msisdnorig | egrep \"$sessionIdSiCdrs\"`tput sgr0`"
somcdrs=$(cat /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SOM* | grep "$msisdnorig" | egrep "$sessionIdSiCdrs")
IsTheresomcdrs=$(cat /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SOM* | grep "$msisdnorig" | egrep "$sessionIdSiCdrs" | cut -d, -f1)
if [ -z $IsTheresomcdrs ];then
        echo ""
        echo "`tput setaf 1`No CDRs!!!`tput setaf 5` It seems cdr file rolled over or CDRH (SOM) process is not running or something`tput sgr0`"
        echo ""
else
        echo "$somcdrs"
fi
}

getOfferStatus()
{
namehost=$(hostname)
if [ "$mysqlmasterhost" == "$namehost" ];then
        whichmysql=$(which mysql)
        isPWinMyCnf=$(cat /etc/my.cnf | grep $mysqlpw | egrep -v grep)
        if [ ! -z "$isPWinMyCnf" ];then
                gomysql=$(echo "$whichmysql -u$mysqluser")
        else
                gomysql=$(echo "$whichmysql -u$mysqluser -p$mysqlpw")
        fi
        getOfferStatus=$(echo "select status from Offer where msisdn = '$msisdnorig';" | $gomysql promotion_$tenant | egrep -v status)
        Offer=$(echo "select * from Offer where msisdn = '$msisdnorig'\G;" | $gomysql promotion_$tenant)
else
        whichmysql=$(ssh tango@$mysqlmasterhost 'which mysql')
        getOfferStatus=$(ssh tango@$mysqlmasterhost "$whichmysql -u '$mysqluser' -p'$mysqlpw' promotion_$tenant -e 'select status from Offer where msisdn = '$msisdnorig';' | egrep -v status" 2>/dev/null)
        Offer=$(ssh tango@$mysqlmasterhost "$whichmysql -u '$mysqluser' -p'$mysqlpw' promotion_$tenant -e 'select * from Offer where msisdn = '$msisdnorig'\G;'" 2>/dev/null)
fi
}

getOfferUuidAndTenantID()
{
namehost=$(hostname)
if [ "$mysqlmasterhost" == "$namehost" ];then
        whichmysql=$(which mysql)
        isPWinMyCnf=$(cat /etc/my.cnf | grep $mysqlpw | egrep -v grep)
        if [ ! -z "$isPWinMyCnf" ];then
                gomysql=$(echo "$whichmysql -u$mysqluser")
        else
                gomysql=$(echo "$whichmysql -u$mysqluser -p$mysqlpw")
        fi
        Offer=$(echo "select * from Offer where msisdn = '$msisdnorig'\G;" | $gomysql promotion_$tenant)
        getOfferUuid=$(echo "select uuid from Offer where msisdn = '$msisdnorig';" | $gomysql promotion_$tenant | egrep -v uuid)
        getOfferTenant=$(echo "select tenantId from Offer where msisdn = '$msisdnorig';" | $gomysql promotion_$tenant | egrep -v tenantId)
else
        whichmysql=$(ssh tango@$mysqlmasterhost 'which mysql')
        Offer=$(ssh tango@$mysqlmasterhost "$whichmysql -u '$mysqluser' -p'$mysqlpw' promotion_$tenant -e 'select * from Offer where msisdn = '$msisdnorig'\G;'" 2>/dev/null)
        getOfferUuid=$(ssh tango@$mysqlmasterhost "$whichmysql -u '$mysqluser' -p'$mysqlpw' promotion_$tenant -e 'select uuid from Offer where msisdn = '$msisdnorig';' | egrep -v uuid" 2>/dev/null)
        getOfferTenant=$(ssh tango@$mysqlmasterhost "$whichmysql -u '$mysqluser' -p'$mysqlpw' promotion_$tenant -e 'select tenantId from Offer where msisdn = '$msisdnorig';' | egrep -v tenantId" 2>/dev/null)
fi
}

getSIBBlogs()
{
sleep 5
echo "------------------------------------------------------------------------------------------------------------------"
echo "`tput setaf 3`cp /tango/logs/sibb/sibb-service.log /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/sibb-service_tangoTBC.log`tput sgr0`"
#echo "`tput setaf 3`scp tangoD:/tango/logs/sibb/sibb-service.log /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/sibb-service_tangoD.log`tput sgr0`"
cp /tango/logs/sibb/sibb-service.log /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/sibb-service_tangoTBC.log
#scp tangoD:/tango/logs/sibb/sibb-service.log /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/sibb-service_tangoD.log
echo "`tput setaf 3`cat /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/sibb-service*.log | grep \"$msisdnorig\"`tput sgr0`"
IsTherehrgLogs=$(cat /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/sibb-service*.log | grep "$msisdnorig")
if [ -z "$IsTherehrgLogs" ];then
        echo ""
        echo -e "`tput setaf 1`No Logs!!!`tput setaf 5` It seems NO SMS was sent to subscriber. Either:\n   1. Logstash is not running\n 2. Filebeat is not running\n 3. SIBB_WSMS is not running`tput sgr0`"
        echo ""
else
        echo "$IsTherehrgLogs"
fi
}

showSIBBcdrs()
{
if [ ! -d "/tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp" ];then
        mkdir /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp
fi
echo "------------------------------------------------------------------------------------------------------------------"
echo "`tput setaf 3`cp /tango/data/cdr/active_SIBB_SR.cdr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SIBB_SR_tangoTBC.cdr`tput sgr0`"
#echo "`tput setaf 3`scp tangoD:/tango/data/cdr/active_SIBB_SR.cdr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SIBB_SR_tangoD.cdr`tput sgr0`"
cp /tango/data/cdr/active_SIBB_SR.cdr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SIBB_SR_tangoTBC.cdr
#scp tangoD:/tango/data/cdr/active_SIBB_SR.cdr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SIBB_SR_tangoD.cdr
ls -altr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SIBB_SR*
echo "`tput setaf 3`cat  /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SIBB_SR* | grep $msisdnorig`tput sgr0`"
sibbCDRs=$(cat  /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SIBB_SR* | grep "$msisdnorig")
if [ -z "$sibbCDRs" ];then
        echo ""
        echo "`tput setaf 1`No SIBB CDRs!!!`tput setaf 5` It seems CDR didnt pass the filters as per SIBB conditions
Very likely \"`tput setaf 1`Current time \"`tput setaf 5` is too old"
        echo "HOWEVER!!! check /tango/logs/sibb/sibb-service.log`tput sgr0`"
        echo ""
else
        echo "$sibbCDRs"
fi
echo "------------------------------------------------------------------------------------------------------------------"
}

checkAMDB()
{
namehost=$(hostname)
if [ "$mysqlmasterhost" == "$namehost" ];then
        whichmysql=$(which mysql)
        isPWinMyCnf=$(cat /etc/my.cnf | grep $mysqlpw | egrep -v grep)
        if [ ! -z "$isPWinMyCnf" ];then
                gomysql=$(echo "$whichmysql -u$mysqluser")
        else
                gomysql=$(echo "$whichmysql -u$mysqluser -p$mysqlpw")
        fi
        echo "------------------------------------------------------------------------------------------------------------------"
        echo "`tput setaf 3`echo \"select * from activity where msisdn = '$msisdnorig'\G;\" | $gomysql activity_meter`tput sgr0`"
        subType=$(echo "select * from activity where msisdn = '$msisdnorig'\G;" | $gomysql activity_meter)
else
        whichmysql=$(ssh tango@$mysqlmasterhost 'which mysql')
        echo "`tput setaf 3`ssh tango@$mysqlmasterhost '$whichmysql -u$mysqluser -p$mysqlpw activity_meter -e \"select * from activity where msisdn = '$msisdnorig'\G;\"'`tput sgr0`"
        subType=$(ssh tango@$mysqlmasterhost "$whichmysql -u '$mysqluser' -p'$mysqlpw' activity_meter -e 'select * from activity where msisdn = '$msisdnorig'\G;'" 2>/dev/null)
fi
echo "$subType"
echo "------------------------------------------------------------------------------------------------------------------"
}


checkOfferPromotionDB()
{
namehost=$(hostname)
if [ "$mysqlmasterhost" == "$namehost" ];then
        whichmysql=$(which mysql)
        isPWinMyCnf=$(cat /etc/my.cnf | grep $mysqlpw | egrep -v grep)
        if [ ! -z "$isPWinMyCnf" ];then
                gomysql=$(echo "$whichmysql -u$mysqluser")
        else
                gomysql=$(echo "$whichmysql -u$mysqluser -p$mysqlpw")
        fi
        echo "------------------------------------------------------------------------------------------------------------------"
        getOfferStatus=$(echo "select status from Offer where msisdn = '$msisdnorig';" | $gomysql promotion_$tenant | egrep -v status)
        echo "`tput setaf 3`echo \"select * from Offer where msisdn = '$msisdnorig'\G;\" | $gomysql promotion_$tenant`tput sgr0`"
        Offer=$(echo "select * from Offer where msisdn = '$msisdnorig'\G;" | $gomysql promotion_$tenant)
else
        whichmysql=$(ssh tango@$mysqlmasterhost 'which mysql')
        getOfferStatus=$(ssh tango@$mysqlmasterhost "$whichmysql -u '$mysqluser' -p'$mysqlpw' promotion_$tenant -e 'select status from Offer where msisdn = '$msisdnorig';' | egrep -v status" 2>/dev/null)
        echo "`tput setaf 3`ssh tango@$mysqlmasterhost '$whichmysql -u$mysqluser -p$mysqlpw promotion_$tenant -e \"select * from Offer where msisdn = '$msisdnorig'\G;\"'`tput sgr0`"
        Offer=$(ssh tango@$mysqlmasterhost "$whichmysql -u '$mysqluser' -p'$mysqlpw' promotion_$tenant -e 'select * from Offer where msisdn = '$msisdnorig'\G;'" 2>/dev/null)
fi
echo "$Offer"
echo "------------------------------------------------------------------------------------------------------------------"
}

# main ()
echo "------------------------------------------------------------------------------------------------------------------"
echo "`tput setaf 2`                               Welcome to \"feedfile.sh\" simulator for Telefonica
                                                version: $version             `tput sgr0`"
echo "------------------------------------------------------------------------------------------------------------------"
cd /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer
echo "`tput setaf 3`Going to /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/`tput sgr0`"
echo "------------------------------------------------------------------------------------------------------------------"
ls -alrt | egrep -v feedfile
echo "------------------------------------------------------------------------------------------------------------------"
defaultfeedfile=$(ls -altr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/ | egrep -v feedfile | egrep -v total | egrep -v "drwxr" | tail -1 | awk "{print \$9}")
echo -n "`tput setaf 3`Enter feed file [Default = $defaultfeedfile] > `tput sgr0`"
read feedfile
if [ -z $feedfile ];then
        feedfile=$defaultfeedfile
fi
if [ ! -f ./$feedfile ];then
        echo ""
        echo "`tput setaf 1`File doesnt exist!!!`tput sgr0` Nothing done, Bye"
        echo ""
else
echo "------------------------------------------------------------------------------------------------------------------"
echo -n "`tput setaf 3`Do you wanna edit the file? [y/n] (Default n) > `tput sgr0`"
read confirm
if [ -z "$confirm" ]; then
        sleep 0
else
        if [ "$confirm" == "y" ];then
                vi $feedfile
        fi
fi
echo "------------------------------------------------------------------------------------------------------------------"
echo "`tput setaf 3`List of Silent Roamers:`tput sgr0`"
cat $feedfile | while read in
do
        getmsisdn=$(echo $in | cut -d"," -f1)
        if [ -z $getmsisdn ] || [ "$getmsisdn" == "_" ]; then
                part1=$(echo "MSISDN= <empty>\t\t")
        else
                part1=$(echo "MSISDN= $getmsisdn\t")
        fi
        color=2
        if [ -z "$getmsisdn" ] || [ "$getmsisdn" == "_" ];then
                color=1
                part2='[NO GOOD TDR, SIBB wont be triggered]'
        fi
        echo -e "$part1""\t`tput setaf $color`$part2`tput sgr0`"
done

echo "------------------------------------------------------------------------------------------------------------------"
lastmsisdnin=$(cat $feedfile | head -1 | cut -d"," -f1)
echo -n "`tput setaf 3`Enter msisdn you would like to monitor [Default = First on the list $lastmsisdnin]  = > `tput sgr0`"
read selectedmsisdn
if [ -z "$selectedmsisdn" ];then
        msisdnin=$(cat $feedfile | grep $lastmsisdnin | cut -d"," -f1 | sed 's/./&0/g' | cut -d= -f2 | sed 's/0 020403/20403/' | sed 's/.$//' | head -1)
        msisdnorig=$lastmsisdnin
else
        msisdnin=$(cat $feedfile | grep $selectedmsisdn | cut -d"," -f1 | sed 's/./&0/g' | cut -d= -f2 | sed 's/0 020403/20403/' | sed 's/.$//' | head -1)
        msisdnorig=$selectedmsisdn
fi


echo ""
echo "`tput setaf 5`############################### NOTE: ####################################
# You selected `tput sgr0`$msisdnorig`tput setaf 5` to be monitored.
# You will see results only for that subscriber in particular (below).   #
# However, all GOOD CDRs from input feedfile will ALSO be processed      #
##########################################################################
`tput sgr0`"

date1=$(echo "$feedfile" | cut -d"-" -f3)
sec1=$(echo "$date1" | rev | cut -c1-2 | rev)
date2=$(echo "$feedfile" | cut -d"-" -f4)
sec2=$(echo "$date2" | rev | cut -c1-2 | rev)

if [[ $sec1 -eq 59 ]];then
        newdate1=$(($date1 + 41))
else
        newdate1=$(($date1 + 1))
fi
if [[ $sec2 -eq 59 ]];then
        newdate2=$(($date2 + 41))
else
        newdate2=$(($date2 + 1))
fi
anothernewdate=$(($date + 2))
prefixnewfile=$(echo "$feedfile" | rev | cut -c30- | rev)
newfeedfile=$(echo "$prefixnewfile""$newdate1""-""$newdate2")
echo "------------------------------------------------------------------------------------------------------------------"
mv $feedfile $newfeedfile
feedfile=$(echo "$newfeedfile")
echo "`tput setaf 3`Feed file is now: `tput sgr0`$feedfile"
echo ""
showfeedfile "$feedfile"
echo "------------------------------------------------------------------------------------------------------------------"
currentTime=$(date '+%Y-%m-%d %H:%M:%S')
echo "`tput setaf 2`FYI : New Line should be = `tput sgr0` $msisdnorig,$currentTime"
echo "------------------------------------------------------------------------------------------------------------------"
echo -n "`tput setaf 3`Do you wanna re-edit it? [y/n] (Default n) > `tput sgr0`"
read confirm
if [ -z "$confirm" ]; then
        sleep 0
else
        if [ "$confirm" == "y" ];then
                vi $feedfile
                showfeedfile "$feedfile"
                echo "------------------------------------------------------------------------------------------------------------------"
        fi
fi

echo -n "`tput setaf 3`Do you wanna drop it in /tango/data/silentroamer/fileload/ [y/n] > `tput sgr0`"
read confirm
if [ "$confirm" == "y" ] || [ -z "$confirm" ];then
        echo -e "\n------------------------------------------------------------------------------------------------------------------"
        cp $feedfile /tango/data/silentroamer/fileload/
        chmod 777 /tango/data/silentroamer/fileload/$feedfile
        echo -n "`tput setaf 3`When do you want prepareArgelaFeedFiles.pl to move feedfile into /tango/data/silentroamer/ready/ so filebeat can process it. [Enter num of mins] [Default = 0] > `tput sgr0`"
        read minDelay
        if [ -z "$minDelay" ];then
                minDelay=0;
                echo "`tput setaf 2`PERL5LIB=$PERL5LIB:/tango/scripts/tangoPerlLib/lib perl /tango/scripts/Generic/tools/prepareArgelaFeedFiles.pl -i 0 -t `tput setaf 3`$minDelay`tput setaf 2` -s /tango/data/silentroamer/fileload/ -d /tango/data/silentroamer/ready -f $feedfile`tput sgr0`"
                echo -n "Moving in 3 Secs *"
                sleep 1
                echo -n " *"
                sleep 1
                echo -n " *"
                sleep 1
                echo " * [Moving Now]"
                PERL5LIB=$PERL5LIB:/tango/scripts/tangoPerlLib/lib perl /tango/scripts/Generic/tools/prepareArgelaFeedFiles.pl -i 0 -t 0 -s /tango/data/silentroamer/fileload/ -d /tango/data/silentroamer/ready -f $feedfile
        else
                echo "`tput setaf 2`PERL5LIB=$PERL5LIB:/tango/scripts/tangoPerlLib/lib perl /tango/scripts/Generic/tools/prepareArgelaFeedFiles.pl -i 0 -t `tput setaf 3`$minDelay`tput setaf 2` -s /tango/data/silentroamer/fileload/ -d /tango/data/silentroamer/ready -f $feedfile`tput sgr0`"
                b=0
                minDelaySecs=$(($minDelay * 60))
                while [ "$b" -lt "$minDelaySecs" ]
                do
                        if [ "$b" -eq "30" ];then echo -n "0.5min "
                        elif [ "$b" -eq "60" ];then echo -n "1min "
                        elif [ "$b" -eq "90" ];then echo -n "1.5mins "
                        elif [ "$b" -eq "120" ];then echo -n "2mins "
                        elif [ "$b" -eq "150" ];then echo -n "2.5mins "
                        elif [ "$b" -eq "180" ];then echo -n "3mins "
                        elif [ "$b" -eq "210" ];then echo -n "3.5mins "
                        elif [ "$b" -eq "240" ];then echo -n "4mins "
                        elif [ "$b" -eq "270" ];then echo -n "4.5mins "
                        elif [ "$b" -eq "300" ];then echo -n "5mins "
                        else echo -n "* ";fi
                        b=$(($b + 5))
                        sleep 5
                done
                echo " * [Moving Now]"
                PERL5LIB=$PERL5LIB:/tango/scripts/tangoPerlLib/lib perl /tango/scripts/Generic/tools/prepareArgelaFeedFiles.pl -i 0 -t $minDelay -s /tango/data/silentroamer/fileload/ -d /tango/data/silentroamer/ready -f $feedfile
        fi
        echo -en "\n`tput setaf 3`Wait until LOGSTASH processes $feedfile and triggers SIBB * "
        finishedprocessed="false"
        a=0
        while [ $a -lt 30 ]
        do
                sleep 0.5
                echo -n "* "
                let a++
        done
        echo -n " Done`tput sgr0`"
        echo ""
        echo "------------------------------------------------------------------------------------------------------------------`tput setaf 2`"
        echo "`tput setaf 3`ls -atlr /tango/data/silentroamer/fileload/ | grep $newfeedfile `tput sgr0`"
        ls -atlr /tango/data/silentroamer/fileload/ | grep "$newfeedfile"
        echo "------------------------------------------------------------------------------------------------------------------`tput setaf 2`"
        echo "`tput setaf 3`ls -atlr /tango/data/silentroamer/ready/ | grep $newfeedfile `tput sgr0`"
        ls -atlr /tango/data/silentroamer/ready/ | grep "$newfeedfile"
        getSIBBlogs
        showSIBBcdrs
        checkAMDB
else
        echo "Nothing done, Bye"
fi

fi