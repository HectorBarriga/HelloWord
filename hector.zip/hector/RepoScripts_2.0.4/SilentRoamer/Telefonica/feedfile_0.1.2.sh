#!/bin/bash
#############################################################################
# Filename:    feedfile.sh
#
# This sh script is to run End-To-End tests for Silent Roamer Telefonica
#
# Copyright (c) Tango Telecom 2017
# Author: Hector Barriga
#
# All rights reserved.
# This document contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or
# in part is expressly prohibited, except as may be specifically
# authorized by prior written agreement or permission of Tango Telecom.
##############################################################################
# version 0.1.0 - First version
# version 0.1.3 - Add multitenancy
version=0.1.2
#
##############################################################################

#---------------------------------------------------------------
# Configurations
#---------------------------------------------------------------
mysqlmasterhost="IPXMIATCDB1"
mysqluser="root"
mysqlpw="t3il3achum"

#subroutines

showfeedfile()
{
columnnames=$(echo "Start_Date_and_time,End_Date_and_time,DATA_RECORD_TYPE,VIOLATION,TIMEOUT,LABEL_OPC,LABEL_DPC,GTCALLING_NO,GTCALLED_NO,MS_ISDN,MSC,BACKCLG_NO,MS_RN,IMSI,SUBSCRIBER_OPERATOR_NAME,SUBSCRIBER_OPERATOR_COUNTRY,IMEI,TAC,SS_CODE,SERVICE_KEY,SUPPORT_CAMEL_PH,ER_CODE,TCAP_ABORT_CAUSE,SCCP_RETCAUSE,SERVCENT_ADDR,USRERR_REASON,NUMOF_SCCPMSG,SCCP_MSGLEN,TP_MTI,DCH,LINKSET_NAME,NUMOF_MO_SMSMSG,NUMOF_MT_SMSMSG,TP_OA_ALPHANUM,CAMEL_CAPABILITY_HANDLING,TP_OA,TP_DA,TRANS_TIME,OP_CODE,DIRECTION,DESTIN_OPERATOR_NAME,DESTIN_OPERATOR_COUNTRY,ORIG_OPERATOR_NAME,ORIG_OPERATOR_COUNTRY,VLR_NUMBER,SGSN_NUMBER,SGSN_ADDRESS,Call_Trace_Jump")
file=$(cat $1 | grep $msisdnorig)
ofile=$(cat $1 | grep $msisdnorig | paste -sd' ')
echo ""
echo "`tput setaf 5`CDR:"
echo "`tput setaf 3`$file"
echo "`tput sgr0`"
echo "`tput setaf 5`List of Fields:`tput sgr0`"
c=0
IFS=","
for i in $ofile
do
        if [ "$c" == "48" ];then
                c=0
                echo ""
        fi
        d=$((c+1))
        getColumnname=$(echo "$columnnames" | cut -d, -f"$d")
        if [ "$c" == "0" ] || [ "$c" == "1" ];then
                getEpochTime=$(echo "base=10; $i" | bc)
                getEpochTime=$(echo $((0x${i})))
                getNormalTime=$(date -d @$((getEpochTime/1000)))
                outputprintf=$(printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-1s \033[32m %-3s\n' $c. $getColumnname "=" $i "=> ")
                echo -en "$outputprintf $getNormalTime\033[1m"
                echo ""
        else
                printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-1s \033[0;39m\n' $c. $getColumnname "=" $i
        fi
        let ++c
done
echo ""
}

showSIcdrs()
{
if [ ! -d "/tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp" ];then
        mkdir /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp
fi
echo "------------------------------------------------------------------------------------------------------------------"
echo "`tput setaf 3`cp /tango/data/cdr/active_SI.cdr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SI_tangoC.cdr`tput sgr0`"
echo "`tput setaf 3`scp tangoD:/tango/data/cdr/active_SI.cdr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SI_tangoD.cdr`tput sgr0`"
cp /tango/data/cdr/active_SI.cdr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SI_tangoC.cdr
scp tangoD:/tango/data/cdr/active_SI.cdr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SI_tangoD.cdr
ls -altr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SI*
sessionIdSiCdrs=$(cat  /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SI* | grep "$msisdnin" | tail -1 | cut -d, -f6)
timeSiCdrs=$(cat  /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SI* | grep "$sessionIdSiCdrs" | tail -1 | cut -d, -f5)
echo "`tput setaf 3`cat  /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SI* | grep $msisdnin | egrep $sessionIdSiCdrs`tput sgr0`"
sicdrs=$(cat  /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SI* | grep $msisdnin | egrep "$sessionIdSiCdrs")
if [ -z "$sicdrs" ];then
        echo ""
        echo "`tput setaf 1`No SI CDRs!!!`tput setaf 5` It seems CDR didnt pass the filters as per trigger_generator.cfg.
Very likely \"`tput setaf 1`Current EPOCH time in Hex\"`tput setaf 5` is too old"
        echo "HOWEVER!!! check:
    1. offset time is not OK. It means Start_Date_and_time and End_Date_and_time are TOO old (See feedfile CDRs first 2 fields)
    2 SI SD is available for VPLMN=$fvisitplmn
    3. active_SI.cdr may have rolled over, check /tango/data/cdr/ussd_si/
    4. trigger_generator.cfg is not configured properly`tput sgr0`"
        echo ""
else
        echo "$sicdrs"
fi
}

showUNScdrs()
{
echo "------------------------------------------------------------------------------------------------------------------"
echo "`tput setaf 3`cp /tango/data/cdr/active_UNS_SMS.cdr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_UNS_SMS_tangoC.cdr`tput sgr0`"
echo "`tput setaf 3`scp tangoD:/tango/data/cdr/active_UNS_SMS.cdr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_UNS_SMS_tangoD.cdr`tput sgr0`"
cp /tango/data/cdr/active_UNS_SMS.cdr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_UNS_SMS_tangoC.cdr
scp tangoD:/tango/data/cdr/active_UNS_SMS.cdr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_UNS_SMS_tangoD.cdr
ls -altr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_UNS_SMS*
echo "`tput setaf 3`cat /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_UNS_SMS* | grep $msisdnorig | egrep \"$timeSiCdrs\"`tput sgr0`"
IsThereunsCDRs=$(cat /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_UNS_SMS* | grep "$msisdnorig" | egrep "$timeSiCdrs" | tail -2)
unsCDRs=$(cat /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_UNS_SMS* | grep "$msisdnorig" | egrep "$timeSiCdrs" | tail -2)
if [ -z "$IsThereunsCDRs" ];then
        echo ""
        echo -e "`tput setaf 1`No CDRs!!!`tput setaf 5` It seems NO SMS was sent to subscriber. Either:\n   1. Subscriber must have received it already\n   2. There is not Campaign configured in PMUI for VPLMN=$fvisitplmn \n   3. active_UNS_SMS.cdr file rolled over\n   4. UNS is not running or something`tput sgr0`"
        echo ""
else
        echo "$unsCDRs"
fi
}

showSOMcdrs()
{
echo "------------------------------------------------------------------------------------------------------------------"
echo "`tput setaf 3`cp /tango/data/cdr/active_SOM.cdr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SOM_tangoC.cdr`tput sgr0`"
echo "`tput setaf 3`scp tangoD:/tango/data/cdr/active_SOM.cdr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SOM_tangoD.cdr`tput sgr0`"
cp /tango/data/cdr/active_SOM.cdr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SOM_tangoC.cdr
scp tangoD:/tango/data/cdr/active_SOM.cdr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SOM_tangoD.cdr
ls -altr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SOM*
echo "`tput setaf 3`cat /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SOM* | grep $msisdnorig | egrep \"$sessionIdSiCdrs\"`tput sgr0`"
somcdrs=$(cat /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SOM* | grep "$msisdnorig" | egrep "$sessionIdSiCdrs")
IsTheresomcdrs=$(cat /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/temp/active_SOM* | grep "$msisdnorig" | egrep "$sessionIdSiCdrs" | cut -d, -f1)
if [ -z $IsTheresomcdrs ];then
        echo ""
        echo "`tput setaf 1`No CDRs!!!`tput setaf 5` It seems cdr file rolled over or CDRH (SOM) process is not running or something`tput sgr0`"
        echo ""
else
        echo "$somcdrs"
fi
}


checkOfferPromotionDB()
{
namehost=$(hostname)
if [ "$mysqlmasterhost" == "$namehost" ];then
        whichmysql=$(which mysql)
        isPWinMyCnf=$(cat /etc/my.cnf | grep $mysqlpw | egrep -v grep)
        if [ ! -z "$isPWinMyCnf" ];then
                gomysql=$(echo "$whichmysql -u$mysqluser")
        else
                gomysql=$(echo "$whichmysql -u$mysqluser -p$mysqlpw")
        fi
        echo "------------------------------------------------------------------------------------------------------------------"
        echo "`tput setaf 3`echo \"select * from Offer where msisdn = '$msisdnorig'\G;\" | $gomysql promotion_$tenant`tput sgr0`"
        Offer=$(echo "select * from Offer where msisdn = '$msisdnorig'\G;" | $gomysql promotion_$tenant)
else
        whichmysql=$(ssh tango@$mysqlmasterhost 'which mysql')
        echo "`tput setaf 3`ssh tango@$mysqlmasterhost '$whichmysql -u$mysqluser -p$mysqlpw promotion_$tenant -e \"select * from Offer where msisdn = '$msisdnorig'\G;\"'`tput sgr0`"
        Offer=$(ssh tango@$mysqlmasterhost "$whichmysql -u '$mysqluser' -p'$mysqlpw' promotion_$tenant -e 'select * from Offer where msisdn = '$msisdnorig'\G;'" 2>/dev/null)
fi
echo "$Offer"
echo "------------------------------------------------------------------------------------------------------------------"
if [ ! -z "$Offer" ];then

        echo "`tput setaf 5`SR_SILENT_ROAMER_SEND_SMPP has already been triggered. You need to wait until \"validityExpiryDate\" (see above) which is configured in Campaigns via PMUI"
        echo -n "`tput setaf 3`Do you want to remove $msisdnorig from promotion_$tenant Database from Offer table? ( No recommended )[y/n] [Default n] >  `tput sgr0`"
        read answer
        if [ "$answer" == "y" ];then
                echo "`tput setaf 2`delete from Offer where msisdn = '$msisdnorig'; | mysql -u root -proot promotion_$tenant"
                echo "delete from Offer where msisdn = '$msisdnorig';" | mysql -u root -proot promotion_$tenant
                echo "/tango/bin/mps | grep 64321 | awk -v i=4 '{print \$4}' | xargs kill -9"
                /tango/bin/mps | grep 64321 | awk -v i=4 '{print $i}' | xargs kill -9
                echo "/tango/bin/mps | grep 19225 | awk -v i=4 '{print \$4}' | xargs kill -9"
                /tango/bin/mps | grep 19225 | awk -v i=4 '{print $i}' | xargs kill -9
                echo "`tput setaf 3`SOM and CMC Processes will take time to restart. Please wait .... `tput sgr0`"
                echo "CTR+C to finish"
                echo -n "Killing processes * "
                i=0
                while [ $i -lt 40 ] && [ -z "$isidle" ]
                do
                        printf '* '
                        sleep 2
                        i=$[$i+1]
                        isidle=$(/tango/bin/mps | awk '/64321/ || /19225/' | grep -i idle)
                done
                echo -n "Process are in Idle, keep waiting * "
                i=0
                while [ $i -lt 40 ] && [ ! -z "$isidle" ]
                do
                        printf '* '
                        sleep 2
                        i=$[$i+1]
                        isidle=$(/tango/bin/mps | awk '/64321/ || /19225/' | grep -i idle)
                done
                echo -n " [`tput setaf 2`Finished`tput sgr0`]"
                echo ""
                echo ""
                echo ""
                echo "`tput setaf 5`TRIGGERING SI AGAING TO REFRESH CACHE SO NEXT TEST WILL WORK`tput sgr0`"
                cd /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer
                mv $feedfile $anothernewfeedfile
                cp $anothernewfeedfile /tango/data/silentroamer/fileload/
                echo "`tput setaf 3`mv $feedfile $anothernewfeedfile"
                echo "$anothernewfeedfile /tango/data/silentroamer/fileload/`tput sgr0`"
                echo "------------------------------------------------------------------------------------------------------------------"
                echo "`tput setaf 3`RUNNING ....:  `tput sgr0`cd /tango/bin; ./trigger_generator.pl -c /tango/config/trigger_generator.cfg"
                cd /tango/bin
                ./trigger_generator.pl -c /tango/config/trigger_generator.cfg
                echo "------------------------------------------------------------------------------------------------------------------"
                echo "`tput setaf 3`ls -atlr /tango/data/silentroamer/fileload/ | grep $newfeedfile `tput sgr0`"
                ls -atlr /tango/data/silentroamer/fileload/ | grep "$newfeedfile"
                showSIcdrs
                showUNScdrs
                showSOMcdrs
                checkOfferPromotionDB

        else
                echo "Bye.."
                echo ""
                echo ""
        fi
else
        echo "`tput setaf 1`No Records in Offer.promotion_$tenant table. Check the following:"
        echo "`tput setaf 5` 1) Postpaid Subscriber doesnt have a core plan. Go to PMI and check subscriber exists in \"Subscriber MGT\". If not, run alias createsubscriberPCC and create it and give it a plan
        - SR_SILENT_ROAMER_GET_PLANS will be 402 if subscriber doesnt exist in PMI
        - SR_SILENT_ROAMER_GET_PLANS will be 200 and SR_SILENT_CMGR_REQUEST will be 3002 if not core plan has been assigned`tput sgr0`"
        echo "`tput setaf 5` 2) Qualifying Criteria `tput sgr0`VPLMN EQUALS $fvisitplmn`tput setaf 5` doesnt exist in PM-UI > Campaigns. Run this command: `tput sgr0`echo \"select * from FieldCondition where value='$fvisitplmn';\" | mysql -u root -proot promotion_$tenant"
        echo "`tput setaf 5` 3) Input File CDRs didnt pass the filters so SI was not hit`tput sgr0`"
        echo "`tput setaf 5` 4) Prepaid Subscriber already has an addon`tput sgr0`"
        echo "`tput setaf 5` 5) A previous record is still in cache although there is not record in promotion_$tenant.Offer table. `tput setaf 2` Try again in 2 mins. `tput sgr0`Bye...
"
fi
}

# main ()
echo "------------------------------------------------------------------------------------------------------------------"
echo "`tput setaf 2`                               Welcome to \"feedfile.sh\" simulator for Telefonica
                                                version: $version             `tput sgr0`"
echo "------------------------------------------------------------------------------------------------------------------"
cd /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer
echo "`tput setaf 3`Going to /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/`tput sgr0`"
echo "------------------------------------------------------------------------------------------------------------------"
ls -alrt | egrep -v feedfile
echo "------------------------------------------------------------------------------------------------------------------"
defaultfeedfile=$(ls -altr /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/ | egrep -v feedfile | egrep -v total | egrep -v "drwxr" | tail -1 | awk "{print \$9}")
echo -n "`tput setaf 3`Enter feed file [Default = $defaultfeedfile] > `tput sgr0`"
read feedfile
if [ -z $feedfile ];then
        feedfile=$defaultfeedfile
fi
if [ ! -f ./$feedfile ];then
        echo ""
        echo "`tput setaf 1`File doesnt exist!!!`tput sgr0` Nothing done, Bye"
        echo ""
else
echo "------------------------------------------------------------------------------------------------------------------"
echo -n "`tput setaf 3`Do you wanna edit the file? [y/n] (Default n) > `tput sgr0`"
read confirm
if [ -z "$confirm" ]; then
        sleep 0
else
        if [ "$confirm" == "y" ];then
                vi $feedfile
        fi
fi
echo "------------------------------------------------------------------------------------------------------------------"
echo "`tput setaf 3`List of Silent Roamers:`tput sgr0`"
cat $feedfile | while read in
do
        getmsisdn=$(echo $in | cut -d"," -f10)
        getopcode=$(echo $in | cut -d"," -f38)
        if [ -z $getmsisdn ] || [ "$getmsisdn" == "_" ]; then
                part1=$(echo "MSISDN= <empty>\t\t""OPCODE=$getopcode")
        else
                part1=$(echo "MSISDN= $getmsisdn\t""OPCODE=$getopcode")
        fi
        visitcountry=$(echo $in | cut -d"," -f15)
        srcountry=$(cat /tango/config/bulk_import/tadigMappings.cfg | grep "$visitcountry" | tail -1 | rev | cut -d',' -f1 | rev)
        color=2
        if [ -z "$getmsisdn" ] || [ "$getmsisdn" == "_" ] || [ "$getopcode" != "2" ];then
                color=1
                srcountry='[NO GOOD CDR, SI wont be triggered]'

        fi
        if [ -z "$srcountry" ];then
                color=1
                srcountry='[NO GOOD CDR, VISITOR COUNTRY OPERATOR is not in /tango/config/bulk_import/tadigMappings.cfg. SI might be triggered but CMCG wont find an OFFER]'
        fi
        echo -e "$part1""\tUBSCRIBER_OPERATOR_NAME=$visitcountry""\tVPLMN=`tput setaf $color`$srcountry`tput sgr0`"
done

echo "------------------------------------------------------------------------------------------------------------------"
lastmsisdnin=$(cat $feedfile | head -1 | cut -d"," -f10)
echo -n "`tput setaf 3`Enter msisdn you would like to monitor [Default = First on the list $lastmsisdnin]  = > `tput sgr0`"
read selectedmsisdn
if [ -z "$selectedmsisdn" ];then
        msisdnin=$(cat $feedfile | grep $lastmsisdnin | cut -d"," -f10 | sed 's/./&0/g' | cut -d= -f2 | sed 's/0 020403/20403/' | sed 's/.$//' | head -1)
        msisdnorig=$lastmsisdnin
        fvisitcountry=$(cat $feedfile | grep $lastmsisdnin | cut -d"," -f15)
        fvisitplmn=$(cat /tango/config/bulk_import/tadigMappings.cfg | grep "$fvisitcountry" | tail -1 | rev | cut -d',' -f1 | rev)
else
        msisdnin=$(cat $feedfile | grep $selectedmsisdn | cut -d"," -f10 | sed 's/./&0/g' | cut -d= -f2 | sed 's/0 020403/20403/' | sed 's/.$//' | head -1)
        msisdnorig=$selectedmsisdn
        fvisitcountry=$(cat $feedfile | grep $selectedmsisdn | cut -d"," -f15)
        fvisitplmn=$(cat /tango/config/bulk_import/tadigMappings.cfg | grep "$fvisitcountry" | tail -1 | rev | cut -d',' -f1 | rev)
fi
tenant=$(echo "$fvisitplmn" | tr '[:upper:]' '[:lower:]')
echo ""
echo "`tput setaf 5`############################### NOTE: ####################################
# You selected `tput sgr0`$msisdnorig`tput setaf 5` to be monitored.
# You will see results only for that subscriber in particular (below).   #
# However, all GOOD CDRs from input feedfile will ALSO be processed      #
##########################################################################
`tput sgr0`"

date1=$(echo "$feedfile" | cut -d"-" -f5)
sec1=$(echo "$date1" | rev | cut -c1-2 | rev)
date2=$(echo "$feedfile" | cut -d"-" -f6)
sec2=$(echo "$date2" | rev | cut -c1-2 | rev)

if [[ $sec1 -eq 59 ]];then
        newdate1=$(($date1 + 41))
else
        newdate1=$(($date1 + 1))
fi
if [[ $sec2 -eq 59 ]];then
        newdate2=$(($date2 + 41))
else
        newdate2=$(($date2 + 1))
fi
anothernewdate=$(($date + 2))
prefixnewfile=$(echo "$feedfile" | rev | cut -c30- | rev)
newfeedfile=$(echo "$prefixnewfile""$newdate1""-""$newdate2")
echo "------------------------------------------------------------------------------------------------------------------"
mv $feedfile $newfeedfile
feedfile=$(echo "$newfeedfile")
echo "`tput setaf 3`Feed file is now: `tput sgr0`$feedfile"
echo ""
showfeedfile "$feedfile"
echo "------------------------------------------------------------------------------------------------------------------"
currentEpoch=$(date +"%s")
currentEpochmillisec=$((currentEpoch*1000))
hexCuerrentEpoch=$(echo "obase=16; $currentEpochmillisec" | bc)
echo "`tput setaf 2`FYI : Current EPOCH time in Hex = `tput sgr0` $hexCuerrentEpoch"
echo "------------------------------------------------------------------------------------------------------------------"
echo -n "`tput setaf 3`Do you wanna re-edit it? [y/n] (Default n) > `tput sgr0`"
read confirm
if [ -z "$confirm" ]; then
        sleep 0
else
        if [ "$confirm" == "y" ];then
                vi $feedfile
                showfeedfile "$feedfile"
                echo "------------------------------------------------------------------------------------------------------------------"
        fi
fi

echo -n "`tput setaf 3`Do you wanna drop it in /tango/data/silentroamer/fileload/ and trigger SI vi sm-api? [y/n] > `tput sgr0`"
read confirm
if [ "$confirm" == "y" ] || [ -z "$confirm" ];then
        echo "------------------------------------------------------------------------------------------------------------------"
        echo "`tput setaf 2`curl -i -X GET -H \"tenant: $tenant\" -H \"Content-Type: application/json\" -H \"Accept: application/json\"  http://IPXMIATCSPCM1:8091/spcm-rest-ws/pcc/spcm/subscribers/$msisdnorig/plans`tput sgr0`"
        curl -i -X GET -H "tenant: $tenant" -H "Content-Type: application/json" -H "Accept: application/json"  http://IPXMIATCSPCM1:8091/spcm-rest-ws/pcc/spcm/subscribers/$msisdnorig/plans
        getSubPlans=$(curl -i -X GET -H "tenant: $tenant" -H "Content-Type: application/json" -H "Accept: application/json" http://IPXMIATCSPCM1:8091/spcm-rest-ws/pcc/spcm/subscribers/$msisdnorig/plans 2>/dev/null)
        doesSubExist=$(echo "$getSubPlans" | grep "200 OK" | egrep -v grep)
        if [ ! -z "$doesSubExist" ];then
                echo -en "`tput setaf 3`\nDo you want to delete subscriber from SPCM manually (Via curl)? Note: If delete, Offer should be sent! [y/n] > `tput sgr0`"
                read rmSubSPCM
                if [ "$rmSubSPCM" == "y" ];then
                        echo "`tput setaf 2`curl -i -X DELETE -H \"Content-Type: application/json\" -H \"Accept: application/json\" -H \"tenant: $tenant\" \"http://IPXMIATCSPCM1:8091/spcm-rest-ws/pcc/spcm/subscribers/$msisdnorig\"`tput sgr0`"
                        curl -i -X DELETE -H "Content-Type: application/json" -H "Accept: application/json" -H "tenant: $tenant" "http://IPXMIATCSPCM1:8091/spcm-rest-ws/pcc/spcm/subscribers/$msisdnorig"
                        echo -e "\n------------------------------------------------------------------------------------------------------------------"
                        echo "`tput setaf 2`curl -i -X GET -H \"tenant: $tenant\" -H \"Content-Type: application/json\" -H \"Accept: application/json\"  http://IPXMIATCSPCM1:8091/spcm-rest-ws/pcc/spcm/subscribers/$msisdnorig/plans`tput sgr0`"
                        curl -i -X GET -H "tenant: $tenant" -H "Content-Type: application/json" -H "Accept: application/json"  http://IPXMIATCSPCM1:8091/spcm-rest-ws/pcc/spcm/subscribers/$msisdnorig/plans
                fi
        else
                echo -en "`tput setaf 3`\nDo you want to ADD subscriber to SPCM manually (Via curl)? Note: if added, offer will be sent if subscriber doesnt have add-ons [y/n] > `tput sgr0`"
                read addSubSPCM
                if [ "$addSubSPCM" == "y" ];then
                        echo "curl -i -X POST -H \"tenant: $tenant\" -H \"Content-Type: application/json\" -H \"Accept: application/json\" \"http://66.119.82.200:8091/spcm-rest-ws/pcc/spcm/subscribers/\" -d '{\"msisdn\":\"$msisdnorig\",\"imsi\":\"740000119139692\",\"alternateNotificationMsisdn\":\"\",\"paymentType\":\"postpaid\",\"class\":\"Standard\",\"locale\":\"en\",\"status\":\"active\",\"dpsEnabled\":true,\"dpsNotification\":false,\"eosNotification\":true,\"paygNotification\":true,\"imei\":\"294032949812345\",\"qosCategoryName\":\"NULL\",\"renewalDayOfMonth\":0}'"
                        curl -i -X POST -H "tenant: $tenant" -H "Content-Type: application/json" -H "Accept: application/json" "http://66.119.82.200:8091/spcm-rest-ws/pcc/spcm/subscribers/" -d '{"msisdn":"'$msisdnorig'","imsi":"740000119139692","alternateNotificationMsisdn":"","paymentType":"postpaid","class":"Standard","locale":"en","status":"active","dpsEnabled":true,"dpsNotification":false,"eosNotification":true,"paygNotification":true,"imei":"294032949812345","qosCategoryName":"NULL","renewalDayOfMonth":0}'
                        echo -e "\n------------------------------------------------------------------------------------------------------------------"
                        echo "`tput setaf 2`curl -i -X GET -H \"tenant: $tenant\" -H \"Content-Type: application/json\" -H \"Accept: application/json\"  http://IPXMIATCSPCM1:8091/spcm-rest-ws/pcc/spcm/subscribers/$msisdnorig/plans`tput sgr0`"
                        curl -i -X GET -H "tenant: $tenant" -H "Content-Type: application/json" -H "Accept: application/json"  http://IPXMIATCSPCM1:8091/spcm-rest-ws/pcc/spcm/subscribers/$msisdnorig/plans
                fi
        fi

        echo -e "\n------------------------------------------------------------------------------------------------------------------"
        cp $feedfile /tango/data/silentroamer/fileload/
        echo -en "\n`tput setaf 3`Wait until trigger generator triggers /tango/scripts/bulk_import/scripts_manager.sh which will process the new Input Files * "
        finishedprocessed="false"
        while [ $finishedprocessed == "false" ]
        do
        if [ ! -f /tango/data/silentroamer/fileload/$feedfile.processed ];then
                sleep 2
                echo -n "* "
        else
                echo -n " Done`tput sgr0`"
                finishedprocessed="true"
        fi
        done
        echo ""
        echo "------------------------------------------------------------------------------------------------------------------`tput setaf 2`"
        getsmapi=$(cat /tango/logs/bulk_import/trigger_generator.log | grep $msisdnorig | egrep sm-api | egrep smEndpoint | tail -1 | cut -d"]" -f4)
        isAIverbose=$(cat /tango/config/bulk_import/trigger_generator.xml | grep DEBUG | grep loglevel | egrep -v grep)
        if [ ! -z "$isAIverbose" ];then
                if [ ! -z "$getsmapi" ];then
                        echo -n "SIWS REQUEST: "
                        cat /tango/logs/bulk_import/trigger_generator.log | grep -A1 $msisdnorig | egrep -A1 sm-api | egrep -A1 smEndpoint | head -1 | tail -2 | while read in;do echo $in | cut -d"]" -f4;done
                        echo -n "SIWS RESPONSE:"
                        cat /tango/logs/bulk_import/trigger_generator.log | grep -A1 $msisdnorig | egrep -A1 sm-api | egrep -A1 smEndpoint | tail -1 | while read in;do echo $in | cut -d"-" -f2;done
                else
                        echo "`tput setaf 1` ERROR: SI was not triggered by trigger generator via SIWS"
                fi
        else
                echo "`tput setaf 5`Note: AI is not in verbose. Hence, I cannot get SIWS request and response"
                echo "Just set DEBUG parameter \"loglevel\" in /tango/config/bulk_import/trigger_generator.xml and restart (just kill it, crontab will restart it) trigger_generator"
                echo "ps -ef | grep trigger_generator"
        fi
        echo -n "`tput sgr0`"
        echo "------------------------------------------------------------------------------------------------------------------"
        echo "`tput setaf 3`ls -atlr /tango/data/silentroamer/fileload/ | grep $newfeedfile `tput sgr0`"
        ls -atlr /tango/data/silentroamer/fileload/ | grep "$newfeedfile"
        showSIcdrs
        showUNScdrs
        showSOMcdrs
        checkOfferPromotionDB
else
        echo "Nothing done, Bye"
fi

fi