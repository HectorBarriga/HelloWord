#!/bin/bash
#
export MYSQL_PWD=root

#subroutines

showfeedfile()
{
file=$(cat $1 | grep $msisdnorig)
ofile=$(cat $1 | grep $msisdnorig | paste -sd' ')
echo ""
echo "`tput setaf 5`CDR:"
echo "`tput setaf 3`$file"
echo "`tput sgr0`"
echo "`tput setaf 5`List of Fields:`tput sgr0`"
c=0
IFS=";"
for i in $ofile
do
        if [ "$c" == "24" ];then
                c=0
                echo ""
        fi
        echo "$c. $i"
        let ++c
done
echo ""
}

showSIcdrs()
{
echo "------------------------------------------------------------------------------------------------------------------"
sessionIdSiCdrs=$(cat  /tango/data/cdr/active_ussd_si.cdr | grep "$msisdnin" | tail -1 | cut -d, -f6)
/tango/logs/COSTAFF/hector/sh_scripts/SI_tool/SI_tool.pl -p $sessionIdSiCdrs
timeSiCdrs=$(cat  cat  /tango/data/cdr/active_ussd_si.cdr | grep "$sessionIdSiCdrs" | tail -1 | cut -d, -f5)
echo "`tput setaf 3`cat  /tango/data/cdr/active_ussd_si.cdr | grep $msisdnin | egrep $sessionIdSiCdrs`tput sgr0`"
sicdrs=$(cat  /tango/data/cdr/active_ussd_si.cdr | grep $msisdnin | egrep "$sessionIdSiCdrs")
if [ -z "$sicdrs" ];then
        echo ""
        echo "`tput setaf 1`No SI CDRs!!!`tput setaf 5` It seems CDR didnt pass the filters as per trigger_generator.cfg.
Very likely \"`tput setaf 1`Current EPOCH time in Hex\"`tput setaf 5` is too old"
        echo "HOWEVER!!! check:
    1. offset time is not OK. It means Start_Date_and_time and End_Date_and_time are TOO old (See feedfile CDRs first 2 fields)
    2 SI SD is available for VPLMN=$fvisitplmn
    3. active_SI.cdr may have rolled over, check /tango/data/cdr/ussd_si/
    4. trigger_generator.cfg is not configured properly`tput sgr0`"
        echo ""
else
        echo "$sicdrs"
fi
}

showUNScdrs()
{
echo "------------------------------------------------------------------------------------------------------------------"
echo "`tput setaf 3`cat /tango/data/cdr/active_uns.cdr | grep $msisdnorig | egrep \"$timeSiCdrs\"`tput sgr0`"
#IsThereunsCDRs=$(cat /tango/data/cdr/active_uns.cdr | grep "$msisdnorig" | egrep "$timeSiCdrs" | tail -2)
#unsCDRs=$(cat /tango/data/cdr/active_uns.cdr | grep "$msisdnorig" | egrep "$timeSiCdrs" | tail -2)
IsThereunsCDRs=$(cat /tango/data/cdr/active_uns.cdr | grep "$msisdnorig" | tail -2)
unsCDRs=$(cat /tango/data/cdr/active_uns.cdr | grep "$msisdnorig" | tail -2)
if [ -z "$IsThereunsCDRs" ];then
        echo ""
        echo -e "`tput setaf 1`No CDRs!!!`tput setaf 5` It seems NO SMS was sent to subscriber. Either:\n   1. Subscriber must have received it already\n   2. There is not Campaign configured in PMUI for VPLMN=$fvisitplmn \n   3. active_UNS_SMS.cdr file rolled over\n   4. UNS is not running or something`tput sgr0`"
        echo ""
else
        echo "$unsCDRs"
fi
}

showSOMcdrs()
{
echo "---------------------------------------------------------"
echo "`tput setaf 3`ls -altr /tango/data/cdr/active_som.cdr`tput sgr0`"
ls -altr /tango/data/cdr/active_som.cdr
echo "`tput setaf 3`cat /tango/data/cdr/active_som.cdr | grep $msisdnorig`tput sgr0`"
somcdrs=$(cat /tango/data/cdr/active_som.cdr | grep "$msisdnorig")
if [ -z $somcdrs ];then
        echo ""
        echo "`tput setaf 1`No CDRs!!!`tput setaf 5` It seems cdr file rolled over or CDRH (SOM) process is not running on tomcat or something`tput sgr0`"
        echo ""
else
        echo "$somcdrs"
fi
}


checkOfferPromotionDB()
{
echo "---------------------------------------------------------"
echo "`tput setaf 3`export MYSQL_PWD=root;echo \"select * from Offer where msisdn = '$msisdnorig';\" | mysql -u root promotion`tput sgr0`"
Offer=$(echo "select * from Offer where msisdn = '$msisdnorig'\G;" | mysql -u root promotion)
echo "$Offer"
echo "---------------------------------------------------------"
if [ ! -z "$Offer" ];then

        echo "`tput setaf 5`SR_SILENT_ROAMER_SEND_SMPP has already been triggered. You need to wait 5 days."
        echo -n "`tput setaf 3`Do you want to remove $msisdnorig from promotion Database from Offer table? [y] [Default n] >  `tput sgr0`"
        read answer
        if [ "$answer" == "y" ];then
                echo "`tput setaf 2`export MYSQL_PWD=root;echo \"delete from Offer where msisdn = '$msisdnorig';\" | mysql -u root promotion"
                echo "delete from Offer where msisdn = '$msisdnorig';" | mysql -u root promotion
                echo "/tango/bin/mps | grep 64321 | awk -v i=4 '{print \$4}' | xargs kill -9"
                /tango/bin/mps | grep 64321 | awk -v i=4 '{print $i}' | xargs kill -9
                echo "/tango/bin/mps | grep 19225 | awk -v i=4 '{print \$4}' | xargs kill -9"
                /tango/bin/mps | grep 19225 | awk -v i=4 '{print $i}' | xargs kill -9
                echo "`tput setaf 3`SOM and CMC Processes will take time to restart. Please wait .... `tput sgr0`"
                echo "CTR+C to finish"
                echo -n "Killing processes * "
                i=0
                while [ $i -lt 40 ] && [ -z "$isidle" ]
                do
                        printf '* '
                        sleep 2
                        i=$[$i+1]
                        isidle=$(/tango/bin/mps | awk '/64321/ || /19225/' | grep -i idle)
                done
                echo -n "Process are in Idle, keep waiting * "
                i=0
                while [ $i -lt 40 ] && [ ! -z "$isidle" ]
                do
                        printf '* '
                        sleep 2
                        i=$[$i+1]
                        isidle=$(/tango/bin/mps | awk '/64321/ || /19225/' | grep -i idle)
                done
                echo -n " [`tput setaf 2`Finished`tput sgr0`]"
                echo ""
                echo ""
                echo ""
                echo "`tput setaf 5`TRIGGERING SI AGAING TO REFRESH CACHE SO NEXT TEST WILL WORK`tput sgr0`"
                cd /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/
                mv $feedfile $anothernewfeedfile
                cp $anothernewfeedfile /tango/data/silentroamer/fileload/
                echo "`tput setaf 3`mv $feedfile $anothernewfeedfile"
                echo "$anothernewfeedfile /tango/data/silentroamer/fileload/`tput sgr0`"
                echo "---------------------------------------------------------"
                echo "`tput setaf 3`RUNNING ....:  `tput sgr0`cd /tango/bin; ./trigger_generator.pl -c /tango/config/trigger_generator.cfg"
                cd /tango/bin
                ./trigger_generator.pl -c /tango/config/trigger_generator.cfg
                echo "---------------------------------------------------------"
                echo "`tput setaf 3`ls -atlr /tango/data/silentroamer/fileload/ | grep $newfeedfile `tput sgr0`"
                ls -atlr /tango/data/silentroamer/fileload/ | grep "$newfeedfile"
                showIScdrs
                showSSRVSMPPcdrs
                showSOMcdrs
                checkOfferPromotionDB

        else
                echo "Bye.."
                echo ""
                echo ""
        fi
else
        echo "`tput setaf 1`No Records in Offer.promotion table. Check the following:"
        echo "`tput setaf 5` 1) Postpaid Subscriber doesnt have a core plan. Go to PMI and check subscriber exists in \"Subscriber MGT\". If not, run alias createsubscriberPCC and create it and give it a plan
        - SR_SILENT_ROAMER_GET_PLANS will be 402 if subscriber doesnt exist in PMI
        - SR_SILENT_ROAMER_GET_PLANS will be 200 and SR_SILENT_CMGR_REQUEST will be 3002 if not core plan has been assigned`tput sgr0`"
        echo "`tput setaf 5` 2) Qualifying Criteria `tput sgr0`VPLMN EQUALS $fvisitplmn`tput setaf 5` doesnt exist in PM-UI > Campaigns. Run this command: `tput sgr0`export MYSQL_PWD=root;echo \"select * from FieldCondition where value='$fvisitplmn';\" | mysql -u root promotion"
        echo "`tput setaf 5` 3) Input File CDRs didnt pass the filters so SI was not hit`tput sgr0`"
        echo "`tput setaf 5` 4) Prepaid Subscriber already has an addon`tput sgr0`"
        echo "`tput setaf 5` 5) A previous record is still in cache although there is not record in promotion.Offer table. `tput setaf 2` Try again in 2 mins. `tput sgr0`Bye...
"
fi
}

# main ()
echo "---------------------------------------------------------"
cd /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/
echo "`tput setaf 3`Going to /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/`tput sgr0`"
echo "---------------------------------------------------------"
ls -alrt | grep MNG_MOBCOM
echo "---------------------------------------------------------"
defaultfeedfile=$(ls -altr | grep MNG_MOBCOM | tail -1 | awk "{print \$9}")
echo -n "`tput setaf 3`Enter feed file [Default = $defaultfeedfile] > `tput sgr0`"
read feedfile
if [ -z $feedfile ];then
        feedfile=$defaultfeedfile
fi
if [ ! -f ./$feedfile ] || [ -z $feedfile ];then
        echo ""
        echo "`tput setaf 1`File doesnt exist!!!`tput sgr0` Nothing done, Bye"
        echo ""
else
echo "---------------------------------------------------------"
echo "`tput setaf 3`List of Silent Roamers:`tput sgr0`"
cat $feedfile | while read in
do
        getmsisdn=$(echo $in | cut -d";" -f5 | cut -d"=" -f2)
        getopcode=$(echo $in | cut -d";" -f2 | cut -d"=" -f2)
        if [ -z $getmsisdn ]; then
                part1=$(echo "MSISDN= <empty>          ""OPCODE=$getopcode")
        else
                part1=$(echo $in | awk -v i=5 'BEGIN{FS=";"}{print $i,"   \t",$(i-3)}')
        fi
        visitplmn=$(echo $in | cut -d";" -f23 | cut -d"=" -f2)
        srcountry=$(echo "select name from Campaign where id in (select campaign_id from CampaignSpecificationCondition  where id in (select id from FieldCondition where value='$visitplmn'));" | mysql -u root promotion | egrep -v name | sed 's/ silent roamer//g')
        campaign=$(echo "select name from Campaign where id in (select campaign_id from CampaignSpecificationCondition  where id in (select id from FieldCondition where value='$visitplmn'));" | mysql -u root promotion | egrep -v name)
        color=2
        if [ -z "$getmsisdn" ] || [ "$getopcode" != "2" ];then
                color=1
                srcountry='[NO GOOD TDR, OpCode is not 2. SI wont be triggered]'

        fi
        if [ -z "$srcountry" ];then
                color=1
                srcountry='[NO GOOD TDR, VPLMN is not in DB or There is not Campaign with that VPLMN. SI might be triggered but CMCG wont find an OFFER]'
        fi
        echo -e "$part1""\tVPLMN=$visitplmn""\tCOUNTRY=`tput setaf 6`$srcountry`tput sgr0`\t`tput sgr0`CAMPAING=$campaign`tput sgr0`\t`tput sgr0`\tTDR=`tput setaf 2`GOOD`tput sgr0`"
done

echo "---------------------------------------------------------"
lastmsisdnin=$(cat $feedfile | egrep -v 'MSISDN=;' | head -1 | cut -d";" -f5 | cut -d= -f2)
echo -n "`tput setaf 3`Enter msisdn you would like to monitor [Default = First on the list $lastmsisdnin]  = > `tput sgr0`"
read selectedmsisdn
if [ -z $selectedmsisdn ];then
        msisdnin=$(cat $feedfile | grep $lastmsisdnin | cut -d";" -f5 | cut -d= -f2 | sed 's/./&0/g' | cut -d= -f2 | sed 's/0 020403/20403/' | sed 's/.$//' | head -1)
        msisdnorig=$lastmsisdnin
        fvisitplmn=$(cat $feedfile | grep $lastmsisdnin | cut -d";" -f23 | cut -d"=" -f2 | head -1)
else
        msisdnin=$(cat $feedfile | grep $selectedmsisdn | cut -d";" -f5 | cut -d= -f2 | sed 's/./&0/g' | cut -d= -f2 | sed 's/0 020403/20403/' | sed 's/.$//' | head -1)
        msisdnorig=$selectedmsisdn
        fvisitplmn=$(cat $feedfile | grep $selectedmsisdn | cut -d";" -f23 | cut -d"=" -f2 | head -1)
fi
echo ""
echo "`tput setaf 5`######################### NOTE: #################################
# You selected `tput sgr0`$msisdnorig`tput setaf 5` to be monitored.
# You will see results for that subscriber in particular below.     #
# However, all GOOD CDRs from input feedfile will ALSO be processed #
#####################################################################
`tput sgr0`"

date=$(echo "$feedfile" | cut -d_ -f3 | cut -d. -f1)
if [ ${date: -2} -eq 59 ];then
        getNowDate=$(perl -e '@d=localtime time(); printf "%4d%02d%02d%02d%02d00\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1]')
        echo -n "`tput setaf 1`File date DAY is now 60. `tput setaf 3`Enter a new date [Default: $getNowDate ] > `tput sgr0`"
        read newdate
        if [ -z "$newdate" ];then
                newdate=$getNowDate
        fi
        anothernewdate=$(($newdate + 1))
else
        newdate=$(($date + 1))
        anothernewdate=$(($date + 2))
fi
prefixnewfile=$(echo "$feedfile" | cut -d_ -f1,2)
extnewfile=$(echo "$feedfile" | cut -d"." -f2)
newfeedfile=$(echo "$prefixnewfile""_""$newdate"".$extnewfile")
anothernewfeedfile=$(echo "$prefixnewfile""_""$anothernewdate"".$extnewfile")
echo "---------------------------------------------------------"
mv $feedfile $newfeedfile
feedfile=$(echo "$newfeedfile")
echo "`tput setaf 3`Feed file is now: `tput sgr0`$feedfile"
echo ""
showfeedfile "$feedfile"
echo "---------------------------------------------------------"
echo -n "`tput setaf 3`Do you wanna re-edit it? [y/n] > `tput sgr0`"
read confirm
if [ -z "$confirm" ]; then
        sleep 0
else
        if [ "$confirm" == "y" ];then
                vi $feedfile
                showfeedfile "$feedfile"
                echo "---------------------------------------------------------"
        fi
fi
echo "`tput setaf 2`
                             ╦═╗╔═╗╔═╗╔╦╗╦ ╦  ╔╦╗╔═╗  ╔╦╗╔═╗╔═╗╔╦╗
───────────────────────────  ╠╦╝║╣ ╠═╣ ║║╚╦╝   ║ ║ ║   ║ ║╣ ╚═╗ ║   ───────────────────────────
                             ╩╚═╚═╝╩ ╩═╩╝ ╩    ╩ ╚═╝   ╩ ╚═╝╚═╝ ╩                           "

echo -n "`tput setaf 3`Do you wanna drop it in /tango/data/silentroamer/fileload/ and trigger SI via sm-api? [y/n] > `tput sgr0`"
read confirm
if [ "$confirm" == "y" ] || [ -z "$confirm" ];then
        echo "------------------------------------------------------------------------------------------------------------------"
        echo "`tput setaf 2`curl -i -X GET -H \"tenant: bics\" -H \"Content-Type: application/json\" -H \"Accept: application/json\"  http://localhost:8091/spcm-rest-ws/pcc/spcm/subscribers/$msisdnorig`tput sgr0`"
        curl -i -X GET -H "tenant: bics" -H "Content-Type: application/json" -H "Accept: application/json"  http://localhost:8091/spcm-rest-ws/pcc/spcm/subscribers/$msisdnorig/
        echo -e "\n------------------------------------------------------------------------------------------------------------------"
        echo "`tput setaf 2`curl -i -X GET -H \"tenant: bics\" -H \"Content-Type: application/json\" -H \"Accept: application/json\"  http://localhost:8091/spcm-rest-ws/pcc/spcm/subscribers/$msisdnorig/plans`tput sgr0`"
        curl -i -X GET -H "tenant: bics" -H "Content-Type: application/json" -H "Accept: application/json"  http://localhost:8091/spcm-rest-ws/pcc/spcm/subscribers/$msisdnorig/plans
        echo -e "\n------------------------------------------------------------------------------------------------------------------"
        cp $feedfile /tango/data/silentroamer/fileload/
        echo "cp $feedfile /tango/data/silentroamer/fileload/"
        echo "---------------------------------------------------------"
        echo "`tput setaf 3`RUNNING ....:  cd /tango/scripts/bulk_import; ./trigger_generator.pl -c /tango/config/bulk_import/trigger_generator.cfg`tput sgr0`"
        cd /tango/scripts/bulk_import
        ./trigger_generator.pl -c /tango/config/bulk_import/trigger_generator.cfg > /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/.tmp
        cat /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/.tmp
        echo "---------------------------------------------------------"
        echo -en "\n`tput setaf 3`Wait until trigger generator triggers /tango/scripts/bulk_import/scripts_manager.sh which will process the new Input Files * "
        finishedprocessed="0"
        a=0
        while [ $finishedprocessed == "0" ]
        do
               finishedprocessed=$(ls -altr /tango/data/silentroamer/fileload/ | grep $feedfile.processed | wc -l)
                sleep 1
                echo -n "* "
                if [ $a -eq 30 -o $a -eq 60 -o $a -eq 120 -o $a -eq 180 -o $a -eq 240 ];then
                        echo -n "$feedfile has not been processed yet "
                fi
                let a++
        done
        echo -n " Done. `tput sgr0`Time = $a secs."
        echo ""
        echo "------------------------------------------------------------------------------------------------------------------`tput setaf 3`"
        echo -en "SM-API REQUEST: `tput setaf 2`\n"
        smapireq=$(cat /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/.tmp | grep $msisdnorig | egrep sm-api | egrep -A1 smEndpoint)
        echo "curl -X GET \"$smapireq\""
        echo -en "`tput setaf 3`SM-API RESPONSE:\n"
        smapiresp=$(cat /tango/logs/COSTAFF/hector/sh_scripts/SilentRoamer/.tmp | grep -A1 $msisdnorig |  grep "http response")
        smapirespOk=$(echo "$smapiresp" | grep "200 OK" | egrep -v grep)
        if [ -z "$smapirespOk" ];then
                echo "`tput setaf 1`echo $smapiresp"
        else
                echo "`tput setaf 2`$smapiresp"
        fi
        echo -n "`tput sgr0`"
        echo "------------------------------------------------------------------------------------------------------------------"
        echo "`tput setaf 3`ls -atlr /tango/data/silentroamer/fileload/ | grep $newfeedfile `tput sgr0`"
        ls -atlr /tango/data/silentroamer/fileload/ | grep "$newfeedfile"
        showSIcdrs
        showUNScdrs
        showSOMcdrs
        checkOfferPromotionDB
else
        echo "Nothing done, Bye"
fi

fi