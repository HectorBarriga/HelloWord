#!/bin/bash
#

# Initial paremeters
hostname=$(hostname)

#subroutines

showfeedfile()
{
file=$(cat $1 | grep $msisdnorig)
ofile=$(cat $1 | grep $msisdnorig | paste -sd' ')
echo ""
echo "`tput setaf 5`CDR:"
echo "`tput setaf 3`$file"
echo "`tput sgr0`"
echo "`tput setaf 5`List of Fields:`tput sgr0`"
c=0
IFS=";"
for i in $ofile
do
        if [ "$c" == "24" ];then
                c=0
                echo ""
        fi
        echo "$c. $i"
        let ++c
done
echo ""
}

showIScdrs()
{
echo "---------------------------------------------------------"
echo "`tput setaf 3`ls -altr /tango/data/cdr/active_ussd_si.cdr`tput sgr0`"
ls -altr /tango/data/cdr/active_ussd_si.cdr
echo "`tput setaf 3`cat /tango/data/cdr/active_ussd_si.cdr | grep $msisdnin`tput sgr0`"
cat /tango/data/cdr/active_ussd_si.cdr | grep "$msisdnin"
}

showSSRVSMPPcdrs()
{
echo "---------------------------------------------------------"
echo "`tput setaf 3`ls -altr /tango/data/cdr/active_ssrv_smpp.cdr`tput sgr0`"
ls -altr /tango/data/cdr/active_ssrv_smpp.cdr
echo "`tput setaf 3`cat /tango/data/cdr/active_ssrv_smpp.cdr | grep $msisdnorig`tput sgr0`"
cat /tango/data/cdr/active_ssrv_smpp.cdr | grep "$msisdnorig"
}

showSOMcdrs()
{
echo "---------------------------------------------------------"
echo "`tput setaf 3`ls -altr /tango/data/cdr/active_som.cdr`tput sgr0`"
ls -altr /tango/data/cdr/active_som.cdr
echo "`tput setaf 3`cat /tango/data/cdr/active_som.cdr | grep $msisdnorig`tput sgr0`"
cat /tango/data/cdr/active_som.cdr | grep "$msisdnorig"
}


checkOfferPromotionDB()
{
echo "---------------------------------------------------------"
echo "`tput setaf 3`echo \"select * from Offer where msisdn = '$msisdnorig';\" | /opt/mysql/bin/mysql -u root -proot promotion`tput sgr0`"
Offer=$(echo "select * from Offer where msisdn = '$msisdnorig'\G;" | /opt/mysql/bin/mysql -u root -proot promotion)
echo "$Offer"
echo "---------------------------------------------------------"
if [ ! -z "$Offer" ];then
   if [ ! -z $msisdnorig ];then
        echo "`tput setaf 5`SR_SILENT_ROAMER_SEND_SMPP has already been triggered. You need to wait 5 days."
        echo -n "`tput setaf 3`Do you want to remove $msisdnorig from promotion Database from Offer table? [y] [Default n] >  `tput sgr0`"
        read answer
        if [ "$answer" == "y" ];then
                echo "`tput setaf 2`delete from Offer where msisdn = '$msisdnorig'; | mysql -u root -proot promotion"
                echo "delete from Offer where msisdn = '$msisdnorig';" | mysql -u root -proot promotion
                echo "/tango/bin/mps | grep 64321 | awk -v i=4 '{print \$4}' | xargs kill -9"
                /tango/bin/mps | grep 64321 | awk -v i=4 '{print $i}' | xargs kill -9
                echo "/tango/bin/mps | grep 19225 | awk -v i=4 '{print \$4}' | xargs kill -9"
                /tango/bin/mps | grep 19225 | awk -v i=4 '{print $i}' | xargs kill -9
                echo "`tput setaf 3`SOM and CMC Processes will take time to restart. Please wait .... `tput sgr0`"
                echo "CTR+C to finish"
                echo -n "Killing processes * "
                i=0
                while [ $i -lt 40 ] && [ -z "$isidle" ]
                do
                        printf '* '
                        sleep 2
                        i=$[$i+1]
                        isidle=$(/tango/bin/mps | awk '/64321/ || /19225/' | grep -i idle)
                done
                echo -n "Process are in Idle, keep waiting * "
                i=0
                while [ $i -lt 40 ] && [ ! -z "$isidle" ]
                do
                        printf '* '
                        sleep 2
                        i=$[$i+1]
                        isidle=$(/tango/bin/mps | awk '/64321/ || /19225/' | grep -i idle)
                done
                echo -n " [`tput setaf 2`Finished`tput sgr0`]"
                echo ""
                echo ""
                echo ""
                echo "`tput setaf 5`TRIGGERING SI AGAING TO REFRESH CACHE SO NEXT TEST WILL WORK`tput sgr0`"
                echo "---------------------------------------------------------"
                echo "curl \"http://$hostname:8080/sm-api/smEndpoint?method=sr&aNumber=$msisdnorig&trigger=EoCN&vplmn=CHNCU&hplmn=MNGMC\""
                curl "http://$hostname:8080/sm-api/smEndpoint?method=sr&aNumber=$msisdnorig&trigger=EoCN&vplmn=CHNCU&hplmn=MNGMC"
                echo "---------------------------------------------------------"
                showIScdrs
                showSSRVSMPPcdrs
                showSOMcdrs
                checkOfferPromotionDB

        else
                echo ""
                echo "`tput setaf 1`Nothing done. Bye..`tput sgr0`"
                echo ""
        fi
   else
        echo ""
        echo "`tput setaf 1`msisdn is empty, try again. Bye`tput sgr0`"
        echo ""
   fi
else
        echo ""
        echo "`tput setaf 2`No Records in Offer.promotion table for $msisdnorig.`tput sgr0`"
        echo ""
fi
}

#main()
echo -n "`tput setaf 3`Enter msisdn > `tput sgr0`"
read msisdnorig
msisdnin=$(echo $msisdnorig | sed 's/./&0/g' | cut -d= -f2 | sed 's/0 020403/20403/' | sed 's/.$//' | head -1)
checkOfferPromotionDB