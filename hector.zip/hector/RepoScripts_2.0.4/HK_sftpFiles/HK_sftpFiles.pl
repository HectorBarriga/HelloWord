#!/usr/bin/perl
##############################################################################
# Filename:    HK_sftpFiles.pl
# Revision:    $Revision: 0.1.0 $
# Author:      Hector Barriga
#
# This perl script transfers into a remote server over sftp all files in the directorY
# specified that are older than a given number of days.
#
# Copyright (c) Tango Telecom 2015
#
# All rights reserved.
# This document contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or
# in part is expressly prohibited, except as may be specifically
# authorized by prior written agreement or permission of Tango Telecom.
##############################################################################
# version 0.1.0 - First version
#
##############################################################################

###### Libraries
use Getopt::Std;

###### my variables
my $logFileDir = "/tango/logs/sftp/";
my $logString;
my $localDir;
my $destDir;
my $destIP;
my $password;
my $user;
my $fileName;
my $ext;
my $removeActive;
my $logDate;
my $oldday;
my $offset;


###### Get arguments

if ( 0 == getopts( "h:l:m:i:p:u:n:e:o:r:h:" ) )
{
        usage();
        exit 0;
}

if ( defined( $opt_h ) )
{
        usage();
}

if ( defined( $opt_l ) )
{
        $localDir = $opt_l;
}
else
{
        usage();
}

if ( defined( $opt_m ) )
{
        $destDir = $opt_m;
}
else
{
        usage();
}

if ( defined( $opt_i ) )
{
        $destIP = $opt_i;
}
else
{
        usage();
}

if ( defined( $opt_p ) )
{
        $password = $opt_p;
}
else
{
        usage();
}

if ( defined( $opt_u ) )
{
        $user = $opt_u;
}
else
{
        $user = "tango";
}

if ( defined( $opt_n ) )
{
        $fileName = $opt_n;
}
else
{
        $fileName = "*";
}

if ( defined( $opt_e ) )
{
        $ext = ".".$opt_e;
}
else
{
        $ext = "";
}

if ( defined( $opt_r ) )
{
        $removeActive = $opt_r;
        if ($removeActive != 1 && $removeActive != 0)
        {
                usage();
        }
}
else
{
        $removeActive = "0";
}

if ( defined( $opt_o ) )
{
        if ($opt_o != "none")
        {
                $offset = $opt_o * 86400;
                @oldday = yesterday();
                $logDate = $oldday[5]."".$oldday[4]."".$oldday[3];
        }
        else
        {
                @oldday = getTime();
                $logDate = $oldday[5]."".$oldday[4]."".$oldday[3];
        }
}
else
{
        $offset = 86400;
        @oldday = yesterday();
        $logDate = $oldday[5]."".$oldday[4]."".$oldday[3];
}

###### Start Script

$logString = "--------------------------- STARTING SFTP ------------------------------\n";
printLog($logString,1);
$logString = "This is the list of Files:";
printLog($logString,1);
my @checkFiles = `ls $localDir$fileName$logDate$ext`;
if (@checkFiles <= 0)
{
        $logString = "------------------ No files found. Nothing done, bye. ------------------\n";
        printLog($logString,1);
        exit 0;
}

foreach (@checkFiles)
{
        s/ //g;
        s/\n//g;
        printLog($_,0);
}

$logString = "SFTP spawn Starting.....";
printLog($logString,1);

my $sftpCommand ="/usr/bin/expect<<EOD
spawn  sftp   $user\@$destIP
expect  \"password:\"
send \"$password\\n\"
expect  \"sftp\"
send \"cd  $destDir\\n\"
expect  \"sftp\"
send \"lcd $localDir\\n\"
expect  \"sftp\"
send \"put $fileName$logDate$ext\\n\"
sleep 10;
expect  \"sftp\"
send \"exit\n\"
EOD";
print "\n------------------------ SFTP Command: ------------------------ \n$sftpCommand \n";
my @result =  `$sftpCommand`;
print "\n------------------------ SFTP returned:------------------------ \n@result \n";
my $lines = @result;
print $lines."\n";
print "\n------------------------ SFTP END------------------------------\n";
printLog($sftpCommand,0);

$logString = "SFTP spawn Finished.";
printLog($logString,1);

if ($removeActive > 0)
{
        $logString = "Removing Files ....";
        printLog($logString,1);
        foreach (@checkFiles)
        {
                s/ //g;
                s/\n//g;
                $removeCommand = "rm $_";
                my @resultRemove = `$removeCommand`;
                printLog($removeCommand,0);
        }
}

$logString = "------------------------- Done. SFTP is completed. ---------------------\n";
printLog($logString,1);




###### SubRutines

sub usage
{
  print <<EOF;


        Usage: HK_sftpFiles.pl

               Mandatory Arguments:

                           -l <Original Directory>     Local Files Directory. Include "/" at the end

               -m <Destination Directory>  sftp files to remote directory. Include "/" at the end

               -i <Remote Host>            Remote Host IP to where the files will be sent

               -p <Remote Password>        Rmote Username's password

               Options:

               -u <Remote Username>        Remote Username
                                           Default: "tango"

               -n <File Name>              Name files to be sftp
                                           Default: "*"

               -e <File Name Extention>    Extention of Name files to be sftp
                                           Example:  zip
                                           Default: "" Nothing will be added

               -o <days>                   To stp files x days ago
                                           Options:
                                           1 = yestereday files
                                           2 = day before yesterday, and so on
                                           none = "" Date will not be taken into account
                                           Default: 0

               -r <Remove Files>           Purge files after having been sftped
                                           Options:
                                           0 = Inactive, it doesn't remove the files
                                           1 = Active, It removes files after having been sftped
                                           2 > Error
                                           Default: 0

               -h                          show help

         e.g.1 HK_sftpFiles.pl -l /tango/data/cdr/ussd_si/archive -n ssrv-be.cdr -e zip /tango/data/cdrStore -i 172.19.0.4 -p t3l3com
         This command will sftp all files ssrv-be.cdr<yesterday>.zip under /tango/data/cdr/ussd_si/archive to tango@172.19.0.4:/tango/data/cdrStore/
         and keep the files

         e.g.2 HK_sftpFiles.pl -l /export/home/soporte/HK_sftpFiles/temp/ -m /tango/data/user_data/COStaff/hector/HK_sftpFiles -i 10.214.57.10 -p T4ng0.Rocks -o none -r 1
         This command will sftp all files /export/home/soporte/HK_sftpFiles/temp/* to tango@10.214.57.10:/tango/data/user_data/COStaff/hector/HK_sftpFiles/ and remove ALL of them afterwards



         NOTE: Do not forget to create log Directory $logFileDir

EOF
  exit;
}

sub printLog
{
 my $logString = shift;
 my $addDate = shift;
 my @time = getTime();
 my $file = $logFileDir."monitorSFTP_".$time[3]."_".$time[4]."_".$time[5].".log";
 my $date = $time[3]."/".$time[4]."/".$time[5];
 my $time = $time[2].":".$time[1].":".$time[0];

 if (open F1,">>".$file)
 {
        if ($addDate == 1)
        {
                print F1 "[ ".$date." ".$time." ] ".$logString."\n";
                close(F1);
        }
        else
        {
                print F1 $logString."\n";
                close(F1);
        }
 }
}

sub getTime
{
 ($Second, $Minute, $Hour, $Day, $Month, $Year, $WeekDay, $DayOfYear, $IsDST) = localtime(time);

 if($Hour < 10)   {  $Hour = "0" . $Hour ; }
 if($Minute < 10) {  $Minute = "0" . $Minute ; }
 if($Second < 10) {  $Second = "0" . $Second ; }
 my $Month = $Month + 1 ;
 if($Month < 10)
 {
 $Month = "0" .
 $Month ;
 }
 if($Day < 10)
 {
  $Day = "0" . $Day ;
 }
 if($Year >= 100)
 {
  $Year = $Year - 100 ;
  $Year = $Year + 2000;
 }
 return  ($Second, $Minute, $Hour, $Day, $Month, $Year, $WeekDay, $DayOfYear, $IsDST);
}

sub yesterday
{
 ($Second, $Minute, $Hour, $Day, $Month, $Year, $WeekDay, $DayOfYear, $IsDST) = localtime(time-$offset);

 if($Hour < 10)   {  $Hour = "0" . $Hour ; }
 if($Minute < 10) {  $Minute = "0" . $Minute ; }
 if($Second < 10) {  $Second = "0" . $Second ; }
 my $Month = $Month + 1 ;
 if($Month < 10)
 {
 $Month = "0" .
 $Month ;
 }
 if($Day < 10)
 {
  $Day = "0" . $Day ;
 }
 if($Year >= 100)
 {
  $Year = $Year - 100 ;
  $Year = $Year + 2000;
 }
 return  ($Second, $Minute, $Hour, $Day, $Month, $Year, $WeekDay, $DayOfYear, $IsDST);
}