#!/bin/bash

# Initial Settings
whiteliststring=Hostname
blackliststring=

if [ -z "$whiteliststring" ] || [ "$whiteliststring" == "none" ];then
        whiteliststring=''
fi
if [ -z "$blackliststring" ];then
        blackliststring='none'
fi


DIR=$(echo "`dirname $0`")
hostname=$(hostname)
pwd=$(pwd)
todayExt=$(perl -e '@d=localtime time()-84600; printf "%4d%02d%02d%02d%02d%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1],$d[0]')
red=`tput setaf 1`
green=`tput setaf 2`
yellow=`tput setaf 3`
blue=`tput setaf 4`
reset=`tput sgr0`
lightblue=`tput setaf 6`
pink=`tput setaf 5`
bold=`tput bold`
italic=`tput sitm`

modifyFileLocalhost()
{
machine=$hostname
echo -e "\n"$yellow"====================================================== Working on $machine "$red" Local machine !"$yellow"======================================================"$reset""
if [ ! -f $file ];then
        echo -e "\n"$red"Sorry, $file doesnt exit in $machine\n"$reset""
        return
fi
if [ ! -d /tango/logs/COSTAFF/hector/modifyFileClusterBackups/ ];then mkdir -p /tango/logs/COSTAFF/hector/modifyFileClusterBackups/;fi
cp -rfp $file /tango/logs/COSTAFF/hector/modifyFileClusterBackups/$onlyFile.$todayExt


################## existingLine
if [ -z "$existingLine" ];then
        existingLine=$(cat $file | tail -1)
        lastLine="yes"
        doesNewLineExist=$(cat $file | grep -w "$existingLine" | wc -l)
else
        doesNewLineExist=$(cat $file | grep "$existingLine" | wc -l)
fi

if [ $doesNewLineExist -eq 0 ];then
        echo ""$yellow"------------------------ Original $file in $machine -----------------------------------"$pink""
        cat $file
        echo ""$yellow"----------------------------------------------------------------"$reset""
        existingLine=$(cat $file | tail -1)
        lastLine="yes"
        echo -e -n "["$red"Warning"$reset"] $existingLineInit is NOT present in $file in $machine. Do you want to add it (Not modify last line) at the end of file [y/n Default = y] > "
        read continue
        if [ "$continue" == "n" ];then
                echo -e "\n"$red"Nothing done in $file in $machine\n"$reset""
                return
        fi
elif [ $doesNewLineExist -gt 1 ];then
        echo -e "["$red"Warning"$reset"] $existingLine is present $doesNewLineExist times in $file in $machine, they ALL will be modified!!!"$reset""
        echo -n "Are you sure you would like to continue [y/n Default = y] > "
        read continue
        if [ "$continue" == "n" ];then
                echo -e "\n"$red"Nothing done in $file in $machine\n"$reset""
                return
        fi
fi

if [ "$lastLine" == "yes" ];then
        cat $file > $DIR/.tempFile
        echo $newLine >> $DIR/.tempFile
else
        if [ "$action" == "r" ];then
                cat $file | sed "s|$existingLine|$newLine|" > $DIR/.tempFile
        else
                cat $file | sed "s|$existingLine|$existingLine\n$newLine|" > $DIR/.tempFile
        fi
fi
echo ""$yellow"-------------------------- New File --------------------------------------"$green""
cat $DIR/.tempFile
echo ""$yellow"----------------------------------------------------------------"$reset""
echo -n "Would you like to deploy it? [y/n Default = y] > "
read continue
if [ "$continue" == "n" ];then
        echo -e "\n"$red"Nothing done in $file in $machine\n"$reset""
        return
fi
cp $DIR/.tempFile $file
echo ""$yellow"-------------------------- CURRENT $file -----------------------------------------"$pink""
cat $file
echo ""$yellow"--------------------------- diff /tango/logs/COSTAFF/hector/modifyFileClusterBackups/$onlyFile.$todayExt $file ----------------------------------"$reset""
diff /tango/logs/COSTAFF/hector/modifyFileClusterBackups/$onlyFile.$todayExt $file
echo ""$yellow"----------------------------------------------------------------"$reset""
echo -e "\nDone\n"
}

modifyFileCluster()
{
machine=$1
echo -e "\n"$yellow"\n\n====================================================== Working on $machine ======================================================"$reset""
if [ $(ssh tango@$machine "ls -altr $file | wc -l"  2> /dev/null) == "0" ];then
        file="$pwd/$onlyFile"
fi
if [ $(ssh tango@$machine "ls -altr $file | wc -l"  2> /dev/null) == "0" ];then
        echo -e "\n"$red"Sorry, $file doesnt exit in $machine. Make sure you put the whole directory path in front of the file. (E.g. ./file is not good)\n"$reset""
        return
fi
if [ $(ssh tango@$machine "ls -d /tango/logs/COSTAFF/hector/modifyFileClusterBackups/ | wc -l"  2> /dev/null) == "0" ];then ssh tango@$machine "mkdir -p /tango/logs/COSTAFF/hector/modifyFileClusterBackups/";fi
onlyFile=$(echo "$file" | rev | cut -d"/" -f1 | rev)
ssh tango@$machine "cp -rfp $file /tango/logs/COSTAFF/hector/modifyFileClusterBackups/$onlyFile.$todayExt"

echo ""$yellow"------------------------ Original $file in $machine -----------------------------------"$pink""
ssh tango@$machine "cat $file"
echo ""$yellow"----------------------------------------------------------------"$reset""


################## existingLine
if [ -z "$existingLineInit" ];then
        existingLine=$(ssh tango@$machine "cat $file | tail -1")
        lastLine="yes"
        doesNewLineExist=$(ssh tango@$machine "cat $file" | grep -w "$existingLine" | wc -l)
else
        doesNewLineExist=$(ssh tango@$machine "cat $file" | grep "$existingLine" | wc -l)
fi

if [ $doesNewLineExist -eq 0 ];then
        existingLine=$(ssh tango@$machine "cat $file | tail -1")
        lastLine="yes"
        echo -e -n "["$red"Warning"$reset"] $existingLineInit is NOT present in $file in $machine. Do you want to add it (Not modify last line) at the end of file [y/n Default = y] > "
        read continue
        if [ "$continue" == "n" ];then
                echo -e "\n"$red"Nothing done in $file in $machine\n"$reset""
                return
        fi
elif [ $doesNewLineExist -gt 1 ];then
        echo -e "["$red"Warning"$reset"] $existingLine is present $doesNewLineExist times in $file in $machine, they ALL will be modified!!!"$reset""
        echo -n "Are you sure you would like to continue [y/n Default = y] > "
        read continue
        if [ "$continue" == "n" ];then
                echo -e "\n"$red"Nothing done in $file in $machine\n"$reset""
                return
        fi
fi

if [ "$lastLine" == "yes" ];then
        ssh tango@$machine "cat $file > $DIR/.tempFile"
        ssh tango@$machine "echo $newLine >> $DIR/.tempFile"
else
        if [ "$action" == "r" ];then
                ssh tango@$machine "cat $file" | sed "s|$existingLine|$newLine|" > $DIR/.tempFile
                getTempFile=$(cat $DIR/.tempFile)
                scp $DIR/.tempFile tango@$machine:$DIR/ >/dev/null 2>&1
        else
                ssh tango@$machine "cat $file" | sed "s|$existingLine|$existingLine\n$newLine|" > $DIR/.tempFile
                getTempFile=$(cat $DIR/.tempFile)
                scp $DIR/.tempFile tango@$machine:$DIR/ >/dev/null 2>&1
        fi
fi
echo ""$yellow"-------------------------- New File --------------------------------------"$green""
ssh tango@$machine "cat $DIR/.tempFile"
echo ""$yellow"----------------------------------------------------------------"$reset""
echo -n "Would you like to deploy it? [y/n Default = y] > "
read continue
if [ "$continue" == "n" ];then
        echo -e "\n"$red"Nothing done in $file in $machine\n"$reset""
        return
fi
ssh tango@$machine "cp $DIR/.tempFile $file"
echo ""$yellow"-------------------------- CURRENT $file -----------------------------------------"$pink""
ssh tango@$machine "cat $file"
echo ""$yellow"--------------------------- ssh tango@$machine \"diff /tango/logs/COSTAFF/hector/modifyFileClusterBackups/$onlyFile.$todayExt $file\" ----------------------------------"$reset""
ssh tango@$machine "diff /tango/logs/COSTAFF/hector/modifyFileClusterBackups/$onlyFile.$todayExt $file"
echo ""$yellow"----------------------------------------------------------------"$reset""
echo -e "\nDone\n"
}


# Main()

echo -n "Enter File [Default directory = $pwd/] > "
read file
onlyFile=$(echo "$file" | rev | cut -d"/" -f1 | rev)
if [ ! -f "$file" ]; then
        file="$pwd/$onlyFile"
fi
if [ -f "$file" ]; then
        echo ""$yellow"------------------------ Original $file -----------------------------------"$pink""
        cat $file
        echo ""$yellow"----------------------------------------------------------------"$reset""
fi
echo -n "Enter EXISTING line [Default last line] > "
read existingLine
existingLineInit=$existingLine
echo -n "Enter NEW line > "
read newLine
if [ -z "$newLine" ]; then
        echo -e "\n"$red"Sorry, there is not new line, nothing done, bye\n"$reset""
        exit
fi
echo -n "Would you like to "$yellow"replace"$reset" EXISTING line with NEW line or "$yellow"add"$reset" NEW line after EXISTING line? [a/r] [ Default = a] > "
read action
echo -n "Enter remote servers list separated by commas or Enter \"cluster\" to get list from /etc/hosts [ Default = $hostname ] > "
read hosts_List
if [ "$hosts_List" == "cluster" ];then
        echo -n "Enter cluster list separated by commas (pattern for /etc/hosts RTE or SPCM or NA [ Default = all ] > "
        read pattern
        if [ ! -z "$pattern" ];then
                listOfPatternsArray=(`echo ${pattern} | sed 's/,/ /g'`)
                listOfPatternsArrayLengh=${#listOfPatternsArray[@]}
        else
                listOfPatternsArray="#"
                listOfPatternsArrayLengh=1
        fi
        for (( j=0;j<$listOfPatternsArrayLengh;j++))
        do
                hosts_List=$(cat /etc/hosts | grep "$whiteliststring" | egrep "#" | egrep "${listOfPatternsArray[$j]}" | egrep -v "$blackliststring" | egrep -v $hostname | awk '{print $5}' | awk '{printf("%s,", $0)}' | sed 's/.$//')
        done
fi
modifyFileLocalhost
for getHost in ${hosts_List//,/ }
do
        if [ "$getHost" != "$hostname" ]; then
                modifyFileCluster "$getHost"
        fi
done