#!/bin/bash
#############################################################################
# Filename:    feedfile.sh
#
# This sh script is to run End-To-End tests for Silent Roamer Telefonica
#
# Copyright (c) Tango Telecom 2017
# Author: Hector Barriga
#
# All rights reserved.
# This document contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or
# in part is expressly prohibited, except as may be specifically
# authorized by prior written agreement or permission of Tango Telecom.
##############################################################################
# version 0.1.0 - First version
# version 0.1.2 - Add multitenancy
# version 0.1.3 - Add Offer Acceptance
version=0.1.3
#
##############################################################################

#---------------------------------------------------------------
# Configurations
#---------------------------------------------------------------
mysqlmasterhost1="IPXMIATCRTE3"
mysqlmasterhost2="IPXMIATCRTE4"
mysqlmasterhostAM1="IPXMIATCDB1"
mysqlmasterhostAM2="IPXMIATCDB2"
mysqluser="root"
mysqlpw="t3il3achum"
spcmMachine=IPXMIATCSPCM_ext
askToEnterNewEpochTime=no
#---------------------------------------------------------------
# Initial conditions
#---------------------------------------------------------------
scriptScript=$1
if [ -z "$1" ];then scriptScript="/tango/logs/COSTAFF/hector/sh_scripts/BusinessConnect";fi
ncat -w 1 $mysqlmasterhost1 3306 </dev/null > $scriptScript/.tmp
if [ ! -s $scriptScript/.tmp ];then
        mysqlmasterhost=$mysqlmasterhost2
else
        mysqlmasterhost=$mysqlmasterhost1
fi
ncat -w 1 $mysqlmasterhostAM1 3306 </dev/null > $scriptScript/.tmp
if [ ! -s $scriptScript/.tmp ];then
        mysqlmasterhostAM=$mysqlmasterhostAM2
else
        mysqlmasterhostAM=$mysqlmasterhostAM1
fi
mv $scriptScript/.tmp /tango/logs/COSTAFF/trash

logDateTime=$(perl -e '@d=localtime time(); printf "[%4d%02d%02d %02d%02d%02d] ", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1],$d[0]')
logFileDate=$(perl -e '@d=localtime time(); printf "%4d%02d%02d", $d[5]+1900,$d[4]+1,$d[3]')

#subroutines

printLog()
{
if [ ! -d "$scriptScript/logs" ];then
        mkdir $scriptScript/logs
fi
echo "$logDateTime [Action = $1] [ Question => $2 ]" >> $scriptScript/logs/feedfileBC_$logFileDate.log
echo "$logDateTime [Action = $1] [ Answer   => $3 ]" >> $scriptScript/logs/feedfileBC_$logFileDate.log
}

showfeedfile()
{
columnnames=$(echo "Start_Date_and_time,End_Date_and_time,DATA_RECORD_TYPE,VIOLATION,TIMEOUT,LABEL_OPC,LABEL_DPC,GTCALLING_NO,GTCALLED_NO,MS_ISDN,MSC,BACKCLG_NO,MS_RN,IMSI,SUBSCRIBER_OPERATOR_NAME,SUBSCRIBER_OPERATOR_COUNTRY,IMEI,TAC,SS_CODE,SERVICE_KEY,SUPPORT_CAMEL_PH,ER_CODE,TCAP_ABORT_CAUSE,SCCP_RETCAUSE,SERVCENT_ADDR,USRERR_REASON,NUMOF_SCCPMSG,SCCP_MSGLEN,TP_MTI,DCH,LINKSET_NAME,NUMOF_MO_SMSMSG,NUMOF_MT_SMSMSG,TP_OA_ALPHANUM,CAMEL_CAPABILITY_HANDLING,TP_OA,TP_DA,TRANS_TIME,OP_CODE,DIRECTION,DESTIN_OPERATOR_NAME,DESTIN_OPERATOR_COUNTRY,ORIG_OPERATOR_NAME,ORIG_OPERATOR_COUNTRY,VLR_NUMBER,SGSN_NUMBER,SGSN_ADDRESS,Call_Trace_Jump")
file=$(cat $1 | grep $msisdnorig)
ofile=$(cat $1 | grep $msisdnorig | paste -sd' ')
echo ""
echo "`tput setaf 5`CDR:"
echo "`tput setaf 3`$file"
echo "`tput sgr0`"
echo "`tput setaf 5`List of Fields:`tput sgr0`"
c=0
IFS=","
for i in $ofile
do
        if [ "$c" == "48" ];then
                c=0
                echo ""
        fi
        d=$((c+1))
        getColumnname=$(echo "$columnnames" | cut -d, -f"$d")
        if [ "$c" == "0" ] || [ "$c" == "1" ];then
                getEpochTime=$(echo "base=10; $i" | bc)
                getEpochTime=$(echo $((0x${i})))
                getNormalTime=$(date -d @$((getEpochTime/1000)))
                outputprintf=$(printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-1s \033[32m %-3s\n' $c. $getColumnname "=" $i "=> ")
                echo -en "$outputprintf $getNormalTime\033[1m"
                echo ""
        else
                printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-1s \033[0;39m\n' $c. $getColumnname "=" $i
        fi
        let ++c
done
echo ""
}

showBCcdrs()
{
if [ ! -d "$scriptScript/temp" ];then
        mkdir $scriptScript/temp
fi
echo "------------------------------------------------------------------------------------------------------------------"
echo "`tput setaf 3`cp /tango/data/cdr/active_BC_SIBB.cdr $scriptScript/temp/active_BC_SIBB_btangoC.cdr`tput sgr0`"
echo "`tput setaf 3`scp tangoD:/tango/data/cdr/active_BC_SIBB.cdr $scriptScript/temp/active_BC_SIBB_btangoD.cdr`tput sgr0`"
cp /tango/data/cdr/active_BC_SIBB.cdr $scriptScript/temp/active_BC_SIBB_btangoC.cdr
scp tangoD:/tango/data/cdr/active_BC_SIBB.cdr $scriptScript/temp/active_BC_SIBB_btangoD.cdr
ls -altr $scriptScript/temp/active_BC_SIBB*
cerosMsisdn=$(echo "$msisdnorig" | sed 's/./&0/g' | sed 's/.$//' | head -1)
echo "`tput setaf 3`cat  $scriptScript/temp/active_BC_SIBB* | grep $cerosMsisdn`tput sgr0`"
wsmsCDRs=$(cat  $scriptScript/temp/active_BC_SIBB* | grep "$cerosMsisdn")
if [ -z "$wsmsCDRs" ];then
        echo ""
        echo "`tput setaf 1`No BC CDRs!!!`tput setaf 5` It seems CDR didnt pass the filters as per SIBB conditions
Very likely \"`tput setaf 1`Current EPOCH time in Hex\"`tput setaf 5` is too old"
        echo "HOWEVER!!! check /tango/logs/sibb.log`tput sgr0`"
        echo ""
else
        echo "$wsmsCDRs"
fi
}

showUNScdrs()
{
echo "------------------------------------------------------------------------------------------------------------------"
echo "`tput setaf 3`cp /tango/data/cdr/active_UNS_BC.cdr $scriptScript/temp/active_UNS_BC_btangoC.cdr`tput sgr0`"
echo "`tput setaf 3`scp tangoD:/tango/data/cdr/active_UNS_BC.cdr $scriptScript/temp/active_UNS_BC_btangoD.cdr`tput sgr0`"
cp /tango/data/cdr/active_UNS_BC.cdr $scriptScript/temp/active_UNS_BC_btangoC.cdr
scp tangoD:/tango/data/cdr/active_UNS_BC.cdr $scriptScript/temp/active_UNS_BC_btangoD.cdr
ls -altr $scriptScript/temp/active_UNS_BC*
echo "`tput setaf 3`cat $scriptScript/temp/active_UNS_BC* | grep $cerosMsisdn | egrep \"$timeSiCdrs\"`tput sgr0`"
IsThereunsCDRs=$(cat $scriptScript/temp/active_UNS_BC* | grep "$cerosMsisdn" | egrep "$timeSiCdrs" | tail -2)
unsCDRs=$(cat $scriptScript/temp/active_UNS_BC* | grep "$cerosMsisdn" | egrep "$timeSiCdrs" | tail -2)
if [ -z "$IsThereunsCDRs" ];then
        echo ""
        echo -e "`tput setaf 1`No CDRs!!!`tput setaf 5` It seems NO SMS was sent to subscriber. Either:\n   1. Subscriber must have received it already\n 2. active_UNS_BC.cdr file rolled over\n   3. GTMS is still processing delivery of SMSs\n 4. UNS is not running or something`tput sgr0`"
        echo ""
else
        echo "$unsCDRs"
        getBCPortalURL=$(echo "$unsCDRs" | cut -d, -f10)
fi
}

showHRGcdrs()
{
echo "------------------------------------------------------------------------------------------------------------------"
echo "`tput setaf 3`cp /tango/data/cdr/active_HRG.cdr $scriptScript/temp/active_HRG_btangoC.cdr`tput sgr0`"
echo "`tput setaf 3`scp tangoD:/tango/data/cdr/active_HRG.cdr $scriptScript/temp/active_HRG_btangoD.cdr`tput sgr0`"
cp /tango/data/cdr/active_HRG.cdr $scriptScript/temp/active_HRG_bangoC.cdr
scp tangoD:/tango/data/cdr/active_HRG.cdr $scriptScript/temp/active_HRG_btangoD.cdr
ls -altr $scriptScript/temp/active_HRG*
echo "`tput setaf 3`cat $scriptScript/temp/active_HRG* | grep $msisdnin | egrep \"$timeSiCdrs\"`tput sgr0`"
IsTherehrgCDRs=$(cat $scriptScript/temp/active_HRG* | grep "$msisdnin" | egrep "$timeSiCdrs" | tail -2)
hrgCDRs=$(cat $scriptScript/temp/active_HRG* | grep "$msisdnin" | egrep "$timeSiCdrs" | tail -2)
if [ -z "$IsTherehrgCDRs" ];then
        echo ""
        echo -e "`tput setaf 1`No CDRs!!!`tput setaf 5` It seems NO SMS was sent to subscriber. Either:\n   1. Subscriber must have received it already\n 2. active_HRG.cdr file rolled over\n   3. GTMS is still processing delivery of SMSs\n 4. HRG is not running or something`tput sgr0`"
        echo ""
else
        echo "$hrgCDRs"
fi
}

showBCPortalURL()
{
echo "-------------------------------- `tput setaf 3`SMS -> BC portal URL `tput sgr0` ------------------------------------------------------------"
echo "`tput setaf 3`To: $msisdnin`tput sgr0`"
getBCPortalURL_L1=${getBCPortalURL:0:88}
getBCPortalURL_L2=${getBCPortalURL:88:92}
echo -e -n "\n\e[104m   $getBCPortalURL_L1    \e[0m\n"
echo -e -n "\e[104m $getBCPortalURL_L2  \e[0m\n\n"
echo "------------------------------------------------------------------------------------------------------------------"
}

getSIBBlogs()
{
sleep 5
echo "------------------------------------------------------------------------------------------------------------------"
echo "`tput setaf 3`cp /tango/logs/sibb/sibb-sms-service.log $scriptScript/temp/sibb-service_btangoC.log`tput sgr0`"
echo "`tput setaf 3`scp tangoD:/tango/logs/sibb/sibb-sms-service.log $scriptScript/temp/sibb-service_btangoD.log`tput sgr0`"
cp /tango/logs/sibb/sibb-sms-service.log $scriptScript/temp/sibb-service_btangoC.txt
scp tangoD:/tango/logs/sibb/sibb-sms-service.log $scriptScript/temp/sibb-service_btangoD.txt
getSibbLogLast=$(cat $scriptScript/temp/sibb-service*.txt | grep -a GetLocationFromVplmn | grep -a "$msisdnorig" | tail -1 |  cut -d"." -f1 | cut -d"-" -f3 | rev | cut -c 3- | rev)

echo "`tput setaf 3`cat $scriptScript/temp/sibb-service*.txt | grep -a \"$getSibbLogLast\" | grep -a \"$msisdnorig\"`tput sgr0`"
IsTherehrgLogs=$(cat $scriptScript/temp/sibb-service*.txt | grep -a "$getSibbLogLast")
IsTherehrgLogs=$(echo "$IsTherehrgLogs" | grep "$msisdnorig")
if [ -z "$IsTherehrgLogs" ];then
        echo ""
        echo -e "`tput setaf 1`No Logs!!!`tput setaf 5` It seems NO SMS was sent to subscriber. Either:\n   1. Logstash is not running\n 2. Filebeat is not running\n 3. SIBB_BC is not running`tput sgr0`"
        echo ""
else
        echo "$IsTherehrgLogs"
fi
}

showSOMcdrs()
{
echo "------------------------------------------------------------------------------------------------------------------"
echo "`tput setaf 3`cp /tango/data/cdr/active_SOM.cdr $scriptScript/temp/active_SOM_btangoC.cdr`tput sgr0`"
echo "`tput setaf 3`scp tangoD:/tango/data/cdr/active_SOM.cdr $scriptScript/temp/active_SOM_btangoD.cdr`tput sgr0`"
cp /tango/data/cdr/active_SOM.cdr $scriptScript/temp/active_SOM_btangoC.cdr
scp tangoD:/tango/data/cdr/active_SOM.cdr $scriptScript/temp/active_SOM_btangoD.cdr
ls -altr $scriptScript/temp/active_SOM*
echo "`tput setaf 3`cat $scriptScript/temp/active_SOM* | grep $msisdnorig | egrep \"$sessionIdSiCdrs\"`tput sgr0`"
somcdrs=$(cat $scriptScript/temp/active_SOM* | grep "$msisdnorig" | egrep "$sessionIdSiCdrs")
IsTheresomcdrs=$(cat $scriptScript/temp/active_SOM* | grep "$msisdnorig" | egrep "$sessionIdSiCdrs" | cut -d, -f1)
if [ -z $IsTheresomcdrs ];then
        echo ""
        echo "`tput setaf 1`No CDRs!!!`tput setaf 5` It seems cdr file rolled over or CDRH (SOM) process is not running or something`tput sgr0`"
        echo ""
else
        echo "$somcdrs"
fi
}

checkAMDB()
{
namehost=$(hostname)
if [ "$mysqlmasterhost" == "$namehost" ];then
        whichmysql=$(which mysql)
        isPWinMyCnf=$(cat /etc/my.cnf | grep $mysqlpw | egrep -v grep)
        if [ ! -z "$isPWinMyCnf" ];then
                gomysql=$(echo "$whichmysql -u $mysqluser")
        else
                gomysql=$(echo "$whichmysql -u $mysqluser -p$mysqlpw")
        fi
        echo "----------------------------------------- `tput setaf 3`RTE3 RTE4 AM `tput sgr0`------------------------------------------------------------"
        echo "`tput setaf 3`echo \"select * from activity where msisdn = '$msisdnorig'\G;\" | $gomysql activity_meter`tput sgr0`"
        subType=$(echo "select * from activity where msisdn = '$msisdnorig'\G;" | /usr/bin/mysql -u root activity_meter)
else
        whichmysql=$(ssh tango@$mysqlmasterhost 'which mysql')
        echo "`tput setaf 3`ssh tango@$mysqlmasterhost '$whichmysql -u$mysqluser -p$mysqlpw activity_meter -e \"select * from activity where msisdn = '$msisdnorig'\G;\"'`tput sgr0`"
        subType=$(ssh tango@$mysqlmasterhost "$whichmysql -u '$mysqluser' -p'$mysqlpw' activity_meter -e 'select * from activity where msisdn = $msisdnorig\G;'" 2>/dev/null)
fi
echo "$subType"
echo "------------------------------------------------------------------------------------------------------------------"
}

checkAMDB_RTE1RTE2()
{
echo "----------------------------------------- `tput setaf 3`RTE1 RTE2 AM `tput sgr0`------------------------------------------------------------"
whichmysql=$(ssh tango@$mysqlmasterhostAM 'which mysql')
echo "`tput setaf 3`ssh tango@$mysqlmasterhostAM '$whichmysql -u root activity_meter -e \"select * from activity where msisdn = '$msisdnorig'\G;\"'`tput sgr0`"
subType=$(ssh tango@$mysqlmasterhostAM "$whichmysql -u 'root' activity_meter -e 'select * from activity where msisdn = $msisdnorig\G;'" 2>/dev/null)
echo "$subType"
echo "------------------------------------------------------------------------------------------------------------------"
}


checkOfferPromotionDB()
{
namehost=$(hostname)
if [ "$mysqlmasterhost" == "$namehost" ];then
        whichmysql=$(which mysql)
        isPWinMyCnf=$(cat /etc/my.cnf | grep $mysqlpw | egrep -v grep)
        if [ ! -z "$isPWinMyCnf" ];then
                gomysql=$(echo "$whichmysql -u$mysqluser")
        else
                gomysql=$(echo "$whichmysql -u$mysqluser -p$mysqlpw")
        fi
        echo "------------------------------------------------------------------------------------------------------------------"
        getOfferStatus=$(echo "select status from Offer where msisdn = '$msisdnorig';" | mysql -u root promotion_$tenant | egrep -v status)
        echo "`tput setaf 3`echo \"select * from Offer where msisdn = '$msisdnorig'\G;\" | mysql -u root promotion_$tenant`tput sgr0`"
        Offer=$(echo "select * from Offer where msisdn = '$msisdnorig'\G;" | mysql -u root promotion_$tenant)
else
        whichmysql=$(ssh tango@$mysqlmasterhost 'which mysql')
        getOfferStatus=$(ssh tango@$mysqlmasterhost "$whichmysql -u '$mysqluser' -p'$mysqlpw' promotion_$tenant -e 'select status from Offer where msisdn = '$msisdnorig';' | egrep -v status" 2>/dev/null)
        echo "`tput setaf 3`ssh tango@$mysqlmasterhost '$whichmysql -u$mysqluser -p$mysqlpw promotion_$tenant -e \"select * from Offer where msisdn = '$msisdnorig'\G;\"'`tput sgr0`"
        Offer=$(ssh tango@$mysqlmasterhost "$whichmysql -u '$mysqluser' -p'$mysqlpw' promotion_$tenant -e 'select * from Offer where msisdn = '$msisdnorig'\G;'" 2>/dev/null)
fi
echo "$Offer"
echo "------------------------------------------------------------------------------------------------------------------"
}





echo "------------------------------------------------------------------------------------------------------------------"
echo "`tput setaf 2`                               Welcome to \"feedfileBC.sh\" Business Connect Simulator for Telefonica
                                                version: $version             `tput sgr0`"
echo "------------------------------------------------------------------------------------------------------------------"
cd $scriptScript
echo "`tput setaf 3`Going to $scriptScript/`tput sgr0`"
echo "------------------------------------------------------------------------------------------------------------------"
ls -alrt | egrep -v feedfile
echo "------------------------------------------------------------------------------------------------------------------"
defaultfeedfile=$(ls -altr $scriptScript/ | egrep -v feedfile | egrep -v total | egrep -v "drwxr" | tail -1 | awk "{print \$9}")
echo -n "`tput setaf 3`Enter feed file [Default = $defaultfeedfile] > `tput sgr0`"
read feedfile
if [ -z $feedfile ];then
        feedfile=$defaultfeedfile
        printLog "Select Feedfile" "Enter feed file [Default = $defaultfeedfile] > " "Empty, so $feedfile is selected"
else
        printLog "Select Feedfile" "Enter feed file [Default = $defaultfeedfile] > " "$feedfile"
fi
if [ ! -f ./$feedfile ];then
        echo ""
        echo "`tput setaf 1`File doesnt exist!!!`tput sgr0` Nothing done, Bye"
        echo ""
else
echo "------------------------------------------------------------------------------------------------------------------"
echo -n "`tput setaf 3`Do you wanna edit the file? [y/n] (Default n) > `tput sgr0`"
read confirm
if [ -z "$confirm" ]; then
        sleep 0
        printLog "Edit Feedfile" "Do you wanna edit the file? [y/n] (Default n) > " "Empty, which equals to not edit"
else
        if [ "$confirm" == "y" ];then
                vi $feedfile
        fi
        printLog "Edit Feedfile" "Do you wanna edit the file? [y/n] (Default n) > " "$confirm"
fi
echo "------------------------------------------------------------------------------------------------------------------"
echo "`tput setaf 3`List of Roamers:`tput sgr0`"
gettadigMappings=$(cat /etc/logstash/tadigMappings.csv)
cat $feedfile | while read in
do
        getmsisdn=$(echo $in | cut -d"," -f10)
        getopcode=$(echo $in | cut -d"," -f39)
        if [ -z $getmsisdn ] || [ "$getmsisdn" == "_" ]; then
                part1=$(echo "MSISDN= <empty>\t\t")
        else
                part1=$(echo "MSISDN= $getmsisdn\t")
        fi
        visitcountry=$(echo $in | cut -d"," -f15)
        srcountry=$(echo "$gettadigMappings" | grep "$visitcountry" | tail -1 | rev | cut -d',' -f1 | rev)
        color=2
        if [ -z "$getmsisdn" ] || [ "$getmsisdn" == "_" ] || [ "$visitcountry" != "VIVO (BR)" ];then
                color=1
                srcountry='[NO GOOD CDR for VIVO, SI wont be triggered]'
        fi
        if [ "$getopcode" != 2 ];then
                color=1
                srcountry='[NO GOOD OP_CODE. It is not 2, SI wont be triggered]'

        fi
        if [ -z "$srcountry" ];then
                color=1
                srcountry='[NO GOOD CDR, VISITOR COUNTRY OPERATOR is not in /etc/logstash/tadigMappings.csv. SI might be triggered but CMCG wont find an OFFER]'
        fi
        echo -e "$part1""\tSUBSCRIBER_OPERATOR_NAME=$visitcountry""\tVPLMN=`tput setaf $color`$srcountry`tput sgr0`"
done

echo "------------------------------------------------------------------------------------------------------------------"
lastmsisdnin=$(cat $feedfile | head -1 | cut -d"," -f10)
echo -n "`tput setaf 3`Enter msisdn you would like to monitor [Default = First on the list $lastmsisdnin]  = > `tput sgr0`"
read selectedmsisdn
if [ -z "$selectedmsisdn" ];then
        msisdnin=$(cat $feedfile | grep $lastmsisdnin | cut -d"," -f10 | sed 's/./&0/g' | cut -d= -f2 | sed 's/0 020403/20403/' | sed 's/.$//' | head -1)
        msisdnorig=$lastmsisdnin
        printLog "Select Msisdn" "Enter msisdn you would like to monitor [Default = First on the list $lastmsisdnin]  = > " "Empty, so $selectedmsisdn is selected"
else
        msisdnin=$(cat $feedfile | grep $selectedmsisdn | cut -d"," -f10 | sed 's/./&0/g' | cut -d= -f2 | sed 's/0 020403/20403/' | sed 's/.$//' | head -1)
        msisdnorig=$selectedmsisdn
        printLog "Select Msisdn" "Enter msisdn you would like to monitor [Default = First on the list $lastmsisdnin]  = > " "$selectedmsisdn"
fi


fvisitcountry=$(cat $feedfile | grep $msisdnorig | cut -d"," -f15)
fvisitplmnNum=$(cat /etc/logstash/tadigMappings.csv | grep "$fvisitcountry" | wc -l)
if [ $fvisitplmnNum -eq 1 ];then
        fvisitplmn=$(cat /etc/logstash/tadigMappings.csv | grep "$fvisitcountry" | rev | cut -d',' -f1 | rev)
else
        defaultfvisitplmn=$(cat /etc/logstash/tadigMappings.csv | grep "$fvisitcountry" | tail -1 | rev | cut -d',' -f1 | rev)
        echo "----------------------"
        cat /etc/logstash/tadigMappings.csv | grep "$fvisitcountry" | rev | cut -d',' -f1 | rev
        echo "----------------------"
        echo -n "`tput setaf 3`As seen, there are 3 tagids in /etc/logstash/tadigMappings.csv!! Please select one of them [Default = $defaultfvisitplmn]  = > `tput sgr0`"
        read fvisitplmn
        printLog "Select visit VPLMN" "As seen, there are 3 tagids in /etc/logstash/tadigMappings.csv!! Please select one of them [Default = $defaultfvisitplmn]  = > " "$fvisitplmn"
fi


tenant=$(echo "$fvisitplmn" | tr '[:upper:]' '[:lower:]')
echo ""
echo "`tput setaf 5`############################### NOTE: ####################################
# You selected `tput sgr0`$msisdnorig`tput setaf 5` to be monitored.
# You will see results only for that subscriber in particular (below).   #
# NOTE: The other GOOD CDRs will ALSO be processed if EPOCH time is ok   #
##########################################################################
`tput sgr0`"

date1=$(echo "$feedfile" | cut -d"-" -f5)
sec1=$(echo "$date1" | rev | cut -c1-2 | rev)
date2=$(echo "$feedfile" | cut -d"-" -f6)
sec2=$(echo "$date2" | rev | cut -c1-2 | rev)

if [[ $sec1 -eq 59 ]];then
        newdate1=$(($date1 + 41))
else
        newdate1=$(($date1 + 1))
fi
if [[ $sec2 -eq 59 ]];then
        newdate2=$(($date2 + 41))
else
        newdate2=$(($date2 + 1))
fi
anothernewdate=$(($date + 2))
prefixnewfile=$(echo "$feedfile" | rev | cut -c30- | rev)
newfeedfile=$(echo "$prefixnewfile""$newdate1""-""$newdate2")
echo "------------------------------------------------------------------------------------------------------------------"
mv $feedfile $newfeedfile
feedfile=$(echo "$newfeedfile")
echo "`tput setaf 3`Feed file is now: `tput sgr0`$feedfile"
echo ""
currentEpoch=$(date +"%s")
currentEpochmillisec=$((currentEpoch*1000))
hexCuerrentEpoch=$(echo "obase=16; $currentEpochmillisec" | bc)
if [ $askToEnterNewEpochTime = "yes" ] || [ $askToEnterNewEpochTime = "true" ]; then
        showfeedfile "$feedfile"
        echo "------------------------------------------------------------------------------------------------------------------"
        echo "`tput setaf 2`FYI : Current EPOCH time is (in Hex) = `tput sgr0` $hexCuerrentEpoch"
        echo "------------------------------------------------------------------------------------------------------------------"
        echo -n "`tput setaf 3`Do you wanna re-edit it? [y/n] (Default n) > `tput sgr0`"
        read confirm
        if [ -z "$confirm" ]; then
                sleep 0
                printLog "EPOCH Time" "Do you wanna re-edit it? [y/n] (Default n) > " "Empty, which equals to not edit"
        else
                if [ "$confirm" == "y" ];then
                        vi $feedfile
                        showfeedfile "$feedfile"
                        echo "------------------------------------------------------------------------------------------------------------------"
                fi
                printLog "EPOCH Time" "Do you wanna re-edit it? [y/n] (Default n) > " "$confirm"
        fi
else
        getFirstFieldEpochTime=$(cat $feedfile | grep "$msisdnorig" | grep "$visitcountry" | grep "$srcountry" | cut -d"," -f1)
        sed "s/$getFirstFieldEpochTime/$hexCuerrentEpoch/g" $feedfile > $scriptScript/.tmp
        mv $scriptScript/.tmp $feedfile
        echo "------------------------------------------------------------------------------------------------------------------"
        echo "`tput setaf 2`FYI : Old EPOCH time was (in HEX) = `tput sgr0` $getFirstFieldEpochTime"
        echo "`tput setaf 2`FYI : New EPOCH time is (in HEX)  = `tput sgr0` $hexCuerrentEpoch"
        echo "------------------------------------------------------------------------------------------------------------------"
fi
showfeedfile "$feedfile"
echo "------------------------------------------------------------------------------------------------------------------"
checkAMDB_RTE1RTE2
isItToBeBounce=$(echo $subType | grep subscriberInfo)
if [ ! -z "$isItToBeBounce" ];then
        echo -n "`tput setaf 3`Do you wanna delele $msisdnorig \"subscriberInfo\" Activity Meter Database (In RTE1/RTE2) ? [y/n] (Default n) > `tput sgr0`"
        read confirmDelAM
        if [ "$confirmDelAM" == "y" ];then
                whichmysql=$(ssh tango@$mysqlmasterhostAM 'which mysql')
                echo "`tput setaf 2`ssh tango@$mysqlmasterhostAM \"$whichmysql -u root activity_meter -e 'delete from activity_meter.activity where msisdn = \"$msisdnorig\";'\"`tput sgr0`"
                ssh tango@$mysqlmasterhostAM "/usr/bin/mysql -u root activity_meter -e 'delete from activity_meter.activity where msisdn  = \"$msisdnorig\";'"

                echo "------------------------------------------------------------------------------------------------------------------"
                checkAMDB_RTE1RTE2
                isItToBeBounce=$(echo $subType | grep subscriberInfo)
                if [ -z "$isItToBeBounce" ];then
                        echo "`tput setaf 6`Clean`tput sgr0` There is not`tput setaf 6` subscriberInfo`tput sgr0` record in Activity Meter Database (In RTE1/RTE2)"
                        echo "------------------------------------------------------------------------------------------------------------------"
                fi
        fi
        printLog "Clean subscriberInfo record in AM" "Do you wanna delele $msisdnorig subscriberInfo Activity Meter Database (In RTE1/RTE2) ? [y/n] (Default n) > " "$confirm"
else
        echo "`tput setaf 6`Clean`tput sgr0` There is not`tput setaf 6` subscriberInfo`tput sgr0` record in Activity Meter Database (In RTE1/RTE2)"
fi

checkAMDB
isItToBeBounce=$(echo $subType | grep SUBSCRIBER_LOCATION)
if [ ! -z "$isItToBeBounce" ];then
        echo -n "`tput setaf 3`Do you wanna delele $msisdnorig \"SUBSCRIBER_LOCATION\" Activity Meter Database? [y/n] (Default n) > `tput sgr0`"
        read confirmDelAM
        if [ "$confirmDelAM" == "y" ];then
                echo "`tput setaf 2`echo \"delete from activity_meter.activity where msisdn = '$msisdnorig' and activity_name = 'SUBSCRIBER_LOCATION';\" | mysql -u root`tput sgr0`"
                echo "delete from activity_meter.activity where msisdn = '$msisdnorig' and activity_name = 'SUBSCRIBER_LOCATION';" | mysql -u root
                echo "------------------------------------------------------------------------------------------------------------------"
                checkAMDB
                isItToBeBounce=$(echo $subType | grep SUBSCRIBER_LOCATION)
                if [ -z "$isItToBeBounce" ];then
                        echo "`tput setaf 6`Clean`tput sgr0` There is not`tput setaf 6` SUBSCRIBER_LOCATION`tput sgr0` record in Activity Meter Database"
                        echo "------------------------------------------------------------------------------------------------------------------"
                fi
                printLog "Clean SUBSCRIBER_LOCATION record in AM" "Do you wanna delele $msisdnorig SUBSCRIBER_LOCATION Activity Meter Database? [y/n] (Default n) > " "$confirm"
        fi
else
        echo "`tput setaf 6`Clean`tput sgr0` There is not`tput setaf 6` SUBSCRIBER_LOCATION`tput sgr0` record in Activity Meter Database"
fi
isItToBeBounce=$(echo $subType | grep SUBSCRIBER_DEBOUNCE_LOCATION)
if [ ! -z "$isItToBeBounce" ];then
        echo -n "`tput setaf 3`Do you wanna delele $msisdnorig \"SUBSCRIBER_DEBOUNCE_LOCATION\" Activity Meter Database? [y/n] (Default n) > `tput sgr0`"
        read confirmDelAM
        if [ "$confirmDelAM" == "y" ];then
                echo "`tput setaf 2`echo \"delete from activity_meter.activity where msisdn = '$msisdnorig' and activity_name = 'SUBSCRIBER_DEBOUNCE_LOCATION';\" | mysql -u root`tput sgr0`"
                echo "delete from activity_meter.activity where msisdn = '$msisdnorig' and activity_name = 'SUBSCRIBER_DEBOUNCE_LOCATION';" | mysql -u root
                echo "------------------------------------------------------------------------------------------------------------------"
                checkAMDB
                isItToBeBounce=$(echo $subType | grep SUBSCRIBER_DEBOUNCE_LOCATION)
                if [ -z "$isItToBeBounce" ];then
                        echo "`tput setaf 6`Clean`tput sgr0` There is not`tput setaf 6` SUBSCRIBER_DEBOUNCE_LOCATION`tput sgr0` record in Activity Meter Database"
                        echo "------------------------------------------------------------------------------------------------------------------"
                fi
                printLog "Clean SUBSCRIBER_DEBOUNCE_LOCATION record in AM" "Do you wanna delele $msisdnorig SUBSCRIBER_DEBOUNCE_LOCATION Activity Meter Database? [y/n] (Default n) > " "$confirm"
        fi
else
        echo "`tput setaf 6`Clean`tput sgr0` There is not`tput setaf 6` SUBSCRIBER_DEBOUNCE_LOCATION `tput sgr0`record in Activity Meter Database"
fi
isItToBeBounce=$(echo $subType | grep offerId)
if [ ! -z "$isItToBeBounce" ];then
        echo -n "`tput setaf 3`Do you wanna delele $msisdnorig \"Token\" Activity Meter Database? [y/n] (Default n) > `tput sgr0`"
        read confirmDelAM
        if [ "$confirmDelAM" == "y" ];then
                echo "`tput setaf 2`echo \"delete from activity_meter.activity where msisdn = '$msisdnorig' and value like '%offerId%';\" | mysql -u root`tput sgr0`"
                echo "delete from activity_meter.activity where msisdn = '$msisdnorig' and value like '%offerId%';" | mysql -u root
                echo "------------------------------------------------------------------------------------------------------------------"
                checkAMDB
                isItToBeBounce=$(echo $subType | grep offerId)
                if [ -z "$isItToBeBounce" ];then
                        echo "`tput setaf 6`Clean`tput sgr0`There is not `tput setaf 6` TOKEN`tput sgr0` in Activity Meter Database"
                fi
        fi
        printLog "Clean Token record in AM" "Do you wanna delele $msisdnorig Token Activity Meter Database? [y/n] (Default n) > " "$confirm"
else
        echo "`tput setaf 6`Clean`tput sgr0` There is not`tput setaf 6` TOKEN`tput sgr0` in Activity Meter Database"
fi
isItToBeBounce=$(echo $subType | grep SUBSCRIBER_EXTERNAL_DND)
if [ ! -z "$isItToBeBounce" ];then
        echo -n "`tput setaf 3`Do you wanna delele $msisdnorig \"SUBSCRIBER_EXTERNAL_DND\" Activity Meter Database? [y/n] (Default n) > `tput sgr0`"
        read confirmDelAM
        if [ "$confirmDelAM" == "y" ];then
                echo "`tput setaf 2`echo \"delete from activity_meter.activity where msisdn = '$msisdnorig' and activity_name = 'SUBSCRIBER_EXTERNAL_DND';\" | mysql -u root`tput sgr0`"
                echo "delete from activity_meter.activity where msisdn = '$msisdnorig' and activity_name = 'SUBSCRIBER_EXTERNAL_DND';" | mysql -u root
                echo "------------------------------------------------------------------------------------------------------------------"
                checkAMDB
                isItToBeBounce=$(echo $subType | grep SUBSCRIBER_EXTERNAL_DND)
                if [ -z "$isItToBeBounce" ];then
                        echo "`tput setaf 6`Clean`tput sgr0` There is not`tput setaf 6` SUBSCRIBER_EXTERNAL_DND`tput sgr0` record in Activity Meter Database"
                        echo "------------------------------------------------------------------------------------------------------------------"
                fi
                printLog "Clean SUBSCRIBER_EXTERNAL_DND record in AM" "Do you wanna delele $msisdnorig SUBSCRIBER_EXTERNAL_DND Activity Meter Database? [y/n] (Default n) > " "$confirm"
        fi
else
        echo "`tput setaf 6`Clean`tput sgr0` There is not`tput setaf 6` SUBSCRIBER_EXTERNAL_DND`tput sgr0` record in Activity Meter Database"
fi
checkOfferPromotionDB
isItToBeBounce=$(echo $Offer | grep offerDefinitionId)
if [ ! -z "$isItToBeBounce" ];then
        echo -n "`tput setaf 3`Do you wanna delele $msisdnorig \"Offer\" record from promotion_brav1 Database? [y/n] (Default n) > `tput sgr0`"
        read confirmDelOffer
        if [ "$confirmDelOffer" == "y" ];then
                echo "`tput setaf 2`echo \"delete from promotion_brav1.Offer where msisdn = '$msisdnorig';\" | mysql -u root`tput sgr0`"
                echo "delete from promotion_brav1.Offer where msisdn = '$msisdnorig';" | mysql -u root
                echo "------------------------------------------------------------------------------------------------------------------"
                checkOfferPromotionDB
                isItToBeBounce=$(echo $Offer | grep offerDefinitionId)
                if [ -z "$isItToBeBounce" ];then
                        echo "`tput setaf 6`Clean`tput sgr0` There is not`tput setaf 6` Offer`tput sgr0` record in promotion_brav1 Database"
                        echo "------------------------------------------------------------------------------------------------------------------"
                        echo -en "\n`tput setaf 3`Wait 10 secs until SOM cache refreshes its data which is taken from promotion_brav1 Database. Note: If after tests, SIBB finds \"No Campaign\", please repeate test. Hopefully, SOM cache is refreshed by then * "
                        finishedprocessed="false"
                        a=0
                        while [ $a -lt 10 ]
                        do
                                sleep 1
                                if [ $a -eq 4 ];then
                                        echo -n "4secs * "
                                elif [ $a -eq 7 ];then
                                        echo -n "7secs * "
                                elif [ $a -eq 10 ];then
                                        echo -n "10secs * "
                                else
                                        echo -n "* "
                                fi
                                let a++
                        done
                        echo -n " Done. Lets continue`tput sgr0`"
                        echo ""
                        echo ""
                fi
        fi
        printLog "Clean Offer record in promotion_brav1.Offer" "Do you wanna delele $msisdnorig Offer record from promotion_brav1 Database? [y/n] (Default n) > " "$confirm"
else
        echo "`tput setaf 6`Clean`tput sgr0` There is not`tput setaf 6` Offer `tput sgr0`record in promotion_brav1 Database"
        echo "------------------------------------------------------------------------------------------------------------------"
        echo ""
fi
        echo -n "`tput setaf 3`Do you wanna drop it in /tango/data/ingest/businessconnect/ [y/n] > `tput sgr0`"
read confirm
if [ "$confirm" == "y" ] || [ -z "$confirm" ];then
        if [ -z "$confirm" ];then
                printLog "Drop feedfile" "Do you wanna drop it in /tango/data/ingest/businessconnect/ [y/n] > " "Empty, which means drop feefile"
        else
                printLog "Drop feedfile" "Do you wanna drop it in /tango/data/ingest/businessconnect/ [y/n] > " "$confirm"
        fi
        echo "------------------------------------------------------------------------------------------------------------------"
        cp $feedfile /tango/data/ingest/businessconnect/
        chmod 777 /tango/data/ingest/businessconnect/$feedfile
        echo -e "\n\n\n`tput setaf 2`================================================= Test Begin ==================================================\n\n"
        echo -en "\n`tput setaf 3`Wait until LOGSTASH processes $feedfile and triggers BC SIBB API * "
        finishedprocessed="false"
        cerosMsisdn=$(echo "$msisdnorig" | sed 's/./&0/g' | sed 's/.$//' | head -1)
        a=0
        isSICDRsReady=$(grep $cerosMsisdn /tango/data/cdr/active_BC_SIBB.cdr | wc -l)
        while [ "$isSICDRsReady" == "0" ]
        do
                isSICDRsReady=$(grep $cerosMsisdn /tango/data/cdr/active_BC_SIBB.cdr | wc -l)
                sleep 1
                echo -n "* "
                if [ $a -eq 30 -o $a -eq 60 -o $a -eq 120 -o $a -eq 180 -o $a -eq 240 ];then
                        echo -n "No CDRs in /tango/data/cdr/active_BC_SIBB.cdr yet "
                fi
                let a++
        done
        echo -n " Done. `tput sgr0`Time = $a secs."
        echo ""
        echo "------------------------------------------------------------------------------------------------------------------`tput setaf 2`"
        echo "`tput setaf 3`ls -atlr /tango/data/ingest/businessconnect/ | grep $newfeedfile `tput sgr0`"
        ls -atlr /tango/data/ingest/businessconnect/ | grep "$newfeedfile"
        showBCcdrs
        sleep 10
        checkAMDB_RTE1RTE2
        checkAMDB
        isItToBeBounce=$(echo $subType | grep subscriberInfo)
        if [ -z "$isItToBeBounce" ];then
                echo "`tput setaf 6`Clean`tput setaf 3` There is not`tput setaf 6` subscriberInfo`tput setaf 3` record in Activity Meter Database`tput sgr0`"
        fi
        isItToBeBounce=$(echo $subType | grep SUBSCRIBER_LOCATION)
        if [ -z "$isItToBeBounce" ];then
                echo "`tput setaf 6`Clean`tput setaf 3` There is not`tput setaf 6` SUBSCRIBER_LOCATION`tput setaf 3` record in Activity Meter Database`tput sgr0`"
        fi
        isItToBeBounce=$(echo $subType | grep offerId)
        if [ -z "$isItToBeBounce" ];then
                echo "`tput setaf 6`Clean`tput setaf 3` There is not`tput setaf 6` TOKEN`tput setaf 3` in Activity Meter Database`tput sgr0`"
        fi
        checkOfferPromotionDB
        isItToBeBounce=$(echo $Offer | grep offerDefinitionId)
        if [ -z "$isItToBeBounce" ];then
                echo "`tput setaf 6`Clean`tput setaf 3` There is not`tput setaf 6` Offer`tput setaf 3` record in promotion_brav1 Database`tput sgr0`"
        fi
        getSIBBlogs
        showSOMcdrs
        finishedprocessed="false"
        showUNScdrs
        showHRGcdrs
        showBCPortalURL
else
        echo "Nothing done, Bye"
fi

fi