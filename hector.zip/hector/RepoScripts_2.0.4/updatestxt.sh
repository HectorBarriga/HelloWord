#!/bin/bash

echo "`tput setaf 1` This script will not run commands. It will only show the commands that need to be run. So, copy them and paste them to run them`tput sgr0`"
echo -n "Enter new lines [`tput setaf 3`For emtpy lines, use TWO \"\\\\\" and add \"n\". Example: xxx`tput setaf 2`\\\\n`tput setaf 3`xxxx`tput sgr0`] > "
read lines
echo -n "Enter file [Include all path] > "
read file
i=0

while(true)
do
        echo -n "Enter node [To include all nodes from /etc/hosts, enter All] [To finish not enter anything] > "
        read readin
        read=${readin,,}
        if [ "$read" == "all" ];then
                getHosts=$(cat /etc/hosts | egrep "#" | egrep tango | cut -d"-" -f2 | tr -d '')
                for host in $getHosts
                do
                        node[$i]=$host
                        let i++
                done
                break
        else
                node[$i]=$read
                let i++
                if [ -z "$read" ]; then
                        break
                fi
        fi
done

nodearraylength=${#node[@]}
let nodearraylength--
for (( j=0;j<$nodearraylength;j++))
do
        echo "echo -e \"$lines\" | ssh `tput setaf 2`${node[$j]}`tput sgr0` \"cat >> $file\";"
done