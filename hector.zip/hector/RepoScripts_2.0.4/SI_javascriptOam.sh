#!/bin/bash

function help()
{
        echo "
        Usage: SI_javascriptOam.sh

        This sh script is to unlock or modify SI JavaScripts in MySQL pmsdb database

        Version:     0.1.0
        Author:      Hector Barriga
        Copyright (c) Tango Telecom 2023

               Options:

               -h <help>             Show help

               -u <unlock JS>        Set JS name that will be unlocked

               -d <pmsdb database>   PMI database. Default = pmsdb_production

               -r <Replace JS name>  Set original JS name here

               -n <New JS name>      Set new JS name here. -r flag is mandatory

               Examples:

               - SI_javascriptOam.sh -u defaultValues
                 It will unlock defaultValues JavaScript in pmsdb_production.ussd_script_expression

               - SI_javascriptOam.sh -r stringToJsonV1 -n stringToJsonV2 -d pmsdb_development
                 It will replace stringToJsonV1 with stringToJsonV2 in pmsdb_development.ussd_script_expression
                 "
}

while getopts u:d:r:n:h option;
do
        case $option in
                u) JSname=$OPTARG;;
                d) pmsdb=$OPTARG;;
                r) origJSname=$OPTARG;;
                n) newJSname=$OPTARG;;
                h) help;h="true";;
        esac
done

if [ "$h" != "true" ];then

if [ -z "$pmsdb" ];then
        pmsdb="pmsdb_production"
fi
if [ ! -z "$JSname" ];then
        getJSid=$(echo "select id from $pmsdb.ussd_script_expression where name = '$JSname';" | mysql -u root | egrep -v id)
        echo "`tput setaf 3`echo \"update $pmsdb.ussd_script_expression set lockdown_enabled = b'0' where id = $getJSid;\" | mysql -u root`tput sgr0`"
        echo "update $pmsdb.ussd_script_expression set lockdown_enabled = b'0' where id = $getJSid;" | mysql -u root
elif [ ! -z "$origJSname"  -a ! -z "$newJSname" ];then
        getJSid=$(echo "select id from $pmsdb.ussd_script_expression where name = '$origJSname';" | mysql -u root | egrep -v id)
        getOrigJSinputs=$(echo "select functionPrototype from $pmsdb.ussd_script_expression where id = $getJSid;" | mysql -u root | egrep -v functionPrototype | cut -d'(' -f2 | cut -d')' -f 1)
        echo "`tput setaf 3`echo \"update $pmsdb.ussd_script_expression set functionPrototype = 'function $newJSname($getOrigJSinputs) {' where id = $getJSid;\" | mysql -u root`tput sgr0`"
        echo "update $pmsdb.ussd_script_expression set functionPrototype = 'function $newJSname($getOrigJSinputs) {' where id = $getJSid;" | mysql -u root
        echo "`tput setaf 3`echo \"update $pmsdb.ussd_script_expression set name = '$newJSname' where id = $getJSid;\" | mysql -u root`tput sgr0`"
        echo "update $pmsdb.ussd_script_expression set name = '$newJSname' where id = $getJSid;" | mysql -u root
elif [ -z "$origJSname" -a ! -z "$newJSname"] || [ ! -z "$origJSname" -a  -z "$newJSname" ];then
        echo -e "\n`tput setaf 1`If you wish to replace a JavaScript name, you must use both -r && -n flags`tput sgr0`\n"
        help
else
        echo -e "\n`tput setaf 1`You are not using flags correctly.`tput sgr0`\n"
        help
fi
fi