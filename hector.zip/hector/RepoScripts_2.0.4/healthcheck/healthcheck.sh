#!/bin/bash
##############################################################################
# Filename:    healthcheck.sh
# Revision:    0.1.0
# Author:      Hector Barriga
#
# Jiras:
# CO Scripts:  COSC-106
# CO Internal: COIT-18730
#
# This sh script is to run a local health check to examine:
# 1. Tango Processes
# 2. Logical IPs
# 3. Disk Space
# 4. Memmory and CPU Usage
# 5. BULK_IMPORT
# 6. FTP CDRs
# 7. Verbose Mode
# 8. Traffic CDR counters
# 9. Curl Health Queries
# 10. Tango Alarms
# 11. pm.log Exceptions
# 12. Tomcat Server Status
# 13. MySQL and its replication
# 14. Elastic Search
# 15. Sigtran Associations
# 16. SMSC Stores
# 17. SMPP binds
# 18. Systemctl status (3rd party services)
# 19. Telnet servers,processes
# 20. Administrative Health Commands
#
# This sh script is mainly used for Tango  CO internal  monitoring
# Copyright (c) Tango Telecom 2018
#
# All rights reserved.
# This document contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or
# in part is expressly prohibited, except as may be specifically
# authorized by prior written agreement or permission of Tango Telecom.
##############################################################################
# version 0.1.0 - First version
# version 0.2.0 - Make CDR count faster
# version 0.2.1 - Add -A flag
# version 0.2.1 - Add -RHEL8 commands
version="0.3.1"
#
##############################################################################
getTERM=$(echo $TERM)
if [ "$getTERM" != "xterm" ];then
        export TERM=xterm
fi
if [ ! -d /tango/logs/COSTAFF/trash/ ];then
        mkdir /tango/logs/COSTAFF/trash/
fi
DIR=$(echo "`dirname $0`")
config_file=$DIR/healthcheck.cfg
hostname=$(hostname)
yesterdayExt=$( perl -e '@d=localtime time()-84600; printf "%4d%02d%02d\n", $d[5]+1900,$d[4]+1,$d[3]')
todayExt=$( perl -e '@d=localtime time(); printf "%4d%02d%02d\n", $d[5]+1900,$d[4]+1,$d[3]')
HH=$( perl -e '@d=localtime time(); printf "%02d\n", $d[2]')
DD=$( perl -e '@d=localtime time(); printf "%02d\n", $d[3]')
pmlogs_todayDD=$( perl -e '@d=localtime time(); printf "%4d-%02d-%02d\n", $d[5]+1900,$d[4]+1,$d[3]')
dday=$(date +%b)

#  Script name: healthcheck
#  This bash script displays a full status of all main machine systems
#  Version: 0.2.0
#
#  First Version(HB for Tango, 17_April 2014)
#
#  Copyright (c) Tango Telecom 2014
#
#  All rights reserved.
#  This document contains confidential and proprietary information of
#  Tango Telecom and any reproduction, disclosure, or use in whole or
#  in part is expressly prohibited, except as may be specifically
#  authorized by prior written agreement or permission of Tango
#  Telecom.

# Subroutines
Spawn_Processes_Status()
{
mv $DIR/$tempFile /tango/logs/COSTAFF/trash/
isRHEL8=$(cat /etc/redhat-release  | grep "Linux release 8" | wc -l)
if [ "$isRHEL8" == "1" ];then
        isPortListen=$(netstat -an | grep "0.0.0.0:$1" | grep LISTEN | grep tcp 2> /dev/null &)
else
        isPortListen=$(ncat -w 1 -zv $hostname $1 </dev/null > $DIR/$tempFile)
fi
if [ ! -z "$isPortListen" ];then
echo "#!/bin/bash
expect <<'EOF'
spawn telnet 0 $1
expect \"assistance.\"
send \"\r\"
expect \"mon>\"
send \"r 0;\r\"
send \"\r\"
expect \"mon>\"
send \"a $2;s $3;\r\"
expect \"mon>\"
send \"r 0;\r\"
send \"\r\"
expect \"mon>\"
send \"quit\r\"
EOF" > $DIR/.Spawn_Processes_Status
chmod 775 $DIR/.Spawn_Processes_Status
$DIR/.Spawn_Processes_Status | tee $DIR/$tempFile &>/dev/null &
sleep 1
patternCount=$(cat $DIR/$tempFile | awk '/'"$4"'/ || /'"$5"'/' | egrep -v "System Id" | wc -l)
string_patternCount=$(cat $DIR/$tempFile | awk '/'"$4"'/ || /'"$5"'/' | egrep -v "System Id")
else
patternCount="-1"
string_patternCount="Connection to port $1 is refused"
fi
}

########################## Administrative Health Commands ##########################
adminCommandsSub()
{
if [ ! -z "$administrative_health_command_list" ];then
        countTotalAdministrativeHealthCommand=$(cat $administrative_health_command_list | cut -d"#" -f 1 | grep shell_command_Enable | wc -l)
else
        countTotalAdministrativeHealthCommand=0
fi
if [ $countTotalAdministrativeHealthCommand -eq 0 ];then if [ "$verbose" == "true" ];then echo -e ""$yellow"\n------ Administrative Health Commands ------"$reset"";echo "["$pink"INFO"$reset"] "$pink"There is not any parameter "$reset"shell_command_x"$pink" in administrative_health_command_list.cfg (x is the instance number). It's ok, healthcheck will not monitor any administrative command and continue"$reset"";fi;else
        printTittleAdministrativeHealthCommand="noyet"
        for (( j=0; j<$countTotalAdministrativeHealthCommand;j++))
        do
            eval shell_commandEnable=( \${shell_command_Enable_$j[@]} )
            eval shell_commandgravity=( \${shell_command_gravity_$j[@]} )
            eval shell_command=( \${shell_command_$j[@]} )
            eval shell_commandresponse_1=( \${shell_command_response_1_$j[@]} )
            eval shell_commandresponse_2=( \${shell_command_response_2_$j[@]} )
            eval shell_commandCase=( \${shell_command_Case_$j[@]} )
            eval shell_commandMinThreshold=( \${shell_command_Min_Threshold_$j[@]} )
            eval shell_commandMaxThreshold=( \${shell_command_Max_Threshold_$j[@]} )
            eval shell_commandMessage=( \${shell_command_Message_$j[@]} )
            eval shell_commandsupport=( \${shell_command_support_$j[@]} )
            shellcommandEnable=$(echo ${shell_commandEnable[@]})
            shellcommandgravity=$(echo ${shell_commandgravity[@]})
            shellcommand=$(echo ${shell_command[@]})
            shellcommandresponse1=$(echo ${shell_commandresponse_1[@]})
            shellcommandresponse2=$(echo ${shell_commandresponse_2[@]})
            shellcommandCaseP=$(echo ${shell_commandCase[@]});shellcommandCase=$(echo $shellcommandCaseP | awk '{print toupper($0)}')
            shellcommandMinThreshold=$(echo ${shell_commandMinThreshold[@]})
            shellcommandMaxThreshold=$(echo ${shell_commandMaxThreshold[@]})
            shellcommandMessage=$(echo ${shell_commandMessage[@]})
            shellcommandsupport=$(echo ${shell_commandsupport[@]})
            if [ $shellcommandEnable -eq 1 ]; then
                if [ "$printTittleAdministrativeHealthCommand" == "noyet" ];then echo -e ""$yellow"\n------ Administrative Health Commands ------"$reset"";printTittleAdministrativeHealthCommand="done";fi
                shellCommandResponse=$(eval "$shellcommand" | grep "$shellcommandresponse1" | grep "$shellcommandresponse2")
                getFirstWordshellCommandResponse=$(echo "$shellCommandResponse" | head -1 | awk "{print \$1}")
                if [ ! -z "$shellcommandMinThreshold" ] && [ -z "$shellcommandMaxThreshold" ] && [ ! -z "${getFirstWordshellCommandResponse##*[!0-9]*}" ];then
                        if [ $getFirstWordshellCommandResponse -gt $shellcommandMinThreshold ];then
                                echo "["$green"OK"$reset"] "$bold"$shellcommandMessage "$reset"is greater than Min Threshold of $shellcommandMinThreshold"
                        elif [ $getFirstWordshellCommandResponse -eq $shellcommandMinThreshold ];then
                                echo "["$green"OK"$reset"] "$bold"$shellcommandMessage "$reset"is equal to $shellcommandMinThreshold Threshold"
                        elif [ $getFirstWordshellCommandResponse -lt $shellcommandMinThreshold ];then
                                if [ "$shellcommandgravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                        echo "["$green"$shellcommandgravity"$reset"] "$bold"$shellcommandMessage "$reset"is less than the minimum threshold of $shellcommandMinThreshold"
                                elif [ "$shellcommandgravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                        echo "["$pink"$shellcommandgravity"$reset"] "$bold"$shellcommandMessage "$reset$pink"is less than the minimum threshold of $shellcommandMinThreshold"$reset""
                                else
                                        echo "["$red"$shellcommandgravity"$reset"] "$bold"$shellcommandMessage "$reset$red"is less than the minimum threshold of $shellcommandMinThreshold"$reset""
                                fi
                        fi
                elif [ -z "$shellcommandMinThreshold" ] && [ ! -z "$shellcommandMaxThreshold" ] && [ ! -z "${getFirstWordshellCommandResponse##*[!0-9]*}" ];then
                        if [ $getFirstWordshellCommandResponse -lt $shellcommandMaxThreshold ];then
                                echo "["$green"OK"$reset"] "$bold"$shellcommandMessage "$reset"is less than Max Threshold of $shellcommandMaxThreshold"
                        elif [ $getFirstWordshellCommandResponse -eq $shellcommandMaxThreshold ];then
                                echo "["$green"OK"$reset"] "$bold"$shellcommandMessage "$reset"is equal to $shellcommandMaxThreshold Threshold"
                        elif [ $getFirstWordshellCommandResponse -gt $shellcommandMaxThreshold ];then
                                if [ "$shellcommandgravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                        echo "["$green"$shellcommandgravity"$reset"] "$bold"$shellcommandMessage "$reset"is greater than the maximum threshold of $shellcommandMaxThreshold"
                                elif [ "$shellcommandgravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                        echo "["$pink"$shellcommandgravity"$reset"] "$bold"$shellcommandMessage "$reset$pink"is greater than the maximum threshold of $shellcommandMaxThreshold"$reset""
                                else
                                        echo "["$red"$shellcommandgravity"$reset"] "$bold"$shellcommandMessage "$reset$red"is greater than the maximum threshold of $shellcommandMaxThreshold"$reset""
                                fi
                        fi
                elif [ ! -z "$shellcommandMinThreshold" ] && [ ! -z "$shellcommandMaxThreshold" ] && [ ! -z "${getFirstWordshellCommandResponse##*[!0-9]*}" ];then
                        if [ $getFirstWordshellCommandResponse -le $shellcommandMaxThreshold ] && [ $getFirstWordshellCommandResponse -ge $shellcommandMinThreshold ];then
                                echo "["$green"OK"$reset"] "$bold"$shellcommandMessage "$reset"is between Max and Min Thresholds [$shellcommandMinThreshold - $shellcommandMaxThreshold]"
                        elif [ $getFirstWordshellCommandResponse -gt $shellcommandMaxThreshold ];then
                                if [ "$shellcommandgravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                        echo "["$green"$shellcommandgravity"$reset"] "$bold"$shellcommandMessage "$reset"is greater than the minimum threshold of $shellcommandMaxThreshold"
                                elif [ "$shellcommandgravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                        echo "["$pink"$shellcommandgravity"$reset"] "$bold"$shellcommandMessage "$reset$pink"is greater than the maximum threshold of $shellcommandMaxThreshold"$reset""
                                else
                                        echo "["$red"$shellcommandgravity"$reset"] "$bold"$shellcommandMessage "$reset$red"is greater than the maximum threshold of $shellcommandMaxThreshold"$reset""
                                fi
                        elif [ $getFirstWordshellCommandResponse -lt $shellcommandMinThreshold ];then
                                if [ "$shellcommandgravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                        echo "["$green"$shellcommandgravity"$reset"] "$bold"$shellcommandMessage "$reset"is less than the minimum threshold of $shellcommandMinThreshold"
                                elif [ "$shellcommandgravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                        echo "["$pink"$shellcommandgravity"$reset"] "$bold"$shellcommandMessage "$reset$pink"is less than the minimum threshold of $shellcommandMinThreshold"$reset""
                                else
                                        echo "["$red"$shellcommandgravity"$reset"] "$bold"$shellcommandMessage "$reset$red"is less than the minimum threshold of $shellcommandMinThreshold"$reset""
                                fi
                        fi
                else
                        if [ ! -z "$shellcommandresponse1" ] && [ ! -z "$shellcommandresponse2" ];then
                                printShellcommandresponse="\"$shellcommandresponse1\" and \"$shellcommandresponse2\""
                        elif [ ! -z "$shellcommandresponse1" ] && [ -z "$shellcommandresponse2" ];then
                                printShellcommandresponse="\"$shellcommandresponse1\""
                        elif [ -z "$shellcommandresponse1" ] && [ ! -z "$shellcommandresponse2" ];then
                                printShellcommandresponse="\"$shellcommandresponse2\""
                        else
                                printShellcommandresponse=""
                        fi
                        if [ "$shellcommandCase" == "UNEXPECTED" ];then
                                printShellcommandErrorMessage="The administrative health command \"$shellcommand\" is showing NOT expected $printShellcommandresponse in its response"
                        else
                                printShellcommandErrorMessage="The administrative health command \"$shellcommand\" is expecting $printShellcommandresponse in its response"
                        fi
                        if [ ! -z "$shellCommandResponse" -a "$shellcommandCase" == "EXPECTED" ] || [ -z "$shellCommandResponse" -a "$shellcommandCase" == "UNEXPECTED" ];then
                                echo "["$green"OK"$reset"] "$bold"$shellcommandMessage"$reset" is healthy"
                        elif [ ! -z "$shellCommandResponse" -a "$shellcommandCase" == "REPORT" ];then
                                echo "["$green"OK"$reset"] "$bold"$shellcommandMessage"$reset" EQUALS TO $shellCommandResponse"
                        else
                                if [ "$shellcommandgravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                        echo "["$green"$shellcommandgravity"$reset"] "$bold"$shellcommandMessage = "$reset"$printShellcommandErrorMessage"
                                elif [ "$shellcommandgravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                        echo "["$pink"$shellcommandgravity"$reset"] "$bold"$shellcommandMessage = "$reset$pink"$printShellcommandErrorMessage"$reset
                                else
                                        echo "["$red"$shellcommandgravity"$reset"] "$bold"$shellcommandMessage = "$reset$red"$printShellcommandErrorMessage"$reset
                                fi

                        fi

                fi
                if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$shellcommandsupport";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                if [ "$verbose" == "true" ];then echo ""$blue"TEST --> Run as Tango user:   $shellcommand"$reset"";fi
            fi
        done
fi
}

########################## CDRs counters ################################
CDRsCountersSub()
{
if [ ! -z "$CDR_counters_list" ];then
        countTotalCDRcounts=$(cat $CDR_counters_list | cut -d"#" -f 1 | grep count_CDR_Enable | wc -l)
else
        countTotalCDRcounts=0
fi
if [ $countTotalCDRcounts -eq 0 ];then if [ "$verbose" == "true" ];then echo -e ""$yellow"\n---------- Traffic CDR counters ------------"$reset"";echo "["$pink"INFO"$reset"] "$pink"There is not any parameter "$reset"count_CDR_Enable_x"$pink" in CDR_counters_list.cfg (x is the instance number). It's ok, healthcheck will not count and monitor any CDRs"$reset"";fi;else
        printTittleCDR="noyet"
        for (( j=0; j<$countTotalCDRcounts;j++))
        do
            eval count_CDREnable=( \${count_CDR_Enable_$j[@]} )
            eval count_CDRID=( \${count_CDR_ID_$j[@]} )
            eval count_CDRgravity=( \${count_CDR_gravity_$j[@]} )
            eval count_CDRRollOverDir=( \${count_CDR_RollOver_Dir_$j[@]} )
            eval count_CDRRollOverFileprefix=( \${count_CDR_RollOver_File_prefix_$j[@]} )
            eval count_CDRRollOverSecondaryHost=( \${count_CDR_RollOver_Secondary_Host_$j[@]} )
            eval count_CDRRollOverTertiaryHost=( \${count_CDR_RollOver_Tertiary_Host_$j[@]} )
            eval count_CDRMinimumThreshold=( \${count_CDR_Minimum_Threshold_$j[@]} )
            eval count_CDRTimeWindow=( \${count_CDR_TimeWindow_$j[@]} )
            eval count_CDRIgnoreFields=( \${count_CDR_IgnoreFields_$j[@]} )
            eval count_CDRfield1=( \${count_CDR_field_1_$j[@]} )
            eval count_CDRpattern1=( \${count_CDR_pattern_1_$j[@]} )
            eval count_CDRfield2=( \${count_CDR_field_2_$j[@]} )
            eval count_CDRpattern2=( \${count_CDR_pattern_2_$j[@]} )
            eval count_CDRfield3=( \${count_CDR_field_3_$j[@]} )
            eval count_CDRpattern3=( \${count_CDR_pattern_3_$j[@]} )
            eval count_CDRfield4=( \${count_CDR_field_4_$j[@]} )
            eval count_CDRpattern4=( \${count_CDR_pattern_4_$j[@]} )
            eval count_CDRfield5=( \${count_CDR_field_5_$j[@]} )
            eval count_CDRpattern5=( \${count_CDR_pattern_5_$j[@]} )
            eval count_CDRfield6=( \${count_CDR_field_6_$j[@]} )
            eval count_CDRpattern6=( \${count_CDR_pattern_6_$j[@]} )
            eval count_CDRfield7=( \${count_CDR_field_7_$j[@]} )
            eval count_CDRpattern7=( \${count_CDR_pattern_7_$j[@]} )
            eval count_CDRfield8=( \${count_CDR_field_8_$j[@]} )
            eval count_CDRpattern8=( \${count_CDR_pattern_8_$j[@]} )
            eval count_CDRStatusMessage=( \${count_CDR_StatusMessage_$j[@]} )
            eval count_CDRsupport=( \${count_CDR_support_$j[@]} )
            eval count_CDRNoContain1=( \${count_CDR_NoContain_1_$j[@]} )
            eval count_CDRNoContain2=( \${count_CDR_NoContain_2_$j[@]} )
            countCDREnable=$(echo ${count_CDREnable[@]})
            countCDRID=$(echo ${count_CDRID[@]})
            countCDRgravity=$(echo ${count_CDRgravity[@]})
            countCDRRollOverDir=$(echo ${count_CDRRollOverDir[@]})
            countCDRRollOverFileprefix=$(echo ${count_CDRRollOverFileprefix[@]})
            countCDRRollOverSecondaryHost=$(echo ${count_CDRRollOverSecondaryHost[@]})
            countCDRRollOverTertiaryHost=$(echo ${count_CDRRollOverTertiaryHost[@]})
            countCDRMinimumThreshold=$(echo ${count_CDRMinimumThreshold[@]});if [ -z "$countCDRMinimumThreshold" ];then countCDRMinimumThreshold=0;fi
            countCDRTimeWindow=$(echo ${count_CDRTimeWindow[@]});if [ -z "$countCDRTimeWindow" ];then countCDRTimeWindow="hour";fi
            countCDRIgnoreFields=$(echo ${count_CDRIgnoreFields[@]});if [ -z "$countCDRIgnoreFields" ];then countCDRIgnoreFields="no";fi
            countCDRfield1=$(echo ${count_CDRfield1[@]});if [ -z "$countCDRfield1" ];then countCDRfield1="2";fi
            countCDRpattern1=$(echo ${count_CDRpattern1[@]});if [ -z "$countCDRpattern1" ];then countCDRpattern1=$countCDRID;fi
            countCDRfield2=$(echo ${count_CDRfield2[@]});if [ -z "$countCDRfield2" ];then countCDRfield2="2";fi
            countCDRpattern2=$(echo ${count_CDRpattern2[@]});if [ -z "$countCDRpattern2" ];then countCDRpattern2=$countCDRID;fi
            countCDRfield3=$(echo ${count_CDRfield3[@]});if [ -z "$countCDRfield3" ];then countCDRfield3="2";fi
            countCDRpattern3=$(echo ${count_CDRpattern3[@]});if [ -z "$countCDRpattern3" ];then countCDRpattern3=$countCDRID;fi
            countCDRfield4=$(echo ${count_CDRfield4[@]});if [ -z "$countCDRfield4" ];then countCDRfield4="2";fi
            countCDRpattern4=$(echo ${count_CDRpattern4[@]});if [ -z "$countCDRpattern4" ];then countCDRpattern4=$countCDRID;fi
            countCDRfield5=$(echo ${count_CDRfield5[@]});if [ -z "$countCDRfield5" ];then countCDRfield5="2";fi
            countCDRpattern5=$(echo ${count_CDRpattern5[@]});if [ -z "$countCDRpattern5" ];then countCDRpattern5=$countCDRID;fi
            countCDRfield6=$(echo ${count_CDRfield6[@]});if [ -z "$countCDRfield6" ];then countCDRfield6="2";fi
            countCDRpattern6=$(echo ${count_CDRpattern6[@]});if [ -z "$countCDRpattern6" ];then countCDRpattern6=$countCDRID;fi
            countCDRfield7=$(echo ${count_CDRfield7[@]});if [ -z "$countCDRfield7" ];then countCDRfield7="2";fi
            countCDRpattern7=$(echo ${count_CDRpattern7[@]});if [ -z "$countCDRpattern7" ];then countCDRpattern7=$countCDRID;fi
            countCDRfield8=$(echo ${count_CDRfield8[@]});if [ -z "$countCDRfield8" ];then countCDRfield8="2";fi
            countCDRpattern8=$(echo ${count_CDRpattern8[@]});if [ -z "$countCDRpattern8" ];then countCDRpattern8=$countCDRID;fi
            countCDRStatusMessage=$(echo ${count_CDRStatusMessage[@]})
            countCDRsupport=$(echo ${count_CDRsupport[@]});if [ -z "$countCDRpattern" ];then countCDRpattern=$countCDRID;fi
            countCDRNoContain1=$(echo ${count_CDRNoContain1[@]});if [ -z "$countCDRNoContain1" ];then countCDRNoContain1="NotUsed";fi
            countCDRNoContain2=$(echo ${count_CDRNoContain2[@]});if [ -z "$countCDRNoContain2" ];then countCDRNoContain2="NotUsed";fi
            if [ $countCDREnable -eq 1 ]; then
                if [ "$printTittleCDR" == "noyet" ];then echo -e ""$yellow"\n---------- Traffic CDR counters ------------"$reset"";printTittleCDR="done";fi
                if [ -z "$countCDRgravity" ];then countCDRgravity="ALERT";else countCDRgravity=$(echo $countCDRgravity | awk '{print toupper($0)}');fi
                cdrTotalPrimary=0
                cdrTotalSecondary=0
                cdrTotalTertiary=0
                pmam=''
                if [ "$countCDRTimeWindow" == "day" ] || [ "$countCDRTimeWindow" == "Day" ] || [ "$countCDRTimeWindow" == "DAY" ];then
                        countCDRRollOverDircountCDRRollOverFile="$countCDRRollOverDir$countCDRRollOverFileprefix*.$todayExt*"
                elif [ "$countCDRTimeWindow" == "10min" ] || [ "$countCDRTimeWindow" == "10" ] || [ "$countCDRTimeWindow" == "10Min" ] || [ "$countCDRTimeWindow" == "10MIN" ];then
                        MM=$( perl -e '@d=localtime time(); printf "%02d\n", $d[1]')
                        MMdigit2=${MM:0:1}
                        MMdigit1=${MM:1:1}
                        if [ "$MMdigit1" == "0" ] || [ "$MMdigit1" == "1" ] || [ "$MMdigit1" == "2" ] || [ "$MMdigit1" == "3" ] || [ "$MMdigit1" == "4" ] || [ "$MMdigit1" == "5" ];then
                                todayExt_HHDD=$( perl -e '@d=localtime time()-600; printf "%4d%02d%02d_%02d%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1]')
                                todayExt_HHDDtrimmed=$(echo $todayExt_HHDD | sed 's/.$//')
                                HHhh=$( perl -e '@d=localtime time()-600; printf "%02d\n", $d[2]')
                                HHhhtrimmed=$( perl -e '@d=localtime time()-600; printf "%02d:%02d\n", $d[2],$d[1]' | sed 's/.$//')
                                HHh="between $HHhhtrimmed""0:00 and $HHhh:$MMdigit2""0"
                        else
                                todayExt_HHDDtrimmed="$todayExt""_""$HH$MMdigit2"
                                HHhh=$( perl -e '@d=localtime time(); printf "%02d\n", $d[2]')
                                HHh="since $HHhh:$MMdigit2""0"
                        fi
                        countCDRRollOverDircountCDRRollOverFile="$countCDRRollOverDir$countCDRRollOverFileprefix*.$todayExt_HHDDtrimmed*"

                        if [ "$HHhh" == "00" ] || [ "$HHhh" == "01" ] || [ "$HHhh" == "02" ] || [ "$HHhh" == "03" ] || [ "$HHhh" == "04" ] || [ "$HHhh" == "05" ] || [ "$HHhh" == "06" ] || [ "$HHhh" == "07" ] || [ "$HHhh" == "08" ] || [ "$HHhh" == "09" ] || [ "$HHhh" == "10" ] || [ "$HHhh" == "11" ];then
                                pmam="am"
                        else
                                pmam="pm"
                        fi
                else
                        MM=$( perl -e '@d=localtime time(); printf "%02d\n", $d[1]')
                        if [ "$MM" == "00" ] || [ "$MM" == "01" ] || [ "$MM" == "02" ] || [ "$MM" == "03" ] || [ "$MM" == "04" ] || [ "$MM" == "05" ];then
                                todayExt_HH=$( perl -e '@d=localtime time()-3600; printf "%4d%02d%02d_%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2]')
                                HHhh=$( perl -e '@d=localtime time()-3600; printf "%02d\n", $d[2]')
                                HHh="from $HHhh"
                        else
                                todayExt_HH="$todayExt""_""$HH"
                                HHhh=$HH
                                HHh="since $HHhh"
                        fi
                        countCDRRollOverDircountCDRRollOverFile="$countCDRRollOverDir$countCDRRollOverFileprefix*.$todayExt_HH*"
                        if [ "$HHhh" == "00" ] || [ "$HHhh" == "01" ] || [ "$HHhh" == "02" ] || [ "$HHhh" == "03" ] || [ "$HHhh" == "04" ] || [ "$HHhh" == "05" ] || [ "$HHhh" == "06" ] || [ "$HHhh" == "07" ] || [ "$HHhh" == "08" ] || [ "$HHhh" == "09" ] || [ "$HHhh" == "10" ] || [ "$HHhh" == "11" ];then
                                pmam="am"
                        else
                                pmam="pm"
                        fi

                fi
                if [ "$countCDRIgnoreFields" == "False" ] || [ "$countCDRIgnoreFields" == "false" ] || [ "$countCDRIgnoreFields" == "no" ] || [ "$countCDRIgnoreFields" == "No" ];then
                        countCDRIgnoreFields="false"
                        if [ "$isRHEL8" == "1" ];then
                                cdrTotalPrimary=$(cat $countCDRRollOverDircountCDRRollOverFile | awk -F ',' -v "f1=${countCDRfield1}" -v p1="$countCDRpattern1" '$f1 == p1' | awk -F ',' -v "f2=${countCDRfield2}" -v p2="$countCDRpattern2" '$f2 == p2' | awk -F ',' -v "f3=${countCDRfield3}" -v p3="$countCDRpattern3" '$f3 == p3' | awk -F ',' -v "f4=${countCDRfield4}" -v p4="$countCDRpattern4" '$f4 == p4' | awk -F ',' -v "f5=${countCDRfield5}" -v p5="$countCDRpattern5" '$f5 == p5' | awk -F ',' -v "f6=${countCDRfield6}" -v p6="$countCDRpattern6" '$f6 == p6' | awk -F ',' -v "f7=${countCDRfield7}" -v p7="$countCDRpattern7" '$f7 == p7' | awk -F ',' -v "f8=${countCDRfield8}" -v p8="$countCDRpattern8" '$f8 == p8' | wc -l)
                                if [ ! -z "$countCDRRollOverSecondaryHost" ];then
                                        cdrTotalSecondary=$(ssh $countCDRRollOverSecondaryHost "cat $countCDRRollOverDircountCDRRollOverFile | awk -F ',' -v f1=${countCDRfield1} -v p1=$countCDRpattern1 '\$f1 == p1' | awk -F ',' -v f2=${countCDRfield2} -v p2=$countCDRpattern2 '\$f2 == p2' | awk -F ',' -v f3=${countCDRfield3} -v p3=$countCDRpattern3 '\$f3 == p3' | awk -F ',' -v f4=${countCDRfield4} -v p4=$countCDRpattern4 '\$f4 == p4' | awk -F ',' -v f5=${countCDRfield5} -v p5=$countCDRpattern5 '\$f5 == p5' | awk -F ',' -v f6=${countCDRfield6} -v p6=$countCDRpattern6 '\$f6 == p6' | awk -F ',' -v f7=${countCDRfield7} -v p7=$countCDRpattern7 '\$f7 == p7' | awk -F ',' -v f8=${countCDRfield8} -v p8=$countCDRpattern8 '\$f8 == p8'" | wc -l)
                                else
                                        cdrTotalSecondary=0
                                fi
                                if [ ! -z "$countCDRRollOverTertiaryHost" ];then
                                cdrTotalTertiary=$(ssh $countCDRRollOverTertiaryHost "cat $countCDRRollOverDircountCDRRollOverFile | awk -F ',' -v f1=${countCDRfield1} -v p1=$countCDRpattern1 '\$f1 == p1' | awk -F ',' -v f2=${countCDRfield2} -v p2=$countCDRpattern2 '\$f2 == p2' | awk -F ',' -v f3=${countCDRfield3} -v p3=$countCDRpattern3 '\$f3 == p3' | awk -F ',' -v f4=${countCDRfield4} -v p4=$countCDRpattern4 '\$f4 == p4' | awk -F ',' -v f5=${countCDRfield5} -v p5=$countCDRpattern5 '\$f5 == p5' | awk -F ',' -v f6=${countCDRfield6} -v p6=$countCDRpattern6 '\$f6 == p6' | awk -F ',' -v f7=${countCDRfield7} -v p7=$countCDRpattern7 '\$f7 == p7' | awk -F ',' -v f8=${countCDRfield8} -v p8=$countCDRpattern8 '\$f8 == p8'" | wc -l)
                                else
                                        cdrTotalTertiary=0
                                fi
                        else
                                cdrTotalPrimary=$(cat $countCDRRollOverDircountCDRRollOverFile | awk -F ',' -v "f1=${countCDRfield1}" -v p1="$countCDRpattern1" -v "f2=${countCDRfield2}" -v p2="$countCDRpattern2" -v "f3=${countCDRfield3}" -v p3="$countCDRpattern3" -v "f4=${countCDRfield4}" -v p4="$countCDRpattern4" -v "f5=${countCDRfield5}" -v p5="$countCDRpattern5" -v "f6=${countCDRfield6}" -v p6="$countCDRpattern6" -v "f7=${countCDRfield7}" -v p7="$countCDRpattern7" -v "f8=${countCDRfield8}" -v p8="$countCDRpattern8" '{if(f1=p1 || f2=p2 ||f3=p3 || f4=p4 || f5=p5 || f6=p6 || f7=p7 || f8=p8) print}' | wc -l)
                                if [ ! -z "$countCDRRollOverSecondaryHost" ];then
                                        cdrTotalSecondary=$(ssh $countCDRRollOverSecondaryHost "cat $countCDRRollOverDircountCDRRollOverFile | awk -F ',' -v f1=${countCDRfield1} -v p1=$countCDRpattern1 -v f2=${countCDRfield2} -v p2=$countCDRpattern2 -v f3=${countCDRfield3} -v p3=$countCDRpattern3 -v f4=${countCDRfield4} -v p4=$countCDRpattern4 -v f5=${countCDRfield5} -v p5=$countCDRpattern5 -v f6=${countCDRfield6} -v p6=$countCDRpattern6 -v f7=${countCDRfield7} -v p7=$countCDRpattern7 -v f8=${countCDRfield8} -v p8=$countCDRpattern8 '{if(\$f1 == p1 || \$f2 == p2 || \$f3 == p3 || \$f4 == p4 || \$f5 == p5 || \$f6 == p6 || \$f7 == p7 || \$f8 == p8) print}'" | wc -l)
                                else
                                        cdrTotalSecondary=0
                                fi
                                if [ ! -z "$countCDRRollOverTertiaryHost" ];then
                                cdrTotalTertiary=$(ssh $countCDRRollOverTertiaryHost "cat $countCDRRollOverDircountCDRRollOverFile | awk -F ',' -v f1=${countCDRfield1} -v p1=$countCDRpattern1 -v f2=${countCDRfield2} -v p2=$countCDRpattern2 -v f3=${countCDRfield3} -v p3=$countCDRpattern3 -v f4=${countCDRfield4} -v p4=$countCDRpattern4 -v f5=${countCDRfield5} -v p5=$countCDRpattern5 -v f6=${countCDRfield6} -v p6=$countCDRpattern6 -v f7=${countCDRfield7} -v p7=$countCDRpattern7 -v f8=${countCDRfield8} -v p8=$countCDRpattern8 '{if(\$f1 == p1 || \$f2 == p2 || \$f3 == p3 || \$f4 == p4 || \$f5 == p5 || \$f6 == p6 || \$f7 == p7 || \$f8 == p8) print}'" | wc -l)
                                else
                                        cdrTotalTertiary=0
                                fi
                        fi
                else
                        cdrTotalPrimary=$(cat $countCDRRollOverDircountCDRRollOverFile | grep "$countCDRpattern1" | grep "$countCDRpattern2" | grep "$countCDRpattern3" | grep "$countCDRpattern4" | grep "$countCDRpattern5" | grep "$countCDRpattern6" | grep "$countCDRpattern7" | grep "$countCDRpattern8" | egrep -v "$countCDRNoContain1" | egrep -v "$countCDRNoContain2" | wc -l)
                        test='cat '$countCDRRollOverDircountCDRRollOverFile' | grep "'$countCDRpattern1'" | grep "'$countCDRpattern2'" | grep "'$countCDRpattern3'" | grep "'$countCDRpattern4'" | grep "'$countCDRpattern5'" | grep "'$countCDRpattern6'" | grep "'$countCDRpattern7'" | grep "'$countCDRpattern8'" | egrep -v "'$countCDRNoContain1'" | egrep -v "'$countCDRNoContain2'" | wc -l'
                        if [ ! -z "$countCDRRollOverSecondaryHost" ];then
                                cdrTotalSecondary=$(ssh $countCDRRollOverSecondaryHost "cat $countCDRRollOverDircountCDRRollOverFile | grep '$countCDRpattern1' | grep '$countCDRpattern2' | grep '$countCDRpattern3' | grep '$countCDRpattern4' | grep '$countCDRpattern5' | grep '$countCDRpattern6' | grep '$countCDRpattern7' | grep '$countCDRpattern8'" | wc -l)
                                test2='    PLUS     ssh '$countCDRRollOverSecondaryHost' "cat '$countCDRRollOverDircountCDRRollOverFile' | grep '$countCDRpattern1' | grep '$countCDRpattern2' | grep '$countCDRpattern3' | grep '$countCDRpattern4' | grep '$countCDRpattern5' | grep '$countCDRpattern6' | grep '$countCDRpattern7' | grep '$countCDRpattern8'" | wc -l'
                        else
                                test2=''
                                cdrTotalSecondary=0
                        fi
                        if [ ! -z "$countCDRRollOverTertiaryHost" ];then
                                cdrTotalTertiary=$(ssh $countCDRRollOverTertiaryHost "cat $countCDRRollOverDircountCDRRollOverFile | grep '$countCDRpattern1' | grep '$countCDRpattern2' | grep '$countCDRpattern3' | grep '$countCDRpattern4' | grep '$countCDRpattern5' | grep '$countCDRpattern6' | grep '$countCDRpattern7' | grep '$countCDRpattern8'" | wc -l)
                                test3='    PLUS     ssh '$countCDRRollOverTertiaryHost' "cat '$countCDRRollOverDircountCDRRollOverFile' | grep '$countCDRpattern1' | grep '$countCDRpattern2' | grep '$countCDRpattern3' | grep '$countCDRpattern4' | grep '$countCDRpattern5' | grep '$countCDRpattern6' | grep '$countCDRpattern7' | grep '$countCDRpattern8'" | wc -l'
                        else
                                test3=''
                                cdrTotalTertiary=0
                        fi
                fi

                cdrTotal=$(($cdrTotalSecondary + $cdrTotalPrimary + $cdrTotalTertiary))
                if [ "$countCDRTimeWindow" == "day" ] || [ "$countCDRTimeWindow" == "Day" ] || [ "$countCDRTimeWindow" == "DAY" ];then
                        countCDRTimeWindowMessage="hits so far today"
                else
                        countCDRTimeWindowMessage="hits $HHh:00 $pmam"
                fi
                if [ $countCDRMinimumThreshold == "0" ];then
                        if [ $cdrTotal -gt $countCDRMinimumThreshold ];then
                                echo "["$green"OK"$reset"] "$bold"$countCDRStatusMessage = "$reset"$cdrTotal $countCDRTimeWindowMessage"
                        else
                                if [ "$countCDRgravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                        echo "["$green"$countCDRgravity"$reset"] "$bold"$countCDRStatusMessage = "$reset"$cdrTotal $countCDRTimeWindowMessage"
                                elif [ "$countCDRgravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                        echo "["$pink"$countCDRgravity"$reset"] $countCDRStatusMessage = "$pink"$cdrTotal $countCDRTimeWindowMessage"$reset""
                                else
                                        echo "["$red"$countCDRgravity"$reset"] $countCDRStatusMessage = "$red"$cdrTotal $countCDRTimeWindowMessage"$reset""
                                fi
                                if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$countCDRsupport";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                        fi
                else
                        if [ $cdrTotal -le $countCDRMinimumThreshold ];then
                                echo "["$green"OK"$reset"] "$bold"$countCDRStatusMessage = "$reset"$cdrTotal $countCDRTimeWindowMessage. Min threshold $countCDRMinimumThreshold"
                        else
                                if [ "$countCDRgravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                        echo "["$green"$countCDRgravity"$reset"] "$bold"$countCDRStatusMessage = "$reset"$cdrTotal $countCDRTimeWindowMessage . The minimum threshold of $countCDRMinimumThreshold has been reached"
                                elif [ "$countCDRgravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                        echo "["$pink"$countCDRgravity"$reset"] $countCDRStatusMessage = "$pink"$cdrTotal $countCDRTimeWindowMessage . The minimum threshold of $countCDRMinimumThreshold has been reached"$reset""
                                else
                                        echo "["$red"$countCDRgravity"$reset"] $countCDRStatusMessage = "$red"$cdrTotal $countCDRTimeWindowMessage . The minimum threshold of $countCDRMinimumThreshold has been reached"$reset""
                                fi
                                if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$countCDRsupport";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                        fi
                fi
                if [ "$verbose" == "true" ] && [ "$countCDRIgnoreFields" == "false" ];then
                        echo -e ""$blue"TEST --> There is not an easy command that can perform this CDR counting.\n         You can however gather $countCDRRollOverDircountCDRRollOverFile from $hostname $countCDRRollOverSecondaryHost $countCDRRollOverTertiaryHost and count CDRs that match the following conditions:"
                        if [ ! -z "$countCDRfield1" ] && [ ! -z "$countCDRpattern1" ];then echo "         Field $countCDRfield1 is equal to $countCDRpattern1";fi
                        if [ ! -z "$countCDRfield2" ] && [ ! -z "$countCDRpattern2" ];then echo "         Field $countCDRfield2 is equal to $countCDRpattern2";fi
                        if [ ! -z "$countCDRfield3" ] && [ ! -z "$countCDRpattern3" ];then echo "         Field $countCDRfield3 is equal to $countCDRpattern3";fi
                        if [ ! -z "$countCDRfield4" ] && [ ! -z "$countCDRpattern4" ];then echo "         Field $countCDRfield4 is equal to $countCDRpattern4";fi
                        if [ ! -z "$countCDRfield5" ] && [ ! -z "$countCDRpattern5" ];then echo "         Field $countCDRfield5 is equal to $countCDRpattern5";fi
                        if [ ! -z "$countCDRfield6" ] && [ ! -z "$countCDRpattern6" ];then echo "         Field $countCDRfield6 is equal to $countCDRpattern6";fi
                        if [ ! -z "$countCDRfield7" ] && [ ! -z "$countCDRpattern7" ];then echo "         Field $countCDRfield7 is equal to $countCDRpattern7";fi
                        if [ ! -z "$countCDRfield8" ] && [ ! -z "$countCDRpattern8" ];then echo "         Field $countCDRfield8 is equal to $countCDRpattern8";fi
                        echo ""$reset""
                elif [ "$verbose" == "true" ] && [ "$countCDRIgnoreFields" != "false" ];then
                        echo ""$blue"TEST --> $test $test2 $test3"$reset""
                fi
            fi
        done
fi
}

########################## Curl Queries ################################
curlQueriesSub()
{
if [ ! -z "$curl_queries_list" ];then
        countTotalcurlQueries=$(cat $curl_queries_list | cut -d"#" -f 1 | grep curl_QueryEnable | wc -l)
else
        countTotalcurlQueries=0
fi
if [ $countTotalcurlQueries -eq 0 ];then if [ "$verbose" == "true" ];then echo -e ""$yellow"\n----------- Curl Health Queries ------------"$reset"";echo "["$pink"INFO"$reset"] "$pink"There is not any parameter "$reset"curl_QueryEnable_x"$pink" in curl_queries_list.cfg (x is the instance number). It's ok, healthcheck will not monitor any process via curl query"$reset"";fi;else
        printTittle="noyet"
        for (( i=0; i<$countTotalcurlQueries;i++))
        do
            eval curl_QueryEnable=( \${curl_QueryEnable_$i[@]} )
            eval curl_Querygravity=( \${curl_Query_gravity_$i[@]} )
            eval curl_ElasticSearchQuery=( \${curl_ElasticSearchQuery_$i[@]} )
            eval curl_ElasticHost=( \${curl_ElasticHost_$i[@]} )
            eval curl_ElasticSearchQuery_user=( \${curl_ElasticSearchQuery_user_$i[@]} )
            eval curl_ElasticSearchQuery_password=( \${curl_ElasticSearchQuery_password_$i[@]} )
            eval curl_DocStoreQuery=( \${curl_DocStoreQuery_$i[@]} )
            eval curl_DocStoreQuery_user=( \${curl_DocStoreQuery_user_$i[@]} )
            eval curl_DocStoreQuery_password=( \${curl_DocStoreQuery_password_$i[@]} )
            eval curl_SOAPQuery=( \${curl_SOAPQuery_$i[@]} )
            eval curl_SOAPdata=( \${curl_SOAPdata_$i[@]} )
            eval curl_EndPoint=( \${curl_EndPoint_$i[@]} )
            eval curl_Type=( \${curl_Type_$i[@]} )
            eval curl_Header1=( \${curl_Header1_$i[@]} )
            eval curl_Header2=( \${curl_Header2_$i[@]} )
            eval curl_Tenant=( \${curl_Tenant_$i[@]} )
            eval curl_ReponsePattern=( \${curl_ReponsePattern_$i[@]} )
            eval curl_ReponsePatternCase=( \${curl_ReponsePatternCase_$i[@]} )
            eval curl_StatusMessage=( \${curl_StatusMessage_$i[@]} )
            eval curl_Querysupport=( \${curl_Query_support_$i[@]} )
            curlQueryEnable=$(echo ${curl_QueryEnable[@]})
            curlQuerygravity=$(echo ${curl_Querygravity[@]})
            curlElasticSearchQuery=$(echo ${curl_ElasticSearchQuery[@]})
            curlElasticHost=$(echo ${curl_ElasticHost[@]})
            curlElasticSearchQuery_user=$(echo ${curl_ElasticSearchQuery_user[@]})
            curlElasticSearchQuery_password=$(echo ${curl_ElasticSearchQuery_password[@]})
            curlDocStoreQuery=$(echo ${curl_DocStoreQuery[@]})
            curlDocStoreQuery_user=$(echo ${curl_DocStoreQuery_user[@]})
            curlDocStoreQuery_password=$(echo ${curl_DocStoreQuery_password[@]})
            curlSOAPQuery=$(echo ${curl_SOAPQuery[@]})
            curlSOAPdata=$(echo ${curl_SOAPdata[@]})
            curlEndPoint=$(echo ${curl_EndPoint[@]})
            curlType=$(echo ${curl_Type[@]})
            curlHeader1=$(echo ${curl_Header1[@]})
            curlHeader2=$(echo ${curl_Header2[@]})
            curlTenant=$(echo ${curl_Tenant[@]})
            curlReponsePattern=$(echo ${curl_ReponsePattern[@]})
            curlReponsePatternCaseP=$(echo ${curl_ReponsePatternCase[@]});curlReponsePatternCase=$(echo $curlReponsePatternCaseP | awk '{print toupper($0)}')
            curlStatusMessage=$(echo ${curl_StatusMessage[@]})
            curlQuerysupport=$(echo ${curl_Querysupport[@]})
        if [ $curlQueryEnable -eq 1 ]; then
                if [ "$printTittle" == "noyet" ];then echo -e ""$yellow"\n----------- Curl Health Queries ------------"$reset"";printTittle="done";fi
                if [ -z "$curlQuerygravity" ];then curlQuerygravity="ALERT";else curlQuerygravity=$(echo $curlQuerygravity | awk '{print toupper($0)}');fi
                if [ ! -z "$curlHeader2" ] && [ "$curlElasticSearchQuery" -ne 1 ] && [ "$curlDocStoreQuery" -ne 1 ] && [ "$curlSOAPQuery" -ne 1 ];then
                        triggerCurlQuery=$(curl -m 10 -s -i -X $curlType -H "tenant: $curlTenant" -H "$curlHeader1" -H "$curlHeader2" $curlEndPoint | grep $curlReponsePattern)
                        printtriggerCurlQuery='curl -m 10 -s -i -X '$curlType' -H "tenant: '$curlTenant'" -H "'$curlHeader1'" -H "'$curlHeader2'" "'$curlEndPoint'"'
                elif [ "$curlElasticSearchQuery" -eq 1 ];then
                        isForCurator=$(echo "$curlReponsePattern" | grep close)
                        hasCurlEndPointIndices=$(echo "$curlEndPoint" | grep indices)
                        if [ ! -z "$isForCurator" ] && [ ! -z "$hasCurlEndPointIndices" ];then
                                NintyForDaysAgoDate=$(perl -e '@d=localtime time()-(84600*95); printf "%4d.%02d.%02d\n", $d[5]+1900,$d[4]+1,$d[3]')
                                triggerCurlQuery=$(curl -m 10 -s -i -X $curlType -u $curlElasticSearchQuery_user:$curlElasticSearchQuery_password $curlEndPoint | grep $curlReponsePattern | grep $NintyForDaysAgoDate)
                                printtriggerCurlQuery='curl -m 10 -s -i -X '$curlType' -u '$curlElasticSearchQuery_user:$curlElasticSearchQuery_password' '$curlEndPoint' | grep '$curlReponsePattern' | grep '$NintyForDaysAgoDate''
                        else
                                triggerCurlQuery=$(curl -m 10 -s -i -X $curlType -u $curlElasticSearchQuery_user:$curlElasticSearchQuery_password $curlEndPoint | grep $curlReponsePattern)
                                printtriggerCurlQuery='curl -m 10 -s -i -X '$curlType' -u '$curlElasticSearchQuery_user:$curlElasticSearchQuery_password' '$curlEndPoint''
                        fi
                elif [ "$curlDocStoreQuery" -eq 1 ];then
                        triggerCurlQuery=$(curl -m 10 -s -i -X $curlType -H "$curlHeader1" -H "$curlHeader2" -u $curlDocStoreQuery_user:$curlDocStoreQuery_password $curlEndPoint | grep $curlReponsePattern)
                        printtriggerCurlQuery='curl -m 10 -s -i -X '$curlType' -H '\"$curlHeader1\"' -H '\"$curlHeader2\"' -u '$curlDocStoreQuery_user:$curlDocStoreQuery_password' '$curlEndPoint''
                elif [ "$curlSOAPQuery" -eq 1 ];then
                        triggerCurlQuery=$(curl -k -m 10 -s -i -H "$curlHeader1" -H "$curlHeader2" -d "$curlSOAPdata" $curlEndPoint | grep $curlReponsePattern)
                        printtriggerCurlQuery="curl -k -m 10 -s -i -H \"$curlHeader1\" -H \"$curlHeader2\" -d '$curlSOAPdata' '$curlEndPoint'"
                else
                        triggerCurlQuery=$(curl -m 10 -s -i -X $curlType -H "tenant: $curlTenant" -H "$curlHeader1" $curlEndPoint | grep "$curlReponsePattern")
                        printtriggerCurlQuery='curl -m 10 -s -i -X '$curlType' -H "tenant: '$curlTenant'" -H "'$curlHeader1'" "'$curlEndPoint'"'
                fi

                if [ "$curlReponsePatternCase" == "EXPECTED" ];then
                        printtriggerCurlQueryErrorMessage="The following curl query is expecting \"$curlReponsePattern\" in its response:"
                else
                        printtriggerCurlQueryErrorMessage="The following curl query is showing NOT expected \"$curlReponsePattern\" in its response:"
                fi
                if [ ! -z "$triggerCurlQuery" -a "$curlReponsePatternCase" == "EXPECTED" ] || [ -z "$triggerCurlQuery" -a "$curlReponsePatternCase" == "UNEXPECTED" ];then
                        echo "["$green"OK"$reset"] "$bold"$curlStatusMessage"$reset""
                        if [ "$curlElasticSearchQuery" -eq 1 ] && [ "$mode" != "noColors" ];then
                                if [ "$ESstatus" != "done" ];then
                                        ESstatus=done
                                fi
                        fi
                else
                        if [ "$curlQuerygravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                echo "["$green"$curlQuerygravity"$reset"] "$bold"$curlStatusMessage = "$reset"$printtriggerCurlQueryErrorMessage $printtriggerCurlQuery"
                        elif [ "$curlQuerygravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                echo "["$pink"$curlQuerygravity"$reset"] "$bold"$curlStatusMessage = "$reset"$printtriggerCurlQueryErrorMessage "$pink"$printtriggerCurlQuery"$reset""
                        else
                                echo "["$red"$curlQuerygravity"$reset"] "$bold"$curlStatusMessage = "$reset"$printtriggerCurlQueryErrorMessage "$red"$printtriggerCurlQuery"$reset""
                        fi
                        if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$curlQuerysupport";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi

                fi
                if [ "$verbose" == "true" ];then echo ""$blue"TEST --> $printtriggerCurlQuery"$reset"";fi
        fi


        done
        if [ "$ESstatus" == "done" ];then
                curl -u $curlElasticSearchQuery_user:$curlElasticSearchQuery_password $curlElasticHost:9200/_cat/nodes?v > $DIR/.tempFile 2> /dev/null
                getCatNodesResult=$(cat $DIR/.tempFile)
                countESnodes=$(echo "$getCatNodesResult" | egrep -v name | wc -l)
                if [ "$countESnodes" -eq 8 ];then
                        echo "["$green"OK"$reset"] "$bold"ELK Cluster - _cat/nodes"$reset
                        cat $DIR/.tempFile
                else
                        echo "["$red"ALERT"$reset"] "$bold"ELK Cluster - _cat/nodes"$reset$red" has less then 8 nodes"$reset""
                        cat $DIR/.tempFile
                fi
                if [ "$verbose" == "true" ];then echo ""$blue"TEST --> curl -u $curlElasticSearchQuery_user:$curlElasticSearchQuery_password $curlElasticHost:9200/_cat/nodes?v"$reset"";fi
        fi
fi
}



# Flags and Mode
while getopts HLvcCAm:r:l:h option;
do
        case $option in
                m) mode=$OPTARG;;
                c) onlyCurlChecks="true";;
                C) onlyCDRsCounter="true";;
                A) onlyAdminCommands="true";;
                r) channel=$OPTARG;;
                v) verbose="true";;
                l) clusterList=$OPTARG;;
                L) clusterList="all";;
                H) flagH="true";;
                h) hcHits=$(cat $DIR/.hits);echo "
        Usage: healthcheck


        Filename:    healthcheck.sh
        Revision:    0.1.0
        Visits:      `tput setaf 2`$hcHits`tput sgr0`
        Author:      Hector Barriga

        Jiras:
        CO Scripts:  COSC-96
        CO Internal: COIT-15435

        This sh script is to run a local health check to examine:
        1. Tango Processes
        2. Logical IPs
        3. Disk Space
        4. Memmory and CPU Usage
        5. BULK_IMPORT
        6. SFTP CDRs
        7. Verbose Mode
        8. Traffic CDR counters
        9. Curl Health Queries
        10. Tango Alarms
        11. pm.log Exceptions
        12. Tomcat Server Status
        13. MySQL and its replication
        14. Elastic Search
        15. Sigtran Associations
        16. SMSC Stores
        17. SMPP binds
        18. Systemctl status (3rd party services)
        19. Telnet servers,processes
        20. Administrative Health Commands

        This sh script is mainly used for Tango  CO internal  monitoring
        Copyright (c) Tango Telecom 2018

        All rights reserved.
        This document contains confidential and proprietary information of
        Tango Telecom and any reproduction, disclosure, or use in whole or
        in part is expressly prohibited, except as may be specifically
        authorized by prior written agreement or permission of Tango Telecom.


               Configuration:

               ./healthcheck.cfg

               Options:

               -h <help>                Show help

               -c <curl checks>         healthcheck only runs curl checks

               -C <count CDRs>          healthcheck only counts CDRs

               -A <Admin Checks>        healthcheck only runs Administrative checks

               -m <mode>                healthcheck has 3 modes: To get issues, to report whether ALL systems are Ok or not.  (useful for crontab jobs)
                                        Notes:
                                                - It runs healthcheck on all machines listed in healtchcheck.cfg
                                                - It is also used to report without colors
                                                - If flag -d is not present, report will be sent via SMS
                                                - This flag has to contain a value
                                        Options:
                                                - getIssues: To find issues and recommend a solution (Default)
                                                - sendIfOk:  To report if there are not issues
                                                - noColors:  To display healthcheck without colors

               -r <report>              healthcheck can report via 3 channels: SMS, Email or print report into healthcheck.log
                                        Notes:
                                                - Flag -m must be present otherwise this flag is ignored
                                                - You can use All or any. Just add them separated by commas
                                                - This flag has to contain a value
                                        Options:
                                                - SMS
                                                - Email
                                                - Log

               -l <cluster list>        Runs healthcheck on all machines listed and only displays issues.
                                        Notes:
                                                - This flag has to contain a value
                                                - if flag -m or -v is present, this flag -l is ignored
                                        Options:
                                                - <machines>: List machines separated by commas.
                                                - all: To run healthcheck on all machines set in parameter hosts_List in healthcheck.cfg
               -L <All Clusters>        Runs healthcheck on all machines set in hosts_List parameter in healtchcheck.cfg Similar to healthcheck.sh -l all

               -v <verbose>             To display (in blue) tests done by the script such as curls, telnet, etc.

               Examples:

               e.g. ./healthcheck.sh
                    It only displays machine full status as per ./healthcheck.cfg settings and recommend a solution if an issue is found

               e.g. ./healthcheck.sh -m getIssues -r SMS,Email,log
                    It sends an SMS , an Email only if it gets/finds an issue and always runs healthcheck and store results in healthcheck.log

               e.g. ./healthcheck.sh -l tangoA,tangoB
                    It displays issues on tangoA and TangoB

               e.g. ./healthcheck.sh -L
                    It displays issues on all machines set in hosts_List parameter in healtchcheck.cfg

               e.g. ./healthcheck.sh -v
                    It displays machine full status and displays all tests run by the script in case you wish to run them manually


               "; h="true";;
        esac
done


#################### healthchcek normal#################
if [ "$h" != "true" ];then
if [ "$mode" == "noColors" ];then
        tempFile=".tempFileNoColors"
else
        tempFile=".tempFile"
fi
################## Read Config File ####################
cat $config_file | grep "list.cfg" | grep "=" | cut -d'#' -f1 | sed '/^$/d' > $DIR/$tempFile
oldIFS="$IFS"
IFS="="
while read name value
do
    eval $name="$value"
done < $DIR/$tempFile
IFS="$oldIFS"
cat $config_file > $DIR/$tempFile
if [ ! -z "$logical_IP_list" ];then cat $logical_IP_list >> $DIR/$tempFile;fi
if [ ! -z "$check_verbose_list" ];then cat $check_verbose_list >> $DIR/$tempFile;fi
if [ ! -z "$systemctl_status_list" ];then cat $systemctl_status_list >> $DIR/$tempFile;fi
if [ ! -z "$CDR_counters_list" ];then cat $CDR_counters_list >> $DIR/$tempFile;fi
if [ ! -z "$curl_queries_list" ];then cat $curl_queries_list >> $DIR/$tempFile;fi
if [ ! -z "$pm_logs_list" ];then cat $pm_logs_list >> $DIR/$tempFile;fi
if [ ! -z "$tango_alarms_list" ];then cat $tango_alarms_list >> $DIR/$tempFile;fi
if [ ! -z "$telnet_list" ];then cat $telnet_list >> $DIR/$tempFile;fi
if [ ! -z "$administrative_health_command_list" ];then cat $administrative_health_command_list >> $DIR/$tempFile;fi


cat $DIR/$tempFile | cut -d'#' -f1 | egrep -v ']' | sed '/^$/d' > $DIR/.tempConfig
mv $DIR/.tempConfig $DIR/$tempFile
oldIFS="$IFS"
IFS="="
while read name value
do
    eval $name="$value"
done < $DIR/$tempFile
IFS="$oldIFS"

################# Count Visists on all cluster #########
if [ "$flagH" == "true" ];then
        for getHost in ${hosts_List//,/ }
        do
                if [ "$getHost" == "$hostname" ];then
                        if [ -f $DIR/.hits ];then
                                FilehcHits=$(cat $DIR/.hits)
                                hcHits=$((hcHits + FilehcHits))
                        fi
                else
                        if [ $(ssh tango@$getHost "ls -altr $DIR/.hits | wc -l"  2> /dev/null) != "0" ];then
                                FilehcHits=$(ssh tango@$getHost "cat $DIR/.hits")
                                hcHits=$((hcHits + FilehcHits))
                        fi
                fi
        done

        echo "Number of Visits = $hcHits, bye"
        exit
fi

######################### Script ########################
if [ "$mode" != "getIssues" ] && [ "$mode" != "sendIfOk" ] && [ -z "$clusterList" ];then
if [ "$mode" != "noColors" ];then
        red=`tput setaf 1`
        green=`tput setaf 2`
        yellow=`tput setaf 3`
        blue=`tput setaf 4`
        reset=`tput sgr0`
        lightblue=`tput setaf 6`
        pink=`tput setaf 5`
        bold=`tput bold`
        italic=`tput sitm`
fi

################## Count healthcheck visits ###########
if [ ! -f $DIR/.hits ];then
        echo 0 > $DIR/.hits
fi
hcHits=$(cat $DIR/.hits)
hcHits=$(($hcHits+1))
echo "$hcHits" > $DIR/.hits

####################### ssh Bander ####################
echo ""
echo "                            healthcheck v$version"
echo "                                "$green"Visits: $hcHits"$reset"      "
echo ""
if [ "$mode" != "noColors" ];then
        chmod 775 /home/tango/.bash_profile
        /home/tango/.bash_profile
fi

############# Run healtcheck by sections only ##########
if [ "$onlyCurlChecks" == "true" ];then
        if [ "$onlyAdminCommands" == "true" ];then
                adminCommandsSub
        fi
        curlQueriesSub
        if [ "$onlyCDRsCounter" == "true" ];then
                CDRsCountersSub
        fi
        echo -e ""$yellow"------------------- End --------------------\n"
        echo "Finished."
        echo "Run "$reset""$bold"healthcheck -v "$reset""$yellow"to display (in blue) tests and suggested supports"
        echo ""$reset""
        export TERM=$getTERM
        exit
fi
if [ "$onlyCDRsCounter" == "true" ];then
        if [ "$onlyAdminCommands" == "true" ];then
                adminCommandsSub
        fi
        CDRsCountersSub
        echo -e ""$yellow"------------------- End --------------------\n"
        echo "Finished."
        echo "Run "$reset""$bold"healthcheck -v "$reset""$yellow"to display (in blue) tests and suggested supports"
        echo ""$reset""
        export TERM=$getTERM
        exit

fi
if [ "$onlyAdminCommands" == "true" ];then
        adminCommandsSub
        if [ "$onlyCurlChecks" == "true" ];then
                curlQueriesSub
        fi
        echo -e ""$yellow"------------------- End --------------------\n"
        echo "Finished."
        echo "Run "$reset""$bold"healthcheck -v "$reset""$yellow"to display (in blue) tests and suggested supports"
        echo ""$reset""
        export TERM=$getTERM
        exit

fi
####################### mps ############################
echo ""
origTERM=$TERM
TERM=linux
/tango/bin/mps
TERM=$origTERM
if (( $? ))
then
echo ""
echo -e "["$red"ALERT"$reset"]"$red" TANGO PROCESSES ARE DOWN !!!!! "$reset""
fi
echo ""

#################### MySQL Replication Status ######################
if [ -z "$replication_status_enable" ];then if [ "$verbose" == "true" ];then echo -e ""$yellow"\n------------ Replication Status ------------"$reset"";echo "["$pink"INFO"$reset"] "$pink"Parameter "$reset"replication_status_enable "$pink"is missing from healthcheck.cfg. It's ok, healthcheck will not monitor slave replication"$reset"";fi;else
        if [ $replication_status_enable -eq 1 ] && [ "$percona" -eq 0 ]; then
                echo -e ""$yellow"\n------------ Replication Status ------------"$reset""
                ismysqlup=$(/bin/ps -ef | grep mysql | grep "mysqld.pid")
                if [ ! -z "$ismysqlup" ]; then
                        isPWinMyCnf=$(cat /etc/my.cnf | grep $mysql_password | egrep -v grep)
                        if [ ! -z "$isPWinMyCnf" ];then
                                slavestatus=$(echo "show slave status\G;" | /usr/bin/mysql  -u $mysql_user | egrep "Running|Error" | egrep -v Slave_SQL_Running_State)
                                test='echo "show slave status\G;" | /usr/bin/mysql  -u '$mysql_user' | egrep "Running|Error" | egrep -v Slave_SQL_Running_State'
                        else
                                slavestatus=$(echo "show slave status\G;" | /usr/bin/mysql  -u $mysql_user -p$mysql_password | egrep "Running|Error" | egrep -v Slave_SQL_Running_State)
                                test='echo "show slave status\G;" | /usr/bin/mysql  -u '$mysql_user' -p'$mysql_password' | egrep "Running|Error" | egrep -v Slave_SQL_Running_State'
                        fi

                        getSlave_IO_RunningNo=$(echo "$slavestatus" | grep Slave_IO_Running | grep No)
                        getSlave_SQL_RunningNo=$(echo "$slavestatus" | grep Slave_SQL_Running | grep No)

                        if [ -z "$slavestatus" ] || [[ ! -z "$getSlave_IO_RunningNo" && ! -z "$getSlave_SQL_RunningNo" ]]; then
                                echo "["$green"OK"$reset"] "$bold"MYSQL"$reset" RUNNING AS MASTER ......"
                                if [ "$verbose" == "true" ];then echo ""$blue"TEST --> $test"$reset"";fi
                        else
                                getSlave_IO_RunningOk=$(echo "$slavestatus" | grep Slave_IO_Running | grep Yes)
                                getSlave_SQL_RunningOk=$(echo "$slavestatus" | grep Slave_SQL_Running | grep Yes)
                                if [ ! -z "$getSlave_IO_RunningOk" ] && [ ! -z "$getSlave_SQL_RunningOk" ];then
                                        echo "["$green"OK"$reset"] "$bold"MYSQL"$reset" RUNNING AS SLAVE ......"
                                        echo "$slavestatus"
                                else
                                        if [ "$replication_status_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                                echo "["$green"$replication_status_gravity"$reset"] "$bold"Replication"$reset" is broken"
                                        elif [ "$replication_status_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                                echo "["$pink"$replication_status_gravity"$reset"] "$pink"Replication is broken"$reset""
                                        else
                                                echo "["$red"$replication_status_gravity"$reset"] "$red"Replication is broken"$reset""
                                        fi
                                        echo "$slavestatus"
                                fi
                                if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$replication_status_support";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                                if [ "$verbose" == "true" ];then echo ""$blue"TEST --> $test"$reset"";fi
                        fi
                else
                        if [ -z "$replication_status_gravity" ];then replication_status_gravity="ALERT";else replication_status_gravity=$(echo $replication_status_gravity | awk '{print toupper($0)}');fi
                                if [ "$replication_status_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                        echo "["$green"$replication_status_gravity"$reset"] "$bold"MYSQL"$reset" IS DOWN"
                                elif [ "$replication_status_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                        echo "["$pink"$replication_status_gravity"$reset"] "$pink"MYSQL IS DOWN"$reset""
                                else
                                        echo "["$red"$replication_status_gravity"$reset"] "$red"MYSQL IS DOWN"$reset""
                                fi
                        if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$replication_status_support";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                        if [ "$verbose" == "true" ];then echo ""$blue"TEST --> /bin/ps -ef | grep mysql | grep \"mysqld.pid\""$reset"";fi
                fi
        elif [ $replication_status_enable -eq 1 ] && [ "$percona" -eq 1 ]; then
                echo -e ""$yellow"\n------------ Replication Status ------------"$reset""
                ismysqlup=$(/bin/ps -ef | grep mysql | grep "mysqld.pid")
                if [ ! -z "$ismysqlup" ]; then
                        isPWinMyCnf=$(cat /etc/my.cnf | grep $mysql_password | egrep -v grep)
                        if [ ! -z "$isPWinMyCnf" ];then
                                get_wsrep_cluster_size=$(echo "SHOW GLOBAL STATUS LIKE 'wsrep_cluster_size'\G;" | /usr/bin/mysql  -u $mysql_user | grep "Value" | cut -d":" -f2 | tr -d " ")
                                test_get_wsrep_cluster_size='echo "SHOW GLOBAL STATUS;"| /usr/bin/mysql  -u '$mysql_user' | grep wsrep_cluster_size'
                                get_wsrep_ready=$(echo "SHOW GLOBAL STATUS LIKE 'wsrep_ready'\G;" | /usr/bin/mysql  -u $mysql_user | grep "Value" | cut -d":" -f2 | tr -d " ")
                                test_get_wsrep_ready='echo "SHOW GLOBAL STATUS;"| /usr/bin/mysql  -u '$mysql_user' | grep wsrep_ready'
                                get_wsrep_connected=$(echo "SHOW GLOBAL STATUS LIKE 'wsrep_connected'\G;" | /usr/bin/mysql  -u $mysql_user | grep "Value" | cut -d":" -f2 | tr -d " ")
                                test_get_wsrep_connected='echo "SHOW GLOBAL STATUS;"| /usr/bin/mysql  -u '$mysql_user' | grep wsrep_connected'
                        else
                                get_wsrep_cluster_size=$(echo "SHOW GLOBAL STATUS LIKE 'wsrep_cluster_size'\G;" | /usr/bin/mysql  -u $mysql_user -p$mysql_password | grep "Value" | cut -d":" -f2 | tr -d " ")
                                test_get_wsrep_cluster_size='echo "SHOW GLOBAL STATUS;" | /usr/bin/mysql  -u '$mysql_user' -p'$mysql_password' | grep wsrep_cluster_size'
                                get_wsrep_ready=$(echo "SHOW GLOBAL STATUS LIKE 'wsrep_ready'\G;" | /usr/bin/mysql  -u $mysql_user -p$mysql_password | grep "Value" | cut -d":" -f2 | tr -d " ")
                                test_get_wsrep_ready='echo "SHOW GLOBAL STATUS;" | /usr/bin/mysql  -u '$mysql_user' -p'$mysql_password' | grep wsrep_ready'
                                get_wsrep_connected=$(echo "SHOW GLOBAL STATUS LIKE 'wsrep_connected'\G;" | /usr/bin/mysql  -u $mysql_user -p$mysql_password | grep "Value" | cut -d":" -f2 | tr -d " ")
                                test_get_wsrep_connected='echo "SHOW GLOBAL STATUS;" | /usr/bin/mysql  -u '$mysql_user' -p'$mysql_password' | grep wsrep_connected'
                        fi

                        getSlave_IO_RunningNo=$(echo "$slavestatus" | grep Slave_IO_Running | grep No)
                        getSlave_SQL_RunningNo=$(echo "$slavestatus" | grep Slave_SQL_Running | grep No)

                        if [ -z "$slavestatus" ] || [[ ! -z "$getSlave_IO_RunningNo" && ! -z "$getSlave_SQL_RunningNo" ]]; then

                                echo "["$green"OK"$reset"] "$bold"MYSQL Percona"$reset" RUNNING AS MASTER ......"
                                if [ "$verbose" == "true" ];then echo ""$blue"TEST --> $test_slavestatus"$reset"";fi
                                numOfGaleras=$(echo "$percona_master_list" | awk -F',' ' { print NF }')
                                if [ ! -z "$get_wsrep_cluster_size" ];then
                                        if [ $numOfGaleras -eq $get_wsrep_cluster_size ];then
                                                echo "["$green"OK"$reset"] "$bold"wsrep_cluster_size"$reset" = $get_wsrep_cluster_size galeras. There is quorum"
                                                if [ "$verbose" == "true" ];then echo ""$blue"TEST --> $test_get_wsrep_cluster_size"$reset"";fi
                                        else
                                                if [ "$replication_status_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                                        echo "["$green"$replication_status_gravity"$reset"] "$bold"SHOW GLOBAL STATUS LIKE wsrep_cluster_size"$reset" SQL query shows: $get_wsrep_cluster_size. As per healthcheck.cfg, there should be $numOfGaleras galeras"
                                                elif [ "$replication_status_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                                        echo "["$pink"$replication_status_gravity"$reset"] "$pink"SHOW GLOBAL STATUS LIKE wsrep_cluster_size SQL query shows: $get_wsrep_cluster_size. As per healthcheck.cfg, there should be $numOfGaleras galeras"$reset""
                                                else
                                                        echo "["$red"$replication_status_gravity"$reset"] "$red"SHOW GLOBAL STATUS LIKE wsrep_cluster_size SQL query shows: $get_wsrep_cluster_size. As per healthcheck.cfg, there should be $numOfGaleras galeras"$reset""
                                                fi
                                                if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$replication_status_support;Check healthcheck.cfg has all galeras configured in percona_master_list parameter;Check all galeras are available by checking MySQL Percona Master-Master is running on each machine";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                                                if [ "$verbose" == "true" ];then echo ""$blue"TEST --> $test_get_wsrep_cluster_size"$reset"";fi
                                        fi
                                else
                                        if [ "$replication_status_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                                echo "["$green"$replication_status_gravity"$reset"] "$bold"Replication"$reset" is broken. SHOW GLOBAL STATUS LIKE wsrep_cluster_size SQL quiery is empty"
                                        elif [ "$replication_status_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                                echo "["$pink"$replication_status_gravity"$reset"] "$pink"Replication is broken. SHOW GLOBAL STATUS LIKE wsrep_cluster_size SQL quiery is empty"$reset""
                                        else
                                                echo "["$red"$replication_status_gravity"$reset"] "$red"Replication is broken. SHOW GLOBAL STATUS LIKE wsrep_cluster_size SQL quiery is empty"$reset""
                                        fi
                                        if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$replication_status_support;Check healthcheck.cfg has all galeras configured in percona_master_list parameter;Check all galeras are available by checking MySQL Percona Master-Master is running on each machine";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                                        if [ "$verbose" == "true" ];then echo ""$blue"TEST --> $test_get_wsrep_cluster_size"$reset"";fi
                                fi

                                if [ "$get_wsrep_connected" == "ON" ];then
                                        echo "["$green"OK"$reset"] "$bold"wsrep_connected"$reset" = $get_wsrep_connected"
                                        if [ "$verbose" == "true" ];then echo ""$blue"TEST --> $test_get_wsrep_connected"$reset"";fi
                                else
                                        if [ "$replication_status_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                                echo "["$green"$replication_status_gravity"$reset"] "$bold"SHOW GLOBAL STATUS LIKE wsrep_connected"$reset" SQL query shows: $get_wsrep_connected. It should be ON. Node does not have network connectivity with any other nodes"
                                        elif [ "$replication_status_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                                echo "["$pink"$replication_status_gravity"$reset"] "$pink"SHOW GLOBAL STATUS LIKE wsrep_connected SQL query shows: $get_wsrep_connected. It should be ON. Node does not have network connectivity with any other nodes"$reset""
                                        else
                                                echo "["$red"$replication_status_gravity"$reset"] "$red"SHOW GLOBAL STATUS LIKE wsrep_connected SQL query shows: $get_wsrep_connected. It should be ON. Node does not have network connectivity with any other nodes"$reset""
                                        fi
                                        if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$replication_status_support";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                                        if [ "$verbose" == "true" ];then echo ""$blue"TEST --> $test_get_wsrep_connected"$reset"";fi
                                fi

                                if [ "$get_wsrep_ready" == "ON" ];then
                                        echo "["$green"OK"$reset"] "$bold"wsrep_ready"$reset" = $get_wsrep_ready"
                                        if [ "$verbose" == "true" ];then echo ""$blue"TEST --> $test_get_wsrep_ready"$reset"";fi
                                else
                                        if [ "$replication_status_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                                echo "["$green"$replication_status_gravity"$reset"] "$bold"SHOW GLOBAL STATUS LIKE wsrep_ready"$reset" SQL query shows: $get_wsrep_ready. It should be ON. Node cannot accept queries"
                                        elif [ "$replication_status_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                                echo "["$pink"$replication_status_gravity"$reset"] "$pink"SHOW GLOBAL STATUS LIKE wsrep_ready SQL query shows: $get_wsrep_ready. It should be ON. Node cannot accept queries"$reset""
                                        else
                                                echo "["$red"$replication_status_gravity"$reset"] "$red"SHOW GLOBAL STATUS LIKE wsrep_ready SQL query shows: $get_wsrep_ready. It should be ON. Node cannot accept queries"$reset""
                                        fi
                                        if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$replication_status_support";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                                        if [ "$verbose" == "true" ];then echo ""$blue"TEST --> $test_get_wsrep_ready"$reset"";fi
                                fi


                        else
                                getSlave_IO_RunningOk=$(echo "$slavestatus" | grep Slave_IO_Running | grep Yes)
                                getSlave_SQL_RunningOk=$(echo "$slavestatus" | grep Slave_SQL_Running | grep Yes)
                                if [ ! -z "$getSlave_IO_RunningOk" ] && [ ! -z "$getSlave_SQL_RunningOk" ] && [ "$hostname" == "$percona_slave" ];then
                                        echo "["$green"OK"$reset"] "$bold"MYSQL"$reset" RUNNING AS SLAVE ......"
                                        echo "$slavestatus"
                                else
                                        if [ "$replication_status_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                                echo "["$green"$replication_status_gravity"$reset"] "$bold"Replication"$reset" is broken"
                                        elif [ "$replication_status_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                                echo "["$pink"$replication_status_gravity"$reset"] "$pink"Replication is broken"$reset""
                                        else
                                                echo "["$red"$replication_status_gravity"$reset"] "$red"Replication is broken"$reset""
                                        fi
                                        echo "$slavestatus"
                                fi
                                if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$replication_status_support";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                                if [ "$verbose" == "true" ];then echo ""$blue"TEST --> $test_slavestatus"$reset"";fi
                        fi
                else
                        if [ -z "$replication_status_gravity" ];then replication_status_gravity="ALERT";else replication_status_gravity=$(echo $replication_status_gravity | awk '{print toupper($0)}');fi
                                if [ "$replication_status_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                        echo "["$green"$replication_status_gravity"$reset"] "$bold"MYSQL"$reset" IS DOWN"
                                elif [ "$replication_status_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                        echo "["$pink"$replication_status_gravity"$reset"] "$pink"MYSQL IS DOWN"$reset""
                                else
                                        echo "["$red"$replication_status_gravity"$reset"] "$red"MYSQL IS DOWN"$reset""
                                fi
                        if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$replication_status_support";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                        if [ "$verbose" == "true" ];then echo ""$blue"TEST --> /bin/ps -ef | grep mysql | grep \"mysqld.pid\""$reset"";fi
                fi
        else
                slavestatus="false"
        fi
fi

################## logicalip status ####################
if [ -z "$logicalip0" ];then if [ "$verbose" == "true" ];then echo -e ""$yellow"\n--------------- Logical IPs ----------------"$reset"";VIPlable=true;echo "["$pink"INFO"$reset"] "$pink"Parameter "$reset"logicalip0 "$pink"is missing from logical_IP_list.cfg It's ok, healthcheck will not monitor it"$reset"";fi;else
        if [ $logicalip0 -eq 1 ]; then
                echo -e ""$yellow"\n--------------- Logical IPs ----------------"$reset""
                VIPlable=true
                VIP_0=$(/sbin/ip addr | grep "^ *inet " | egrep "$vip0")
                ping_VIP_0=$(ping $vip0 -c 1)
                isPingOk_0=$(echo "$ping_VIP_0" | awk '/Destination Host Unreachable/ || /100% packet loss/')
                test='/sbin/ip addr | grep "^ *inet " | egrep "'$vip0'"'
                echo ""$bold"---- $vip_name0 ----"$reset""
                if [ -z "$logicalip_gravity0" ];then logicalip_gravity_ToUpper0="ALERT";else logicalip_gravity_ToUpper0=$(echo $logicalip_gravity0 | awk '{print toupper($0)}');fi
                if [ -z "$VIP_0" ] && [ ! -z "$slavestatus" ]; then
                        if [ -z "$isPingOk_0" ];then
                                echo "["$green"OK"$reset"] $slave_message0"
                        else
                                if [ "$logicalip_gravity_ToUpper0" == "INFO" ] && [ "$verbose" != "true" ];then
                                        echo "["$green"$logicalip_gravity_ToUpper0"$reset"] "$bold"$slave_message0"$reset" However, it is UNREACHABLE !!"
                                elif [ "$logicalip_gravity_ToUpper0" == "INFO" ] && [ "$verbose" == "true" ];then
                                        echo "["$pink"$logicalip_gravity_ToUpper0"$reset"] "$pink"$slave_message0. However, it is UNREACHABLE !!"$reset""
                                else
                                        echo "["$red"$logicalip_gravity_ToUpper0"$reset"] "$red"$slave_message0. However, it is UNREACHABLE !!"$reset""
                                fi
                                if [ "$verbose" == "true" ];then echo ""$blue"SUPPORT--> Check network, Firewalls and routers. As root, use nmap or alias clusterNet -h"$reset"";fi
                        fi
                elif [ -z "$VIP_0" ] && [ -z "$slavestatus" ] && [ $VIP_For_MySQL_0 -eq 1 ]; then
                        if [ "$logicalip_gravity_ToUpper0" == "INFO" ] && [ "$verbose" != "true" ];then
                                echo -e "["$green"$logicalip_gravity_ToUpper0"$reset"] "$bold"$vip_name0"$reset" is DOWN and this machine is MySQL Master!!!!!. - It might be UP on slave machine braking replication. - It might be DOWN on both machines"
                        elif [ "$logicalip_gravity_ToUpper0" == "INFO" ] && [ "$verbose" == "true" ];then
                                echo -e "["$pink"$logicalip_gravity_ToUpper0"$reset"] $vip_name0 "$pink"is DOWN and this machine is MySQL Master!!!!!. \n - It might be UP on slave machine braking replication.\n - It might be DOWN on both machines"$reset""
                        else
                                echo -e "["$red"$logicalip_gravity_ToUpper0"$reset"] $vip_name0 "$red"is DOWN and this machine is MySQL Master!!!!!. \n - It might be UP on slave machine braking replication.\n - It might be DOWN on both machines"$reset""
                        fi
                        if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$logicalip_support0";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                elif [ -z "$VIP_0" ] && [ -z "$slavestatus" ] && [ $VIP_For_MySQL_0 -eq 0 ]; then
                        if [ -z "$isPingOk_0" ];then
                                echo "["$green"OK"$reset"] $slave_message0"
                        else
                                if [ "$logicalip_gravity_ToUpper0" == "INFO" ] && [ "$verbose" != "true" ];then
                                        echo "["$green"$logicalip_gravity_ToUpper0"$reset"] "$bold"$slave_message0"$reset" However, it is UNREACHABLE !!"
                                elif [ "$logicalip_gravity_ToUpper0" == "INFO" ] && [ "$verbose" == "true" ];then
                                        echo "["$pink"$logicalip_gravity_ToUpper0"$reset"] "$pink"$slave_message0. However, it is UNREACHABLE !!"$reset""
                                else
                                        echo "["$red"$logicalip_gravity_ToUpper0"$reset"] "$red"$slave_message0. However, it is UNREACHABLE !!"$reset""
                                fi
                                if [ "$verbose" == "true" ];then echo ""$blue"SUPPORT--> Check network, Firewalls and routers. As root, use nmap or alias clusterNet -h"$reset"";fi
                        fi
                else
                        if [ -z "$isPingOk_0" ];then
                                echo "["$green"OK"$reset"] $VIP_0" | sed 's/    //g'
                        else
                                if [ "$logicalip_gravity_ToUpper0" == "INFO" ] && [ "$verbose" != "true" ];then
                                        echo "["$red"$logicalip_gravity_ToUpper0"$reset"] "$bold"$slave_message0"$reset" However, it is UNREACHABLE !!"
                                elif [ "$logicalip_gravity_ToUpper0" == "INFO" ] && [ "$verbose" == "true" ];then
                                        echo "["$pink"$logicalip_gravity_ToUpper0"$reset"] "$pink"$slave_message0. However, it is UNREACHABLE !!"$reset""
                                else
                                        echo "["$red"$logicalip_gravity_ToUpper0"$reset"] "$red"$slave_message0. However, it is UNREACHABLE !!"$reset""
                                fi
                                if [ "$verbose" == "true" ];then echo ""$blue"SUPPORT--> Check network, Firewalls and routers. As root, use nmap or alias clusterNet -h"$reset"";fi
                        fi
                fi
                if [ "$verbose" == "true" ];then echo ""$blue"TEST --> $test"$reset"";fi
        fi
fi

if [ -z "$logicalip1" ];then if [ "$verbose" == "true" ];then if [ "$VIPlable" != "true" ];then echo -e ""$yellow"\n--------------- Logical IPs ----------------"$reset"";VIPlable=true;fi;echo "["$pink"INFO"$reset"] "$pink"Parameter "$reset"logicalip1 "$pink"is missing from logical_IP_list.cfg. It's ok, healthcheck will not monitor it"$reset"";fi;else
        if [ $logicalip1 -eq 1 ]; then
                if [ "$VIPlable" != "true" ];then
                        echo -e ""$yellow"\n--------------- Logical IPs ----------------"$reset""
                        VIPlable=true
                fi
                VIP_1=$(/sbin/ip addr | grep "^ *inet " | egrep "$vip1")
                ping_VIP_1=$(ping $vip1 -c 1)
                isPingOk_1=$(echo "$ping_VIP_1" | awk '/Destination Host Unreachable/ || /100% packet loss/')
                test='/sbin/ip addr | grep "^ *inet " | egrep "'$vip1'"'
                echo ""$bold"---- $vip_name1 ----"$reset""
                if [ -z "$logicalip_gravity1" ];then logicalip_gravity_ToUpper1="ALERT";else logicalip_gravity_ToUpper1=$(echo $logicalip_gravity1 | awk '{print toupper($0)}');fi
                ping_VIP_0=$(ping $vip0 -c 1)
                if [ -z "$VIP_1" ] && [ ! -z "$slavestatus" ]; then
                        if [ -z "$isPingOk_1" ];then
                                echo "["$green"OK"$reset"] $slave_message1"
                        else
                                if [ "$logicalip_gravity_ToUpper1" == "INFO" ] && [ "$verbose" != "true" ];then
                                        echo "["$green"$logicalip_gravity_ToUpper1"$reset"] "$bold"$slave_message1"$reset" However, it is UNREACHABLE !!"
                                elif [ "$logicalip_gravity_ToUpper1" == "INFO" ] && [ "$verbose" == "true" ];then
                                        echo "["$pink"$logicalip_gravity_ToUpper1"$reset"] "$pink"$slave_message1. However, it is UNREACHABLE !!"$reset""
                                else
                                        echo "["$red"$logicalip_gravity_ToUpper1"$reset"] "$red"$slave_message1. However, it is UNREACHABLE !!"$reset""
                                fi
                                if [ "$verbose" == "true" ];then echo ""$blue"SUPPORT--> Check network, Firewalls and routers. As root, use nmap or alias clusterNet -h"$reset"";fi
                        fi
                elif [ -z "$VIP_1" ] && [ -z "$slavestatus" ] && [ $VIP_For_MySQL_1 -eq 1 ]; then
                        if [ "$logicalip_gravity_ToUpper1" == "INFO" ] && [ "$verbose" != "true" ];then
                                echo -e "["$green"$logicalip_gravity_ToUpper1"$reset"] "$bold"$vip_name1"$reset" is DOWN and this machine is MySQL Master!!!!!. \n - It might be UP on slave machine braking replication.\n - It might be DOWN on both machines"
                        elif [ "$logicalip_gravity_ToUpper1" == "INFO" ] && [ "$verbose" == "true" ];then
                                echo -e "["$pink"$logicalip_gravity_ToUpper1"$reset"] "$pink"$vip_name1 is DOWN and this machine is MySQL Master!!!!!. \n - It might be UP on slave machine braking replication.\n - It might be DOWN on both machines"$reset""
                        else
                                echo -e "["$red"$logicalip_gravity_ToUpper1"$reset"] "$red"$vip_name1 is DOWN and this machine is MySQL Master!!!!!. \n - It might be UP on slave machine braking replication.\n - It might be DOWN on both machines"$reset""
                        fi
                        if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$logicalip_support1";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                elif [ -z "$VIP_1" ] && [ -z "$slavestatus" ] && [ $VIP_For_MySQL_1 -eq 0 ]; then
                        if [ -z "$isPingOk_1" ];then
                                echo "["$green"OK"$reset"] $slave_message1"
                        else
                                if [ "$logicalip_gravity_ToUpper1" == "INFO" ] && [ "$verbose" != "true" ];then
                                        echo "["$green"$logicalip_gravity_ToUpper1"$reset"] "$bold"$slave_message1"$reset" However, it is UNREACHABLE !!"
                                elif [ "$logicalip_gravity_ToUpper1" == "INFO" ] && [ "$verbose" == "true" ];then
                                        echo "["$pink"$logicalip_gravity_ToUpper1"$reset"] "$pink"$slave_message1. However, it is UNREACHABLE !!"$reset""
                                else
                                        echo "["$red"$logicalip_gravity_ToUpper1"$reset"] "$red"$slave_message1. However, it is UNREACHABLE !!"$reset""
                                fi
                                if [ "$verbose" == "true" ];then echo ""$blue"SUPPORT--> Check network, Firewalls and routers. As root, use nmap or alias clusterNet -h"$reset"";fi
                        fi
                else
                        if [ -z "$isPingOk_1" ];then
                                echo "["$green"OK"$reset"] $VIP_1" | sed 's/    //g'
                        else
                                if [ "$logicalip_gravity_ToUpper1" == "INFO" ] && [ "$verbose" != "true" ];then
                                        echo "["$green"$logicalip_gravity_ToUpper1"$reset"] "$bold"$slave_message1"$reset" However, it is UNREACHABLE !!"
                                elif [ "$logicalip_gravity_ToUpper1" == "INFO" ] && [ "$verbose" == "true" ];then
                                        echo "["$pink"$logicalip_gravity_ToUpper1"$reset"] "$pink"$slave_message1. However, it is UNREACHABLE !!"$reset""
                                else
                                        echo "["$red"$logicalip_gravity_ToUpper1"$reset"] "$red"$slave_message1. However, it is UNREACHABLE !!"$reset""
                                fi
                                if [ "$verbose" == "true" ];then echo ""$blue"SUPPORT--> Check network, Firewalls and routers. As root, use nmap or alias clusterNet -h"$reset"";fi
                        fi
                fi
                if [ "$verbose" == "true" ];then echo ""$blue"TEST --> $test"$reset"";fi
        fi
fi
if [ -z "$logicalip2" ];then if [ "$verbose" == "true" ];then if [ "$VIPlable" != "true" ];then echo -e ""$yellow"\n--------------- Logical IPs ----------------"$reset"";VIPlable=true;fi;echo "["$pink"INFO"$reset"] "$pink"Parameter "$reset"logicalip2 "$pink"is missing from logical_IP_list.cfg. It's ok, healthcheck will not monitor it"$reset"";fi;else
        if [ $logicalip2 -eq 1 ]; then
                if [ "$VIPlable" != "true" ];then
                        echo -e ""$yellow"\n--------------- Logical IPs ----------------"$reset""
                fi
                VIP_2=$(/sbin/ip addr | grep "^ *inet " | egrep "$vip2")
                ping_VIP_2=$(ping $vip2 -c 1)
                isPingOk_2=$(echo "$ping_VIP_2" | awk '/Destination Host Unreachable/ || /100% packet loss/')
                test='/sbin/ip addr | grep "^ *inet " | egrep "'$vip2'"'
                echo ""$bold"---- $vip_name2 ----"$reset""
                if [ -z "$logicalip_gravity2" ];then logicalip_gravity_ToUpper2="ALERT";else logicalip_gravity_ToUpper2=$(echo $logicalip_gravity2 | awk '{print toupper($0)}');fi
                if [ -z "$VIP_2" ] && [ ! -z "$slavestatus" ]; then
                        if [ -z "$isPingOk_2" ];then
                                echo "["$green"OK"$reset"] $slave_message2"
                        else
                                if [ "$logicalip_gravity_ToUpper2" == "INFO" ] && [ "$verbose" != "true" ];then
                                        echo "["$green"$logicalip_gravity_ToUpper2"$reset"] "$bold"$slave_message2"$reset" However, it is UNREACHABLE !!"
                                elif [ "$logicalip_gravity_ToUpper2" == "INFO" ] && [ "$verbose" == "true" ];then
                                        echo "["$pink"$logicalip_gravity_ToUpper2"$reset"] "$pink"$slave_message2. However, it is UNREACHABLE !!"$reset""
                                else
                                        echo "["$red"$logicalip_gravity_ToUpper2"$reset"] "$red"$slave_message2. However, it is UNREACHABLE !!"$reset""
                                fi
                                if [ "$verbose" == "true" ];then echo ""$blue"SUPPORT--> Check network, Firewalls and routers. As root, use nmap or alias clusterNet -h"$reset"";fi
                        fi
                elif [ -z "$VIP_2" ] && [ -z "$slavestatus" ] && [ $VIP_For_MySQL_2 -eq 1 ]; then
                        if [ "$logicalip_gravity_ToUpper2" == "INFO" ] && [ "$verbose" != "true" ];then
                                echo -e "["$green"$logicalip_gravity_ToUpper0"$reset"] "$bold"$vip_name2"$reset" is DOWN and this machine is MySQL Master!!!!!. \n - It might be UP on slave machine braking replication.\n - It might be DOWN on both machines"
                        elif [ "$logicalip_gravity_ToUpper2" == "INFO" ] && [ "$verbose" == "true" ];then
                                echo -e "["$pink"$logicalip_gravity_ToUpper0"$reset"] "$pink"$vip_name2 is DOWN and this machine is MySQL Master!!!!!. \n - It might be UP on slave machine braking replication.\n - It might be DOWN on both machines"$reset""
                        else
                                echo -e "["$red"$logicalip_gravity_ToUpper0"$reset"] "$red"$vip_name2 is DOWN and this machine is MySQL Master!!!!!. \n - It might be UP on slave machine braking replication.\n - It might be DOWN on both machines"$reset""
                        fi
                        if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$logicalip_support2";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                elif [ -z "$VIP_2" ] && [ -z "$slavestatus" ] && [ $VIP_For_MySQL_2 -eq 0 ]; then
                        if [ -z "$isPingOk_1" ];then
                                echo "["$green"OK"$reset"] $slave_message2"
                        else
                                if [ "$logicalip_gravity_ToUpper2" == "INFO" ] && [ "$verbose" != "true" ];then
                                        echo "["$green"$logicalip_gravity_ToUpper2"$reset"] "$bold"$slave_message2"$reset" However, it is UNREACHABLE !!"
                                elif [ "$logicalip_gravity_ToUpper2" == "INFO" ] && [ "$verbose" == "true" ];then
                                        echo "["$pink"$logicalip_gravity_ToUpper2"$reset"] "$pink"$slave_message2. However, it is UNREACHABLE !!"$reset""
                                else
                                        echo "["$red"$logicalip_gravity_ToUpper2"$reset"] "$red"$slave_message2. However, it is UNREACHABLE !!"$reset""
                                fi
                                if [ "$verbose" == "true" ];then echo ""$blue"SUPPORT--> Check network, Firewalls and routers. As root, use nmap or alias clusterNet -h"$reset"";fi
                        fi
                else
                        if [ -z "$isPingOk_2" ];then
                                echo "["$green"OK"$reset"] $VIP_2" | sed 's/    //g'
                        else
                                if [ "$logicalip_gravity_ToUpper2" == "INFO" ] && [ "$verbose" != "true" ];then
                                        echo "["$green"$logicalip_gravity_ToUpper2"$reset"] "$bold"$slave_message2"$reset" However, it is UNREACHABLE !!"
                                elif [ "$logicalip_gravity_ToUpper2" == "INFO" ] && [ "$verbose" == "true" ];then
                                        echo "["$pink"$logicalip_gravity_ToUpper2"$reset"] "$pink"$slave_message2. However, it is UNREACHABLE !!"$reset""
                                else
                                        echo "["$red"$logicalip_gravity_ToUpper2"$reset"] "$red"$slave_message2. However, it is UNREACHABLE !!"$reset""
                                fi
                                if [ "$verbose" == "true" ];then echo ""$blue"SUPPORT--> Check network, Firewalls and routers. As root, use nmap or alias clusterNet -h"$reset"";fi
                        fi
                fi
                if [ "$verbose" == "true" ];then echo ""$blue"TEST --> $test"$reset"";fi
        fi
fi

#################### Tomcat Status #####################
if [ -z "$tomcat" ];then if [ "$verbose" == "true" ];then echo -e ""$yellow"\n-------------- Tomcat Status ---------------"$reset"";echo "["$pink"INFO"$reset"] "$pink"Parameter "$reset"tomcat "$pink"is missing from healthcheck.cfg. It's ok, healthcheck will not monitor tomcat status"$reset"";fi;else
        if [ $tomcat -eq 1 ]; then
        echo -e ""$yellow"\n-------------- Tomcat Status ---------------"$reset""
        tomcatstatus=$(/bin/ps -ef | grep java | grep "/usr/share/tomcat" | /bin/awk '{print "RUNNING....\n" "UID: " $1"     PID: " $2 "     STime: " $5 " " $6;}')
        test='/bin/ps -ef | grep java | grep "/usr/share/tomcat"'
        tomcatstatus1=$(/bin/ps -ef | grep java | grep "/usr/share/tomcat" | /bin/awk '{print "RUNNING...."}')
        tomcatstatus2=$(/bin/ps -ef | grep java | grep "/usr/share/tomcat" | /bin/awk '{print "UID: " $1"     PID: " $2 "     STime: " $5 " " $6;}')
        if [ -z "$tomcatstatus" ]; then
                if [ -z "$tomcat_gravity" ];then tomcat_gravity="ALERT";else tomcat_gravity=$(echo $tomcat_gravity | awk '{print toupper($0)}');fi
                if [ "$tomcat_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                        echo "["$green"$tomcat_gravity"$reset"] Tomcat is DOWN !!!!! Start it asap."
                elif [ "$tomcat_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                        echo "["$pink"$tomcat_gravity"$reset"] "$pink"Tomcat is DOWN !!!!! Start it asap."$reset""
                else
                        echo "["$red"$tomcat_gravity"$reset"] "$red"Tomcat is DOWN !!!!! Start it asap."$reset""
                fi
                if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$tomcat_support";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
        else
                echo "["$green"OK"$reset"] "$bold"Tomcat"$reset" is $tomcatstatus1"
                echo "$tomcatstatus2"
        fi
        if [ "$verbose" == "true" ];then echo ""$blue"TEST --> $test"$reset"";fi
        fi
fi

#################### Apache ##############################
if [ -z "$apache" ];then if [ "$verbose" == "true" ];then echo -e ""$yellow"\n-------------- Apache Status ---------------"$reset"";echo "["$pink"INFO"$reset"] "$pink"Parameter "$reset"apache "$pink"is missing from healthcheck.cfg. It's ok, healthcheck will not monitor Apache"$reset"";fi;else
        if [ $apache -eq 1 ]; then
                apachestatus=$(ps -ef | grep httpd | awk '/httpd/' | wc -l | tr -s " ")
                test='ps -ef | grep httpd | awk '/httpd/' | wc -l | tr -s " "'
                if [ $apachestatus -eq 0 ]; then
                        echo -e ""$yellow"\n-------------- Apache Status ---------------"$reset""
                        if [ -z "$apache_gravity" ];then apache_gravity="ALERT";else apache_gravity=$(echo $apache_gravity | awk '{print toupper($0)}');fi
                        if [ "$apache_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                echo "["$green"$apache_gravity"$reset"] "$bold"Apache"$reset" is DOWN !!!!! Start it asap"
                        elif [ "$apache_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                echo "["$pink"$apache_gravity"$reset"] "$pink"Apache is DOWN !!!!! Start it asap"$reset""
                        else
                                echo "["$red"$apache_gravity"$reset"] "$red"Apache is DOWN !!!!! Start it asap"$reset""
                        fi
                        if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$apache_support";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                else
                        echo -e ""$yellow"\n-------------- Apache Status ---------------"$reset""
                        echo "["$green"OK"$reset"] "$bold"Apache"$reset""
                fi
                if [ "$verbose" == "true" ];then echo ""$blue"TEST --> $test"$reset"";fi
        fi
fi


################ Sigtran Association s####################
if [ -z "$sigtran" ];then if [ "$verbose" == "true" ];then echo -e ""$yellow"\n---------- Sigtran Associations ------------"$reset"";echo "["$pink"INFO"$reset"] "$pink"Parameter "$reset"sigtran "$pink"is missing from healthcheck.cfg. It's ok, healthcheck will not monitor sigtran associations"$reset"";fi;else
        if [ $sigtran -eq 1 ]; then
                echo -e ""$yellow"\n---------- Sigtran Associations ------------"$reset""
                printSigtranSupport="noyet"
                if [ -z "$sigtran_gravity" ];then sigtran_gravity="ALERT";else sigtran_gravity=$(echo $sigtran_gravity | awk '{print toupper($0)}');fi
                Spawn_Processes_Status "$sigtran_m3ua_port_0" M3UA_OM_oamIf display "$sigtran_Pattern_0" "$sigtran_Pattern_1"
                if [ $patternCount -eq 0 ];then
                        echo "["$green"OK"$reset"] "$bold"M3UA States"$reset" (port $sigtran_m3ua_port_0)"
                elif [ $patternCount -eq -1 ];then
                        if [ "$sigtran_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                echo "["$green"$sigtran_gravity"$reset"] $string_patternCount"
                        elif [ "$sigtran_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                echo "["$pink"$sigtran_gravity"$reset"]"$pink" $string_patternCount"$reset""
                        else
                                echo "["$red"$sigtran_gravity"$reset"]"$red" $string_patternCount"$reset""
                        fi
                        if [ "$verbose" == "true" ] && [ "$printSigtranSupport" == "noyet" ];then printSigtranSupport="done";num=0;IFS=';' read -ra supportline <<< "$sigtran_support";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                else
                        if [ "$sigtran_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                echo "["$green"$sigtran_gravity"$reset"] Some M3UA(port $sigtran_m3ua_port_0) States are DOWN"
                        elif [ "$sigtran_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                echo "["$pink"$sigtran_gravity"$reset"]"$pink" Some M3UA(port $sigtran_m3ua_port_0) States are DOWN"$reset""
                        else
                                echo "["$red"$sigtran_gravity"$reset"]"$red" Some M3UA(port $sigtran_m3ua_port_0) States are DOWN"$reset""
                        fi
                        if [ "$verbose" == "true" ] && [ "$printSigtranSupport" == "noyet" ];then printSigtranSupport="done";num=0;IFS=';' read -ra supportline <<< "$sigtran_support";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                fi
                if [ "$verbose" == "true" ];then echo -e ""$blue"TEST --> telnet 0 $sigtran_m3ua_port_0\nadd M3UA_OM_oamIf;send display"$reset"";fi
                if [ ! -z $sigtran_m3ua_port_1 ];then
                        Spawn_Processes_Status "$sigtran_m3ua_port_1" M3UA_OM_oamIf display "$sigtran_Pattern_0" "$sigtran_Pattern_1"
                        if [ $patternCount -eq 0 ];then
                                echo "["$green"OK"$reset"] "$bold"M3UA States"$reset" (port $sigtran_m3ua_port_1)"
                        elif [ $patternCount -eq -1 ];then
                                if [ "$sigtran_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                        echo "["$green"$sigtran_gravity"$reset"] $string_patternCount"
                                elif [ "$sigtran_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                        echo "["$pink"$sigtran_gravity"$reset"]"$pink" $string_patternCount"$reset""
                                else
                                        echo "["$red"$sigtran_gravity"$reset"]"$red" $string_patternCount"$reset""
                                fi
                        if [ "$verbose" == "true" ] && [ "$printSigtranSupport" == "noyet" ];then printSigtranSupport="done";num=0;IFS=';' read -ra supportline <<< "$sigtran_support";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                        else
                                if [ "$sigtran_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                        echo "["$green"$sigtran_gravity"$reset"] Some M3UA(port $sigtran_m3ua_port_1) States are DOWN"
                                elif [ "$sigtran_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                        echo "["$pink"$sigtran_gravity"$reset"]"$pink" Some M3UA(port $sigtran_m3ua_port_1) States are DOWN"$reset""
                                else
                                        echo "["$red"$sigtran_gravity"$reset"]"$red" Some M3UA(port $sigtran_m3ua_port_1) States are DOWN"$reset""
                                fi
                        if [ "$verbose" == "true" ] && [ "$printSigtranSupport" == "noyet" ];then printSigtranSupport="done";num=0;IFS=';' read -ra supportline <<< "$sigtran_support";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                        fi
                        if [ "$verbose" == "true" ];then echo -e ""$blue"TEST --> telnet 0 $sigtran_m3ua_port_1\nadd M3UA_OM_oamIf;send display"$reset"";fi
                fi
                if [ ! -z $sigtran_m3ua_port_2 ];then
                        Spawn_Processes_Status "$sigtran_m3ua_port_2" M3UA_OM_oamIf display "$sigtran_Pattern_0" "$sigtran_Pattern_1"
                        if [ $patternCount -eq 0 ];then
                                echo "["$green"OK"$reset"] "$bold"M3UA States"$reset" (port $sigtran_m3ua_port_2)"
                        elif [ $patternCount -eq -1 ];then
                                if [ "$sigtran_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                        echo "["$green"$sigtran_gravity"$reset"] $string_patternCount"
                                elif [ "$sigtran_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                        echo "["$pink"$sigtran_gravity"$reset"]"$pink" $string_patternCount"$reset""
                                else
                                        echo "["$red"$sigtran_gravity"$reset"]"$red" $string_patternCount"$reset""
                                fi
                        if [ "$verbose" == "true" ] && [ "$printSigtranSupport" == "noyet" ];then printSigtranSupport="done";num=0;IFS=';' read -ra supportline <<< "$sigtran_support";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                        else
                                if [ "$sigtran_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                        echo "["$green"$sigtran_gravity"$reset"] Some M3UA(port $sigtran_m3ua_port_2) States are DOWN"
                                elif [ "$sigtran_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                        echo "["$pink"$sigtran_gravity"$reset"]"$pink" Some M3UA(port $sigtran_m3ua_port_2) States are DOWN"$reset""
                                else
                                        echo "["$red"$sigtran_gravity"$reset"]"$red" Some M3UA(port $sigtran_m3ua_port_2) States are DOWN"$reset""
                                fi
                        if [ "$verbose" == "true" ] && [ "$printSigtranSupport" == "noyet" ];then printSigtranSupport="done";num=0;IFS=';' read -ra supportline <<< "$sigtran_support";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                        fi
                        if [ "$verbose" == "true" ];then echo -e ""$blue"TEST --> telnet 0 $sigtran_m3ua_port_2\nadd M3UA_OM_oamIf;send display"$reset"";fi
                fi
                checksigtran=$( /bin/netstat --sctp -n | egrep -v Send-Q | egrep -v connections)
                test='/bin/netstat --sctp -n | egrep -v Send-Q | egrep -v connections'
                numOfAssoc=$(/bin/netstat --sctp -n | grep ESTABLISHED  | wc -l)
                if [ -z "$checksigtran" ]; then
                        if [ "$sigtran_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                echo "["$green"$sigtran_gravity"$reset"] "$bold"ALL associations"$reset" are DOWN !!!"
                        elif [ "$sigtran_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                echo "["$pink"$sigtran_gravity"$reset"] "$pink"ALL associations are DOWN !!!"$reset""
                        else
                                echo "["$red"$sigtran_gravity"$reset"] "$red"ALL associations are DOWN !!!"$reset""
                        fi
                        if [ "$verbose" == "true" ] && [ "$printSigtranSupport" == "noyet" ];then printSigtranSupport="done";num=0;IFS=';' read -ra supportline <<< "$sigtran_support";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                elif [ $numOfAssoc -lt $sigtran_numOfAssociations ];then
                        if [ "$sigtran_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                echo "["$green"$sigtran_gravity"$reset"] "$bold"Some associations"$reset" are missing !!!"
                        elif [ "$sigtran_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                echo "["$pink"$sigtran_gravity"$reset"] "$pink"Some associations are missing !!!"$reset""
                        else
                                echo "["$red"$sigtran_gravity"$reset"] "$red"Some associations are missing !!!"$reset""
                        fi
                        if [ "$verbose" == "true" ] && [ "$printSigtranSupport" == "noyet" ];then printSigtranSupport="done";num=0;IFS=';' read -ra supportline <<< "$sigtran_support";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                        /bin/netstat --sctp -n | egrep -v Send-Q | egrep -v connections
                else
                        echo "["$green"OK"$reset"] "$bold"SCCP"$reset" ALL Associations"
                        /bin/netstat --sctp -n | egrep -v Send-Q | egrep -v connections
                fi
                if [ "$verbose" == "true" ];then echo ""$blue"TEST --> $test"$reset"";fi
                mv $DIR/.Spawn_Processes_Status /tango/logs/COSTAFF/trash/
        fi
fi

#################### Filesystem ##############################
echo -e ""$yellow"\n---------------- FileSystem ----------------"$reset""

if [ -z "$FilesystemThreshold_gravity" ];then FilesystemThreshold_gravity="ALERT";else FilesystemThreshold_gravity=$(echo $FilesystemThreshold_gravity | awk '{print toupper($0)}');fi
percentages=$(df -h | grep "%" | egrep -v -i Use | egrep -v mnt | egrep -v iso | egrep -v media | awk '{print $5}' | cut -d% -f1)
test="df -h"
while read spaceDisk
do
        if [ -z "$FilesystemThreshold" ];then if [ "$verbose" == "true" ];then echo "["$pink"INFO"$reset"] "$pink"Parameter "$reset"FilesystemThreshold "$pink"is missing from healthcheck.cfg. It's ok, healthcheck will use default value = 90%"$reset"";FilesystemThreshold=90;fi;fi
        if [ $spaceDisk -gt $FilesystemThreshold ] && [ $spaceDisk -ne 100 ] ;then
                Filesystem=$(df -h | grep $spaceDisk |  awk '{print $6}')
                if [ "$FilesystemThreshold_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                        echo "["$green"$FilesystemThreshold_gravity"$reset"] Filesystem $Filesystem is higher than $FilesystemThreshold%"
                elif [ "$FilesystemThreshold_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                        echo "["$pink"$FilesystemThreshold_gravity"$reset"] "$pink"Filesystem "$reset"$Filesystem"$pink" is higher than $FilesystemThreshold% "$reset""
                else
                        echo "["$red"$FilesystemThreshold_gravity"$reset"] "$red"Filesystem "$reset"$Filesystem"$red" is higher than $FilesystemThreshold% "$reset""
                fi
                if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$FilesystemThreshold_support";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                export spaceNoOk="true"
        elif [ $spaceDisk -eq 100 ] ;then
                Filesystem=$(df -h | grep $spaceDisk | awk '{print $6}')
                echo "["$red"ALERT"$reset"] Filesystem "$reset"$Filesystem"$red" is full -> 100%"$reset""
                if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$FilesystemThreshold_support";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                export spaceNoOk="true"
        fi
done <<< "$percentages"
if [ "$spaceNoOk" != "true" ];then
        echo "["$green"OK"$reset"] "$bold"All FileSystems"$reset" are less than $FilesystemThreshold%"
fi
if [ "$verbose" == "true" ];then echo ""$blue"TEST --> $test"$reset"";fi

hasBlkidPermissions=$(sudo -l | grep NOPASSWD | grep blkid)
if [ ! -z "$hasBlkidPermissions" ];then
        echo "root,swap" > $DIR/.tempFile
        diskDeviceLable_p=$(cat /etc/fstab | grep defaults | egrep -v "swap" | awk '{print $2}' | rev | cut -d"/" -f1 | rev | sed '/^$/d')
        for fstabline in $diskDeviceLable_p
        do
                oldFstabline=$(cat $DIR/.tempFile)
                echo "$oldFstabline,$fstabline" > $DIR/.tempFile
        done
        disk_Device_Lables=$(cat $DIR/.tempFile)
        for diskDeviceLable in ${disk_Device_Lables//,/ }
        do
                blkidDiskDeviceLable=$(sudo /usr/sbin/blkid | grep $diskDeviceLable)
                getDiskDevice=$(sudo /usr/sbin/blkid | grep "\"$diskDeviceLable\"" | cut -d":" -f1)
                if [ -z "$blkidDiskDeviceLable" ];then
                        echo "["$red"ALERT"$reset"] "$red"Disk Device "$reset"$getDiskDevice = $diskDeviceLable"$red" is not mounted"$reset""
                        if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "Make sure $getDiskDevice:$diskDeviceLable is mounted/connected via Hypervisor or physical machine";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                else
                        echo "["$green"OK"$reset"] "$bold"$getDiskDevice "$reset"= $diskDeviceLable"
                fi
        done
        if [ "$verbose" == "true" ];then echo ""$blue"TEST --> Run \"blkid\" as root user or \"sudo blkid\" as tango user "$reset"";fi
else
        if [ "$verbose" == "true" ];then echo "["$pink"INFO"$reset"] "$pink"blkid has not permissions for tango user. Hence, healthcheck cannot check mounting devices (disks). As root, add /usr/sbin/blkid in tango ALL=NOPASSWD in /etc/sudoers. Note: No need to restart anything "$reset"";fi
fi



#################### Memmory and CPU ##############################
echo -e ""$yellow"\n---------- Memmory and CPU Usage -----------"$reset""
if [ -z "$memmoryThreshold_gravity" ];then memmoryThreshold_gravity="ALERT";else memmoryThreshold_gravity=$(echo $memmoryThreshold_gravity | awk '{print toupper($0)}');fi
if [ -z "$swapThreshold_gravity" ];then swapThreshold_gravity="ALERT";else swapThreshold_gravity=$(echo $swapThreshold_gravity | awk '{print toupper($0)}');fi
if [ -z "$cpuThreshold_gravity" ];then cpuThreshold_gravity="ALERT";else cpuThreshold_gravity=$(echo $cpuThreshold_gravity | awk '{print toupper($0)}');fi
memmory=$(free -m | grep Mem | awk '{print $4}')
testm='free -m'
swap=$(free -m | grep Swap | awk '{print $3}')
tests='free -m'

if [ -z "$memmoryThreshold" ];then if [ "$verbose" == "true" ];then echo "["$pink"INFO"$reset"] "$pink"Parameter "$reset"memmoryThreshold "$pink"is missing from healthcheck.cfg. It's ok, healthcheck will use default value = 100MB"$reset"";memmoryThreshold=100;fi;fi
if [ $memmory -lt $memmoryThreshold ]; then
        if [ "$memmoryThreshold_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                echo "["$green"$memmoryThreshold_gravity"$reset"] Free Memmory is very low : $memmory M"
        elif [ "$memmoryThreshold_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                echo "["$pink"$memmoryThreshold_gravity"$reset"] "$pink"Free Memmory is very low : $memmory M"$reset""
        else
                echo "["$red"$memmoryThreshold_gravity"$reset"] "$red"Free Memmory is very low : $memmory M"$reset""
        fi
        if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$memmorySwapCPU_support";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
        if [ "$verbose" == "true" ];then echo ""$blue"TEST --> $testm"$reset"";fi
        memoryNoOk="true"
fi

if [ -z "$swapThreshold" ];then if [ "$verbose" == "true" ];then echo "["$pink"INFO"$reset"] "$pink"Parameter "$reset"swapThreshold "$pink"is missing from healthcheck.cfg. It's ok, healthcheck will use default value = 1000MB"$reset"";swapThreshold=1000;fi;fi
if [ $swap -gt $swapThreshold ]; then
        if [ "$swapThreshold_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                echo "["$green"$swapThreshold_gravity"$reset"] "$bold"Swap Memmory"$reset" is higher than $swapThreshold M"
        elif [ "$swapThreshold_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                echo "["$pink"$swapThreshold_gravity"$reset"] "$pink"Swap Memmory is higher than $swapThreshold M "$reset""
        else
                echo "["$red"$swapThreshold_gravity"$reset"] "$red"Swap Memmory is higher than $swapThreshold M "$reset""
        fi
        if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$memmorySwapCPU_support";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
        if [ "$verbose" == "true" ];then echo ""$blue"TEST --> $tests"$reset"";fi
        memoryNoOk="true"
fi
if [ "$memoryNoOk" != "true" ];then
                echo "["$green"OK"$reset"] "$bold"Free Memmory"$reset" is higher than $memmoryThreshold""M"
                if [ "$verbose" == "true" ];then echo ""$blue"TEST --> $testm"$reset"";fi
                echo "["$green"OK"$reset"] "$bold"Swap Memmory"$reset" is less than $swapThreshold""M"
                if [ "$verbose" == "true" ];then echo ""$blue"TEST --> $tests"$reset"";fi
fi

if [ -z "$cpuThreshold" ];then if [ "$verbose" == "true" ];then echo "["$pink"INFO"$reset"] "$pink"Parameter "$reset"cpuThreshold "$pink"is missing from healthcheck.cfg. It's ok, healthcheck will use default value = 90%"$reset"";cpuThreshold=90;fi;fi
if [ -z "$cpumonPipesDir" ];then if [ "$verbose" == "true" ];then echo "["$pink"INFO"$reset"] "$pink"Parameter "$reset"cpumonPipesDir "$pink"is missing from healthcheck.cfg. It's ok, healthcheck will use default value = 90%"$reset"";cpumonPipesDir="/home/tango/logs/stats/monitor/cpumonPipes";fi;fi
while read in
do
        getCpu=$(echo "$in" | awk '{print $6}' | cut -d"%" -f1)
        testt='cat "'$cpumonPipesDir'"/cpumonPipes_*_"'$todayExt'".txt | grep "CPU"'
        if [ $getCpu -gt $cpuThreshold ] && [ "$displayWarning" != "done" ];then
                displayWarning='done'
                if [ "$cpuThreshold_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                        echo "["$green"$cpuThreshold_gravity"$reset"] High CPU Usage today => It reached $cpuThreshold% earlier on"
                elif [ "$cpuThreshold_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                        echo "["$pink"$cpuThreshold_gravity"$reset"] "$pink" High CPU Usage today => It reached $cpuThreshold% earlier on"$reset""
                else
                        echo "["$red"$cpuThreshold_gravity"$reset"] "$red" High CPU Usage today => It reached $cpuThreshold% earlier on"$reset""
                fi
                if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$memmorySwapCPU_support";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                if [ "$verbose" == "true" ];then echo ""$blue"TEST --> $testt"$reset"";fi
        fi
done < <(cat $cpumonPipesDir/cpumonPipes_*_$todayExt.txt | grep "CPU" | egrep -v Usage)
while read in
do
        getCpu=$(echo "$in" | awk '{print $6}' | cut -d"%" -f1)
        testy='cat "'$cpumonPipesDir'"/cpumonPipes_*_"'$yesterdayExt'".txt | grep "CPU"'
        if [ $getCpu -gt $cpuThreshold ] && [ "$displayWarning" != "done" ];then
                displayWarning='done'
                if [ "$cpuThreshold_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                        echo "["$green"$cpuThreshold_gravity"$reset"] CPU Usage was higher than $cpuThreshold% yesterday"
                elif [ "$cpuThreshold_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                        echo "["$pink"$cpuThreshold_gravity"$reset"] "$pink" CPU Usage was higher than $cpuThreshold% yesterday"$reset""
                else
                        echo "["$red"$cpuThreshold_gravity"$reset"] "$red" CPU Usage was higher than $cpuThreshold% yesterday"$reset""
                fi
                if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$memmorySwapCPU_support";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                if [ "$verbose" == "true" ];then echo ""$blue"TEST --> $testy"$reset"";fi
        fi
done < <(cat $cpumonPipesDir/cpumonPipes_*_$yesterdayExt.txt | grep "CPU" | egrep -v Usage)

if [ "$displayWarning" == "noyet" ];then
        echo "["$green"OK"$reset"] CPU has been less than $cpuThreshold% since yesterday"$reset""
        if [ "$verbose" == "true" ];then echo -n ""$blue"TEST --> $testt;"$reset"";echo ""$blue" $testy"$reset"";fi
fi

########################## SMSC ####################################
if [ -z "$smscEnable" ];then if [ "$verbose" == "true" ];then echo -e ""$yellow"\n------------------ SMSC --------------------"$reset"";echo "["$pink"INFO"$reset"] "$pink"Parameter "$reset"smscEnable "$pink"is missing from healthcheck.cfg. It's ok, healthcheck will not monitor any SMSC process"$reset"";fi;else
        if [ $smscEnable -eq 1 ];then
        echo -e ""$yellow"\n------------------ SMSC --------------------"$reset""
                if [ -z "$smsc_gravity" ];then smsc_gravity="ALERT";else smsc_gravity=$(echo $smsc_gravity | awk '{print toupper($0)}');fi
                Spawn_Processes_Status $smpp_router_port_0 SMPP_router display "\|" "noneeded"
                string_Smpp=$string_patternCount
                patternCountSmpp=$patternCount
                Spawn_Processes_Status $store_port_0 oam stateDisplay "ACTIVE" "BACKUP"
                string_Store=$(echo "$string_patternCount" | tr -d '[:space:]' | cut -d":" -f2)
                if [ $patternCount -ge 1 ];then
                        echo "["$green"OK"$reset"] "$bold"STORE State: "$reset"$string_Store"
                elif [ $patternCount -eq -1 ];then
                        if [ "$smsc_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                echo "["$green"$smsc_gravity"$reset"] $string_patternCount"
                        elif [ "$smsc_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                echo "["$pink"$smsc_gravity"$reset"]"$pink" $string_patternCount"$reset""
                        else
                                echo "["$red"$smsc_gravity"$reset"]"$red" $string_patternCount"$reset""
                        fi
                        if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$store_support";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                else
                        if [ "$smsc_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                echo "["$green"$smsc_gravity"$reset"] STORE is not OK. Summary State: $string_Store"
                        elif [ "$smsc_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                echo "["$pink"$smsc_gravity"$reset"]"$pink" STORE is not OK. Summary State: $string_Store"$reset""
                        else
                                echo "["$red"$smsc_gravity"$reset"]"$red" STORE is not OK. Summary State: $string_Store"$reset""
                        fi
                        if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$store_support";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                fi
                if [ "$verbose" == "true" ];then echo -e ""$blue"TEST --> telnet 0 $store_port_0\nadd oam;send stateDisplay"$reset"";fi
                patternCount=$patternCountSmpp
                smpp_VIP=$(/sbin/ip addr | grep "^ *inet " | egrep "$smpp_router_VIP_0" | wc -l)
                if [ $patternCount -eq $smpp_router_numOfBinds_0 ];then
                        echo "["$green"OK"$reset"] "$bold"SMPP binds"$reset""
                elif [ $smpp_VIP -eq 1 ] && [ $patternCount -ne $smpp_router_numOfBinds_0 ];then
                        if [ "$smsc_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                echo "["$green"$smsc_gravity"$reset"] ALL SMPP binds are missing. Fix ASAP"
                        elif [ "$smsc_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                echo "["$pink"$smsc_gravity"$reset"]"$pink" ALL SMPP binds are missing. Fix ASAP"$reset""
                        else
                                echo "["$red"$smsc_gravity"$reset"]"$red" ALL SMPP binds are missing. Fix ASAP"$reset""
                        fi
                        if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$smpp_router_support";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                elif [ $patternCount -eq -1 ];then
                        if [ "$smsc_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                echo "["$green"$smsc_gravity"$reset"] $string_Smpp"
                        elif [ "$smsc_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                echo "["$pink"$smsc_gravity"$reset"]"$pink" $string_Smpp"$reset""
                        else
                                echo "["$red"$smsc_gravity"$reset"]"$red" $string_Smpp"$reset""
                        fi
                else
                        echo "["$green"OK"$reset"] There should not be binds. There is not VIP"
                fi
                if [ "$verbose" == "true" ];then echo -e ""$blue"TEST --> telnet 0 $smpp_router_port_0\nadd SMPP_router;send display"$reset"";fi
                if [ $patternCount -ne -1 ] && [ $smpp_VIP -eq 1 ];then
                        echo "$string_Smpp"
                fi
                mv $DIR/.Spawn_Processes_Status /tango/logs/COSTAFF/trash/
        fi
fi

########################## BULK_IMPORT ####################################
if [ -z "$bulk_import_Enable" ];then if [ "$verbose" == "true" ];then echo -e ""$yellow"\n--------------- BULK_IMPORT ----------------"$reset"";echo "["$pink"INFO"$reset"] "$pink"Parameter "$reset"bulk_import_Enable "$pink"is missing from healthcheck.cfg. It's ok, healthcheck will not monitor any Bulk_Import process"$reset"";fi;else
        if [ $bulk_import_Enable -eq 1 ];then
        echo -e ""$yellow"\n--------------- BULK_IMPORT ----------------"$reset""
        bulk_importOK="yes"
        if [ -z "$bulk_import_gravity" ];then bulk_import_gravity="ALERT";else bulk_import_gravity=$(echo $bulk_import_gravity | awk '{print toupper($0)}');fi
        isBulkImportUp=$(ps -ef | grep "$bulk_import_AI_perlFile_0" | egrep -v grep | wc -l)
        if [ $isBulkImportUp -eq 1 ] && [ ! -z "$bulk_import_AI_perlFile_0" ];then
                PIDBulkImport=$(ps -ef | grep "$bulk_import_AI_perlFile_0" | egrep -v grep | awk '{print $2}')
                echo "["$green"OK"$reset"] "$bold"$bulk_import_AI_perlFile_0"$reset" Running - PID: $PIDBulkImport"
        elif [ $isBulkImportUp -eq 0 ] && [ ! -z "$bulk_import_AI_perlFile_0" ];then
                if [ "$bulk_import_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                        echo "["$green"$bulk_import_gravity"$reset"] "$bold"$bulk_import_AI_perlFile_0"$reset" is not running."
                elif [ "$bulk_import_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                        echo "["$pink"$bulk_import_gravity"$reset"]"$pink" $bulk_import_AI_perlFile_0 is not running."$reset""
                else
                        echo "["$red"$bulk_import_gravity"$reset"]"$red" $bulk_import_AI_perlFile_0 is not running."$reset""
                fi
                bulk_importOK="no"
        fi
        if [ "$verbose" == "true" ];then echo ""$blue"TEST --> ps -ef | grep $bulk_import_AI_perlFile_0 | egrep -v grep | wc -l"$reset"";fi
        isBulkImportUp=$(ps -ef | grep "$bulk_import_AI_perlFile_1" | egrep -v grep | wc -l)
        if [ $isBulkImportUp -eq 1 ] && [ ! -z "$bulk_import_AI_perlFile_1" ];then
                PIDBulkImport=$(ps -ef | grep "$bulk_import_AI_perlFile_1" | egrep -v grep | awk '{print $2}')
                echo "["$green"OK"$reset"] "$bold"$bulk_import_AI_perlFile_1"$reset" Running - PID: $PIDBulkImport"
        elif [ $isBulkImportUp -eq 0 ] && [ ! -z "$bulk_import_AI_perlFile_1" ];then
                if [ "$bulk_import_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                        echo "["$green"$bulk_import_gravity"$reset"] $bulk_import_AI_perlFile_1 is not running."
                elif [ "$bulk_import_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                        echo "["$pink"$bulk_import_gravity"$reset"]"$pink" $bulk_import_AI_perlFile_1 is not running."$reset""
                else
                        echo "["$red"$bulk_import_gravity"$reset"]"$red" $bulk_import_AI_perlFile_1 is not running."$reset""
                fi
                bulk_importOK="no"
        fi
        if [ "$verbose" == "true" ];then echo ""$blue"TEST --> ps -ef | grep $bulk_import_AI_perlFile_1 | egrep -v grep | wc -l"$reset"";fi
        isBulkImportUp=$(ps -ef | grep "$bulk_import_AI_perlFile_2" | egrep -v grep | wc -l)
        if [ $isBulkImportUp -eq 1 ] && [ ! -z "$bulk_import_AI_perlFile_2" ];then
                PIDBulkImport=$(ps -ef | grep "$bulk_import_AI_perlFile_2" | egrep -v grep | awk '{print $2}')
                echo "["$green"OK"$reset"] "$bold"$bulk_import_AI_perlFile_2"$reset" Running - PID: $PIDBulkImport"
        elif [ $isBulkImportUp -eq 0 ] && [ ! -z "$bulk_import_AI_perlFile_2" ];then
                if [ "$bulk_import_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                        echo "["$green"$bulk_import_gravity"$reset"] "$bold"$bulk_import_AI_perlFile_2"$reset" is not running."
                elif [ "$bulk_import_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                        echo "["$pink"$bulk_import_gravity"$reset"]"$pink" $bulk_import_AI_perlFile_2 is not running."$reset""
                else
                        echo "["$red"$bulk_import_gravity"$reset"]"$red" $bulk_import_AI_perlFile_2 is not running."$reset""
                fi
                bulk_importOK="no"
        fi
        if [ "$verbose" == "true" ];then echo ""$blue"TEST --> ps -ef | grep $bulk_import_AI_perlFile_2 | egrep -v grep | wc -l"$reset"";fi
        isBulkImportUp=$(ps -ef | grep "$bulk_import_AI_perlFile_3" | egrep -v grep | wc -l)
        if [ $isBulkImportUp -eq 1 ] && [ ! -z "$bulk_import_AI_perlFile_3" ];then
                PIDBulkImport=$(ps -ef | grep "$bulk_import_AI_perlFile_3" | egrep -v grep | awk '{print $2}')
                echo "["$green"OK"$reset"] "$bold"$bulk_import_AI_perlFile_3"$reset" Running - PID: $PIDBulkImport"
        elif [ $isBulkImportUp -eq 0 ] && [ ! -z "$bulk_import_AI_perlFile_3" ];then
                if [ "$bulk_import_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                        echo "["$green"$bulk_import_gravity"$reset"] "$bold"$bulk_import_AI_perlFile_3"$reset" is not running."
                elif [ "$bulk_import_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                        echo "["$pink"$bulk_import_gravity"$reset"]"$pink" $bulk_import_AI_perlFile_3 is not running."$reset""
                else
                        echo "["$red"$bulk_import_gravity"$reset"]"$red" $bulk_import_AI_perlFile_3 is not running."$reset""
                fi
                bulk_importOK="no"
        fi
        if [ "$verbose" == "true" ] && [ "$bulk_importOK" == "no" ];then num=0;IFS=';' read -ra supportline <<< "$bulk_import_support";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
        if [ "$verbose" == "true" ];then echo ""$blue"TEST --> ps -ef | grep $bulk_import_AI_perlFile_3 | egrep -v grep | wc -l"$reset"";fi


        mv $DIR/$tempFile /tango/logs/COSTAFF/trash/
        ncat -w 1 -zv $bulk_import_AI_host_primary 22 </dev/null > $DIR/$tempFile
        if [ -s $DIR/$tempFile ];then
                echo "["$green"OK"$reset"] "$bold"SFTP"$reset" is working correctly"
        else
                mv $DIR/$tempFile /tango/logs/COSTAFF/trash/
                ncat -w 1 -zv $bulk_import_AI_host_backup 22 </dev/null > $DIR/$tempFile
                if [ -s $DIR/$tempFile ];then
                        if [ "$bulk_import_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                echo "["$green"$bulk_import_gravity"$reset"] "$bold"SFTP"$reset" is responding on $bulk_import_AI_host_backup however it is NOT working on $bulk_import_AI_host_primary"
                        elif [ "$bulk_import_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                echo "["$pink"$bulk_import_gravity"$reset"]"$pink" SFTP is responding on $bulk_import_AI_host_backup however it is NOT working on $bulk_import_AI_host_primary"$reset""
                        else
                                echo "["$red"$bulk_import_gravity"$reset"]"$red" SFTP is responding on $bulk_import_AI_host_backup however it is NOT working on $bulk_import_AI_host_primary"$reset""
                        fi
                else
                        if [ "$bulk_import_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                echo "["$green"$bulk_import_gravity"$reset"] "$bold"SFTP"$reset" is not responding. Check $bulk_import_AI_host_primary or $bulk_import_AI_host_backup"
                        elif [ "$bulk_import_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                echo "["$pink"$bulk_import_gravity"$reset"]"$pink" SFTP is not responding. Check $bulk_import_AI_host_primary or $bulk_import_AI_host_backup"$reset""
                        else
                                echo "["$red"$bulk_import_gravity"$reset"]"$red" SFTP is not responding. Check $bulk_import_AI_host_primary or $bulk_import_AI_host_backup"$reset""
                        fi
                fi
                if [ "$verbose" == "true" ]; then echo ""$blue"SUPPORT--> Check network connectivity with RTE machines. As root user, use nmap or alias clusterNet -h"$reset"";fi
        fi
        if [ "$verbose" == "true" ];then echo ""$blue"TEST --> ncat -w 1 -zv $bulk_import_AI_host_primary 22"$reset"";fi
        fi
fi

########################## FTP_CDRs ####################################
if [ -z "$ftp_CDRs_Enable" ];then if [ "$verbose" == "true" ];then echo -e ""$yellow"\n---------------- SFTP CDRs ------------------"$reset"";echo "["$pink"INFO"$reset"] "$pink"Parameter "$reset"ftp_CDRs_Enable "$pink"is missing from healthcheck.cfg. It's ok, healthcheck will not monitor any FTP transfer"$reset"";fi;else
        if [ $ftp_CDRs_Enable -eq 1 ];then
        echo -e ""$yellow"\n---------------- SFTP CDRs ------------------"$reset""
        if [ -z "$ftp_CDRs_gravity" ];then ftp_CDRs_gravity="ALERT";else ftp_CDRs_gravity=$(echo $ftp_CDRs_gravity | awk '{print toupper($0)}');fi
        isSFTPopen=$(nmap $ftp_CDRs_host_primary -PN -p ssh | grep ssh)

        if [ ! -z "$isSFTPopen" ];then
                echo "["$green"OK"$reset"] "$bold"Remote server $ftp_CDRs_host_primary"$reset" is responding"
                if [ "$verbose" == "true" ];then echo ""$blue"TEST --> ncat -w 1 -zv $ftp_CDRs_host_primary $ftp_CDRs_port"$reset"";fi
                countFTPAttempts=$(cat $ftp_CDRs_logs_path | grep "$yesterdayExt" | egrep -v INF | egrep -v "Current DATE" | egrep -v "Files Date" | wc -l)
                countFTPSuccessfulLogs=$(cat $ftp_CDRs_logs_path | grep INF | grep "succesfully uploaded" | grep "$yesterdayExt" | wc -l)
                getFTPSuccessfulLogs=$(cat $ftp_CDRs_logs_path | awk '/WRN/ || /ERR/' | grep "$yesterdayExt")
                if [ $countFTPSuccessfulLogs -eq $countFTPAttempts ];then
                        echo "["$green"OK"$reset"] "$bold"$ftp_CDRs_logs_path"$reset" logs are correct"
                        if [ "$verbose" == "true" ];then echo ""$blue"TEST --> cat $ftp_CDRs_logs_path | grep DBG | grep \"$yesterdayExt\" | wc -l;cat $ftp_CDRs_logs_path | grep INF | grep \"succesfully uploaded\" | grep \"$yesterdayExt\" | wc -l"$reset"";fi
                else
                        if [ "$ftp_CDRs_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                echo "["$green"$ftp_CDRs_gravity"$reset"] "$bold"$ftp_CDRs_logs_path"$reset" has this bad log: $getFTPSuccessfulLogs"
                        elif [ "$ftp_CDRs_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                echo "["$pink"$ftp_CDRs_gravity"$reset"]"$pink" $ftp_CDRs_logs_path has this bad log:"$reset" $getFTPSuccessfulLogs"
                        else
                                echo "["$red"$ftp_CDRs_gravity"$reset"]"$red" $ftp_CDRs_logs_path has this bad log:"$reset" $getFTPSuccessfulLogs"
                        fi
                        if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$ftp_CDRs_support";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                        if [ "$verbose" == "true" ];then echo ""$blue"TEST --> cat $ftp_CDRs_logs_path | awk '/WRN/ || /ERR/' | grep \"$yesterdayExt\""$reset"";fi
                fi
        else
                isSFTPopen=$(nmap $ftp_CDRs_host_backup -PN -p ssh | grep ssh)

                if [ ! -z "$isSFTPopen" ];then
                        if [ "$ftp_CDRs_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                echo "["$green"$ftp_CDRs_gravity"$reset"] "$bold"Remote server $ftp_CDRs_host_primary"$reset" is responding however it is NOT working on $ftp_CDRs_host_backup"
                        elif [ "$ftp_CDRs_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                echo "["$pink"$ftp_CDRs_gravity"$reset"]"$pink" Remote server $ftp_CDRs_host_primary is responding however it is NOT working on $ftp_CDRs_host_backup"$reset""
                        else
                                echo "["$red"$ftp_CDRs_gravity"$reset"]"$red" Remote server $ftp_CDRs_host_primary is responding however it is NOT working on $ftp_CDRs_host_backup"$reset""
                        fi
                else
                        if [ "$ftp_CDRs_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                echo "["$green"$ftp_CDRs_gravity"$reset"] "$bold"Remote server $ftp_CDRs_host_primary"$reset" is NOT responding"
                        elif [ "$ftp_CDRs_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                echo "["$pink"$ftp_CDRs_gravity"$reset"]"$pink" Remote server $ftp_CDRs_host_primary is NOT responding"$reset""
                        else
                                echo "["$red"$ftp_CDRs_gravity"$reset"]"$red" Remote server $ftp_CDRs_host_primary is NOT responding"$reset""
                        fi
                fi
                if [ "$verbose" == "true" ]; then echo ""$blue"SUPPORT--> Check connectivity with FTP server $ftp_CDRs_host_primary and port $ftp_CDRs_port. As root user, use nmap or alias clusterNet -h"$reset"";fi
                if [ "$verbose" == "true" ];then echo ""$blue"TEST -->  ncat -w 1 -zv $ftp_CDRs_host_backup $ftp_CDRs_port2"$reset"";fi
        fi
        fi
fi

########################## Systemctl Status ################################
if [ ! -z $systemctl_status_list ];then
        countTotalSystemctlStatus=$(cat $systemctl_status_list | cut -d"#" -f 1 | grep systemctl_status_Enable | wc -l)
else
        countTotalSystemctlStatus=0
fi
if [ $countTotalSystemctlStatus -eq 0 ];then if [ "$verbose" == "true" ];then echo -e ""$yellow"\n------------ Systemctl Status --------------"$reset"";echo "["$pink"INFO"$reset"] "$pink"There is not any parameter "$reset"systemctl_status_Enable_x"$pink" in systemctl_status_list.cfg (x is the instance number). It's ok, healthcheck will not monitor any system service"$reset"";fi;else
        printTitleSystemctlStatus="noyet"
        for (( s=0; s<$countTotalSystemctlStatus;s++))
        do
            eval systemctl_statusEnable=( \${systemctl_status_Enable_$s[@]} )
            eval systemctl_statusService=( \${systemctl_status_Service_$s[@]} )
            eval systemctl_statusgravity=( \${systemctl_status_gravity_$s[@]} )
            eval systemctl_statussupport=( \${systemctl_status_support_$s[@]} )
            systemctlstatusEnable=$(echo ${systemctl_statusEnable[@]})
            systemctlstatusService=$(echo ${systemctl_statusService[@]})
            systemctlstatusgravity=$(echo ${systemctl_statusgravity[@]})
            systemctlstatussupport=$(echo ${systemctl_statussupport[@]})
            if [ $systemctlstatusEnable -eq 1 ]; then
                if [ "$printTitleSystemctlStatus" == "noyet" ];then echo -e ""$yellow"\n------------ Systemctl Status --------------"$reset"";printTitleSystemctlStatus="done";fi
                isSystemctlStatusActive=$(systemctl status $systemctlstatusService | grep "Active:" | grep running)
                if [ ! -z "$isSystemctlStatusActive" ];then
                        echo "["$green"OK"$reset"] "$bold"$systemctlstatusService"$reset" is Active"
                else
                        if [ -z "$systemctlstatusgravity" ];then systemctlstatusgravity="ALERT";else systemctlstatusgravity=$(echo $systemctlstatusgravity | awk '{print toupper($0)}');fi
                        if [ "$systemctlstatusgravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                echo "["$green"$systemctlstatusgravity"$reset"] "$bold"$systemctlstatusService"$reset" is NOT Active"
                        elif [ "$systemctlstatusgravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                echo "["$pink"$systemctlstatusgravity"$reset"]"$pink" $systemctlstatusService is NOT Active"$reset""
                        else
                                echo "["$red"$systemctlstatusgravity"$reset"]"$red" $systemctlstatusService is NOT Active"$reset""
                        fi
                        if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$systemctlstatussupport";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                fi
                if [ "$verbose" == "true" ];then echo ""$blue"TEST --> systemctl status $systemctlstatusService"$reset"";fi
            fi
        done
fi

########################## Verbose Mode ################################
if [ ! -z "$check_verbose_list" ];then
        countTotalCheckVerbose=$(cat $check_verbose_list | cut -d"#" -f 1 | grep check_Verbose_Enable | wc -l)
else
        countTotalCheckVerbose=0
fi
if [ $countTotalCheckVerbose -eq 0 ];then if [ "$verbose" == "true" ];then echo -e ""$yellow"\n-------------- Verbose Mode ----------------"$reset"";echo "["$pink"INFO"$reset"] "$pink"There is not any parameter "$reset"check_Verbose_Enable_x"$pink" in check_verbose_list.cfg (x is the instance number). It's ok, healthcheck will not check the verbose mode for any process"$reset"";fi;else
        printTittleCDR="noyet"
        for (( j=0; j<$countTotalCheckVerbose;j++))
        do
            ifPMhasProcessWithVerbose=''
            eval check_VerboseEnable=( \${check_Verbose_Enable_$j[@]} )
            eval check_Verbosegravity=( \${check_Verbose_gravity_$j[@]} )
            eval check_VerboseGetViaFileOrQuery=( \${check_Verbose_GetViaFileOrQuery_$j[@]} )
            eval check_VerboseQueryEndPoint=( \${check_Verbose_Query_EndPoint_$j[@]} )
            eval check_VerboseQueryEndPointVerboseString=( \${check_Verbose_Query_EndPoint_VerboseString_$j[@]} )
            eval check_VerboseFileDir=( \${check_Verbose_File_Dir_$j[@]} )
            eval check_VerboseFile=( \${check_Verbose_File_$j[@]} )
            eval check_VerboseFileParameter_1=( \${check_Verbose_File_Parameter_1_$j[@]} )
            eval check_VerboseFileParameterVerboseString_1=( \${check_Verbose_File_Parameter_VerboseString_1_$j[@]} )
            eval check_VerboseFileParameter_2=( \${check_Verbose_File_Parameter_2_$j[@]} )
            eval check_VerboseFileParameterVerboseString_2=( \${check_Verbose_File_Parameter_VerboseString_2_$j[@]} )
            eval check_VerboseFileParameter_3=( \${check_Verbose_File_Parameter_3_$j[@]} )
            eval check_VerboseFileParameterVerboseString_3=( \${check_Verbose_File_Parameter_VerboseString_3_$j[@]} )
            eval check_VerboseStatusMessage=( \${check_Verbose_StatusMessage_$j[@]} )
            eval check_Verbosesupport=( \${check_Verbose_support_$j[@]} )
            checkVerboseEnable=$(echo ${check_VerboseEnable[@]})
            checkVerbosegravity=$(echo ${check_Verbosegravity[@]})
            checkVerboseGetViaFileOrQuery=$(echo ${check_VerboseGetViaFileOrQuery[@]})
            checkVerboseQueryEndPoint=$(echo ${check_VerboseQueryEndPoint[@]})
            checkVerboseQueryEndPointVerboseString=$(echo ${check_VerboseQueryEndPointVerboseString[@]})
            checkVerboseFileDir=$(echo ${check_VerboseFileDir[@]})
            checkVerboseFile=$(echo ${check_VerboseFile[@]})
            checkVerboseFileParameter_1=$(echo ${check_VerboseFileParameter_1[@]})
            checkVerboseFileParameterVerboseString_1=$(echo ${check_VerboseFileParameterVerboseString_1[@]})
            checkVerboseFileParameter_2=$(echo ${check_VerboseFileParameter_2[@]})
            checkVerboseFileParameterVerboseString_2=$(echo ${check_VerboseFileParameterVerboseString_2[@]})
            checkVerboseFileParameter_3=$(echo ${check_VerboseFileParameter_3[@]})
            checkVerboseFileParameterVerboseString_3=$(echo ${check_VerboseFileParameterVerboseString_3[@]})
            checkVerboseStatusMessage=$(echo ${check_VerboseStatusMessage[@]})
            checkVerbosesupport=$(echo ${check_Verbosesupport[@]})
            if [ $checkVerboseEnable -eq 1 ] && [ "$checkVerboseGetViaFileOrQuery" == "file" ]; then
                if [ "$printTittleCDR" == "noyet" ];then echo -e ""$yellow"\n-------------- Verbose Mode ----------------"$reset"";printTittleCDR="done";fi
                        if [ -z "$checkVerbosegravity" ];then checkVerbosegravity="ALERT";else checkVerbosegravity=$(echo $checkVerbosegravity | awk '{print toupper($0)}');fi
                        isItOK="yes"
                        getDebugLine=$(cat $checkVerboseFileDir/$checkVerboseFile | grep "$checkVerboseFileParameter_1" | cut -d"#" -f1 | grep -i -e "$checkVerboseFileParameterVerboseString_1" | head -1)
                        if [ ! -z "$getDebugLine" ] && [ ! -z "$checkVerboseFileParameter_1" ] && [ ! -z "$checkVerboseFileParameterVerboseString_1" ];then
                                if [ "$checkVerboseFile" == "PM.cfg" ] && [ "$checkVerboseFileParameterVerboseString_1" == "-v" ];then
                                        getPMProcess=$(cat /tango/config//PM.cfg | grep -E "Description|$getDebugLine" | grep -B 1 Argument | grep Description | cut -d"=" -f 2)
                                        ifPMhasProcessWithVerbose="Process: '$getPMProcess'"" in "
                                fi
                                if [ "$checkVerbosegravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                        echo "["$green"$checkVerbosegravity"$reset"] "$bold"$checkVerboseStatusMessage"$reset" is in verbose mode. $ifPMhasProcessWithVerbose$checkVerboseFileDir/$checkVerboseFile is configured with $getDebugLine"
                                elif [ "$checkVerbosegravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                        echo "["$pink"$checkVerbosegravity"$reset"] "$bold"$checkVerboseStatusMessage"$reset" is in verbose mode. "$pink"$ifPMhasProcessWithVerbose$checkVerboseFileDir/$checkVerboseFile is configured with $getDebugLine"$reset""
                                else
                                        echo "["$red"$checkVerbosegravity"$reset"] "$bold"$checkVerboseStatusMessage"$reset" is in verbose mode. "$red"$ifPMhasProcessWithVerbose$checkVerboseFileDir/$checkVerboseFile is configured with $getDebugLine"$reset""
                                fi
                                if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$checkVerbosesupport";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                                if [ "$verbose" == "true" ];then echo ""$blue"TEST -->  cat $checkVerboseFileDir/$checkVerboseFile | grep \"$checkVerboseFileParameter_1\" | cut -d'#' -f1 | grep -i -e \"$checkVerboseFileParameterVerboseString_1\""$reset"";fi
                                isItOK="no"
                        fi
                        getDebugLine=$(cat $checkVerboseFileDir/$checkVerboseFile | grep "$checkVerboseFileParameter_2" | cut -d"#" -f1 | grep -i "$checkVerboseFileParameterVerboseString_2")
                        if [ ! -z "$getDebugLine" ] && [ ! -z "$checkVerboseFileParameter_2" ] && [ ! -z "$checkVerboseFileParameterVerboseString_2" ];then
                                if [ "$checkVerbosegravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                        echo "["$green"$checkVerbosegravity"$reset"] "$bold"$checkVerboseStatusMessage"$reset" is in verbose mode. $checkVerboseFileDir/$checkVerboseFile is configured with $getDebugLine"
                                elif [ "$checkVerbosegravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                        echo "["$pink"$checkVerbosegravity"$reset"] "$bold"$checkVerboseStatusMessage"$reset" is in verbose mode. "$pink"$checkVerboseFileDir/$checkVerboseFile is configured with $getDebugLine"$reset""
                                else
                                        echo "["$red"$checkVerbosegravity"$reset"] "$bold"$checkVerboseStatusMessage"$reset" is in verbose mode. "$red"$checkVerboseFileDir/$checkVerboseFile is configured with $getDebugLine"$reset""
                                fi
                                if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$checkVerbosesupport";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                                if [ "$verbose" == "true" ];then echo ""$blue"TEST -->  cat $checkVerboseFileDir/$checkVerboseFile | grep \"$checkVerboseFileParameter_2\" | cut -d'#' -f1 | grep -i \"$checkVerboseFileParameterVerboseString_2\""$reset"";fi
                                isItOK="no"
                        fi
                        getDebugLine=$(cat $checkVerboseFileDir/$checkVerboseFile | grep "$checkVerboseFileParameter_3" | cut -d"#" -f1 | grep -i "$checkVerboseFileParameterVerboseString_3")
                        if [ ! -z "$getDebugLine" ] && [ ! -z "$checkVerboseFileParameter_3" ] && [ ! -z "$checkVerboseFileParameterVerboseString_3" ];then
                                if [ "$checkVerbosegravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                        echo "["$green"$checkVerbosegravity"$reset"] "$bold"$checkVerboseStatusMessage"$reset" is in verbose mode. $checkVerboseFileDir/$checkVerboseFile is configured with $getDebugLine"
                                elif [ "$checkVerbosegravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                        echo "["$pink"$checkVerbosegravity"$reset"] "$bold"$checkVerboseStatusMessage"$reset" is in verbose mode. "$pink"$checkVerboseFileDir/$checkVerboseFile is configured with $getDebugLine"$reset""
                                else
                                        echo "["$red"$checkVerbosegravity"$reset"] "$bold"$checkVerboseStatusMessage"$reset" is in verbose mode. "$red"$checkVerboseFileDir/$checkVerboseFile is configured with $getDebugLine"$reset""
                                fi
                                if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$checkVerbosesupport";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                                if [ "$verbose" == "true" ];then echo ""$blue"TEST -->  cat $checkVerboseFileDir/$checkVerboseFile | grep \"$checkVerboseFileParameter_3\" | cut -d'#' -f1 | grep -i \"$checkVerboseFileParameterVerboseString_3\""$reset"";fi
                                isItOK="no"
                        fi
                        if [ "$isItOK" == "yes" ];then
                                echo "["$green"OK"$reset"] "$bold"$checkVerboseStatusMessage"$reset" is quiet"
                                if [ "$verbose" == "true" ] && [ ! -z "$checkVerboseFileParameter_1" ] && [ ! -z "$checkVerboseFileParameterVerboseString_1" ];then echo ""$blue"TEST -->  cat $checkVerboseFileDir/$checkVerboseFile | grep \"$checkVerboseFileParameter_1\" | cut -d'#' -f1 | grep -i \"$checkVerboseFileParameterVerboseString_1\""$reset"";fi
                                if [ "$verbose" == "true" ] && [ ! -z "$checkVerboseFileParameter_2" ] && [ ! -z "$checkVerboseFileParameterVerboseString_2" ];then echo ""$blue"TEST -->  cat $checkVerboseFileDir/$checkVerboseFile | grep \"$checkVerboseFileParameter_2\" | cut -d'#' -f1 | grep -i \"$checkVerboseFileParameterVerboseString_2\""$reset"";fi
                                if [ "$verbose" == "true" ] && [ ! -z "$checkVerboseFileParameter_3" ] && [ ! -z "$checkVerboseFileParameterVerboseString_3" ];then echo ""$blue"TEST -->  cat $checkVerboseFileDir/$checkVerboseFile | grep \"$checkVerboseFileParameter_3\" | cut -d'#' -f1 | grep -i \"$checkVerboseFileParameterVerboseString_3\""$reset"";fi
                        fi
            elif [ $checkVerboseEnable -eq 1 ] && [ "$checkVerboseGetViaFileOrQuery" == "curl" ]; then
                if [ "$printTittleCDR" == "noyet" ];then echo -e ""$yellow"\n-------------- Verbose Mode ----------------"$reset"";printTittleCDR="done";fi
                        if [ -z "$checkVerbosegravity" ];then checkVerbosegravity="ALERT";else checkVerbosegravity=$(echo $checkVerbosegravity | awk '{print toupper($0)}');fi
                        getDebugLine=$(curl -m 10 -s -i -XGET $checkVerboseQueryEndPoint | grep $checkVerboseQueryEndPointVerboseString)
                        printgetDebugLine='curl -m 10 -s -i -XGET '$checkVerboseQueryEndPoint''
                        if [ -z "$getDebugLine" ];then
                                echo "["$green"OK"$reset"] "$bold"$checkVerboseStatusMessage"$reset" is quiet"
                        else
                                if [ "$checkVerbosegravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                        echo "["$green"$checkVerbosegravity"$reset"] "$bold"$checkVerboseStatusMessage"$reset" is in verbose mode. This curl query shows it is in debug: $printgetDebugLine"
                                elif [ "$checkVerbosegravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                        echo "["$pink"$checkVerbosegravity"$reset"] "$bold"$checkVerboseStatusMessage"$reset" is in verbose mode. This curl query shows it is in debug: "$pink"$printgetDebugLine"$reset""
                                else
                                        echo "["$red"$checkVerbosegravity"$reset"] "$bold"$checkVerboseStatusMessage"$reset" is in verbose mode. This curl query shows it is in debug: "$red"$printgetDebugLine"$reset""
                                fi
                                if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$checkVerbosesupport";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                        fi
                        if [ "$verbose" == "true" ];then echo ""$blue"TEST --> curl -m 10 -s -i -XGET $checkVerboseQueryEndPoint | grep $checkVerboseQueryEndPointVerboseString"$reset"";fi
            fi
        done
fi



########################## Administrative Health Commands ##########################
adminCommandsSub


########################## CDRs counters ################################
CDRsCountersSub


########################## Curl Queries ################################
curlQueriesSub

################################ PMUI List Managment #######################################
if [ -z "$listManagment_enabled" ];then if [ "$verbose" == "true" ];then echo -e ""$yellow"\n---------- PMUI List Managment -------------"$reset"";echo "["$pink"INFO"$reset"] "$pink"Parameter "$reset"listManagment_enabled "$pink"is missing from healthcheck.cfg. It's ok, healthcheck will not monitor PMUI List Managment"$reset"";fi;else
        if [ $listManagment_enabled -eq 1 ];then
                echo -e ""$yellow"\n---------- PMUI List Managment -------------"$reset""
                curl -s -u $listManagment_ESuser:$listManagment_ESpw -XGET "$listManagment_ESdataHost:$listManagment_ESdataPort/campaign_lists/_search?q=list_name:*&pretty" | grep list_name | cut -d'"' -f4 > $DIR/$tempFile
                test1="echo \"----- Get ES lists ------\";curl -s -u $listManagment_ESuser:$listManagment_ESpw -XGET \"""$listManagment_ESdataHost:$listManagment_ESdataPort""/campaign_lists/_search?q=list_name:*&pretty\" | grep list_name | cut -d'\"' -f4"
                echo -e "#!/bin/bash\nssh $listManagment_mysqlmasterhost 'echo \"select tag,name from FieldMapping;\" | mysql -u $listManagment_mysqluser -p$listManagment_mysqlpw $listManagment_mysql_promotionDB' | grep Lists" > $DIR/$tempFile
                test2="echo \"----- Get MySQL lists ------\";ssh $listManagment_mysqlmasterhost 'echo \"select tag,name from FieldMapping;\" | mysql -u $listManagment_mysqluser -p$listManagment_mysqlpw $listManagment_mysql_promotionDB' | grep Lists"
                test3="echo \"----- Get an MSISDN in a list\";curl -s -u $listManagment_ESuser:$listManagment_ESpw -X POST -H 'Content-Type: application/json' \"$listManagment_ESdataHost:$listManagment_ESdataPort/campaign_lists/_search\" -d '{\"query\" : {\"term\" : { \"list_values\" : \"<MSISDN here>\" }}}'"
                chmod 777 $DIR/$tempFile
                $DIR/$tempFile > $DIR/.tempFile2 2> /dev/null
                mv $DIR/.tempFile2 $DIR/$tempFile
                getCurrentPMUILists=$(cat $DIR/$tempFile)
                showgetCurrentPMUILists=$(echo $getCurrentPMUILists | sed 's/ /\n/g' | egrep -v Lists)
                q=0
                for listInES in $(echo $getCurrentPMUILists | sed 's/ /\n/g' | egrep -v Lists)
                do
                        getCurrentPMUIListsArray[$q]="$listInES"
                        let "q= $q + 1"
                done

                for getESList in "${getCurrentPMUIListsArray[@]}"
                do
                        cat $DIR/$tempFile | egrep -v "$getESList" | tee  $DIR/$tempFile > /dev/null 2>&1
                done
                countLists=$(cat $DIR/$tempFile | wc -l)
                if [ $countLists -ne 0 ];then
                        if [ -z "$listManagment_gravity" ];then listManagment_gravity="ALERT";else listManagment_gravity=$(echo $listManagment_gravity | awk '{print toupper($0)}');fi
                        if [ "$listManagment_gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                echo "["$green"$listManagment_gravity"$reset"] The following Lists were deleted in PMUI and still remain in ElasticSearch!!"
                        elif [ "$listManagment_gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                echo "["$pink"$listManagment_gravity"$reset"] "$pink"The following Lists were deleted in PMUI and still remain in ElasticSearch!!"$reset""
                        else
                                echo "["$red"$listManagment_gravity"$reset"] "$red"The following Lists were deleted in PMUI and still remain in ElasticSearch!!"$reset""
                        fi
                        cat $DIR/$tempFile
                        echo ""$blue"SUPPORT--> Remove them manually, run the following curl queries:"
                        cat -n $DIR/$tempFile | sort -k2 | uniq -f1 | sort -k1 | cut -f2- | while read in;do echo "           curl -u $listManagment_ESuser:$listManagment_ESpw -X POST -H \"Content-Type: application/json\" http://$listManagment_ESdataHost:$listManagment_ESdataPort/campaign_lists/_delete_by_query -d '{\"query\": {\"match\": {\"list_name\": \"$in\"}}}';";echo "           sleep 60;";done
                        echo ""$reset""

                else
                        echo "["$green"OK"$reset"] "$bold"Lists to be cleant in ElasticSearch"$reset" = 0 Lists"
                fi
                if [ "$verbose" == "true" ];then echo ""$blue"TEST --> $test1;$test2;$test3"$reset"";fi
        fi
fi


########################## Telent Processes ################################
if [ ! -z "$telnet_list" ];then
        countTotaltelent=$(cat $telnet_list | cut -d"#" -f 1 | grep telnet_Enabled | wc -l)
else
        countTotaltelent=0
fi
if [ $countTotaltelent -eq 0 ];then if [ "$verbose" == "true" ];then echo -e ""$yellow"\n------------ Telent Processes --------------"$reset"";echo "["$pink"INFO"$reset"] "$pink"There is not any parameter "$reset"telnet_Enable_x"$pink" in telnet_list.cfg (x is the instance number). It's ok, healthcheck will not telnet any server, application or process"$reset"";fi;else
        connectedTo=''
        printTittleConnTelnet="noyet"
        printTittleStatsTelnet="noyet"
        for (( f=0; f<$countTotaltelent;f++))
        do
            eval telnet_Enabled=( \${telnet_Enabled_$f[@]} )
            eval telnet_tangoprocess=( \${telnet_tango_process_$f[@]} )
            eval telnet_gravity=( \${telnet_gravity_$f[@]} )
            eval telnet_hostname=( \${telnet_hostname_$f[@]} )
            eval telnet_port=( \${telnet_port_$f[@]} )
            eval telnet_consolestring=( \${telnet_console_string_$f[@]} )
            eval telnet_sendcommand=( \${telnet_send_command_$f[@]} )
            eval telnet_sendquitcommand=( \${telnet_send_quit_command_$f[@]} )
            eval telnet_resetCommanddisplayStats=( \${telent_resetCommand_displayStats_$f[@]} )
            eval telnet_catchstring1=( \${telnet_catch_string_1_$f[@]} )
            eval telnet_catchstring2=( \${telnet_catch_string_2_$f[@]} )
            eval telnet_catchstring3=( \${telnet_catch_string_3_$f[@]} )
            eval telnet_Nocatchstring=( \${telnet_No_catch_string_$f[@]} )
            eval telnet_catchstringtype=( \${telnet_catch_string_type_$f[@]} )
            eval telnet_StatusMessage=( \${telnet_StatusMessage_$f[@]} )
            eval telnet_support=( \${telnet_support_$f[@]} )
            telnetEnabled=$(echo ${telnet_Enabled[@]})
            telnettangoprocess=$(echo ${telnet_tangoprocess[@]});if [ -z "$telnettangoprocess" ];then telnettangoprocess=1;fi
            telnetgravity=$(echo ${telnet_gravity[@]})
            telnethostname=$(echo ${telnet_hostname[@]});if [ -z "$telnethostname" ];then telnethostname=0;fi
            telnetport=$(echo ${telnet_port[@]})
            telnetconsolestring=$(echo ${telnet_consolestring[@]});if [ -z "$telnetconsolestring" ];then telnetconsolestring='mon>';fi
            telnetsendcommand=$(echo ${telnet_sendcommand[@]})
            telnetsendquitcommand=$(echo ${telnet_sendquitcommand[@]});if [ -z "$telnetsendquitcommand" ];then telnetsendquitcommand='quit';fi
            telnetresetCommanddisplayStats=$(echo ${telnet_resetCommanddisplayStats[@]})
            telnetcatchstring1=$(echo ${telnet_catchstring1[@]})
            telnetcatchstring2=$(echo ${telnet_catchstring2[@]})
            telnetcatchstring3=$(echo ${telnet_catchstring3[@]})
            telnetNocatchstring=$(echo ${telnet_Nocatchstring[@]})
            telnetcatchstringtype=$(echo ${telnet_catchstringtype[@]});if [ -z "$telnetcatchstringtype" ];then telnetcatchstringtype='error';fi
            telnetStatusMessage=$(echo ${telnet_StatusMessage[@]})
            telnetsupport=$(echo ${telnet_support[@]})


            if [ $telnetEnabled -eq 1 ] && [ ! -z "$telnetport" ] && [ ! -z "$telnetsendcommand" ] && [ ! -z "$telnetcatchstring1" ]; then
                isTelnetsendcommandForStatsDisplay=$(echo "$telnetsendcommand" | tr '[:upper:]' '[:lower:]')
                if [[ $isTelnetsendcommandForStatsDisplay = *"stats"* ]]; then
                       if [ "$printTittleStatsTelnet" == "noyet" ];then echo -e ""$yellow"\n---------- Process Stats (Telnet) ----------"$reset"";printTittleStatsTelnet="done";fi
                else
                        if [ "$printTittleConnTelnet" == "noyet" ];then echo -e ""$yellow"\n----- Remote Server Connection (Telnet) ----"$reset"";printTittleConnTelnet="done";fi
                fi
                if [ -z "$telnetgravity" ];then telnetgravity="ALERT";else telnetgravity=$(echo $telnetgravity | awk '{print toupper($0)}');fi
                if [ $telnettangoprocess -eq 1 ];then
                        mv $DIR/$tempFile /tango/logs/COSTAFF/trash/

                        isRHEL8=$(cat /etc/redhat-release  | grep "Linux release 8" | wc -l)
                        if [ "$isRHEL8" == "1" ];then
                                isPortListen=$(netstat -an | grep "0.0.0.0:$telnetport" | grep LISTEN | grep tcp 2> /dev/null &)
                        else
                                isPortListen=$(ncat -w 1 $telnethostname $telnetport </dev/null > $DIR/$tempFile)
                        fi
                else
                        echo "telnet not to Tango process" > $DIR/$tempFile
                fi
                if [ ! -z "$isPortListen" ];then
                        if [ $telnettangoprocess -eq 1 ] && [ "$telnetresetCommanddisplayStats" == "no" ];then
                                echo "#!/bin/bash
expect <<'EOF'
spawn telnet $telnethostname $telnetport
expect \"assistance.\"
send \"\r\"
expect \"$telnetconsolestring\"
send \"r 0;\r\"
send \"\r\"
expect \"$telnetconsolestring\"
send \"$telnetsendcommand;\r\"
expect \"$telnetconsolestring\"
send \"r 0;\r\"
send \"\r\"
expect \"$telnetconsolestring\"
send \"$telnetsendquitcommand\r\"
EOF" > $DIR/.Spawn_Processes_Status_$f
                        elif [ $telnettangoprocess -eq 1 ] && [ "$telnetresetCommanddisplayStats" == "yes" ];then
                                echo "#!/bin/bash
expect <<'EOF'
spawn telnet $telnethostname $telnetport
expect \"assistance.\"
send \"\r\"
expect \"$telnetconsolestring\"
send \"r 0;\r\"
send \"\r\"
expect \"$telnetconsolestring\"
send \"$telnetsendcommand;\r\"
expect \"reset\"
send \"0\r\"
send \"r 0;\r\"
expect \"$telnetconsolestring\"
send \"$telnetsendquitcommand\r\"
EOF" > $DIR/.Spawn_Processes_Status_$f
                        else
                                echo "#!/bin/bash
expect <<'EOF'
spawn telnet $telnethostname $telnetport
expect \"Escape character is '^]'\"
send \"\r\"
EOF" > $DIR/.Spawn_Processes_Status_$f
connectedTo="remmote server"
                        fi
                        chmod 775 $DIR/.Spawn_Processes_Status_$f
                        if [ -f $DIR/$tempFile ];then mv $DIR/$tempFile /tango/logs/COSTAFF/trash/;fi
                        $DIR/.Spawn_Processes_Status_$f | tee $DIR/$tempFile &>/dev/null &
                        sleep 5
                        if [ ! -z "$telnetNocatchstring" ];then
                                patternCount=$(cat $DIR/$tempFile | awk '/'"$telnetcatchstring1"'/ && /'"$telnetcatchstring2"'/&& /'"$telnetcatchstring3"'/' | egrep -v "$telnetNocatchstring" | wc -l)
                                patternString=$(cat $DIR/$tempFile | grep "$telnetcatchstring1" | grep "$telnetcatchstring2" | grep "$telnetcatchstring3" | egrep -v "$telnetNocatchstring")

                                if [ -z "$patternString" ] && [ ! -z "$telnetcatchstring1" ] && [ ! -z "$telnetcatchstring2" ];then
                                        patternString=$(cat $DIR/$tempFile | grep -v spawn | grep -v Trying | grep "$telnetcatchstring1" | grep "$telnetcatchstring2" | egrep -v "$telnetNocatchstring")
                                fi
                                if [ -z "$patternString" ] && [ ! -z "$telnetcatchstring1" ] && [ ! -z "$telnetcatchstring3" ];then
                                        patternString=$(cat $DIR/$tempFile | grep -v spawn | grep -v Trying | grep "$telnetcatchstring1" | grep "$telnetcatchstring3" | egrep -v "$telnetNocatchstring")
                                fi
                                if [ -z "$patternString" ] && [ ! -z "$telnetcatchstring2" ] && [ ! -z "$telnetcatchstring3" ];then
                                        patternString=$(cat $DIR/$tempFile | grep -v spawn | grep -v Trying | grep "$telnetcatchstring2" | grep "$telnetcatchstring3" | egrep -v "$telnetNocatchstring")
                                fi
                                if [ -z "$patternString" ] && [ ! -z "$telnetcatchstring1" ];then
                                        patternString=$(cat $DIR/$tempFile | grep -v spawn | grep -v Trying | grep "$telnetcatchstring1" | egrep -v "$telnetNocatchstring")
                                fi
                                if [ -z "$patternString" ] && [ ! -z "$telnetcatchstring2" ];then
                                        patternString=$(cat $DIR/$tempFile | grep -v spawn | grep -v Trying | grep "$telnetcatchstring2" | egrep -v "$telnetNocatchstring")
                                fi
                                if [ -z "$patternString" ] && [ ! -z "$telnetcatchstring3" ];then
                                        patternString=$(cat $DIR/$tempFile | grep -v spawn | grep -v Trying | grep "$telnetcatchstring3" | egrep -v "$telnetNocatchstring")
                                fi
                        else
                                telnetcatchstring1NoSpaces=$(echo "$telnetcatchstring1" | tr -d "[:space:]")
                                telnetcatchstring2NoSpaces=$(echo "$telnetcatchstring2" | tr -d "[:space:]")
                                telnetcatchstring3NoSpaces=$(echo "$telnetcatchstring3" | tr -d "[:space:]")
                                patternCount=$(cat $DIR/$tempFile | tr -d " \t" | awk '/'"$telnetcatchstring1NoSpaces"'/ && /'"$telnetcatchstring2NoSpaces"'/&& /'"$telnetcatchstring3NoSpaces"'/' | wc -l)
                                patternString=$(cat $DIR/$tempFile | grep "$telnetcatchstring1" | grep "$telnetcatchstring2" | grep "$telnetcatchstring3")

                                if [ -z "$patternString" ] && [ ! -z "$telnetcatchstring1" ] && [ ! -z "$telnetcatchstring2" ];then
                                        patternString=$(cat $DIR/$tempFile | grep -v spawn | grep -v Trying | grep "$telnetcatchstring1" | grep "$telnetcatchstring2")
                                fi
                                if [ -z "$patternString" ] && [ ! -z "$telnetcatchstring1" ] && [ ! -z "$telnetcatchstring3" ];then
                                        patternString=$(cat $DIR/$tempFile | grep -v spawn | grep -v Trying | grep "$telnetcatchstring1" | grep "$telnetcatchstring3")
                                fi
                                if [ -z "$patternString" ] && [ ! -z "$telnetcatchstring2" ] && [ ! -z "$telnetcatchstring3" ];then
                                        patternString=$(cat $DIR/$tempFile | grep -v spawn | grep -v Trying | grep "$telnetcatchstring2" | grep "$telnetcatchstring3")
                                fi
                                if [ -z "$patternString" ] && [ ! -z "$telnetcatchstring1" ];then
                                        patternString=$(cat $DIR/$tempFile | grep -v spawn | grep -v Trying | grep "$telnetcatchstring1")
                                fi
                                if [ -z "$patternString" ] && [ ! -z "$telnetcatchstring2" ];then
                                        patternString=$(cat $DIR/$tempFile | grep -v spawn | grep -v Trying | grep "$telnetcatchstring2")
                                fi
                                if [ -z "$patternString" ] && [ ! -z "$telnetcatchstring3" ];then
                                        patternString=$(cat $DIR/$tempFile | grep -v spawn | grep -v Trying | grep "$telnetcatchstring3")
                                fi
                        fi
                        if [ $telnettangoprocess -eq 1 ];then
                                patternString=$(echo $patternString | awk '{for (i=1; i<NF; i++) printf $i " "; if (NF >= 1) print $NF; }')
                        else
                                patternString=$(echo $patternString | awk '{for (i=1; i<NF; i++) printf $i " "; if (NF >= 4) print $NF; }')
                        fi

                        if [ "$telnetcatchstringtype" == "error" ];then
                                if [ $patternCount -eq 0 ];then
                                        echo -e "["$green"OK"$reset"] "$bold"$telnetStatusMessage ="$reset" $patternString$connectedTo"
                                else
                                        if [ "$telnetgravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                                echo -e "["$green"$telnetgravity"$reset"] "$bold"$telnetStatusMessage ="$reset" $patternString"$reset""
                                        elif [ "$telnetgravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                                echo -e "["$pink"$telnetgravity"$reset"] "$pink"$telnetStatusMessage ="$reset" $patternString"$reset""
                                        else
                                                echo -e "["$red"$telnetgravity"$reset"] "$red"$telnetStatusMessage ="$reset" $patternString"$reset""
                                        fi
                                        if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$telnetsupport";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                                 fi
                         else
                                if [ $patternCount -ne 0 ];then
                                        echo -e "["$green"OK"$reset"] "$bold"$telnetStatusMessage ="$reset" $patternString$connectedTo"
                                else
                                        if [ "$telnetgravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                                echo -e "["$green"$telnetgravity"$reset"] "$bold"$telnetStatusMessage ="$reset" telnet failed"$reset""
                                        elif [ "$telnetgravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                                echo -e "["$pink"$telnetgravity"$reset"] "$pink"$telnetStatusMessage ="$reset" telnet failed"$reset""
                                        else
                                                echo -e "["$red"$telnetgravity"$reset"] "$red"$telnetStatusMessage ="$reset" telnet failed"$reset""
                                        fi
                                        if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$telnetsupport";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                                 fi


                         fi


                         if [ "$verbose" == "true" ];then echo ""$blue"TEST --> Run: telnet $telnethostname $telnetport then enter command: $telnetsendcommand"$reset"";fi
                else
                        if [ "$telnetgravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                echo "["$green"$telnetgravity"$reset"] telnet $telnetStatusMessage failed. It cannot be connected!"
                        elif [ "$telnetgravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                echo "["$pink"$telnetgravity"$reset"] "$pink"telnet $telnetStatusMessage failed. It cannot be connected!"$reset""
                        else
                                echo "["$red"$telnetgravity"$reset"] "$red"telnet $telnetStatusMessage failed. It cannot be connected!"$reset""
                        fi
                        if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$telnetsupport";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                        if [ "$verbose" == "true" ];then echo ""$blue"TEST --> Run: ncat -w 1 -zv $telnethostname $telnetport"$reset"";fi
                fi

                if [ -f $DIR/.Spawn_Processes_Status_$f ];then
                    mv $DIR/.Spawn_Processes_Status_$f /tango/logs/COSTAFF/trash/
                fi

            fi
        done
fi

################################ ALARMS #######################################
echo -e ""$yellow"\n-------------- Tango Alarms ----------------"$reset""
getAllONalarms=$(cat /tango/logs/aeh/alarm.log | grep "ON," | egrep -v DG_lan | egrep -v GTMS_query_0 | egrep -v "downstream links" | egrep -v "traffic rate has now" | cut -d, -f4)
areThereOverallAlarms="no"
while  read getONalarm
do
        countONalarms=$(cat /tango/logs/aeh/alarm.log | egrep -v GTMS_query_0 | grep "ON," | grep "$getONalarm" | wc -l)
        countOFFalarms=$(cat /tango/logs/aeh/alarm.log | egrep -v GTMS_query_0 | grep "OFF," | grep "$getONalarm" | wc -l)
        if [ $countONalarms -ne $countOFFalarms ];then
                if [ -z "$Tango_Alarms_Global_Gravity" ];then Tango_Alarms_Global_Gravity="ALERT";else Tango_Alarms_Global_Gravity=$(echo $Tango_Alarms_Global_Gravity | awk '{print toupper($0)}');fi
                if [ "$Tango_Alarms_Global_Gravity" == "INFO" ] && [ "$verbose" != "true" ];then
                        echo -e "["$green"$Tango_Alarms_Global_Gravity"$reset"] Check /tango/logs/aeh/alarm.log This alarm is activated !!\n$getONalarm"
                elif [ "$Tango_Alarms_Global_Gravity" == "INFO" ] && [ "$verbose" == "true" ];then
                        echo -e "["$pink"$Tango_Alarms_Global_Gravity"$reset"]"$pink" Check /tango/logs/aeh/alarm.log This alarm is activated !!\n$getONalarm"$reset""
                else
                        echo -e "["$red"$Tango_Alarms_Global_Gravity"$reset"]"$red" Check /tango/logs/aeh/alarm.log This alarm is activated !!\n$getONalarm"$reset""
                fi
                if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "Check ALARM-RS.pdf document";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                areThereOverallAlarms="yes"
        fi
done <<< "$getAllONalarms"
if [ "$areThereOverallAlarms" == "no" ];then
        echo "["$green"OK"$reset"] "$bold"Overall Alarms:"$reset" There are not any activated"
fi
if [ "$verbose" == "true" ];then echo ""$blue"TEST --> cat /tango/logs/aeh/alarm.log"$reset"";fi



if [ ! -z "$tango_alarms_list" ];then
        countTotalTangoAlarm=$(cat $tango_alarms_list | cut -d"#" -f 1 | grep Tango_Alarm_enable | wc -l)
else
        countTotalTangoAlarm=0
fi
if [ $countTotalTangoAlarm -eq 0 ];then if [ "$verbose" == "true" ];then echo "["$pink"INFO"$reset"] "$pink"There is not any parameter "$reset"Tango_Alarm_enable_x"$pink" in $tango_alarms_list (x is the instance number). It's ok, healthcheck will not look for especial Alarms in /tango/log/aeh/alarm.log"$reset"";fi;else
        printTittle="noyet"
        for (( u=0; u<$countTotalTangoAlarm;u++))
        do
            eval Tango_Alarmenable=( \${Tango_Alarm_enable_$u[@]} )
            eval Tango_Alarmgravity=( \${Tango_Alarm_gravity_$u[@]} )
            eval Tango_Alarm=( \${Tango_Alarm_$u[@]} )
            eval Tango_Alarmsupport=( \${Tango_Alarm_support_$u[@]} )
            Tango_Alarmenable=$(echo ${Tango_Alarmenable[@]})
            TangoAlarmgravity=$(echo ${Tango_Alarmgravity[@]})
            TangoAlarm=$(echo ${Tango_Alarm[@]})
            TangoAlarmsupport=$(echo ${Tango_Alarmsupport[@]})
            if [ $Tango_Alarmenable -eq 1 ]; then
                countONalarm=$(cat /tango/logs/aeh/alarm.log | grep "$TangoAlarm" | grep "ON," | wc -l)
                countOFFalarm=$(cat /tango/logs/aeh/alarm.log | grep "$TangoAlarm" | grep "OFF," | wc -l)
                if [ $countONalarm -ne $countOFFalarm ];then
                        if [ -z "$TangoAlarmgravity" ];then TangoAlarmgravity="ALERT";else TangoAlarmgravity=$(echo $TangoAlarmgravity | awk '{print toupper($0)}');fi
                        if [ "$TangoAlarmgravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                echo "["$green"$TangoAlarmgravity"$reset"] "$bold"$TangoAlarm"$reset" alarm activated"
                        elif [ "$TangoAlarmgravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                echo "["$pink"$TangoAlarmgravity"$reset"]"$pink" $TangoAlarm alarm activated"$reset""
                        else
                                echo "["$red"$TangoAlarmgravity"$reset"]"$red" $TangoAlarm alarm activated"$reset""
                        fi
                        if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$TangoAlarmsupport";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                elif [ $countONalarm -ne 0 ];then
                        if [ "$verbose" != "true" ];then
                                echo "["$green"INFO"$reset"] "$bold"$TangoAlarm"$reset" alarm went ON but it is now OFF"
                        elif [ "$verbose" == "true" ];then
                                echo "["$pink"$TangoAlarmgravity"$reset"]"$pink" $TangoAlarm alarm went ON but it is now OFF"$reset""
                        fi
                        if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$TangoAlarmsupport";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                else
                        echo "["$green"OK"$reset"]" $bold"$TangoAlarm"$reset" alarm is OFF"
                fi
                if [ "$verbose" == "true" ];then echo ""$blue"TEST --> cat /tango/logs/aeh/alarm.log"$reset"";fi
            fi
        done
fi

################################ pm.log #######################################
if [ ! -z "$pm_logs_list" ];then
        countTotalpmlogsExceptions=$(cat $pm_logs_list | cut -d"#" -f 1 | grep pmlog_Exception_Enable | wc -l)
else
        countTotalpmlogsExceptions=0
fi
if [ $countTotalpmlogsExceptions -eq 0 ];then if [ "$verbose" == "true" ];then echo -e ""$yellow"\n----------- pm.log Exceptions --------------"$reset"";echo "["$pink"INFO"$reset"] "$pink"There is not any parameter "$reset"pmlog_Exception_Enable_x"$pink" in $pm_logs_list (x is the instance number). It's ok, healthcheck will not look for errors in pm.log"$reset"";fi;else
        printTittle="noyet"
        overthelastMessage="times over the last"
        isPmlogsOk="yes"
        for (( b=0; b<$countTotalpmlogsExceptions;b++))
        do
            eval pmlog_ExceptionEnable=( \${pmlog_Exception_Enable_$b[@]} )
            eval pmlog_Exceptionsupport=( \${pmlog_Exception_support_$b[@]} )
            eval pmlog_Exceptiongravity=( \${pmlog_Exception_gravity_$b[@]} )
            eval pmlog_Exception1=( \${pmlog_Exception_1_$b[@]} )
            eval pmlog_Exception2=( \${pmlog_Exception_2_$b[@]} )
            eval pmlog_ExceptionThreshold=( \${pmlog_Exception_Threshold_$b[@]} )
            eval pmlog_ExceptionMessage=( \${pmlog_Exception_Message_$b[@]} )
            eval pmlog_ExceptionTimeWindow=( \${pmlog_Exception_TimeWindow_$b[@]} )
            pmlogExceptionEnable=$(echo ${pmlog_ExceptionEnable[@]})
            pmlogExceptionsupport=$(echo ${pmlog_Exceptionsupport[@]})
            pmlogExceptiongravity=$(echo ${pmlog_Exceptiongravity[@]})
            pmlogException1=$(echo ${pmlog_Exception1[@]})
            pmlogException2=$(echo ${pmlog_Exception2[@]})
            pmlogExceptionThreshold=$(echo ${pmlog_ExceptionThreshold[@]});if [ -z "$pmlogExceptionThreshold" ];then pmlogExceptionThreshold=1;fi
            pmlogExceptionMessage=$(echo ${pmlog_ExceptionMessage[@]})
            pmlogExceptionTimeWindow=$(echo ${pmlog_ExceptionTimeWindow[@]})
            if [ $pmlogExceptionEnable -eq 1 ]; then
                    if [ "$printTittle" == "noyet" ];then echo -e ""$yellow"\n----------- pm.log Exceptions --------------"$reset"";printTittle="done";fi
                    if [ -z "$pmlogExceptiongravity" ];then pmlogExceptiongravity="ALERT";else pmlogExceptiongravity=$(echo $pmlogExceptiongravity | awk '{print toupper($0)}');fi
                    if [ -z "$pmlogExceptionTimeWindow" ];then
                        countException=$(cat /tango/logs/process/pm.log | awk "/$pmlogException1/ && /$pmlogException2/" | wc -l)
                        getException=$(cat /tango/logs/process/pm.log | awk "/$pmlogException1/ && /$pmlogException2/" | tail -1)
                        test="cat /tango/logs/process/pm.log | awk '/""$pmlogException1""/ && /""$pmlogException2""/' | wc -l"
                        overthelastMessage="times"
                    elif [ "$pmlogExceptionTimeWindow" == "day" ] || [ "$pmlogExceptionTimeWindow" == "Day" ] || [ "$pmlogExceptionTimeWindow" == "DAY" ]; then
                        countException=$(cat /tango/logs/process/pm.log | awk "/$pmlogException1/ && /$pmlogException2/ && /$pmlogstodayDD/" | wc -l)
                        getException=$(cat /tango/logs/process/pm.log | awk "/$pmlogException1/ && /$pmlogException2/ && /$pmlogstodayDD/" | tail -1)
                        test="cat /tango/logs/process/pm.log | awk '/""$pmlogException1""/ && /""$pmlogException2""/ && /""$pmlogstodayDD""/' | wc -l"
                    elif [ "$pmlogExceptionTimeWindow" == "hour" ] || [ "$pmlogExceptionTimeWindow" == "Hour" ] || [ "$pmlogExceptionTimeWindow" == "HOUR" ]; then
                        countException=$(cat /tango/logs/process/pm.log | awk "/$pmlogException1/ && /$pmlogException2/" | wc -l)
                        getException=$(cat /tango/logs/process/pm.log | awk "/$pmlogException1/ && /$pmlogException2/" | tail -1)
                        test="cat /tango/logs/process/pm.log | awk '/""$pmlogException1""/ && /""$pmlogException2""/' | wc -l"
                    else
                        countException=$(cat /tango/logs/process/pm.log | awk "/$pmlogException1/ && /$pmlogException2/" | wc -l)
                        getException=$(cat /tango/logs/process/pm.log | awk "/$pmlogException1/ && /$pmlogException2/" | tail -1)
                        test="cat /tango/logs/process/pm.log | awk '/""$pmlogException1""/ && /""$pmlogException2""/' | wc -l"
                        overthelastMessage="times"
                    fi
                    if [ $countException -ge $pmlogExceptionThreshold ];then
                        if [ "$pmlogExceptiongravity" == "INFO" ] && [ "$verbose" != "true" ];then
                                echo -e "["$green"$pmlogExceptiongravity"$reset"] "$bold"$pmlogExceptionMessage:"$reset" The following exception has been generated in pm.log file (not in rolled over pm.log files) more than $pmlogExceptionThreshold $overthelastMessage $pmlogExceptionTimeWindow\n$getException"
                        elif [ "$pmlogExceptiongravity" == "INFO" ] && [ "$verbose" == "true" ];then
                                echo -e "["$pink"$pmlogExceptiongravity"$reset"] "$pink"$pmlogExceptionMessage: The following exception has been generated in pm.log file (not in rolled over pm.log files) more than $pmlogExceptionThreshold $overthelastMessage $pmlogExceptionTimeWindow !!\n"$reset"$getException"
                        else
                                echo -e "["$red"$pmlogExceptiongravity"$reset"] "$red"$pmlogExceptionMessage: The following exception has been generated in pm.log file (not in rolled over pm.log files) more than $pmlogExceptionThreshold $overthelastMessage $pmlogExceptionTimeWindow !!  "$reset"$getException"
                        fi
                        if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "$pmlogExceptionsupport";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
                        isPmlogsOk="no"
                    fi
                    if [ "$verbose" == "true" ];then echo ""$blue"TEST --> $test"$reset"";fi
            fi

        done
        if [ "$isPmlogsOk" == "yes" ];then
                echo "["$green"OK"$reset"] "$bold"Process Manager:"$reset" pm.log is not generating nasty exeptions"
        fi
fi

################################## Cores ##############################

echo -e ""$yellow"\n------------ Tango Core Files --------------"
getCoresDataDir=$(ls -alt /tango/data/cores/ | grep "core" | egrep -v cores_mysql | grep "$dday $DD" | tail -1)
getCoresProcessDir=$(ls -alt /tango/logs/process/ | grep "core" | grep "$dday $DD" | tail -1)
getCoresMysqlDir=$(ls -alt /tango/data/cores/cores_mysql/ | grep "core" | grep "$dday $DD" | tail -1)
isThereCore="no"
foundACore="no"

if [ ! -z "$getCoresDataDir" ];then
        getCoreFile=$(echo "$getCoresDataDir" | awk '{print $9}')
        getCoreDir="/tango/data/cores/"
        getCoreLine=$(file /tango/data/cores/$getCoreFile)
        echo "["$red"ALERT"$reset"] "$bold"/tango/data/cores/$getCoreFile:"$reset" was generated today !!"$red" $getCoreLine"$reset""
        isThereCore="yes"
        foundACore="yes"
fi
if [ ! -z "$getCoresProcessDir" ] && [ "$foundACore" == "no" ];then
        getCoreFile=$(echo "$getCoresProcessDir" | awk '{print $9}')
        getCoreLine=$(file /tango/logs/process/$getCoreFile)
        echo "["$red"ALERT"$reset"] "$bold"/tango/logs/process/$getCoreFile:"$reset" was generated today !!"$red" $getCoreLine"$reset""
        isThereCore="yes"
fi
if [ ! -z "$getCoresMysqlDir" ];then
        getCoreFile=$(echo "$getCoresMysqlDir" | awk '{print $9}')
        getCoreLine=$(file /tango/data/cores/cores_mysql/$getCoreFile)
        echo "["$red"ALERT"$reset"] "$bold"/tango/data/cores/cores_mysql/$getCoreFile:"$reset" was generated today !!"$red" $getCoreLine"$reset""
        isThereCore="yes"
fi

if [ "$isThereCore" == "no" ];then
        echo -e "["$green"OK"$reset"] "$bold"Tango Process Cores:"$reset" None so far today"
else
        if [ "$verbose" == "true" ];then num=0;IFS=';' read -ra supportline <<< "How to dump the core: gdb <Tango binary> $getCoreFile, then run \"bt\" then run \"bt full\" and run \"quit\" to exit";for printsupportline in "${supportline[@]}"; do num=$((num+1));echo ""$blue"SUPPORT$num--> $printsupportline"$reset"";done;fi
fi
if [ "$verbose" == "true" ];then echo ""$blue"TEST --> Run: ls -altr /tango/data/cores/$getCoreFile"$reset"";fi


#######################################################################

mv $DIR/$tempFile /tango/logs/COSTAFF/trash/

echo -e ""$yellow"\n--------------------------------------------"
echo "Finished."
echo "Run "$reset""$bold"healthcheck -v "$reset""$yellow"to display (in blue) tests and suggested supports"
echo ""$reset""
export TERM=$getTERM

######## Flag -c is present
elif [ ! -z "$clusterList" ];then
        yellow=`tput setaf 3`
        reset=`tput sgr0`
        green=`tput setaf 2`
        if [ "$clusterList" == "all" ];then
                clusterList=$hosts_List
        fi
        AllOk='yes'

        for getHost in ${clusterList//,/ }
        do
                clusterListTitle="noyet"
                if [ "$getHost" == "$hostname" ];then
                        $DIR/healthcheck.sh -m noColors > $DIR/.healthcheck_Cluster_output.txt
                else
                        ssh tango@$getHost "$DIR/healthcheck.sh -m noColors" > $DIR/.healthcheck_Cluster_output.txt
                fi
                getAlertsFailures=$(cat $DIR/.healthcheck_Cluster_output.txt | grep 'Failure\|ALERT\|WARNING\|INFO')
                while read in
                do
                        if [ ! -z "$in" ];then
                                if [ "$clusterListTitle" == "noyet" ];then echo -e ""$yellow"\n----------------- $getHost -----------------"$reset"";clusterListTitle="already";fi
                                echo "$in"
                                AllOk='no'
                        fi
                done <<< "$getAlertsFailures"
        done

        if [ "$mode" == "sendIfOk" ] && [ "$AllOk" == "yes" ];then
                echo "Everything ["$green"OK"$reset"] Monitored hosts: $hosts_List"
        fi
        mv $DIR/.healthcheck_Cluster_output.txt /tango/logs/COSTAFF/trash/





######## Flag -m is getIssues or sendIfOk and -c is not defined

elif [ "$mode" == "getIssues" ] || [ "$mode" == "sendIfOk" ];then

        sendSMS()
        {
                timeStampNow=$(perl -e '@d=localtime time(); printf "%4d%02d%02d%02d%02d%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1],$d[0]')
                submitTimeStampNow=$(perl -e '@d=localtime time(); printf "%4d-%02d-%02d %02d:%02d:%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1],$d[0]')
                spPasswordNow=$(echo -n "001952Tiws123$timeStampNow" | md5sum | cut -d'-' -f1 | tr -d '[:space:]')

                for getSendSMS_msisdn in ${sendSMS_msisdn//,/ }
                do
                        echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>
        <soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:loc=\"http://www.csapi.org/schema/parlayx/management/manage/v1_0/local\" xmlns:v2=\"http://www.huawei.com.cn/schema/common/v2_1\">
          <soapenv:Header>
              <v2:RequestSOAPHeader>
                 <v2:spId>001952</v2:spId>
                 <v2:spPassword>$spPasswordNow</v2:spPassword>
                 <v2:serviceId>0100983000</v2:serviceId>
                 <v2:timeStamp>$timeStampNow</v2:timeStamp>
              </v2:RequestSOAPHeader>
          </soapenv:Header>
          <soapenv:Body>
              <loc:sendSms>
                 <!--1 or more repetitions:-->
                 <loc:addresses>$getSendSMS_msisdn</loc:addresses>
                 <!--Optional:-->
                 <loc:senderName>1413</loc:senderName>
        <loc:message>$1 [Time: $submitTimeStampNow] $2</loc:message>
                 </loc:sendSms>
          </soapenv:Body>
        </soapenv:Envelope>" > $DIR/sendSMS.xml
                        curl -k --header "Content-Type: application/soap+xml" --header "SOAPAction: post" --data @$DIR/sendSMS.xml  https://187.8.166.33:443/osg/services/SendSmsService
                        sleep 5
                done
        }

        logging()
        {
                if [ ! -d /tango/logs/healthcheck/archive/ ];then
                        mkdir -p /tango/logs/healthcheck/archive
                fi
                extTimeStampNow=$(perl -e '@d=localtime time(); printf "%4d%02d%02d_%02d%02d%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1],$d[0]')
                if [ -f /tango/logs/healthcheck/healthcheck.log ];then
                        getOldExtTimeStampNow=$(cat /tango/logs/healthcheck/healthcheck.log | grep "Log Time" | cut -d"=" -f2 | tr -d " ")
                        mv /tango/logs/healthcheck/healthcheck.log /tango/logs/healthcheck/healthcheck.log.$getOldExtTimeStampNow
                fi
                echo "                              Log Time=$extTimeStampNow" > /tango/logs/healthcheck/healthcheck.log
                $DIR/healthcheck.sh -m noColors >> /tango/logs/healthcheck/healthcheck.log
                for getReport_Type_List in ${report_Type_List//,/ }
                do
                        get_Issues=$(cat /tango/logs/healthcheck/healthcheck.log | grep 'ALERT\|Failure')
                        get_Issues1=$(cat /tango/logs/healthcheck/healthcheck.log | grep "$getReport_Type_List")
                        if [ ! -z "$get_Issues" ] || [ ! -z "$get_Issues1" ];then
                                chmod 6750 /tango/logs/healthcheck/healthcheck.log
                        else
                                chmod 750 /tango/logs/healthcheck/healthcheck.log
                        fi
                done
        }

        email()
        {
        if [ "$1" == "prepare" ];then
                getIssueType=$(echo "$3" | cut -d "]" -f1)
                getIssueCont=$(echo "$3" | cut -d "]" -f2)
                getCore=$(echo "$getIssueCont" | grep "core" | grep "500" | cut -d":" -f1)
                if [ ! -z "$getCore" ];then
                        getReportedCores=$(cat $DIR/.cores | grep "$getCore")
                        if [ -z "$getReportedCores" ];then
                                echo "$getCore" >> $DIR/.cores
                                sendEmail="yes"
                        else
                                sendEmail="no"
                        fi
                else
                        sendEmail="yes"
                fi
                listMailTo=(`echo ${email_To_list} | sed 's/,/ /g'`)
                listMailToLength=${#listMailTo[@]}
                echo "<table cellpadding=\"2\" style=\"white-space:wrap;border:1px solid black;border-collapse:collapse\">" >> $DIR/.emailTmpFile.txt
                echo "<tr><th align=\"left\"; bgcolor='#ff0000'>$getIssueType] $2</th></tr>" >> $DIR/.emailTmpFile.txt
                echo "<tr><td>$getIssueCont</td></tr>" >> $DIR/.emailTmpFile.txt
                echo "" >> $DIR/.emailTmpFile.txt
                echo "</table>" >> $DIR/.emailTmpFile.txt
        elif [ "$1" == "send" ] && [ "$sendEmail" == "yes" ];then
                for (( j=0;j<$listMailToLength;j++))
                do
                        /tango/scripts/Generic/tools/sendMail_SMTPS.pl -f no-reply-mcm.businesssolutions@telefonica.com  -t ${listMailTo[$j]} -n no-reply-mcm.businesssolutions@telefonica.com -s "[Telefonica] Healthcheck" -x smtp.office365.com -U no-reply-mcm.businesssolutions@telefonica.com -P nG2T.bf9 -a "cat $DIR/.emailTmpFile.txt"
                done
        elif [ "$1" == "allOk" ];then
                messageAllOk=${2//,/<br>}
                listMailTo=(`echo ${email_To_list} | sed 's/,/ /g'`)
                listMailToLength=${#listMailTo[@]}
                echo "<table style=\"white-space:wrap;border:1px solid black;border-collapse:collapse\">" > $DIR/.emailTmpFile.txt
                echo "<tr><th style=\"padding: 5px\"; align=\"left\"; bgcolor='#00ff00'>[Everything OK]</th></tr>" >> $DIR/.emailTmpFile.txt
                echo "<tr><td style=\"padding: 6px\">$messageAllOk</td></tr>" >> $DIR/.emailTmpFile.txt
                echo "" >> $DIR/.emailTmpFile.txt
                echo "</table>" >> $DIR/.emailTmpFile.txt
                for (( j=0;j<$listMailToLength;j++))
                do
                        /tango/scripts/Generic/tools/sendMail_SMTPS.pl -f no-reply-mcm.businesssolutions@telefonica.com  -t ${listMailTo[$j]} -n no-reply-mcm.businesssolutions@telefonica.com -s "[Telefonica] Healthcheck" -x smtp.office365.com -U no-reply-mcm.businesssolutions@telefonica.com -P nG2T.bf9 -a "cat $DIR/.emailTmpFile.txt"
                done
        fi

        }



        if [ -z "$channel" ];then
                channel=sms
        else
                channel=$(echo "$channel" | tr '[:upper:]' '[:lower:]')
                hasChannelLog=$(echo "$channel" | grep "log")
                if [ ! -z "$hasChannelLog" ];then
                        logging
                        if [ "$channel" == "log" ];then
                                exit
                        fi
                fi
        fi
        hasChannelSMS=$(echo "$channel" | grep "sms")
        hasChannelEmail=$(echo "$channel" | grep "email")
        if [ $email_enable -eq 1 -a ! -z "$hasChannelEmail" ] || [ $sendSMS_enable -eq 1 -a ! -z "$hasChannelSMS" ];then
                if [ ! -f $DIR/.recordSubmitReport ];then
                        touch $DIR/.recordSubmitReport
                fi
                getBashDate=$(date "+%s")
                getBashDateNormal=(date -u -d @$getBashDate +%Y%m%d_%H%M%S)
                AllOk='yes'
                emailTmpFileCreated="no"
                for getHost in ${hosts_List//,/ }
                do
                        ssh tango@$getHost "$DIR/healthcheck.sh -m noColors" > $DIR/.healthcheck_output.txt
                        sed 's/\r//g'  /tango/scripts/Generic/Others/healthcheck/.healthcheck_output.txt > /tango/scripts/Generic/Others/healthcheck/.healthcheck_output_dos2linux.txt
                        mv /tango/scripts/Generic/Others/healthcheck/.healthcheck_output_dos2linux.txt /tango/scripts/Generic/Others/healthcheck/.healthcheck_output.txt
                        getAlertsFailures=$(cat $DIR/.healthcheck_output.txt | grep 'ALERT\|Failure')
                        while read in
                        do
                                if [ ! -z "$in" ];then
                                        checkRecordSubmitReportIn=$(echo "$in" | cut -d"]" -f2)
                                        checkRecordSubmitReport=$(cat $DIR/.recordSubmitReport | grep "$getHost" | grep "$checkRecordSubmitReportIn" | tail -1)
                                        if [ -z "$checkRecordSubmitReport" ];then
                                                recordSubmitReportID=$(head /dev/urandom | tr -dc A-Za-z0-9 | head -c 13 ; echo "$getBashDate")
                                                echo "$getBashDate;$recordSubmitReportID;[$getHost];[$getBashDateNormal];$in;SUBMITTED" >> $DIR/.recordSubmitReport
                                                submitLockout="desabled"
                                        else
                                                getRecordSubmitReportTime=$(echo "$checkRecordSubmitReport" | cut -d";" -f1)
                                                getRecordSubmitReportTimeDiff=$(printf "%s\n" $(( $getBashDate - $getRecordSubmitReportTime )))
                                                submit_lockout_time_Sec=$(( submit_lockout_time * 3600 ))
                                                if [ $getRecordSubmitReportTimeDiff -lt $submit_lockout_time_Sec ];then
                                                        submitLockout="active"
                                                else
                                                        OldRecordSubmitReportID=$(echo "$checkRecordSubmitReport" | cut -d";" -f2)
                                                        sed -i "/$OldRecordSubmitReportID/d" $DIR/.recordSubmitReport
                                                        recordSubmitReportID=$(head /dev/urandom | tr -dc A-Za-z0-9 | head -c 13 ; echo "$getBashDate")
                                                        echo "$getBashDate;$recordSubmitReportID;[$getHost];[$getBashDateNormal];$in;SUBMITTED" >> $DIR/.recordSubmitReport
                                                        submitLockout="desabled"
                                                fi
                                        fi

                                        if [ $sendSMS_enable -eq 1 ] && [ ! -z "$hasChannelSMS" ] && [ "$submitLockout" == "desabled" ];then
                                                sendSMS "[$getHost]" "$in"
                                        fi
                                        if [ $email_enable -eq 1 ] && [ ! -z "$hasChannelEmail" ] && [ "$submitLockout" == "desabled" ];then
                                                if [ "$emailTmpFileCreated" != "yes" ];then
                                                        echo > $DIR/.emailTmpFile.txt
                                                        emailTmpFileCreated="yes"
                                                fi
                                                email "prepare" "$getHost" "$in"
                                        fi
                                        AllOk='no'
                                fi
                        done <<< "$getAlertsFailures"


                        for get_Report_Type_List in ${report_Type_List//,/ }
                        do
                                getReports=$(cat $DIR/.healthcheck_output.txt | grep "$get_Report_Type_List" | egrep -v ALERT | egrep -v Failure)
                                while read in
                                do
                                        if [ ! -z "$in" ];then
                                                if [ $sendSMS_enable -eq 1 ] && [ ! -z "$hasChannelSMS" ] && [ "$submitLockout" == "desabled" ];then
                                                        sendSMS "[$getHost]" "$in"
                                                fi
                                                if [ $email_enable -eq 1 ] && [ ! -z "$hasChannelEmail" ] && [ "$submitLockout" == "desabled" ];then
                                                if [ "$emailTmpFileCreated" != "yes" ];then
                                                        echo > $DIR/.emailTmpFile.txt
                                                        emailTmpFileCreated="yes"
                                                fi
                                                        email "prepare" "$getHost" "$in"
                                                fi
                                                AllOk='no'
                                        fi
                                done <<< "$getReports"
                        done
                done
                        if [ $email_enable -eq 1 ] && [ ! -z "$hasChannelEmail" ];then
                                email "send"
                        fi

                if [ "$mode" == "sendIfOk" ] && [ ! -z "$hosts_List" ] && [ "$AllOk" == "yes" ];then
                        if [ $sendSMS_enable -eq 1 ] && [ ! -z "$hasChannelSMS" ];then
                                sendSMS "Everything OK. Monitored hosts: $hosts_List" "DRE Telefonica"
                        fi
                        if [ $sendSMS_enable -eq 1 ] && [ ! -z "$hasChannelEmail" ];then
                                email "allOk" "No Issues found. Monitored hosts:<br><br> $hosts_List"
                        fi
                fi
        else
                echo "`tput setaf 1`Wrong option in flag -r. Options: SMS,Email or Log, try again. Bye`tput sgr0`"
        fi



fi
fi