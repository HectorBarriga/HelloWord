#!/bin/bash
isADir=$(echo "$1" | grep "/" | wc -l)
if [ -z "$1" ] && [ -z "$2" ];then
        echo "`tput setaf 1`Find what? Example:  `tput setaf 2`findword /tango/config/ port`tput sgr0`"
elif [ $isADir -eq 0 ] && [ -z "$2" ];then
        result=$(find ./ -type f | xargs grep -l "$1" 2>/dev/null)
        echo $result | tr " " "\n"
elif [ "$isADir" -eq 0 ] && [ ! -z "$2" ] && [ "$2" != "-v" ];then
        echo "`tput setaf 1`Find where? Example:  `tput setaf 2`findword /tango/config/ $2`tput sgr0`"
elif [ "$isADir" -eq 0 ] && [ ! -z "$2" ] && [ "$2" == "-v" ];then
        result=$(find ./ -type f | xargs grep "$1" 2>/dev/null)
        echo "$result" | while read in
        do
                echo "`tput setaf 2`"
                echo "$in" | cut -d":" -f1
                echo -n "`tput sgr0`"
                echo "$in" | cut -d":" -f2
        done
elif [ "$isADir" -eq 1 ] && [ -z "$2" ];then
        echo "`tput setaf 1`Find what? Example:  `tput setaf 2`findword $1 port`tput sgr0`"
else
        if [ -z "$3" ];then
                result=$(find $1 -type f | xargs grep -l "$2" 2>/dev/null)
                echo $result | tr " " "\n"
        elif [ "$3" == "-v" ];then
                result=$(find $1 -type f | xargs grep "$2" 2>/dev/null)
                echo "$result" | while read in
                do
                        echo "`tput setaf 2`"
                        echo "$in" | cut -d":" -f1
                        echo -n "`tput sgr0`"
                        echo "$in" | cut -d":" -f2
                done
        fi
fi