#!/bin/bash
##############################################################################
# Filename:    BackupAndRestoreBCSdatabase.sh
# Revision:    $Revision: 0.1.0 $
# Author:      Hector Barriga
#
# This sh script is to provide the following functionalities:
# 1. List current Jobs stored in BCM database (GUI)
# 2. Export Old Jobs
# 3. Search Exported Old Jobs
# 4. Import & Restore Old Jobs
#
# It is recommended to use the GUI but if you need to remove ALL jobs faster, you can use this script
#
# This sh script is mainly used for housekeeping.
# Copyright (c) Tango Telecom 2015
#
# All rights reserved.
# This document contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or
# in part is expressly prohibited, except as may be specifically
# authorized by prior written agreement or permission of Tango Telecom.
##############################################################################
# version 0.1.0 - First version
#
##############################################################################

# Initial Arguments
dryRun=0
today=$(perl -e '@d=localtime time(); printf "__%4d-%02d-%02d\n", $d[5]+1900,$d[4]+1')
todate=$(perl -e '@d=localtime time(); printf "%4d-%02d-%02d\n", $d[5]+1900,$d[4]+1,$d[3]')
timenow=$(perl -e '@d=localtime time(); printf "%4d%02d%02d %02d:%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1]')
lognow=$(perl -e '@d=localtime time(); printf "%4d-%02d-%02d\n", $d[5]+1900,$d[4]+1,$d[3]')
importnow=$(perl -e '@d=localtime time(); printf "%4d%02d%02d%02d%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1]')
red=`tput setaf 1`
green=`tput setaf 2`
yellow=`tput setaf 3`
pink=`tput setaf 5`
blue=`tput setaf 6`
reset=`tput sgr0`

# Subroutines

printLog()
{
echo "[ $timenow ] $1" >> /tango/logs/bcs/BackupAndRestoreBCMdatabase_$lognow.log
}

login()
{
clear
echo ""
echo "-------------------------------------------------------------------------------------------------------------------"
echo "|${yellow}    ____                   _                         ___       ____                 _                            ${reset}|"
echo "|${yellow}   | __ )    __ _    ___  | | __  _   _   _ __      ( _ )     |  _ \    ___   ___  | |_    ___    _ __    ___    ${reset}|"
echo "|${yellow}   |  _ \   / _  |  / __| | |/ / | | | | | '_ \     / _ \/\   | |_) |  / _ \ / __| | __|  / _ \  | '__|  / _ \   ${reset}|"
echo "|${yellow}   | |_) | | (_| | | (__  |   <  | |_| | | |_) |   | (_>  <   |  _ <  |  __/ \__ \ | |_  | (_) | | |    |  __/   ${reset}|"
echo "|${yellow}   |____/   \__,_|  \___| |_|\_\  \__,_| | .__/     \___/\/   |_| \_\  \___| |___/  \__|  \___/  |_|     \___|   ${reset}|"
echo "|${yellow}                                         |_|                                                                     ${reset}|"
echo "|${yellow}                      ___    ___   __  __        _          _            _                                       ${reset}|"
echo "|${yellow}                     | _ )  / __| |  \/  |    __| |  __ _  | |_   __ _  | |__   __ _   ___  ___                  ${reset}|"
echo "|${yellow}                     | _ \ | (__  | |\/| |   / _  | / _' | |  _| / _' | | '_ \ / _' | (_-< / -_)                 ${reset}|"
echo "|${yellow}                     |___/  \___| |_|  |_|   \__,_| \__,_|  \__| \__,_| |_.__/ \__,_| /__/ \___|                 ${reset}|"
echo "|                                                                                                                 |"
echo "|${yellow}                                              2015 Tango Telecom                                                 ${reset}|"
echo "|${yellow}                                                 Version 0.1.0                                                   ${reset}|"
echo "|                                                                                                                 |"
echo "|                                                                                                                 |"
echo "|     LOGIN                                                                                                       |"
echo "|                                                                                                                 |"
echo "|     Enger MySQL user and password:                                                                              |"
echo "|                                                                                                                 |"
echo "|                                                                                                                 |"
echo "| ${red}control+C to Cancel${reset}                                                                                             |"
echo "-------------------------------------------------------------------------------------------------------------------"
echo ""
}

mainmenu()
{
clear
echo ""
echo "-------------------------------------------------------------------------------------------------------------------"
echo "|${yellow}    ____                   _                         ___       ____                 _                            ${reset}|"
echo "|${yellow}   | __ )    __ _    ___  | | __  _   _   _ __      ( _ )     |  _ \    ___   ___  | |_    ___    _ __    ___    ${reset}|"
echo "|${yellow}   |  _ \   / _  |  / __| | |/ / | | | | | '_ \     / _ \/\   | |_) |  / _ \ / __| | __|  / _ \  | '__|  / _ \   ${reset}|"
echo "|${yellow}   | |_) | | (_| | | (__  |   <  | |_| | | |_) |   | (_>  <   |  _ <  |  __/ \__ \ | |_  | (_) | | |    |  __/   ${reset}|"
echo "|${yellow}   |____/   \__,_|  \___| |_|\_\  \__,_| | .__/     \___/\/   |_| \_\  \___| |___/  \__|  \___/  |_|     \___|   ${reset}|"
echo "|${yellow}                                         |_|                                                                     ${reset}|"
echo "|${yellow}                      ___    ___   __  __        _          _            _                                       ${reset}|"
echo "|${yellow}                     | _ )  / __| |  \/  |    __| |  __ _  | |_   __ _  | |__   __ _   ___  ___                  ${reset}|"
echo "|${yellow}                     | _ \ | (__  | |\/| |   / _  | / _' | |  _| / _' | | '_ \ / _' | (_-< / -_)                 ${reset}|"
echo "|${yellow}                     |___/  \___| |_|  |_|   \__,_| \__,_|  \__| \__,_| |_.__/ \__,_| /__/ \___|                 ${reset}|"
echo "|                                                                                                                 |"
echo "|${yellow}                                              2015 Tango Telecom                                                 ${reset}|"
echo "|${yellow}                                                 Version 0.1.0                                                   ${reset}|"
echo "|                                                                                                                 |"
echo "|                                                                                                                 |"
echo "| WELCOME                                                                                                         |"
echo "|                                                                                                                 |"
echo "| 1. List current Jobs stored in BCM database (GUI)                                                               |"
echo "| 2. Export Old Jobs                                                                                              |"
echo "| 3. Search Exported Old Jobs                                                                                     |"
echo "| 4. Import & Restore Old Jobs                                                                                    |"
echo "| 5. Exit                                                                                                         |"
echo "|                                                                                                                 |"
echo "| ${red}control+C to Cancel${reset}                                                                                             |"
echo "-------------------------------------------------------------------------------------------------------------------"
echo ""
}

listJobs_menu()
{
clear
echo ""
echo "-------------------------------------------------------------------------------------------------------------------"
echo "|${yellow}     _      ___   ___   _____      ___   _   _   ___   ___   ___   _  _   _____        _    ___    ___           ${reset}|"
echo "|${yellow}    | |    |_ _| / __| |_   _|    / __| | | | | | _ \ | _ \ | __| | \| | |_   _|    _ | |  / _ \  | _ )   ___    ${reset}|"
echo "|${yellow}    | |__   | |  \__ \   | |     | (__  | |_| | |   / |   / | _|  | .  |   | |     | || | | (_) | | _ \ (_-<     ${reset}|"
echo "|${yellow}    |____| |___| |___/   |_|      \___|  \___/  |_|_\ |_|_\ |___| |_|\_|   |_|      \__/   \___/  |___/ /__/     ${reset}|"
echo "|${yellow}                      ___    ___   __  __        _          _            _                                       ${reset}|"
echo "|${yellow}                     | _ )  / __| |  \/  |    __| |  __ _  | |_   __ _  | |__   __ _   ___  ___                  ${reset}|"
echo "|${yellow}                     | _ \ | (__  | |\/| |   / _  | / _' | |  _| / _' | | '_ \ / _' | (_-< / -_)                 ${reset}|"
echo "|${yellow}                     |___/  \___| |_|  |_|   \__,_| \__,_|  \__| \__,_| |_.__/ \__,_| /__/ \___|                 ${reset}|"
echo "|                                                                                                                 |"
echo "|${yellow}                                              2015 Tango Telecom                                                 ${reset}|"
echo "|${yellow}                                                 Version 0.1.0                                                   ${reset}|"
echo "|                                                                                                                 |"
echo "|                                                                                                                 |"
echo "| List current Jobs stored in BCM database (GUI):                                                                 |"
echo "|                                                                                                                 |"
echo "| 1. All Jobs [ It will display $1 jobs!! ]                                                                       |"
echo "| 2. By Number of Days Before Today                                                                               |"
echo "| 3. By Job Status                                                                                                |"
echo "| 4. By Number of Days Before Today & Job Status                                                                  |"
echo "| 5. Exit                                                                                                         |"
echo "|                                                                                                                 |"
echo "| ${red}control+C to Cancel${reset}                                                                                             |"
echo "-------------------------------------------------------------------------------------------------------------------"
echo ""
}

ExportJobs_menu()
{
clear
echo ""
echo "-------------------------------------------------------------------------------------------------------------------"
echo "|${yellow}        ______                                 _        ____    _       _          _           _                 ${reset}|"
echo "|${yellow}       |  ____|                               | |      / __ \  | |     | |        | |         | |                ${reset}|"
echo "|${yellow}       | |__    __  __  _ __     ___    _ __  | |_    | |  | | | |   __| |        | |   ___   | |__    ___       ${reset}|"
echo "|${yellow}       |  __|   \ \/ / | '_ \   / _ \  | '__| | __|   | |  | | | |  / _  |    _   | |  / _ \  | '_ \  / __|      ${reset}|"
echo "|${yellow}       | |____   >  <  | |_) | | (_) | | |    | |_    | |__| | | | | (_| |   | |__| | | (_) | | |_) | \__ \      ${reset}|"
echo "|${yellow}       |______| /_/\_\ | .__/   \___/  |_|     \__|    \____/  |_|  \__,_|    \____/   \___/  |_.__/  |___/      ${reset}|"
echo "|${yellow}                       | |                                                                                       ${reset}|"
echo "|${yellow}                       |_|                                                                                       ${reset}|"
echo "|${yellow}                      ___    ___   __  __        _          _            _                                       ${reset}|"
echo "|${yellow}                     | _ )  / __| |  \/  |    __| |  __ _  | |_   __ _  | |__   __ _   ___  ___                  ${reset}|"
echo "|${yellow}                     | _ \ | (__  | |\/| |   / _  | / _' | |  _| / _' | | '_ \ / _' | (_-< / -_)                 ${reset}|"
echo "|${yellow}                     |___/  \___| |_|  |_|   \__,_| \__,_|  \__| \__,_| |_.__/ \__,_| /__/ \___|                 ${reset}|"
echo "|                                                                                                                 |"
echo "|${yellow}                                              2015 Tango Telecom                                                 ${reset}|"
echo "|${yellow}                                                 Version 0.1.0                                                   ${reset}|"
echo "|                                                                                                                 |"
echo "|                                                                                                                 |"
echo "| 1. Enter DATE                                                                                                   |"
echo "| 2. Enter Number of DAYS BEFORE TODAY                                                                            |"
echo "| 3. Exit                                                                                                         |"
echo "|                                                                                                                 |"
echo "| ${red}control+C to Cancel${reset}                                                                                             |"
echo "-------------------------------------------------------------------------------------------------------------------"
echo ""
}

ExportJobs_days_menu()
{
clear
echo ""
echo "-------------------------------------------------------------------------------------------------------------------"
echo "|${yellow}        ______                                 _        ____    _       _          _           _                 ${reset}|"
echo "|${yellow}       |  ____|                               | |      / __ \  | |     | |        | |         | |                ${reset}|"
echo "|${yellow}       | |__    __  __  _ __     ___    _ __  | |_    | |  | | | |   __| |        | |   ___   | |__    ___       ${reset}|"
echo "|${yellow}       |  __|   \ \/ / | '_ \   / _ \  | '__| | __|   | |  | | | |  / _  |    _   | |  / _ \  | '_ \  / __|      ${reset}|"
echo "|${yellow}       | |____   >  <  | |_) | | (_) | | |    | |_    | |__| | | | | (_| |   | |__| | | (_) | | |_) | \__ \      ${reset}|"
echo "|${yellow}       |______| /_/\_\ | .__/   \___/  |_|     \__|    \____/  |_|  \__,_|    \____/   \___/  |_.__/  |___/      ${reset}|"
echo "|${yellow}                       | |                                                                                       ${reset}|"
echo "|${yellow}                       |_|                                                                                       ${reset}|"
echo "|${yellow}                      ___    ___   __  __        _          _            _                                       ${reset}|"
echo "|${yellow}                     | _ )  / __| |  \/  |    __| |  __ _  | |_   __ _  | |__   __ _   ___  ___                  ${reset}|"
echo "|${yellow}                     | _ \ | (__  | |\/| |   / _  | / _' | |  _| / _' | | '_ \ / _' | (_-< / -_)                 ${reset}|"
echo "|${yellow}                     |___/  \___| |_|  |_|   \__,_| \__,_|  \__| \__,_| |_.__/ \__,_| /__/ \___|                 ${reset}|"
echo "|                                                                                                                 |"
echo "|${yellow}                                              2015 Tango Telecom                                                 ${reset}|"
echo "|${yellow}                                                 Version 0.1.0                                                   ${reset}|"
echo "|                                                                                                                 |"
echo "|                                                                                                                 |"
echo "| BY YOU ENTERING THE NUMBER OF DAYS BEFORE TODAY:                                                                |"
echo "|     * I shall keep the Jobs that were created within those days in the BCM database (GUI)                       |"
echo "|     * I shall export the old Jobs into /backup/ partition                                                       |"
echo "|                                                                                                                 |"
echo "|                                                                                                                 |"
echo "| ${red}control+C to Cancel${reset}                                                                                             |"
echo "-------------------------------------------------------------------------------------------------------------------"
echo ""
}

ExportJobs_date_menu()
{
clear
echo ""
echo "-------------------------------------------------------------------------------------------------------------------"
echo "|${yellow}        ______                                 _        ____    _       _          _           _                 ${reset}|"
echo "|${yellow}       |  ____|                               | |      / __ \  | |     | |        | |         | |                ${reset}|"
echo "|${yellow}       | |__    __  __  _ __     ___    _ __  | |_    | |  | | | |   __| |        | |   ___   | |__    ___       ${reset}|"
echo "|${yellow}       |  __|   \ \/ / | '_ \   / _ \  | '__| | __|   | |  | | | |  / _  |    _   | |  / _ \  | '_ \  / __|      ${reset}|"
echo "|${yellow}       | |____   >  <  | |_) | | (_) | | |    | |_    | |__| | | | | (_| |   | |__| | | (_) | | |_) | \__ \      ${reset}|"
echo "|${yellow}       |______| /_/\_\ | .__/   \___/  |_|     \__|    \____/  |_|  \__,_|    \____/   \___/  |_.__/  |___/      ${reset}|"
echo "|${yellow}                       | |                                                                                       ${reset}|"
echo "|${yellow}                       |_|                                                                                       ${reset}|"
echo "|${yellow}                      ___    ___   __  __        _          _            _                                       ${reset}|"
echo "|${yellow}                     | _ )  / __| |  \/  |    __| |  __ _  | |_   __ _  | |__   __ _   ___  ___                  ${reset}|"
echo "|${yellow}                     | _ \ | (__  | |\/| |   / _  | / _' | |  _| / _' | | '_ \ / _' | (_-< / -_)                 ${reset}|"
echo "|${yellow}                     |___/  \___| |_|  |_|   \__,_| \__,_|  \__| \__,_| |_.__/ \__,_| /__/ \___|                 ${reset}|"
echo "|                                                                                                                 |"
echo "|${yellow}                                              2015 Tango Telecom                                                 ${reset}|"
echo "|${yellow}                                                 Version 0.1.0                                                   ${reset}|"
echo "|                                                                                                                 |"
echo "|                                                                                                                 |"
echo "| BY YOU ENTERING THE DATE:                                                                                       |"
echo "|     * I shall keep the Jobs that were created AFTER the DATE in the BCM database (GUI)                          |"
echo "|     * I shall export the Jobs BEFORE and ON the DATE into /backup/ partition                                    |"
echo "|                                                                                                                 |"
echo "| NOTE: You must enter de DATE in this format yyyy-mm-dd Example: 2014-10-08                                      |"
echo "|                                                                                                                 |"
echo "| ${red}control+C to Cancel${reset}                                                                                             |"
echo "-------------------------------------------------------------------------------------------------------------------"
echo ""
}

searchExported_msisdn_menu()
{
clear
echo ""
echo "-------------------------------------------------------------------------------------------------------------------"
echo "|${yellow}    _____                                _         ______                                 _                _     ${reset}|"
echo "|${yellow}   / ____|                              | |       |  ____|                               | |              | |    ${reset}|"
echo "|${yellow}  | (___     ___    __ _   _ __    ___  | |__     | |__    __  __  _ __     ___    _ __  | |_    ___    __| |    ${reset}|"
echo "|${yellow}   \___ \   / _ \  / _  | | '__|  / __| | '_ \    |  __|   \ \/ / | '_ \   / _ \  | '__| | __|  / _ \  / _  |    ${reset}|"
echo "|${yellow}   ____) | |  __/ | (_| | | |    | (__  | | | |   | |____   >  <  | |_) | | (_) | | |    | |_  |  __/ | (_| |    ${reset}|"
echo "|${yellow}  |_____/   \___|  \__,_| |_|     \___| |_| |_|   |______| /_/\_\ | .__/   \___/  |_|     \__|  \___|  \__,_|    ${reset}|"
echo "|${yellow}                                                                  | |                                            ${reset}|"
echo "|${yellow}                                                                  |_|                                            ${reset}|"
echo "|${yellow}                                    ___    _      _        _         _                                           ${reset}|"
echo "|${yellow}                                   / _ \  | |  __| |    _ | |  ___  | |__   ___                                  ${reset}|"
echo "|${yellow}                                  | (_) | | | / _  |   | || | / _ \ | '_ \ (_-<                                  ${reset}|"
echo "|${yellow}                                   \___/  |_| \__,_|    \__/  \___/ |_.__/ /__/                                  ${reset}|"
echo "|                                                                                                                 |"
echo "|${yellow}                                              2015 Tango Telecom                                                 ${reset}|"
echo "|${yellow}                                                 Version 0.1.0                                                   ${reset}|"
echo "|                                                                                                                 |"
echo "|                                                                                                                 |"
echo "| SEARCH ALL JOBS BY MSISDN OVER A PERIOD OF TIME                                                                 |"
echo "|                                                                                                                 |"
echo "| 1. Enter subscriber's msisdn                                                                                    |"
echo "|                                                                                                                 |"
echo "| ${red}control+C to Cancel${reset}                                                                                             |"
echo "-------------------------------------------------------------------------------------------------------------------"
echo ""
}

searchExported_start_menu()
{
clear
echo ""
echo "-------------------------------------------------------------------------------------------------------------------"
echo "|${yellow}    _____                                _         ______                                 _                _     ${reset}|"
echo "|${yellow}   / ____|                              | |       |  ____|                               | |              | |    ${reset}|"
echo "|${yellow}  | (___     ___    __ _   _ __    ___  | |__     | |__    __  __  _ __     ___    _ __  | |_    ___    __| |    ${reset}|"
echo "|${yellow}   \___ \   / _ \  / _  | | '__|  / __| | '_ \    |  __|   \ \/ / | '_ \   / _ \  | '__| | __|  / _ \  / _  |    ${reset}|"
echo "|${yellow}   ____) | |  __/ | (_| | | |    | (__  | | | |   | |____   >  <  | |_) | | (_) | | |    | |_  |  __/ | (_| |    ${reset}|"
echo "|${yellow}  |_____/   \___|  \__,_| |_|     \___| |_| |_|   |______| /_/\_\ | .__/   \___/  |_|     \__|  \___|  \__,_|    ${reset}|"
echo "|${yellow}                                                                  | |                                            ${reset}|"
echo "|${yellow}                                                                  |_|                                            ${reset}|"
echo "|${yellow}                                    ___    _      _        _         _                                           ${reset}|"
echo "|${yellow}                                   / _ \  | |  __| |    _ | |  ___  | |__   ___                                  ${reset}|"
echo "|${yellow}                                  | (_) | | | / _  |   | || | / _ \ | '_ \ (_-<                                  ${reset}|"
echo "|${yellow}                                   \___/  |_| \__,_|    \__/  \___/ |_.__/ /__/                                  ${reset}|"
echo "|                                                                                                                 |"
echo "|${yellow}                                              2015 Tango Telecom                                                 ${reset}|"
echo "|${yellow}                                                 Version 0.1.0                                                   ${reset}|"
echo "|                                                                                                                 |"
echo "|                                                                                                                 |"
echo "| SEARCH ALL JOBS BY MSISDN OVER A PERIOD OF TIME                                                                 |"
echo "|                                                                                                                 |"
echo "| 2. Enter Start Date.                                                                                            |"
echo "|                                                                                                                 |"
echo "| NOTE: You must enter de DATE in this format yyyy-mm-dd Example: 2014-10-08                                      |"
echo "|                                                                                                                 |"
echo "| ${red}control+C to Cancel${reset}                                                                                             |"
echo "-------------------------------------------------------------------------------------------------------------------"
echo ""
}

searchExported_end_menu()
{
clear
echo ""
echo "-------------------------------------------------------------------------------------------------------------------"
echo "|${yellow}    _____                                _         ______                                 _                _     ${reset}|"
echo "|${yellow}   / ____|                              | |       |  ____|                               | |              | |    ${reset}|"
echo "|${yellow}  | (___     ___    __ _   _ __    ___  | |__     | |__    __  __  _ __     ___    _ __  | |_    ___    __| |    ${reset}|"
echo "|${yellow}   \___ \   / _ \  / _  | | '__|  / __| | '_ \    |  __|   \ \/ / | '_ \   / _ \  | '__| | __|  / _ \  / _  |    ${reset}|"
echo "|${yellow}   ____) | |  __/ | (_| | | |    | (__  | | | |   | |____   >  <  | |_) | | (_) | | |    | |_  |  __/ | (_| |    ${reset}|"
echo "|${yellow}  |_____/   \___|  \__,_| |_|     \___| |_| |_|   |______| /_/\_\ | .__/   \___/  |_|     \__|  \___|  \__,_|    ${reset}|"
echo "|${yellow}                                                                  | |                                            ${reset}|"
echo "|${yellow}                                                                  |_|                                            ${reset}|"
echo "|${yellow}                                    ___    _      _        _         _                                           ${reset}|"
echo "|${yellow}                                   / _ \  | |  __| |    _ | |  ___  | |__   ___                                  ${reset}|"
echo "|${yellow}                                  | (_) | | | / _  |   | || | / _ \ | '_ \ (_-<                                  ${reset}|"
echo "|${yellow}                                   \___/  |_| \__,_|    \__/  \___/ |_.__/ /__/                                  ${reset}|"
echo "|                                                                                                                 |"
echo "|${yellow}                                              2015 Tango Telecom                                                 ${reset}|"
echo "|${yellow}                                                 Version 0.1.0                                                   ${reset}|"
echo "|                                                                                                                 |"
echo "|                                                                                                                 |"
echo "| SEARCH ALL JOBS BY MSISDN OVER A PERIOD OF TIME                                                                 |"
echo "|                                                                                                                 |"
echo "| 3. Enter END Date.                                                                                              |"
echo "|                                                                                                                 |"
echo "| NOTE: You must enter de DATE in this format yyyy-mm-dd Example: 2014-10-08                                      |"
echo "|                                                                                                                 |"
echo "| ${red}control+C to Cancel${reset}                                                                                             |"
echo "-------------------------------------------------------------------------------------------------------------------"
echo ""
}

Imported_menu()
{
clear
echo ""
echo "-------------------------------------------------------------------------------------------------------------------"
echo "|${yellow}  _____                                      _                  _____                 _                          ${reset}|"
echo "|${yellow} |_   _|                                    | |       ___      |  __ \               | |                         ${reset}|"
echo "|${yellow}   | |    _ __ ___    _ __     ___    _ __  | |_     ( _ )     | |__) |   ___   ___  | |_    ___    _ __    ___  ${reset}|"
echo "|${yellow}   | |   | '_   _ \  | '_ \   / _ \  | '__| | __|    / _ \/\   |  _  /   / _ \ / __| | __|  / _ \  | '__|  / _ \ ${reset}|"
echo "|${yellow}  _| |_  | | | | | | | |_) | | (_) | | |    | |_    | (_>  <   | | \ \  |  __/ \__ \ | |_  | (_) | | |    |  __/ ${reset}|"
echo "|${yellow} |_____| |_| |_| |_| | .__/   \___/  |_|     \__|    \___/\/   |_|  \_\  \___| |___/  \__|  \___/  |_|     \___| ${reset}|"
echo "|${yellow}                     | |                                                                                         ${reset}|"
echo "|${yellow}                     |_|                                                                                         ${reset}|"
echo "|${yellow}                                    ___    _      _        _         _                                           ${reset}|"
echo "|${yellow}                                   / _ \  | |  __| |    _ | |  ___  | |__   ___                                  ${reset}|"
echo "|${yellow}                                  | (_) | | | / _  |   | || | / _ \ | '_ \ (_-<                                  ${reset}|"
echo "|${yellow}                                   \___/  |_| \__,_|    \__/  \___/ |_.__/ /__/                                  ${reset}|"
echo "|                                                                                                                 |"
echo "|${yellow}                                              2015 Tango Telecom                                                 ${reset}|"
echo "|${yellow}                                                 Version 0.1.0                                                   ${reset}|"
echo "|                                                                                                                 |"
echo "|                                                                                                                 |"
echo "| IMPORT EXPORTED JOBS BACK INTO BCM (GUI)                                                                        |"
echo "|                                                                                                                 |"
echo "| 1. Import all Jobs by msisdn over a period of time                                                              |"
echo "| 2. Import an especific Job by JobID                                                                             |"
echo "|                                                                                                                 |"
echo "| ${red}control+C to Cancel${reset}                                                                                             |"
echo "-------------------------------------------------------------------------------------------------------------------"
echo ""
}

Imported_msisdn_menu()
{
clear
echo ""
echo "-------------------------------------------------------------------------------------------------------------------"
echo "|${yellow}  _____                                      _                  _____                 _                          ${reset}|"
echo "|${yellow} |_   _|                                    | |       ___      |  __ \               | |                         ${reset}|"
echo "|${yellow}   | |    _ __ ___    _ __     ___    _ __  | |_     ( _ )     | |__) |   ___   ___  | |_    ___    _ __    ___  ${reset}|"
echo "|${yellow}   | |   | '_   _ \  | '_ \   / _ \  | '__| | __|    / _ \/\   |  _  /   / _ \ / __| | __|  / _ \  | '__|  / _ \ ${reset}|"
echo "|${yellow}  _| |_  | | | | | | | |_) | | (_) | | |    | |_    | (_>  <   | | \ \  |  __/ \__ \ | |_  | (_) | | |    |  __/ ${reset}|"
echo "|${yellow} |_____| |_| |_| |_| | .__/   \___/  |_|     \__|    \___/\/   |_|  \_\  \___| |___/  \__|  \___/  |_|     \___| ${reset}|"
echo "|${yellow}                     | |                                                                                         ${reset}|"
echo "|${yellow}                     |_|                                                                                         ${reset}|"
echo "|${yellow}                                    ___    _      _        _         _                                           ${reset}|"
echo "|${yellow}                                   / _ \  | |  __| |    _ | |  ___  | |__   ___                                  ${reset}|"
echo "|${yellow}                                  | (_) | | | / _  |   | || | / _ \ | '_ \ (_-<                                  ${reset}|"
echo "|${yellow}                                   \___/  |_| \__,_|    \__/  \___/ |_.__/ /__/                                  ${reset}|"
echo "|                                                                                                                 |"
echo "|${yellow}                                              2015 Tango Telecom                                                 ${reset}|"
echo "|${yellow}                                                 Version 0.1.0                                                   ${reset}|"
echo "|                                                                                                                 |"
echo "|                                                                                                                 |"
echo "| IMPORT ALL JOBS BY MSISDN OVER A PERIOD OF TIME                                                                 |"
echo "|                                                                                                                 |"
echo "| 1. Enter subscriber's msisdn                                                                                    |"
echo "|                                                                                                                 |"
echo "| ${red}control+C to Cancel${reset}                                                                                             |"
echo "-------------------------------------------------------------------------------------------------------------------"
echo ""
}

Imported_start_menu()
{
clear
echo ""
echo "-------------------------------------------------------------------------------------------------------------------"
echo "|${yellow}  _____                                      _                  _____                 _                          ${reset}|"
echo "|${yellow} |_   _|                                    | |       ___      |  __ \               | |                         ${reset}|"
echo "|${yellow}   | |    _ __ ___    _ __     ___    _ __  | |_     ( _ )     | |__) |   ___   ___  | |_    ___    _ __    ___  ${reset}|"
echo "|${yellow}   | |   | '_   _ \  | '_ \   / _ \  | '__| | __|    / _ \/\   |  _  /   / _ \ / __| | __|  / _ \  | '__|  / _ \ ${reset}|"
echo "|${yellow}  _| |_  | | | | | | | |_) | | (_) | | |    | |_    | (_>  <   | | \ \  |  __/ \__ \ | |_  | (_) | | |    |  __/ ${reset}|"
echo "|${yellow} |_____| |_| |_| |_| | .__/   \___/  |_|     \__|    \___/\/   |_|  \_\  \___| |___/  \__|  \___/  |_|     \___| ${reset}|"
echo "|${yellow}                     | |                                                                                         ${reset}|"
echo "|${yellow}                     |_|                                                                                         ${reset}|"
echo "|${yellow}                                    ___    _      _        _         _                                           ${reset}|"
echo "|${yellow}                                   / _ \  | |  __| |    _ | |  ___  | |__   ___                                  ${reset}|"
echo "|${yellow}                                  | (_) | | | / _  |   | || | / _ \ | '_ \ (_-<                                  ${reset}|"
echo "|${yellow}                                   \___/  |_| \__,_|    \__/  \___/ |_.__/ /__/                                  ${reset}|"
echo "|                                                                                                                 |"
echo "|${yellow}                                              2015 Tango Telecom                                                 ${reset}|"
echo "|${yellow}                                                 Version 0.1.0                                                   ${reset}|"
echo "|                                                                                                                 |"
echo "|                                                                                                                 |"
echo "| IMPORT ALL JOBS BY MSISDN OVER A PERIOD OF TIME                                                                 |"
echo "|                                                                                                                 |"
echo "| 2. Enter Start Date.                                                                                            |"
echo "|                                                                                                                 |"
echo "| NOTE: You must enter de DATE in this format yyyy-mm-dd Example: 2014-10-08                                      |"
echo "|                                                                                                                 |"
echo "| ${red}control+C to Cancel${reset}                                                                                             |"
echo "-------------------------------------------------------------------------------------------------------------------"
echo ""
}

Imported_end_menu()
{
clear
echo ""
echo "-------------------------------------------------------------------------------------------------------------------"
echo "|${yellow}  _____                                      _                  _____                 _                          ${reset}|"
echo "|${yellow} |_   _|                                    | |       ___      |  __ \               | |                         ${reset}|"
echo "|${yellow}   | |    _ __ ___    _ __     ___    _ __  | |_     ( _ )     | |__) |   ___   ___  | |_    ___    _ __    ___  ${reset}|"
echo "|${yellow}   | |   | '_   _ \  | '_ \   / _ \  | '__| | __|    / _ \/\   |  _  /   / _ \ / __| | __|  / _ \  | '__|  / _ \ ${reset}|"
echo "|${yellow}  _| |_  | | | | | | | |_) | | (_) | | |    | |_    | (_>  <   | | \ \  |  __/ \__ \ | |_  | (_) | | |    |  __/ ${reset}|"
echo "|${yellow} |_____| |_| |_| |_| | .__/   \___/  |_|     \__|    \___/\/   |_|  \_\  \___| |___/  \__|  \___/  |_|     \___| ${reset}|"
echo "|${yellow}                     | |                                                                                         ${reset}|"
echo "|${yellow}                     |_|                                                                                         ${reset}|"
echo "|${yellow}                                    ___    _      _        _         _                                           ${reset}|"
echo "|${yellow}                                   / _ \  | |  __| |    _ | |  ___  | |__   ___                                  ${reset}|"
echo "|${yellow}                                  | (_) | | | / _  |   | || | / _ \ | '_ \ (_-<                                  ${reset}|"
echo "|${yellow}                                   \___/  |_| \__,_|    \__/  \___/ |_.__/ /__/                                  ${reset}|"
echo "|                                                                                                                 |"
echo "|${yellow}                                              2015 Tango Telecom                                                 ${reset}|"
echo "|${yellow}                                                 Version 0.1.0                                                   ${reset}|"
echo "|                                                                                                                 |"
echo "|                                                                                                                 |"
echo "| IMPORT ALL JOBS BY MSISDN OVER A PERIOD OF TIME                                                                 |"
echo "|                                                                                                                 |"
echo "| 3. Enter END Date.                                                                                              |"
echo "|                                                                                                                 |"
echo "| NOTE: You must enter de DATE in this format yyyy-mm-dd Example: 2014-10-08                                      |"
echo "|                                                                                                                 |"
echo "| ${red}control+C to Cancel${reset}                                                                                             |"
echo "-------------------------------------------------------------------------------------------------------------------"
echo ""
}

Imported_jobid_menu()
{
clear
echo ""
echo "-------------------------------------------------------------------------------------------------------------------"
echo "|${yellow}  _____                                      _                  _____                 _                          ${reset}|"
echo "|${yellow} |_   _|                                    | |       ___      |  __ \               | |                         ${reset}|"
echo "|${yellow}   | |    _ __ ___    _ __     ___    _ __  | |_     ( _ )     | |__) |   ___   ___  | |_    ___    _ __    ___  ${reset}|"
echo "|${yellow}   | |   | '_   _ \  | '_ \   / _ \  | '__| | __|    / _ \/\   |  _  /   / _ \ / __| | __|  / _ \  | '__|  / _ \ ${reset}|"
echo "|${yellow}  _| |_  | | | | | | | |_) | | (_) | | |    | |_    | (_>  <   | | \ \  |  __/ \__ \ | |_  | (_) | | |    |  __/ ${reset}|"
echo "|${yellow} |_____| |_| |_| |_| | .__/   \___/  |_|     \__|    \___/\/   |_|  \_\  \___| |___/  \__|  \___/  |_|     \___| ${reset}|"
echo "|${yellow}                     | |                                                                                         ${reset}|"
echo "|${yellow}                     |_|                                                                                         ${reset}|"
echo "|${yellow}                                    ___    _      _        _         _                                           ${reset}|"
echo "|${yellow}                                   / _ \  | |  __| |    _ | |  ___  | |__   ___                                  ${reset}|"
echo "|${yellow}                                  | (_) | | | / _  |   | || | / _ \ | '_ \ (_-<                                  ${reset}|"
echo "|${yellow}                                   \___/  |_| \__,_|    \__/  \___/ |_.__/ /__/                                  ${reset}|"
echo "|                                                                                                                 |"
echo "|${yellow}                                              2015 Tango Telecom                                                 ${reset}|"
echo "|${yellow}                                                 Version 0.1.0                                                   ${reset}|"
echo "|                                                                                                                 |"
echo "|                                                                                                                 |"
echo "| IMPORT AN ESPECIFIC JOB BY JobId                                                                                |"
echo "|                                                                                                                 |"
echo "| 1. Enter JobId.                                                                                                 |"
echo "|                                                                                                                 |"
echo "|                                                                                                                 |"
echo "| ${red}control+C to Cancel${reset}                                                                                             |"
echo "-------------------------------------------------------------------------------------------------------------------"
echo ""
}



listJobs_All()
{
echo ""
echo "${yellow}-----------------------------------------------1. List all Jobs ------------------------------------------------${reset}"
echo ""
echo ""
echo ""
echo "${pink}--------------------------------------------------------------"
echo "|  start_date  | Job id |  NAME"
echo "--------------------------------------------------------------${reset}"
echo "select start_date,id,NAME from jobs;" | mysql -u $mysqluser -p$password broadcast | egrep -v start_date | awk '{print "|  "$1"  |  "$2"  |  "$3}'
echo "${pink}--------------------------------------------------------------${reset}"
echo "Bye."
echo ""
}

listJobs_date()
{
echo ""
echo "${yellow}---------------------------------- 2. List Jobs For the last $days --------------------------------------${reset}"
echo ""
echo ""
echo ""
echo "${pink}--------------------------------------------------------------"
echo "|  start_date  | Job id |  NAME"
echo "--------------------------------------------------------------${reset}"
echo "select start_date,id,NAME from jobs where start_date > now() - INTERVAL $days day;" | mysql -u $mysqluser -p$password broadcast | egrep -v start_date | awk '{print "|  "$1"  |  "$2"  |  "$3}'
echo "${pink}--------------------------------------------------------------${reset}"
echo "Bye."
echo ""
}

listJobs_status()
{
echo ""
echo "${yellow}---------------------------------- 3. List Jobs By Job Status $days --------------------------------------${reset}"
echo ""
echo ""
echo ""
echo "${pink}--------------------------------------------------------------"
echo "|  start_date  | Job id | status |  NAME"
echo "--------------------------------------------------------------${reset}"
echo "select start_date,id,status,NAME from jobs where status like '$1' or status like '$2' or status like '$3';" | mysql -u $mysqluser -p$password broadcast | egrep -v start_date | awk '{print "|  "$1"  |  "$2"  |  "$3" | " $4}'
echo "${pink}--------------------------------------------------------------${reset}"
echo "Bye."
echo ""
}

listJobs_days_status()
{
echo ""
echo "${yellow}-------------------------- 4. List Jobs For the last $days AND By Job Status $days ------------------------${reset}"
echo ""
echo ""
echo ""
echo "${pink}--------------------------------------------------------------"
echo "|  start_date  | Job id | status |  NAME"
echo "--------------------------------------------------------------${reset}"
echo "select start_date,id,status,NAME from jobs where start_date > now() - INTERVAL $1 day and status like '$2' or status like '$3' or status like '$4';" | mysql -u $mysqluser -p$password broadcast | egrep -v start_date | awk '{print "|  "$1"  |  "$2"  |  "$3" | " $4}'
echo "select start_date,id,status,NAME from jobs where start_date > now() - INTERVAL $1 day and status like '$2' or status like '$3' or status like '$4';"
echo "${pink}--------------------------------------------------------------${reset}"
echo "Bye."
echo ""
}

exportAndDumpJobsAndCampaignLinksForDate()
{
echo "select id,start_date from jobs where start_date <= '$1';" | /opt/mysql/bin/mysql -u $mysqluser -p$password broadcast | egrep -v id > /tango/scripts/Generic/HouseKeeping/jobsid.tmp
echo "[ $timenow ] Jobs older than $1 are being exported and dumped in /backup/bcs_housekeeping/exports/ and /backup/bcs_housekeeping/dumps/ respectively, please wait..."
echo "[ $timenow ] Jobs older than $1 are being exported and dumped in /backup/bcs_housekeeping/exports/ and /backup/bcs_housekeeping/dumps/ respectively, please wait..." >> /tango/logs/bcs/BackupAndRestoreBCMdatabase_$lognow.log
echo ""
cat /tango/scripts/Generic/HouseKeeping/jobsid.tmp | while read in;do
        idjob=$(echo $in | awk '{print $1}');
        ext=$(echo $in | awk '{print $1"_"$2}');
        echo "select * into outfile '/backup/bcs_housekeeping/exports/job_message_info_$ext.txt' FIELDS TERMINATED BY '|' LINES TERMINATED BY '\n' FROM job_message_info WHERE job_oid='$idjob';" | /opt/mysql/bin/mysql -u $mysqluser -p$password broadcast
        echo "${pink}[ $timenow ] Exporting Job $idjob into /backup/ partition ..........${reset}"
        echo "${pink}[ $timenow ] Exporting Job $idjob into /backup/ partition ..........${reset}" >> /tango/logs/bcs/BackupAndRestoreBCMdatabase_$lognow.log
        echo "select * into outfile '/backup/bcs_housekeeping/exports/job_message_info_$ext.txt' FIELDS TERMINATED BY '|' LINES TERMINATED BY '\n' FROM job_message_info WHERE job_oid='$idjob';"

        echo "select * into outfile '/backup/bcs_housekeeping/exports/campaign_jobs_$ext.txt' FIELDS TERMINATED BY '|' LINES TERMINATED BY '\n' FROM campaign_jobs WHERE job_id='$idjob';" | /opt/mysql/bin/mysql -u $mysqluser -p$password broadcast
        echo "select * into outfile '/backup/bcs_housekeeping/exports/campaign_jobs_$ext.txt' FIELDS TERMINATED BY '|' LINES TERMINATED BY '\n' FROM campaign_jobs WHERE job_id='$idjob';"
        echo "select * into outfile '/backup/bcs_housekeeping/exports/jobs_$ext.txt' FIELDS TERMINATED BY '|' LINES TERMINATED BY '\n' FROM jobs WHERE id='$idjob';" | /opt/mysql/bin/mysql -u $mysqluser -p$password broadcast
        echo "select * into outfile '/backup/bcs_housekeeping/exports/jobs_$ext.txt' FIELDS TERMINATED BY '|' LINES TERMINATED BY '\n' FROM jobs WHERE id='$idjob';"

        echo "select * into outfile '/backup/bcs_housekeeping/exports/job_reports_$ext.txt' FIELDS TERMINATED BY '|' LINES TERMINATED BY '\n' FROM job_reports WHERE id='$idjob';" | /opt/mysql/bin/mysql -u $mysqluser -p$password broadcast
        echo "select * into outfile '/backup/bcs_housekeeping/exports/job_reports_$ext.txt' FIELDS TERMINATED BY '|' LINES TERMINATED BY '\n' FROM job_reports WHERE id='$idjob';"

        echo "select * into outfile '/backup/bcs_housekeeping/exports/message_statistics_$ext.txt' FIELDS TERMINATED BY '|' LINES TERMINATED BY '\n' FROM message_statistics WHERE id='$idjob';" | /opt/mysql/bin/mysql -u $mysqluser -p$password /opt/mysql/bin/mysql
        echo "select * into outfile '/backup/bcs_housekeeping/exports/message_statistics_$ext.txt' FIELDS TERMINATED BY '|' LINES TERMINATED BY '\n' FROM message_statistics WHERE id='$idjob';"

        echo "select * into outfile '/backup/bcs_housekeeping/exports/messages_$ext.txt' FIELDS TERMINATED BY '|' LINES TERMINATED BY '\n' FROM messages_$idjob;"| /opt/mysql/bin/mysql -u $mysqluser -p$password broadcast
        echo "select * into outfile '/backup/bcs_housekeeping/exports/messages_$ext.txt' FIELDS TERMINATED BY '|' LINES TERMINATED BY '\n' FROM messages_$idjob;"

        /opt/mysql/bin/mysqldump broadcast -u $mysqluser -p$password messages_$idjob > /backup/bcs_housekeeping/dumps/messages_$ext.dump;
        echo "mysqldump broadcast -u $mysqluser -p$password messages_$idjob > /backup/bcs_housekeeping/dumps/messages_$ext.dump;"
        echo "${pink}---------------------------------------------------------${reset}"

done
}

deleteJobsAndCampaignLinksForDate()
{
echo ""
echo "${pink}====================================================================="
echo "Jobs older than $1 are being cleant from BCM database, please wait..."
echo "=====================================================================${reset}"
echo ""
echo "Jobs older than $1 are being cleant from BCM database, please wait..." >> /tango/logs/bcs/BackupAndRestoreBCMdatabase_$lognow.log
cat /tango/scripts/Generic/HouseKeeping/jobsid.tmp | while read in;do
        idjob=$(echo $in | awk '{print $1}');
        echo "${pink}Housekeeping for Job $idjob ........................${reset}"
        echo "${pink}Housekeeping for Job $idjob ........................${reset}" >> /tango/logs/bcs/BackupAndRestoreBCMdatabase_$lognow.log
        echo "DELETE FROM job_message_info WHERE job_oid=$idjob;" | mysql -u $mysqluser -p$password broadcast;
        echo "DELETE FROM job_message_info WHERE job_oid=$idjob;"
        echo "DELETE FROM  campaign_jobs WHERE job_id=$idjob;" | mysql -u $mysqluser -p$password broadcast;
        echo "DELETE FROM  campaign_jobs WHERE job_id=$idjob;"
        echo "DELETE FROM jobs WHERE id=$idjob;" | mysql -u $mysqluser -p$password broadcast;
        echo "DELETE FROM jobs WHERE id=$idjob;"
        echo "DROP TABLE messages_$idjob;" | mysql -u $mysqluser -p$password broadcast;
        echo "DROP TABLE messages_$idjob;"
        echo "${pink}---------------------------------------------------------${reset}"
done

rm /tango/scripts/Generic/HouseKeeping/jobsid.tmp
echo "Finished, Bye"
echo "Finished, Bye" >> /tango/logs/bcs/BackupAndRestoreBCMdatabase_$lognow.log
echo ""
}

searchExported()
{
i=0
while(true); do
        if [[ "$extdate" != $3 ]]; then
                extdate=$(date +%Y-%m-%d -d "$2 + $i day")
                getJobfile=$(find /backup/bcs_housekeeping/exports/messages*$extdate.txt -type f | xargs grep -l "$1")
                if [ ! -z "$getJobfile" ]; then
                        touch /tango/scripts/Generic/HouseKeeping/foundjob.tmp
                        echo "$getJobfile" >> /tango/scripts/Generic/HouseKeeping/foundjob.tmp
                fi
                let i=i+1
        else
                echo ""
                echo "${pink}----------------------------------------------------"
                echo "| ${reset}$1${pink} was found in the following jobs: "
                echo "----------------------------------------------------${reset}"
                cat /tango/scripts/Generic/HouseKeeping/foundjob.tmp | while read in; do
                        getJobId=$(ls $in | cut -d_ -f3)
                        getJobStartDate=$(cat $in | grep $1| cut -d'|' -f8)
                        getJobStartTime=$(cat $in | grep $1| cut -d'|' -f9)
                        getJobstatus=$(cat $in |  grep $1| cut -d'|' -f4)
                        smpplink=$(cat $in |  grep $1| cut -d'|' -f6)
                        getMessage=$(cat $in |  grep $1| cut -d'|' -f2)
                        echo "${pink}| Job Id :${reset} $getJobId"
                        echo "${pink}| Start Date and Time :${reset} $getJobStartDate $getJobStartTime"
                        echo "${pink}| Message Status :${reset} $getJobstatus"
                        echo "${pink}| SMPP Link : ${reset} $smpplink"
                        echo "${pink}| Message :${reset} $getMessage"
                        echo "${pink}----------------------------------------------------${reset}"
                done
                echo ""
                rm /tango/scripts/Generic/HouseKeeping/foundjob.tmp
                break
        fi
done
}

Imported()
{
i=0
while(true); do
        if [[ "$extdate" != $3 ]]; then
                extdate=$(date +%Y-%m-%d -d "$2 + $i day")
                getJobfile=$(find /backup/bcs_housekeeping/exports/messages*$extdate.txt -type f | xargs grep -l "$1")
                if [ ! -z "$getJobfile" ]; then
                        touch /tango/scripts/Generic/HouseKeeping/foundjob.tmp
                        echo "$getJobfile" >> /tango/scripts/Generic/HouseKeeping/foundjob.tmp
                fi
                let i=i+1
        else
                echo ""
                echo "${pink}----------------------------------------------------"
                echo "| ${reset}$1${pink} was found in the following jobs: "
                echo "----------------------------------------------------${reset}"
                cat /tango/scripts/Generic/HouseKeeping/foundjob.tmp | while read in; do
                        getJobId=$(ls $in | cut -d_ -f3)
                        getJobStartDate=$(cat $in | grep $1| cut -d'|' -f8)
                        getJobStartTime=$(cat $in | grep $1| cut -d'|' -f9)
                        getJobstatus=$(cat $in |  grep $1| cut -d'|' -f4)
                        smpplink=$(cat $in |  grep $1| cut -d'|' -f6)
                        getMessage=$(cat $in |  grep $1| cut -d'|' -f2)
                        echo "${pink}| Job_Id :${reset} $getJobId"
                        echo "${pink}| Start Date and Time :${reset} $getJobStartDate $getJobStartTime"
                        echo "${pink}| Message Status :${reset} $getJobstatus"
                        echo "${pink}| SMPP Link : ${reset} $smpplink"
                        echo "${pink}| Message :${reset} $getMessage"
                        echo "${pink}----------------------------------------------------${reset}"
                done
                break
        fi
done
echo ""
echo -n "Would you like to import all Jobs into BCM database ? [y/n] > "
read confirm
if [ "$confirm" == "y" ]; then
        echo ""
        c=0
        numjobs=$(cat /tango/scripts/Generic/HouseKeeping/foundjob.tmp | wc -l)
        cat /tango/scripts/Generic/HouseKeeping/foundjob.tmp | while read in; do
                getJobId=$(ls $in | cut -d_ -f3)
                cp /tango/scripts/Generic/HouseKeeping/JobIdTemplate.cvs /tango/data/bcs/fileload/search/JobId$getJobId$importnow.cvs
                getNewJobId=$(echo "select id from jobs where NAME like 'JobId$getJobId$importnow%';" | mysql -u $mysqluser -p$password broadcast | egrep -v id)
                echo "Restoring Job $getJobId into BCM tables, processing..."
                echo "Restoring Job $getJobId into BCM tables, processing..." >> /tango/logs/bcs/BackupAndRestoreBCMdatabase_$lognow.log
                while [ -z "$getNewJobId" ];do
                        getNewJobId=$(echo "select id from jobs where NAME like 'JobId$getJobId$importnow%';" | mysql -u $mysqluser -p$password broadcast | egrep -v id)
                        sleep 1
                done
                echo "drop table messages_$getNewJobId;" | mysql -u $mysqluser -p$password broadcast
                echo "drop table messages_$getNewJobId;" >> /tango/logs/bcs/BackupAndRestoreBCMdatabase_$lognow.log

                #RECOVER messages_xxxx TABLES
                mysql -u $mysqluser -p$password broadcast < /backup/bcs_housekeeping/dumps/messages_$getJobId*.dump
                echo "rename table messages_$getJobId to messages_$getNewJobId;" | mysql -u $mysqluser -p$password broadcast
                echo "rename table messages_$getJobId to messages_$getNewJobId;" >> /tango/logs/bcs/BackupAndRestoreBCMdatabase_$lognow.log

                #RECOVER jobs VALUES
                NAME=$(cat /backup/bcs_housekeeping/exports/jobs_$getJobId*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f2)
                start_time=$(cat /backup/bcs_housekeeping/exports/jobs_$getJobId*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f4)
                description=$(cat /backup/bcs_housekeeping/exports/jobs_$getJobId*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f5)
                status=$(cat /backup/bcs_housekeeping/exports/jobs_$getJobId*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f6)
                start_date=$(cat /backup/bcs_housekeeping/exports/jobs_$getJobId*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f7)
                expiry_date=$(cat /backup/bcs_housekeeping/exports/jobs_$getJobId*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f8)
                expiry_time=$(cat /backup/bcs_housekeeping/exports/jobs_$getJobId*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f9)
                end_submit_date=$(cat /backup/bcs_housekeeping/exports/jobs_$getJobId*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f10)
                end_submit_time=$(cat /backup/bcs_housekeeping/exports/jobs_$getJobId*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f11)
                source_address=$(cat /backup/bcs_housekeeping/exports/jobs_$getJobId*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f12)
                user_id=$(cat /backup/bcs_housekeeping/exports/jobs_$getJobId*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f15)
                delivery_receipts_enabled=$(cat /backup/bcs_housekeeping/exports/jobs_$getJobId*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f20)
                message=$(cat /backup/bcs_housekeeping/exports/jobs_$getJobId*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f21)
                filenames=$(cat /backup/bcs_housekeeping/exports/jobs_$getJobId*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f22)
                ip_address=$(cat /backup/bcs_housekeeping/exports/jobs_$getJobId*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f24)
                message_type=$(cat /backup/bcs_housekeeping/exports/jobs_$getJobId*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f27)
                message_encoding=$(cat /backup/bcs_housekeeping/exports/jobs_$getJobId*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f28)
                job_type=$(cat /backup/bcs_housekeeping/exports/jobs_$getJobId*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f31)
                preferred_message_rate=$(cat /backup/bcs_housekeeping/exports/jobs_$getJobId*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f33)
                priority=$(cat /backup/bcs_housekeeping/exports/jobs_$getJobId*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f34)
                ignore_blackout_periods=$(cat /backup/bcs_housekeeping/exports/jobs_$getJobId*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f35)
                ignore_whiteblacklists=$(cat /backup/bcs_housekeeping/exports/jobs_$getJobId*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f36)
                ignore_campaign_message_limits=$(cat /backup/bcs_housekeeping/exports/jobs_$getJobId*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f37)

                echo "UPDATE jobs SET NAME='IMPORTED $importnow Original JobId $getJobId NAME $NAME',start_time='$start_time',description='$description',status='$status',start_date='$start_date',expiry_date='$expiry_date',expiry_time='$expiry_time',end_submit_date='$end_submit_date',end_submit_time='$end_submit_time',source_address='$source_address',user_id=$user_id,delivery_receipts_enabled='$delivery_receipts_enabled',message='$message',filenames='$filenames',ip_address='$ip_address',message_type='$message_type',message_encoding='$message_encoding',job_type=$job_type,preferred_message_rate='$preferred_message_rate',priority=$priority,ignore_blackout_periods=$ignore_blackout_periods,ignore_whiteblacklists=$ignore_whiteblacklists,ignore_campaign_message_limits=$ignore_campaign_message_limits WHERE id = $getNewJobId ;" | mysql -u $mysqluser -p$password broadcast

                echo "UPDATE jobs SET NAME='IMPORTED $importnow Original JobId $getJobId NAME $NAME',start_time='$start_time',description='$description',status='$status',start_date='$start_date',expiry_date='$expiry_date',expiry_time='$expiry_time',end_submit_date='$end_submit_date',end_submit_time='$end_submit_time',source_address='$source_address',user_id=$user_id,delivery_receipts_enabled='$delivery_receipts_enabled',message='$message',filenames='$filenames',ip_address='$ip_address',message_type='$message_type',message_encoding='$message_encoding',job_type=$job_type,preferred_message_rate='$preferred_message_rate',priority=$priority,ignore_blackout_periods=$ignore_blackout_periods,ignore_whiteblacklists=$ignore_whiteblacklists,ignore_campaign_message_limits=$ignore_campaign_message_limits WHERE id = $getNewJobId ;" >> /tango/logs/bcs/BackupAndRestoreBCMdatabase_$lognow.log

                #RECOVER message_statistics VALUES
                Isdeliverydeleted=$(cat /backup/bcs_housekeeping/exports/message_statistics_$getJobId*.txt | cut -d'|' -f2 | egrep -v "No such file or directory")
                if [ ! -z "$Isdelivery_deleted" ]; then
                delivery_deleted=$(cat /backup/bcs_housekeeping/exports/message_statistics_$getJobId*.txt | cut -d'|' -f2)
                delivery_delivered=$(cat /backup/bcs_housekeeping/exports/message_statistics_$getJobId*.txt | cut -d'|' -f3)
                delivery_duplicate=$(cat /backup/bcs_housekeeping/exports/message_statistics_$getJobId*.txt | cut -d'|' -f4)
                delivery_expired=$(cat /backup/bcs_housekeeping/exports/message_statistics_$getJobId*.txt | cut -d'|' -f5)
                delivery_rejected=$(cat /backup/bcs_housekeeping/exports/message_statistics_$getJobId*.txt | cut -d'|' -f6)
                delivery_undeliverable=$(cat /backup/bcs_housekeeping/exports/message_statistics_$getJobId*.txt | cut -d'|' -f7)
                delivery_unknown=$(cat /backup/bcs_housekeeping/exports/message_statistics_$getJobId*.txt | cut -d'|' -f8)
                expired_post_submission=$(cat /backup/bcs_housekeeping/exports/message_statistics_$getJobId*.txt | cut -d'|' -f9)
                expired_pre_submission=$(cat /backup/bcs_housekeeping/exports/message_statistics_$getJobId*.txt | cut -d'|' -f10)
                submits_aged=$(cat /backup/bcs_housekeeping/exports/message_statistics_$getJobId*.txt | cut -d'|' -f11)
                submits_attempted=$(cat /backup/bcs_housekeeping/exports/message_statistics_$getJobId*.txt | cut -d'|' -f12)
                submits_blacklisted=$(cat /backup/bcs_housekeeping/exports/message_statistics_$getJobId*.txt | cut -d'|' -f13)
                submits_optedout=$(cat /backup/bcs_housekeeping/exports/message_statistics_$getJobId*.txt | cut -d'|' -f14)
                daily_limit_reached=$(cat /backup/bcs_housekeeping/exports/message_statistics_$getJobId*.txt | cut -d'|' -f15)
                submits_failed=$(cat /backup/bcs_housekeeping/exports/message_statistics_$getJobId*.txt | cut -d'|' -f16)
                monthly_limit_reached=$(cat /backup/bcs_housekeeping/exports/message_statistics_$getJobId*.txt | cut -d'|' -f17)
                submits_rejected=$(cat /backup/bcs_housekeeping/exports/message_statistics_$getJobId*.txt | cut -d'|' -f18)
                submits_throttled=$(cat /backup/bcs_housekeeping/exports/message_statistics_$getJobId*.txt | cut -d'|' -f19)
                submits_verified=$(cat /backup/bcs_housekeeping/exports/message_statistics_$getJobId*.txt | cut -d'|' -f20)
                weekly_limit_reached=$(cat /backup/bcs_housekeeping/exports/message_statistics_$getJobId*.txt | cut -d'|' -f21)
                submits_whitelisted=$(cat /backup/bcs_housekeeping/exports/message_statistics_$getJobId*.txt | cut -d'|' -f22)
                updated_at=$(cat /backup/bcs_housekeeping/exports/message_statistics_$getJobId*.txt | cut -d'|' -f25)

                echo "UPDATE message_statistics SET delivery_deleted=$delivery_deleted,delivery_delivered=$delivery_delivered,delivery_duplicate=$delivery_duplicate,delivery_expired=$delivery_expired,delivery_rejected=$delivery_rejected,delivery_undeliverable=$delivery_undeliverable,delivery_unknown=$expired_post_submission,expired_pre_submission=$expired_pre_submission,submits_aged=$submits_aged,submits_attempted=$submits_attempted,submits_blacklisted=$submits_blacklisted,submits_optedout=$submits_optedout,daily_limit_reached=$daily_limit_reached,submits_failed=$submits_failed,monthly_limit_reached=$monthly_limit_reached,submits_rejected=$submits_rejected,submits_throttled=$submits_throttled,submits_verified=$submits_verified,weekly_limit_reached=$weekly_limit_reached,submits_whitelisted=$submits_whitelisted,updated_at='$updated_at' WHERE id = $getNewJobId ;" >> /tango/logs/bcs/BackupAndRestoreBCMdatabase_$lognow.log
                echo "UPDATE message_statistics SET delivery_deleted=$delivery_deleted,delivery_delivered=$delivery_delivered,delivery_duplicate=$delivery_duplicate,delivery_expired=$delivery_expired,delivery_rejected=$delivery_rejected,delivery_undeliverable=$delivery_undeliverable,delivery_unknown=$expired_post_submission,expired_pre_submission=$expired_pre_submission,submits_aged=$submits_aged,submits_attempted=$submits_attempted,submits_blacklisted=$submits_blacklisted,submits_optedout=$submits_optedout,daily_limit_reached=$daily_limit_reached,submits_failed=$submits_failed,monthly_limit_reached=$monthly_limit_reached,submits_rejected=$submits_rejected,submits_throttled=$submits_throttled,submits_verified=$submits_verified,weekly_limit_reached=$weekly_limit_reached,submits_whitelisted=$submits_whitelisted,updated_at='$updated_at' WHERE id = $getNewJobId ;" | mysql -u $mysqluser -p$password broadcast
                fi


        done
        echo ""
        echo "Finished, $numjobs jobs were successfully imported. They are now available on the BCM GUI"
        echo "${red}NOTE: As per housekeeping policies, these jobs will be exported during next automatic housekeeping crontab job${reset}"
        echo "Finished, $numjobs jobs were successfully imported. They are now available on the BCM GUI" >> /tango/logs/bcs/BackupAndRestoreBCMdatabase_$lognow.log
        echo "${red}NOTE: As per housekeeping policies, these jobs will be exported during next automatic housekeeping crontab job${reset}" >> /tango/logs/bcs/BackupAndRestoreBCMdatabase_$lognow.log
else
        echo "Nothing done, Bye."
        echo "Nothing done, Bye." >> /tango/logs/bcs/BackupAndRestoreBCMdatabase_$lognow.log
fi

rm /tango/scripts/Generic/HouseKeeping/foundjob.tmp
}

Imported_JobId()
{
echo ""
echo -n "Would you like to import Job $1 into BCM database ? [y/n] > "
read confirm
if [ "$confirm" == "y" ]; then
        echo ""
        cp /tango/scripts/Generic/HouseKeeping/JobIdTemplate.cvs /tango/data/bcs/fileload/search/JobId$1$importnow.cvs
        getNewJobId=$(echo "select id from jobs where NAME like 'JobId$1$importnow%';" | mysql -u $mysqluser -p$password broadcast | egrep -v id)
        echo "Restoring Job $1 into BCM tables, processing..."
        echo "Restoring Job $1 into BCM tables, processing..." >> /tango/logs/bcs/BackupAndRestoreBCMdatabase_$lognow.log
        while [ -z "$getNewJobId" ];do
                getNewJobId=$(echo "select id from jobs where NAME like 'JobId$1$importnow%';" | mysql -u $mysqluser -p$password broadcast | egrep -v id)
        sleep 1
        done
        echo "drop table messages_$getNewJobId;" | mysql -u $mysqluser -p$password broadcast
        echo "drop table messages_$getNewJobId;" >> /tango/logs/bcs/BackupAndRestoreBCMdatabase_$lognow.log

        #RECOVER messages_xxxx TABLES
        mysql -u $mysqluser -p$password broadcast < /backup/bcs_housekeeping/dumps/messages_$1*.dump
        echo "rename table messages_$1 to messages_$getNewJobId;" | mysql -u $mysqluser -p$password broadcast
        echo "rename table messages_$1 to messages_$getNewJobId;" >> /tango/logs/bcs/BackupAndRestoreBCMdatabase_$lognow.log

        #RECOVER jobs VALUES
        NAME=$(cat /backup/bcs_housekeeping/exports/jobs_$1*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f2)
        start_time=$(cat /backup/bcs_housekeeping/exports/jobs_$1*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f4)
        description=$(cat /backup/bcs_housekeeping/exports/jobs_$1*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f5)
        status=$(cat /backup/bcs_housekeeping/exports/jobs_$1*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f6)
        start_date=$(cat /backup/bcs_housekeeping/exports/jobs_$1*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f7)
        expiry_date=$(cat /backup/bcs_housekeeping/exports/jobs_$1*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f8)
        expiry_time=$(cat /backup/bcs_housekeeping/exports/jobs_$1*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f9)
        end_submit_date=$(cat /backup/bcs_housekeeping/exports/jobs_$1*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f10)
        end_submit_time=$(cat /backup/bcs_housekeeping/exports/jobs_$1*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f11)
        source_address=$(cat /backup/bcs_housekeeping/exports/jobs_$1*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f12)
        user_id=$(cat /backup/bcs_housekeeping/exports/jobs_$1*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f15)
        delivery_receipts_enabled=$(cat /backup/bcs_housekeeping/exports/jobs_$1*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f20)
        message=$(cat /backup/bcs_housekeeping/exports/jobs_$1*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f21)
        filenames=$(cat /backup/bcs_housekeeping/exports/jobs_$1*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f22)
        ip_address=$(cat /backup/bcs_housekeeping/exports/jobs_$1*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f24)
        message_type=$(cat /backup/bcs_housekeeping/exports/jobs_$1*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f27)
        message_encoding=$(cat /backup/bcs_housekeeping/exports/jobs_$1*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f28)
        job_type=$(cat /backup/bcs_housekeeping/exports/jobs_$1*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f31)
        preferred_message_rate=$(cat /backup/bcs_housekeeping/exports/jobs_$1*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f33)
        priority=$(cat /backup/bcs_housekeeping/exports/jobs_$1*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f34)
        ignore_blackout_periods=$(cat /backup/bcs_housekeeping/exports/jobs_$1*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f35)
        ignore_whiteblacklists=$(cat /backup/bcs_housekeeping/exports/jobs_$1*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f36)
        ignore_campaign_message_limits=$(cat /backup/bcs_housekeeping/exports/jobs_$1*.txt | awk '{printf("%s",$0)}' | cut -d'|' -f37)


        echo "UPDATE jobs SET NAME='IMPORTED $importnow Original JobId $1 NAME $NAME ',start_time='$start_time',description='$description ',status='$status',start_date='$start_date',expiry_date='$expiry_date',expiry_time='$expiry_time',end_submit_date='$end_submit_date',end_submit_time='$end_submit_time',source_address='$source_address',user_id=$user_id,delivery_receipts_enabled='$delivery_receipts_enabled',message='$message ',filenames='$filenames ',ip_address='$ip_address',message_type='$message_type',message_encoding='$message_encoding',job_type=$job_type,preferred_message_rate='$preferred_message_rate',priority=$priority,ignore_blackout_periods=$ignore_blackout_periods,ignore_whiteblacklists=$ignore_whiteblacklists,ignore_campaign_message_limits=$ignore_campaign_message_limits WHERE id = $getNewJobId ;" | mysql -u $mysqluser -p$password broadcast

        echo "UPDATE jobs SET NAME='IMPORTED $importnow Original JobId $1 NAME $NAME',start_time='$start_time',description='$description',status='$status',start_date='$start_date',expiry_date='$expiry_date',expiry_time='$expiry_time',end_submit_date='$end_submit_date',end_submit_time='$end_submit_time',source_address='$source_address',user_id=$user_id,delivery_receipts_enabled='$delivery_receipts_enabled',message='$message',filenames='$filenames',ip_address='$ip_address',message_type='$message_type',message_encoding='$message_encoding',job_type=$job_type,preferred_message_rate='$preferred_message_rate',priority=$priority,ignore_blackout_periods=$ignore_blackout_periods,ignore_whiteblacklists=$ignore_whiteblacklists,ignore_campaign_message_limits=$ignore_campaign_message_limits WHERE id = $getNewJobId ;" >> /tango/logs/bcs/BackupAndRestoreBCMdatabase_$lognow.log

        #RECOVER message_statistics VALUES
        delivery_deleted=$(cat /backup/bcs_housekeeping/exports/message_statistics_$1*.txt | cut -d'|' -f2)
        delivery_delivered=$(cat /backup/bcs_housekeeping/exports/message_statistics_$1*.txt | cut -d'|' -f3)
        delivery_duplicate=$(cat /backup/bcs_housekeeping/exports/message_statistics_$1*.txt | cut -d'|' -f4)
        delivery_expired=$(cat /backup/bcs_housekeeping/exports/message_statistics_$1*.txt | cut -d'|' -f5)
        delivery_rejected=$(cat /backup/bcs_housekeeping/exports/message_statistics_$1*.txt | cut -d'|' -f6)
        delivery_undeliverable=$(cat /backup/bcs_housekeeping/exports/message_statistics_$1*.txt | cut -d'|' -f7)
        delivery_unknown=$(cat /backup/bcs_housekeeping/exports/message_statistics_$1*.txt | cut -d'|' -f8)
        expired_post_submission=$(cat /backup/bcs_housekeeping/exports/message_statistics_$1*.txt | cut -d'|' -f9)
        expired_pre_submission=$(cat /backup/bcs_housekeeping/exports/message_statistics_$1*.txt | cut -d'|' -f10)
        submits_aged=$(cat /backup/bcs_housekeeping/exports/message_statistics_$1*.txt | cut -d'|' -f11)
        submits_attempted=$(cat /backup/bcs_housekeeping/exports/message_statistics_$1*.txt | cut -d'|' -f12)
        submits_blacklisted=$(cat /backup/bcs_housekeeping/exports/message_statistics_$1*.txt | cut -d'|' -f13)
        submits_optedout=$(cat /backup/bcs_housekeeping/exports/message_statistics_$1*.txt | cut -d'|' -f14)
        daily_limit_reached=$(cat /backup/bcs_housekeeping/exports/message_statistics_$1*.txt | cut -d'|' -f15)
        submits_failed=$(cat /backup/bcs_housekeeping/exports/message_statistics_$1*.txt | cut -d'|' -f16)
        monthly_limit_reached=$(cat /backup/bcs_housekeeping/exports/message_statistics_$1*.txt | cut -d'|' -f17)
        submits_rejected=$(cat /backup/bcs_housekeeping/exports/message_statistics_$1*.txt | cut -d'|' -f18)
        submits_throttled=$(cat /backup/bcs_housekeeping/exports/message_statistics_$1*.txt | cut -d'|' -f19)
        submits_verified=$(cat /backup/bcs_housekeeping/exports/message_statistics_$1*.txt | cut -d'|' -f20)
        weekly_limit_reached=$(cat /backup/bcs_housekeeping/exports/message_statistics_$1*.txt | cut -d'|' -f21)
        submits_whitelisted=$(cat /backup/bcs_housekeeping/exports/message_statistics_$1*.txt | cut -d'|' -f22)
        updated_at=$(cat /backup/bcs_housekeeping/exports/message_statistics_$1*.txt | cut -d'|' -f25)

        echo "UPDATE message_statistics SET delivery_deleted=$delivery_deleted,delivery_delivered=$delivery_delivered,delivery_duplicate=$delivery_duplicate,delivery_expired=$delivery_expired,delivery_rejected=$delivery_rejected,delivery_undeliverable=$delivery_undeliverable,delivery_unknown=$expired_post_submission,expired_pre_submission=$expired_pre_submission,submits_aged=$submits_aged,submits_attempted=$submits_attempted,submits_blacklisted=$submits_blacklisted,submits_optedout=$submits_optedout,daily_limit_reached=$daily_limit_reached,submits_failed=$submits_failed,monthly_limit_reached=$monthly_limit_reached,submits_rejected=$submits_rejected,submits_throttled=$submits_throttled,submits_verified=$submits_verified,weekly_limit_reached=$weekly_limit_reached,submits_whitelisted=$submits_whitelisted,updated_at='$updated_at' WHERE id = $getNewJobId ;" | mysql -u $mysqluser -p$password broadcast

        echo "UPDATE message_statistics SET delivery_deleted=$delivery_deleted,delivery_delivered=$delivery_delivered,delivery_duplicate=$delivery_duplicate,delivery_expired=$delivery_expired,delivery_rejected=$delivery_rejected,delivery_undeliverable=$delivery_undeliverable,delivery_unknown=$expired_post_submission,expired_pre_submission=$expired_pre_submission,submits_aged=$submits_aged,submits_attempted=$submits_attempted,submits_blacklisted=$submits_blacklisted,submits_optedout=$submits_optedout,daily_limit_reached=$daily_limit_reached,submits_failed=$submits_failed,monthly_limit_reached=$monthly_limit_reached,submits_rejected=$submits_rejected,submits_throttled=$submits_throttled,submits_verified=$submits_verified,weekly_limit_reached=$weekly_limit_reached,submits_whitelisted=$submits_whitelisted,updated_at='$updated_at' WHERE id = $getNewJobId ;" >> /tango/logs/bcs/BackupAndRestoreBCMdatabase_$lognow.log


        echo ""
        echo "Finished. Job $1 was successfully imported. It is now available on the BCM GUI"
        echo ""
        echo "${red}NOTE: As per housekeeping policies, this job $1 will be exported during next automatic housekeeping crontab job${reset}"
        echo ""
        echo "${red}Finished. NOTE: As per housekeeping policies, this job $1 will be exported during next automatic housekeeping crontab job${reset}" >> /tango/logs/bcs/BackupAndRestoreBCMdatabase_$lognow.log
else
        echo ""
        echo "${red}Nothing done, Bye.${reset}"
        echo "Nothing done, Bye." >> /tango/logs/bcs/BackupAndRestoreBCMdatabase_$lognow.log
        echo ""
fi

}


#CLEAN temp files
tempfiles=$(ls -altr /tango/scripts/Generic/HouseKeeping/*.tmp)
if [ ! -z "$tempfiles" ];then
        rm /tango/scripts/Generic/HouseKeeping/jobsid.tmp
fi


# Start Script

#------------------------------- CRONTAB JOB or MANUAL --------------------------------------
if [ "$#" -eq  "0" ]; then


#------------------------------------- Login ------------------------------------------------
login
echo -n "Enter mysql user > "
read mysqluser
echo -n "Enter mysql password > "
read password
echo ""
checkmysqluser=$(echo "select 1;" | mysql -u $mysqluser -p$password broadcast | tail -1)
if [ "$checkmysqluser" == "1" ]; then

#----------------------------------- Main Menu ----------------------------------------------
        mainmenu
        echo ""
        echo -n "Enter option > "
        read option
        printLog "Main Menu Enter option >  $option"

        if [ "$option" == "1" ]; then
                njobs=$(echo "select count(*) from jobs;" | mysql -u $mysqluser -p$password broadcast  | egrep -v count)
                listJobs_menu $njobs
                echo ""
                echo -n "Enter option > "
                read option
                printLog "List All Jobs Menu Enter option >  $option"
                if [ "$option" == "1" ]; then
                        listJobs_All
                elif [ "$option" == "2" ]; then
                        echo -n "Enter the number of days [ Before today ]  > "
                        read days
                        listJobs_date "$days"
                elif [ "$option" == "3" ]; then
                        echo ""
                        echo "${blue}Select any of the following Job Status [Capitals]: "
                        echo "|------------------|"
                        echo "| COMPLETED        |"
                        echo "| CANCELLED        |"
                        echo "| EXPIRED          |"
                        echo "| JOB_SERVER_ERROR |"
                        echo "| SUBMIT_FAILED    |"
                        echo "| DATABASE_ERROR   |"
                        echo "| NULL             |"
                        echo "|------------------|${reset}"
                        echo ""
                        echo -n "Enter status > "
                        read status0
                        echo "Would you like to add another Job Status (Max 3)? [y/n]"
                        read more
                        if [ "$more" == "y" ]; then
                                echo -n "Enter status > "
                                read status1
                                echo "Would you like to add another Job Status (Max 3)? [y/n]"
                                read more
                                if [ "$more" == "y" ]; then
                                        echo -n "Enter status > "
                                        read status2
                                fi
                        fi
                        listJobs_status $status0 $status1 $status2
                elif [ "$option" == "4" ]; then
                        echo -n "Enter the number of days [ Before today ]  > "
                        read days
                        echo ""
                        echo "${blue}Select any of the following Job Status [Capitals]: "
                        echo "|------------------|"
                        echo "| COMPLETED        |"
                        echo "| CANCELLED        |"
                        echo "| EXPIRED          |"
                        echo "| JOB_SERVER_ERROR |"
                        echo "| SUBMIT_FAILED    |"
                        echo "| DATABASE_ERROR   |"
                        echo "| NULL             |"
                        echo "|------------------|${reset}"
                        echo ""
                        echo -n "Enter status > "
                        read status0
                        echo "Would you like to add another Job Status (Max 3)? [y/n]"
                        read more
                        if [ "$more" == "y" ]; then
                                echo -n "Enter status > "
                                read status1
                                echo "Would you like to add another Job Status (Max 3)? [y/n]"
                                read more
                                if [ "$more" == "y" ]; then
                                        echo -n "Enter status > "
                                        read status2
                                fi
                        fi
                        listJobs_days_status $days $status0 $status1 $status2
                   elif [ "$option" == "5" ]; then
                        echo ""
                        echo "Bye."
                        echo ""
                   else
                        echo ""
                        echo "${red}Wrong option, please try again, Bye.${reset}"
                        echo ""
                fi

        elif [ "$option" == "2" ]; then
                ExportJobs_menu
                echo ""
                echo -n "Enter option > "
                read option
                printLog "Export Old Jobs Menu Enter option >  $option"
                if [ "$option" == "1" ]; then
                        ExportJobs_date_menu
                        echo ""
                        echo -n "Enter DATE > "
                        read exportdate
                        length=$(echo ${#exportdate})
                        if [ "$length" != "10" ]; then
                                echo -n "$exportdate ${red}format is incorrect.${reset} Enter DATE [Example: 2014-08-10] > "
                                read exportdate
                        fi
                        length=$(echo ${#exportdate})
                        if [ "$length" == "10" ]; then
                                printLog "Enter DATE > $exportdate"
                                exportAndDumpJobsAndCampaignLinksForDate $exportdate
                                printLog "Finished exportAndDumpJobsAndCampaignLinksForDate $exportdate"
                                deleteJobsAndCampaignLinksForDate $exportdate
                                printLog "Finished deleteJobsAndCampaignLinksForDate $exportdate"
                        else
                                echo "$exportdate ${red}format is incorrect again. Bye.${reset}"
                                echo ""
                        fi

                elif [ "$option" == "2" ]; then
                        ExportJobs_days_menu
                        echo ""
                        echo -n "Enter the Number of Days Before Today > "
                        read exportdays
                        exportsecs=$((86400 * ($exportdays - 1)))
                        jobExpiryDate=$(perl -e '@d=localtime time() - $ARGV[0]; printf "%4d-%02d-%02d\n", $d[5]+1900,$d[4]+1,$d[3]' -- "$exportsecs")
                        printLog "Enter the Number of Days Before Today You Would Like To Keep in BCM Database (GUI) > $exportdays $jobExpiryDate"
                        exportAndDumpJobsAndCampaignLinksForDate $jobExpiryDate
                        printLog "Finished exportAndDumpJobsAndCampaignLinksForDate $jobExpiryDate"
                        deleteJobsAndCampaignLinksForDate $jobExpiryDate
                        printLog "Finished deleteJobsAndCampaignLinksForDate $jobExpiryDate"

                 elif [ "$option" == "3" ]; then
                        echo ""
                        echo "Bye."
                        echo ""
                 else
                        echo ""
                        echo "${red}Wrong option, please try again, Bye.${reset}"
                        echo ""
                fi

        elif [ "$option" == "3" ]; then
                searchExported_msisdn_menu
                echo ""
                echo -n "Enter msisdn [Include Country Code] > "
                read msisdn
                length=$(echo ${#msisdn})
                if [ "$length" != "11" ]; then
                        echo -n "$msisdn ${red}format is incorrect.${reset} Enter msisdn [Include Country Code] > "
                        read msisdn
                fi
                length=$(echo ${#msisdn})
                if [ "$length" == "11" ]; then
                        searchExported_start_menu
                        echo ""
                        echo -n "Enter START date > "
                        read startdate
                        length=$(echo ${#startdate})
                        if [ "$length" != "10" ]; then
                                echo -n "$startdate ${red}format is incorrect.${reset} Enter START date [Example: 2014-08-10] > "
                                read startdate
                        fi
                        length=$(echo ${#startdate})
                        if [ "$length" == "10" ]; then
                                searchExported_end_menu
                                echo ""
                                echo -n "Enter END date > "
                                read enddate
                                length=$(echo ${#enddate})
                                if [ "$length" != "10" ]; then
                                        echo -n "$enddate ${red}format is incorrect.${reset} Enter END date [Example: 2014-08-10] > "
                                        read enddate
                                fi
                                length=$(echo ${#enddate})
                                if [ "$length" == "10" ]; then
                                        searchExported $msisdn $startdate $enddate
                                        echo "Bye."
                                else
                                        echo -n "$enddate ${red}format is incorrect again. Bye.${reset}"
                                        echo ""
                                fi
                        else
                                echo -n "$startdate ${red}format is incorrect again. Bye.${reset}"
                                echo ""
                        fi
                else
                        echo -n "$msisdn ${red}format is incorrect again. Bye.${reset}"
                        echo ""
                fi

        elif [ "$option" == "4" ]; then
                Imported_menu
                echo -n "Enter option > "
                read option
                printLog "Import MainMenu Enter option >  $option"
                if [ "$option" == "1" ]; then
                        Imported_msisdn_menu
                        echo ""
                        echo -n "Enter msisdn [Include Country Code] > "
                        read msisdn
                        length=$(echo ${#msisdn})
                        if [ "$length" != "11" ]; then
                                        echo -n "$msisdn ${red}format is incorrect.${reset} Enter msisdn [Include Country Code] > "
                                        read msisdn
                        fi
                        length=$(echo ${#msisdn})
                        if [ "$length" == "11" ]; then
                                        Imported_start_menu
                                        echo ""
                                        echo -n "Enter START date > "
                                        read startdate
                                        length=$(echo ${#startdate})
                                        if [ "$length" != "10" ]; then
                                                        echo -n "$startdate ${red}format is incorrect.${reset} Enter START date [Example: 2014-08-10] > "
                                                        read startdate
                                        fi
                                        length=$(echo ${#startdate})
                                        if [ "$length" == "10" ]; then
                                                        Imported_end_menu
                                                        echo ""
                                                        echo -n "Enter END date > "
                                                        read enddate
                                                        length=$(echo ${#enddate})
                                                        if [ "$length" != "10" ]; then
                                                                        echo -n "$enddate ${red}format is incorrect.${reset} Enter END date [Example: 2014-08-10] > "
                                                                        read enddate
                                                        fi
                                                        length=$(echo ${#enddate})
                                                        if [ "$length" == "10" ]; then
                                                                        Imported $msisdn $startdate $enddate
                                                                        echo "Bye."
                                                        else
                                                                        echo -n "$enddate ${red}format is incorrect again. Bye.${reset}"
                                                                        echo ""
                                                        fi
                                        else
                                                        echo -n "$startdate ${red}format is incorrect again. Bye.${reset}"
                                                        echo ""
                                        fi
                        else
                                        echo -n "$msisdn ${red}format is incorrect again. Bye.${reset}"
                                        echo ""
                        fi
                elif [ "$option" == "2" ]; then
                        Imported_jobid_menu
                        echo -n "Enter Job Id > "
                        read jobid
                        findjob=$(find /backup/bcs_housekeeping/exports/ -name *_$jobid*)
                        if [ ! -z "$findjob" ]; then
                                echo ""
                                echo "${pink}I found the following exported files and dumps:"
                                echo "----------------------------------------------------------------${reset}"
                                find /backup/bcs_housekeeping/exports/ -name *_$jobid*
                                find /backup/bcs_housekeeping/dumps/ -name *_$jobid*
                                echo "${pink}----------------------------------------------------------------${reset}"
                                Imported_JobId $jobid
                        else
                                echo ""
                                echo "${red}Sorry, I didn't find $jobid Job, Bye.${reset}"
                                echo ""
                        fi
                else
                        echo ""
                        echo "${red}Wrong option, please try again, Bye.${reset}"
                        echo ""
                fi

        else
                echo ""
                echo "Nothing done, Bye"
                echo ""
                printLog "Nothing done, Bye"
        fi


else
    echo "${red}"
    echo "Wrong MYSQL user=${reset}$mysqluser ${red}password=${reset}$password"
    echo "${red}Please contact BCM database administrator. Bye. ${reset}"
    echo ""
    printLog "Wrong MYSQL user=$mysqluser password=$password"
    printLog "Please contact BCM database administrator. Bye."
    echo ""
fi



#---------------------------------------- CRONTAB JOB ------------------------------------------
else
        printLog "----------------------------------------------------- START $timenow ------------------------------------------------"
        printLog " "
        mysqluser=root
        password=claro123

        exportsecs=$((86400 * ($1 - 1)))
        jobExpiryDate=$(perl -e '@d=localtime time() - $ARGV[0]; printf "%4d-%02d-%02d\n", $d[5]+1900,$d[4]+1,$d[3]' -- "$exportsecs")
        deletesecs=$((86400 * ($1 - 2)))
        jobDeleteDate=$(perl -e '@d=localtime time() - $ARGV[0]; printf "%4d/%02d/%02d\n", $d[5]+1900,$d[4]+1,$d[3]' -- "$deletesecs")
        printLog "Crontab Job > Number of days Before Today: $1 Date: $jobExpiryDate"
        exportAndDumpJobsAndCampaignLinksForDate $jobExpiryDate
        rm /tango/scripts/Generic/HouseKeeping/jobsid.tmp
        printLog "Crontab Job > Finished exportAndDumpJobsAndCampaignLinksForDate $jobExpiryDate"
        printLog "Crontab Job > Housekeeping for Job older than $jobDeleteDate"
        echo "call deleteJobsAndCampaignLinksForDate('$jobDeleteDate 00:00', 0);" | /opt/mysql/bin/mysql -u $mysqluser -p$password broadcast
        printLog "call deleteJobsAndCampaignLinksForDate('$jobDeleteDate 00:00', 0);"
        printLog  "Crontab Job > Finished, Bye"

fi