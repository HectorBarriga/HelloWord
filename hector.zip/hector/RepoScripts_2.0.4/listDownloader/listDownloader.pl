#!/usr/bin/perl
##############################################################################
# Filename:    listDownloader.pl
# Revision:    $Revision: 1.1.2 $
# Author:      Hector Barriga
#
# CO Scripts:  COSC-127
#
# This perl script implements a client for the PMI List Download, List Manager and VIVO list manager web portal
#
# Copyright (c) Tango Telecom 2012-2019
#
# All rights reserved.
# This document contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or
# in part is expressly prohibited, except as may be specifically
# authorized by prior written agreement or permission of Tango Telecom.
##############################################################################
# version 1.0.0 - First version
# version 1.1.0 - To add "transfer" mode. It allow Tx downloaded lists from RTEDMZ to RTE VMs. By Hector
# version 1.1.1 - To add whitelist of permited lists names. By Hector
# version 1.1.2 - To allow to download lists from other mailbox_id. By Hector
# version 1.1.3 - Fix bug about log file listDownloader_yymmdd.log permissions - CSR-4242
# version 2.0.0 - Introduce listDownloader.pl multitenant
# version 2.0.1 - Ping remote server and die if not reachable
# Change by John Loughnane - 15th November 2022
# Autochargingrenewallist format is different so extra code required
# version 2.0.2 - Cancel unresonposive downloads
##############################################################################

use Getopt::Std;
use Net::Ping;

my @scriptPath = split '/', $0;
my $whoami=`whoami`;
chomp($whoami);
my $scriptName = $scriptPath[$#scriptPath];
my $scriptCanonicalName = (split/\./,$scriptName)[0];
$0 =~ m/(.+)[\/\\](.+)$/;
my $scriptRelativePath=$1;
my $scriptTmpFile = $scriptRelativePath."/.tmp";

# Lets not upset the machine.. ;)
setpriority(0,0,10);
#checkForRoot();
#################################### VERSION ############################
my $VERSION = "1.1.3";
my $subVersion = "\n$scriptName Script version $VERSION \n";
   $subVersion .= "Copyright by Tango Telecom 2008-2019 (c)\n";
   $subVersion .= "All rights reserved.\n\n\n";
#########################################################################
# GENERAL PARAMETERS
my $VERBOSE_FLAG =1;
my $DEST_PATH="/tango/data/$scriptName/";
my $SOURCE_PATH="/tango/data/listmanager/drop/";
my $DEBUG_FILE = "$scriptCanonicalName"."_".getLocalDateForFile();
my $DEBUG_LOGDIR = "/tango/logs/$scriptCanonicalName";
my $CURL_CMD = "/usr/bin/curl";
my $SUDO_TANGO_CMD = "sudo -u tango";
my $USERNAME = "";
my $PASSWORD = "";
my $JSESSIONID ="";
my $ELASTICDUMP="/usr/lib/node_modules/elasticdump/bin/elasticdump";
my @LINK_FILES_TO_DOWNLOAD;
my $CMD_LOGIN = "$CURL_CMD -k -u <USERNAME>:<PASSWORD> -D - -X POST -H \"Content-Type: application/x-www-form-urlencoded\" -d \"operation=LOGON&remote=<USERNAME>&password=<PASSWORD>&mailbox_server=&logon=+Iniciar\" \"https://<REMOTE_SERVER><SOURCE_PATH>\"";
my $CMD_FETCH_FILE_LIST = "$CURL_CMD -k -H \"Cookie: JSESSIONID=<SESSION_ID>\" \"https://<REMOTE_SERVER><SOURCE_PATH>?operation=DIRECTORY&mailbox_id=<MAILBOX_ID>&Submit=Directory\"";
my $CMD_DOWNLOAD_FILE = "$SUDO_TANGO_CMD $CURL_CMD -k -H \"Cookie: JSESSIONID=<SESSION_ID>\" \"https://<REMOTE_SERVER>/<URL>\" -o <FILE_OUTPUT>";
getConfigs();
my $CMD_OPEN_FILE = "$SUDO_TANGO_CMD $CURL_CMD -k -H \"Cookie: JSESSIONID=<SESSION_ID>\" \"https://<REMOTE_SERVER>/<URL>\" | awk '/$awkPermitedLists/' | wc -l";
my $host =  "IPXMIATCRTE1DMZ_drews";
my $CMD_DUMP_ALL_LISTS_FROM_ES = "$ELASTICDUMP --input=http://<USERNAME>:<PASSWORD>@<REMOTE_SERVER>:9201/<SOURCE_PATH> --limit=$limit --output=<DEST_PATH>/elasticdump_All_Lists.json.PART --type=data --transform=\"delete doc._source\" --transform=\"delete doc._index\" --transform=\"delete doc._type\" --transform=\"delete doc._score\" --concurrencyInterval=$concurrencyInterval";
my $PASSWORDLESS_FLAG =1;


getopts( "i:t:u:p:d:m:s:c:l:a:hv" );

$DEBUG_LOGDIR = $opt_l if ( defined( $opt_l) );
my $DEBUG_LOGFILE = "$DEBUG_LOGDIR/$DEBUG_FILE.$opt_m.log";
`sudo -u tango mkdir $DEBUG_LOGDIR` if ( ! -d $DEBUG_LOGDIR && $whoami ne "tango");
`mkdir $DEBUG_LOGDIR` if ( ! -d $DEBUG_LOGDIR && $whoami eq "tango");

if (!defined( $opt_t) || !defined( $opt_d) || !defined( $opt_u) || !defined( $opt_p) || !defined( $opt_i) || !defined( $opt_m) || !defined( $opt_s))
{
    printLog("\n\nFlags -d, -s, -u, -p, -i and -m are mandatory\n");
    usage();
    exit 0;
}

main();
exit(0);

sub main
{
        $VERBOSE_FLAG = 1 if ( defined( $opt_v) );
        $TENANT = $opt_t if ( defined( $opt_t) );
        $REMOTE_SERVER = $opt_i if ( defined( $opt_i) );
        $DEST_PATH = $opt_d if ( defined( $opt_d) );
        $SOURCE_PATH = $opt_s if ( defined( $opt_s) );
        $USERNAME = $opt_u if ( defined( $opt_u) );
        $PASSWORD = $opt_p if ( defined( $opt_p) );
        $PROTOCOL_MODE = lc $opt_m if (defined( $opt_m));
        $MAILBOX_ID = $opt_c if ( defined( $opt_c) );
        $AUDIT_DIR = $opt_a if ( defined( $opt_a) );
        `sudo -u tango mkdir -p $DEST_PATH` if ( ! -d $DEST_PATH && $whoami ne "tango");
        `sudo -u tango mkdir -p $DEST_PATH/processing` if ( ! -d "$DEST_PATH/processing" && $opt_m ne "elasticdump" && $whoami ne "tango");
        `sudo -u tango mkdir -p $DEST_PATH/transfered` if ( ! -d "$DEST_PATH/transfered" && $opt_m eq "http" && $whoami ne "tango");
        `sudo -u tango mkdir -p $DEST_PATH/import` if ( ! -d "$DEST_PATH/import" && $opt_m eq "sftp" && $whoami ne "tango");
        `sudo -u tango mkdir -p $DEST_PATH/drop` if ( ! -d "$DEST_PATH/drop" && $opt_m eq "sftp" && $whoami ne "tango");
        `sudo -u tango mkdir -p $DEST_PATH` if ( ! -d "$DEST_PATH" && $opt_m eq "elasticdump" && $whoami ne "tango");
        `sudo -u tango mkdir -p $DEST_PATH/transfered` if ( ! -d "$DEST_PATH/transfered" && $opt_m eq "elasticdump" && $whoami ne "tango");
        `mkdir -p $DEST_PATH` if ( ! -d $DEST_PATH && $whoami eq "tango");
        `mkdir -p $DEST_PATH/processing` if ( ! -d "$DEST_PATH/processing" && $opt_m ne "elasticdump" && $whoami eq "tango");
        `mkdir -p $DEST_PATH/transfered` if ( ! -d "$DEST_PATH/transfered" && $opt_m eq "http" && $whoami eq "tango");
        `mkdir -p $DEST_PATH/import` if ( ! -d "$DEST_PATH/import" && $opt_m eq "sftp" && $whoami eq "tango");
        `mkdir -p $DEST_PATH/drop` if ( ! -d "$DEST_PATH/drop" && $opt_m eq "sftp" && $whoami eq "tango");
        `mkdir -p $DEST_PATH` if ( ! -d "$DEST_PATH" && $opt_m eq "elasticdump" && $whoami eq "tango");
        `mkdir -p $DEST_PATH/transfered` if ( ! -d "$DEST_PATH/transfered" && $opt_m eq "elasticdump" && $whoami eq "tango");

        if ( $PROTOCOL_MODE eq "http" )
        {
                downloadFilesViaHTTP();
        }
        elsif ( $PROTOCOL_MODE eq "sftp")
        {
                downloadFilesViaSFTP();
        }
        elsif ( $PROTOCOL_MODE eq "elasticdump")
        {
                downloadFilesViaESdump();
        }
        else
        {
                printLog("\n\nFlag -m $opt_m is not valid !!!\n");
                usage();
                exit 0;
        }
}

sub checkListBatchNumBlacklist
{
        if( $batchNumBlacklist =~ m/$_[0]/ )
        {
                $listBatchNumBlacklist = "yes";
        }
        else
        {
                $listBatchNumBlacklist = "no";
        }
}

sub getConfigs
{
        use FindBin '$Bin';
        $scriptDir = $Bin."/";
        open listDownloaderCfgFile, "<$scriptDir/listDownloader.cfg" or die(color("reset"), "\nCould not open $scriptDir/listDownloader.cfg. $!\n\n");
        while(<listDownloaderCfgFile>)
        {
                chomp;
                if( $_ =~ m/PermitedLists/ )
                {
                        $_=~ s/\s//g;
                        @PermitedListsHashArray = split('#',$_);
                        @PermitedListsArray = split('=',$PermitedListsHashArray[0]);
                        $PermitedLists = $PermitedListsArray[1];
                        $awkPermitedLists = $PermitedListsArray[1];
                        $awkPermitedLists =~ s/,/\/ || \//g;
                }

                if( $_ =~ m/batchNumBlacklist/ )
                {
                        $_=~ s/\s//g;
                        @batchNumBlacklistHashArray = split('#',$_);
                        @batchNumBlacklistArray = split('=',$batchNumBlacklistHashArray[0]);
                        $batchNumBlacklist = $batchNumBlacklistArray[1];
                }

                if( $_ =~ m/limit/ )
                {
                        $_=~ s/\s//g;
                        @limitHashArray = split('#',$_);
                        @limitArray = split('=',$limitHashArray[0]);
                        $limit = $limitArray[1];
                }

                if( $_ =~ m/concurrencyInterval/ )
                {
                        $_=~ s/\s//g;
                        @concurrencyIntervalHashArray = split('#',$_);
                        @concurrencyIntervalArray = split('=',$concurrencyIntervalHashArray[0]);
                        $concurrencyInterval = $concurrencyIntervalArray[1];
                }

                if( $_ =~ m/PMIServers/ )
                {
                        $_=~ s/\s//g;
                        @PMIServersHashArray = split('#',$_);
                        @PMIServersArray = split('=',$PMIServersHashArray[0]);
                        $PMIServers = $PMIServersArray[1];
                }
        }
        close listDownloaderCfgFile;
}

sub downloadFilesViaHTTP
{
        printLog("==================================================== Start Download Files Via [$PROTOCOL_MODE] [$TENANT] ====================================================");
        printLog("Starting run... Tenant [$TENANT] Remote Server Username:[$USERNAME] URL path: [$SOURCE_PATH] Destination folder: [$DEST_PATH]");
        login();
        getFileList() if($JSESSIONID);
        downloadSessionFiles() if($JSESSIONID);
        printLog("End run!!!");

}

sub downloadFilesViaSFTP
{
        printLog("==================================================== Start Download Files Via [$PROTOCOL_MODE] [$TENANT] ====================================================");
        printLog("Starting run... Tenant [$TENANT] Remote Server Username:[$USERNAME] Destination folder [$DEST_PATH] Source (remote server) folder [$SOURCE_PATH] Remote Server [$REMOTE_SERVER]");
        testConnectivity();
        sftpFiles();
        printLog("End run!!!");
}

sub downloadFilesViaESdump
{
        printLog("==================================================== Start Download Lists From ES Via [$PROTOCOL_MODE] [$TENANT] ====================================================");
        printLog("Starting run... Tenant [$TENANT] Elastic Search Username and Password:[$USERNAME:$PASSWORD] ES server: $REMOTE_SERVER:9201 Index: [$SOURCE_PATH] Destination folder: [$DEST_PATH] AuditDir: [$AUDIT_DIR]");
        if (defined ($AUDIT_DIR) and $AUDIT_DIR ne "now")
        {
                $auditDirectoryChanged = "false";
                auditDirectory();
                if ($auditDirectoryChanged eq "true")
                {
                        printLog("$AUDIT_DIR has been audited and it has been changed. Either a list was modified or a new list was imported via PMI List Manager or Vivo Portal. I will then proceed to download ALL lists. They should be transfered to all PMI subscriber.list.download.locations");
                        printLog("Since there are new $scanAuditDirArray files in $AUDIT_DIR, I am updating $scriptRelativePath/.auditDir with $scanAuditDirArray. It will be updated again when a new list gets imported into ES");
                        `sudo -u tango echo "$scanAuditDirArray" > $scriptRelativePath/.auditDir`;
                }
                else
                {
                        printLog("Flas -a is defined and it is not \"now\". Hence, I will download lists if and only if $AUDIT_DIR has been modified by PMI List Download or Vivo Portal imports");
                        printLog("$AUDIT_DIR has been audited and NOTHING has been changed. There are still $scanAuditDirArray files.  Hence, I will not proceed to download any list. PMI List Download will to be updated. Maybe next time...");
                }
        }
        else
        {
                $auditDirectoryChanged = "true";
                printLog("Flag -a is not defined or it is set to \"now\". I will then proceed to download ALL lists. They should be transfered to all PMI subscriber.list.download.locations");
        }

        if ($auditDirectoryChanged eq "true")
        {
                elasticDump();
        }
        printLog("End run!!!");
}

sub sftpFiles
{
        my $sftpListSpawn = <<"END_FILE1";
#!/bin/bash
expect <<'EOF1'
spawn  sftp   $USERNAME\@$REMOTE_SERVER
expect  \"password:\"
send \"$PASSWORD\\n\"
expect  \"sftp\"
send \"cd  $SOURCE_PATH/\\n\"
expect  \"sftp\"
send \"ls *.csv\\n\"
expect  \"sftp\"
send \"exit\n\"
EOF1
END_FILE1
        open(my $spawnFile1, '>', $scriptTmpFile) or die "Could not write file '$sftpListSpawn' $!";
        print $spawnFile1 $sftpListSpawn;
        close $spawnFile1;
        system("chmod 755 $scriptTmpFile");
        printLog("SFTP Command to list remote files: \n $sftpListSpawn \n");
        my @result =  `$sftpListSpawn`;
        printLog("SFTP Result: \n @result \n");
        if ($result[5] =~ /.csv/ && $result[5] !~ /not found/)
        {
                my @allFiles = split /\s+/, $result[5];
                $printAllFiles=join(',', @allFiles), "\n";
                printLog("Getting all files into array: [$printAllFiles]");


                foreach (@allFiles)
                {
                        my $sftpGetSpawn = <<"END_FILE2";
#!/bin/bash
expect <<'EOF2'
spawn  sftp   $USERNAME\@$REMOTE_SERVER
expect  \"password:\"
send \"$PASSWORD\\n\"
expect  \"sftp\"
send \"cd  $SOURCE_PATH/\\n\"
expect  \"sftp\"
send \"lcd  $DEST_PATH/\\n\"
expect  \"sftp\"
send \"get $_\\n\"
expect  \"sftp\"
send \"rename $_ ./transfered/$_\\n\"
expect  \"sftp\"
send \"exit\n\"
EOF2
END_FILE2
                        open(my $spawnFile2, '>', $scriptTmpFile) or die "Could not write file '$sftpGetSpawn' $!";
                        print $spawnFile2 $sftpGetSpawn;
                        close $spawnFile2;
                        system("chmod 755 $scriptTmpFile");
                        printLog("SFTP Command to transfer/get files: \n $sftpGetCommand \n");
                        my @result =  `$sftpGetSpawn`;
                        printLog("SFTP Result: \n @result \n");
                        my @changePermissions = `sudo chown $USERNAME:lists $DEST_PATH/$_`;
                        printLog("$_ SFTP transfer COMPLETED!. Changing permissions so nodejs \"list-file-watcher.service\" can upload it into ES via List Manager: \n @changePermissions \n");
                }
        }
        else
        {
                printLog("No csv files found in $USERNAME\@$REMOTE_SERVER:$SOURCE_PATH");
        }

}

sub login
{
        my $cmd = $CMD_LOGIN;
        $cmd =~ s/<REMOTE_SERVER>/$REMOTE_SERVER/g;
        $cmd =~ s/<SOURCE_PATH>/$SOURCE_PATH/g;
        $cmd =~ s/<USERNAME>/$USERNAME/g;
        $cmd =~ s/<PASSWORD>/$PASSWORD/g;
        printLog("Logging in... $cmd");
        my @cmdResult = `$cmd`;
        foreach my $line (@cmdResult)
        {
                printLog( "Searching line: $line" );
                if ($line =~ /JSESSIONID/)
                {
                        printLog( "Found JSESSIONID IN LINE: $line" );
                        #Set-Cookie: JSESSIONID=123...; Path=/cehttp_pt; Secure
                        my ($session) = $line =~ m/JSESSIONID=(\w+)/g;
                        if ($session)
                        {
                                printLog("Logged in! Session = $session");
                                $JSESSIONID = $session;
                                return;
                        }
                }
        }
}


sub getFileList
{
        my $cmd = $CMD_FETCH_FILE_LIST;
        $cmd =~ s/<REMOTE_SERVER>/$REMOTE_SERVER/g;
        $cmd =~ s/<SOURCE_PATH>/$SOURCE_PATH/g;
        $cmd =~ s/<SESSION_ID>/$JSESSIONID/g;
        $cmd =~ s/<MAILBOX_ID>/$MAILBOX_ID/g;
        printLog("Fetching file... $cmd ");
        my @cmdResult = `$cmd`;
        my  @foundHREFLine = (0);
        foreach my $line (@cmdResult)
        {
#                printLog("Scaning line for A HREF:\t| $line");

                if ($line =~ /A HREF/)
                {
                        push @foundHREFLine, 1;
                        #<A HREF="/cehttp_pt/servlet/MailboxServlet?operation=DOWNLOAD&mailbox_id=U0001998&batch_num=0168539&data_format=B&batch_id=WSMSVIPList.csv"
                        my @link = split ('"',$line );
                        if ($link[1])
                        {
                                printLog("Scaning line for A HREF: Found file link in page = $link[1]");
                                push @LINK_FILES_TO_DOWNLOAD, $link[1];
                        }
                }
        }
        if ($foundHREFLine[-1] == 0)
        {
                printLog("Scaning line for A HREF: NO FILES FOUND\n");
        }
        else
        {
                foreach my $line (@cmdResult)
                {
                        printLog("\t| $line");
                }
        }
}


sub downloadSessionFiles
{
        foreach my $fileLink (@LINK_FILES_TO_DOWNLOAD)
        {
                my @fetchParameters = split /[?&]/, $fileLink;
                my @pushed_FILE_TO_DOWNLOAD = ();
                foreach my $parameter (@fetchParameters)
                {
                        if ($parameter =~ /batch_id/)
                        {
                                my @fileToDownload = split('\=',$parameter);
                                printLog("-------------------------- Handling file $fileToDownload[1] --------------------------");
                                push @pushed_FILE_TO_DOWNLOAD, $fileToDownload[1];
                        }
                        if ($parameter =~ /batch_num/)
                        {
                                @pushed_batch_num = ();
                                my @batch_num = split('\=',$parameter);
                                push @pushed_batch_num, $batch_num[1];
                        }
                }
                my @fileToDownloadNotExt = split('\.',$pushed_FILE_TO_DOWNLOAD[0]);
                my $file_to_save = $DEST_PATH."/".$fileToDownloadNotExt[0]."_".getLocalDateAndTimeWithSecs().".csv";
                my $file_processing_PART = $DEST_PATH."/processing/".$fileToDownloadNotExt[0]."_".getLocalDateAndTimeWithSecs().".csv.PART";
                checkListBatchNumBlacklist($pushed_batch_num[0]);


                if (glob("$DEST_PATH/processing/$fileToDownloadNotExt[0]*.csv.PART"))
                {
                        printLog("Sorry, $pushed_FILE_TO_DOWNLOAD[0] is currently being downloaded. Try again later");
                }
                elsif ( $listBatchNumBlacklist eq 'yes' )
                {
                        printLog("Sorry, batch_num=$pushed_batch_num[0] is blacklisted so list $pushed_FILE_TO_DOWNLOAD[0] wont be handled. Please request Vivo to purge that list since it has already been downloaded");
                }
                else
                {
                        my $file_processing = $DEST_PATH."/processing/".$fileToDownloadNotExt[0]."_".getLocalDateAndTimeWithSecs().".csv";
                        my $cmd = $CMD_OPEN_FILE;
                        $cmd =~ s/<REMOTE_SERVER>/$REMOTE_SERVER/g;
                        $cmd =~ s/<SESSION_ID>/$JSESSIONID/g;
                        $cmd =~ s/<URL>/$fileLink/g;
                        printLog("Checking if $pushed_FILE_TO_DOWNLOAD[0] contains valid lists [$PermitedLists] ... $cmd");
                        my $isListValid = `$cmd`;

                        if ( $isListValid > 0 )
                        {
                                $cmd = $CMD_DOWNLOAD_FILE;
                                $cmd =~ s/<REMOTE_SERVER>/$REMOTE_SERVER/g;
                                $cmd =~ s/<SESSION_ID>/$JSESSIONID/g;
                                $cmd =~ s/<URL>/$fileLink/g;
                                $cmd =~ s/<FILE_OUTPUT>/$file_processing_PART/g;
                                printLog("$pushed_FILE_TO_DOWNLOAD[0] contains valid lists. Downloading NOW!... $cmd");
                                my @cmdResut = `$cmd`;
                                system("mv $file_processing_PART $file_processing");
                                printLog("New $pushed_FILE_TO_DOWNLOAD[0] Download done. NOTE extention has been modified to .csv if it was different. Checking if it has already been downloaded ... $cmd");
                                @getLastReadyFile = glob("$DEST_PATH/$fileToDownloadNotExt[0]*");
                                @getLastTransferedFile = glob("$DEST_PATH/transfered/$fileToDownloadNotExt[0]*");
                                my $newFile_md5sum = `md5sum $file_processing |cut -f 1 -d " "`;
                                my $newFile_md5sumPrint = `md5sum $file_processing`;
                                if ($getLastReadyFile[$#getLastReadyFile])
                                {
                                        my $getLastReadyFile_md5sum = `md5sum $getLastReadyFile[$#getLastReadyFile] |cut -f 1 -d " "`;
                                        my $getLastReadyFile_md5sumPrint = `md5sum $getLastReadyFile[$#getLastReadyFile]`;
                                        if ($newFile_md5sum eq $getLastReadyFile_md5sum)
                                        {
                                                printLog("$pushed_FILE_TO_DOWNLOAD[0] is exactly the same as Last downloaded file. It seems there is not delta (new, removed or modifieded lines). File will remain under $DEST_PATH/processing/ Note RTE only gets the files (with deltas) from $DEST_PATH/\n Last File = $getLastReadyFile_md5sumPrint New File =  $newFile_md5sumPrint");
                                        }
                                        else
                                        {
                                                if ($getLastTransferedFile[$#getLastTransferedFile])
                                                {
                                                        my $getLastTransferedFile_md5sum = `md5sum $getLastTransferedFile[$#getLastTransferedFile] |cut -f 1 -d " "`;
                                                        my $getLastTransferedFile_md5sumPrint = `md5sum $getLastTransferedFile[$#getLastTransferedFile]`;
                                                        if ($newFile_md5sum eq $getLastTransferedFile_md5sum)
                                                        {
                                                                printLog("$pushed_FILE_TO_DOWNLOAD[0] is exactly the same as Last Transfered file. It seems there is not delta (new, removed or modifieded lines). File will remain under $DEST_PATH/processing/ Note RTE only gets the files (with deltas) from $DEST_PATH/\n Last File = $getLastTransferedFile_md5sumPrint New File =  $newFile_md5sumPrint");
                                                        }
                                                        else
                                                        {
                                                                system("mv $file_processing $file_to_save");
                                                                printLog("There is a delta between $pushed_FILE_TO_DOWNLOAD[0] and last Transfered file. FILE MUST BE INGESTED INTO ELASTIC SEARCH VIA RTE ListManager. Then, storing $pushed_FILE_TO_DOWNLOAD[0] under $DEST_PATH/\n Last File = $getLastTransferedFile_md5sumPrint New File =  $newFile_md5sumPrint");
                                                        }
                                                }
                                                else
                                                {
                                                        system("mv $file_processing $file_to_save");
                                                        printLog("There is a delta between $pushed_FILE_TO_DOWNLOAD[0] and last downloaded file. FILE MUST BE INGESTED INTO ELASTIC SEARCH VIA RTE ListManager. Then, storing $pushed_FILE_TO_DOWNLOAD[0] under $DEST_PATH/\n Last File = $getLastReadyFile_md5sumPrint New File =  $newFile_md5sumPrint");
                                                }
                                        }
                                }
                                else
                                {
                                        if ($getLastTransferedFile[$#getLastTransferedFile])
                                        {
                                                my $getLastTransferedFile_md5sum = `md5sum $getLastTransferedFile[$#getLastTransferedFile] |cut -f 1 -d " "`;
                                                my $getLastTransferedFile_md5sumPrint = `md5sum $getLastTransferedFile[$#getLastTransferedFile]`;
                                                if ($newFile_md5sum eq $getLastTransferedFile_md5sum)
                                                {
                                                        printLog("$pushed_FILE_TO_DOWNLOAD[0] is exactly the same as Last Transfered file. It seems there is not delta (new, removed or modifieded lines). File will remain under $DEST_PATH/processing/ Note RTE only gets the files (with deltas) from $DEST_PATH/\n Last File = $getLastTransferedFile_md5sumPrint New File =  $newFile_md5sumPrint");
                                                }
                                                else
                                                {
                                                        system("mv $file_processing $file_to_save");
                                                        printLog("There is a delta between $pushed_FILE_TO_DOWNLOAD[0] and last Transfered file. FILE MUST BE INGESTED INTO ELASTIC SEARCH VIA RTE ListManager. Then, storing $pushed_FILE_TO_DOWNLOAD[0] under $DEST_PATH/\n Last File = $getLastTransferedFile_md5sumPrint New File =  $newFile_md5sumPrint");
                                                }
                                        }
                                        else
                                        {
                                                system("mv $file_processing $file_to_save");
                                                printLog("FILE MUST BE INGESTED INTO ELASTIC SEARCH VIA RTE ListManager. Then, storing $pushed_FILE_TO_DOWNLOAD[0] under $DEST_PATH/");
                                        }
                                }
                        }
                        else
                        {
                                printLog("$pushed_FILE_TO_DOWNLOAD[0] does not contain valid lists. Hence, it will not be downloaded ... $cmd");
                        }
                }
        }
}

sub auditDirectory
{
        `sudo -u tango echo "0" > $scriptRelativePath/.auditDir` if ( ! -e "$scriptRelativePath/.auditDir");
        $scanAuditDirArray = `du -b $AUDIT_DIR | awk '{print \$1}'`;
        chomp($scanAuditDirArray);
        closedir (DIR);
        $OLD_scanAuditDirArray = `cat $scriptRelativePath/.auditDir`;
        chomp($OLD_scanAuditDirArray);
        if ($scanAuditDirArray eq $OLD_scanAuditDirArray)
        {
                $auditDirectoryChanged = "false";
        }
        else
        {
                $auditDirectoryChanged = "true";
        }
        return;
}

sub elasticDump
{
        my $cmd = $CMD_DUMP_ALL_LISTS_FROM_ES;
        $cmd =~ s/<USERNAME>/$USERNAME/g;
        $cmd =~ s/<PASSWORD>/$PASSWORD/g;
        $cmd =~ s/<SOURCE_PATH>/$SOURCE_PATH/g;
        $cmd =~ s/<DEST_PATH>/$DEST_PATH/g;
        $cmd =~ s/<REMOTE_SERVER>/$REMOTE_SERVER/g;

        if (-e "$DEST_PATH/elasticdump_All_Lists.json.PART")
        {
                my $mtime = (stat("$DEST_PATH/processing/$fileToDownloadNotExt[0]*.csv.PART"))[9];
                my $ctime = time;
                my $time_diff = ($ctime - $mtime);
                if ($time_diff > 216000)
                {
                        printLog("ALERT, $DEST_PATH/elasticdump_All_Lists.json.PART is older than 6 hours! I will cancel this download now and allow the new download");
                        printLog("rm $DEST_PATH/elasticdump_All_Lists.json.PART");
                        system("rm $DEST_PATH/elasticdump_All_Lists.json.PART");
                }
                else
                {
                        printLog("Sorry, $DEST_PATH/elasticdump_All_Lists.json.PART is currently being downloaded. Try again later");
                }
        }
        else
        {
                printLog("$cmd");
                my $elasticdumpCMD = `$cmd`;
                system("mv $DEST_PATH/elasticdump_All_Lists.json.PART $DEST_PATH/elasticdump_All_Lists.json");
                system("chown tango:tango $DEST_PATH/elasticdump_All_Lists.json");
                system("chmod 775 $DEST_PATH/elasticdump_All_Lists.json");
                generatePMILists();
                testConnectivity();
                scpPMILists();
        }
}

sub generatePMILists
{
        my $CMD_FETCH_LISTS_NAMES_FROM_LISTMANAGER = "$CURL_CMD -m 10 -s -u tangoInternalServiceUser:tmp12345 -X GET -H \"Content-Type: application/json\" -H \"Accept: application/json\" -H \"tenant: $TENANT\" localhost:8287/list-manager/lists | jq '.[] | .name' -r";
        my $cmd = $CMD_FETCH_LISTS_NAMES_FROM_LISTMANAGER;
        my $fetchLists = `$cmd`;
        printLog("$cmd");
        my @fetchListsArray = split('\n', $fetchLists);
        my $printFetchLists = join(",",@fetchListsArray);
        printLog("Current Lists: $printFetchLists");
        foreach my $list_name (@fetchListsArray)
        {
                printLog( "Gathering all MSISDNs from list_name: $list_name" );
                `echo -n "" > $DEST_PATH/$list_name.csv`;
                open elasticdump_All_ListsFILE, "<$DEST_PATH/elasticdump_All_Lists.json" or die(color("reset"), "\nCould not open $DEST_PATH/elasticdump_All_Lists.json. $!\n\n");
                while(<elasticdump_All_ListsFILE>)
                {
                        chomp;
                        if ($_ =~ /$list_name/)
                        {
                                my $exportListFile = "$DEST_PATH/$list_name.csv";
                                open(my $exportLine, '>>', $exportListFile) or die "Could not write file '$exportListFile' $!";
                                @msisdnSub_p1 = split('"',$_);
                                @msisdnSub_p2 = split('-',$msisdnSub_p1[3]);

                                #### Begin Change
                                $valueToPrint = "";
                                $msisdnSub_p2_size = @msisdnSub_p2;
                                if($msisdnSub_p2_size == 1) {
                                   # for the case <imsi|msisdn><listname>, extact the numeric part
                                   if($msisdnSub_p2[0]=~/(\d+)(([a-z]|[A-Z])+)/){
                                        $valueToPrint = $1;
                                   }
                                }
                                else {
                                   if($msisdnSub_p2[1] =~ /\d+/){
                                        # for the case <listname>-<imsi|msisdn>
                                        $valueToPrint = $msisdnSub_p2[1];
                                   }else {
                                        $valueToPrint =$msisdnSub_p2[0];
                                   }
                                }

                                print $exportLine $valueToPrint."\n";

                                ## End Change
                                close $exportLine;
                        }
                }
                close elasticdump_All_ListsFILE;
                system("chmod 775 $DEST_PATH/$list_name.csv");
                system("chown tango:tango $DEST_PATH/$list_name.csv");
        }
}

sub scpPMILists
{
        @getPMIServers = split(',',$PMIServers);
        foreach my $scpPMIServer (@getPMIServers)
        {
                my $checkRemoteOldListsDir = `sudo -u tango ssh $scpPMIServer "ls -altr /tango/data/listmanager/ | grep oldLists | grep $TENANT | wc -l"`;
                if ( $checkRemoteOldListsDir == 0)
                {
                        `sudo -u tango ssh $scpPMIServer "mkdir -p /tango/data/listmanager/oldLists_$TENANT"`;
                        printLog("On $scpPMIServer: mkdir -p /tango/data/listmanager/oldLists_$TENANT");
                }
                `sudo -u tango ssh $scpPMIServer "mv $DEST_PATH/*.csv /tango/data/listmanager/oldLists_$TENANT"`;
                printLog("On $scpPMIServer: mv $DEST_PATH/*.csv /tango/data/listmanager/oldLists_$TENANT");
                `sudo -u tango scp $DEST_PATH/*.csv $scpPMIServer:$DEST_PATH`;
                printLog("sudo -u tango scp $DEST_PATH/*.csv $scpPMIServer:$DEST_PATH");
        }
        system("mv $DEST_PATH/*.csv $DEST_PATH/transfered");
        printLog("mv $DEST_PATH/*.csv $DEST_PATH/transfered");
}



sub printLog
{
   my $msg = shift;
   my $DATE = getLocalDate();
   my $TIME = getLocalTime();
   my $msg_header = '[' . $DATE . ' ' . $TIME . '] [' . $TENANT . '] [' . $PROTOCOL_MODE . ']';

   if (open(FH_printDebug,">>$DEBUG_LOGFILE"))
   {
        print FH_printDebug $msg_header, $msg, "\n";
        print "$msg_header $msg \n" if ($VERBOSE_FLAG);
        close (FH_printDebug);
   }
   else
   {
     die "printLog :: Can't append to debug file (Maybe script is running as tango user) \"$DEBUG_LOGFILE\"";
   }
}

sub getTime
{
 ($Second, $Minute, $Hour, $Day, $Month, $Year, $WeekDay, $DayOfYear, $IsDST) = localtime(time);

 if($Hour < 10)   {  $Hour = "0" . $Hour ; }
 if($Minute < 10) {  $Minute = "0" . $Minute ; }
 if($Second < 10) {  $Second = "0" . $Second ; }
 my $Month = $Month + 1 ;
 if($Month < 10)
 {
  $Month = "0" .
  $Month ;
 }
 if($Day < 10)
 {
  $Day = "0" . $Day ;
 }
 if($Year >= 100)
 {
  $Year = $Year - 100 ;
  $Year = $Year + 2000;
 }
 return  ($Second, $Minute, $Hour, $Day, $Month, $Year, $WeekDay, $DayOfYear, $IsDST);
}

sub getLocalTime
{
  my $sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst;
  ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
  my $local_time = sprintf "%02d:%02d:%02d", $hour, $min, $sec;
  return $local_time;
}

sub getLocalDate
{
   my $sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst;
  ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
  $year = $year + 1900;
  $mon += 1;
  my $local_date = sprintf "%02d%02d%04d", $mday, $mon, $year;
  return $local_date;
}

sub getLocalDateAndTime {
   my $sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst;
  ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
  $year = $year + 1900;
  $mon += 1;
  my $local_date_and_time = sprintf "%02d%02d%04d%02d%02d", $mday, $mon, $year, $hour, $min;
  return $local_date_and_time;
}

sub getLocalDateAndTimeWithSecs {
   my $sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst;
  ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
  $year = $year + 1900;
  $mon += 1;
  my $local_date_and_time = sprintf "%04d%02d%02d%02d%02d%02d", $year, $mon, $mday, $hour, $min, $sec;
  return $local_date_and_time;
}

sub getLocalDateAndTimeWithMins {
   my $sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst;
  ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
  $year = $year + 1900;
  $mon += 1;
  my $local_date_and_time = sprintf "%04d%02d%02d_%02d%02d", $year, $mon, $mday, $hour, $min;
  return $local_date_and_time;
}

sub getLocalDateForFile {
   my $sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst;
  ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
  $year = $year + 1900;
  $mon += 1;
  my $local_date_f = sprintf "%04d%02d%02d", $year, $mon, $mday;
  return $local_date_f;
}

sub checkForRoot
{
        my $login = (getpwuid $>);
        if ($login ne 'root')
        {
                print "this script must run as root \n ;-)\n";
                exit(1);
        }
}

sub testConnectivity
{
        $p = Net::Ping->new();
        printLog("$REMOTE_SERVER is alive.") if $p->ping($REMOTE_SERVER);
        printLog("$REMOTE_SERVER is not reachable, bye.") unless $p->ping($REMOTE_SERVER);
        die "$REMOTE_SERVER is not reachable, bye.\n" unless $p->ping($REMOTE_SERVER);
}
##################################################################################################################################
sub usage
{
    print <<EO_USAGE;

Usage: $scriptName
Jira: COSC-127
Version: $VERSION

        This script can only be run as root

        MANDATORY
        -t <TENANT>
        -u <USERNAME>
        -p <PASSWORD>
        -d <DESTINATION PATH> Path to the folder INTO where list is downloaded/transfered. (Local folder)
        -m <PROTOCOL MODE> To download list via  sftp or http
                -sftp -> To transfer list from RTEDMZ to RTE VMs.
                -http -> To download list from VIVO list manager web portal
                -elasticdump -> To download ALL lists from ElasticSearch. It groups subscribers per list_name into separate csv files (index defined in flagh -s)
        -i <REMOTE SERVER> IP or Domain of remote server FROM where lists is to be downloaded/transfered
        -s <SOURCE PATH> Source path or directory from where list taken
                -HTTP download, it is the URL's path.
                -SFTP transfer, it is the path to folder FROM where list is to be transfered. (Remote folder)
                -elasticdump, set campaign_lists index. Example: brav1-campaign_lists
        -a <AUDIT DIRECTORY> It is releveant if flag -m is \"elasticdump\". It audits or examins a directory. If changed, download the list
                -now [Default] -> Downloads list without auditing any directory. Useful to download lists periodically (Every morning) regarless lists change or not
                -<Dir Path>, it is the path to audit. Useful to download a list as soon as listDownloader.pl detects the directory has changedi (A list has changed or there is a new list)


        OPTIONAL
        -l <DEBUG_LOGDIR> Directory where log files are to be generated
        -c <MAILBOX_ID> Caixa Postal to filter lists from Vivo Portal.
        -v Displays the verbose debug entries


        EXAMPLE
        1.  /tango/scripts/listDownloader/listDownloader.pl -t brav1 -i webedi.vivo.com.br -u U0001998 -p vivo2014 -d /tango/data/listDownloader/ -s /cehttp_pt/servlet/MailboxServlet -m http
            Downloads lists from VIVO list manager web portal [https://webedi.vivo.com.br/cehttp_pt/servlet/MailboxServlet] to local directory /tango/data/listDownloader/ It used as part of the import of lists into ES.
            Notes:
                - The lines in the file must have the following format: "<I or D>,5424,<LIST NAME>,<IMSI or MSISDN>,,,,RWDB,OTHERS".
                - The file will be downloaded if and only if <LIST NAME> is configured listDownloader.cfg. Note, it is case sensitive

        2.  /tango/scripts/listDownloader/listDownloader.pl -t brav1 -i IPXMIATCRTE1DMZ_drews -u brav1 -p t3l3com123 -s /tango/data/listDownloader/ -d /tango/data/listmanager/drop/ -m sftp
            Transfer lists from RTEDMZ:/tango/data/listDownloader/ to RTE:/tango/data/listmanager/drop/ Once completed, file is moved in RTEDMZ:/tango/data/listDownloader/transfered/ It used as part of the import of lists into ES. Nodejs fileloader, whose directory is /tango/data/listmanager/drop/, does the import and it only runs on RTE1/RTE2. Therefore this should be used on RTE1/RTE2 to pull the lists from RTE1DMZ/RTE2DMZ

        3.  /tango/scripts/listDownloader/listDownloader.pl -t brav1 -i IPXMIATCDB_oam -u elastic -p t3il3achum -s brav1-campaign_lists -d /tango/data/listmanager/brav1/export/ -m elasticdump
            Downloads ALL documents from http://IPXMIATCDB_oam:9201/brav1-campaign_lists and store ALL lists into separate csv files at /tango/data/listmanager/export/. Each file (list) will only
            contain MSISDNs. It is recommended to use ESdata node Logical IP (IPXMIATCDB_oam) for HA.
            Notes:
                - Configure limit (number of requests to ES per chunk) and concurrencyInterval (time in ms between chunks) in listDownloader.cfg. It is to determine how fast ALL lists are downloaded from ES

        4.  /tango/scripts/listDownloader/listDownloader.pl -t brav1 -i IPXMIATCDB_oam -u elastic -p t3il3achum -s brav1-campaign_lists -d /tango/data/listmanager/brav1/export/ -m elasticdump -a /tango/data/listmanager/drop/
            Same as example 3. but it downloads ALL lists if and only if /tango/data/listmanager/drop/ has been changed. It changes when a new list is imported via PMI List Manager or Vivo Portal


EO_USAGE
}

sub help
{
    print <<EO_HELP;

Help for script $scriptname (c) Tango Telecom 2008


EO_HELP

    usage();
}

##################################END