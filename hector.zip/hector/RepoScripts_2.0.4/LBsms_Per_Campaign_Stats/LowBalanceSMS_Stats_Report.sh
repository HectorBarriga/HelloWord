#!/bin/bash
#############################################################################
# Filename:    LowBalanceSMS_Stats_Report.sh
# Revision:    $Revision: 0.1.0 $
# Author:      Hector Barriga
#
# Jiras:
# CO Scripts:  COSC-71
# CO Internal: COIT-13905
#
# This sh script displays statisctics report outlining the number of Low Balance SMS notifications
# per Campaign specific. The stats that this script generates is based only on SI CDRs
#
# Copyright (c) Tango Telecom 2016
# Author: Hector Barriga
#
# All rights reserved.
# This document contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or
# in part is expressly prohibited, except as may be specifically
# authorized by prior written agreement or permission of Tango Telecom.
##############################################################################
# version 0.1.0 - First version
#
##############################################################################

# Initial Arguments
logtoday=$(perl -e '@d=localtime time(); printf "%4d-%02d-%02d\n", $d[5]+1900,$d[4]+1,$d[3]')
hournow=$(perl -e '@d=localtime time(); printf "%02d\n", $d[2]')
minnow=$(perl -e '@d=localtime time(); printf "%02d\n", $d[1]')
if [ "$hournow" -lt "00" ] || [ "$hournow" -eq "00" -a "$minnow" -lt "20" ]; then
        logtoday=$(perl -e '@d=localtime time()-84600; printf "%4d-%02d-%02d\n", $d[5]+1900,$d[4]+1,$d[3]')
fi
dateReport=$(perl -e '@d=localtime time(); printf "%4d/%02d/%02d %02d:%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1]')
midnight=$(perl -e '$d=localtime(); printf $d' | awk '{print $1" " $2" " $3" 00:00"}')
year=$(perl -e '@d=localtime time(); printf "%4d\n", $d[5]+1900')
currenttime=$(perl -e '$d=localtime(time-600); printf $d' | cut -d":" -f1,2)
backcdrdate=$(perl -e '@d=localtime time()-1200; printf "%4d%02d%02d_%02d%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1]' | sed 's/.$//')
red=`tput setaf 1`
green=`tput setaf 2`
yellow=`tput setaf 3`
pink=`tput setaf 5`
blue=`tput setaf 6`
reset=`tput sgr0`
bold="\033[1m"

# Subroutines

printhelp()
{
echo "
${green}Usage: LowBalanceSMS_Stats_Report.sh${reset}

This sh script, which has to be called by a tango user crontab job every 10mins, displays statisctics report outlining the number of Low Balance SMS notifications
per Campaign specific. The stats that this script generates is based only on SI CDRs

${red}NOTE: You must have configured LowBalanceSMS_Stats_Report.cfg before using this script${reset}

Copyright (c) Tango Telecom 2016
Author: Hector Barriga

All rights reserved.
This document contains confidential and proprietary information of
Tango Telecom and any reproduction, disclosure, or use in whole or
in part is expressly prohibited, except as may be specifically
authorized by prior written agreement or permission of Tango Telecom.

Version 0.1.0 - First Version


               Options:

               -c <config file>         Config File that contains all script configurable parameters
                                        It is important to include directory path

               -h <help>                Show help

               ${yellow}e.g. 0,10,20,30,40,50 * * * * /bin/nice /tango/scripts/CMC/LowBalanceSMS_Stats_Report.sh -c /tango/scripts/CMC/LowBalanceSMS_Stats_Report.cfg${reset}
               "
}

printLog()
{
if [ `echo "$log_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$log_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
newlogFile=$(echo $logFile | cut -d. -f1)
logExt=$(echo $logFile | cut -d. -f2)
echo "[ $dateReport ] $1 $2" >> $logDir/$newlogFile.$logtoday.$logExt
fi
}

printStat()
{
newstatFile=$(echo $statFile | cut -d. -f1)
statExt=$(echo $statFile | cut -d. -f2)
if [ ! -f "$statDir/$newstatFile.$logtoday.$statExt" ];then
if [ "$1" == "cont" ];then
statcont="
---------------------------------------------------
Number of LB SMS for Campaign $2 \t= $3
---------------------------------------------------
"
statbody="$statbody $statcont"
else
stathead="
===================================================
Low Balance SMS Per Campaign Statistics Report
Start time  :   $midnight $year
End Time    :   $currenttime $year
===================================================
"
printLog "Updating Stats into $statDir/$newstatFile.$logtoday.$statExt"
printLog "$stathead $statbody
TOTAL LB SMS       =  $2

===================================================
"
echo -e "$stathead $statbody
TOTAL LB SMS       =  $2

===================================================

NOTE: This is an automated email from Tango BCN-PCN Operation and Maintenance System. DO NOT REPLY

" > $statDir/$newstatFile.$logtoday.$statExt
fi
else
if [ "$1" == "cont" ];then
oldvalue=$(cat $statDir/$newstatFile.$logtoday.$statExt | grep  "Number of LB SMS for Campaign $2" | cut -d"=" -f2 | tr -d ' ')
printLog "$\(cat $statDir/$newstatFile.$logtoday.$statExt | grep  \"Number of LB SMS for Campaign $2\" | cut -d\"=\" -f2 | tr -d ' ')"
printLog "oldvalue = $oldvalue"
if [ ! -z "$oldvalue" ];then
        newvalue=$(($oldvalue + $3))
        printLog "sed -i \"s/.*Number of LB SMS for Campaign $2.*/Number of LB SMS for Campaign $2 \t= $newvalue/g\" $statDir/$newstatFile.$logtoday.$statExt"
        sed -i "s/.*Number of LB SMS for Campaign $2.*/Number of LB SMS for Campaign $2 \t= $newvalue/g" $statDir/$newstatFile.$logtoday.$statExt
else
        echo "

$config_in was just updated.
New campaigns will be printed at the end only for today

---------------------------------------------------
Number of LB SMS for Campaign $2 \t= $3
---------------------------------------------------

" >> $statDir/$newstatFile.$logtoday.$statExt
printLog "Adding this line at the end of stat file: Number of LB SMS for Campaign $2 \t= $3"
fi

else
sed -i "s/.*End Time.*/End Time    :   $currenttime $year/g" $statDir/$newstatFile.$logtoday.$statExt
oldvalue=$(cat $statDir/$newstatFile.$logtoday.$statExt | grep  "TOTAL LB SMS" | cut -d"=" -f2 | tr -d ' ')
newvalue=$(($oldvalue + $2))
printLog "sed -i \"s/.*TOTAL LB SMS.*/TOTAL LB SMS       =  $newvalue/g\" $statDir/$newstatFile.$logtoday.$statExt"
sed -i "s/.*TOTAL LB SMS.*/TOTAL LB SMS       =  $newvalue/g" $statDir/$newstatFile.$logtoday.$statExt
printLog "Finish updating Stats into $statDir/$newstatFile.$logtoday.$statExt"
fi
fi
}

getSICDRs()
{
nodelength=${#node[@]}
for (( i=0;i<$nodelength;i++))
do
        printLog "scp ${node[$i]}:$cdrbackdir/ussd_si_${node[$i]}.$backcdrdate $DIR/temp/"
        scp ${node[$i]}:$cdrbackdir/ussd_si_${node[$i]}.$backcdrdate* $DIR/temp/
done
}

sendMail()
{
/usr/bin/perl /tango/scripts/sendMail.pl -f "$from_mail" -t "$to_mails" -n "$display_mail" -s "[GP:BCN-PCN] Low Balance SMS Per Campaign Report on $logtoday" -x $smtp_server -a "/bin/cat $statDir/$newstatFile.$logtoday.$statExt"
printLog "/usr/bin/perl /tango/scripts/sendMail.pl -f \"$from_mail\" -t \"$to_mails\" -n \"$display_mail\" -s \"[GP:BCN-PCN] Low Balance SMS Per Campaign Report on $logtoday\" -x $smtp_server -a \"/bin/cat $statDir/$newstatFile.$logtoday.$statExt\""
}


# Flags
while getopts c:h option;
do
        case $option in
                c) config_in=$OPTARG;;
                h) printhelp; h="true";;
        esac
done

if [ ! -z "$config_in" ];then

#---------------------------------------------------------------
# If it doesnt exist, create temp directory in where all temporal CDRs and important files will be stored temporarely
#--------------------------------------------------------------
DIR=$(cat $config_in | tr -d " \t\r" | grep logDir | cut -d"#" -f1 | cut -d= -f2)
if [ ! -d "$DIR/temp" ];then
mkdir $DIR/temp
fi

#---------------------------------------------------------------
# get Genearl Paramenters from LowBalanceSMS_Stats_Report.cfg
#--------------------------------------------------------------

sed -n '/\[General]/,/\[/p' $config_in | awk  '!/\[General]/ && !/\[/' | sed 's/[[:space:]]//g' | awk '/log_enable/ || /logDir/ || /logFile/ || /statDir/ || /statFile/' | cut -d"#" -f1 > $DIR/temp/tmp.file
config_file=$DIR/temp/tmp.file
oldIFS="$IFS"
IFS="="
while read name value
do
    eval $name="$value"
done < $config_file
IFS="$oldIFS"

#---------------------------------------------------------------
# Get Campaigns and Offer_Definition_External_ID from  LowBalanceSMS_Stats_Report.cfg
#--------------------------------------------------------------

sed -n '/\[Campaigns]/,/\[/p' $config_in | awk  '!/\[Campaigns]/ && !/\[/' | sed 's/[[:space:]]//g' | awk '/numberOfCampagins/' | cut -d"#" -f1 > $DIR/temp/tmp.file
config_file=$DIR/temp/tmp.file
oldIFS="$IFS"
IFS="="
while read name value
do
    eval $name="$value"
done < $config_file
IFS="$oldIFS"

#---------------------------------------------------------------
# get local and remote SI CDRs Paramenters from LowBalanceSMS_Stats_Report.cfg
#--------------------------------------------------------------

sed -n '/\[cdrs]/,/\[/p' $config_in | awk  '!/\[cdrs]/ && !/\[/' | sed 's/[[:space:]]//g' | awk '/scpNodes/ || /SINname/ || /cdrbackdir/' | cut -d"#" -f1 > $DIR/temp/tmp.file
config_file=$DIR/temp/tmp.file
oldIFS="$IFS"
IFS="="
while read name value
do
    eval $name="$value"
done < $config_file
IFS="$oldIFS"

node=(`echo $scpNodes | sed 's/,/\n/g'`)


#---------------------------------------------------------------
# get sendMail Paramenters from LowBalanceSMS_Stats_Report.cfg
#--------------------------------------------------------------

sed -n '/\[sendmail]/,/\[/p' $config_in | awk  '!/\[sendmail]/ && !/\[/' |  sed 's/[[:space:]]//g' | awk '/emailenable/ || /from_mail/ || /to_mails/ || /display_mail/ || /smtp_server/' | cut -d"#" -f1 > $DIR/temp/tmp.file
config_file=$DIR/temp/tmp.file
oldIFS="$IFS"
IFS="="
while read name value
do
    eval $name="$value"
done < $config_file
IFS="$oldIFS"



# Start Script
printLog "###################### Start ######################"
rm $DIR/temp/*
printLog "rm $DIR/temp/*"
getSICDRs
for (( i=0;i<$numberOfCampagins;i++))
do
        campaign[$i]=$(sed -n '/\[Campaigns]/,/\[/p' $config_in | awk  '!/\[Campaigns]/ && !/\[/' | sed 's/[[:space:]]//g' | grep campaign$i | cut -d"=" -f2)
        printLog "campaign$i = ${campaign[$i]}"
        Offer_Definition_External_IDs[$i]=$(sed -n '/\[Campaigns]/,/\[/p' $config_in | awk  '!/\[Campaigns]/ && !/\[/' | sed 's/[[:space:]]//g' | grep offerDefExtId$i | cut -d"=" -f2)
        printLog "Offer_Definition_External_IDs$i = ${Offer_Definition_External_IDs[$i]}"
        OfferDefinitionExternalID=(`echo ${Offer_Definition_External_IDs[$i]} | sed 's/,/ /g'`)
        OfferDefinitionExternalIDsLength=${#OfferDefinitionExternalID[@]}
        stats_campagin_total=0
        for (( j=0;j<$OfferDefinitionExternalIDsLength;j++))
        do
                printLog "stats_campagin[$j]=$\(grep \"$SINname,${OfferDefinitionExternalID[$j]},1\" $DIR/temp/* | wc -l | tr -d ' ')"
                stats_campagin[$j]=$(grep "$SINname,${OfferDefinitionExternalID[$j]},1" $DIR/temp/* | wc -l | tr -d ' ')
                let stats_campagin_total+=${stats_campagin[$j]}
        done
        printLog "Stats for Campaign =  ${campaign[$i]}"
        printLog "Number of LB SMS   =  $stats_campagin_total"
        printStat "cont" "${campaign[$i]}" "$stats_campagin_total"
done
totalLBSMS=$(grep SR_EOBN_LowBalance_SMSNotify $DIR/temp/* | wc -l | tr -d ' ')
printLog "totalLBSMS=$\(grep SR_EOBN_LowBalance_SMSNotify $DIR/temp/* | wc -l | tr -d ' ')"
printLog "TOTAL LB SMS       =  $totalLBSMS"
printStat "end" "$totalLBSMS"
if [ `echo "$emailenable" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$emailenable" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
sendMail
else
printLog "Email is not enabled"
fi



else
if [ -z "$h" ];then
printhelp
fi
fi