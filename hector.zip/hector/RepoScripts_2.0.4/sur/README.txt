d0) Set this alias
0.1) tango bashrc
vi /home/tango/.bashrc
alias sur='/tango/logs/COSTAFF/hector/sh_scripts/sur/.rus'

source /home/tango/.bashrc

0.2) Also add this in root bashrc
vi  /root/.bashrc
alias rte2dmz='/tango/logs/COSTAFF/hector/sh_scripts/sur/.rus;/tango/logs/COSTAFF/hector/sh_scripts/sshLogin.sh rte2dmz root'

1) Update sur password
1.1) Get hash
echo -n "." | md5sum
1.2) Update it in /tango/logs/COSTAFF/hector/sh_scripts/sur/.rus in placeholder "hash"

2) Set keys and Encrypt "<rootpassword>,<GenericPassword>"
Notes:
- <GenericPassword> is the one used in step  1.1)
- Note both are separated by a comma

2.1) Create private and pub keys  (as tango user)
cd /tango/logs/COSTAFF/hector/
openssl genrsa -out /tango/logs/COSTAFF/hector/sh_scripts/sur/rsa_key.pri 2048; openssl rsa -in /tango/logs/COSTAFF/hector/sh_scripts/sur/rsa_key.pri -out /tango/logs/COSTAFF/hector/sh_scripts/sur/rsa_key.pub -outform PEM -pubout

2.2) Generate secret.dat

echo "bernabeuT0ur1,." | openssl rsautl -encrypt -inkey /tango/logs/COSTAFF/hector/sh_scripts/sur/rsa_key.pub -pubin -out /tango/logs/COSTAFF/hector/sh_scripts/sur/secret.dat

or (when there is an intermediate user that has direct permission to su to root like in Mobily or Digicel)

echo -e "\nssh csg@localhost\nsudo su -\n\nP@pUx65lg*TX@OC8\n" | openssl rsautl -encrypt -inkey /tango/logs/COSTAFF/hector/sh_scripts/sur/rsa_key.pub -pubin -out /tango/logs/COSTAFF/hector/sh_scripts/sur/secret.dat

2.3) Remove public password if you want to
del /tango/logs/COSTAFF/hector/sh_scripts/sur/rsa_key.pub

2.4) Install .rus
cp /tango/logs/COSTAFF/hector/RepoScripts/sur/.rus /tango/logs/COSTAFF/hector/sh_scripts/sur/.rus

3) Set root ssh access via atlaskey
3.1) crontab (root)

*/5 * * * * /tango/logs/COSTAFF/hector/sh_scripts/sur/.rus -r >/dev/null 2>&1

3.2) Drop authorized_keys (as tango user)
cp /tango/logs/COSTAFF/hector/sh_scripts/sur/authorized_keys.StopRecover  /tango/logs/COSTAFF/hector/sh_scripts/sur/authorized_keys

3.3) Stop recovery

del /tango/logs/COSTAFF/hector/sh_scripts/sur/authorized_keys

3.4) Get rid of README.txt as it has too much information
del /tango/logs/COSTAFF/hector/sh_scripts/sur/README.txt