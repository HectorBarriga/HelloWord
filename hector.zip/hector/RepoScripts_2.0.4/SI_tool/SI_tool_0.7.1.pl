#!/usr/bin/perl

###############################################################################
# Filename:    SI_tool.pl
# Author:      Hector Barriga
#
# Jiras:
# CO Scripts:  COSC-105
#
# SI_tool, perl script, only for Linux OS, is to illustrate a Service Definition (SD) already deployed on the Service Interpreter (SI).
# It is suitable to communicate with an existing SI SD by sending requests and receiving responses via HTTP server.
#
# The HTTP SI_tool relies on a HTTP server being initialised during the USSD SI start-up. Make sure it is configured
# Also, HTTP SI_tool relies on USSD SI CDRs SIN names activated. Make sure they are activated
#
# This script will then display User Requests and/Or User Notifies. Besides, it also displays SI CDRs for each SI
# interaction and remote App CDRs which is helpful for monitoring
#
# Copyright (c) Tango Telecom 2018
# Author: Hector Barriga
#
# All rights reserved.
# This document contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or
# in part is expressly prohibited, except as may be specifically
# authorized by prior written agreement or permission of Tango Telecom.
##############################################################################
# version 0.1.0 - First version
# version 0.2.13 - Add Inputs and Outputs to Server Requests and JavaScripts Screens
# version 0.3.3 - Support script on both Linux and Unix (SunSo) servers
# version 0.3.4 - Adding Version
# version 0.3.5 - Bug: Sending empty SC shouldnt not be allowed
# version 0.4.0 - Introduce option "back" to change MSISDN
# version 0.4.1 - Introduce CDR Map Errors to display Warnings
# version 0.5.0 - Introduce cdrmon mode
# version 0.5.1 - Introduce remote app responses
# version 0.5.2 - Introduce auto-exit
# version 0.5.3 - Add HRG CDR Map Errors
# version 0.5.4 - Add CMGR CDR Map Errors
# version 0.6.0 - Introduce remote Server CDRs
# version 0.6.1 - Fix a Cause Of Termination Bug
# version 0.6.1 - Add Activity Meter
# version 0.6.2 - Add SI API json USSD request
# version 0.7.0 - Evolve SI_tool into SIBB_tool
my $version="0.7.0";
##
###############################################################################

#Libraries
use LWP::UserAgent;
use Term::ANSIColor;
use File::Compare;
use Getopt::Std;
use Term::ReadLine;
use List::MoreUtils qw(uniq);
use Time::HiRes 'gettimeofday', 'tv_interval', qw( sleep );
use Date::Parse;
use IO::Handle;
use IO::Select;
use JSON;

###### Get arguments

if ( 0 == getopts( "h:s:a:j:c:m:p:f:t:w:i:r:d:" ) )
{
        usage();
        exit 0;
}

if ( defined( $opt_h ) )
{
        usage();
}

if ( defined( $opt_s ) )
{
        $SINscreenWide = $opt_s;
}
else
{
        $SINscreenWide = '75';
}

if ( defined( $opt_a ) )
{
        $HTTP_REST_API_WS = $opt_a;
}

if ( defined( $opt_j ) )
{
        $serviceCodeJson = $opt_j;
}

if ( defined( $opt_c ) )
{
        $CDRscreenWide = $opt_c;
}
else
{
       $CDRscreenWide = '120'
}

if ( defined( $opt_m ) )
{
        $msisdnInt = $opt_m;
        $msisdnIntFlag = 'true';
}
else
{
        $msisdnInt = $testmsisdn;
}

if ( defined( $opt_p ) )
{
        $CDRCorrelationIDIllustrator = $opt_p;
        $Illustrator_mode = "cdrmon";
        $key="noNull";
        print color("yellow"),"\n==============================================================================================\n", color("reset");
        print color("green"),"\n                                     WELCOME TO SI_tool\n                                       Version $version\n",color("yellow"),"==============================================================================================\n\n",color("reset");
}
else
{
        $CDRCorrelationIDIllustrator = "false";
        $Illustrator_mode="off";
        $key="";
}
if ( defined( $opt_f ) )
{
        $file__ussd_si_cdrs = $opt_f;
}
if ( defined( $opt_t ) )
{
        $tps = $opt_t;
}
else
{
        $tps = '100';
}
if ( defined( $opt_w ) )
{
        $timewindow = $opt_w;
}
else
{
       $timewindow = '10'
}
if ( defined( $opt_r ) )
{
        $opt_r=~ s/ /\%20/g;
        $ussdString = $opt_r;
}
if ( defined( $opt_d ) )
{
        $cdrpattern = $opt_d;
}
else
{
        $cdrpattern = 'deactivated';
}
if ( defined( $opt_i ) )
{
        $incremental = $opt_i;
}
else
{
        $incremental = 'no';
}

#Parameters
my $copycommand = qx(which cp);
chomp $copycommand;
my $mkdircommand = qx(which mkdir);
chomp $mkdircommand;
my $touchcommand = qx(which touch);
chomp $touchcommand;
my $mvcommand = qx(which mv);
chomp $mvcommand;
my $operativeSystem = qx(uname);
chomp $operativeSystem;
my $host_name = qx(hostname);
chomp $host_name;
my $getPerlTermReadLineGnu = qx(rpm -qa | grep perl-Term-ReadLine-Gnu | wc -l);
chomp $getPerlTermReadLineGnu;
my $term = Term::ReadLine->new('My shell');
$term->ornaments(0);
my $ua = LWP::UserAgent->new(keep_alive=>1);
$req = HTTP::Request->new(GET);
$req->protocol('HTTP/1.1');
$acclinecounter = 0;
my $nb_stdin = new IO::Select( *STDIN );

# Configs
getConfigs();

# Initial Parameters
my $spawnSIFilesh = '.spawn_SI.sh';
my $autologoutActive = 'no';
my $logout=$logoutTime*60;
my $logout30=$logout - 30;
my $logout10=$logout - 10;
my @SEhttpServercfgFilesplit = split "/" , $SEhttpServercfgFile;
my $SEhttpServercfgOutFile = "${SIsimScriptDir}/.${SEhttpServercfgFilesplit[-1]}.sisim";
my $spawnSIshOutFile = "${SIsimScriptDir}${spawnSIFilesh}";
my $USSD_servicesDirFile = "${ussd_si_sd_servicesDir}/${USSD_servicesFile}";
my $USSD_scriptsDirFile = "${ussd_si_sd_servicesDir}/${USSD_scriptsFile}";
my $send_configReload_to_USSD_siOamFlag = 'false';
my $send_reloadConfig_to_HTTP_oamFlag = 'false';
my $getDuplications = 'false';
my $SINscreenWides = $SINscreenWide."s";
my $RMscreenWide = $SINscreenWide-20;
my $RMscreenWides = $RMscreenWide."s";
my $RMscreenWide1 = $RMscreenWide+1;
my $SINscreenContentWide = $SINscreenWide-2;
my $SINscreenContentWide2 = $SINscreenContentWide*2;
my $SINscreenContentWide3 = $SINscreenContentWide*3;
my $CDRscreenWides = $CDRscreenWide."s";
my $CDRscreenContentWide = $CDRscreenWide-2;
my @USSD_SI_VersionNum = split "-" , $USSD_SI_Version ;
my $noCDRs="true";
my $sendVerbose="true";
my $newdeploymentFlag="no";
my $opt_h="noHelp";
if ($USSD_SI_VersionNum[2] gt '46')
{
        $SINnameCDRnum = '16';
}
elsif ($USSD_SI_VersionNum[2] eq '46' and $USSD_SI_VersionNum[3] gt '6')
{
        $SINnameCDRnum = '16';
}
elsif ($USSD_SI_VersionNum[2] eq '46' and $USSD_SI_VersionNum[3] eq '6' and $USSD_SI_VersionNum[4] ge '1')
{
        $SINnameCDRnum = '16';
}
else
{
        $SINnameCDRnum = '15';
}
if ($USSD_SI_VersionNum[2] lt '32')
{
        $SIversionURLFlag = 'low';
}





#Script
# ----------------------------------------------------------------------------------------------------------------------

$checkIfSI_toolRunning = qx(ps -ef | grep SI_tool | egrep -v grep | egrep -v vim | wc -l );
chomp($checkIfSI_toolRunning);
if ( defined( $opt_p ) and defined( $opt_r )){print color("red"),"\nSORRY! Flag -r and -p can not be defined together. Run SI_tool.pl -h. Bye\n",color("reset");exit;}
if ( defined( $opt_r ))
{
        if ($SE_httpServer_Configured_Ok eq "yes")
        {
                print color("red"),"\nSORRY! \$SE_httpServer_Configured_Ok parameter is TRUE. Hence, you cannot use SI_tool multi-trigger mode in \"quick use\" (using flags).\n\nHowever, you can use the multi-trigger mode on the SI_tool console. Just run SI_tool.pl and send command \" multitrigger \" and enter all needed parameters.\nFor more help, Run SI_tool.pl -h. Bye\n\n",color("reset");
                exit;
        }
        if ($HTTP_REST_API_WS eq "USSD_siWebService")
        {
                $jsonData=$ussdString;
        }
        triggermode();
        exit;
}

if ( defined( $opt_p ))
{
        if ( $checkIfSI_toolRunning != "1")
        {
                if ( $checkIfSI_toolRunning != "0")
                {
                        print color("red"),"\nSORRY! \"SI_tool\" is already being RUN by SOMEONE else. Only 1 SI_tool allowed per server. So, I am going to cancel this now to protect the other SI_tool process temporal backups. Bye\n",color("reset");
                        exit;
                }
        }
}
else
{
        if ( $checkIfSI_toolRunning != "1")
        {
                print color("red"),"\nSORRY! \"SI_tool\" is already being RUN by SOMEONE else. Only 1 SI_tool allowed per server. So, I am going to cancel this now to protect the other SI_tool process temporal backups. Bye\n",color("reset");
                if ( $operativeSystem eq "Linux")
                {
                        qx(ps -ef | grep SI_tool | egrep -v grep | sort | tail -1 | tr -s " " | cut -d " " -f 2 | xargs kill -9);
                }
                else
                {
                        qx(ps -ef | grep SI_tool | egrep -v grep | sort | tail -1 | tr -s " " | cut -d " " -f 3 | xargs kill -9);
                }
        }
}

unless (-e "$spawnSIshOutFile" )
{
        write_spawn_SIshFile($USSD_SI_port);
        print color("green"),"\nINFO: .spawn_SI.sh file didnt exist. It is Ok now, I just created. I need it to be able to telnet(spawn) to SI to send state machine requests\n", color("reset");
}
if ($SIversionURLFlag eq "low")
{
        $msisdnInt = "123456789";
        print color("yellow"),"\n==============================================================================================\n", color("reset");
        print color("green"),"\n                                     WELCOME TO SI_tool\n                                       Version $version\n",color("red"),"                                   Send \"exit\"  to quit\n",color("green"),"Since SI version is ",color("reset"),"$USSD_SI_Version ",color("green"),"MSISDN will be $msisdnInt and cant be changed\n",color("reset");
        commands();
        if ( $getPerlTermReadLineGnu != "1")
        {
        print color("red"),"------------------------------------------------------------------\n";
        print color("red"),"\nWARNING! \"perl package perl-Term-ReadLine-Gnu\" is not installed.\nYou can continue and use SI_tool but it will be good to install it.\n               yum install perl-Term-ReadLine-Gnu*.rpm\n";
        print color("red"),"-------------------------------------------------------------------\n\n",color("reset");
        }
}
else
{
        if ($msisdnIntFlag ne "true")
        {
                if ($Illustrator_mode ne "cdrmon")
                {
                        print color("yellow"),"\n==============================================================================================\n", color("reset");
                        print color("green"),"\n                                     WELCOME TO SI_tool\n                                       Version $version\n",color("red"),"                                   Send \"exit\"  to quit\n",color("reset");
                        if ( $getPerlTermReadLineGnu != "1")
                        {
                                print color("red"),"-------------------------------------------------------------------\n";
                                print color("red"),"\nWARNING! \"perl package perl-Term-ReadLine-Gnu\" is not installed.\nYou can continue and use SI_tool but it will be good to install it.\n                yum install perl-Term-ReadLine-Gnu*.rpm\n",color("reset");
                                print color("red"),"-------------------------------------------------------------------\n\n",color("reset");
                        }
                        print color("yellow"),"\n==============================================================================================\n\n", color("reset");
                        print color("yellow"),"\n==============================================================================================\n\n", color("reset");
                                                unless ($HTTP_REST_API_WS eq "USSD_siWebService")
                                                {
                                                                $prompt="\e[0mEnter MSISDN including Country Code  (Default=$testmsisdn) [press \"Enter\" key to continue] > ";
                                                                $msisdnIn = $term->readline($prompt);
                                                                $term->addhistory($msisdnIn);
                                                                chomp($msisdnIn);
                                                                if ($msisdnIn ne "")
                                                                {
                                                                                if ($msisdnIn eq "exit")
                                                                                {
                                                                                                addHistory("$msisdnIn");
                                                                                                exit;
                                                                                }
                                                                                else
                                                                                {
                                                                                                $msisdnInt = $msisdnIn;
                                                                                                addHistory("$msisdnIn");
                                                                                }
                                                                }
                                                                else
                                                                {
                                                                                $msisdnInt = "$testmsisdn";
                                                                }
                                                }
                }
        }
        else
        {
                print color("yellow"),"\n==============================================================================================\n", color("reset");
                print color("green"),"\n                                     WELCOME TO SI_tool\n                                       Version $version\n",color("red"),"                                   Send \"exit\"  to quit\n",color("reset");
                if ( $getPerlTermReadLineGnu != "1")
                {
                        print color("red"),"-------------------------------------------------------------------\n";
                        print color("red"),"\nWARNING! \"perl package perl-Term-ReadLine-Gnu\" is not installed.\nYou can continue and use SI_tool but it will be good to install it.\n                yum install perl-Term-ReadLine-Gnu*.rpm\n",color("reset");
                        print color("red"),"-------------------------------------------------------------------\n\n",color("reset");
                }
                print color("yellow"),"\n==============================================================================================\n";
        }
}
if ($Illustrator_mode ne "cdrmon")
{
        $ussdsimsisdnInt = join "0", ( $msisdnInt =~ m/(.)/g );


$iskeyjavaScriptTagkeyHistory = 1;
while ( $iskeyjavaScriptTagkeyHistory == "1" )
{
        $prompt="\n\e[0mEnter JavaScript names separated by commas to display INPUTS/OUTPUTS [press \"Enter\" to skip] > ";
        $javaScriptTagkey = $term->readline($prompt);
        $term->addhistory($javaScriptTagkey);
        chomp($javaScriptTagkey);
        if ( $javaScriptTagkey ne "")
        {
                if ($javaScriptTagkey eq "exit")
                {
                        addHistory("$javaScriptTagkey");
                        exit;
                }
                else
                {
                        @javaScriptAllTagskey = split "," , $javaScriptTagkey;
                        $javaScriptTagkeyFlag = 'yes';
                        $autologoutActive = 'yes';
                        @javaScriptAllTags = uniq @javaScriptAllTagskey;
                        addHistory("$javaScriptTagkey");
                        $iskeyjavaScriptTagkeyHistory = 0;
                }
        }
        else
        {
                $javaScriptTagkeyFlag = 'false';
                $autologoutActive = 'no';
                $iskeyjavaScriptTagkeyHistory = 0;
        }


        @historykey = split  /\|/ , $javaScriptTagkey;
        @historykeypattern = split( 'grep ', $historykey[1] );
        if ( $historykey[0] == "history" and $historykey[1] ne "" )
        {
                $javaScriptTagkey = 'history';
                $nohistorygrep = 'no';
        }
        else
        {
                $nohistorygrep = 'yes';
        }
        if ($javaScriptTagkey eq "history")
        {
                print color("yellow"),"\n==============================================================================================\n",color("reset");
                print color("green"),"\n                                     SI_tool History\n                                       \n",color("reset");
                if ($nohistorygrep eq "no")
                {
                        system("cat $SIsimScriptDir/.SI_tool_history | grep $historykeypattern[1]");
                }
                else
                {
                       system("cat $SIsimScriptDir/.SI_tool_history");
                }

                $| = 1 ;
                $iskeyjavaScriptTagkeyHistory = 1;
        }

}



        startSIsim('start');
        $SIG{INT} = \&interrupt;
        sub interrupt
        {
            print STDERR color("red")," Send \"exit\"  to quit :) ",color("reset"),"> "
        }
        if ( $operativeSystem eq 'Linux')
        {
                chomp(my @checkExpect = `rpm -qa | grep expect`);
                if ( $checkExpect[-1] eq "" )
                {
                        print color("red"),"\nWARNING! \"expect\" package is not installed. It is used to spawn Service Interpreter to send state machine requests\nAs root, run this command: yum install -y expect*",color("reset");
                        print color("green"),"\nIN THE MAINTIME, telnet SI (telnet 0 $USSD_SI_port) and send verbose temporarely or other requests MANUALLY",color("reset");
                        print "\nAre you sure you want to continue? [If yes, press Return. If not, enter exit] > ";
                        $continue0 = <STDIN>;
                        chomp($continue0);
                        if ( $continue0 eq "exit"){exit;}
                }
        }
}
if ($Illustrator_mode ne "cdrmon"){commands();}
while(true)
{
        $scp_CDRs_done = "noYet";
        $hrgResourceFoundhits = '0';
        if ($Illustrator_mode ne "cdrmon")
        {
                print "\n";
                                unless ($HTTP_REST_API_WS eq "USSD_siWebService")
                                {
                                                system("echo -n  '\e[44m [MSISDN=$msisdnInt] SEND > \e[0m'");
                                }
                                else
                                {
                                                system("echo -n  '\e[44m [USSD_siWebService - JSON String] SEND > \e[0m'");
                                                $msisdnInt=$testmsisdn;
                                }
                if ($autologoutActive eq "yes")
                {
                        $key = 'noInput';
                        while($key eq "noInput")
                        {
                                if ( $nb_stdin -> can_read(0) )
                                {
                                        $prompt="";
                                        $key = $term->readline($prompt);
                                        $term->addhistory($key);
                                        chomp($key);
                                        addHistory("$key");
                                        $q=0;
                                }
                                else
                                {
                                        sleep 1;
                                        if ($q eq $logout30){system("echo -n  '\n\e[41m [Exiting in 30 secs] SEND NOW > \e[0m'");}
                                        if ($q eq $logout10){system("echo -n  '\n\e[41m [Exiting in 10 secs] SEND NOW > \e[0m'");}
                                        if ($q eq $logout){exit;}
                                }
                                $q=$q+1;
                        }
                }
                else
                {
                        $prompt="";
                        $key = $term->readline($prompt);
                        $term->addhistory($key);
                        chomp($key);
                        addHistory("$key");
                }
        }

        @historykey = split  /\|/ , $key;
        @historykeypattern = split( 'grep ', $historykey[1] );
        if ( $historykey[0] == "history" and $historykey[1] ne "" )
        {
                $key = 'history';
                $nohistorygrep = 'no';
        }
        else
        {
                $nohistorygrep = 'yes';
        }


        if ($key eq "" and $Illustrator_mode ne "cdrmon")
        {
                my $tryagain = 0;
                while($tryagain == 0)
                {
                        print colored("You must send something. Try again\n",'red');
                        commands();
                        unless ($HTTP_REST_API_WS eq "USSD_siWebService")
                                                {
                                                                system("echo -n  '\e[44m [MSISDN=$msisdnInt] SEND > \e[0m'");
                                                }
                                                else
                                                {
                                                                system("echo -n  '\e[44m [USSD_siWebService - JSON String] SEND > \e[0m'");
                                                }
                        if ($autologoutActive eq "yes")
                        {
                                $key = 'noInput';
                                while($key eq "noInput")
                                {
                                        if ( $nb_stdin -> can_read(0) )
                                        {
                                                print color("reset"),"\n";
                                                $prompt="";
                                                $key = $term->readline($prompt);
                                                $term->addhistory($key);
                                                chomp($key);
                                                unless ($key eq ""){$tryagain = 1;addHistory("$key");}
                                                $q=0;
                                        }
                                        else
                                        {
                                                sleep 1;
                                                if ($q eq $logout30){system("echo -n  '\n\e[41m [Exiting in 30 secs] SEND NOW > \e[0m'");}
                                                if ($q eq $logout10){system("echo -n  '\n\e[41m [Exiting in 10 secs] SEND NOW > \e[0m'");}
                                                if ($q eq $logout){exit;}
                                        }
                                        $q=$q+1;
                                }
                        }
                        else
                        {
                                $prompt="";
                                $key = $term->readline($prompt);
                                $term->addhistory($key);
                                chomp($key);
                                addHistory("$key");
                                unless ($key eq ""){$tryagain = 1;addHistory("$key");}
                        }
                };

        }
        if ($key eq "exit")
        {
                addHistory("$key");
                exit;
        }
        elsif ($key eq "back")
        {
                        addHistory("$key");
                        print color("yellow"),"\n==============================================================================================\n",color("reset");
                        print color("green"),"\n                                     WELCOME TO SI_tool\n                                       Version $version\n",color("red"),"                                   Send \"exit\"  to quit\n",color("reset");
                        print color("yellow"),"\n==============================================================================================\n\n",color("reset");
                                                $prompt="\e[0mEnter HTTP_REST_API_WS ( Options: SI_Http_MI_Interface or USSD_siWebService Default = USSD_siWebService ) [press Enter to use default] > ";
                                                $HTTP_REST_API_WS = $term->readline($prompt);
                                                $term->addhistory($HTTP_REST_API_WS);
                                                chomp($HTTP_REST_API_WS);
                                                if ( $HTTP_REST_API_WS ne "USSD_siWebService" and $HTTP_REST_API_WS ne "")
                                                {
                                                                $HTTP_REST_API_WS = $HTTP_REST_API_WS;
                                                                addHistory("$HTTP_REST_API_WS");
                                                                $prompt="\e[0mEnter MSISDN including Country Code  ( Default = $msisdnInt ) [press Enter to use default] > ";
                                                                $msisdnIn = $term->readline($prompt);
                                                                $term->addhistory($msisdnIn);
                                                                chomp($msisdnIn);
                                                                if ($msisdnIn ne "") { $msisdnInt = $msisdnIn;addHistory("$msisdnIn"); }
                                                                else {print color("red"),"You didnt enter a valid MSISDN. It remains the same $msisdnInt.\n",color("reset");}
                                                                $ussdsimsisdnInt = join "0", ( $msisdnInt =~ m/(.)/g );
                                                }
                                                elsif ($HTTP_REST_API_WS eq "")
                                                {
                                                                $HTTP_REST_API_WS = "USSD_siWebService";
                                                }

        }
        elsif ($key eq "history")
        {
                        print color("yellow"),"\n==============================================================================================\n",color("reset");
                        print color("green"),"\n                                     SI_tool History\n                                       \n",color("reset");
                        if ($nohistorygrep eq "no")
                        {
                                system("cat $SIsimScriptDir/.SI_tool_history | grep $historykeypattern[1]");
                        }
                        else
                        {
                                system("cat $SIsimScriptDir/.SI_tool_history");
                        }
        }
        elsif ($key eq "multitrigger" and $HTTP_REST_API_WS ne "USSD_siWebService")
        {
                addHistory("$key");
                print "\nThis is to trigger SI multiple times. Important Notes:\n";
                print "- Session will run on the background. Hence, UR will not be able to be responded by user and session will timeout\n";
                print "- This will be useful to trigger SD where handset is not involved\n\n";
                $prompt=colored(" [multi-trigger Mode] Enter ussdString >",'white on_blue')," ";
                $key = $term->readline($prompt);
                $term->addhistory($key);
                chomp($key);
                addHistory("$key");
                unless ($key eq "")
                {
                        $key=~ s/ /\%20/g;
                        $ussdString=$key;
                        $prompt=colored(" [multi-trigger Mode] Enter TPS [Default=100] > ",'white on_blue')," ";
                        $key = $term->readline($prompt);
                        $term->addhistory($key);
                        chomp($key);
                        if ($key eq ""){$tps='100';}
                        else{$tps=$key;addHistory("$key");}
                        $prompt=colored(" [multi-trigger Mode] How long?(secs) [Default=10] > ",'white on_blue')," ";
                        $key = $term->readline($prompt);
                        $term->addhistory($key);
                        chomp($key);
                        if ($key eq ""){$timewindow='10';}
                        else{$timewindow=$key;addHistory("$key");}
                        $prompt=colored(" [multi-trigger Mode] Enter MSISDN [Default=$msisdnInt] > ",'white on_blue')," ";
                        $key = $term->readline($prompt);
                        $term->addhistory($key);
                        chomp($key);
                        if ($key ne ""){$msisdnInt=$key;addHistory("$key");}
                        $prompt=colored(" [multi-trigger Mode] For each hit, do you want to increment msisdns by 1 [Default = no] (yes/no) > ",'white on_blue')," ";
                        $key = $term->readline($prompt);
                        $term->addhistory($key);
                        chomp($key);
                        if ($key eq ""){$incremental='no';}
                        else{$incremental=$key;addHistory("$key");}
                        $prompt=colored(" [multi-trigger Mode] Enter first CDR \"pattern\" to get CDR hits  [Default = no] > ",'white on_blue')," ";
                        $key = $term->readline($prompt);
                        $term->addhistory($key);
                        chomp($key);
                        if ($key eq ""){$cdrpattern='deactivated';}
                        else{$cdrpattern=$key;addHistory("$key");}
                        $prompt=colored(" [multi-trigger Mode] Enter second CDR \"pattern\" to get CDR hits [Default = no] > ",'white on_blue')," ";
                        $key = $term->readline($prompt);
                        $term->addhistory($key);
                        chomp($key);
                        if ($key eq ""){$cdrpattern2='deactivated';}
                        else{$cdrpattern2=$key;addHistory("$key");}
                        print color("yellow"),"\n======= multi-trigger mode =======\n";
                        triggermode();
                }
                else
                {
                        print color("red"),"You didnt enter a valid ussdString. Try again.\n",color("reset");
                }
        }
        elsif ($key eq "multitrigger" and $HTTP_REST_API_WS eq "USSD_siWebService")
        {
                addHistory("$key");
                print "\nThis is to trigger SI multiple times. Important Notes:\n";
                print "- Session will run on the background. Hence, UR will not be able to be responded by user and session will timeout\n";
                print "- This will be useful to trigger SD where handset is not involved\n\n";
                $prompt=colored(" [multi-trigger Mode] Enter JSON string DATA (Must include {} and Do not include msisdn and serviceCode) > ",'white on_blue')," ";
                $key = $term->readline($prompt);
                $term->addhistory($key);
                chomp($key);
                addHistory("$key");
                unless ($key eq "")
                {
                        $jsonData=$key;
                        $prompt=colored(" [multi-trigger Mode] Enter serviceCode [Default=$serviceCodeDefault] > ",'white on_blue')," ";
                        $key = $term->readline($prompt);
                        $term->addhistory($key);
                        chomp($key);
                        if ($key eq ""){$serviceCodeJson=$serviceCodeDefault;}
                        else{$serviceCodeJson=$key;addHistory("$key");}
                        $prompt=colored(" [multi-trigger Mode] Enter MSISDN [Default=$testmsisdn] > ",'white on_blue')," ";
                        $key = $term->readline($prompt);
                        $term->addhistory($key);
                        chomp($key);
                        if ($key ne ""){$msisdnInt=$key;addHistory("$key");}
                        $prompt=colored(" [multi-trigger Mode] Enter TPS [Default=100] > ",'white on_blue')," ";
                        $key = $term->readline($prompt);
                        $term->addhistory($key);
                        chomp($key);
                        if ($key eq ""){$tps='100';}
                        else{$tps=$key;addHistory("$key");}
                        $prompt=colored(" [multi-trigger Mode] How long?(secs) [Default=10] > ",'white on_blue')," ";
                        $key = $term->readline($prompt);
                        $term->addhistory($key);
                        chomp($key);
                        if ($key eq ""){$timewindow='10';}
                        else{$timewindow=$key;addHistory("$key");}
                        $prompt=colored(" [multi-trigger Mode] For each hit, do you want to increment msisdns by 1 [Default = no] (yes/no) > ",'white on_blue')," ";
                        $key = $term->readline($prompt);
                        $term->addhistory($key);
                        chomp($key);
                        if ($key eq ""){$incremental='no';}
                        else{$incremental=$key;addHistory("$key");}
                        $prompt=colored(" [multi-trigger Mode] Enter first CDR \"pattern\" to get CDR hits  [Default = no] > ",'white on_blue')," ";
                        $key = $term->readline($prompt);
                        $term->addhistory($key);
                        chomp($key);
                        if ($key eq ""){$cdrpattern='deactivated';}
                        else{$cdrpattern=$key;addHistory("$key");}
                        $prompt=colored(" [multi-trigger Mode] Enter second CDR \"pattern\" to get CDR hits [Default = no] > ",'white on_blue')," ";
                        $key = $term->readline($prompt);
                        $term->addhistory($key);
                        chomp($key);
                        if ($key eq ""){$cdrpattern2='deactivated';}
                        else{$cdrpattern2=$key;addHistory("$key");}
                        print color("yellow"),"\n======= multi-trigger mode =======\n";
                        triggermode();
                }
                else
                {
                        print color("red"),"You didnt enter a valid ussdString. Try again.\n",color("reset");
                }
        }
        elsif ($key eq "cdrmon")
        {
                addHistory("$key");
                $noCDRs="true";
                print "";
                $prompt=colored(" [cdrmon Mode] Enter sessionID > ",'white on_blue')," ";
                $key = $term->readline($prompt);
                $term->addhistory($key);
                chomp($key);
                my $CDRCorrelationIDIllustrator=$key;
                $prompt=colored(" [cdrmon Mode] Enter file (Default = $active_ussd_si_cdrs) > ",'white on_blue')," ";
                $key = $term->readline($prompt);
                $term->addhistory($key);
                chomp($key);
                if ($key eq "")
                {
                        $file__ussd_si_cdrs=$active_ussd_si_cdrs;
                }
                else
                {
                        $file__ussd_si_cdrs=$key;
                        addHistory("$key");
                }
                if ($CDRCorrelationIDIllustrator eq "")
                {
                        print color("red"),"You didnt enter a valid Session ID. Try again.\n",color("reset");
                        $Illustrator_mode="off";
                }
                else
                {
                        addHistory("$CDRCorrelationIDIllustrator");
                        isSessionIDinFile("$CDRCorrelationIDIllustrator","$file__ussd_si_cdrs","$rollover_ussd_si_cdrs_dir","$rollover_ussd_si_cdrs_file_prefix");
                        if ($isSessionIDinRollOverFileFlag eq "yes")
                        {
                                print color("yellow"),"INFO!! session ID is not present in $file__ussd_si_cdrs. However, I found it in $foundSessionIDFile. So, I am going to use that one instead\n",color("reset");
                                $file__ussd_si_cdrs=$foundSessionIDFile;
                        }
                        $Illustrator_mode="cdrmon";
                        print_SIN_Screen($CDRCorrelationIDIllustrator,$file__ussd_si_cdrs,$Illustrator_mode);
                        $Illustrator_mode=$pushIllustrator_modeFlag[-1];
                }
        }
        elsif ($key eq "help")
        {
                addHistory("$key");
                usage();
                commands();
        }
        elsif ($key eq "display")
        {
                addHistory("$key");
                commands();
        }
        elsif ($Illustrator_mode eq "cdrmon")
        {
                unless ( defined($opt_f))
                {
                        $file__ussd_si_cdrs=$active_ussd_si_cdrs;
                }
                $SIG{INT} = \&interrupt2;
                if ($CDRCorrelationIDIllustrator ne "all")
                {
                        isSessionIDinFile("$CDRCorrelationIDIllustrator","$file__ussd_si_cdrs","$rollover_ussd_si_cdrs_dir","$rollover_ussd_si_cdrs_file_prefix");
                        if ($isSessionIDinRollOverFileFlag eq "yes")
                        {
                                print color("yellow"),"INFO!! session ID is not present in $file__ussd_si_cdrs. However, I found it in $foundSessionIDFile. So, I am going to use that one instead\n",color("reset");
                                $file__ussd_si_cdrs=$foundSessionIDFile;
                        }
                        print_SIN_Screen($CDRCorrelationIDIllustrator,$file__ussd_si_cdrs,$Illustrator_mode);
                        exit;
                }
                else
                {
                        unless (-e $file__ussd_si_cdrs){print color("red"),"\nCould not open ussd si cdrs file.  It might not be configured in SI_tool.pl. Run SI_tool -h for more details\n",color("reset");exit;}
                        open USSDSICDRFILEforAll, "<$file__ussd_si_cdrs" or die(color("reset"), "\nCould not open ussd si cdrs file. $! It might not be configured in SI_tool.pl. Run SI_tool -h for more details\n\n");
                        while(<USSDSICDRFILEforAll>)
                        {
                                chomp;
                                if( $_ =~ m/17,40/ )
                                {
                                        @CDRCorrelationIDIllustratorArray=split ",", $_;
                                        push (@storeAllCorrelationIDArray,$CDRCorrelationIDIllustratorArray[$CorrellationID_SICDR_FieldNum]);
                                        print "\n\n\n================================================================== SI Session ID : $CDRCorrelationIDIllustratorArray[$CorrellationID_SICDR_FieldNum] ==================================================================\n\n\n";
                                        print_SIN_Screen($CDRCorrelationIDIllustratorArray[$CorrellationID_SICDR_FieldNum],$file__ussd_si_cdrs,$Illustrator_mode);
                                }
                        }
                        close USSDSICDRFILEforAll;
                        exit;
                }
        }
        else
        {
                                if ($HTTP_REST_API_WS eq "SI_Http_MI_Interface")
                                {
                                                startSIsim('checkIfDeployed');
                                                if ($SIversionURLFlag eq "low")
                                                {
                                                                $url="http://127.0.0.1:$SI_Http_port/USSD_serviceInterpreter/$SI_Http_instance/se/facebook/?ussdString=".$key;
                                                }
                                                else
                                                {
                                                                $url="http://127.0.0.1:$SI_Http_port/USSD_serviceInterpreter/$SI_Http_instance/se/facebook/?msisdn=".$msisdnInt."&ussdString=".$key;
                                                }
                                                $req->url($url);
                                                $ua->default_header ("Connection" => "keep-alive");

                                                $res = $ua->request($req);
                                }
                                elsif ($HTTP_REST_API_WS eq "USSD_siWebService")
                                {
                                                $url="http://127.0.0.1:$SI_Http_port/USSD_serviceInterpreter/$SI_Http_instance/se/ussd-si-ws-request";
                                                $req = HTTP::Request->new(POST => $url);
                                                $req->content_type('application/json;charset=utf-8');
                                                $req->content($key);
                                                $ua = LWP::UserAgent->new;
                                                $res = $ua->request($req);
                                }

                # check the outcome
                #if ($res->is_success) {
                $Illustrator_mode="off";
                print_SIN_Screen($CDRCorrelationIDIllustrator,$file__ussd_si_cdrs,$Illustrator_mode);
                #}
                #else {
                #       print "Error: " . $res->status_line . "\n"
                #}
        }
};



#Subroutines
sub startSIsim
{
$startSIsimInput=$_[0];
if ($SE_httpServer_Configured_Ok ne "no" && $startSIsimInput eq "start" )
{
        startSIsimWarning();
        unless (-e "$SEhttpServercfgOutFile")
        {
                write_SE_httpServercfg();
                print color("green"),"\nINFO: .SE_httpServer.cfg.sisim didnt exist. It is Ok now, I just created. I need it to allow SI_tool to send request to SI via its HTTP interface\n", color("reset");
        }
        handleFileBackup($SEhttpServercfgFile,"backup");
        system("$copycommand -rfp /tango/config/SE_httpServer.cfg $SIsimScriptDir/.SE_httpServer.cfg.orig");
        system("$copycommand $SIsimScriptDir/.SE_httpServer.cfg.sisim /tango/config/SE_httpServer.cfg");
        $send_reloadConfig_to_HTTP_oamFlag = 'true';
        push (@pushsend_reloadConfig_to_HTTP_oamFlag,$send_reloadConfig_to_HTTP_oamFlag);
        send_reloadConfig_to_HTTP_oam("start");
        $autologoutActive = 'yes';
}
if ($startSIsimInput == "start" )
{
        reloadTempUSSD_SI_main();
}
if ($javaScriptTagkeyFlag eq "yes")
{
        reloadTempUSSD_SD_SI_files($startSIsimInput);
}
if ( $pushsend_configReload_to_USSD_siOamFlag[-1] eq "true" && $startSIsimInput eq "start")
{
        welcomeWarning();
        send_configReload_to_USSD_siOam("start");
}
if ($pushsend_configReload_to_USSD_siOamFlagNewDeployment[-1] eq "true")
{
        newDeployWarning();
        send_configReload_to_USSD_siOam("start");
        $sendVerbose="true";
}
if ( $sendVerbose eq "true")
{
        system("$spawnSIshOutFile verbose");
        print color("yellow"),"\nSending verbose to USSD_serviceInterpreter/$SI_Http_instance/serviceClient";
        if ( $operativeSystem eq 'SunOS')
        {
                print color("Cyan"),"\n\nONLY IF you get error ",color("red"),"Can't locate Expect.pm in \@INC",color("Cyan")," below, you need to install Expect perl module. (So might IO-Tty).\nDo the following: Exit, download Perl module(s) from http://search.cpan.org/ and as root, run these commands:\n1) perl Makefile.PL\n2) make\n3) make test\n4) make install\n5) Finally run correct permissions\n\n",color("red");
        @checkExpectModule = qx(perl -e "use Expect;");
        }
        print color("yellow"),"\n==============================================================================================\n", color("reset");
        $sendVerbose="false";
}
}


sub stopSIsim
{
if ($SE_httpServer_Configured_Ok ne "no" )
{
        system("$copycommand -rfp $SIsimScriptDir/.SE_httpServer.cfg.orig /tango/config/SE_httpServer.cfg");
}
reloadOrigUSSD_SI_main();
reloadOrigUSSD_SD_SI_files();
if ( $pushsend_reloadConfig_to_HTTP_oamFlag[-1] eq "true")
{
        send_reloadConfig_to_HTTP_oam("stop");
}
if ( $pushsend_configReload_to_USSD_siOamFlag[-1] eq "true")
{
        send_configReload_to_USSD_siOam("stop");
}
print "Bye.\n\n";
exit;
}

# Write temporal SE_httpServer.cfg if needed ( $SE_httpServer_Configured_Ok is enabled)
sub write_SE_httpServercfg
{
        my $SEhttpServercfgFile = <<'END_FILE';
[General]
HTTP requests enabled               = yes
#HTTP requests enabled               = no
Maximum connections                 = 256
Disabled status code                = 500
#Base directory                      = /tango/data/http
Base directory                      = /tango
Directory index                     = index.html
Request timeout                     = 10
Processing timeout                  = 60

[SE requests]
Enabled                             = yes
Disabled status code                = 500

[File requests]
Enabled                             = yes
Disabled status code                = 500

[Method requests]
Enabled                             = yes
Disabled status code                = 500

[Persistent connections]
Enabled                             = true
Maximum requests                    = 10
Idle timeout                        = 15

[Content Type]
default                             = text/plain
html                                = text/html
xml                                 = text/xml
xsl                                 = text/xml
css                                 = text/css

[Whitelist]
Number of addresses                 = 0
IP address 1                        = 127.0.0.1

[SE API Routing]
# This section configures mapping of URL to application string

# Match type . set to exact for exact matching, set to prefix for prefix matchin
MatchType = prefix

# Number of string maps to follow
NumberOfStringMaps = 2

# string map N in the format:
# applicationName, url1, url2,.,urlM
# Note that the application name must correspond to an entry in the
# [ApplicationX] sections
Map1 = ussdDialogue, facebook
Map2 = ussdSingle, ussdSingleRequest, ussdSingleNotification

# [ApplicationX]
# Application name = application name
# Application address = SE address of application
# Response timeout = time SE HTTP server should wait for a response from the
# application (in milliseconds)
[Application0]

Application name = ussdDialogue
Application address = SI_Http_MI_Interface/-
#Application address = UHSA_dialogueRouter/-
Response timeout = 40000

[Application1]
Application name = ussdSingle
Application address = SI_Http_MI_Interface/-
Response timeout = 40000

[URL Translation]
# This section is used to perform strip and replace on an incoming URL to get it
 # in the correct format for the SE HTTP server to parse

# Set to exact for exact matching, prefix for prefix matching
MatchType = prefix

# Number of string maps to follow
NumberOfStringMaps = 6

# String map N in the format:
# outputUrl, inputUrl
Map1 = USSD_httpServer/0/se/ussdOpen, ussdOpen
Map2 = USSD_httpServer/0/se/ussdRequest, ussdRequest
Map3 = USSD_httpServer/0/se/ussdNotification, ussdNotification
Map4 = USSD_httpServer/0/se/ussdClose, ussdClose
Map5 = USSD_httpServer/0/se/ussdSingleRequest, ussdSingleRequest
Map6 = USSD_httpServer/0/se/ussdSingleNotification, ussdSingleNotification
END_FILE

open(my $fh, '>', $SEhttpServercfgOutFile) or die "Could not write file '$SEhttpServercfgFile' $! It might not be configured in SI_tool.pl. Run SI_tool -h for more details";
print $fh $SEhttpServercfgFile;
close $fh;
}

sub write_spawn_SIshFile
{
$SIport = $_[0];
        my $spawnSIshFile = <<"END_FILE1";
#!/bin/bash
if [ "\$1" == "verbose" ];then
expect <<'EOF'
log_user 0
spawn telnet 0 $SIport
expect "assistance."
send "\\r"
expect "mon>"
send "r 0;\\r"
send "\\r"
expect "mon>"
send "a serviceClient;s verbose;\\r"
send "\\r"
expect "mon>"
send "r 0;\\r"
send "\\r"
expect "mon>"
send "quit\\r"
log_user 1
EOF
elif [ "\$1" == "quiet" ];then
expect <<'EOF'
log_user 0
spawn telnet 0 $SIport
expect "assistance."
send "\\r"
expect "mon>"
send "r 0;\\r"
send "\\r"
expect "mon>"
send "a serviceClient;s quiet;\\r"
send "\\r"
expect "mon>"
send "r 0;\\r"
send "\\r"
expect "mon>"
send "quit\\r"
log_user 1
EOF
elif [ "\$1" == "reloadSIconfigs" ];then
expect <<'EOF'
log_user 0
spawn telnet 0 $SIport
expect "assistance."
send "\\r"
expect "mon>"
send "r 0;\\r"
send "\\r"
expect "mon>"
send "a USSD_siOam;s configReload;\\r"
send "\\r"
expect "mon>"
send "r 0;\\r"
send "\\r"
expect "mon>"
send "quit\\r"
log_user 1
EOF
elif [ "\$1" == "HTTP_reloadConfig" ];then
expect <<'EOF'
log_user 0
spawn telnet 0 $SIport
expect "assistance."
send "\\r"
expect "mon>"
send "r 0;\\r"
send "\\r"
expect "mon>"
send "a HTTP_oam;s reloadConfig;\\r"
send "\\r"
expect "mon>"
send "r 0;\\r"
send "\\r"
expect "mon>"
send "quit\\r"
log_user 1
EOF
elif [ "\$1" == "HTTP_reloadWhiteList" ];then
expect <<'EOF'
log_user 0
spawn telnet 0 $SIport
expect "assistance."
send "\\r"
expect "mon>"
send "r 0;\\r"
send "\\r"
expect "mon>"
send "a HTTP_oam;s reloadWhiteList;\\r"
send "\\r"
expect "mon>"
send "r 0;\\r"
send "\\r"
expect "mon>"
send "quit\\r"
log_user 1
EOF
elif [ "\$1" == "HTTP_reloadSeRouting" ];then
expect <<'EOF'
log_user 0
spawn telnet 0 $SIport
expect "assistance."
send "\\r"
expect "mon>"
send "r 0;\\r"
send "\\r"
expect "mon>"
send "a HTTP_oam;s reloadSeRouting;\\r"
send "\\r"
expect "mon>"
send "r 0;\\r"
send "\\r"
expect "mon>"
send "quit\\r"
log_user 1
EOF
elif [ "\$1" == "HTTP_reloadUrlTranslate" ];then
expect <<'EOF'
log_user 0
spawn telnet 0 $SIport
expect "assistance."
send "\\r"
expect "mon>"
send "r 0;\\r"
send "\\r"
expect "mon>"
send "a HTTP_oam;s reloadUrlTranslate;\\r"
send "\\r"
expect "mon>"
send "r 0;\\r"
send "\\r"
expect "mon>"
send "quit\\r"
log_user 1
EOF
fi
END_FILE1
open(my $fh1, '>', $spawnSIshOutFile) or die "Could not write file '$spawnSIshFile' $! It might not be configured in SI_tool.pl. Run SI_tool -h for more details";
print $fh1 $spawnSIshFile;
close $fh1;
system("chmod 755 $spawnSIshOutFile");
}

sub startSIsimWarning
{
print color("yellow"),"\n==============================================================================================\n";
print color("red"),"WARNING! \$SE_httpServer_Configured_Ok parameter in SI_tool.pl is enabled.\n",color("yellow");
print "--I'm about to temporarely reload a new SE_httpServer.cfg in the SI via",color("red")," \"send reloadConfig to HTTP_oam\"",color("yellow")," to allow SI_tool to interact with SI HTTP interface. \n";
print "--Note that, I will recover/reload original SE_httpServer.cfg when closing the SI_tool \n";
print "==============================================================================================\n", color("reset");
$prompt="\n\e[0mAre you sure you want to continue? [If NOT, cancel with Control+C] [Otherwise, enter return] > ";
$continue = $term->readline($prompt);
$term->addhistory($continue);
chomp($continue);
unless (lc($continue) eq 'yes' or lc($continue) eq 'y' )
{
}
}

sub print_SIN_Screen
{
$CDRCorrelationIDIllustrator=$_[0];
$file__ussd_si_cdrs=$_[1];
$Illustrator_mode=$_[2];
printCDRsscreen($CDRCorrelationIDIllustrator,$file__ussd_si_cdrs,$Illustrator_mode);
if ($noCDRs ne "true")
{
        if ( $typeOfSIN eq "UN" )
        {
                $typeOfSINtitle = 'User Notify : '.$SINname[$SINnameCDRnum];
                $acclinecounter = 0;
                printf( "\e[0m\n%-$SINscreenWides", "                      V");;printf( "\e[0m\n%-$SINscreenWides", " ");printf( "\e[0m\n%-$SINscreenWides", "$typeOfSINtitle" );
                if ($UNErrorWarning ne "false" )
                {
                        printf( "\e[7;49;32m\n%-$SINscreenWides", "\e[1;31;42m$UNErrorWarning \e[0m" );
                        printf( "\e[7;49;32m\n %-$SINscreenWides", " " );
                        if ($CoTErrorWarning ne "false" )
                        {
                          printf( "\e[7;49;32m\n%-$SINscreenWides", "\e[1;31;42m$CoTErrorWarning \e[0m" );
                                print_UN_Screen($USSD_Content);
                        }
                        else
                        {
                                print_UN_Screen($USSD_Content);
                        }
                }
                else
                {
                        if ($CoTErrorWarning ne "false" )
                        {
                            printf( "\e[7;49;32m\n%-$SINscreenWides", "\e[1;31;42m $CoTErrorWarning \e[0m" );
                                print_UN_Screen($USSD_Content);
                        }
                        else
                        {
                                print_UN_Screen($USSD_Content);
                        }
                }
        }
        elsif ( $typeOfSIN eq "UR" )
        {
                $typeOfSINtitle = 'User Request';
              printf( "\e[0m\n%-$SINscreenWides", "                      V");;printf( "\e[0m\n%-$SINscreenWides", " ");printf( "\e[0m\n%-$SINscreenWides", "$typeOfSINtitle" );
                printf( "\e[7;49;93m\n %-$SINscreenWides", " " );
        }
}


if ($Illustrator_mode eq "cdrmon" and $typeOfSIN eq "UN" and $noCDRs ne "true")
{
        if ($UNErrorWarning ne "false" )
        {
                printf( "\e[7;49;32m\n%-$SINscreenWides", "\e[1;31;42m$UNErrorWarning \e[0m" );
                printf( "\e[7;49;32m\n %-$SINscreenWides", " " );
                if ($CoTErrorWarning ne "false" )
                {
                        printf( "\e[7;49;32m\n%-$SINscreenWides", "\e[1;31;42m $CoTErrorWarning \e[0m" );
                        printf( "\e[7;49;32m\n %-$SINscreenWides", " " );
                }
                else
                {
                        printf( "\e[7;49;32m\n %-$SINscreenWides", " " );
                }
        }
        else
        {
                if ($CoTErrorWarning ne "false" )
                {
                        printf( "\e[7;49;32m\n%-$SINscreenWides", "\e[1;31;42m $CoTErrorWarning \e[0m" );
                        printf( "\e[7;49;32m\n%-$SINscreenWides", " " );
                }
                else
                {
                        printf( "\e[7;49;32m\n %-$SINscreenWides", " " );
                        printf( "\e[7;49;32m\n %-$SINscreenWides", $UR_UserResponse );
                        printf( "\e[7;49;32m\n %-$SINscreenWides", " " );
                }
        }
        $Illustrator_modeFlag = 'off';
        push (@pushIllustrator_modeFlag,$Illustrator_modeFlag);
}
else
{
        if ($noCDRs eq "true")
        {
                $URstr = "noCDRs";
        }
        else
        {
                $URstr = $res->decoded_content;
        }
}
if ($noCDRs eq "true")
{
        print color("red"),"\nCould not find CDRs.\n",color("reset");
}
else
{
while($URstr =~ /([^\n]+)\n?/g)
{
        $URstrLineLength = length $1;
        if ( $URstrLineLength > $SINscreenContentWide and $URstrLineLength < $SINscreenContentWide2 )
        {
                $URstrLine1 =  substr($1, 0, $SINscreenContentWide);
                $URstrLine2 =  substr($1, $SINscreenContentWide);
                printf( "\n %-$SINscreenWides", $URstrLine1 );
                printf( "\n %-$SINscreenWides", $URstrLine2 );
        }
        elsif ( $URstrLineLength > $SINscreenContentWide2 and $URstrLineLength < $SINscreenContentWide3 )
        {
                $URstrLine1 =  substr($1, 0, $SINscreenContentWide);
                $URstrLine2 =  substr($1, $SINscreenContentWide, $SINscreenContentWide);
                $URstrLine3 =  substr($1, $SINscreenContentWide*2, $SINscreenContentWide);
                printf( "\n %-$SINscreenWides", $URstrLine1 );
                printf( "\n %-$SINscreenWides", $URstrLine2 );
                printf( "\n %-$SINscreenWides", $URstrLine3 );
        }
        elsif ( $URstrLineLength > $SINscreenContentWide3 )
        {
                $URstrLine1 =  substr($1, 0, $SINscreenContentWide);
                $URstrLine2 =  substr($1, $SINscreenContentWide, $SINscreenContentWide);
                $URstrLine3 =  substr($1, $SINscreenContentWide2, $SINscreenContentWide);
                $URstrLine4 =  substr($1, $SINscreenContentWide3, $SINscreenContentWide);
                printf( "\n %-$SINscreenWides", $URstrLine1 );
                printf( "\n %-$SINscreenWides", $URstrLine2 );
                printf( "\n %-$SINscreenWides", $URstrLine3 );
                printf( "\n %-$SINscreenWides", $URstrLine4 );
        }
        else
        {
        printf( "\n %-$SINscreenWides", $1 );
        }
}
print " ";
printf( "\n %-$SINscreenWides\e[0m\n", " " );
}
}

sub printCDRsscreen
{
$CDRCorrelationIDIllustrator=$_[0];
$file__ussd_si_cdrs=$_[1];
$Illustrator_mode=$_[2];
$linecounter = 0;
$SRNextSINcannotbedetermined = 'false';


if ( $Illustrator_mode ne "cdrmon")
{
        unless (-e $active_ussd_si_cdrs){print color("red"),"\nCould not open ussd si cdrs file.  It might not be configured in SI_tool.pl. Run SI_tool -h for more details\n",color("reset");exit;}
        open USSDSICDRFILE, "<$active_ussd_si_cdrs" or die(color("reset"), "\nCould not open ussd si cdrs file. $! It might not be configured in SI_tool.pl. Run SI_tool -h for more details\n\n");
        while(<USSDSICDRFILE>)
        {
                chomp;
                if( $_ =~ m/$ussdsimsisdnInt/ )
                {
                        push (@allussdsicdrsformsisdnInt,$_);
                        $noCDRs="false";
                }
        }
        my @CDRCorrelationID = split "," , $allussdsicdrsformsisdnInt[-1];
        close USSDSICDRFILE;
        $pushCDRCorrelationID =$CDRCorrelationID[$CorrellationID_SICDR_FieldNum]
}
else
{
        unless (-e $file__ussd_si_cdrs){print color("red"),"\nCould not open ussd si cdrs file.  It might not be configured in SI_tool.pl. Run SI_tool -h for more details\n",color("reset");exit;}
        open USSDSICDRFILE, "<$file__ussd_si_cdrs" or die(color("reset"), "\nCould not open ussd si cdrs file. $! It might not be configured in SI_tool.pl. Run SI_tool -h for more details\n\n");
        while(<USSDSICDRFILE>)
        {
                chomp;
                if( $_ =~ m/$CDRCorrelationIDIllustrator/ )
                {
                        push (@allussdsicdrsforCDRCorrelationID,$_);
                        $noCDRs="false";
                }
        }
        my @ussdsimsisdnfromillustrator = split "," , $allussdsicdrsforCDRCorrelationID[-1];
        my @CDRCorrelationID = split "," , $allussdsicdrsforCDRCorrelationID[-1];
        close USSDSICDRFILE;
        $ussdsimsisdnInt = $ussdsimsisdnfromillustrator[0];
        if ($noCDRs eq "true")
        {
                $pushCDRCorrelationID='noCDRs';
        }
        else
        {
                $pushCDRCorrelationID = $ussdsimsisdnfromillustrator[5];
        }
}

if ($noCDRs eq "true")
{
        if (defined($opt_p))
        {
                        print color("red"),"\nCould not find cdrs with Correllation ID $opt_p, Bye.\n",color("reset");
                        exit;
        }
}
else
{
        if ( $Illustrator_mode ne "cdrmon")
        {
                printf( "\e[0m %-$SINscreenWides", "                     |" );printf( "%$CDRscreenWides", "CDRs $active_ussd_si_cdrs" );
        }
        else
        {
                printf( "\e[0m %-$SINscreenWides", "                     |" );printf( "%$CDRscreenWides", "CDRs $file__ussd_si_cdrs" );
        }
        printf( "\e[0m\n %-$SINscreenWides", "                     |" );printf( "\e[7;49;37m %-$CDRscreenWides", " " );
        $CDRCorrelationID[$CorrellationID_SICDR_FieldNum]=$pushCDRCorrelationID;
}

if ( $Illustrator_mode ne "cdrmon")
{
        open USSDSICDRFILE1, "<$active_ussd_si_cdrs" or die(color("reset"), "\nCould not open ussd si cdrs file. $! It might not be configured in SI_tool.pl. Run SI_tool -h for more details\n\n");
}
else
{
        open USSDSICDRFILE1, "<$file__ussd_si_cdrs" or die(color("reset"), "\nCould not open ussd si cdrs file. $! It might not be configured in SI_tool.pl. Run SI_tool -h for more details\n\n");
}
while(<USSDSICDRFILE1>)
 {

     chomp;
     if( $_ =~ m/$CDRCorrelationID[$CorrellationID_SICDR_FieldNum]/ and $noCDRs ne "true")
     {
        $linecounter++;
        if ( $linecounter > $acclinecounter )
        {
                $ussdsiCDRlinelength = length $_;
                if ( $ussdsiCDRlinelength > $CDRscreenContentWide )
                {
                        for (my $d=0; $d < $ussdsiCDRlinelength; $d+=$CDRscreenContentWide)
                        {
                                $ussdsiCDRstrLine =  substr($_, $d, $CDRscreenContentWide);
                                printf( "\e[0m\n %-$SINscreenWides", "                     |" );
                                printf( "\e[7;49;37m %-$CDRscreenWides", $ussdsiCDRstrLine );
                                printf( "\e[0m\n %-$SINscreenWides", "                     |" );
                                printf( "\e[7;49;37m %-$CDRscreenWides", " " );
                        }
                }
                else
                {
                        printf( "\e[0m\n %-$SINscreenWides", "                     |" );printf( "\e[7;49;37m %-$CDRscreenWides", $_ );
                        printf( "\e[0m\n %-$SINscreenWides", "                     |" );printf( "\e[7;49;37m %-$CDRscreenWides", " " );
                }

                if( $_ =~ m/$CDRCorrelationID[$CorrellationID_SICDR_FieldNum]/ and $_ =~ m/$ussdsimsisdnInt,17,48/)
                {
                        @SINname = split "," , $_;
                        if ($SINname[$RawErrorCodeType_SICDR_FieldNum] eq "1" and $SINname[$OperCodeType_SICDR_FieldNum] eq "-1")
                        {
                                $SCErrorWarning="          FAILURE!!!! Result Code = Next SIN cannot be determined          ";
                        }
                        else
                        {
                                $SCErrorWarning="false";
                        }
                        print_SC_Screen($CDRCorrelationID[$CorrellationID_SICDR_FieldNum],$SCErrorWarning);
                }

                if( $_ =~ m/$CDRCorrelationID[$CorrellationID_SICDR_FieldNum]/ and $_ =~ m/$ussdsimsisdnInt,17,46/)
                {
                        @SINname = split "," , $_;
                        if ($SINname[$RawErrorCodeType_SICDR_FieldNum] eq "5" and $SINname[$OperCodeType_SICDR_FieldNum] eq "-1")
                        {
                                $SRErrorWarning="          INFO: Result Code = Next SIN cannot be determined                ";
                                $SRNextSINcannotbedetermined = 'true';
                        }
                        elsif ($SINname[$RawErrorCodeType_SICDR_FieldNum] eq "5" and $SINname[$RawErrorCode_SICDR_FieldNum] eq "500")
                        {
                                $SRErrorWarning="        FAILURE!!!! Raw Error Code returned by HTTP Adaptor = $SINname[$RawErrorCode_SICDR_FieldNum]          ";
                        }
                        elsif ($SINname[$RawErrorCodeType_SICDR_FieldNum] eq "5" and $SINname[$RawErrorCode_SICDR_FieldNum] eq "501")
                        {
                                $SRErrorWarning="        FAILURE!!!! Raw Error Code returned by HTTP Adaptor = $SINname[$RawErrorCode_SICDR_FieldNum]          ";
                        }
                        elsif ($SINname[$RawErrorCodeType_SICDR_FieldNum] eq "5" and $SINname[$RawErrorCode_SICDR_FieldNum] eq "502")
                        {
                                $SRErrorWarning="        FAILURE!!!! Raw Error Code returned by HTTP Adaptor = $SINname[$RawErrorCode_SICDR_FieldNum]          ";
                        }
                        elsif ($SINname[$RawErrorCodeType_SICDR_FieldNum] eq "4" and $SINname[$RawErrorCode_SICDR_FieldNum] ne "0")
                        {
                                if ($SINname[$RawErrorCodeType_SICDR_FieldNum] eq "4" and $SINname[$RawErrorCode_SICDR_FieldNum] ne "200")
                                {
                                        $SRErrorWarning="        FAILURE!!!! Raw Error Code returned by HTTP Adaptor = $SINname[$RawErrorCode_SICDR_FieldNum]          ";
                                }
                        }
                        elsif ($SINname[$RawErrorCodeType_SICDR_FieldNum] eq "3" and $SINname[$RawErrorCode_SICDR_FieldNum] ne "0" and $SINname[$RawErrorCode_SICDR_FieldNum] ne "200")
                        {
                                $SRErrorWarning="        FAILURE!!!! Raw Error Code returned by Remote Server = $SINname[$RawErrorCode_SICDR_FieldNum]         ";
                        }
                        else
                        {
                                $SRErrorWarning="false";
                        }
                        print_SR_Screen($CDRCorrelationID[$CorrellationID_SICDR_FieldNum],$SRErrorWarning,$SINname[$Date_SICDR_FieldNum],$SINname[$Time_SICDR_FieldNum]);
                }
            }
     }
     if( $_ =~ m/$CDRCorrelationID[$CorrellationID_SICDR_FieldNum]/ and $_ =~ m/$ussdsimsisdnInt,17,49/ and $_ =~ m/REQ/)
     {
                @UR_CDR_content = split "," , $_;
                $URmenu=$UR_CDR_content[$UR_REQUESTcontent_SICDR_FieldNum];
                $cdrSequenceNumber=$UR_CDR_content[$UR_SequenceNumber_SICDR_FieldNum];
                if ($Illustrator_mode ne "cdrmon")
                {
                        $typeOfSIN = 'UR';
                }
                elsif ($Illustrator_mode eq "cdrmon")
                {
                        printf( "\e[0m\n\n%-$SINscreenWides", "SESSION START: Correlation ID $CDRCorrelationID[$CorrellationID_SICDR_FieldNum]" );
                        printf( "\e[7;49;34m\n %-$SINscreenWides", " " );
                        printf( "\e[7;49;34m\n %-$SINscreenWides", $URmenu );
                        printf( "\e[7;49;34m\n %-$SINscreenWides", " " );
                        printf( "\e[0m\n %-$SINscreenWides", " " );
                }
     }
     if( $_ =~ m/$CDRCorrelationID[$CorrellationID_SICDR_FieldNum]/ and $_ =~ m/$ussdsimsisdnInt,17,44/ and $_ =~ m/$cdrSequenceNumber/)
     {
                @SINname = split "," , $_;
                $typeOfSIN='UR_RM';
     }

     if( $_ =~ m/$CDRCorrelationID[$CorrellationID_SICDR_FieldNum]/ and $_ =~ m/$ussdsimsisdnInt,17,49/ and $_ =~ m/RSP/ and $_ =~ m/$cdrSequenceNumber/ and $typeOfSIN eq "UR_RM")
     {
                @UR_CDR_UserResponse = split "," , $_;
                $UR_UserResponse=$UR_CDR_UserResponse[$UR_RESPONSEcontent_SICDR_FieldNum];
                if ($noCDRs ne "true" and $foundCDR43 ne "true")
                {
                        print_UR_Screen_for_cdrmon();
                }

     }
     if( $_ =~ m/$CDRCorrelationID[$CorrellationID_SICDR_FieldNum]/ and $_ =~ m/$ussdsimsisdnInt,17,43/)
     {
                $foundCDR43 = 'true';
                @SINname = split "," , $_;
                if ($SINname[$RawErrorCodeType_SICDR_FieldNum] eq "0" and $SINname[$OperCodeType_SICDR_FieldNum] eq "1")
                {
                        $UNErrorWarning="                FAILURE!!!! Result Code = Operation Error                  ";
                }
                elsif ($SINname[$RawErrorCodeType_SICDR_FieldNum] eq "0" and $SINname[$OperCodeType_SICDR_FieldNum] eq "2")
                {
                        $UNErrorWarning="                FAILURE!!!! Result Code = System Error"                     ;
                }
                elsif ($SINname[$RawErrorCodeType_SICDR_FieldNum] eq "0" and $SINname[$OperCodeType_SICDR_FieldNum] eq "-1")
                {
                        $UNErrorWarning="                FAILURE!!!! Result Code = Next SIN undetermined            ";
                }
                else
                {
                        $UNErrorWarning="false";
                }
     }

     if( $_ =~ m/$CDRCorrelationID[$CorrellationID_SICDR_FieldNum]/ and $_ =~ m/$ussdsimsisdnInt,17,49/ and $_ =~ m/RSP/ and $foundCDR43 eq "true")
     {
                @USSD_CDR_Content = split "," , $_;
                $USSD_Content=$USSD_CDR_Content[$UR_RESPONSEcontent_SICDR_FieldNum];
                $foundCDR43 = 'false';
     }

     if( $_ =~ m/$CDRCorrelationID[$CorrellationID_SICDR_FieldNum]/ and $_ =~ m/$ussdsimsisdnInt,17,47/)
     {
                $typeOfSIN = 'HO';
                if ($noCDRs ne "true")
                {
                        print_HO_Screen();
                }
     }

     if( $_ =~ m/$CDRCorrelationID[$CorrellationID_SICDR_FieldNum]/ and $_ =~ m/$ussdsimsisdnInt,17,41/)
     {
        $typeOfSIN = 'UN';
        @getEndCDR = split "," , $_;
        if ($getEndCDR[$CauseofTermination_SICDR_FieldNum] eq "1")
        {
                $CoTErrorWarning="         SESSION WAS ENDED!!!! Cause of Termination: User timeout         ";
        }
        elsif ($getEndCDR[$CauseofTermination_SICDR_FieldNum] eq "2")
        {
                $CoTErrorWarning="         SESSION WAS ENDED!!!! Cause of Termination: User teardown        ";
        }
        elsif ($getEndCDR[$CauseofTermination_SICDR_FieldNum] eq "3")
        {
                $CoTErrorWarning="         SESSION WAS ENDED!!!! Cause of Termination: User error           ";
        }
        elsif ($getEndCDR[$CauseofTermination_SICDR_FieldNum] eq "4")
        {
                $CoTErrorWarning="         SESSION WAS ENDED!!!! Cause of Termination: User is busy         ";
        }
        elsif ($getEndCDR[$CauseofTermination_SICDR_FieldNum] eq "6")
        {
                $CoTErrorWarning="     SESSION WAS ENDED!!!! Cause of Termination = 6   > Other Error       ";
        }
        elsif ($getEndCDR[$CauseofTermination_SICDR_FieldNum] eq "9")
        {
                $CoTErrorWarning="         SESSION WAS ENDED!!!! Cause of Termination: Whitelist Error      ";
        }
        elsif ($getEndCDR[$CauseofTermination_SICDR_FieldNum] eq "7" or $getEndCDR[$CauseofTermination_SICDR_FieldNum] eq "8" or $getEndCDR[$CauseofTermination_SICDR_FieldNum] eq "10")
        {
                $CoTErrorWarning="         SESSION WAS ENDED!!!! Cause of Termination: Throttiling Error    ";
        }
        else
        {
                $CoTErrorWarning="false";
        }
    }
}
close USSDSICDRFILE1;
$acclinecounter = $linecounter;

}

sub print_SC_Screen
{
$JavaScriptTagFoundFlag1 = 'false';
$JavaScriptTagFoundFinished = 'false';
$JavaScriptTagFoundFlagcont = 'false';
$JavaScriptTagFoundFlag3 = 'false';
$JavaScriptTagFoundFlag4 = 'false';
$typeOfSINtitle = 'JavaScript : '.$SINname[$SINnameCDRnum];
$mapparameterInputCounter = 0;
$mapparameterOutputCounter = 0;
@getAllOUTPUTSFromPmlogs = ();
@getAllINPUTSFromPmlogs = ();
$finishGetFromPmlogsFlag = 'false';
$JavaScriptFoundstatusCode = 'false';

getAllInputsOutoutsFromPmlogs($_[0]);
printf( "\e[0m\n %-$SINscreenWides", "                     V");;printf( "\n%-$SINscreenWides", " ");printf( "\n%-$SINscreenWides", "$typeOfSINtitle" );
if ($SCErrorWarning ne "false" )
{
        printf( "\e[7;49;35m\n%-$SINscreenWides", "\e[1;31;42m$SCErrorWarning \e[0m" );
        printf( "\e[7;49;35m\n %-$SINscreenWides", " " );
}
else
{
        printf( "\e[7;49;35m\n %-$SINscreenWides", " " );
}
open USSDSISDservicesFILE1, "<$ussd_si_sd_servicesDir/USSD_services.cfg" or die(color("reset"), "\nCould not open ussd si USSD_services.cfg file. $! It might not be configured in SI_tool.pl. Run SI_tool -h for more details\n\n");
while(<USSDSISDservicesFILE1>)
{
     chomp;
     if( $_ =~ m/$SINname[$SINnameCDRnum]/ )
        {
                $JavaScriptTagFoundFlag1 = 'true';
        }
     if( $_ =~ m/SCRIPT_REQ/ and $JavaScriptTagFoundFlag1 eq "true")
        {
                $JavaScriptTagFoundFlag1 = 'false';
        }
     if( $_ =~ m/Function/ and $JavaScriptTagFoundFlag1 eq "true" and $JavaScriptTagFoundFinished eq "false" )
        {
                @JSFunctionName = split "Function = ",$_;
                foreach (@javaScriptAllTags)
                {
                        if( $_ =~ m/$JSFunctionName[-1]/ )
                        {
                                $finishGetFromPmlogsFlag = 'true';
                        }
                }
                if ( $finishGetFromPmlogsFlag eq "true")
                {
                        finishgetINPUTSFromPmlogs($JSFunctionName[-1]);
                        @getEachInput = split /\|/ , $cleanInputLine[-1];
                        @getEachOutput = split /\|/ , $cleanOutputLine[-1];
                }
                printf( "\n %-$SINscreenWides", $_ );
                printf( "\n %-$SINscreenWides", "------------------------------------------------");
                printf( "\n %-$SINscreenWides", "              INPUTS                  ");
                if ($javaScriptTagkeyFlag eq "yes" and $finishGetFromPmlogsFlag eq "true")
                {
                        printf( "\n %-$SINscreenWides", " PLACEHOLDER    =>    PARAMETER   =   CONTENT");
                        printf( "\n %-$SINscreenWides", " ");
                }
                $JavaScriptTagFoundFlag1 = 'false';
                $JavaScriptTagFoundFlagcont = 'true';
        }
     if( $_ =~ m/Status Code/ and $JavaScriptFoundstatusCode eq "false" and $JavaScriptTagFoundFlagcont eq "true" and $JavaScriptTagFoundFinished eq "false" )
        {
                @statusCode = split "= ", $_;
                $JavaScriptFoundstatusCode = 'true';
        }
     if( $_ =~ m/ScriptInputData/ and $JavaScriptTagFoundFlagcont eq "true" )
        {
                $JavaScriptTagFoundFlag3 = 'true';
        }
     if ( $_ =~ m/Map/ and $_ =~ /,/ and $JavaScriptTagFoundFlag3 eq "true" and $JavaScriptTagFoundFlagcont eq "true" )
        {
                @mapparameter = split "," , $_;
                if ($javaScriptTagkeyFlag eq "yes" and $finishGetFromPmlogsFlag eq "true")
                {
                        $mapparameterLength = scalar @getEachInput;
                        @getPlaceHolder = split "= " , $mapparameter[0];
                        if ($mapparameterInputCounter < $mapparameterLength)
                        {
                                if ($getPlaceHolder[-1] eq "\${session_callReferenceId}")
                                {
                                        $printInputsLine = $getEachInput[$mapparameterInputCounter];
                                }
                                else
                                {
                                        $printInputsLine = $getPlaceHolder[-1]." => ".$getEachInput[$mapparameterInputCounter];
                                }
                                $printInputsLineLenth = length $printInputsLine;
                                if ( $printInputsLineLenth > $SINscreenContentWide )
                                {
                                        for (my $m=0; $m < $printInputsLineLenth; $m+=$SINscreenContentWide)
                                        {
                                                $printInputstrLine =  substr($printInputsLine, $m, $SINscreenContentWide);
                                                printf( "\n %-$SINscreenWides", $printInputstrLine );
                                        }
                                }
                                else
                                {
                                        printf( "\n %-$SINscreenWides", $printInputsLine);
                                }
                                $mapparameterInputCounter++;
                        }
                }
                else
                {
                        printf( "\n %-$SINscreenWides", $mapparameter[0] );
                }
        }
     if( $_ =~ m/ScriptOutputData/ and $_ !=~ m/Param/ and $JavaScriptTagFoundFlag3 eq "true" and $JavaScriptTagFoundFlagcont eq "true" )
        {
                unless( $_ =~ m/Parameter/)
                {
                printf( "\n %-$SINscreenWides", "------------------------------------------------");
                printf( "\n %-$SINscreenWides", "              OUTPUTS             ");
                if ($javaScriptTagkeyFlag eq "yes" and $finishGetFromPmlogsFlag eq "true")
                {
                        printf( "\n %-$SINscreenWides", " PLACEHOLDER     =>             CONTENT");
                        printf( "\n %-$SINscreenWides", " ");
                }
                $JavaScriptTagFoundFlag3 = 'false';
                $JavaScriptTagFoundFlag4 = 'true';
                }

        }
     if ( $_ =~ m/Map/ and $_ =~ /,/ and $JavaScriptTagFoundFlag4 eq "true" and $JavaScriptTagFoundFlagcont eq "true")
        {
                @mapparameter = split "," , $_;
                if ($javaScriptTagkeyFlag eq "yes" and $finishGetFromPmlogsFlag eq "true")
                {
                        $mapparameterLength = scalar @getEachOutput;
                        @getPlaceHolder = split "= " , $mapparameter[0];
                        if ($mapparameterOutputCounter < $mapparameterLength)
                        {
                                $printOutputsLine = $getPlaceHolder[-1]." => ".$getEachOutput[$mapparameterOutputCounter];
                                $printOutputsLineLenth = length $printOutputsLine;
                                $statusCode1 = $statusCode[-1]; $getPlaceHolder1 = $getPlaceHolder[-1];
                                @statusCodeCleant = split "{", $statusCode1;@getPlaceHolderCleant = split "{", $getPlaceHolder1;

                                if ( $statusCodeCleant[-1] eq $getPlaceHolderCleant[-1] )
                                {
                                        $statusCodePlaceHolder =  $getPlaceHolder[-1]."=".$getEachOutput[$mapparameterOutputCounter];

                                }
                                else
                                {
                                        $statusCodePlaceHolder = $statusCode[-1];
                                }
                                if ( $printOutputsLineLenth > $SINscreenContentWide )
                                {
                                        for (my $c=0; $c < $printOutputsLineLenth; $c+=$SINscreenContentWide)
                                        {
                                                $printOutputstrLine =  substr($printOutputsLine, $c, $SINscreenContentWide);
                                                printf( "\n %-$SINscreenWides", $printOutputstrLine );
                                        }
                                }
                                else
                                {
                                        printf( "\n %-$SINscreenWides", $printOutputsLine);
                                }
                                $mapparameterOutputCounter++;
                        }
                }
                else
                {
                        printf( "\n %-$SINscreenWides", $mapparameter[0] );
                }
        }
     if( $_ =~ m/ScriptRequestTag/ and $JavaScriptTagFoundFlagcont eq "true" )
        {
                $JavaScriptTagFoundFlagcont = 'false';
                $JavaScriptTagFoundFinished = 'true';
        }
     if( $_ =~ m/UserMessageTag0/ and $JavaScriptTagFoundFlagcont eq "true" )
        {
                $JavaScriptTagFoundFlagcont = 'false';
                $JavaScriptTagFoundFinished = 'true';
        }

}
close USSDSISDservicesFILE1;
printf( "\n %-$SINscreenWides", "------------------------------------------------");
printf( "\n%-8s\e[0m", " Resp Map = ");
$statusCodePlaceHolderlength = length $statusCodePlaceHolder;
if ( $statusCodePlaceHolderlength > $RMscreenWide and $javaScriptTagkeyFlag eq "yes" and $finishGetFromPmlogsFlag eq "true")
{
        for (my $r=0; $r < $printOutputsLineLenth; $r+=$RMscreenWide)
        {
                $statusCodePlaceHolderLine =  substr($statusCodePlaceHolder, $r, $RMscreenWide);
                printf( " %-$RMscreenWides", $statusCodePlaceHolderLine );
        }
}
elsif ($statusCodePlaceHolderlength < $RMscreenWide1 and $javaScriptTagkeyFlag eq "yes" and $finishGetFromPmlogsFlag eq "true")
{
        printf( "%-$RMscreenWides", "$statusCodePlaceHolder");
}
else
{
        printf( "%-$RMscreenWides", "$statusCode[-1]");
}
printf( "\e[7;49;35m%-9s", " ");
printf( "\e[7;49;35m\n %-$SINscreenWides\e[0m", " ");
}

sub print_UR_Screen_for_cdrmon
{
if ($Illustrator_mode ne "cdrmon")
{
        $typeOfSINtitle = 'Response Map of : '.$SINname[$SINnameCDRnum];
        printf( "\e[0m\n%-$SINscreenWides", "                      V");;printf( "\e[0m\n%-$SINscreenWides", " ");printf( "\e[0m\n%-$SINscreenWides", "$typeOfSINtitle" );
        printf( "\e[5;49;90m\n %-$SINscreenWides", " " );
        printf( "\n%-8s\e[0m", " Resp Map = ");
        printf( "%-$RMscreenWides", "   User Response => $UR_UserResponse");
        printf( "\e[5;49;90m%-9s", " ");
        printf( "\n %-$SINscreenWides\n", " ");
}
else
{
        $typeOfSINtitle = 'User Request';
        printf( "\e[0m\n%-$SINscreenWides", "                      V");;printf( "\e[0m\n%-$SINscreenWides", " ");printf( "\e[0m\n%-$SINscreenWides", "$typeOfSINtitle" );
        printf( "\e[7;49;93m\n %-$SINscreenWides", " " );

        while($URmenu =~ /([^\n]+)\n?/g)
        {
                $URstrLineLength = length $1;
                if ( $URstrLineLength > $SINscreenContentWide and $URstrLineLength < $SINscreenContentWide2 )
                {
                        $URstrLine1 =  substr($1, 0, $SINscreenContentWide);
                        $URstrLine2 =  substr($1, $SINscreenContentWide);
                        printf( "\n %-$SINscreenWides", $URstrLine1 );
                        printf( "\n %-$SINscreenWides", $URstrLine2 );
                }
                elsif ( $URstrLineLength > $SINscreenContentWide2 and $URstrLineLength < $SINscreenContentWide3 )
                {
                        $URstrLine1 =  substr($1, 0, $SINscreenContentWide);
                        $URstrLine2 =  substr($1, $SINscreenContentWide, $SINscreenContentWide);
                        $URstrLine3 =  substr($1, $SINscreenContentWide*2, $SINscreenContentWide);
                        printf( "\n %-$SINscreenWides", $URstrLine1 );
                        printf( "\n %-$SINscreenWides", $URstrLine2 );
                        printf( "\n %-$SINscreenWides", $URstrLine3 );
                }
                elsif ( $URstrLineLength > $SINscreenContentWide3 )
                {
                        $URstrLine1 =  substr($1, 0, $SINscreenContentWide);
                        $URstrLine2 =  substr($1, $SINscreenContentWide, $SINscreenContentWide);
                        $URstrLine3 =  substr($1, $SINscreenContentWide2, $SINscreenContentWide);
                        $URstrLine4 =  substr($1, $SINscreenContentWide3, $SINscreenContentWide);
                        printf( "\n %-$SINscreenWides", $URstrLine1 );
                        printf( "\n %-$SINscreenWides", $URstrLine2 );
                        printf( "\n %-$SINscreenWides", $URstrLine3 );
                        printf( "\n %-$SINscreenWides", $URstrLine4 );
                 }
                else
                {
                printf( "\n %-$SINscreenWides", $1 );
                }
        }
        printf( "\n %-$SINscreenWides", " ");
        printf( "\n %-$SINscreenWides", "------------------------------------------------");
        printf( "\n%-8s\e[0m", " Resp Map = ");
        printf( "%-$RMscreenWides", "   User Response => $UR_UserResponse");
        printf( "\e[7;49;93m%-9s", " ");
        printf( "\n %-$SINscreenWides\n", " ");
}
}

sub print_UN_Screen
{
printf( "\e[7;49;32m\n %-$SINscreenWides", " " );
while($_[0] =~ /([^\n]+)\n?/g)
{
        $UNstrLineLength = length $1;
        if ( $UNstrLineLength > $SINscreenContentWide and $UNstrLineLength < $SINscreenContentWide2 )
        {
                $UNstrLine1 =  substr($1, 0, $SINscreenContentWide);
                $UNstrLine2 =  substr($1, $SINscreenContentWide);
                printf( "\n %-$SINscreenWides", $UNstrLine1 );
                printf( "\n %-$SINscreenWides", $UNstrLine2 );
        }
        elsif ( $UNstrLineLength > $SINscreenContentWide2 and $UNstrLineLength < $SINscreenContentWide3 )
        {
                $UNstrLine1 =  substr($1, 0, $SINscreenContentWide);
                $UNstrLine2 =  substr($1, $SINscreenContentWide, $SINscreenContentWide);
                $UNstrLine3 =  substr($1, $SINscreenContentWide*2, $SINscreenContentWide);
                printf( "\n %-$SINscreenWides", $UNstrLine1 );
                printf( "\n %-$SINscreenWides", $UNstrLine2 );
                printf( "\n %-$SINscreenWides", $UNstrLine3 );
        }
        elsif ( $UNstrLineLength > $SINscreenContentWide3 )
        {
                $UNstrLine1 =  substr($1, 0, $SINscreenContentWide);
                $UNstrLine2 =  substr($1, $SINscreenContentWide, $SINscreenContentWide);
                $UNstrLine3 =  substr($1, $SINscreenContentWide2, $SINscreenContentWide);
                $UNstrLine4 =  substr($1, $SINscreenContentWide3, $SINscreenContentWide);
                printf( "\n %-$SINscreenWides", $UNstrLine1 );
                printf( "\n %-$SINscreenWides", $UNstrLine2 );
                printf( "\n %-$SINscreenWides", $UNstrLine3 );
                printf( "\n %-$SINscreenWides", $UNstrLine4 );
        }
        else
        {
        printf( "\n %-$SINscreenWides", $1 );
        }
}
}


sub print_HO_Screen
{
        $typeOfSINtitle = 'Handover Request : '.$SINname[$SINnameCDRnum];
        printf( "\e[0m\n%-$SINscreenWides", "                      V");;printf( "\e[0m\n%-$SINscreenWides", " ");printf( "\e[0m\n%-$SINscreenWides", "$typeOfSINtitle" );
        printf( "\e[7;49;94m\n %-$SINscreenWides", " " );

        while($USSD_Content =~ /([^\n]+)\n?/g)
        {
                $URstrLineLength = length $1;
                if ( $URstrLineLength > $SINscreenContentWide and $URstrLineLength < $SINscreenContentWide2 )
                {
                        $URstrLine1 =  substr($1, 0, $SINscreenContentWide);
                        $URstrLine2 =  substr($1, $SINscreenContentWide);
                        printf( "\n %-$SINscreenWides", $URstrLine1 );
                        printf( "\n %-$SINscreenWides", $URstrLine2 );
                }
                elsif ( $URstrLineLength > $SINscreenContentWide2 and $URstrLineLength < $SINscreenContentWide3 )
                {
                        $URstrLine1 =  substr($1, 0, $SINscreenContentWide);
                        $URstrLine2 =  substr($1, $SINscreenContentWide, $SINscreenContentWide);
                        $URstrLine3 =  substr($1, $SINscreenContentWide*2, $SINscreenContentWide);
                        printf( "\n %-$SINscreenWides", $URstrLine1 );
                        printf( "\n %-$SINscreenWides", $URstrLine2 );
                        printf( "\n %-$SINscreenWides", $URstrLine3 );
                }
                elsif ( $URstrLineLength > $SINscreenContentWide3 )
                {
                        $URstrLine1 =  substr($1, 0, $SINscreenContentWide);
                        $URstrLine2 =  substr($1, $SINscreenContentWide, $SINscreenContentWide);
                        $URstrLine3 =  substr($1, $SINscreenContentWide2, $SINscreenContentWide);
                        $URstrLine4 =  substr($1, $SINscreenContentWide3, $SINscreenContentWide);
                        printf( "\n %-$SINscreenWides", $URstrLine1 );
                        printf( "\n %-$SINscreenWides", $URstrLine2 );
                        printf( "\n %-$SINscreenWides", $URstrLine3 );
                        printf( "\n %-$SINscreenWides", $URstrLine4 );
                 }
                else
                {
                printf( "\n %-$SINscreenWides", $1 );
                }
        }
        printf( "\n %-$SINscreenWides", " ");
        printf( "\n %-$SINscreenWides", "------------------------------------------------");
        printf( "\n%-8s\e[0m", " Resp Map = ");
        printf( "%-$RMscreenWides", " Continue (AO Mode)");
        printf( "\e[7;49;94m%-9s", " ");
        printf( "\n %-$SINscreenWides\n", " ");
        $HONote='ATTENTION ! From this point, MI dialogue is terminated and the rest of session/interactions will be carried out using a series of separate NI dialogues. Run SI_tool in cdrmon mode to display the rest of session/interactions. Send \"help\"';
        printf( "\e[0;49;91m\n %-$SINscreenWides", " " );
        while($HONote =~ /([^\n]+)\n?/g)
        {
                $URstrLineLength = length $1;
                if ( $URstrLineLength > $SINscreenContentWide and $URstrLineLength < $SINscreenContentWide2 )
                {
                        $URstrLine1 =  substr($1, 0, $SINscreenContentWide);
                        $URstrLine2 =  substr($1, $SINscreenContentWide);
                        printf( "\n %-$SINscreenWides", $URstrLine1 );
                        printf( "\n %-$SINscreenWides", $URstrLine2 );
                }
                elsif ( $URstrLineLength > $SINscreenContentWide2 and $URstrLineLength < $SINscreenContentWide3 )
                {
                        $URstrLine1 =  substr($1, 0, $SINscreenContentWide);
                        $URstrLine2 =  substr($1, $SINscreenContentWide, $SINscreenContentWide);
                        $URstrLine3 =  substr($1, $SINscreenContentWide*2, $SINscreenContentWide);
                        printf( "\n %-$SINscreenWides", $URstrLine1 );
                        printf( "\n %-$SINscreenWides", $URstrLine2 );
                        printf( "\n %-$SINscreenWides", $URstrLine3 );
                }
                elsif ( $URstrLineLength > $SINscreenContentWide3 )
                {
                        $URstrLine1 =  substr($1, 0, $SINscreenContentWide);
                        $URstrLine2 =  substr($1, $SINscreenContentWide, $SINscreenContentWide);
                        $URstrLine3 =  substr($1, $SINscreenContentWide2, $SINscreenContentWide);
                        $URstrLine4 =  substr($1, $SINscreenContentWide3, $SINscreenContentWide);
                        printf( "\n %-$SINscreenWides", $URstrLine1 );
                        printf( "\n %-$SINscreenWides", $URstrLine2 );
                        printf( "\n %-$SINscreenWides", $URstrLine3 );
                        printf( "\n %-$SINscreenWides", $URstrLine4 );
                 }
                else
                {
                printf( "\n %-$SINscreenWides", $1 );
                }
        }
}


sub print_SR_Screen
{
$CDRCorrelationID = $_[0];
$DateTime_SICDR_FieldNum = "$_[2]".","."$_[3]";
$DateTime_SPCMCDR_FieldNum = "$_[3]";
$DateTime_AMCDR_FieldNum = "$_[3]";
$ServerRequestTagFoundFlag1 = 'false';
$ServerRequestTagFoundFinished = 'false';
$ServerRequestTagFoundFlagcont = 'false';
$RequestStrFoundFlag = 'false';
$ServerRequestTagFoundFlag4 = 'false';
$typeOfSINtitle = 'Server Request : '.$SINname[$SINnameCDRnum];
$SRFoundstatusCode = 'false';
$printCylinderCounter="0";
printf( "\e[0m\n%-$SINscreenWides", "                      V");printf( "\n%-$SINscreenWides", " ");printf( "\n%-$SINscreenWides", "$typeOfSINtitle");

if ($SRErrorWarning ne "false" and $SRNextSINcannotbedetermined eq "false")
{
        printf( "\e[7;49;31m\n%-$SINscreenWides", "\e[1;31;42m$SRErrorWarning \e[0m" );
        printf( "\e[7;49;31m\n %-$SINscreenWides", " " );
}
if ($SRErrorWarning ne "false" and $SRNextSINcannotbedetermined eq "true")
{
        printf( "\e[7;49;31m\n%-$SINscreenWides", "\e[0;49;32m$SRErrorWarning \e[0m" );
        printf( "\e[7;49;31m\n %-$SINscreenWides", " " );
}
else
{
        printf( "\e[7;49;31m\n %-$SINscreenWides", " " );
}
printCylinder("$printCylinderCounter","no","no","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
open USSDSISDservicesFILE2, "<$ussd_si_sd_servicesDir/USSD_services.cfg" or die(color("reset"), "\nCould not open ussd si USSD_services.cfg file. $! It might not be configured in SI_tool.pl. Run SI_tool -h for more details\n\n");
while(<USSDSISDservicesFILE2>)
 {
     chomp;
     if( $_ =~ m/$SINname[$SINnameCDRnum]/ )
        {
                $ServerRequestTagFoundFlag1 = 'true';
        }
     if( $_ =~ m/    Request/ and $ServerRequestTagFoundFlag1 eq "true" and $RequestStrFoundFlag eq "false" )
        {
                @SRTNumline = split "= " , $_;
                $SRTNum = 'ServerRequestTag'.$SRTNumline[1];
                $SRTNextNum = $SRTNumline[1] + 1;
                $SRTNextNumline = 'ServerRequestTag'.$SRTNextNum;
                $RequestStrFoundFlag = 'true';
        }
    if( $_ =~ m/Response Map Value/ and $SRFoundstatusCode eq "false" and $ServerRequestTagFoundFlag1 eq "true" and $ServerRequestTagFoundFinished eq "false" )
        {
                @ResponseMapValueLine = split "= ", $_;
                $SRFoundstatusCode = 'true';
        }
     if( $_ =~ m/$SRTNum/ and $RequestStrFoundFlag eq "true" and $ServerRequestTagFoundFlag1 = 'true' and $ServerRequestTagFoundFinished eq "false" )
        {
                $ServerRequestTagFoundFlag1 = 'false';
                $ServerRequestTagFoundFlagcont = 'true';
        }
     if( $ServerRequestTagFoundFlagcont eq "true" and $ServerRequestTagFoundFinished eq "false" )
        {
                unless ($_ =~ m/ServerRequestTag/ or $_ =~ m/ScriptRequestTag0/ or $_ =~ m/UserMessageTag0/)
                {
                        $SRstrLineTrimSpaces = $_;
                        $SRstrLineTrimSpaces =~ s/\s//g;
                        $SRstrLineLength = length $SRstrLineTrimSpaces;
                        if ($_ =~ m/    Resource/ )
                        {
                                my @srurlresource =  split "=" , $SRstrLineTrimSpaces;
                                $srurlresourceline = $srurlresource[1];
                                my @srurlresourcepath = split "/" , $srurlresourceline;
                                $srurlresourcepathlast = $srurlresourcepath[-1];
                                $srurlresourcelineLowerCase = lc $srurlresourceline;
                                if ($srurlresourcelineLowerCase =~ m/hrg/ or $srurlresourcelineLowerCase =~ m/http-request-generator/ or $srurlresourcelineLowerCase =~ m/http_request_generator/)
                                {

                                        $hrgResourceFoundhits = $hrgResourceFoundhits + 1;
                                }
                                elsif ($srurlresourcelineLowerCase =~ m/sibb/ or $srurlresourcelineLowerCase =~ m/$sibbPort/)
                                {
                                        $srurlresourcepathlast = $srurlresourcepath[3];
                                        $foundSIBBRequest = 'yes';
                                }
                                else
                                {
                                        $foundSIBBRequest = 'no';
                                }

                        }
                        if ($_ =~ m/SE_RESOURCE/ or $_ =~ m/HTTP_POST/ or $_ =~ m/HTTP_DELETE/ or $_ =~ m/HTTP_PUT/ or $_ =~ m/HTTP_GET/)
                        {
                                @srType =  split "=" , $SRstrLineTrimSpaces;
                                $srTypeline = $srType[1];
                        }
                        if ( $SRstrLineLength > $SINscreenContentWide )
                        {
                                for (my $i=0; $i < $SRstrLineLength; $i+=$SINscreenContentWide)
                                {
                                        $SRstrLine =  substr($SRstrLineTrimSpaces, $i, $SINscreenContentWide);
                                        printf( "\n %-$SINscreenWides", $SRstrLine );
                                        $saveDollar=$_;
                                        printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                                        $_=$saveDollar;
                                }
                        }
                        else
                        {
                                printf( "\n %-$SINscreenWides", $SRstrLineTrimSpaces );
                                $saveDollar=$_;
                                printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                                $_=$saveDollar;
                        }
                }
        }
     if( $_ =~ m/$SRTNextNumline/ and $ServerRequestTagFoundFlagcont eq "true" and $ServerRequestTagFoundFinished eq "false" )
        {

                $ServerRequestTagFoundFlagcont = 'false';
                $ServerRequestTagFoundFinished = 'true';
        }
     if( $_ =~ m/ScriptRequestTag0/ and $ServerRequestTagFoundFlagcont eq "true" and $ServerRequestTagFoundFinished eq "false" )
        {

                $ServerRequestTagFoundFlagcont = 'false';
                $ServerRequestTagFoundFinished = 'true';
        }
     if( $_ =~ m/UserMessageTag0/ and $ServerRequestTagFoundFlagcont eq "true" and $ServerRequestTagFoundFinished eq "false" )
        {

                $ServerRequestTagFoundFlagcont = 'false';
                $ServerRequestTagFoundFinished = 'true';
        }
}
close USSDSISDservicesFILE2;
$foundpmlog = 'no';
$foundpmlogresponse = 'no';
$foundpmlogresponsecont = 'no';
$foundpmlogresponsefinished = 'no';
printf( "\n %-$SINscreenWides", " " );
printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
printf( "\n %-$SINscreenWides", "------------------------------------------------- " );
printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
printf( "\n %-$SINscreenWides", " " );
printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
printf( "\n %-$SINscreenWides", "                   REQUEST SENT:                  " );
printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
printf( "\n %-$SINscreenWides", " " );
printCylinder("$printCylinderCounter","brakeLine","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
open pmlogFILE, "</tango/logs/process/pm.log" or die(color("reset"), "\nCould not open pm.log file. $!\n\n");
while(<pmlogFILE>)
 {
        chomp;
        unless ( $USSD_SI_port eq "17020")
        {
                $ServiceClientFilter = 'USSD ServiceClient';
        }
        else
        {
                $ServiceClientFilter = 'prepareHttpUrl';
        }
        if( $_ =~ m/$ServiceClientFilter/ and $_ =~ m/Prepared URL is/ and $_ =~ m/$srurlresourcepathlast/  and $_ =~ m/$msisdnInt/ and $_ =~ m/$CDRCorrelationID/ and $pushResourceRemServ[-1] ne "dndManager" and $pushResourceRemServ[-1] ne "CMGR" and $pushResourceRemServ[-1] ne "HRG" and $pushResourceRemServ[-1] ne "activity-meter" and $foundpmlogresponsefinished eq "no")
        {
                $foundpmlog = 'yes';
                $pmlogstrLineLength = length $_;
                if ( $pmlogstrLineLength > $SINscreenContentWide )
                {
                        for (my $j=0; $j < $pmlogstrLineLength; $j+=$SINscreenContentWide)
                        {
                                $pmlogstrLine =  substr($_, $j, $SINscreenContentWide);
                                printf( " %-$SINscreenWides", $pmlogstrLine );
                                $saveDollar=$_;
                                printCylinder("$printCylinderCounter","brakeLine","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                                $_=$saveDollar;
                        }
                }
                else
                {
                        printf( "\n %-$SINscreenWides", $_ );
                        $saveDollar=$_;
                        printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                        $_=$saveDollar;
                }
        }
        if( $_ =~ m/$ServiceClientFilter/ and $_ =~ m/Prepared URL is/ and $_ =~ m/$msisdnInt/ and $pushResourceRemServ[-1] eq "dndManager" and $srTypeline ne "SE_RESOURCE" and $foundpmlogresponsefinished eq "no" and $foundDNDRequest ne "yes")
        {
                $foundDNDRequest = 'yes';
                $foundpmlog = 'yes';
                $saveDollarAgain=$_;
                $foundpmlogresponseAgain = 'no';
                open pmlogFILEAgain, "</tango/logs/process/pm.log" or die(color("reset"), "\nCould not open pm.log file. $!\n\n");
                @lines = <pmlogFILEAgain>;
                while($line = pop @lines)
                {
                        chomp($line);
                        if( $line =~ m/$ServiceClientFilter/ and $line =~ m/Prepared URL is/ and $line =~ m/$msisdnInt/ and $line =~ m/dndManager/ and $foundpmlogresponseAgain ne "yes")
                        {
                                $foundpmlogresponseAgain = 'yes';
                                printf( " %-$SINscreenWides", " " );
                                $saveDollar=$line;
                                printCylinder("$printCylinderCounter","brakeLine","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                                $line=$saveDollar;
                                $pmlogstrLineLength = length $line;
                                if ( $pmlogstrLineLength > $SINscreenContentWide )
                                {
                                        for (my $j=0; $j < $pmlogstrLineLength; $j+=$SINscreenContentWide)
                                        {
                                                $pmlogstrLine =  substr($line, $j, $SINscreenContentWide);
                                                printf( " %-$SINscreenWides", $pmlogstrLine );
                                                $saveDollar=$line;
                                                printCylinder("$printCylinderCounter","brakeLine","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                                                $line=$saveDollar;
                                        }
                                }
                                else
                                {
                                        printf( "\n %-$SINscreenWides", $line );
                                        $saveDollar=$line;
                                        printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                                        $line=$saveDollar;
                                }
                        }
                }
                close pmlogFILEagain;
                $_=$saveDollarAgain;
        }
        if( $_ =~ m/$ServiceClientFilter/ and $pushResourceRemServ[-1] eq "CMGR" and $foundpmlogresponsefinished eq "no" and $foundCMGRRequest ne "yes")
        {
                $foundCMGRRequest = 'yes';
                $foundpmlog = 'yes';
                $srurlresourcelength = length $srurlresourceline;
                if ( $srurlresourcelength > $SINscreenContentWide )
                {
                        for (my $k=0; $k < $srurlresourcelength; $k+=$SINscreenContentWide)
                        {
                                $srurlresource =  substr($srurlresourceline, $k, $SINscreenContentWide);
                                printf( " %-$SINscreenWides", $srurlresource );
                                $saveDollar=$_;
                                printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                                $_=$saveDollar;
                        }
                }
                else
                {
                        printf( " %-$SINscreenWides", $srurlresourceline );
                        $saveDollar=$_;
                        printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                        $_=$saveDollar;
                }
        }
        if( $_ =~ m/$ServiceClientFilter/ and $pushResourceRemServ[-1] eq "HRG" and $foundpmlogresponsefinished eq "no" and $foundHRGRequest ne "yes" and $foundpmlogHRGreq ne "yes")
        {
                $foundHRGRequest = 'yes';
                $hrgContext = $parseHRGCDR[$context_HRGCDR_FieldNum];
        }
        if( $pushResourceRemServ[-1] eq "HRG" and $foundpmlogresponsefinished eq "no" and $foundHRGRequest eq "yes" and $_ =~ m/$hrgContext/ and $_ =~ m/$CDRCorrelationID/)
        {
                $foundpmlogHRGreq =  'yes';
                $foundHRGRequest = 'yes';
                $foundpmlog = 'yes';
                $pmlogrespstrLineLength = length $_;
                if ( $pmlogrespstrLineLength > $SINscreenContentWide )
                {
                        for (my $zzz=0; $zzz < $pmlogrespstrLineLength; $zzz+=$SINscreenContentWide)
                        {
                                $pmlogrespstrLine = substr($_, $zzz, $SINscreenContentWide);
                                printf( " %-$SINscreenWides", $pmlogrespstrLine );
                                $saveDollar=$_;
                                printCylinder("$printCylinderCounter","brakeLine","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                                $_=$saveDollar;
                        }
                }
                else
                {
                        printf( "\n %-$SINscreenWides", $_ );
                        $saveDollar=$_;
                        printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                        $_=$saveDollar;
                }
        }
        if( $_ =~ m/------/ and $foundpmlog eq "yes" and $foundpmlogresponse eq "no" and $foundpmlogresponsefinished eq "no")
        {
                $foundpmlogresponsecont = 'yes';
        }


        if( $_ =~ m/</ and $_ =~ m/>/ and $foundpmlogresponsecont eq "yes" and $foundpmlogresponsefinished eq "no" and $foundDNDRequest ne "yes" and $foundCMGRRequest ne "yes" and $foundSIBBRequest ne "yes")
        {
                if ($foundHRGRequest eq "yes")
                {
                        $foundHRGRequest = 'no';
                        $foundpmlogHRGreq = 'no';
                }
                printf( " %-$SINscreenWides", " " );
                $saveDollar=$_;
                printCylinder("$printCylinderCounter","brakeLine","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                $_=$saveDollar;
                printf( " %-$SINscreenWides", "------------------------------------------------- " );
                $saveDollar=$_;
                printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                $_=$saveDollar;
                printf( "\n %-$SINscreenWides", " " );
                $saveDollar=$_;
                printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                $_=$saveDollar;
                printf( "\n %-$SINscreenWides", "                     RESPONSE : " );
                $saveDollar=$_;
                printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                $_=$saveDollar;
                printf( "\n %-$SINscreenWides", " " );
                $saveDollar=$_;
                printCylinder("$printCylinderCounter","brakeLine","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                $_=$saveDollar;
                $foundpmlogresponse = 'yes';
                $saveDollarAgain=$_;
                $foundpmlogresponseAgain = 'no';
                open pmlogFILEAgain, "</tango/logs/process/pm.log" or die(color("reset"), "\nCould not open pm.log file. $!\n\n");
                @lines = <pmlogFILEAgain>;
                while($line = pop @lines)
                {
                        chomp($line);
                        if( $line =~ m/</ and $line =~ m/>/ and $foundpmlogresponseAgain ne "yes")
                        {
                                $foundpmlogresponseAgain = 'yes';
                                printf( " %-$SINscreenWides", " " );
                                $saveDollar=$line;
                                printCylinder("$printCylinderCounter","brakeLine","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                                $line=$saveDollar;
                                $pmlogstrLineLength = length $line;
                                if ( $pmlogstrLineLength > $SINscreenContentWide )
                                {
                                        for (my $nn=0; $nn < $pmlogstrLineLength; $nn+=$SINscreenContentWide)
                                        {
                                                $pmlogstrLine =  substr($line, $nn, $SINscreenContentWide);
                                                printf( " %-$SINscreenWides", $pmlogstrLine );
                                                $saveDollar=$line;
                                                printCylinder("$printCylinderCounter","brakeLine","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                                                $line=$saveDollar;
                                        }
                                }
                                else
                                {
                                        printf( "\n %-$SINscreenWides", $line );
                                        $saveDollar=$line;
                                        printCylinder("$printCylinderCounter","brakeLine","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                                        $line=$saveDollar;
                                }
                        }
                }
                close pmlogFILEagain;
                $_=$saveDollarAgain;

                $foundpmlogresponsefinished = 'yes';
        }
        elsif( $_ =~ m/{/ and $_ =~ m/}/ and $foundpmlogresponsecont eq "yes" and $foundpmlogresponsefinished eq "no" and $foundDNDRequest ne "yes" and $foundCMGRRequest ne "yes" and $foundHRGRequest ne "yes")
        {
                printf( " %-$SINscreenWides", " " );
                $saveDollar=$_;
                printCylinder("$printCylinderCounter","brakeLine","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                $_=$saveDollar;
                printf( " %-$SINscreenWides", "------------------------------------------------- " );
                $saveDollar=$_;
                printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                $_=$saveDollar;
                printf( "\n %-$SINscreenWides", " " );
                $saveDollar=$_;
                printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                $_=$saveDollar;
                printf( "\n %-$SINscreenWides", "                     RESPONSE : " );
                $saveDollar=$_;
                printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                $_=$saveDollar;
                printf( "\n %-$SINscreenWides", " " );
                $saveDollar=$_;
                printCylinder("$printCylinderCounter","brakeLine","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                $_=$saveDollar;
                $foundpmlogresponse = 'yes';
                $pmlogrespstrLineLength = length $_;
                if ( $pmlogrespstrLineLength > $SINscreenContentWide )
                {
                        for (my $n=0; $n < $pmlogrespstrLineLength; $n+=$SINscreenContentWide)
                        {
                                $pmlogrespstrLine = substr($_, $n, $SINscreenContentWide);
                                printf( " %-$SINscreenWides", $pmlogrespstrLine );
                                $saveDollar=$_;
                                printCylinder("$printCylinderCounter","brakeLine","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                                $_=$saveDollar;
                        }
                }
                else
                {
                        printf( "\n %-$SINscreenWides", $_ );
                        $saveDollar=$_;
                        printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                        $_=$saveDollar;
                }
                $foundpmlogresponsefinished = 'yes';
        }
        elsif( $_ =~ m/{/ and $_ =~ m/}/ and $foundpmlogresponsecont eq "yes" and $foundpmlogresponsefinished eq "no" and $foundHRGRequest eq "yes" and  $_ =~ m/$msisdnInt/ and $_ =~ m/HRG/ and $_ =~ m/$CDRCorrelationID/)
        {
                $foundHRGRequest = 'no';
                printf( " %-$SINscreenWides", " " );
                $saveDollar=$_;
                printCylinder("$printCylinderCounter","brakeLine","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                $_=$saveDollar;
                printf( " %-$SINscreenWides", "------------------------------------------------- " );
                $saveDollar=$_;
                printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                $_=$saveDollar;
                printf( "\n %-$SINscreenWides", " " );
                $saveDollar=$_;
                printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                $_=$saveDollar;
                printf( "\n %-$SINscreenWides", "                     RESPONSE : " );
                $saveDollar=$_;
                printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                $_=$saveDollar;
                printf( "\n %-$SINscreenWides", " " );
                $saveDollar=$_;
                printCylinder("$printCylinderCounter","brakeLine","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                $_=$saveDollar;
                $foundpmlogresponse = 'yes';
                $pmlogrespstrLineLength = length $_;
                if ( $pmlogrespstrLineLength > $SINscreenContentWide )
                {
                        for (my $kk=0; $kk < $pmlogrespstrLineLength; $kk+=$SINscreenContentWide)
                        {
                                $pmlogrespstrLine = substr($_, $kk, $SINscreenContentWide);
                                printf( " %-$SINscreenWides", $pmlogrespstrLine );
                                $saveDollar=$_;
                                printCylinder("$printCylinderCounter","brakeLine","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                                $_=$saveDollar;
                        }
                }
                else
                {
                        printf( "\n %-$SINscreenWides", $_ );
                        $saveDollar=$_;
                        printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                        $_=$saveDollar;
                }
                $foundpmlogresponsefinished = 'yes';
        }
        elsif( $_ =~ m/{/ and $_ =~ m/}/ and $foundpmlogresponsecont eq "yes" and $foundpmlogresponsefinished eq "no" and $foundDNDRequest eq "yes" and  $_ =~ m/$msisdnInt/ and $_ =~ m/settingType/)
        {
                $foundpmlogresponseAgain = 'no';
                $foundDNDRequest = 'no';
                printf( " %-$SINscreenWides", " " );
                $saveDollar=$_;
                printCylinder("$printCylinderCounter","brakeLine","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                $_=$saveDollar;
                printf( " %-$SINscreenWides", "------------------------------------------------- " );
                $saveDollar=$_;
                printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                $_=$saveDollar;
                printf( "\n %-$SINscreenWides", " " );
                $saveDollar=$_;
                printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                $_=$saveDollar;
                printf( "\n %-$SINscreenWides", "                     RESPONSE : " );
                $saveDollar=$_;
                printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                $_=$saveDollar;
                printf( "\n %-$SINscreenWides", " " );
                $saveDollar=$_;
                printCylinder("$printCylinderCounter","brakeLine","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                $_=$saveDollar;
                $foundpmlogresponse = 'yes';
                $saveDollarAgain=$_;
                open pmlogFILEAgain, "</tango/logs/process/pm.log" or die(color("reset"), "\nCould not open pm.log file. $!\n\n");
                @lines = <pmlogFILEAgain>;
                while($line = pop @lines)
                {
                        chomp($line);
                        if( $line =~ m/{/ and $line =~ m/}/ and $line =~ m/$msisdnInt/ and $line =~ m/settingType/ and $foundpmlogresponseAgain ne "yes")
                        {
                                $foundpmlogresponseAgain = 'yes';
                                $line=$saveDollar;
                                $pmlogrespstrLineLength = length $line;
                                if ( $pmlogrespstrLineLength > $SINscreenContentWide )
                                {
                                        for (my $n=0; $n < $pmlogrespstrLineLength; $n+=$SINscreenContentWide)
                                       {
                                                $pmlogrespstrLine = substr($line, $n, $SINscreenContentWide);
                                                printf( " %-$SINscreenWides", $pmlogrespstrLine );
                                                $saveDollar=$line;
                                                printCylinder("$printCylinderCounter","brakeLine","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                                                $line=$saveDollar;
                                        }
                                }
                                else
                                {
                                        printf( "\n %-$SINscreenWides", $line );
                                        $saveDollar=$line;
                                        printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                                        $line=$saveDollar;
                                }
                        }
                }
                close pmlogFILEagain;
                $_=$saveDollarAgain;
                $foundpmlogresponsefinished = 'yes';
        }
        elsif( $_ =~ m/{/ and $_ =~ m/}/ and $foundpmlogresponsecont eq "yes" and $foundpmlogresponsefinished eq "no" and $foundCMGRRequest eq "yes" and  $_ =~ m/$msisdnInt/ and $_ =~ m/trigger/)
        {
                $foundCMGRRequest = 'no';
                $foundpmlogresponseAgain = 'no';
                $saveDollarAgain=$_;
                open pmlogFILEAgain, "</tango/logs/process/pm.log" or die(color("reset"), "\nCould not open pm.log file. $!\n\n");
                @lines = <pmlogFILEAgain>;
                while($line = pop @lines)
                {
                        chomp($line);
                        if( $line =~ m/{/ and $line =~ m/}/ and $line =~ m/$msisdnInt/ and $line =~ m/trigger/ and $foundpmlogresponseAgain ne "yes")
                        {
                                $foundpmlogresponseAgain = 'yes';
                                printf( "\n %-$SINscreenWides", " " );
                                $saveDollar=$line;
                                printCylinder("$printCylinderCounter","brakeLine","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                                $line=$saveDollar;
                                $pmlogreqstrLineLength = length $line;
                                if ( $pmlogreqstrLineLength > $SINscreenContentWide )
                                {
                                        for (my $n=0; $n < $pmlogreqstrLineLength; $n+=$SINscreenContentWide)
                                        {
                                                $pmlogreqstrLine = substr($line, $n, $SINscreenContentWide);
                                                printf( " %-$SINscreenWides", $pmlogreqstrLine );
                                                $saveDollar=$line;
                                                printCylinder("$printCylinderCounter","brakeLine","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                                                $line=$saveDollar;
                                        }
                                }
                                else
                                {
                                     printf( "\n %-$SINscreenWides", $line );
                                        $saveDollar=$line;
                                        printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                                        $line=$saveDollar;
                                }
                        }
                }
                close pmlogFILEagain;
                $_=$saveDollarAgain;
                $foundpmlogresponse = 'yes';
                $foundpmlogresponsefinished = 'yes';

                printf( " %-$SINscreenWides", " " );
                $saveDollar=$_;
                printCylinder("$printCylinderCounter","brakeLine","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                $_=$saveDollar;
                printf( " %-$SINscreenWides", "------------------------------------------------- " );
                $saveDollar=$_;
                printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                $_=$saveDollar;
                printf( "\n %-$SINscreenWides", " " );
                $saveDollar=$_;
                printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                $_=$saveDollar;
                printf( "\n %-$SINscreenWides", "                     RESPONSE : " );
                $saveDollar=$_;
                printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                $_=$saveDollar;
                printf( "\n %-$SINscreenWides", " " );
                $saveDollar=$_;
                printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                $_=$saveDollar;
                $foundpmlogresponse = 'yes';
                printf( "\n %-$SINscreenWides","CMGR Response not found in pm.logs, sorry" );
                $saveDollar=$_;
                printCylinder("$printCylinderCounter","brakeLine","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                $_=$saveDollar;

        }
        elsif( $_ =~ m/\[]/ and $foundpmlogresponsecont eq "yes" and $foundpmlogresponsefinished eq "no" and $foundDNDRequest eq "yes")
        {
                $foundDNDRequest = 'no';
                printf( " %-$SINscreenWides", " " );
                $saveDollar=$_;
                printCylinder("$printCylinderCounter","brakeLine","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                $_=$saveDollar;
                printf( " %-$SINscreenWides", "------------------------------------------------- " );
                $saveDollar=$_;
                printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                $_=$saveDollar;
                printf( "\n %-$SINscreenWides", " " );
                $saveDollar=$_;
                printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                $_=$saveDollar;
                printf( "\n %-$SINscreenWides", "                     RESPONSE : " );
                $saveDollar=$_;
                printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                $_=$saveDollar;
                printf( "\n %-$SINscreenWides", " " );
                $saveDollar=$_;
                printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                $_=$saveDollar;
                $foundpmlogresponse = 'yes';
                printf( "\n %-$SINscreenWides","[]" );
                $saveDollar=$_;
                printCylinder("$printCylinderCounter","brakeLine","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                $_=$saveDollar;
                $foundpmlogresponsefinished = 'yes';
        }
        elsif( $_ =~ m/<ssrvResponse>/ and $foundpmlogresponsecont eq "yes" and $foundpmlogresponsefinished eq "no" and $getSIBBRequestlogsFinished ne "yes" and $getSIBBRequestlogs ne "yes")
        {
                $getSIBBRequestlogs = 'yes';
        }
        elsif( $getSIBBRequestlogs eq "yes")
        {
                $_ =~ s/^\s+|\s+$//g;
                if ($_ ne "--------")
                {
                        push @SIBBRequestlogs,$_;
                        $getSIBBRequestlogsFinished = 'no';
                }
                else
                {
                        $getSIBBRequestlogs = 'no';
                        printf( " %-$SINscreenWides", " " );
                        $saveDollar=$_;
                        printCylinder("$printCylinderCounter","brakeLine","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                        $_=$saveDollar;
                        printf( " %-$SINscreenWides", "------------------------------------------------- " );
                        $saveDollar=$_;
                        printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                        $_=$saveDollar;
                        printf( "\n %-$SINscreenWides", " " );
                        $saveDollar=$_;
                        printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                        $_=$saveDollar;
                        printf( "\n %-$SINscreenWides", "                     RESPONSE : " );
                        $saveDollar=$_;
                        printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                        $_=$saveDollar;
                        printf( "\n %-$SINscreenWides", " " );
                        $saveDollar=$_;
                        printCylinder("$printCylinderCounter","brakeLine","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                        $_=$saveDollar;
                        $SIBBRequestlogsStr = join(" ", @SIBBRequestlogs);
                        $SIBBRequestlogsStrLength = length $SIBBRequestlogsStr;
                        if ( $SIBBRequestlogsStrLength > $SINscreenContentWide )
                        {
                                for (my $ss=0; $ss < $SIBBRequestlogsStrLength; $ss+=$SINscreenContentWide)
                                {
                                        $SIBBRequestlogsStrLine = substr($SIBBRequestlogsStr, $ss, $SINscreenContentWide);
                                        printf( " %-$SINscreenWides", $SIBBRequestlogsStrLine );
                                        $saveDollar=$SIBBRequestlogsStr;
                                        printCylinder("$printCylinderCounter","brakeLine","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                                        $SIBBRequestlogsStr=$saveDollar;
                                }
                        }
                        else
                        {
                                printf( "\n %-$SINscreenWides", $SIBBRequestlogsStr );
                                $saveDollar=$SIBBRequestlogsStr;
                                printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                                $SIBBRequestlogsStr=$saveDollar;
                        }
                        $foundpmlogresponsefinished = 'yes';
                        @SIBBRequestlogs=();
                        $SIBBRequestlogsStr = '';
                }
        }

}
$srurlresourcelength = length $srurlresourceline;
if ( $foundpmlog eq "no" )
{
        if ( $srurlresourcelength > $SINscreenContentWide )
        {
                for (my $k=0; $k < $srurlresourcelength; $k+=$SINscreenContentWide)
                {
                        $srurlresource =  substr($srurlresourceline, $k, $SINscreenContentWide);
                        printf( " %-$SINscreenWides", $srurlresource );
                        $saveDollar=$_;
                        printCylinder("$printCylinderCounter","brakeLine","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                        $_=$saveDollar;
                }
        }
        else
        {
                printf( " %-$SINscreenWides", $srurlresourceline );
                $saveDollar=$_;
                printCylinder("$printCylinderCounter","brakeLine","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
                $_=$saveDollar;
        }
}
close pmlogFILE;
printf( " %-$SINscreenWides", " " );
printCylinder("$printCylinderCounter","brakeLine","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
printf( " %-$SINscreenWides", "------------------------------------------------- " );
printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
printf( "\n %-$SINscreenWides", " " );
printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
printf( "\n%-8s\e[0m", " Resp Map = ");
printf( "%-$RMscreenWides", "$ResponseMapValueLine[-1]");
printf( "\e[7;49;31m%-9s", " ");
printCylinder("$printCylinderCounter","no","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
printf( "\n %-$SINscreenWides", " ");
printCylinder("$printCylinderCounter","brakeLine","$srurlresourceline","$DateTime_SICDR_FieldNum");$printCylinderCounter = $printCylinderCounter + 1;
}

sub reloadTempUSSD_SI_main
{
my $reloadUSSD_SI_mainFlag = 'no';
my $reloadUSSD_SI_mainFlagNoLine = 'no';
my $foundincludeSINnamesLine = 'no';
open USSDSIMAINFILE, "<$USSD_SI_mainFile" or die(color("reset"), "\nCould not open USSD_SI_main file. $! It might not be configured in SI_tool.pl. Run SI_tool -h for more details\n\n");
while(<USSDSIMAINFILE>)
{
        chomp;
        my @RemoveIfHashes = split "#" , $_;
        if( $RemoveIfHashes[0] =~ m/include SIN names/ )
        {
        my $foundincludeSINnamesLine = 'yes';
        push (@pushfoundincludeSINnamesLine,$foundincludeSINnamesLine);
                if( $RemoveIfHashes[0] =~ m/include SIN names/ and $RemoveIfHashes[0] =~ m/no/ )
                {
                        handleFileBackup($USSD_SI_mainFile,"backup");
                        handleFileBackup($USSD_SI_mainFile,"orig");
                        $reloadUSSD_SI_mainFlag = 'yes';
                        $autologoutActive = 'yes';
                }
                elsif( $RemoveIfHashes[0] =~ m/include SIN names/ and $RemoveIfHashes[0] =~ m/false/ )
                {
                        handleFileBackup($USSD_SI_mainFile,"backup");
                        handleFileBackup($USSD_SI_mainFile,"orig");
                        $reloadUSSD_SI_mainFlag = 'yes';
                        $autologoutActive = 'yes';
                }
        }
}
unless( $pushfoundincludeSINnamesLine[-1] eq "yes" )
{
        handleFileBackup($USSD_SI_mainFile,"backup");
        handleFileBackup($USSD_SI_mainFile,"orig");
        $reloadUSSD_SI_mainFlag = 'yes';
        $reloadUSSD_SI_mainFlagNoLine = 'yes';
        $autologoutActive = 'yes';
}

close USSDSIMAINFILE;
push (@pushreloadUSSD_SI_mainFlag,$reloadUSSD_SI_mainFlag);
if ( $reloadUSSD_SI_mainFlag eq 'yes')
{
        replaceUSSDSImainFile($USSD_SI_mainFile,"include SIN names","include SIN names = yes",$reloadUSSD_SI_mainFlagNoLine);
        $send_configReload_to_USSD_siOamFlag = 'true';
        push (@pushsend_configReload_to_USSD_siOamFlag,$send_configReload_to_USSD_siOamFlag);
}
}

sub reloadOrigUSSD_SI_main
{
if( $pushreloadUSSD_SI_mainFlag[-1] eq "yes" )
{
        handleFileBackup($USSD_SI_mainFile,"recover");
}
}

sub reloadTempUSSD_SD_SI_files
{
if ($_[0] eq "start")
{
        my $reloadUSSD_SI_SDFlag = 'no';
        handleFileBackup($USSD_servicesDirFile,"backup");
        handleFileBackup($USSD_scriptsDirFile,"backup");
        handleFileBackup($USSD_servicesDirFile,"orig");
        handleFileBackup($USSD_scriptsDirFile,"orig");
        $reloadUSSD_SI_SDFlag = 'yes';
        push (@pushreloadUSSD_SI_SDFlag,$reloadUSSD_SI_SDFlag);
}
elsif ($_[0] eq "checkIfDeployed")
{
        $javaScriptAllTagsLength = scalar @javaScriptAllTags;
        for (my $s=0; $s < $javaScriptAllTagsLength; $s++)
        {
        system("$copycommand -rfp $USSD_servicesDirFile $SIsimScriptDir/.$USSD_servicesFile.checkReplace");
        handleFileBackup($USSD_servicesDirFile,"checkIfDeployed");
        system("$copycommand -rfp $USSD_scriptsDirFile $SIsimScriptDir/.$USSD_scriptsFile.checkReplace");
        handleFileBackup($USSD_scriptsDirFile,"checkIfDeployed");
        }
}

if ($_[0] eq "start")
{
        $javaScriptAllTagsLength = scalar @javaScriptAllTags;
        for (my $s=0; $s < $javaScriptAllTagsLength; $s++)
        {
                replaceUSSDservicesFile($javaScriptAllTags[$s],'start');
                replaceUSSDscriptFile($javaScriptAllTags[$s],'start');
        }
        $send_configReload_to_USSD_siOamFlag = 'true';
        push (@pushsend_configReload_to_USSD_siOamFlag,$send_configReload_to_USSD_siOamFlag);
}
elsif ($_[0] eq "checkIfDeployed")
{
        if ($pushnewdeploymentFlag[-1] eq "true")
        {
                $javaScriptAllTagsLength = scalar @javaScriptAllTags;
                for (my $s=0; $s < $javaScriptAllTagsLength; $s++)
                {
                        replaceUSSDservicesFile($javaScriptAllTags[$s],'start');
                        replaceUSSDscriptFile($javaScriptAllTags[$s],'start');
                }
                $send_configReload_to_USSD_siOamFlagNewDeployment = 'true';
                push (@pushsend_configReload_to_USSD_siOamFlagNewDeployment,$send_configReload_to_USSD_siOamFlagNewDeployment);
        }
        else
        {
                $send_configReload_to_USSD_siOamFlagNewDeployment = 'false';
                push (@pushsend_configReload_to_USSD_siOamFlagNewDeployment,$send_configReload_to_USSD_siOamFlagNewDeployment);
        }
}
}

sub reloadOrigUSSD_SD_SI_files
{
if( $pushreloadUSSD_SI_SDFlag[-1] eq "yes" )
{
        handleFileBackup($USSD_servicesDirFile,"recover");
        handleFileBackup($USSD_scriptsDirFile,"recover");
        system("mv $SIsimScriptDir/.*Replace $SIsimScriptDir/backups/");
}
}

sub handleFileBackup
{
@inputFile = split "/" , $_[0];
$backedfile = "${SIsimScriptDir}/.${inputFile[-1]}.$_[1]";

if ( $_[1] eq "backup" )
{
        my @time = getTime();
        my $datetimenow = $time[3].$time[4].$time[5]."_".$time[2].$time[1].$time[0];
        $backedfile = "${SIsimScriptDir}/backups/.${inputFile[-1]}.$_[1]";

        unless  (-e "$SIsimScriptDir/backups/")
        {
                system("$mkdircommand $SIsimScriptDir/backups/");
                print color("green"),"\nINFO: $mkdircommand $SIsimScriptDir/backups/ directory didnt exist. It is Ok now, it has been already created/ \n", color("reset");
        }
        unless (-e "$SIsimScriptDir/backups/.$inputFile[-1].$_[1]")
        {
                system("$copycommand -rfp $_[0] $SIsimScriptDir/backups/.$inputFile[-1].$_[1]");
                system("$copycommand -rfp $_[0] $SIsimScriptDir/backups/.$inputFile[-1].$_[1].$datetimenow");
                print color("green"),"\nINFO: $inputFile[-1].$_[1] didnt exist. It is Ok now, backup was created under $SIsimScriptDir/backups/ \n", color("reset");
        }
        unless (compare($_[0], $backedfile) == 0)
        {
                print color("red"),"\nATTENTION! $_[0] and $SIsimScriptDir/backups/.$inputFile[-1].$_[1] are different. This is not normal. I took this backup when SI_tool was run last time";
                print "\nReasons:\n--Either $_[0] needed to be changed by someone else and must remain the same\n--Either Service Definition was deployed via USSD PMI\n--Ether putty or other window was closed or SI_tool was killed while SI_tool was running\n", color("reset");
                print "\nDo you want to backup $_[0]",color("yellow")," [Enter b]",color("reset")," or recover $SIsimScriptDir/backups/.$inputFile[-1].$_[1]",color("yellow")," [Enter r]",color("reset")," (Default b) ? > ";
                $backupkey = <STDIN>;
                chomp($backupkey);
                if ( $backupkey eq "b" or $backupkey eq "")
                {
                        system("$copycommand -rfp $_[0] $SIsimScriptDir/backups/.$inputFile[-1].$_[1]");
                        system("$copycommand -rfp $_[0] $SIsimScriptDir/backups/.$inputFile[-1].$_[1].$datetimenow");
                        print color("green"),"\nINFO: It is Ok now, backup was created under $SIsimScriptDir/backups/ \n", color("reset");
                }
                else
                {
                        system("$copycommand -rfp $SIsimScriptDir/backups/.$inputFile[-1].$_[1] $_[0]");
                        print color("green"),"\nINFO: It is Ok now,  $_[0] was recovered with last backup \n", color("reset");
                }
        }
}
elsif ( $_[1] eq "orig" )
{
        system("$copycommand -rfp $_[0] $SIsimScriptDir/.$inputFile[-1].$_[1]");
}
elsif ( $_[1] eq "recover" )
{
        system("$copycommand -rfp $SIsimScriptDir/.$inputFile[-1].orig $_[0]");
}
elsif ( $_[1] eq "checkIfDeployed")
{
        $checkReplaceservicesfile="$SIsimScriptDir/.$USSD_servicesFile.checkReplace";
        $ussdservicesoutfile="$SIsimScriptDir/.$USSD_servicesFile.startReplace";
        unless (compare($checkReplaceservicesfile, $ussdservicesoutfile) == 0)
        {
                $newdeploymentFlag = 'true';
                push (@pushnewdeploymentFlag,$newdeploymentFlag);
        }
        else
        {
                $checkReplacescriptsfile="$SIsimScriptDir/.$USSD_scriptsFile.checkReplace";
                $ussdscriptsoutfile="$SIsimScriptDir/.$USSD_scriptsFile.startReplace";
                unless (compare($checkReplacescriptsfile, $ussdscriptsoutfile) == 0)
                {
                        $newdeploymentFlag = 'true';
                        push (@pushnewdeploymentFlag,$newdeploymentFlag);
                }
                else
                {
                        $newdeploymentFlag = 'false';
                        push (@pushnewdeploymentFlag,$newdeploymentFlag);
                }
        }
}
}


sub replaceUSSDSImainFile
{
my $ussdsimainoutfile = "$_[0].out_temp";
open IN_USSDSIMAINFILE, "<$_[0]" or die(color("reset"), "\nCould not open $_[0] file. $! It might not be configured in SI_tool.pl. Run SI_tool -h for more details\n\n");
open OUT_USSDSIMAINFILE, ">$ussdsimainoutfile" or die(color("reset"), "\nCould not open $ussdsimainoutfile file. $! It might not be configured in SI_tool.pl. Run SI_tool -h for more details\n\n");
while(<IN_USSDSIMAINFILE>)
{
     chomp;
     if( $_ =~ m/$_[1]/ )
        {
                print OUT_USSDSIMAINFILE $_[2]."\n";
        }
     elsif ( $_ =~ m/CDR]/ and $_[3] eq "yes")
        {
                print OUT_USSDSIMAINFILE "[CDR]\ninclude SIN names = yes\n";
        }
     else
        {
                print OUT_USSDSIMAINFILE $_."\n";
        }
}
close OUT_USSDSIMAINFILE;
close IN_USSDSIMAINFILE;
system("$mvcommand $ussdsimainoutfile $_[0]");
}

sub replaceUSSDservicesFile
{
$USSDservicesFileFoundJS = 'false';
$JavaScriptLineFound = 'false';
$NumberOfStringMapsLineFound = 'false';
$USSDservicesFileFinished = 'false';
$getMapVariables = 'false';
@getMapAllVariables = ();
$v = 0;
my $ussdservicesoutfile = "$SIsimScriptDir/.$USSD_servicesFile.out_temp";
open IN_USSDSERVICESFILE, "<$USSD_servicesDirFile" or die(color("reset"), "\nCould not open $USSD_servicesDirFile file. $! It might not be configured in SI_tool.pl. Run SI_tool -h for more details\n\n");
open OUT_USSDSERVICESFILE, ">$ussdservicesoutfile" or die(color("reset"), "\nCould not open $ussdservicesoutfile file. $! It might not be configured in SI_tool.pl. Run SI_tool -h for more details\n\n");
while(<IN_USSDSERVICESFILE>)
{
     chomp;
     if( $_ =~ m/$_[0]/ and $USSDservicesFileFinished eq "false")
        {
                $USSDservicesFileFoundJS = 'true';
                print OUT_USSDSERVICESFILE $_."\n"
        }
     elsif( $_ =~ m/ScriptInputData/ and $USSDservicesFileFoundJS eq "true" and $USSDservicesFileFinished eq "false")
        {
                $USSDservicesFileFoundJS = 'false';
                $JavaScriptLineFound = 'true';
                print OUT_USSDSERVICESFILE $_."\n"
        }
     elsif( $_ =~ m/NumberOfStringMaps/ and $JavaScriptLineFound eq "true" and $USSDservicesFileFinished eq "false")
        {
                $JavaScriptLineFound = 'false';
                $NumberOfStringMapsLineFound = 'true';
                $getMapVariables = 'true';
                @NumberOfStringMapsNum = split "= ", $_;
                $NumberOfStringMapsNextNum = $NumberOfStringMapsNum[-1] + 1;
                $NumberOfStringMapsLastNum = $NumberOfStringMapsNum[-1] + 2;
                print OUT_USSDSERVICESFILE "NumberOfStringMaps = ".$NumberOfStringMapsLastNum."\n";
        }
     elsif( $_ =~ m/Map/ and $getMapVariables eq "true" and $USSDservicesFileFinished eq "false")
        {
                @getMapAllVariablesLine = split ", ", $_;
                @getMapAllVariables[$v] = $getMapAllVariablesLine[-1];
                $v++;
                print OUT_USSDSERVICESFILE $_."\n"

        }
     elsif( $_ =~ m/ScriptOutputData/ and $NumberOfStringMapsLineFound eq "true" and $USSDservicesFileFinished eq "false")
        {
                $getMapVariables = 'false';
                $NumberOfStringMapsLineFound = 'false';
                $USSDservicesFileFinished = 'true';
                print OUT_USSDSERVICESFILE "    Map".$NumberOfStringMapsNextNum." = \${session_callReferenceId},session_callReferenceId\n    Map".$NumberOfStringMapsLastNum." = \${session_msisdn},msisdn_For_SI_tool\n\n".$_."\n";
        }
     else
        {
                print OUT_USSDSERVICESFILE $_."\n"
        }

}
close OUT_USSDSERVICESFILE;
close IN_USSDSERVICESFILE;
system("$mvcommand $ussdservicesoutfile $USSD_servicesDirFile");
system("$copycommand -rfp $USSD_servicesDirFile $SIsimScriptDir/.$USSD_servicesFile.startReplace")
}

sub replaceUSSDscriptFile
{
$USSDSCRIPTFILEFoundJS = 'false';
$USSDscriptFileFinished = 'false';
$USSDSCRIPTFILEFoundArray = 'false';
@pushpmlogsFunctionVariables = ();
my $ussdscriptsoutfile = "$SIsimScriptDir/.$USSD_scriptsFile.out_temp";
open IN_USSDSCRIPTFILE, "<$USSD_scriptsDirFile" or die(color("reset"), "\nCould not open $USSD_scriptsDirFile file. $! It might not be configured in SI_tool.pl. Run SI_tool -h for more details\n\n");
open OUT_USSDSCRIPTFILE, ">$ussdscriptsoutfile" or die(color("reset"), "\nCould not open $ussdscriptsoutfile file. $! It might not be configured in SI_tool.pl. Run SI_tool -h for more details\n\n");
while(<IN_USSDSCRIPTFILE>)
{
        chomp;
        $TrimSpacesreturnLine = $_;
        $TrimSpacesreturnLine =~ s/\s//g;
        if( $_ =~ m/function $_[0]\(/ and $USSDscriptFileFinished eq "false")
        {
                $USSDSCRIPTFILEFoundJS = 'true';
                $newFunctionVariables = join(',',@getMapAllVariables);
                foreach my $eachVariable (@getMapAllVariables)
                {
                        push @pushpmlogsFunctionVariables, $eachVariable." = \" + ".$eachVariable;
                }
                $pmlogsFunctionVariables = join(' + " | ',@pushpmlogsFunctionVariables);
                if($newFunctionVariables eq "")
                {
                        print OUT_USSDSCRIPTFILE "function ".$_[0]."(session_callReferenceId,msisdn_SI_tool) {\nprint(\"[javascript = ".$_[0]."] [ session_callReferenceId = \" + session_callReferenceId + \" msisdn_SI_tool = \" + msisdn_SI_tool + \" ] [INPUT] There are no Input Parameters for this script\");\n" ;
                }
                else
                {
                        print OUT_USSDSCRIPTFILE "function ".$_[0]."(".$newFunctionVariables.",session_callReferenceId,msisdn_SI_tool) {\nprint(\"[javascript = ".$_[0]."] [ session_callReferenceId = \" + session_callReferenceId + \" msisdn_SI_tool = \" + msisdn_SI_tool + \" ] [INPUT] ".$pmlogsFunctionVariables.");\n" ;
                }
        }
        elsif ( $_ =~ m/var / and $_ =~ m/rray/ and $_ =~ m/ew / and $_ =~ m/=/ and $USSDSCRIPTFILEFoundJS eq "true" and $USSDscriptFileFinished eq "false")
        {
                $USSDSCRIPTFILEFoundArray = 'true';
                $USSDSCRIPTFILEArrayLine = $_;
                print OUT_USSDSCRIPTFILE $_."\n"
        }
        elsif ( $_ =~ m/var / and $_ =~ m/rray=/ and $USSDSCRIPTFILEFoundJS eq "true" and $USSDscriptFileFinished eq "false")
        {
                $USSDSCRIPTFILEFoundArray = 'true';
                $USSDSCRIPTFILEArrayLine = $_;
                print OUT_USSDSCRIPTFILE $_."\n"
        }
        elsif ( $_ =~ m/var / and $_ =~ m/= \[/ and $USSDSCRIPTFILEFoundJS eq "true" and $USSDscriptFileFinished eq "false" and $USSDSCRIPTFILEFoundArray eq "false")
        {
                $USSDSCRIPTFILEFoundArray = 'true';
                $USSDSCRIPTFILEArrayLine = $_;
                print OUT_USSDSCRIPTFILE $_."\n"
        }
        elsif ( $_ =~ m/var / and $_ =~ m/=\[/ and $USSDSCRIPTFILEFoundJS eq "true" and $USSDscriptFileFinished eq "false" and $USSDSCRIPTFILEFoundArray eq "false")
        {
                $USSDSCRIPTFILEFoundArray = 'true';
                $USSDSCRIPTFILEArrayLine = $_;
                print OUT_USSDSCRIPTFILE $_."\n"
        }
        elsif ( $TrimSpacesreturnLine =~ m/return/ and $USSDSCRIPTFILEFoundJS eq "true" and $USSDscriptFileFinished eq "false" and $USSDSCRIPTFILEFoundArray eq "true")
        {
                $USSDscriptFileFinished = 'true';
                @returnArrayName1 = split "return" , $TrimSpacesreturnLine;
                @returnArrayName = split ";" , $returnArrayName1[-1];
                if ( $USSDSCRIPTFILEArrayLine =~ m/$returnArrayName[0]/ )
                {
                        print OUT_USSDSCRIPTFILE "print(\"[javascript = ".$_[0]."] [ session_callReferenceId = \" + session_callReferenceId + \" msisdn_SI_tool = \" + msisdn_SI_tool + \" ] [OUTPUT] resultArray = \" + ".$returnArrayName[0].".join('|'));\n    return ".$returnArrayName[0].";\n";
                }
                else
                {
                        print OUT_USSDSCRIPTFILE "print(\"[javascript = ".$_[0]."] [ session_callReferenceId = \" + session_callReferenceId + \" msisdn_SI_tool = \" + msisdn_SI_tool + \" ] [OUTPUT] resultArray = \" + ".$returnArrayName[0].");\n    return ".$returnArrayName[0].";\n";
                }
        }
        else
        {
                print OUT_USSDSCRIPTFILE $_."\n"
        }


}
close OUT_USSDSCRIPTFILE;
close IN_USSDSCRIPTFILE;
system("$mvcommand $ussdscriptsoutfile $USSD_scriptsDirFile");
system("$copycommand -rfp $USSD_scriptsDirFile $SIsimScriptDir/.$USSD_scriptsFile.startReplace")
}

sub getAllInputsOutoutsFromPmlogs
{
open PMLOGSSCRIPT, "</tango/logs/process/pm.log" or die(color("reset"), "\nCould not open pm.log file. $!\n\n");
while(<PMLOGSSCRIPT>)
{
     chomp;
     if ( $_ =~ m/$_[0]/ and $_ =~ m/$msisdnInt/ and $_ =~ m/INPUT/)
        {
                 push (@getAllINPUTSFromPmlogs,$_);
        }
     if ( $_ =~ m/$_[0]/ and $_ =~ m/$msisdnInt/ and $_ =~ m/OUTPUT/)
        {
                 push (@getAllOUTPUTSFromPmlogs,$_);
        }

}
close PMLOGSSCRIPT;
}

sub finishgetINPUTSFromPmlogs
{
foreach (@getAllINPUTSFromPmlogs)
{
        if ($_ =~ m/$_[0]]/)
        {
                $getInputLine = $_;
                @cleanInputLine = split "INPUT] ",$getInputLine;
        }
}
foreach (@getAllOUTPUTSFromPmlogs)
{
        if ($_ =~ m/$_[0]/)
        {
                $getOutputLine = $_;
                @cleanOutputLine = split "OUTPUT] resultArray = ",$getOutputLine;
        }
}
}

sub send_configReload_to_USSD_siOam
{
if ( $_[0] eq "start" )
{
        print color("yellow"),"\n==============================================================================================\n";
        print "Sending \"configReload\" to USSD_siOam (telnet 0 $USSD_SI_port > add USSD_siOam; send configReload)";
        system("$spawnSIshOutFile reloadSIconfigs ");
        print "\nReloading ";
        $| = 1;
        foreach my $h (0..6){print '.';sleep 1;}
        $| = 0;
        print "\n", color("reset");
}
else
{
        print color("yellow"),"Sending \"configReload\" to USSD_siOam (telnet 0 $USSD_SI_port > add USSD_siOam; send configReload)";
        system("$spawnSIshOutFile reloadSIconfigs ");
        print "\nStopping and recovering original configurations ";
        $| = 1;
        foreach my $h (0..6){print '.';sleep 1;}
        $| = 0;
        print color("yellow"),"\n==============================================================================================\n\n", color("reset");
}
}

sub send_reloadConfig_to_HTTP_oam
{
if ( $_[0] eq "start" )
{
        print color("yellow"),"\n==============================================================================================\n";
        print "Sending \"reloadConfig\" to HTTP_oam (telnet 0 $USSD_SI_port > add HTTP_oam; send reloadConfig)";
        system("$spawnSIshOutFile HTTP_reloadConfig ");
        system("$spawnSIshOutFile HTTP_reloadWhiteList ");
        system("$spawnSIshOutFile HTTP_reloadSeRouting ");
        system("$spawnSIshOutFile HTTP_reloadUrlTranslate ");
        print "\nReloading ";
        $| = 1;
        foreach my $h (0..6){print '.';sleep 1;}
        $| = 0;
        print "\n", color("reset");
}
else
{
        print color("yellow"),"\nSending \"reloadConfig\" to HTTP_oam (telnet 0 $USSD_SI_port > add HTTP_oam; send reloadConfig)";
        system("$spawnSIshOutFile HTTP_reloadConfig ");
        system("$spawnSIshOutFile HTTP_reloadWhiteList ");
        system("$spawnSIshOutFile HTTP_reloadSeRouting ");
        system("$spawnSIshOutFile HTTP_reloadUrlTranslate ");
        print "\nStopping and recovering original configurations ";
        $| = 1;
        foreach my $h (0..6){print '.';sleep 1;}
        $| = 0;
        print color("yellow"),"\n==============================================================================================\n\n", color("reset");
}
}

sub welcomeWarning
{
print color("red"),"\n                                         WARNING !\n      Do not run this tool on productive platforms on where Service Interpreter runs\n";
print "       --This script will TEMPORARELY change Service Interpreter configurations---\n",color("green"),"Run this tool on a testbed/lab. Just get/transfer USSD_services.cfg and USSD_script.js files\n\n";
print color("red"),"                                    Hold Control+C Now\n\n",color("green");
$prompt="\e[0mAre you sure you want to continue ? [Press Enter to continue] > ";
$contkey = $term->readline($prompt);
$term->addhistory($contkey);
chomp($contkey);
}

sub isSessionIDinFile
{
        $isSessionIDinFileQx=qx(grep $_[0] $_[1] | egrep -v grep);
        if ($isSessionIDinFileQx eq "")
        {
                $isSessionIDinFileQx=qx(grep $_[0] $_[2]/$_[3]* | egrep -v grep | head -1);
                if ($isSessionIDinFileQx eq "")
                {
                        $isSessionIDinRollOverFileFlag='no';
                }
                else
                {
                        @isSessionIDinFileQx=split(':', $isSessionIDinFileQx);
                        $isSessionIDinRollOverFileFlag='yes';
                        $foundSessionIDFile=$isSessionIDinFileQx[0];
                }
        }
        else
        {
                $isSessionIDinRollOverFileFlag='no';
        }
}

sub isSessionIDinFileForSPCM
{
        unless($scpCDRsFlag eq "yes")
        {
                $isSessionIDinFileQx=qx(grep '$_[0],39' $_[1] | grep $_[4] | egrep -v grep);
                if ($isSessionIDinFileQx eq "")
                {
                        $isSessionIDinFileQx=qx(grep '$_[0],39' $_[2]/$_[3]* | grep $_[4] | grep -v grep | head -1);
                        if ($isSessionIDinFileQx eq "")
                        {
                                $isSessionIDinRollOverFileFlag='no';
                        }
                        else
                        {
                                @isSessionIDinFileQx=split(':', $isSessionIDinFileQx);
                                $isSessionIDinRollOverFileFlag='yes';
                        }
                }
                else
                {
                        $isSessionIDinRollOverFileFlag='no';
                }
        }
        else
        {
                $isSessionIDinFileQx=qx(grep '$_[0],39' $SIsimScriptDir/scpCDRs/* | grep $_[4] | egrep -v grep | head -1 );
                @isSessionIDinFileQx=split(':', $isSessionIDinFileQx);
                if ($isSessionIDinFileQx eq "")
                {
                        $isSessionIDinRollOverFileFlag='no';
                }
                else
                {
                        $isSessionIDinRollOverFileFlag='yes';
                        $foundSessionIDFile=$isSessionIDinFileQx[0];
                }
        }

}

sub isSessionIDinFileForDND
{
        $isSessionIDinFileQx=qx(grep $_[0] $_[1] | grep $_[4] | egrep -v grep);
        if ($isSessionIDinFileQx eq "")
        {
                if ($itIsCMGR eq "yes")
                {
                        $isSessionIDinFileQx=qx(grep $_[0] $_[2]/$_[3]* | grep $_[4] | egrep -v grep | tail -1);
                }
                else
                {
                        $isSessionIDinFileQx=qx(grep $_[0] $_[2]/$_[3]* | grep $_[4] | egrep -v grep | head -1);
                }
                if ($isSessionIDinFileQx eq "")
                {
                        $isSessionIDinRollOverFileFlag='no';
                }
                else
                {
                        @isSessionIDinFileQx=split(':', $isSessionIDinFileQx);
                        $isSessionIDinRollOverFileFlag='yes';
                        $foundSessionIDFile=$isSessionIDinFileQx[0];
                }
        }
        else
        {
                $isSessionIDinRollOverFileFlag='no';
        }
}


sub isSessionIDinFileForAM
{
        $isSessionIDinFileQx=qx(grep $_[0] $_[1] | grep $_[4] | egrep -v grep);
        if ($isSessionIDinFileQx eq "")
        {
                $isSessionIDinFileQx=qx(grep $_[0] $_[2]/$_[3]* | grep $_[4] | egrep -v grep | head -1);
                if ($isSessionIDinFileQx eq "")
                {
                        $isSessionIDinRollOverFileFlag='no';
                }
                else
                {
                        @isSessionIDinFileQx=split(':', $isSessionIDinFileQx);
                        $isSessionIDinRollOverFileFlag='yes';
                        $foundSessionIDFile=$isSessionIDinFileQx[0];
                }
        }
        else
        {
                $isSessionIDinRollOverFileFlag='no';
        }
}

sub newDeployWarning
{
        print color("red"),"\nATTENTION! $USSD_servicesDirFile and/or $USSD_scriptsDirFile  has been changed.";
        print "\nReasons:\n--Either Service Definition was deployed via USSD PMI\n--Either USSD SI files were edited manually\n", color("reset");
        print "I will be reloading SI_tool now .... ";
}

sub triggermode
{
getTime();
$startime=$Hour.":".$Minute.":".$Second;
$triggertime=$startime;
my $start = [ gettimeofday() ];
my $windowtimesofar = '0';
$j='0';
while ($timewindow > $windowtimesofar)
{
        getTime();
        $timenow=$Hour.":".$Minute.":".$Second;
        $windowtimesofar =  str2time($timenow) - str2time($startime);

        if ($incremental eq "yes")
        {
                if ($_ ne "0")
                {
                        $msisdnInt=$msisdnInt + 1;
                }
        }
        my $iteration_start = [ gettimeofday() ];
        if ($HTTP_REST_API_WS ne "USSD_siWebService")
        {
                if ($SIversionURLFlag eq "low")
                {
                        $curlUrl="http://127.0.0.1:$SI_Http_port/USSD_serviceInterpreter/$SI_Http_instance/se/facebook/?ussdString=".$ussdString;
                }
                else
                {
                        $curlUrl="http://127.0.0.1:$SI_Http_port/USSD_serviceInterpreter/$SI_Http_instance/se/facebook/?msisdn=".$msisdnInt."&ussdString=".$ussdString;
                }
                print color("reset"),"[$timenow] Request = curl '$curlUrl'\n",color("red");

                $j=$j+1;
                my $pid = fork();die "fork failed" unless defined $pid;
                if ($pid == 0)
                {
                        #my $exit_code = system("curl '$curlUrl' &>/dev/null");
                        #exit $exit_code >> 8;
                        exec("curl '$curlUrl' &>/dev/null");
                }
        }
        elsif ($HTTP_REST_API_WS eq "USSD_siWebService")
        {
                $key = '{"msisdn":"' . $msisdnInt . '","serviceCode":"' . $serviceCodeJson . '","data":' . $jsonData . '}';
                $url="http://127.0.0.1:$SI_Http_port/USSD_serviceInterpreter/$SI_Http_instance/se/ussd-si-ws-request";
                $req = HTTP::Request->new(POST => $url);
                $req->content_type('application/json;charset=utf-8');
                $req->content($key);
                $ua = LWP::UserAgent->new;
                $res = $ua->request($req);
                print color("reset"),"[$timenow] Request = '$key'\n",color("red");
        }

        $elapsed_secs[$_] = tv_interval($iteration_start);
        sleep(1/($tps));
}
my $total_secs = tv_interval($start);
print color("green"),"\n============= Perl Script Info ======================\nStart time = $startime\nEnd time = $timenow\n";
print "Total seconds = $total_secs\nNumber of Requests = $j";
@total_secs_roundown=split(/\./, $total_secs);
$Actualtps=$j/$total_secs;
@Actualtpsr=split(/\./, $Actualtps);
print "\nActual TPS = (Number of Requests / Total seconds) =~ ".$Actualtpsr[0];
print "\n============== SI CDR Results =====================\n";
print color("reset"),"Wait while I get all CDRs. Give  me $timewindow secs ....\n",color("green");
sleep(10*$timewindow);
getCDRfield("17,40");
print "Start time = $startime[-1]\nEnd time = $endtime[-1]\n";
$total_secs =  str2time($endtime[-1]) - str2time($startime[-1]);
print "Total seconds = $total_secs\nNumber of Requests = $pushcdrcounter[-1]";
$Actualtps=$pushcdrcounter[-1]/$total_secs;
@Actualtpsr=split(/\./, $Actualtps);
print "\nActual TPS = (Number of Requests / Total seconds) =~ ".$Actualtpsr[0];
print "\nFirst CDR(type 40) = $firstCDR\nLast CDR(type 40) = $lastCDR\n";
$msisdnsicdr = join "0", ( $msisdnInt =~ m/(.)/g );
print "grep $msisdnsicdr $active_ussd_si_cdrs | tail -2";
if ( $cdrpattern ne "deactivated")
{
        print "\n============== $cdrpattern CDR Results ====================\n";
        getCDRfield("$cdrpattern");
        $cdrpatternhits=$cdrcounter;
        @firstCDRArray=split(',',$firstCDR);
        @lastCDRArray=split(',',$lastCDR);
        print "Start time = $firstCDRArray[4]\nEnd time = $lastCDRArray[4]\n";
        $total_secs =  str2time($lastCDRArray[4]) - str2time($firstCDRArray[4]);
        print "Total seconds = $total_secs";
        print "\n---------------------\n";
        print "[Time]       hits\n---------------------\n";
        while (str2time($lastCDRArray[4]) > str2time($firstCDRArray[4]))
        {
                getPatternHits("$pattern","$firstCDRArray[4]");
                print "[$firstCDRArray[4]]   $hitspattern\n";
                my @timeinc = split /:/, $firstCDRArray[4], 3;
                $timeinc[2] += 1;

                for (my $i = 2; $i >= 1; $i--)
                {
                        if ($timeinc[$i] >= 60)
                        {
                                 $timeinc[$i] -= 60;
                                 $timeinc[$i-1]++;
                        }
                }

                $timeinc[0] -= 24 if $timeinc[0] >= 24;
                $firstCDRArray[4] = join ':', map { length($_) < 2 ? "0$_" : $_ } @timeinc;
        }
        getPatternHits("$pattern","$firstCDRArray[4]");
        print "[$firstCDRArray[4]]   $hitspattern\n";
        print "\n---------------------\nTotal hits = $cdrpatternhits\n";
        print "\nFirst CDR(type 40) = $firstCDR\n";
        print "\nLast CDR(type 40) = $lastCDR\n";
        print "\nSI_tool -f $active_ussd_si_cdrs -p $sessionID[-1]\n";
        print "\ngrep $pattern $active_ussd_si_cdrs | tail -1";
}
if ( $cdrpattern2 ne "deactivated")
{
        print "\n============== $cdrpattern2 CDR Results ====================\n";
        getCDRfield("$cdrpattern2");
        $cdrpattern2hits=$cdrcounter;
        @firstCDRArray=split(',',$firstCDR);
        @lastCDRArray=split(',',$lastCDR);
        print "Start time = $firstCDRArray[4]\nEnd time = $lastCDRArray[4]\n";
        $total_secs =  str2time($lastCDRArray[4]) - str2time($firstCDRArray[4]);
        print "Total seconds = $total_secs";
        print "\n---------------------\n";
        print "[Time]       hits\n---------------------\n";
        while (str2time($lastCDRArray[4]) > str2time($firstCDRArray[4]))
        {
                getPatternHits("$pattern","$firstCDRArray[4]");
                print "[$firstCDRArray[4]]   $hitspattern\n";
                my @timeinc = split /:/, $firstCDRArray[4], 3;
                $timeinc[2] += 1;

                for (my $i = 2; $i >= 1; $i--)
                {
                        if ($timeinc[$i] >= 60)
                        {
                                 $timeinc[$i] -= 60;
                                 $timeinc[$i-1]++;
                        }
                }

                $timeinc[0] -= 24 if $timeinc[0] >= 24;
                $firstCDRArray[4] = join ':', map { length($_) < 2 ? "0$_" : $_ } @timeinc;
        }
        getPatternHits("$pattern","$firstCDRArray[4]");
        print "[$firstCDRArray[4]]   $hitspattern\n";
        print "\n---------------------\nTotal hits = $cdrpattern2hits\n";
        print "\nFirst CDR(type 40) = $firstCDR\n";
        print "\nLast CDR(type 40) = $lastCDR\n";
        print "\nSI_tool -f $active_ussd_si_cdrs -p $sessionID[-1]\n";
        print "\ngrep $pattern $active_ussd_si_cdrs | tail -1";
}
print "\n===================================================\n\n",color("reset");
}


sub getCDRfield
{
$cdrcounter="0";
$pattern=$_[0];
$firstCDR="No CDRs";
$lastCDR="No CDRs";
open USSDSICDRFILE, "<$active_ussd_si_cdrs" or die(color("reset"), "\nCould not open ussd si cdrs file. $! It might not be configured in SI_tool.pl. Run SI_tool -h for more details\n\n");
while(<USSDSICDRFILE>)
{
      chomp;
      if( $_ =~ m/$pattern/ and $cdrcounter eq "0" )
      {
                @startimep=split(',', $_);
                $isItAnOldCdr = str2time($startimep[4]) -  str2time($triggertime);
                if ($isItAnOldCdr >= "0")
                {
                        push (@startime,$startimep[4]);
                        push (@sessionID,$startimep[5]);
                        $cdrcounter=$cdrcounter+1;
                        $firstCDR=$_
                }
      }
      elsif ( $_ =~ m/$pattern/)
      {
                @endtimep=();
                @endtimep=split(',', $_);
                $isItAnOldCdr = str2time($endtimep[4]) -  str2time($triggertime);
                push (@endtime,$endtimep[4]);
                push (@sessionID,$startimep[5]);
                $cdrcounter=$cdrcounter+1;
                $lastCDR=$_
      }
      push (@pushcdrcounter,$cdrcounter);
}
close USSDSICDRFILE;
}

sub getPatternHits
{
$hitspattern="0";
$cdrcounter="0";
$pattern=$_[0];
$secondStr=$_[1];
open USSDSICDRHITSFILE, "<$active_ussd_si_cdrs" or die(color("reset"), "\nCould not open ussd si cdrs file. $! It might not be configured in SI_tool.pl. Run SI_tool -h for more details\n\n");
while(<USSDSICDRHITSFILE>)
{
      chomp;
      if( $_ =~ m/$pattern/ and $_ =~ m/$secondStr/)
      {
             $hitspattern=$hitspattern+1;
      }
      push (@pushhitspattern,$hitspattern);
}
close USSDSICDRHITSFILE;
}


sub getTime
{
 ($Second, $Minute, $Hour, $Day, $Month, $Year, $WeekDay, $DayOfYear, $IsDST) = localtime(time);

 if($Hour < 10)   {  $Hour = "0" . $Hour ; }
 if($Minute < 10) {  $Minute = "0" . $Minute ; }
 if($Second < 10) {  $Second = "0" . $Second ; }
 my $Month = $Month + 1 ;
 if($Month < 10)
 {
 $Month = "0" .
 $Month ;
 }
 if($Day < 10)
 {
  $Day = "0" . $Day ;
 }
 if($Year >= 100)
 {
  $Year = $Year - 100 ;
  $Year = $Year + 2000;
 }
 return  ($Second, $Minute, $Hour, $Day, $Month, $Year, $WeekDay, $DayOfYear, $IsDST);
}

sub commands
{
        print color("green"),"\nCOMMANDS:\n - '*SC*tokens#'        Send it to hit a SI SD\n - 'cdrmon'             Send it to illustrate an earlier SI dialogue (IN interactions)\n - 'multitrigger'       Send it to trigger SI multiple times\n - 'back'               Send it to go back and change MSISDN\n - 'display'            Send it to display commands\n - 'history'            Send it to display history\n - 'help'               Send it to display usage\n - 'exit'               Send it to exit SI_tool\n\n",color("reset");
}

sub usage
{
  print <<EOFF;


        Usage: SI_tool.pl

               SI_tool console Commands:

               exit <Quit SI_tool.pl>                           Send "exit" and return bash shell

               back <Go back>                                   Send "back" to go back and change MSISDN

               cdrmon  <CDRs illustrator>                       Send "cdrmon" to illustrate earlier SI dialogueis (it displays SIN interactions)

               multitrigger <Multi-Trigger Mode>                It enables multi-trigger mode. To trigger SI multiple times.
                                                                This will be useful to trigger SD where handset is not involved
                                                                Important Notes:
                                                                - Session will run on the background. Hence, UR will not be able to be responded by user and session will timeout
                                                                - For ussdStrings, \"%20\" must be used instead of spaces

               help <help>                                      Send "help" to display usage


               Flag Options:

               -a <HTTP REST API EndPoint>                      HTTP REST API State Machine
                                                                Options:
                                                                -SI_Http_MI_Interface => USSD string must be entered
                                                                -USSD_siWebService    => Json string must be entered
                                                                Default: What is configured in HTTP_REST_API_WS parameter in SI_tool.cfg

               -j <serviceCode>                                 serviceCode
                                                                Default: What is configured in serviceCode parameter in SI_tool.cfg

               -s <Service Commands SIN Screen wide>            Set with number of spaces
                                                                Default: "75"

               -c <CDR Screen wide>                             Set with number of spaces
                                                                Default: "120"

               -m <msisdn bNumber>                              Include Country Code
                                                                Default: It's set up in SI_tool.cfg

               -p <CDRs Correlation ID>                         Cdrmon mode. Set CDR Correlation ID to illustrate an earlier SI dialogue (it displays SIN interactions)
                                                                Note: Flag -r is not allowed
                                                                Default: 000000 If flag is present
                                                                all: It gathers and displays \"all\" Correllation IDs (all sessions)

               -f <File for ussd_si CDRs>                       Cdrmon mode. Set File for ussd_si CDRs. Flag -p must be present
                                                                Default: /tango/data/cdr/active_ussd_si.cdr

               -r <Multi-Trigger Mode>                          It enables multi-trigger mode. session_ussdString  request to trigger SI directly from bash shell multiple times.
                                                                This will be useful to trigger SD where handset is not involved
                                                                Important Notes:
                                                                - Session will run on the background. Hence, UR will not be able to be responded by user and session will timeout
                                                                - Dont use flag -p
                                                                - You must enclose request with "'" quotes
																- If using USSD_siWebService in flag -a, set here Data json string. Include ' and {}

               -t <hps>                                         Hits per second. Number of times SI will be triggered.
                                                                This flag will be used if -r flag is present
                                                                Default: "100"

               -w <time window>                                 Time in seconds that script will last at hps defined in -h flag
                                                                This flag will be used if -rt flag is present
                                                                Default: "10"

               -i <range of msisdn>                             yes or no
                                                                yes: For each request, msisdn gets incremented by 1
                                                                no:  All request will have same msisdn
                                                                This flag will be used if -r flag is present
                                                                Default: no

               -d <Get hits of a particular CDR>                If you are interested on a particular CDR, set a pattern in this flag
                                                                This flag will be used if -r flag is present
                                                                Default: no pattern

               -h                                               show help


                e.g.1 SI_tool.pl -s 50 -c 100 -m 353872958622
                This triggers SI_tool.pl in console mode for 353872958622

                e.g.2 SI_tool.pl -p BPyc00001 -f /tmp/ussd_si.cdr
                This only illustrates SI dialogue (it displays SIN interactions) for Correlation ID BPyc00001 in /tmp/ussd_si.cdr

                e.g.3 SI_tool.pl -j 8484 -r '{\"trigger\":\"locationUpdate\",\"tenantId\":\"CHRIS\",\"vplmn\":\"26803\",\"timestamp\":\"20/11/2018 17:43:10\",\"imsi\":\"8530103\",\"serviceKey\":\"_\"}' -a USSD_siWebService -t 10 -w 10 -m 5511942384075
                This will trigger SI statemachine: USSD_siWebService, 100 times per second during 10 seconds (total 100 times). Each request will use same msisdn 5511942384075


                e.g.4 SI_tool.pl -r '*8383*locupd*ECUOT*ECUOT*27/02/2018 14:46:47#' -t 10 -w 10 -i yes -m 0872957000 -d SR_provisioning -a SI_Http_MI_Interface
                This will trigger SI statemachine: SI_Http_MI_Interface, 100 times per second during 10 seconds (total 100 times). Each request will use different msisdn. Range= 0872957000 - 0872957999. Results will also show CDR \"SR_provisioning\"  hits

Note: These flags are for quick usage. However, please set the config parameters and defaults in SI_tool.cfg


EOFF
if ( $opt_h ne "noHelp" )
{
  exit;
}
}

sub interrupt2
{
    print STDERR color("reset"),"";
    exit;
}

sub printCylinder
{
$patternLowerCase = lc $_[2];
$ResourceRemServ=$_[2];
$DateTime_SICDR_FieldNum=$_[3];
if ($patternLowerCase =~ m/cmgr/)
{
        getCDRsForRemoteServerSub("cmgr","$DateTime_SICDR_FieldNum");
        $getCDRsForRemoteServerFlag='true';
        $ResourceRemServ='CMGR';
        push(@pushResourceRemServ,$ResourceRemServ);
}
elsif ($patternLowerCase =~ m/dnd/)
{
        getCDRsForRemoteServerSub("dnd","$DateTime_SICDR_FieldNum");
        $getCDRsForRemoteServerFlag='true';
        $ResourceRemServ='dndManager';
        push(@pushResourceRemServ,$ResourceRemServ);
}
elsif ($patternLowerCase =~ m/hrg/ or $patternLowerCase =~ m/http-request-generator/ or $patternLowerCase =~ m/http_request_generator/)
{
        getCDRsForRemoteServerSub("hrg","$DateTime_SICDR_FieldNum");
        $getCDRsForRemoteServerFlag='true';
        $ResourceRemServ='HRG';
        push(@pushResourceRemServ,$ResourceRemServ);
}
elsif ($patternLowerCase =~ m/sibb/ or $patternLowerCase =~ m/$sibbPort/)
{
        getCDRsForRemoteServerSub("sibb","$DateTime_SICDR_FieldNum");
        $getCDRsForRemoteServerFlag='true';
        $ResourceRemServ='SIBB';
        push(@pushResourceRemServ,$ResourceRemServ);
}
elsif ($patternLowerCase =~ m/activity-meter/)
{
        getCDRsForRemoteServerSub("activity-meter","$DateTime_SICDR_FieldNum");
        $getCDRsForRemoteServerFlag='true';
        $ResourceRemServ='activity-meter';
        push(@pushResourceRemServ,$ResourceRemServ);
}
elsif ($patternLowerCase =~ m/spcm-rest-ws/)
{
                getCDRsForRemoteServerSub("spcm-rest-ws");
                $getCDRsForRemoteServerFlag='true';
                $ResourceRemServ='SPCM';
                push(@pushResourceRemServ,$ResourceRemServ);
}
else
{
        getCDRsForRemoteServerSub("None","$DateTime_SICDR_FieldNum");
        $getCDRsForRemoteServerFlag='true';
        push(@pushResourceRemServ,"NoFound");
}
getRemServScreenSpaces("$ResourceRemServ","54");
$Spaces01=$pushSpaces1[-1];
$Spaces02=$pushSpaces2[-1];
getRemServScreenSpaces("$pushTransactionType[-1]","38");
$Spaces03=$pushSpaces1[-1];
$Spaces04=$pushSpaces2[-1];
getRemServScreenSpaces("$pushErrorCode[-1]","28");
$Spaces05=$pushSpaces1[-1];
$Spaces06=$pushSpaces2[-1];
$GetCDRsForRemoteServerLength = length $pushGetCDRsForRemoteServer[-1];
if ($GetCDRsForRemoteServerLength <= 54 and $getCDRsForRemoteServerFlag eq "true")
{
        $GetCDRsForRemoteServer1 = $pushGetCDRsForRemoteServer[-1];
        $RemoteServerCDRLenth = length $GetCDRsForRemoteServer1;
        $Spaces11 = (54 - $RemoteServerCDRLenth);
        $GetCDRsForRemoteServer2 = "";
        $Spaces12 ='54';
        $GetCDRsForRemoteServer3 = "";
        $Spaces13 ='54';
        $GetCDRsForRemoteServer4 = "";
        $Spaces14 ='54';
        $GetCDRsForRemoteServer5 = "";
        $Spaces15 ='54';
        $GetCDRsForRemoteServer6 = "";
        $Spaces16 ='54';
}
elsif ($GetCDRsForRemoteServerLength > 54 and $GetCDRsForRemoteServerLength <= 108 and $getCDRsForRemoteServerFlag eq "true")
{
        $GetCDRsForRemoteServer1 = substr($pushGetCDRsForRemoteServer[-1],0,54);
        $Spaces11 = "0";
        $GetCDRsForRemoteServer2 = substr($pushGetCDRsForRemoteServer[-1],54,54);
        $RemoteServerCDRLenth = length $GetCDRsForRemoteServer2;
        $Spaces12 = (54 - $RemoteServerCDRLenth);
        $GetCDRsForRemoteServer3 = "";
        $Spaces13 ='54';
        $GetCDRsForRemoteServer4 = "";
        $Spaces14 ='54';
        $GetCDRsForRemoteServer5 = "";
        $Spaces15 ='54';
        $GetCDRsForRemoteServer6 = "";
        $Spaces16 ='54';

}
elsif ($GetCDRsForRemoteServerLength > 108 and $GetCDRsForRemoteServerLength <= 162 and $getCDRsForRemoteServerFlag eq "true")
{
        $GetCDRsForRemoteServer1 = substr($pushGetCDRsForRemoteServer[-1],0,54);
        $Spaces11 = "0";
        $GetCDRsForRemoteServer2 = substr($pushGetCDRsForRemoteServer[-1],54,54);
        $Spaces12 = "0";
        $GetCDRsForRemoteServer3 = substr($pushGetCDRsForRemoteServer[-1],108,54);
        $RemoteServerCDRLenth = length $GetCDRsForRemoteServer3;
        $Spaces13 = (54 - $RemoteServerCDRLenth);
        $GetCDRsForRemoteServer4 = "";
        $Spaces14 ='54';
        $GetCDRsForRemoteServer5 = "";
        $Spaces15 ='54';
        $GetCDRsForRemoteServer6 = "";
        $Spaces16 ='54';

}
elsif ($GetCDRsForRemoteServerLength > 162 and $GetCDRsForRemoteServerLength <= 216 and $getCDRsForRemoteServerFlag eq "true")
{
        $GetCDRsForRemoteServer1 = substr($pushGetCDRsForRemoteServer[-1],0,54);
        $Spaces11 = "0";
        $GetCDRsForRemoteServer2 = substr($pushGetCDRsForRemoteServer[-1],54,54);
        $Spaces12 = "0";
        $GetCDRsForRemoteServer3 = substr($pushGetCDRsForRemoteServer[-1],108,54);
        $Spaces13 = "0";
        $GetCDRsForRemoteServer4 = substr($pushGetCDRsForRemoteServer[-1],162,54);
        $RemoteServerCDRLenth = length $GetCDRsForRemoteServer4;
        $Spaces14 = (54 - $RemoteServerCDRLenth);
        $GetCDRsForRemoteServer5 = "";
        $Spaces15 ='54';
        $GetCDRsForRemoteServer6 = "";
        $Spaces16 ='54';

}
elsif ($GetCDRsForRemoteServerLength > 216 and $GetCDRsForRemoteServerLength <= 270 and $getCDRsForRemoteServerFlag eq "true")
{
        $GetCDRsForRemoteServer1 = substr($pushGetCDRsForRemoteServer[-1],0,54);
        $Spaces11 = "0";
        $GetCDRsForRemoteServer2 = substr($pushGetCDRsForRemoteServer[-1],54,54);
        $Spaces12 = "0";
        $GetCDRsForRemoteServer3 = substr($pushGetCDRsForRemoteServer[-1],108,54);
        $Spaces13 = "0";
        $GetCDRsForRemoteServer4 = substr($pushGetCDRsForRemoteServer[-1],162,54);
        $Spaces14 = "0";
        $GetCDRsForRemoteServer5 = substr($pushGetCDRsForRemoteServer[-1],216,54);
        $RemoteServerCDRLenth = length $GetCDRsForRemoteServer5;
        $Spaces15 = (54 - $RemoteServerCDRLenth);
        $GetCDRsForRemoteServer6 = "";
        $Spaces16 ='54';

}
elsif ($GetCDRsForRemoteServerLength > 270 and $GetCDRsForRemoteServerLength <= 324 and $getCDRsForRemoteServerFlag eq "true")
{
        $GetCDRsForRemoteServer1 = substr($pushGetCDRsForRemoteServer[-1],0,54);
        $Spaces11 = "0";
        $GetCDRsForRemoteServer2 = substr($pushGetCDRsForRemoteServer[-1],54,54);
        $Spaces12 = "0";
        $GetCDRsForRemoteServer3 = substr($pushGetCDRsForRemoteServer[-1],108,54);
        $Spaces13 = "0";
        $GetCDRsForRemoteServer4 = substr($pushGetCDRsForRemoteServer[-1],162,54);
        $Spaces14 = "0";
        $GetCDRsForRemoteServer5 = substr($pushGetCDRsForRemoteServer[-1],216,54);
        $Spaces15 = "0";
        $GetCDRsForRemoteServer6 = substr($pushGetCDRsForRemoteServer[-1],270,54);
        $RemoteServerCDRLenth = length $GetCDRsForRemoteServer6;
        $Spaces16 = (54 - $RemoteServerCDRLenth);

}


if ($_[0] eq "10")
{
        print "\e[0m-----------Request------------>";
}
elsif ($_[0] eq "12")
{
        print "\e[0m<----------Response------------";
}
else
{
        print "\e[0m                               ";
}
if ($_[0] eq "0"){for (0..18){print " ";}for (0..18){print "#";}}
elsif ($_[0] eq "1"){for (0..12){print " ";}for (0..5){print "#";}for (0..18){print "\e[48;5;52m \e[0m";}for (0..5){print "#";}}
elsif ($_[0] eq "2"){for (0..7){print " ";}for (0..4){print "#";}for (0..30){print "\e[48;5;52m \e[0m";}for (0..4){print "#";}}
elsif ($_[0] eq "3"){for (0..3){print " ";}for (0..3){print "#";}for (0..40){print "\e[48;5;52m \e[0m";}for (0..3){print "#";}}
elsif ($_[0] eq "4"){print " ";for (0..2){print "#";}for (0..49){print "\e[48;5;52m \e[0m";}for (0..2){print "#";}}
elsif ($_[0] eq "5"){print "#";for (0..$Spaces01){print "\e[48;5;52m \e[0m";}print "\e[48;5;52m$ResourceRemServ\e[0m";for (0..$Spaces02){print "\e[48;5;52m \e[0m";}print "#";}
elsif ($_[0] eq "6"){for (0..1){print "#";}for (0..53){print "\e[48;5;52m \e[0m";}for (0..1){print "#";}}
elsif ($_[0] eq "7"){print "#";print "\e[48;5;52m \e[0m";for (0..2){print "#";}for (0..47){print "\e[48;5;52m \e[0m";}for (0..2){print "#";}print "\e[48;5;52m \e[0m";print "#";}
elsif ($_[0] eq "8"){print "#";for (0..3){print "\e[48;5;52m \e[0m";}for (0..3){print "#";}for (0..39){print "\e[48;5;52m \e[0m";}for (0..3){print "#";}for (0..3){print "\e[48;5;52m \e[0m";}print "#";}
elsif ($_[0] eq "9"){print "#";for (0..7){print "\e[48;5;52m \e[0m";}for (0..4){print "#";}for (0..29){print "\e[48;5;52m \e[0m";}for (0..4){print "#";}for (0..7){print "\e[48;5;52m \e[0m";}print "#";}
elsif ($_[0] eq "10"){print "#";for (0..12){print "\e[48;5;52m \e[0m";}for (0..4){print "#";}for (0..19){print "\e[48;5;52m \e[0m";}for (0..4){print "#";}for (0..12){print "\e[48;5;52m \e[0m";}print "#";}
elsif ($_[0] eq "11"){print "#";for (0..17){print "\e[48;5;52m \e[0m";}for (0..19){print "#";}for (0..17){print "\e[48;5;52m \e[0m";}print "#";}
elsif ($_[0] eq "12"){print "#";print "\e[48;5;52m                          CDRs:                         \e[0m";print "#";}
elsif ($_[0] eq "13"){print "#";print "\e[48;5;52m \e[0m";print "\e[48;5;52m$GetCDRsForRemoteServer1\e[0m";for (0..$Spaces11){print "\e[48;5;52m \e[0m";}print "#";}
elsif ($_[0] eq "14"){print "#";print "\e[48;5;52m \e[0m";print "\e[48;5;52m$GetCDRsForRemoteServer2\e[0m";for (0..$Spaces12){print "\e[48;5;52m \e[0m";}print "#";}
elsif ($_[0] eq "15"){print "#";print "\e[48;5;52m \e[0m";print "\e[48;5;52m$GetCDRsForRemoteServer3\e[0m";for (0..$Spaces13){print "\e[48;5;52m \e[0m";}print "#";}
elsif ($_[0] eq "16"){print "#";print "\e[48;5;52m \e[0m";print "\e[48;5;52m$GetCDRsForRemoteServer4\e[0m";for (0..$Spaces14){print "\e[48;5;52m \e[0m";}print "#";}
elsif ($_[0] eq "17"){print "#";print "\e[48;5;52m \e[0m";print "\e[48;5;52m$GetCDRsForRemoteServer5\e[0m";for (0..$Spaces15){print "\e[48;5;52m \e[0m";}print "#";}
elsif ($_[0] eq "18"){print "#";print "\e[48;5;52m \e[0m";print "\e[48;5;52m$GetCDRsForRemoteServer6\e[0m";for (0..$Spaces16){print "\e[48;5;52m \e[0m";}print "#";}
elsif ($_[0] eq "19"){for (0..1){print "#";}for (0..53){print "\e[48;5;52m \e[0m";}for (0..1){print "#";}}
elsif ($_[0] eq "20"){for (0..1){print " ";}for (0..2){print "#";}for (0..47){print "\e[48;5;52m \e[0m";}for (0..2){print "#";}}
elsif ($_[0] eq "21"){for (0..4){print " ";}for (0..3){print "#";}for (0..$Spaces03){print "\e[48;5;52m \e[0m";}if ($pushTransactionTypeError[-1] eq "no"){print "\e[48;5;52m$pushTransactionType[-1]\e[0m";}else{print "\e[1;31;42m$pushTransactionType[-1]\e[0m";}for (0..$Spaces04){print "\e[48;5;52m \e[0m";}for (0..3){print "#";}}
elsif ($_[0] eq "22"){for (0..8){print " ";}for (0..4){print "#";}for (0..$Spaces05){print "\e[48;5;52m \e[0m";}print "\e[48;5;52m$pushErrorCode[-1]\e[0m";for (0..$Spaces06){print "\e[48;5;52m \e[0m";}for (0..4){print "#";}}
elsif ($_[0] eq "23"){for (0..13){print " ";}for (0..3){print "#";}for (0..19){print "\e[48;5;52m \e[0m";}for (0..3){print "#";}}
elsif ($_[0] eq "24"){for (0..18){print " ";}for (0..18){print "#";}}
if ($_[1] eq "brakeLine")
{
        print "\e[7;49;31m\n";
}
else
{
        print "\e[7;49;31m";
}
}

sub getCDRsForRemoteServerSub
{
$ussdsimsisdnIntOLD=$ussdsimsisdnInt;
$ussdsimsisdnInt = substr($ussdsimsisdnInt, 7);
$itIsCMGR="no";
$DateTime_SICDR_FieldNum=$_[1];
@pushTransactionType=();
@pushTransactionTypeError=();
@pushErrorCode=();
@pushGetCDRsForRemoteServer=();
$TransactionType="No CDRs Found";
push(@pushTransactionType,$TransactionType);
$TransactionTypeError="yes";
push(@pushTransactionTypeError,$TransactionTypeError);
$ErrorCode="";
push(@pushErrorCode,$ErrorCode);
$getCDRsForRemoteServer="";
push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
if ($_[0] eq "dnd" && $dnd_print_cdrs_on_remote_server eq "yes")
{
        isSessionIDinFileForDND("$ussdsimsisdnInt","$file_dnd_cdrs","$rolloverdnd_cdrs_dir","$rolloverdnd_cdrs_file_prefix","$DateTime_SICDR_FieldNum");
        if ($isSessionIDinRollOverFileFlag eq "yes")
        {
                $file_dnd_cdrs=$foundSessionIDFile;
        }
        unless (-e $file_dnd_cdrs){print color("red"),"\nCould not open DND cdrs file. It might not be configured in SI_tool.pl. Run SI_tool -h for more details\n",color("reset");exit;}
        open RemoteAppDNDCDRFile, "<$file_dnd_cdrs" or die(color("reset"), "\nCould not open DND cdrs file. $! It might not be configured in SI_tool.pl. Run SI_tool -h for more details\n\n");
        while(<RemoteAppDNDCDRFile>)
        {
                chomp;
                if($_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/80,1/ and $_ =~ m/$DateTime_SICDR_FieldNum/)
                {
                        @parseDNDCDR=split ",", $_;
                        $TransactionType="Setting ADDED";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="no";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        if ($parseDNDCDR[6] eq "BLOCKED")
                        {
                                        $ErrorCode="SettingType=BLOCKED";
                        }
                        else
                        {
                                        $ErrorCode="SettingType=ALLOWED";
                        }
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif( $_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/80,2/ and $_ =~ m/$DateTime_SICDR_FieldNum/)
                {
                        @parseDNDCDR=split ",", $_;
                        $TransactionType="Setting UPDATED";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="no";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        if ($parseDNDCDR[6] eq "BLOCKED")
                        {
                                        $ErrorCode="SettingType=BLOCKED";
                        }
                        else
                        {
                                        $ErrorCode="SettingType=ALLOWED";
                        }
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif( $_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/80,3/ and $_ =~ m/$DateTime_SICDR_FieldNum/)
                {
                        @parseDNDCDR=split ",", $_;
                        $TransactionType="Setting DELETED";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="no";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        if ($parseDNDCDR[6] eq "BLOCKED")
                        {
                                        $ErrorCode="SettingType=BLOCKED";
                        }
                        else
                        {
                                        $ErrorCode="SettingType=ALLOWED";
                        }
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif( $_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/80,4/ and $_ =~ m/$DateTime_SICDR_FieldNum/)
                {
                        @parseDNDCDR=split ",", $_;
                        $TransactionType="Setting PRUNED";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="no";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        if ($parseDNDCDR[6] eq "BLOCKED")
                        {
                                        $ErrorCode="SettingType=BLOCKED";
                        }
                        else
                        {
                                        $ErrorCode="SettingType=ALLOWED";
                        }
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
        }
        close RemoteAppDNDCDRFile;
}
elsif($_[0] eq "cmgr" && $cmgr_print_cdrs_on_remote_server eq "yes")
{
        $itIsCMGR="yes";
        isSessionIDinFileForDND("$ussdsimsisdnInt","$file_cmgr_cdrs","$rollovercmgr_cdrs_dir","$rollovercmgr_cdrs_file_prefix","0");
        if ($isSessionIDinRollOverFileFlag eq "yes")
        {
                $file_cmgr_cdrs=$foundSessionIDFile;
        }
        unless (-e $file_cmgr_cdrs){print color("red"),"\nCould not open CMGR cdrs file.  It might not be configured in SI_tool.pl. Run SI_tool -h for more details\n",color("reset");exit;}
        open RemoteAppCMGRCDRFile, "<$file_cmgr_cdrs" or die(color("reset"), "\nCould not open CMGR cdrs file. $! It might not be configured in SI_tool.pl. Run SI_tool -h for more details\n\n");
        while(<RemoteAppCMGRCDRFile>)
        {
                chomp;
                if( $_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/63,1/ )
                {
                        $TransactionType="No Offer Applicable";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="no";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="errorCode=No present";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif( $_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/63,2/ )
                {
                        $TransactionType="Offer Added";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="no";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="errorCode=0";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif( $_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/63,3/ )
                {
                        $TransactionType="Offer Accepted";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="no";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="errorCode=0";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif( $_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/63,4/ )
                {
                        $TransactionType="Offer Expired";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="yes";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="errorCode=No present";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif( $_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/63,5/ )
                {
                        $TransactionType="Offer doesnt exist";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="yes";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="errorCode=No present";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif( $_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/63,6/ )
                {
                        $TransactionType="Offer Expired";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="yes";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="errorCode=No present";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif( $_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/63,7/ )
                {
                        $TransactionType="Subscriber Daily Limit";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="yes";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="errorCode=No present";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif( $_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/63,8/ )
                {
                        $TransactionType="Subscriber Weekly Limit";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="yes";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="errorCode=No present";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif( $_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/63,9/ )
                {
                        $TransactionType="Subscriber Not in Cache";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="yes";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="errorCode=No present";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
        }
        close RemoteAppCMGRCDRFile;
}
elsif($_[0] eq "hrg" && $hrg_print_cdrs_on_remote_server eq "yes")
{
        $hrgCDRFoundhits = '0';
        isSessionIDinFile("$CDRCorrelationID","$file_hrg_cdrs","$rolloverhrg_cdrs_dir","$rolloverhrg_cdrs_file_prefix");
        if ($isSessionIDinRollOverFileFlag eq "yes")
        {
                $file_hrg_cdrs=$foundSessionIDFile;
        }
        unless (-e $file_hrg_cdrs){print color("red"),"\nCould not open HRG cdrs file.  It might not be configured in SI_tool.pl. Run SI_tool -h for more details\n",color("reset");exit;}
        open RemoteAppHRGCDRFile, "<$file_hrg_cdrs" or die(color("reset"), "\nCould not open HRG cdrs file. $! It might not be configured in SI_tool.pl. Run SI_tool -h for more details\n\n");
        while(<RemoteAppHRGCDRFile>)
        {
                chomp;
                if( $_ =~ m/$CDRCorrelationID/ and $_ =~ m/87,1/ )
                {
                        $hrgCDRFoundhits = $hrgCDRFoundhits + 1;
                        if ($hrgResourceFoundhits eq $hrgCDRFoundhits)
                        {
                                @parseHRGCDR=split ",", $_;
                                $TransactionType="Request Successful";
                                push(@pushTransactionType,$TransactionType);
                                $TransactionTypeError="no";
                                push(@pushTransactionTypeError,$TransactionTypeError);
                                $ErrorCode="ResponseCode=$parseHRGCDR[$serverResponseCode_HRGCDR_FieldNum]";
                                push(@pushErrorCode,$ErrorCode);
                                $getCDRsForRemoteServer=$_;
                                push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                        }
                }
                elsif( $_ =~ m/$CDRCorrelationID/ and $_ =~ m/87,2/ )
                {
                        $hrgCDRFoundhits = $hrgCDRFoundhits + 1;
                        if ($hrgResourceFoundhits eq $hrgCDRFoundhits)
                        {
                                @parseHRGCDR=split ",", $_;
                                $TransactionType="Failed: No Handler Matched";
                                push(@pushTransactionType,$TransactionType);
                                $TransactionTypeError="yes";
                                push(@pushTransactionTypeError,$TransactionTypeError);
                                $ErrorCode="ResponseCode=$parseHRGCDR[$serverResponseCode_HRGCDR_FieldNum]";
                                push(@pushErrorCode,$ErrorCode);
                                $getCDRsForRemoteServer=$_;
                                push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                        }
                }
                elsif( $_ =~ m/$CDRCorrelationID/ and $_ =~ m/87,3/ )
                {
                        $hrgCDRFoundhits = $hrgCDRFoundhits + 1;
                        if ($hrgResourceFoundhits eq $hrgCDRFoundhits)
                        {
                                @parseHRGCDR=split ",", $_;
                                $TransactionType="Failed: Server Error";
                                push(@pushTransactionType,$TransactionType);
                                $TransactionTypeError="yes";
                                push(@pushTransactionTypeError,$TransactionTypeError);
                                $ErrorCode="ResponseCode=$parseHRGCDR[$serverResponseCode_HRGCDR_FieldNum]";
                                push(@pushErrorCode,$ErrorCode);
                                $getCDRsForRemoteServer=$_;
                                push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                        }
                }
                elsif( $_ =~ m/$CDRCorrelationID/ and $_ =~ m/87,4/ )
                {
                        $hrgCDRFoundhits = $hrgCDRFoundhits + 1;
                        if ($hrgResourceFoundhits eq $hrgCDRFoundhits)
                        {
                                @parseHRGCDR=split ",", $_;
                                $TransactionType="Failed: Internal Error";
                                push(@pushTransactionType,$TransactionType);
                                $TransactionTypeError="yes";
                                push(@pushTransactionTypeError,$TransactionTypeError);
                                $ErrorCode="ResponseCode=$parseHRGCDR[$serverResponseCode_HRGCDR_FieldNum]";
                                push(@pushErrorCode,$ErrorCode);
                                $getCDRsForRemoteServer=$_;
                                push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                        }
                }
        }
        close RemoteAppHRGCDRFile;
}
elsif($_[0] eq "sibb" && $sibb_print_cdrs_on_remote_server eq "yes" )
{
        isSessionIDinFile("$CDRCorrelationID","$file_sibb_cdrs","$rolloversibb_cdrs_dir","$rolloversibb_cdrs_file_prefix");
        if ($isSessionIDinRollOverFileFlag eq "yes")
        {
                $file_sibb_cdrs=$foundSessionIDFile;
        }
        unless (-e $file_sibb_cdrs){print color("red"),"\nCould not open SIBB cdrs file.  It might not be configured in SI_tool.pl. Run SI_tool -h for more details\n",color("reset");exit;}
        open RemoteAppSIBBCDRFile, "<$file_sibb_cdrs" or die(color("reset"), "\nCould not open SIBB cdrs file. $! It might not be configured in SI_tool.pl. Run SI_tool -h for more details\n\n");
        while(<RemoteAppSIBBCDRFile>)
        {
                chomp;
                if( $_ =~ m/$CDRCorrelationID/ and $_ =~ m/Operation  OK/ )
                {
                        @parseSIBBCDR=split ",", $_;
                        $TransactionType="$parseSIBBCDR[$serverResponseOperation_SIBBCDR_FieldNum]";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="no";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="errorCode = $parseSIBBCDR[$ErrorCode_SIBBCDR_FieldNum]";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif( $_ =~ m/$CDRCorrelationID/ and $_ =~ m/Error from OCS/ )
                {
                        @parseSIBBCDR=split ",", $_;
                        $TransactionType="$parseSIBBCDR[$serverResponseOperation_SIBBCDR_FieldNum]";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="yes";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="errorCode = $parseSIBBCDR[$ErrorCode_SIBBCDR_FieldNum]";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif( $_ =~ m/$CDRCorrelationID/ and $_ =~ m/HRG/ and $_ =~ m/Error/ )
                {
                        @parseSIBBCDR=split ",", $_;
                        $TransactionType="HRG Error";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="yes";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="errorCode = $parseSIBBCDR[$ErrorCode_SIBBCDR_FieldNum]";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                else
                {
                        @parseSIBBCDR=split ",", $_;
                        $TransactionType="Operation Error";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="yes";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="errorCode = $parseSIBBCDR[$ErrorCode_SIBBCDR_FieldNum]";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
        }
        close RemoteAppSIBBCDRFile;
}
elsif($_[0] eq "activity-meter")
{
        $msisdnForAM0 = substr($ussdsimsisdnInt, -1, 1);
        $msisdnForAM1 = substr($ussdsimsisdnInt, -3, 1);
        $msisdnForAM2 = substr($ussdsimsisdnInt, -5, 1);
        $msisdnForAM3 = substr($ussdsimsisdnInt, -7, 1);
        $msisdnForAM4 = substr($ussdsimsisdnInt, -9, 1);
        $msisdnForAM5 = substr($ussdsimsisdnInt, -11, 1);
        $msisdnForAM = "$msisdnForAM5"."$msisdnForAM4"."$msisdnForAM3"."$msisdnForAM2"."$msisdnForAM1"."$msisdnForAM0";

        isSessionIDinFileForAM("$msisdnForAM","$file_am_cdrs","$rolloveram_cdrs_dir","$rolloveram_cdrs_file_prefix","$DateTime_AMCDR_FieldNum");
        if ($isSessionIDinRollOverFileFlag eq "yes")
        {
                $file_am_cdrs=$foundSessionIDFile;
        }
        unless (-e $file_am_cdrs){print color("red"),"\nCould not open Activity-Meter cdrs file. It might not be configured in SI_tool.pl. Run SI_tool -h for more details\n",color("reset");exit;}
        open RemoteAppAMCDRFile, "<$file_am_cdrs" or die(color("reset"), "\nCould not open Activity-Meter cdrs file. $! It might not be configured in SI_tool.pl. Run SI_tool -h for more details\n\n");
        while(<RemoteAppAMCDRFile>)
        {
                chomp;
                if($_ =~ m/$msisdnForAM/ and $_ =~ m/$DateTime_AMCDR_FieldNum/)
                {
                        $TransactionType="value:0";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="no";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="MSISDN Created in Database";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
        }
        close RemoteAppAMCDRFile;
}
elsif($_[0] eq "spcm-rest-ws" && $spcm_print_cdrs_on_remote_server eq "yes" )
{
        if($scp_CDRs_done eq "noYet")
        {
                $scp_CDRs_done = "already";
                scp_CDRs("$file_spcm_cdrs","$rolloverspcm_cdrs_dir","$rolloverspcm_cdrs_file_prefix","$spcm_list_machines");
                if($scpCDRsFlag eq "yes")
                {
                        $scp_CDRs_spcm='yes';
                }
                else
                {
                        $scp_CDRs_spcm='no';
                }
        }
        $old_ussdsimsisdnInt=$ussdsimsisdnInt;
        $ussdsimsisdnInt =~ s/0003100/0004100/g;
        isSessionIDinFileForSPCM("$ussdsimsisdnInt","$file_spcm_cdrs","$rolloverspcm_cdrs_dir","$rolloverspcm_cdrs_file_prefix","$DateTime_SPCMCDR_FieldNum");
        if ($isSessionIDinRollOverFileFlag eq "yes")
        {
                $file_spcm_cdrs=$foundSessionIDFile;
        }
        else
        {
                $file_spcm_cdrs="$SIsimScriptDir/scpCDRs/.dummyfile";
        }
        unless (-e $file_spcm_cdrs){print color("red"),"\nCould not open SPCM cdrs file. It might not be configured in SI_tool.pl. Run SI_tool -h for more details\n",color("reset");exit;}
        open RemoteAppSPCMCDRFile, "<$file_spcm_cdrs" or die(color("reset"), "\nCould not open SPCM cdrs file. $! It might not be configured in SI_tool.pl. Run SI_tool -h for more details\n\n");
        while(<RemoteAppSPCMCDRFile>)
        {
                chomp;
                if($_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/39,0/)
                {
                        @parseSPCMCDR=split ",", $_;
                        $TransactionType="Plan purchased";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="no";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="Plan=$parseSPCMCDR[$planName_SPCMCDR_FieldNum]";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif($_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/39,1/)
                {
                        @parseSPCMCDR=split ",", $_;
                        $TransactionType="Plan purchase failure";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="no";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="Plan=$parseSPCMCDR[$planName_SPCMCDR_FieldNum]";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif($_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/39,2/)
                {
                        @parseSPCMCDR=split ",", $_;
                        $TransactionType="Plan activation";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="no";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="Plan=$parseSPCMCDR[$planName_SPCMCDR_FieldNum]";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif($_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/39,3/)
                {
                        @parseSPCMCDR=split ",", $_;
                        $TransactionType="Plan deativation";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="no";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="Plan=$parseSPCMCDR[$planName_SPCMCDR_FieldNum]";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif($_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/39,4/)
                {
                        @parseSPCMCDR=split ",", $_;
                        $TransactionType="Usage consumed";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="no";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="Plan=$parseSPCMCDR[$planName_SPCMCDR_FieldNum]";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif($_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/39,5/)
                {
                        @parseSPCMCDR=split ",", $_;
                        $TransactionType="Plan expiry";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="no";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="Plan=$parseSPCMCDR[$planName_SPCMCDR_FieldNum]";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif($_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/39,6/)
                {
                        @parseSPCMCDR=split ",", $_;
                        $TransactionType="Plan cancellation";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="no";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="Plan=$parseSPCMCDR[$planName_SPCMCDR_FieldNum]";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif($_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/39,7/)
                {
                        @parseSPCMCDR=split ",", $_;
                        $TransactionType="Plan provisioning failure";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="no";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="Plan=$parseSPCMCDR[$planName_SPCMCDR_FieldNum]";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif($_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/39,8/)
                {
                        @parseSPCMCDR=split ",", $_;
                        $TransactionType="Plan termination";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="no";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="Plan=$parseSPCMCDR[$planName_SPCMCDR_FieldNum]";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif($_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/39,9/)
                {
                        @parseSPCMCDR=split ",", $_;
                        $TransactionType="Plan volume top up";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="no";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="Plan=$parseSPCMCDR[$planName_SPCMCDR_FieldNum]";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif($_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/39,10/)
                {
                        @parseSPCMCDR=split ",", $_;
                        $TransactionType="Plan validity period top up";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="no";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="Plan=$parseSPCMCDR[$planName_SPCMCDR_FieldNum]";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif($_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/39,11/)
                {
                        @parseSPCMCDR=split ",", $_;
                        $TransactionType="Plan top up time";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="no";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="Plan=$parseSPCMCDR[$planName_SPCMCDR_FieldNum]";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif($_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/39,12/)
                {
                        @parseSPCMCDR=split ",", $_;
                        $TransactionType="Usage available";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="no";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="Plan=$parseSPCMCDR[$planName_SPCMCDR_FieldNum]";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif($_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/39,13/)
                {
                        @parseSPCMCDR=split ",", $_;
                        $TransactionType="Plan renewal parked";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="no";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="Plan=$parseSPCMCDR[$planName_SPCMCDR_FieldNum]";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif($_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/39,14/)
                {
                        @parseSPCMCDR=split ",", $_;
                        $TransactionType="Plan refunded";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="no";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="Plan=$parseSPCMCDR[$planName_SPCMCDR_FieldNum]";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif($_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/39,15/)
                {
                        @parseSPCMCDR=split ",", $_;
                        $TransactionType="Plan refund deferred";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="no";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="Plan=$parseSPCMCDR[$planName_SPCMCDR_FieldNum]";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif($_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/39,16/)
                {
                        @parseSPCMCDR=split ",", $_;
                        $TransactionType="Not in use";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="no";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="Plan=$parseSPCMCDR[$planName_SPCMCDR_FieldNum]";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif($_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/39,17/)
                {
                        @parseSPCMCDR=split ",", $_;
                        $TransactionType="Activation Pending Timeout";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="no";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="Plan=$parseSPCMCDR[$planName_SPCMCDR_FieldNum]";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif($_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/39,18/)
                {
                        @parseSPCMCDR=split ",", $_;
                        $TransactionType="Plan Validity Carried Forward";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="no";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="Plan=$parseSPCMCDR[$planName_SPCMCDR_FieldNum]";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif($_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/39,19/)
                {
                        @parseSPCMCDR=split ",", $_;
                        $TransactionType="Plan Volume has been boosted";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="no";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="Plan=$parseSPCMCDR[$planName_SPCMCDR_FieldNum]";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif($_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/39,20/)
                {
                        @parseSPCMCDR=split ",", $_;
                        $TransactionType="Plan Validity has been boosted";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="no";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="Plan=$parseSPCMCDR[$planName_SPCMCDR_FieldNum]";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif($_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/39,21/)
                {
                        @parseSPCMCDR=split ",", $_;
                        $TransactionType="Failure to charge for plan booster";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="no";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="Plan=$parseSPCMCDR[$planName_SPCMCDR_FieldNum]";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
                elsif($_ =~ m/$ussdsimsisdnInt/ and $_ =~ m/39,22/)
                {
                        @parseSPCMCDR=split ",", $_;
                        $TransactionType="Booster charged successfully";
                        push(@pushTransactionType,$TransactionType);
                        $TransactionTypeError="no";
                        push(@pushTransactionTypeError,$TransactionTypeError);
                        $ErrorCode="Plan=$parseSPCMCDR[$planName_SPCMCDR_FieldNum]";
                        push(@pushErrorCode,$ErrorCode);
                        $getCDRsForRemoteServer=$_;
                        push(@pushGetCDRsForRemoteServer,$getCDRsForRemoteServer);
                }
        }
        close RemoteAppSPCMCDRFile;
        $ussdsimsisdnInt=$old_ussdsimsisdnInt;
}

$ussdsimsisdnInt=$ussdsimsisdnIntOLD;

}

sub getRemServScreenSpaces
{
        $RemoteServerLenth = length $_[0];
        $RemoteServerLenthEven = $RemoteServerLenth % 2;
        if ($RemoteServerLenthEven eq "0")
        {
                $getSpaces1 = ($_[1] - $RemoteServerLenth) / 2;
                $getSpaces2 = $getSpaces1;
        }
        else
        {
                $getSpaces1 = ($_[1] + 1 - $RemoteServerLenth) / 2;
                $getSpaces2 = $getSpaces1 - 1;
        }
        @pushSpaces1=();
        @pushSpaces2=();
        push (@pushSpaces1,$getSpaces1);
        push (@pushSpaces2,$getSpaces2);
}

sub addHistory
{
        open(my $HISTORYFILE, '>>', "$SIsimScriptDir/.SI_tool_history");
        print $HISTORYFILE "$_[0]\n";
        close $HISTORYFILE;
}

sub getConfigs
{
        use FindBin '$Bin';
        $SIsimScriptDir = $Bin."/";
        open SI_tool_cfgFile, "<$SIsimScriptDir/SI_tool.cfg" or die(color("reset"), "\nCould not open $SIsimScriptDir/SI_tool.cfg. $!\n\n");
        while(<SI_tool_cfgFile>)
        {
                chomp;
                if( $_ =~ m/logoutTime/ )
                {
                        $_=~ s/\s//g;
                        @logoutTimeHashArray = split('#',$_);
                        @logoutTimeArray = split('=',$logoutTimeHashArray[0]);
                        $logoutTime = $logoutTimeArray[1];
                }
                elsif( $_ =~ m/SE_httpServer_Configured_Ok/ )
                {
                        $_=~ s/\s//g;
                        @SE_httpServer_Configured_OkHashArray = split('#',$_);
                        @SE_httpServer_Configured_OkArray = split('=',$SE_httpServer_Configured_OkHashArray[0]);
                        $SE_httpServer_Configured_Ok = $SE_httpServer_Configured_OkArray[1];
                }
                elsif( $_ =~ m/testmsisdn/ )
                {
                        $_=~ s/\s//g;
                        @testmsisdnHashArray = split('#',$_);
                        @testmsisdnArray = split('=',$testmsisdnHashArray[0]);
                        $testmsisdn = $testmsisdnArray[1];
                }
                elsif( $_ =~ m/HTTP_REST_API_WS/  )
                {
                        unless ( defined( $opt_a ) )
                        {
                                $_=~ s/\s//g;
                                @HTTP_REST_API_WSHashArray = split('#',$_);
                                @HTTP_REST_API_WSArray = split('=',$HTTP_REST_API_WSHashArray[0]);
                                $HTTP_REST_API_WS = $HTTP_REST_API_WSArray[1];
                        }
                }
                elsif( $_ =~ m/serviceCodeDefault/  )
                {
                        unless ( defined( $opt_j ) )
                        {
                                $_=~ s/\s//g;
                                @serviceCodeDefaultHashArray = split('#',$_);
                                @serviceCodeDefaultArray = split('=',$serviceCodeDefaultHashArray[0]);
                                $serviceCodeDefault = $serviceCodeDefaultArray[1];
                        }
                }
                elsif( $_ =~ m/USSD_SI_Version/ )
                {
                        $_=~ s/\s//g;
                        @USSD_SI_VersionHashArray = split('#',$_);
                        @USSD_SI_VersionArray = split('=',$USSD_SI_VersionHashArray[0]);
                        $USSD_SI_Version = $USSD_SI_VersionArray[1];
                }
                elsif( $_ =~ m/USSD_SI_port/ )
                {
                        $_=~ s/\s//g;
                        @USSD_SI_portHashArray = split('#',$_);
                        @USSD_SI_portArray = split('=',$USSD_SI_portHashArray[0]);
                        $USSD_SI_port = $USSD_SI_portArray[1];
                }
                elsif( $_ =~ m/sibbPort/ )
                {
                        $_=~ s/\s//g;
                        @sibbPortHashArray = split('#',$_);
                        @sibbPortArray = split('=',$sibbPortHashArray[0]);
                        $sibbPort = $sibbPortArray[1];
                }
                elsif( $_ =~ m/SI_Http_port/ )
                {
                        $_=~ s/\s//g;
                        @SI_Http_portHashArray = split('#',$_);
                        @SI_Http_portArray = split('=',$SI_Http_portHashArray[0]);
                        $SI_Http_port = $SI_Http_portArray[1];
                }
                elsif( $_ =~ m/SI_Http_instance/ )
                {
                        $_=~ s/\s//g;
                        @SI_Http_instanceHashArray = split('#',$_);
                        @SI_Http_instanceArray = split('=',$SI_Http_instanceHashArray[0]);
                        $SI_Http_instance = $SI_Http_instanceArray[1];
                }
                elsif( $_ =~ m/SEhttpServercfgFile/ )
                {
                        $_=~ s/\s//g;
                        @SEhttpServercfgFileHashArray = split('#',$_);
                        @SEhttpServercfgFileArray = split('=',$SEhttpServercfgFileHashArray[0]);
                        $SEhttpServercfgFile = $SEhttpServercfgFileArray[1];
                }
                elsif( $_ =~ m/USSD_SI_mainFile/ )
                {
                        $_=~ s/\s//g;
                        @USSD_SI_mainFileHashArray = split('#',$_);
                        @USSD_SI_mainFileArray = split('=',$USSD_SI_mainFileHashArray[0]);
                        $USSD_SI_mainFile = $USSD_SI_mainFileArray[1];
                }
                elsif( $_ =~ m/USSD_servicesFile/ )
                {
                        $_=~ s/\s//g;
                        @USSD_servicesFileHashArray = split('#',$_);
                        @USSD_servicesFileArray = split('=',$USSD_servicesFileHashArray[0]);
                        $USSD_servicesFile = $USSD_servicesFileArray[1];
                }
                elsif( $_ =~ m/USSD_scriptsFile/ )
                {
                        $_=~ s/\s//g;
                        @USSD_scriptsFileHashArray = split('#',$_);
                        @USSD_scriptsFileArray = split('=',$USSD_scriptsFileHashArray[0]);
                        $USSD_scriptsFile = $USSD_scriptsFileArray[1];
                }
                elsif( $_ =~ m/ussd_si_sd_servicesDir/ )
                {
                        $_=~ s/\s//g;
                        @ussd_si_sd_servicesDirHashArray = split('#',$_);
                        @ussd_si_sd_servicesDirArray = split('=',$ussd_si_sd_servicesDirHashArray[0]);
                        $ussd_si_sd_servicesDir = $ussd_si_sd_servicesDirArray[1];
                }
                elsif( $_ =~ m/active_ussd_si_cdrs/ )
                {
                        $_=~ s/\s//g;
                        @active_ussd_si_cdrsHashArray = split('#',$_);
                        @active_ussd_si_cdrsArray = split('=',$active_ussd_si_cdrsHashArray[0]);
                        $active_ussd_si_cdrs = $active_ussd_si_cdrsArray[1];
                }
                elsif( $_ =~ m/rollover_ussd_si_cdrs_dir/ )
                {
                        $_=~ s/\s//g;
                        @rollover_ussd_si_cdrs_dirHashArray = split('#',$_);
                        @rollover_ussd_si_cdrs_dirArray = split('=',$rollover_ussd_si_cdrs_dirHashArray[0]);
                        $rollover_ussd_si_cdrs_dir = $rollover_ussd_si_cdrs_dirArray[1];
                }
                elsif( $_ =~ m/rollover_ussd_si_cdrs_file_prefix/ )
                {
                        $_=~ s/\s//g;
                        @rollover_ussd_si_cdrs_file_prefixHashArray = split('#',$_);
                        @rollover_ussd_si_cdrs_file_prefixArray = split('=',$rollover_ussd_si_cdrs_file_prefixHashArray[0]);
                        $rollover_ussd_si_cdrs_file_prefix = $rollover_ussd_si_cdrs_file_prefixArray[1];
                }
                elsif( $_ =~ m/cmgr_print_cdrs_on_remote_server/ )
                {
                        $_=~ s/\s//g;
                        @cmgr_print_cdrs_on_remote_serverHashArray = split('#',$_);
                        @cmgr_print_cdrs_on_remote_serverArray = split('=',$cmgr_print_cdrs_on_remote_serverHashArray[0]);
                        $cmgr_print_cdrs_on_remote_server = $cmgr_print_cdrs_on_remote_serverArray[1];
                }
                elsif( $_ =~ m/file_cmgr_cdrs/ )
                {
                        $_=~ s/\s//g;
                        @file_cmgr_cdrsHashArray = split('#',$_);
                        @file_cmgr_cdrsArray = split('=',$file_cmgr_cdrsHashArray[0]);
                        $file_cmgr_cdrs = $file_cmgr_cdrsArray[1];
                }
                elsif( $_ =~ m/rollovercmgr_cdrs_dir/ )
                {
                        $_=~ s/\s//g;
                        @rollovercmgr_cdrs_dirHashArray = split('#',$_);
                        @rollovercmgr_cdrs_dirArray = split('=',$rollovercmgr_cdrs_dirHashArray[0]);
                        $rollovercmgr_cdrs_dir = $rollovercmgr_cdrs_dirArray[1];
                }
                elsif( $_ =~ m/rollovercmgr_cdrs_file_prefix/ )
                {
                        $_=~ s/\s//g;
                        @rollovercmgr_cdrs_file_prefixHashArray = split('#',$_);
                        @rollovercmgr_cdrs_file_prefixArray = split('=',$rollovercmgr_cdrs_file_prefixHashArray[0]);
                        $rollovercmgr_cdrs_file_prefix = $rollovercmgr_cdrs_file_prefixArray[1];
                }
                elsif( $_ =~ m/dnd_print_cdrs_on_remote_server/ )
                {
                        $_=~ s/\s//g;
                        @dnd_print_cdrs_on_remote_serverHashArray = split('#',$_);
                        @dnd_print_cdrs_on_remote_serverArray = split('=',$dnd_print_cdrs_on_remote_serverHashArray[0]);
                        $dnd_print_cdrs_on_remote_server = $dnd_print_cdrs_on_remote_serverArray[1];
                }
                elsif( $_ =~ m/file_dnd_cdrs/ )
                {
                        $_=~ s/\s//g;
                        @file_dnd_cdrsHashArray = split('#',$_);
                        @file_dnd_cdrsArray = split('=',$file_dnd_cdrsHashArray[0]);
                        $file_dnd_cdrs = $file_dnd_cdrsArray[1];
                }
                elsif( $_ =~ m/rolloverdnd_cdrs_dir/ )
                {
                        $_=~ s/\s//g;
                        @rolloverdnd_cdrs_dirHashArray = split('#',$_);
                        @rolloverdnd_cdrs_dirArray = split('=',$rolloverdnd_cdrs_dirHashArray[0]);
                        $rolloverdnd_cdrs_dir = $rolloverdnd_cdrs_dirArray[1];
                }
                elsif( $_ =~ m/rolloverdnd_cdrs_file_prefix/ )
                {
                        $_=~ s/\s//g;
                        @rolloverdnd_cdrs_file_prefixHashArray = split('#',$_);
                        @rolloverdnd_cdrs_file_prefixArray = split('=',$rolloverdnd_cdrs_file_prefixHashArray[0]);
                        $rolloverdnd_cdrs_file_prefix = $rolloverdnd_cdrs_file_prefixArray[1];
                }
                elsif( $_ =~ m/am_print_cdrs_on_remote_server/ )
                {
                        $_=~ s/\s//g;
                        @am_print_cdrs_on_remote_serverHashArray = split('#',$_);
                        @am_print_cdrs_on_remote_serverArray = split('=',$am_print_cdrs_on_remote_serverHashArray[0]);
                        $am_print_cdrs_on_remote_server = $am_print_cdrs_on_remote_serverArray[1];
                }
                elsif( $_ =~ m/file_am_cdrs/ )
                {
                        $_=~ s/\s//g;
                        @file_am_cdrsHashArray = split('#',$_);
                        @file_am_cdrsArray = split('=',$file_am_cdrsHashArray[0]);
                        $file_am_cdrs = $file_am_cdrsArray[1];
                }
                elsif( $_ =~ m/rolloveram_cdrs_dir/ )
                {
                        $_=~ s/\s//g;
                        @rolloveram_cdrs_dirHashArray = split('#',$_);
                        @rolloveram_cdrs_dirArray = split('=',$rolloveram_cdrs_dirHashArray[0]);
                        $rolloveram_cdrs_dir = $rolloveram_cdrs_dirArray[1];
                }
                elsif( $_ =~ m/rolloveram_cdrs_file_prefix/ )
                {
                        $_=~ s/\s//g;
                        @rolloveram_cdrs_file_prefixHashArray = split('#',$_);
                        @rolloveram_cdrs_file_prefixArray = split('=',$rolloveram_cdrs_file_prefixHashArray[0]);
                        $rolloveram_cdrs_file_prefix = $rolloveram_cdrs_file_prefixArray[1];
                }
                elsif( $_ =~ m/spcm_print_cdrs_on_remote_server/ )
                {
                        $_=~ s/\s//g;
                        @spcm_print_cdrs_on_remote_serverHashArray = split('#',$_);
                        @spcm_print_cdrs_on_remote_serverArray = split('=',$spcm_print_cdrs_on_remote_serverHashArray[0]);
                        $spcm_print_cdrs_on_remote_server = $spcm_print_cdrs_on_remote_serverArray[1];
                }
                elsif( $_ =~ m/spcm_list_machines/ )
                {
                        $_=~ s/\s//g;
                        @spcm_list_machinesHashArray = split('#',$_);
                        @spcm_list_machinesArray = split('=',$spcm_list_machinesHashArray[0]);
                        $spcm_list_machines = $spcm_list_machinesArray[1];
                }
                elsif( $_ =~ m/file_spcm_cdrs/ )
                {
                        $_=~ s/\s//g;
                        @file_spcm_cdrsHashArray = split('#',$_);
                        @file_spcm_cdrsArray = split('=',$file_spcm_cdrsHashArray[0]);
                        $file_spcm_cdrs = $file_spcm_cdrsArray[1];
                }
                elsif( $_ =~ m/rolloverspcm_cdrs_dir/ )
                {
                        $_=~ s/\s//g;
                        @rolloverspcm_cdrs_dirHashArray = split('#',$_);
                        @rolloverspcm_cdrs_dirArray = split('=',$rolloverspcm_cdrs_dirHashArray[0]);
                        $rolloverspcm_cdrs_dir = $rolloverspcm_cdrs_dirArray[1];
                }
                elsif( $_ =~ m/rolloverspcm_cdrs_file_prefix/ )
                {
                        $_=~ s/\s//g;
                        @rolloverspcm_cdrs_file_prefixHashArray = split('#',$_);
                        @rolloverspcm_cdrs_file_prefixArray = split('=',$rolloverspcm_cdrs_file_prefixHashArray[0]);
                        $rolloverspcm_cdrs_file_prefix = $rolloverspcm_cdrs_file_prefixArray[1];
                }
                elsif( $_ =~ m/planName_SPCMCDR_FieldNum/ )
                {
                        $_=~ s/\s//g;
                        @planName_SPCMCDR_FieldNumHashArray = split('#',$_);
                        @planName_SPCMCDR_FieldNumArray = split('=',$planName_SPCMCDR_FieldNumHashArray[0]);
                        $planName_SPCMCDR_FieldNum = $planName_SPCMCDR_FieldNumArray[1];
                }
                elsif( $_ =~ m/hrg_print_cdrs_on_remote_server/ )
                {
                        $_=~ s/\s//g;
                        @hrg_print_cdrs_on_remote_serverHashArray = split('#',$_);
                        @hrg_print_cdrs_on_remote_serverArray = split('=',$hrg_print_cdrs_on_remote_serverHashArray[0]);
                        $hrg_print_cdrs_on_remote_server = $hrg_print_cdrs_on_remote_serverArray[1];
                }
                elsif( $_ =~ m/file_hrg_cdrs/ )
                {
                        $_=~ s/\s//g;
                        @file_hrg_cdrsHashArray = split('#',$_);
                        @file_hrg_cdrsArray = split('=',$file_hrg_cdrsHashArray[0]);
                        $file_hrg_cdrs = $file_hrg_cdrsArray[1];
                }
                elsif( $_ =~ m/rolloverhrg_cdrs_dir/ )
                {
                        $_=~ s/\s//g;
                        @rolloverhrg_cdrs_dirHashArray = split('#',$_);
                        @rolloverhrg_cdrs_dirArray = split('=',$rolloverhrg_cdrs_dirHashArray[0]);
                        $rolloverhrg_cdrs_dir = $rolloverhrg_cdrs_dirArray[1];
                }
                elsif( $_ =~ m/rolloverhrg_cdrs_file_prefix/ )
                {
                        $_=~ s/\s//g;
                        @rolloverhrg_cdrs_file_prefixHashArray = split('#',$_);
                        @rolloverhrg_cdrs_file_prefixArray = split('=',$rolloverhrg_cdrs_file_prefixHashArray[0]);
                        $rolloverhrg_cdrs_file_prefix = $rolloverhrg_cdrs_file_prefixArray[1];
                }
                elsif( $_ =~ m/sibb_print_cdrs_on_remote_server/ )
                {
                        $_=~ s/\s//g;
                        @sibb_print_cdrs_on_remote_serverHashArray = split('#',$_);
                        @sibb_print_cdrs_on_remote_serverArray = split('=',$sibb_print_cdrs_on_remote_serverHashArray[0]);
                        $sibb_print_cdrs_on_remote_server = $sibb_print_cdrs_on_remote_serverArray[1];
                }
                elsif( $_ =~ m/file_sibb_cdrs/ )
                {
                        $_=~ s/\s//g;
                        @file_sibb_cdrsHashArray = split('#',$_);
                        @file_sibb_cdrsArray = split('=',$file_sibb_cdrsHashArray[0]);
                        $file_sibb_cdrs = $file_sibb_cdrsArray[1];
                }
                elsif( $_ =~ m/rolloversibb_cdrs_dir/ )
                {
                        $_=~ s/\s//g;
                        @rolloversibb_cdrs_dirHashArray = split('#',$_);
                        @rolloversibb_cdrs_dirArray = split('=',$rolloversibb_cdrs_dirHashArray[0]);
                        $rolloversibb_cdrs_dir = $rolloversibb_cdrs_dirArray[1];
                }
                elsif( $_ =~ m/rolloversibb_cdrs_file_prefix/ )
                {
                        $_=~ s/\s//g;
                        @rolloversibb_cdrs_file_prefixHashArray = split('#',$_);
                        @rolloversibb_cdrs_file_prefixArray = split('=',$rolloversibb_cdrs_file_prefixHashArray[0]);
                        $rolloversibb_cdrs_file_prefix = $rolloversibb_cdrs_file_prefixArray[1];
                }
                elsif( $_ =~ m/Date_SICDR_FieldNum/ )
                {
                        $_=~ s/\s//g;
                        @Date_SICDR_FieldNumHashArray = split('#',$_);
                        @Date_SICDR_FieldNumArray = split('=',$Date_SICDR_FieldNumHashArray[0]);
                        $Date_SICDR_FieldNum = $Date_SICDR_FieldNumArray[1];
                }
                elsif( $_ =~ m/Time_SICDR_FieldNum/ )
                {
                        $_=~ s/\s//g;
                        @Time_SICDR_FieldNumHashArray = split('#',$_);
                        @Time_SICDR_FieldNumArray = split('=',$Time_SICDR_FieldNumHashArray[0]);
                        $Time_SICDR_FieldNum = $Time_SICDR_FieldNumArray[1];
                }
                elsif( $_ =~ m/CorrellationID_SICDR_FieldNum/ )
                {
                        $_=~ s/\s//g;
                        @CorrellationID_SICDR_FieldNumHashArray = split('#',$_);
                        @CorrellationID_SICDR_FieldNumArray = split('=',$CorrellationID_SICDR_FieldNumHashArray[0]);
                        $CorrellationID_SICDR_FieldNum = $CorrellationID_SICDR_FieldNumArray[1];
                }
                elsif( $_ =~ m/OperCodeType_SICDR_FieldNum/ )
                {
                        $_=~ s/\s//g;
                        @OperCodeType_SICDR_FieldNumHashArray = split('#',$_);
                        @OperCodeType_SICDR_FieldNumArray = split('=',$OperCodeType_SICDR_FieldNumHashArray[0]);
                        $OperCodeType_SICDR_FieldNum = $OperCodeType_SICDR_FieldNumArray[1];
                }
                elsif( $_ =~ m/RawErrorCode_SICDR_FieldNum/ )
                {
                        $_=~ s/\s//g;
                        @RawErrorCode_SICDR_FieldNumHashArray = split('#',$_);
                        @RawErrorCode_SICDR_FieldNumArray = split('=',$RawErrorCode_SICDR_FieldNumHashArray[0]);
                        $RawErrorCode_SICDR_FieldNum = $RawErrorCode_SICDR_FieldNumArray[1];
                }
                elsif( $_ =~ m/RawErrorCodeType_SICDR_FieldNum/ )
                {
                        $_=~ s/\s//g;
                        @RawErrorCodeType_SICDR_FieldNumHashArray = split('#',$_);
                        @RawErrorCodeType_SICDR_FieldNumArray = split('=',$RawErrorCodeType_SICDR_FieldNumHashArray[0]);
                        $RawErrorCodeType_SICDR_FieldNum = $RawErrorCodeType_SICDR_FieldNumArray[1];
                }
                elsif( $_ =~ m/CauseofTermination_SICDR_FieldNum/ )
                {
                        $_=~ s/\s//g;
                        @CauseofTermination_SICDR_FieldNumHashArray = split('#',$_);
                        @CauseofTermination_SICDR_FieldNumArray = split('=',$CauseofTermination_SICDR_FieldNumHashArray[0]);
                        $CauseofTermination_SICDR_FieldNum = $CauseofTermination_SICDR_FieldNumArray[1];
                }
                elsif( $_ =~ m/UR_SequenceNumber_SICDR_FieldNum/ )
                {
                        $_=~ s/\s//g;
                        @UR_SequenceNumber_SICDR_FieldNumHashArray = split('#',$_);
                        @UR_SequenceNumber_SICDR_FieldNumArray = split('=',$UR_SequenceNumber_SICDR_FieldNumHashArray[0]);
                        $UR_SequenceNumber_SICDR_FieldNum = $UR_SequenceNumber_SICDR_FieldNumArray[1];
                }
                elsif( $_ =~ m/UR_REQUESTcontent_SICDR_FieldNum/ )
                {
                        $_=~ s/\s//g;
                        @UR_REQUESTcontent_SICDR_FieldNumHashArray = split('#',$_);
                        @UR_REQUESTcontent_SICDR_FieldNumArray = split('=',$UR_REQUESTcontent_SICDR_FieldNumHashArray[0]);
                        $UR_REQUESTcontent_SICDR_FieldNum = $UR_REQUESTcontent_SICDR_FieldNumArray[1];
                }
                elsif( $_ =~ m/UR_RESPONSEcontent_SICDR_FieldNum/ )
                {
                        $_=~ s/\s//g;
                        @UR_RESPONSEcontent_SICDR_FieldNumHashArray = split('#',$_);
                        @UR_RESPONSEcontent_SICDR_FieldNumArray = split('=',$UR_RESPONSEcontent_SICDR_FieldNumHashArray[0]);
                        $UR_RESPONSEcontent_SICDR_FieldNum = $UR_RESPONSEcontent_SICDR_FieldNumArray[1];
                }
                elsif( $_ =~ m/serverResponseCode_HRGCDR_FieldNum/ )
                {
                        $_=~ s/\s//g;
                        @serverResponseCode_HRGCDR_FieldNumHashArray = split('#',$_);
                        @serverResponseCode_HRGCDR_FieldNumArray = split('=',$serverResponseCode_HRGCDR_FieldNumHashArray[0]);
                        $serverResponseCode_HRGCDR_FieldNum = $serverResponseCode_HRGCDR_FieldNumArray[1];
                }
                elsif( $_ =~ m/context_HRGCDR_FieldNum/ )
                {
                        $_=~ s/\s//g;
                        @context_HRGCDR_FieldNumHashArray = split('#',$_);
                        @context_HRGCDR_FieldNumArray = split('=',$context_HRGCDR_FieldNumHashArray[0]);
                        $context_HRGCDR_FieldNum = $context_HRGCDR_FieldNumArray[1];
                }
                elsif( $_ =~ m/ErrorCode_SIBBCDR_FieldNum/ )
                {
                        $_=~ s/\s//g;
                        @ErrorCode_SIBBCDR_FieldNumHashArray = split('#',$_);
                        @ErrorCode_SIBBCDR_FieldNumArray = split('=',$ErrorCode_SIBBCDR_FieldNumHashArray[0]);
                        $ErrorCode_SIBBCDR_FieldNum = $ErrorCode_SIBBCDR_FieldNumArray[1];
                }
                elsif( $_ =~ m/serverResponseOperation_SIBBCDR_FieldNum/ )
                {
                        $_=~ s/\s//g;
                        @serverResponseOperation_SIBBCDR_FieldNumHashArray = split('#',$_);
                        @serverResponseOperation_SIBBCDR_FieldNumArray = split('=',$serverResponseOperation_SIBBCDR_FieldNumHashArray[0]);
                        $serverResponseOperation_SIBBCDR_FieldNum = $serverResponseOperation_SIBBCDR_FieldNumArray[1];
                }
        }
        close SI_tool_cfgFile;
}

sub scp_CDRs
{
        $scpCDRsFlag = 'no';
        @machinesListArray = split(',', $_[3]);
        $machinesListArrayLength = scalar @machinesListArray;
        unless($machinesListArrayLength = 0)
        {
                foreach my $machine (@machinesListArray)
                {
                        unless($machine eq $host_name)
                        {
                                unless(-e "$SIsimScriptDir/scpCDRs/")
                                {
                                        system("$mkdircommand $SIsimScriptDir/scpCDRs/");
                                        system("$touchcommand $SIsimScriptDir/scpCDRs/.dummyfile");
                                }
                                system("scp $machine:$_[0] $SIsimScriptDir/scpCDRs/active_$_[2]_$machine.cdr &>/dev/null");
                                if ($Illustrator_mode eq "cdrmon")
                                {
                                        @hourext = split(':', $DateTime_SPCMCDR_FieldNum);
                                        system("scp $machine:$_[1]/$_[2]*_$hourext[0]* $SIsimScriptDir/scpCDRs/ &>/dev/null");
                                }
                                $scpCDRsFlag = 'yes';
                        }
                }
        }
}



END
{
        if (defined($opt_p))
        {
                print "\nFinished, Bye.\n\n";
        }
        else
        {
                unless (defined($opt_r))
                {
                        unless ($opt_h eq "")
                        {
                                system("$spawnSIshOutFile quiet ");
                                {
                                        print color("yellow"),"\n==============================================================================================\nSending \"quiet\" to SI (telnet 0 $USSD_SI_port) to stop verbose mode\n",color("reset");
                                }
                                stopSIsim();
                        }
                }
        }
}