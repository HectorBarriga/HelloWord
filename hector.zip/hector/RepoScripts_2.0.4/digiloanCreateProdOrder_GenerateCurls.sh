#!/bin/bash
SCRIPT=$(realpath "$0")
defaultMsisdn="13455163528"
defaultSVEnv="HRD"
TMF620Level="L4"
echo "`tput setaf 2`
TEST MSISDNS:

13455163528
13455012316
13455163626
18764034045
13451003216     Supriya Demo 5
13451003228     Supriya Demo 5
13454879318     PrePaid for Plan Purchase
13455163645     PrePaid for Plan Purchase and PlanPurchase Karan
13453421244     PlanPurchase Nitish
13458009140     PlanPurchase Test for Hector
13458009138     PlanPurchase Test for Hector
13455163626     Karan
13455483091     SV UAT Alessandro
13453233464     Jadan SIT USSSD
12468339211     BARBADOS USSD SIT and SV SIT
13455483136     Cayman SIT cassandrea
13453233530     Mogany Cay UAT
12468421291     UAT Pardeep
13450508040     Digiloan Burno Villa
13453233387     SIT Jadan Jones
13453233509     SIT Paul Gordon
13453233385     SIT Jadan Jones
18697601014     PROD
18697678606     UAT St Kitts
`tput sgr0`";
echo -n "Enter MSISDN [Default = $defaultMsisdn] > "
read msisdn
if [ -z "$msisdn" ] ;then msisdn=$defaultMsisdn;fi
echo -n "Enter SV Environment [Default = $defaultSVEnv] > "
read SVEnv
if [ -z "$SVEnv" ] ;then SVEnv=$defaultSVEnv;fi

if [ $SVEnv == "SIT" ];then
        SubKey="a2dc29ac86bb49528ec4ca90ab38cd2f"
        APIMDomain="sit-apim.digicelgroup.com"
elif [ $SVEnv == "UAT" ];then
        SubKey="44fd6e018469407ea6be0bdddb36ed3d"
        APIMDomain="uat-apim.digicelgroup.com"
elif [ $SVEnv == "HRD" ];then
        SubKey="c4a7619bc8644636a1f899405a8974d3"
        APIMDomain="stg-apim.digicelgroup.com"
elif [ $SVEnv == "PROD" ];then
        SubKey="38c691706ce24907be81bf04534427b7"
        APIMDomain="apim.digicelgroup.com"
else
        echo -e "\nWrong Environment, bye\n";exit
fi

if [ -z "$msisdn" ] ;then msisdn=$defaultMsisdn;fi
getTMF632=$(curl -X GET -H "tenant: production" -H "" "http://localhost:8286/serviceRequest?context=APIM_$SVEnv""_TMF632_PartyManagement&APIMSubscriptionKey=$SubKey&tenant=production&APIMSubscriptionKey=$SubKey&msisdn=$msisdn")
isTMF632=$(echo "$getTMF632" | sed 's/><[^/]/>\n</g' | grep TangoResponseCode | cut -d">" -f2 | cut -d"<" -f1)
prodCat=$(curl -X GET -H "tenant: production" -H "" "http://localhost:8286/serviceRequest?context=APIM_$SVEnv""_TMF637_ProductInventoryManagement&APIMSubscriptionKey=$SubKey&tenant=production&APIMSubscriptionKey=$SubKey&msisdn=$msisdn" )
isTMF637=$(echo "$prodCat" | grep TangoResponseCode | cut -d">" -f4 | cut -d"<" -f1)
prodCatId=$(echo "$prodCat" | sed 's/><[^/]/>\n</g' | grep rodCatalogID | cut -d">" -f2 | cut -d"<" -f1 | jq '.prodCatalogId[0]')
prodCatName=$(echo "$prodCat" | sed 's/><[^/]/>\n</g' | grep rodCatalogName | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.prodCatalogName[0]')
currentDigiLoanID=$(echo "$prodCat" | sed 's/><[^/]/>\n</g' | grep urrentDigiLoan | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.currentDigiLoan[0].id')
currentDigiLoanName=$(echo "$prodCat" | sed 's/><[^/]/>\n</g' | grep urrentDigiLoan | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.currentDigiLoan[0].name')
baseProdInsId=$(curl -X GET -H "tenant: production" -H "" "http://localhost:8286/serviceRequest?context=APIM_$SVEnv""_TMF637_ProductInventoryManagement&APIMSubscriptionKey=$SubKey&tenant=production&APIMSubscriptionKey=$SubKey&msisdn=$msisdn" | sed 's/><[^/]/>\n</g' | grep aseProdInstanceId| cut -d">" -f2 | cut -d"<" -f1 | jq '.baseProdInstanceID[0]')
customerId=$(curl -X GET -H "tenant: production" -H "" "http://localhost:8286/serviceRequest?msisdn=13455163528&context=APIM_$SVEnv""_TMF629_getCustomerID&tenant=production&APIMSubscriptionKey=$SubKey&msisdnIn=$msisdn"| sed 's/><[^/]/>\n</g' | grep ustomerID| cut -d">" -f2 | cut -d"<" -f1)
curl -X GET -H "Accept: application/json" -H "Ocp-Apim-Subscription-Key: $SubKey" "https://$APIMDomain/product-catalog-management/productOffering?channel=USSD&customerId=$customerId&retrievalType=3&objKeys=$prodCatId&offerEligibility=Available&baseProductInstanceId=$baseProdInsId&fields=bundledProductOffering"
echo -e "\n------------------------------------------------------------------------------------------------------------------------------------------------------\n                          ^\n                          |"
echo -e "\nTMF620 via APIM get Families L3 Digiloan\n\n`tput setaf 3`curl -X GET -H \"Accept: application/json\" -H \"Ocp-Apim-Subscription-Key: $SubKey\" \"https://$APIMDomain/product-catalog-management/productOffering?channel=USSD&customerId=$customerId&retrievalType=3&objKeys=$prodCatId&offerEligibility=Available&baseProductInstanceId=$baseProdInsId&fields=bundledProductOffering\"`tput sgr0`"

echo "------------------------------------------------------------------------------------------------------------------------------------------------------"
echo "$getTMF632"
echo -e "\n------------------------------------------------------------------------------------------------------------------------------------------------------\n                          ^\n                          |"
echo -e "\nTMF632 via HRG get Subscriber preffered Language  Digiloan\n\n`tput setaf 2`curl -X GET -H \"tenant: production\" -H \"\" \"http://localhost:8286/serviceRequest?context=APIM_$SVEnv""_TMF632_PartyManagement&APIMSubscriptionKey=$SubKey&tenant=production&APIMSubscriptionKey=$SubKey&msisdn=$msisdn\"`tput sgr0`"
if [ "$isTMF632" == "200" ];then
        echo -e "\033[97;42;1m TMF632 = 200 OK \033[m\n\n"
else
        echo -e "\033[97;41;1m TMF632 = 200 NOT OK \033[m\n\n"
fi
echo "------------------------------------------------------------------------------------------------------------------------------------------------------"
echo "$prodCat"
echo -e "\n------------------------------------------------------------------------------------------------------------------------------------------------------\n                          ^\n                          |"
echo -e "\nTMF637 via HRG get Prod Catalog Digiloan\n\n`tput setaf 2`curl -X GET -H \"tenant: production\" -H \"\" \"http://localhost:8286/serviceRequest?context=APIM_$SVEnv""_TMF637_ProductInventoryManagement&APIMSubscriptionKey=$SubKey&tenant=production&APIMSubscriptionKey=$SubKey&msisdn=$msisdn\"`tput sgr0`"
if [ "$isTMF637" == "200" ];then
        echo -e "\033[97;42;1m TMF637 = 200 OK \033[m\n\n"
else
        echo -e "\033[97;41;1m TMF632 = 200 NOT OK \033[m\n\n"
fi
echo "------------------------------------------------------------------------------------------------------------------------------------------------------"
getFamiliesDigiloanL3=$(curl -X GET -H "tenant: production" -H "" "http://localhost:8286/serviceRequest?msisdn=$msisdn&context=APIM_$SVEnv""_TMF620_GetFamilies_L3&tenant=production&APIMSubscriptionKey=$SubKey&customerID=$customerId&productCatalogID=$prodCatId&baseProductInstanceId=$baseProdInsId&familyKey=digiloan&msisdnIn=$msisdn")
isTMF620=$(echo "$getFamiliesDigiloanL3" | sed 's/><[^/]/>\n</g' | grep TangoResponseCode | cut -d">" -f2 | cut -d"<" -f1)
echo $getFamiliesDigiloanL3
echo -e "\n------------------------------------------------------------------------------------------------------------------------------------------------------\n                          ^\n                          |"
echo -e "\nTMF620 via HRG get Families Digiloan\n\n`tput setaf 2`curl -X GET -H \"tenant: production\" -H \"\" \"http://localhost:8286/serviceRequest?msisdn=$msisdn&context=APIM_$SVEnv""_TMF620_GetFamilies_L3&tenant=production&APIMSubscriptionKey=$SubKey&customerID=$customerId&productCatalogID=$prodCatId&baseProductInstanceId=$baseProdInsId&familyKey=digiloan&msisdnIn=$msisdn\"`tput sgr0`"
if [ "$isTMF620" == "200" ];then
        echo -e "\033[97;42;1m TMF620 = 200 OK \033[m\n\n"
else
        echo -e "\033[97;41;1m TMF632 = 200 NOT OK \033[m\n\n"
fi
echo "------------------------------------------------------------------------------------------------------------------------------------------------------"
echo -e "\n`tput setaf 2`=====================================================\nFAMILY MENU"
i=0
j=1
echo "$getFamiliesDigiloanL3" | grep familyBundles | cut -d">" -f2 | cut -d"<" -f1 |jq '.familyBundles[] | .id,.name' | sed -r 's/"//g' | while read in;do if [ $i == "0" ] || [ $i == "2" ] || [ $i == "4" ] || [ $i == "6" ] || [ $i == "8" ] || [ $i == "10" ] || [ $i == "12" ] || [ $i == "14" ] || [ $i == "16" ] || [ $i == "18" ] || [ $i == "20" ] || [ $i == "22" ] || [ $i == "24" ]; then echo -n "$j - [FamilyID = $in] ";j=$((j+1));else echo $in;fi;i=$((i+1));done
echo "===================================================== `tput sgr0`"
echo -n -e "\n\nEnter Family ID [If you want to, clean Scrollback on putty] > "
read familyID
if [ -z "$familyID" ]; then
        echo -e "\nWhat? "
        echo -n -e "\n\nEnter Family ID [If you want to, clean Scrollback on putty] > "
        read familyID
fi
echo "------------------------------------------------------------------------------------------------------------------------------------------------------"
removeA="no"

if [ "$currentDigiLoanID" != "null" ] || [ "$currentDigiLoanName" != "null" ];then
        echo -e "\n`tput setaf 1`=====================================================\n$msisdn ALREADY HAS A DIGI LOAN\n(You cannot add more loans until Subs has paid off to SV and SV removes/cancels it automatically)\n\n"
        echo "Current Loan:`tput setaf 3`$currentDigiLoanName [$currentDigiLoanID]"
        echo "`tput setaf 3`===================================================== `tput sgr0`"
        echo -n -e "\n\nDo you want to get TMF622 request to remove it? [Default: Yes] > "
        read removeA
        if [ -z "$removeA" ]; then removeA="yes";fi
        remove=$(echo "$removeA" | tr '[:upper:]' '[:lower:]')
        if [ "$remove" == "yes" ];then
        prodOfferItems=$(curl -X GET -H "tenant: production" -H "" "http://localhost:8286/serviceRequest?msisdn=$msisdn&context=APIM_$SVEnv""_TMF620_GetProdOfferItems_L3&tenant=production&APIMSubscriptionKey=$SubKey&customerID=$customerId&productCatalogID=$prodCatId&baseProductInstanceId=$baseProdInsId&productID=$currentDigiLoanID")
                operationJson=$(echo "                                            {
                                                \"product\": {
                                                    \"op\": \"remove\",
                                                    \"productOffering\": {
                                                        \"id\": \"$currentDigiLoanID\",
                                                        \"name\": \"$currentDigiLoanName\"
                                                    }
                                                }
                                            }")
                operationFamily="remove"
        fi
fi
if [ "$removeA" == "no" ];then
        echo -e "\n`tput setaf 2`=====================================================\nDigi Loans Menu"
        i=0
        j=1
        echo "$getFamiliesDigiloanL3" | grep familyBundles | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.familyBundles[] | select(.id == "'"$familyID"'") | .childOffers[]' | grep 'planAvailability\|planNameOrig\|planId\|{\|}' | jq -r '.[]' | sed -r 's/"//g' | while read in;do if [ $i == "0" ] || [ $i == "3" ] || [ $i == "6" ] || [ $i == "9" ] || [ $i == "12" ] || [ $i == "15" ] || [ $i == "18" ] || [ $i == "21" ]; then echo -n "$j - [ProductID = $in] ";j=$((j+1)); elif [ $i == "2" ] || [ $i == "5" ] || [ $i == "8" ] || [ $i == "11" ] || [ $i == "14" ] || [ $i == "17" ] || [ $i == "20" ] || [ $i == "14" ]; then if [ "$in" == "Unavailable" ];then echo -e "`tput setaf 1`[$in]`tput setaf 2`";else echo "[$in]";fi;else echo -n "$in ";fi;i=$((i+1));done
        echo "===================================================== `tput sgr0`"
        echo -n -e "\n\nEnter product ID [Raw TMF620 APIM response is above on top] > "
        read prodID
        if [ -z "$prodID" ]; then
                echo -e "\nWhat?"
                echo -n -e "\n\nEnter product ID [Raw TMF620 APIM response is above on top] > "
                read prodID
        fi
        productNameTitle=$(echo "$getFamiliesDigiloanL3" | grep familyBundles | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.familyBundles[] | select(.id == "'"$familyID"'") | .childOffers[] | select(.planId == "'"$prodID"'") | .planNameOrig' | cut -d'"' -f2)
        productName=$(echo "$productNameTitle" |sed -e 's/ /%20/g' )
        prodOfferItems=$(curl -X GET -H "tenant: production" -H "" "http://localhost:8286/serviceRequest?msisdn=$msisdn&context=APIM_$SVEnv""_TMF620_GetProdOfferItems_L3&tenant=production&APIMSubscriptionKey=$SubKey&customerID=$customerId&productCatalogID=$prodCatId&baseProductInstanceId=$baseProdInsId&productID=$prodID&familyKey=digiloan")
        echo $prodOfferItems
        echo -e "\n------------------------------------------------------------------------------------------------------------------------------------------------------\n                          ^\n                          |"
        echo -e "\nTMF620 via HRG get ProdOffer Items Digiloan\n\n`tput setaf 2`curl -X GET -H \"tenant: production\" -H \"\" \"http://localhost:8286/serviceRequest?msisdn=$msisdn&context=APIM_$SVEnv""_TMF620_GetProdOfferItems_L3&tenant=production&APIMSubscriptionKey=$SubKey&customerID=$customerId&productCatalogID=$prodCatId&baseProductInstanceId=$baseProdInsId&productID=$prodID&familyKey=digiloan\"`tput sgr0`"
        operationJson=$(echo "                                            {
                                                \"product\": {
                                                    \"op\": \"add\",
                                                    \"productOffering\": {
                                                        \"id\": \"$prodID\",
                                                        \"name\": \"$productName\"
                                                    }
                                                }
                                            }")
        operationFamily="add"


fi
# GET ITEMS TO CREATE PROD ORDER
familyName=$(echo "$getFamiliesDigiloanL3" | grep familyBundles | cut -d">" -f2 | cut -d"<" -f1 | jq '.familyBundles[] | .id,.name' | grep $familyID -A1 | tail -1 | cut -d'"' -f2)
rootBundleID=$(echo "$prodOfferItems" | grep rootBundleID | cut -d">" -f2 | cut -d"<" -f1)
rootBundleName=$(echo "$prodOfferItems" | grep rootBundleName | cut -d">" -f2 | cut -d"<" -f1)
planAvailability=$(echo "$getFamiliesDigiloanL3" | grep familyBundles | cut -d">" -f2 | cut -d"<" -f1 | jq '.familyBundles[] | .childOffers[] | select(.planId == "'"$prodID"'") | .planAvailability' | sed -r 's/"//g' )

if [ -z "$currentDigiLoanID" ];then
        currentDigiLoanID="''"
fi
if [ -z "$currentDigiLoanName" ];then
        currentDigiLoanName="''"
fi

echo -e "\n`tput setaf 3`############################################
msisdnIn=$msisdn
customerId=$customerId
productCatalogID=$prodCatId
productCatalogName=$prodCatName
familyID=$familyID
familyName=$familyName
productID=$prodID
productName=$productName
rootBundleID=$rootBundleID
rootBundleName=$rootBundleName
currentDigiLoanID=$currentDigiLoanID
currentDigiLoanName=$currentDigiLoanName
planAvailability=$planAvailability
############################################ `tput sgr0`\n"
if [ "$planAvailability" == "Unavailable" ];then
        echo -e "\n\n\033[97;41;1m Characteristic\033[93;41;1m UnavailabilityReason\033[97;41;1m is present in the TMF620 cataloge for selected digiloan monetary offer. Bye \033[m\n\n"
        #exit
fi
echo -e "\n\n\033[97;44;1m TMF622 Create Product Order Digiloan POST BODY \033[m\n\n"
echo "
{
    \"reason\": \"Not Available\",
    \"@type\": \"Alter Product Options\",
    \"relatedParty\": [
        {
            \"id\": \"$customerId\",
            \"@referredType\": \"customer\"
        }
    ],
    \"productOrderItem\": [
        {
            \"action\": \"replace\",
            \"product\": {
                \"id\": \"BBB11111\",
                \"op\": \"replace\",
                \"productOffering\": {
                    \"id\": \"$prodCatId\",
                    \"name\": \"$prodCatName\"
                },
                \"realizingService\": [
                    {
                        \"@type\": \"Wireless Service\",
                        \"name\": \"$msisdn\"
                    }
                ],
                \"productRelationship\": [
                    {
                        \"product\": {
                            \"op\": \"add\",
                            \"productOffering\": {
                                \"id\": \"$rootBundleID\",
                                \"name\": \"$rootBundleName\"
                            },
                            \"productRelationship\": [
                                {
                                    \"product\": {
                                        \"op\": \"$operationFamily\",
                                        \"productOffering\": {
                                            \"id\": \"$familyID\",
                                            \"name\": \"$familyName\"
                                        },
                                        \"productRelationship\": [
$operationJson
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
}

"

prodCatNameCurl=$(echo "$prodCatName" | sed -e 's/ /%20/g')
productCatalogNameCurl=$(echo "$productCatalogName" | sed -e 's/ /%20/g')
rootBundleNameCurl=$(echo "$rootBundleName" | sed -e 's/ /%20/g')
familyNameCurl=$(echo "$familyName" | sed -e 's/ /%20/g')
productNameCurl=$(sed -e 's/ /%20/g' <<< $productName)
echo "`tput setaf 2`curl -X GET -H \"tenant: production\"  'http://localhost:8286/serviceRequest?msisdnIn=$msisdn&context=APIM_$SVEnv""_TMF622_DigiloanCreateProductOrder_L3&tenant=production&APIMSubscriptionKey=$SubKey&customerID=$customerId&sessionID=1111AAA&productCatalogID=$prodCatId&productCatalogName=$prodCatNameCurl&rootBundleID=$rootBundleID&rootBundleName=$rootBundleNameCurl&familyID=$familyID&familyName=$familyNameCurl&productID=$prodID&productName=$productNameCurl'`tput sgr0`"