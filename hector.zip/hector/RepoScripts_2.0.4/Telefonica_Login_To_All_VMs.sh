#!/bin/bash
date=$(date +'%Y%m%d%H%M%S')
housekeeping=$(ls -altr /home/hector/login_scripts/Telefonica_Login_To_All_VMs/ | wc -l)
if [ $housekeeping -gt 1000 ];then
        echo -e "`tput setaf 1`\n\nWARNING! There are more than 1000 files in /home/hector/login_scripts/Telefonica_Login_To_All_VMs/ Please clean it and try again. Bye`tput sgr0`\n\n"
        exit
fi
getRamdon=$(echo $RANDOM)
echo $getRamdon >> "/home/hector/login_scripts/Telefonica_Login_To_All_VMs/random_$date.list"
sleep 5
countPuttyWindows=$(cat /home/hector/login_scripts/Telefonica_Login_To_All_VMs/random_$date.list | wc -l)
if [ $countPuttyWindows -gt 27 ];then
        echo -e "`tput setaf 1`\n\nWARNING!You opened too many Putty windows. `tput setaf 3`$countPuttyWindows `tput setaf 1`Windows Bye`tput sgr0`\n\n"
        exit
elif [ $countPuttyWindows -lt 27 ];then
        echo -e "`tput setaf 1`\n\nWARNING!You didnt open enough Putty windows. `tput setaf 3`$countPuttyWindows `tput setaf 1`Windows Bye`tput sgr0`\n\n"
        exit
fi
cat /home/hector/.bashrc | grep Telefonica.sh | grep 192 | egrep -v lab | cut -d"=" -f2 > /home/hector/login_scripts/Telefonica_Login_To_All_VMs/nodes_$getRamdon.list
paste /home/hector/login_scripts/Telefonica_Login_To_All_VMs/nodes_$getRamdon.list "/home/hector/login_scripts/Telefonica_Login_To_All_VMs/random_$date.list" > /home/hector/login_scripts/Telefonica_Login_To_All_VMs/merged_$getRamdon.txt
getLoginCmd=$(grep "$getRamdon" /home/hector/login_scripts/Telefonica_Login_To_All_VMs/merged_$getRamdon.txt | cut -d"'" -f2 | sed 's/"//g')
echo -e "\n`tput setaf 6`- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -\ngetRamdon=$getRamdon\n$getLoginCmd\n- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -`tput sgr0`\n\n"

$getLoginCmd