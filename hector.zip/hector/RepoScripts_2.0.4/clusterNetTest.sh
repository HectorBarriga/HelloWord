#!/bin/bash
#############################################################################
# Filename:    clusterNetTest.sh
# Revision:    $Revision: 0.4.0 $
# Author:      Hector Barriga
#
# Jiras:
# CO Scripts:  COSC-xx
# CO Internal: COIT-xx
#
# This sh script uses nmap package and $hostsfile to test Network Connectivity
# FROM each interface of local node TO all remmote nodes' interfaces
#
# Script offers four flags
# 1. Scan only specific ports. For that, add flag -p. To add more, use commas
# 2. Scan within same type of VLANs. For that, add flag -m and its mode. vlan or all
# 3. Scan between interfaces that belong to a specific type. Check $hostsfile and choose
# 4. Scan specific type of interfaces based on a pattern as per $hostsfile
#
# Copyright (c) Tango Telecom 2016
# Author: Hector Barriga
#
# All rights reserved.
# This document contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or
# in part is expressly prohibited, except as may be specifically
# authorized by prior written agreement or permission of Tango Telecom.
##############################################################################
# version 0.1.0 - First versionA
# version 0.2.0 - Classify Test Results by colors
# version 0.3.0 - Add flags p,l,m,t,h
# version 0.3.1 - If nmap tests is open, run a ping to validate.
# version 0.4.0 - Add flag to be able to chose a different hosts file (not only /etc/hosts)
#
##############################################################################

#---------------------------------------------------------------
# Set Initial variables
#---------------------------------------------------------------
today=`date +20%y%m%d`
todaydate=$(perl -e '@d=localtime time(); printf "%02d%02d%02d\n", $d[5]-100,$d[4]+1,$d[3]')
operativesystem=$(uname)
user=$(whoami)

#---------------------------------------------------------------
# Flags
#---------------------------------------------------------------
while getopts p:m:t:l:s:f:h option;
do
        case $option in
                p) ports=$OPTARG;;
                l) listinit=$OPTARG;list=$(echo "$listinit" | tr '[:upper:]' '[:lower:]');;
                m) mode=$OPTARG;;
                t) type=$OPTARG;;
                s) localIP=$OPTARG;;
                f) hostsfile=$OPTARG;;
                h) echo -e "
        Usage: clusterNetTest.sh

        This sh script uses nmap package and $hostsfile to test Network Connectivity
        Scan FROM each interface of local node TO all remmote nodes' interfaces
        Copyright (c) Tango Telecom 2015

               Options:
               -p <ports>               Ports to be scanned
                                        Note: Porst must be separated by commas
                                        default = All Ports (TOO SLOW)
										
               -l <list of nodes>       Only test between listed nodes
                                        Note: Nodes must be separated by commas
                                        default = All nodes
										
               -m <mode>                Scan within same VLANs or against ALL interfaces
                                        vlan = Scans within same VLANs only
                                        all = Scans all source interfaces againts all dest interfaces defined in $hostsfile
                                        default = All. However, script will print in `tput setaf 5`Pink`tput sgr0` if interfaces are in the same VLAN
										
               -t <type of insterface>  Scan between specific type of interfaces (Add flag with pattern as per $hostsfile) or scan particular/explicit IP(s)
                                        explicit = IPs or hostnames defined in flag -l will be only scanned. /etc/hosts (or other file if -f is present) wont be used to get destingation IPs.
                                        default = All types
										
               -s <sourcer IP>          local IP used to send the scans. Mandatory if flag -t is equal to \"explicit\".
			   
               -f <hosts file?          Option to select a different hosts file other than /etc/hosts
                                        default = /etc/hosts
										
               -h <help>                Show help

               e.g. ./clusterNetTest.sh -p 22,443 -l ipxmiatcgtp1,ipxmiatcnac1
               Scans from each interface of local node TO ipxmiatcgtp1's and ipxmiatcnac1's' interfaces but only scans ports 22 and 443

               e.g. ./clusterNetTest.sh -m vlan -s oam
               Scans within VLANS but only oam interfaces on all ports

               e.g. ./clusterNetTest.sh -s sig -p 2905
               Scan from each interface to all remote interfaces that have pattern \"sig\" in /etc/hosts (sigtran) with ports 2905

               e.g. ./clusterNetTest.sh -t explicit -s 172.19.1.1 -l 172.19.1.2,172.19.1.3 -p 22
               Scans from 172.19.1.1 to 172.19.1.2 and 172.19.1.23 with port 22

               e.g. ./clusterNetTest.sh -f /tango/logs/COStaff/hector/myhosts.txt -p22
               Scan from each interface to all remote interfaces with port 22 that are defined in /tango/logs/COStaff/hector/myhosts.txt


        Test Results Classified by Colors:
                \e[30;48;5;82mResult SUCCESSFUL \e[0m    =    Connectivity Ok and there must be connectivity. Interfaces are in same VLAN
                \e[30;48;5;196mResult FAILED     \e[0m    =    Connectivity failed and there must be connectivity. Interfaces are in same VLAN
                \e[0;48;5;196mREMOTE NODE DOWN  \e[0m    =    Remote Node is down and there must be connectivity. Interfaces are in same VLAN
                \e[42mREMOTE NODE DOWN  \e[0m    =    Remote Node is down but it is OK. There must not be connection since insterfaces are in different VLANs
                `tput setaf 2`Result SUCCESSFUL `tput sgr0`    =    Connectivity failed or Remote Node is Down but there must NOT be connectity. Interfaces are NOT in same VLAN
                `tput setaf 1`Result FAILED `tput sgr0`        =    Connectivity Ok but there must NOT be connectity. Interfaces are NOT in same VLAN

               ";help="true";;
        esac
done

#---------------------------------------------------------------
# Subroutines
#---------------------------------------------------------------

echoCommandResult()
{
if [ "$1" == "redRemoteNodeDown" ]; then
        echo -e "\e[0;48;5;196m REMOTE NODE DOWN\e[0m"
fi
if [ "$1" == "greenRemoteNodeDown" ]; then
        echo -e "\e[42m REMOTE NODE DOWN\e[0m"
fi
echo "$2" | while read line
do
        linelength=$(echo ${#line})
        endspace=$((70 - $linelength))
        if [ "$1" == "green" ]; then
                echo -e "\e[30;48;5;82m $line \c"
        elif [ "$1" == "red" ]; then
                echo -e "\e[30;48;5;196m $line \c"
        elif [ "$1" == "redRemoteNodeDown" ]; then
                echo -e "\e[0;48;5;196m $line \c"
        elif [ "$1" == "greenRemoteNodeDown" ]; then
                echo -e "\e[42m $line \c"
        fi
        for (( c=0; c<=$endspace; c++ ))
        do
                echo -n " "
        done
        echo -e "\e[0m"
done
}

if [ "$help" ==  "true" ];then
        echo ""
else

#---------------------------------------------------------------
# Script
#---------------------------------------------------------------
if [ "$type" == "explicit" ];then
        if [ -z "$localIP" ];then
                tput setaf 1
                echo ""
                echo "Sorry, if -t is to be \"explicit\", you must add -s with local IP(s). Run clusterNetTest.sh -h"
                echo ""
                tput sgr0
                exit
        fi
        if [ "$mode" == "vlan" ];then
                tput setaf 1
                echo ""
                echo "Sorry, flags -t as \"explicit\" and -m as \"vlan\" cannot work together. Explicit remote IP vlan can be not defined. Run clusterNetTest.sh -h"
                echo ""
                tput sgr0
                exit
        fi
fi
tput setaf 3
ip -s -s neigh flush all
tput sgr0
if [ -z "$hostsfile" ];then
        hostsfile="/etc/hosts"
fi
if [ "$operativesystem" == "SunOS" ]; then
        isNmap=$(pkginfo | grep nmap)
        export TERM=xtermc
else
        isNmap=$(rpm -qa | grep nmap)
fi

if [ -z "$isNmap" ];then
        tput setaf 1
        echo "Sorry, nmap package is not installed. Please install it, Bye"
        tput sgr0
        exit
fi
if [ "$user" != "root" ];then
        tput setaf 1
        echo "Sorry, run this script as root, Bye"
        tput sgr0
        exit
fi

hostname=$(hostname | tr '[:upper:]' '[:lower:]')
if [ -z "$type" ] && [ -z "$list" ];then
        getInterfaces=$(cat $hostsfile | tr '[:upper:]' '[:lower:]' | grep $hostname | egrep -v "#" | awk '{print $1}')
        getRemoteInterfaces=$(cat $hostsfile | tr '[:upper:]' '[:lower:]' | egrep -v "127.0.0.1" | egrep -v "::1" | egrep -v $hostname | egrep -v "#" | sed '/^\s*$/d' | awk '{print $1}')
elif [ ! -z "$type" ] && [ -z "$list" ];then
        getInterfaces=$(cat $hostsfile | tr '[:upper:]' '[:lower:]' | grep $type | egrep $hostname | awk '{print $1}')
        getRemoteInterfaces=$(cat $hostsfile | tr '[:upper:]' '[:lower:]' | grep $type | egrep -v "127.0.0.1" | egrep -v "::1" | egrep -v $hostname | egrep -v "#" | sed '/^\s*$/d' | awk '{print $1}')
elif [ -z "$type" ] && [ ! -z "$list" ];then
        getInterfaces=$(cat $hostsfile | tr '[:upper:]' '[:lower:]' | grep $hostname | awk '{print $1}')
        j=0
        for i in $(echo $list | sed "s/,/ /g")
        do
                getRemoteInterfaces[$j]=$(cat $hostsfile | tr '[:upper:]' '[:lower:]' | grep $i | awk '{print $1}')
                j=$((j+1))
        done
        getRemoteInterfaces=$(echo "${getRemoteInterfaces[*]}" | tr " " "\n")
elif [ ! -z "$type" ] && [ ! -z "$list" ];then
        if [ "$type" != "explicit" ];then
                getInterfaces=$(cat $hostsfile | tr '[:upper:]' '[:lower:]' | grep $type | egrep $hostname | awk '{print $1}')
        else
                h=0
                for o in $(echo $localIP | sed "s/,/ /g")
                do
                        getInterfaces[$h]=$(echo "$o")
                        checkIfconfig=$(ifconfig -a | grep $o)
                        if [ -z "$checkIfconfig" ]; then
                                tput setaf 1
                                echo ""
                                echo "Sorry, $o doesn't belong to this host $hostname. It cannot be used as source IP. Run clusterNetTest.sh -h"
                                echo ""
                                tput setaf 3
                                echo "Running \"ip -s -s neigh flush all\" ......"
                                ip -s -s neigh flush all
                                tput sgr0
                                exit

                        fi
                        h=$((h+1))
                done
                getInterfaces=$(echo "${getInterfaces[*]}" | tr " " "\n")
        fi
        j=0
        for i in $(echo $list | sed "s/,/ /g")
        do
                if [ "$type" == "explicit" ];then
                        getRemoteInterfaces[$j]=$(echo "$i")
                else
                        getRemoteInterfaces[$j]=$(cat $hostsfile | tr '[:upper:]' '[:lower:]' | grep $i)
                fi
                j=$((j+1))
        done
        if [ "$type" != "explicit" ];then
                getRemoteInterfaces=$(echo "${getRemoteInterfaces[*]}" | tr " " "\n" | grep $type | awk '{print $1}')
        else
                getRemoteInterfaces=$(echo "${getRemoteInterfaces[*]}" | tr " " "\n" | awk '{print $1}')
        fi
fi

echo "$getInterfaces" | while read srcIP;
do
        echo "$getRemoteInterfaces" | while read destIP;
        do
                if [ "$type" != "explicit" ];then
                        srcAlias=$(cat $hostsfile | tr '[:upper:]' '[:lower:]' |  grep -w $srcIP | awk '{print $2}')
                        destAlias=$(cat $hostsfile | tr '[:upper:]' '[:lower:]' | grep -w $destIP | awk '{print $2}')
                else
                        srcAlias=$srcIP
                        destAlias=$destIP
                fi
                srcAliasExt=$(echo $srcAlias | awk -F'_' '{print $2}')
                destAliasExt=$(echo $destAlias | awk -F'_' '{print $2}')
                if [ "$mode" == "vlan" ] && [ "$srcAliasExt" == "$destAliasExt" ];then
                        echo ""
                        echo "`tput setaf 3`=================== FROM $srcAlias TO $destAlias ====================`tput sgr0`"
                        if [ ! -z "$ports" ];then
                                echo "`tput setaf 5`nmap -S$srcIP $destIP -P0 -p$ports -n`tput sgr0`"
                                nmapCommand=$(nmap -S$srcIP $destIP -P0 -p$ports -n)
                        else
                                echo "`tput setaf 3`nmap -S$srcIP $destIP -P0 -n`tput sgr0`"
                                nmapCommand=$(nmap -S$srcIP $destIP -P0 -n)
                        fi
                        isOpen=$(echo "$nmapCommand" | tr '[:upper:]' '[:lower:]' | awk '/open/ || /closed/')
                        destNodeDown=$(echo "$nmapCommand" | tr '[:upper:]' '[:lower:]' | grep "0 hosts up")
                        if [ -z "$isOpen" ] && [ -z "$destNodeDown" ];then
                                echoCommandResult red "$nmapCommand"
                        elif [ ! -z "$destNodeDown" ];then
                                echoCommandResult redRemoteNodeDown "$nmapCommand"
                        else
                                echo -e "`tput setaf 5`nmap is OPEN. Pinging to validate: ping -I $srcIP $destIP -c 1`tput sgr0`"
                                pingCommand=$(ping -I $srcIP $destIP -c 1)
                                isPing=$(echo "$pingCommand" | awk '/Destination Host Unreachable/ || /100% packet loss/')
                                if [ -z "$isPing" ];then
                                        echoCommandResult green "$nmapCommand"
                                else
                                        echoCommandResult red "$nmapCommand"
                                fi
                        fi
                elif [ "$mode" != "vlan" ];then
                        echo ""
                        echo "`tput setaf 3`=================== FROM $srcAlias TO $destAlias ====================`tput sgr0`"
                        if [ ! -z "$ports" ];then
                                echo "`tput setaf 3`nmap -S$srcIP $destIP -P0 -p$ports -n`tput sgr0`"
                                nmapCommand=$(nmap -S$srcIP $destIP -P0 -p$ports -n)
                                isOpen=$(echo "$nmapCommand" | tr '[:upper:]' '[:lower:]' | awk '/open/ || /closed/')
                                destNodeDown=$(echo "$nmapCommand" | tr '[:upper:]' '[:lower:]' | grep "0 hosts up")
                                if [ "$srcAliasExt" == "$destAliasExt" ];then
                                        if [ -z "$isOpen" ] && [ -z "$destNodeDown" ];then
                                                echoCommandResult red "$nmapCommand"
                                        elif [ ! -z "$destNodeDown" ];then
                                                echoCommandResult redRemoteNodeDown "$nmapCommand"
                                        else
                                                echo -e "`tput setaf 5`nmap is OPEN. Pinging to validate: ping -I $srcIP $destIP -c 1`tput sgr0`"
                                                pingCommand=$(ping -I $srcIP $destIP -c 1)
                                                isPing=$(echo "$pingCommand" | awk '/Destination Host Unreachable/ || /100% packet loss/')
                                                if [ -z "$isPing" ];then
                                                        echoCommandResult green "$nmapCommand"
                                                else
                                                        echoCommandResult red "$pingCommand"
                                                fi
                                        fi
                                elif [ "$srcAliasExt" == "vas" ] && [ "$destAliasExt" == "ext" ];then
                                        if [ -z "$isOpen" ] && [ -z "$destNodeDown" ];then
                                                echoCommandResult red "$nmapCommand"
                                        elif [ ! -z "$destNodeDown" ];then
                                                echoCommandResult redRemoteNodeDown "$nmapCommand"
                                        else
                                                echo -e "`tput setaf 5`nmap is OPEN. Pinging to validate: ping -I $srcIP $destIP -c 1`tput sgr0`"
                                                pingCommand=$(ping -I $srcIP $destIP -c 1)
                                                isPing=$(echo "$pingCommand" | awk '/Destination Host Unreachable/ || /100% packet loss/')
                                                if [ -z "$isPing" ];then
                                                        echoCommandResult green "$nmapCommand"
                                                else
                                                        echoCommandResult red "$pingCommand"
                                                fi
                                        fi
                                elif [ "$srcAliasExt" == "ext" ] && [ "$destAliasExt" == "vas" ];then
                                        if [ -z "$isOpen" ] && [ -z "$destNodeDown" ];then
                                                echoCommandResult red "$nmapCommand"
                                        elif [ ! -z "$destNodeDown" ];then
                                                echoCommandResult redRemoteNodeDown "$nmapCommand"
                                        else
                                                echo -e "`tput setaf 5`nmap is OPEN. Pinging to validate: ping -I $srcIP $destIP -c 1`tput sgr0`"
                                                pingCommand=$(ping -I $srcIP $destIP -c 1)
                                                isPing=$(echo "$pingCommand" | awk '/Destination Host Unreachable/ || /100% packet loss/')
                                                if [ -z "$isPing" ];then
                                                        echoCommandResult green "$nmapCommand"
                                                else
                                                        echoCommandResult red "$pingCommand"
                                                fi
                                        fi
                                elif [ "$srcAliasExt" == "vas" ] && [ "$destAliasExt" == "ws" ];then
                                        if [ -z "$isOpen" ] && [ -z "$destNodeDown" ];then
                                                echoCommandResult red "$nmapCommand"
                                        elif [ ! -z "$destNodeDown" ];then
                                                echoCommandResult redRemoteNodeDown "$nmapCommand"
                                        else
                                                echo -e "`tput setaf 5`nmap is OPEN. Pinging to validate: ping -I $srcIP $destIP -c 1`tput sgr0`"
                                                pingCommand=$(ping -I $srcIP $destIP -c 1)
                                                isPing=$(echo "$pingCommand" | awk '/Destination Host Unreachable/ || /100% packet loss/')
                                                if [ -z "$isPing" ];then
                                                        echoCommandResult green "$nmapCommand"
                                                else
                                                        echoCommandResult red "$pingCommand"
                                                fi
                                        fi
                                elif [ "$srcAliasExt" == "ws" ] && [ "$destAliasExt" == "vas" ];then
                                        if [ -z "$isOpen" ] && [ -z "$destNodeDown" ];then
                                                echoCommandResult red "$nmapCommand"
                                        elif [ ! -z "$destNodeDown" ];then
                                                echoCommandResult redRemoteNodeDown "$nmapCommand"
                                        else
                                                echo -e "`tput setaf 5`nmap is OPEN. Pinging to validate: ping -I $srcIP $destIP -c 1`tput sgr0`"
                                                pingCommand=$(ping -I $srcIP $destIP -c 1)
                                                isPing=$(echo "$pingCommand" | awk '/Destination Host Unreachable/ || /100% packet loss/')
                                                if [ -z "$isPing" ];then
                                                        echoCommandResult green "$nmapCommand"
                                                else
                                                        echoCommandResult red "$pingCommand"
                                                fi
                                        fi
                                elif [ "$srcAliasExt" == "ext" ] && [ "$destAliasExt" == "ws" ];then
                                        if [ -z "$isOpen" ] && [ -z "$destNodeDown" ];then
                                                echoCommandResult red "$nmapCommand"
                                        elif [ ! -z "$destNodeDown" ];then
                                                echoCommandResult redRemoteNodeDown "$nmapCommand"
                                        else
                                                echo -e "`tput setaf 5`nmap is OPEN. Pinging to validate: ping -I $srcIP $destIP -c 1`tput sgr0`"
                                                pingCommand=$(ping -I $srcIP $destIP -c 1)
                                                isPing=$(echo "$pingCommand" | awk '/Destination Host Unreachable/ || /100% packet loss/')
                                                if [ -z "$isPing" ];then
                                                        echoCommandResult green "$nmapCommand"
                                                else
                                                        echoCommandResult red "$pingCommand"
                                                fi
                                        fi
                                elif [ "$srcAliasExt" == "ws" ] && [ "$destAliasExt" == "ext" ];then
                                        if [ -z "$isOpen" ] && [ -z "$destNodeDown" ];then
                                                echoCommandResult red "$nmapCommand"
                                        elif [ ! -z "$destNodeDown" ];then
                                                echoCommandResult redRemoteNodeDown "$nmapCommand"
                                        else
                                                echo -e "`tput setaf 5`nmap is OPEN. Pinging to validate: ping -I $srcIP $destIP -c 1`tput sgr0`"
                                                pingCommand=$(ping -I $srcIP $destIP -c 1)
                                                isPing=$(echo "$pingCommand" | awk '/Destination Host Unreachable/ || /100% packet loss/')
                                                if [ -z "$isPing" ];then
                                                        echoCommandResult red "$nmapCommand"
                                                else
                                                        echoCommandResult red "$pingCommand"
                                                fi
                                        fi
                                elif [ "$srcAliasExt" == "gx" ] && [ "$destAliasExt" == "diam" ];then
                                        if [ -z "$isOpen" ] && [ -z "$destNodeDown" ];then
                                                echoCommandResult red "$nmapCommand"
                                        elif [ ! -z "$destNodeDown" ];then
                                                echoCommandResult redRemoteNodeDown "$nmapCommand"
                                        else
                                                echo -e "`tput setaf 5`nmap is OPEN. Pinging to validate: ping -I $srcIP $destIP -c 1`tput sgr0`"
                                                pingCommand=$(ping -I $srcIP $destIP -c 1)
                                                isPing=$(echo "$pingCommand" | awk '/Destination Host Unreachable/ || /100% packet loss/')
                                                if [ -z "$isPing" ];then
                                                        echoCommandResult green "$nmapCommand"
                                                else
                                                        echoCommandResult red "$pingCommand"
                                                fi
                                        fi
                                elif [ "$srcAliasExt" == "diam" ] && [ "$destAliasExt" == "gx" ];then
                                        if [ -z "$isOpen" ] && [ -z "$destNodeDown" ];then
                                                 echoCommandResult red "$nmapCommand"
                                        elif [ ! -z "$destNodeDown" ];then
                                                 echoCommandResult redRemoteNodeDown "$nmapCommand"
                                        else
                                                echo -e "`tput setaf 5`nmap is OPEN. Pinging to validate: ping -I $srcIP $destIP -c 1`tput sgr0`"
                                                pingCommand=$(ping -I $srcIP $destIP -c 1)
                                                isPing=$(echo "$pingCommand" | awk '/Destination Host Unreachable/ || /100% packet loss/')
                                                if [ -z "$isPing" ];then
                                                        echoCommandResult green "$nmapCommand"
                                                else
                                                        echoCommandResult red "$pingCommand"
                                                fi
                                        fi
                                else
                                        if [ -z "$isOpen" ] && [ -z "$destNodeDown" ];then
                                                tput setaf 2
                                                echo "$nmapCommand"
                                        elif [ ! -z "$destNodeDown" ];then
                                                echoCommandResult greenRemoteNodeDown "$nmapCommand"
                                        else
                                                echo -e "`tput setaf 5`nmap is OPEN. Pinging to validate: ping -I $srcIP $destIP -c 1`tput sgr0`"
                                                pingCommand=$(ping -I $srcIP $destIP -c 1)
                                                isPing=$(echo "$pingCommand" | awk '/Destination Host Unreachable/ || /100% packet loss/')
                                                if [ -z "$isPing" ];then
                                                        tput setaf 1
                                                        echo "$nmapCommand"
                                                else
                                                        tput setaf 2
                                                        echo -e "\nPING FAILED\n"
                                                        ping -I $srcIP $destIP -c 1
                                                fi
                                        fi
                                fi
                                tput sgr0
                        else
                                echo "`tput setaf 3`nmap -S$srcIP $destIP -P0 -n`tput sgr0`"
                                nmapCommand=$(nmap -S$srcIP $destIP -P0 -n)
                                isOpen=$(echo "$nmapCommand" | tr '[:upper:]' '[:lower:]' | awk '/open/ || /closed/')
                                destNodeDown=$(echo "$nmapCommand" | tr '[:upper:]' '[:lower:]' | grep "0 hosts up")
                                if [ "$srcAliasExt" == "$destAliasExt" ];then
                                        if [ -z "$isOpen" ] && [ -z "$destNodeDown" ];then
                                                 echoCommandResult red "$nmapCommand"
                                        elif [ ! -z "$destNodeDown" ];then
                                                echoCommandResult redRemoteNodeDown "$nmapCommand"
                                        else
                                                echo -e "`tput setaf 5`nmap is OPEN. Pinging to validate: ping -I $srcIP $destIP -c 1`tput sgr0`"
                                                pingCommand=$(ping -I $srcIP $destIP -c 1)
                                                isPing=$(echo "$pingCommand" | awk '/Destination Host Unreachable/ || /100% packet loss/')
                                                if [ -z "$isPing" ];then
                                                        echoCommandResult green "$nmapCommand"
                                                else
                                                        echoCommandResult red "$pingCommand"
                                                fi
                                        fi
                                elif [ "$srcAliasExt" == "vas" ] && [ "$destAliasExt" == "ext" ];then
                                        if [ -z "$isOpen" ] && [ -z "$destNodeDown" ];then
                                                echoCommandResult red "$nmapCommand"
                                        elif [ ! -z "$destNodeDown" ];then
                                                echoCommandResult redRemoteNodeDown "$nmapCommand"
                                        else
                                                echo -e "`tput setaf 5`nmap is OPEN. Pinging to validate: ping -I $srcIP $destIP -c 1`tput sgr0`"
                                                pingCommand=$(ping -I $srcIP $destIP -c 1)
                                                isPing=$(echo "$pingCommand" | awk '/Destination Host Unreachable/ || /100% packet loss/')
                                                if [ -z "$isPing" ];then
                                                        echoCommandResult green "$nmapCommand"
                                                else
                                                        echoCommandResult red "$pingCommand"
                                                fi
                                        fi
                                elif [ "$srcAliasExt" == "ext" ] && [ "$destAliasExt" == "vas" ];then
                                        if [ -z "$isOpen" ] && [ -z "$destNodeDown" ];then
                                                echoCommandResult red "$nmapCommand"
                                        elif [ ! -z "$destNodeDown" ];then
                                                echoCommandResult redRemoteNodeDown "$nmapCommand"
                                        else
                                                echo -e "`tput setaf 5`nmap is OPEN. Pinging to validate: ping -I $srcIP $destIP -c 1`tput sgr0`"
                                                pingCommand=$(ping -I $srcIP $destIP -c 1)
                                                isPing=$(echo "$pingCommand" | awk '/Destination Host Unreachable/ || /100% packet loss/')
                                                if [ -z "$isPing" ];then
                                                        echoCommandResult green "$nmapCommand"
                                                else
                                                        echoCommandResult red "$pingCommand"
                                                fi
                                        fi
                                else
                                        nmapCommand=$(nmap -S$srcIP $destIP -P0 -n)
                                        isOpen=$(echo "$nmapCommand" | tr '[:upper:]' '[:lower:]' | awk '/open/ || /closed/')
                                        destNodeDown=$(echo "$nmapCommand" | tr '[:upper:]' '[:lower:]' | grep "0 hosts up")
                                        if [ -z "$isOpen" ] && [ -z "$destNodeDown" ];then
                                                tput setaf 2
                                                echo "$nmapCommand"
                                        elif [ ! -z "$destNodeDown" ];then
                                                echoCommandResult redRemoteNodeDown "$nmapCommand"
                                                tput setaf 2
                                                echo "$nmapCommand"
                                        else
                                                echo -e "`tput setaf 5`nmap is OPEN. Pinging to validate: ping -I $srcIP $destIP -c 1`tput sgr0`"
                                                pingCommand=$(ping -I $srcIP $destIP -c 1)
                                                isPing=$(echo "$pingCommand" | awk '/Destination Host Unreachable/ || /100% packet loss/')
                                                if [ -z "$isPing" ];then
                                                        tput setaf 1
                                                        echo "$nmapCommand"
                                                else
                                                        tput setaf 2
                                                        echo -e "\nPING FAILED\n"
                                                        ping -I $srcIP $destIP -c 1
                                                fi
                                        fi
                                fi
                                tput sgr0
                        fi
                fi
        done
done
tput setaf 3
echo "Running \"ip -s -s neigh flush all\" ......"
ip -s -s neigh flush all
tput sgr0
fi