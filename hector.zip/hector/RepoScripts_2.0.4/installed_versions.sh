#!/bin/bash
getDir=$(ls -altr /tango/ | grep -w config | grep user_data | egrep -v config_roll | cut -d">" -f2 | cut -d"/" -f1,2,3,4,5)
echo -e "`tput setaf 2`cat $getDir/*nstalled_versions.txt`tput sgr0`"
cat $getDir/*nstalled_versions.txt