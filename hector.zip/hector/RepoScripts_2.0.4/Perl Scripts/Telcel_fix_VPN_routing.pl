#!/usr/bin/perl

# Tango: vp0g00d / vk*zbp2M (January 2013)
# Miguel Goyos:  vgp28ff / ledesma2

my $cmd='route print';
my $cmd_result = `$cmd`;
#$cmd_result =~ s/[\x0A\x0D]/|/g; 
my @cmd_result_array = split(/[\x0A\x0D]+/, $cmd_result);
#open(OUT, "> temp.txt");
#print $cmd_result;
#print $#cmd_result_array;
my @cmd_change_route = ();
my $VPN_gateway = '';
foreach $routeLine (@cmd_result_array)
{
	next unless $routeLine =~ m/^\s*(\d+\.\d+\.\d+\.\d+)\s+(\d+\.\d+\.\d+\.\d+)\s+(\d+\.\d+\.\d+\.\d+)/i;
	my $dest = $1;
	my $mask = $2;
	my $gateway = $3;
#	print $dest,'|',$mask,'|',$gateway,"\n";
	if(($dest eq '0.0.0.0') && ($mask eq '128.0.0.0') && ($gateway=~m/^\s*(10\.18\d\.\d+\.\d+)/)) {
	  $VPN_gateway = $gateway;
	  push @cmd_change_route, 'route delete 0.0.0.0 mask 128.0.0.0 ' . $VPN_gateway;
	}		
	if(($dest eq '128.0.0.0') && ($mask eq '255.0.0.0') && ($gateway=~m/^\s*(10\.18\d\.\d+\.\d+)/)) {
	  $VPN_gateway = $gateway;
	  push @cmd_change_route, 'route delete 128.0.0.0 mask 255.0.0.0 ' . $VPN_gateway;
	}		
	if(($dest eq '10.0.0.0') && ($mask eq '255.0.0.0') && ($gateway=~m/^\s*(10\.18\d\.\d+\.\d+)/)) {
	  $VPN_gateway = $gateway;
	}
	if(($dest eq '192.0.0.0') && ($mask eq '255.0.0.0') && ($gateway=~m/^\s*(10\.18\d\.\d+\.\d+)/)) {
	  $VPN_gateway = $gateway;
	}
}
print 'VPN_gateway=', $VPN_gateway, "???\n";
if($VPN_gateway =~ m/^\s*(\d+\.\d+\.\d+\.\d+)/) {
  print 'VPN_gateway=', $VPN_gateway, "\n";
	
	# add the routes that are necessary 
	push @cmd_change_route, 'route add 10.0.0.0 mask 255.0.0.0 ' . $VPN_gateway;
	push @cmd_change_route, 'route add 192.0.0.0 mask 255.0.0.0 ' . $VPN_gateway;  
  
  foreach $routeLine (@cmd_result_array)
  {
	  next unless $routeLine =~ m/^\s*(\d+\.\d+\.\d+\.\d+)\s+(\d+\.\d+\.\d+\.\d+)\s+(\d+\.\d+\.\d+\.\d+)/i;
	  my $dest = $1;
	  my $mask = $2;
	  my $gateway = $3;
	  #-- prepare other commands
	  next unless ($gateway eq $VPN_gateway);
	  if(($dest =~ m/^\s*(128|200|201|202|208|204|224)\./) && ($gateway eq $VPN_gateway)) {
	  	push @cmd_change_route, 'route delete ' . $dest . ' mask ' . $mask . ' ' . $gateway;
	  }
  }
}

#print join(' | ',@cmd_change_route), "\n";

foreach $this_route_change (@cmd_change_route) {
	print 'CMD=', $this_route_change, "\n";
	my $cmd_res = `$this_route_change`;
	print 'RES=', $cmd_res, "\n";
}
<>;
#close(OUT);
