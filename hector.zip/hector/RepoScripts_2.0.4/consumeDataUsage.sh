#!/bin/bash
DIR=$(echo "`dirname $0`")
red=`tput setaf 1`
green=`tput setaf 2`
yellow=`tput setaf 3`
blue=`tput setaf 4`
reset=`tput sgr0`
lightblue=`tput setaf 6`
pink=`tput setaf 5`
bold=`tput bold`
italic=`tput sitm`
if [ -z "$1" ];then
        echo -n "Enter msisdn > "
        read msisdn
        if [ -z "$msisdn" ];then echo -e "\n"$red"Sorry, you must enter a valid msisdn, bye"$reset"\n";exit;fi
else
        msisdn=$1
fi
echo -e ""$yellow"\n------------------- Get Subscriber plans -------------------"$reset""
echo ""$green"curl -X GET -H \"Content-Type: application/json\" -H \"Accept: application/json\" -H \"tenant: brav1\" \"http://IPXMIATCSPCM1:8091/spcm-rest-ws/pcc/spcm/subscribers/$msisdn/plans\" |python -m json.tool"$reset""
planIDs=$(curl -s -X GET -H "Content-Type: application/json" -H "Accept: application/json" -H "tenant: brav1" "http://IPXMIATCSPCM1:8091/spcm-rest-ws/pcc/spcm/subscribers/$msisdn/plans" |python -m json.tool | grep id | egrep -v identifier | egrep -v booster | egrep -v -i validity  | cut -d'"' -f4)
planNames=$(curl -s -X GET -H "Content-Type: application/json" -H "Accept: application/json" -H "tenant: brav1" "http://IPXMIATCSPCM1:8091/spcm-rest-ws/pcc/spcm/subscribers/$msisdn/plans" |python -m json.tool | grep name | cut -d'"' -f4)
echo -e ""$yellow"\nplanID(s) :\n"$reset""
planIDid=1
while read planID
do
        if [ "$planIDid" == "1" ];then
                planDefault=$planID
        fi
        echo -n "$planID  => "
        echo "$planNames" | sed -n "${planIDid}p"
        let ++planIDid
done <<< "$planIDs"
echo -e ""$yellow"\n--------------------------------------"$reset""
echo -n "Enter planID [ Default = $planDefault ] > "
read planID
if [ -z "$planID" ];then
        planID=$planDefault
fi
echo -e ""$yellow"\n------------------- Get Subscriber Usage -------------------"$reset""
echo ""$green"curl -X GET -H \"Content-Type: application/json\" -H \"Accept: application/json\" -H \"tenant: brav1\" \"http://IPXMIATCSPCM1:8091/spcm-rest-ws/pcc/spcm/subscribers/$msisdn/plans/$planID/usage\" |python -m json.tool | grep usage | egrep -v activationModeType | head -1"$reset""
getUsage=$(curl -s -X GET -H "Content-Type: application/json" -H "Accept: application/json" -H "tenant: brav1" "http://IPXMIATCSPCM1:8091/spcm-rest-ws/pcc/spcm/subscribers/$msisdn/plans/$planID/usage" |python -m json.tool | grep usage | egrep -v activationModeType | head -1 | cut -d'"' -f3 | cut -d':' -f2 | cut -d, -f1 | tr -d "[:space:]")
echo -e "\nUsage = $getUsage"
echo -e ""$yellow"\n----------------------- Consume Data -----------------------"$reset""
if [ -z "$2" ];then
        echo -n "Enter MBytes to consume [Default = 190] > "
        read consume
        if [ -z "$consume" ];then
                consume="190000000"
        else
                consume=$(($consume*1000000))
        fi
else
        consume=$2
fi
echo -n "Do you want to consume $consume bytes? [y/n Default = y ] > "
read response
if [ -z "$response" ] || [ "$response" == "y" ];then
        echo ""$green"curl -i -X POST -d '{\"amount\": $consume}' -H \"Content-Type: application/json\" -H \"Accept: application/json\" -H \"tenant: brav1\" \"http://IPXMIATCSPCM1:8091/spcm-rest-ws/pcc/spcm/subscribers/$msisdn/plans/$planID/consume\""$reset""
curl -i -X POST -d '{"amount": "'$consume'"}' -H "Content-Type: application/json" -H "Accept: application/json" -H "tenant: brav1" "http://IPXMIATCSPCM1:8091/spcm-rest-ws/pcc/spcm/subscribers/$msisdn/plans/$planID/consume"
echo -e ""$yellow"\n---------------- Get Subscriber New Usage ------------------"$reset""
echo ""$green"curl -X GET -H \"Content-Type: application/json\" -H \"Accept: application/json\" -H \"tenant: brav1\" \"http://IPXMIATCSPCM1:8091/spcm-rest-ws/pcc/spcm/subscribers/$msisdn/plans/$planID/usage\" |python -m json.tool | grep usage | egrep -v activationModeType | head -1"$reset""
getUsage=$(curl -s -X GET -H "Content-Type: application/json" -H "Accept: application/json" -H "tenant: brav1" "http://IPXMIATCSPCM1:8091/spcm-rest-ws/pcc/spcm/subscribers/$msisdn/plans/$planID/usage" |python -m json.tool | grep usage | egrep -v activationModeType | head -1 | cut -d'"' -f3 | cut -d':' -f2 | cut -d, -f1 | tr -d "[:space:]")
echo -e "\nNew Usage = $getUsage"
echo -e "\n"$yellow"Done, bye"$reset"\n"
else
        echo -e ""$red"\nNothing happened. No consume was done, bye\n"$reset""
fi