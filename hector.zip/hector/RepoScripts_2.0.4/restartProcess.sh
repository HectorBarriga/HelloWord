#!/bin/bash
#`mode="monit"
mode="PM"

if [ "$mode" != "monit" ];then

        trap 'echo -e "\n\n`tput setaf 1`Control+C is not allowed. Please wait until restartProcess finishes its task`tput sgr0`\n"' 2
        hostname=$(hostname)
        if [ -z "$1" ];then
                echo -e "\n`tput setaf 1`Sorry, you must append process index. Bye.`tput sgr0`\n"
                exit
        fi
        isItFailed=$(/tango/bin/mps | grep -w "$1\." | grep "Failed" | egrep -v grep | wc -l)
        if [ $isItFailed -ne 1 ];then
                getCAEHhostname=$(cat /tango/config/PM.cfg  | grep -A1 "CAEH Host"  | tail -1 | awk '{print $4}')
                if [ "$getCAEHhostname" == $hostname ];then
                        if [ ! -f /tango/logs/COSTAFF/hector/sh_scripts/AEH.cfg.restatProcess.back ];then
                                cp -rfp /tango/config/AEH.cfg /tango/logs/COSTAFF/hector/sh_scripts/AEH.cfg.restatProcess.back
                        fi
                        cp -rfp /tango/config/AEH.cfg /tango/config/AEH.cfg.temp
                        sed -i 's/10.30.191.87/0.0.0.0/g' /tango/config/AEH.cfg
                        /tango/bin/mps | grep "CAEH" | awk '{print $4}' | xargs kill -9
                else
                        if [ $(ssh $getCAEHhostname "ls -altr /tango/logs/COSTAFF/hector/sh_scripts/AEH.cfg.restatProcess.back | wc -l"  2> /dev/null) == "0" ];then
                                ssh $getCAEHhostname "cp -rfp /tango/config/AEH.cfg /tango/logs/COSTAFF/hector/sh_scripts/AEH.cfg.restatProcess.back"
                        fi
                        ssh $getCAEHhostname "cp -rfp /tango/config/AEH.cfg /tango/config/AEH.cfg.temp"
                        ssh $getCAEHhostname "sed -i 's/10.30.191.87/0.0.0.0/g' /tango/config/AEH.cfg"
                        ssh $getCAEHhostname "/tango/bin/mps | grep "CAEH" | awk '{print \$4}' | xargs kill -9" 2> /dev/null
                fi
                getPort=$(/tango/bin/mps | grep -w "$1\." | awk '{print $5}')
                getProcessName=$(/tango/bin/mps | grep -w "$1\." | cut -d'[' -f2 | cut -d']' -f1)
                echo "`tput setaf 3``tput bold`-------------------------- Restarting `tput sgr0``tput setaf 6``tput bold`$getProcessName `tput sgr0``tput setaf 3``tput bold`--------------------------`tput sgr0`"
                echo -n "`tput setaf 3`Wait while alarms in CAEH is disabled`tput sgr0` * "
                for d in {1..5};do echo -n "* ";sleep 1;done; echo "`tput setaf 3`Done "
                echo "`tput setaf 2`/tango/bin/pm_shutdown -m $1`tput setaf 3`"
                /tango/bin/pm_shutdown -m $1
                echo -n "`tput setaf 3`Wait for $getProcessName to shutdown`tput sgr0` * "
                isItShutdown=$(/tango/bin/mps | grep -w "$1\." | grep "Shutdown" | egrep -v grep | wc -l)
                while [ $isItShutdown -ne 1 ]
                do
                        echo -n "* "
                        isItShutdown=$(/tango/bin/mps | grep -w "$1\." | grep "Shutdown" | egrep -v grep | wc -l)
                        sleep 1
                done
                echo "* `tput setaf 3`Done "
                isItRunning=$(ps -ef | grep "$getPort" | egrep -v grep | wc -l)
                echo -n "`tput setaf 3`Wait for $getProcessName to stop completely`tput sgr0` * "
                pidCounter=0
                while [ $isItRunning -ne 0 ]
                do
                        echo -n "* "
                        isItRunning=$(ps -ef | grep "$getPort" | egrep -v grep | egrep -v root | wc -l)
                        sleep 1
                        if [ $pidCounter -eq 10 ] || [ $pidCounter -eq 20 ] || [ "$pidCounter" == "done" ];then
                                killit=""
                                echo -e -n "\nIt seems process keeps running on the background, would you like me to kill it [ Default = n (`tput setaf 2`Keep waiting`tput sgr0`)] ? > "
                                read killit
                                if [ "$killit" == "y" ] || [ "$killit" == "Y" ] || [ "$killit" == "yes" ];then
                                        getPID=$(ps -ef | grep "$getPort" | egrep -v grep | egrep -v root | grep java | awk '{print $2}')
                                        kill -9 $getPID
                                        echo "`tput setaf 2`kill -9 $getPID`tput sgr0` "
                                        sleep 1
                                        isItRunning=$(ps -ef | grep "$getPort" | egrep -v grep | egrep -v root | wc -l)
                                fi
                        fi
                        pidCounter=$((pidCounter+1))
                done
                echo "`tput setaf 3`Done "
        else
                getPort=$(/tango/bin/mps | grep -w "$1\." | awk '{print $4}')
                getProcessName=$(/tango/bin/mps | grep -w "$1\." | cut -d'[' -f2 | cut -d']' -f1)
                getCAEHhostname=$(cat /tango/config/PM.cfg  | grep -A1 "CAEH Host"  | tail -1 | awk '{print $4}')
                if [ "$getCAEHhostname" == $hostname ];then
                        if [ ! -f /tango/logs/COSTAFF/hector/sh_scripts/AEH.cfg.restatProcess.back ];then
                                cp -rfp /tango/config/AEH.cfg /tango/logs/COSTAFF/hector/sh_scripts/AEH.cfg.restatProcess.back
                        fi
                        cp -rfp /tango/config/AEH.cfg /tango/config/AEH.cfg.temp
                        sed -i 's/10.30.191.87/0.0.0.0/g' /tango/config/AEH.cfg
                        /tango/bin/mps | grep "CAEH" | awk '{print $4}' | xargs kill -9
                else
                        if [ $(ssh $getCAEHhostname "ls -altr /tango/logs/COSTAFF/hector/sh_scripts/AEH.cfg.restatProcess.back | wc -l"  2> /dev/null) == "0" ];then
                                ssh $getCAEHhostname "cp -rfp /tango/config/AEH.cfg /tango/logs/COSTAFF/hector/sh_scripts/AEH.cfg.restatProcess.back"
                        fi
                        ssh $getCAEHhostname "cp -rfp /tango/config/AEH.cfg /tango/config/AEH.cfg.temp"
                        ssh $getCAEHhostname "sed -i 's/10.30.191.87/0.0.0.0/g' /tango/config/AEH.cfg"
                        ssh $getCAEHhostname "/tango/bin/mps | grep "CAEH" | awk '{print \$4}' | xargs kill -9" 2> /dev/null
                fi
                echo "`tput setaf 3``tput bold`-------------------------- Restarting `tput sgr0``tput setaf 6``tput bold`$getProcessName `tput sgr0``tput setaf 3``tput bold`--------------------------`tput sgr0`"
                echo -n "`tput setaf 3`Wait while alarms in CAEH is disabled`tput sgr0` * "
                for d in {1..5};do echo -n "* ";sleep 1;done; echo "`tput setaf 3`Done "
                isItRunning=$(ps -ef | grep "$getPort" | egrep -v grep | wc -l)
                if [ $isItRunning -ne 0 ];then
                        getPID=$(ps -ef | grep "$getPort" | egrep -v grep | egrep -v root | grep java | awk '{print $2}')
                        echo -e -n "`tput setaf 3`It seems $getProcessName process keeps running on the background, I will kill it [`tput setaf 2`kill -9 $getPID`tput setaf 3`] now`tput sgr0` *"
                        kill -9 $getPID
                        sleep 1
                        echo -n " *"
                        sleep 1
                        echo " * `tput setaf 3`Done`tput sgr0`"
                else
                        echo -e "`tput setaf 3`$getProcessName process is not running on the background. Not need to kill it. Continue ...`tput sgr0`"
                fi
        fi
        echo "`tput setaf 2`/tango/bin/pm_shutdown -m $1 -r`tput setaf 3`"
        echo -n "`tput setaf 3`Restarting now. Wait for $getProcessName to be running completely`tput sgr0` * "
        /tango/bin/pm_shutdown -m $1 -r
        isItRunning=$(/tango/bin/mps | grep -w "$1\." | grep "Running" | egrep -v grep | wc -l)
        while [ $isItRunning -eq 0 ]
        do
                echo -n "* "
                isItRunning=$(/tango/bin/mps | grep -w "$1\." | grep "Running" | egrep -v grep | wc -l)
                sleep 1

                isItFailed=$(/tango/bin/mps | grep -w "$1\." | grep "Failed" | egrep -v grep | wc -l)
                while [ $isItFailed -eq 1 ]
                do
                        echo -e "\n`tput setaf 1`Sorry, $getProcessName has Failed, `tput setaf 3`[Dont forget to re-enable CAEH alarms]`tput setaf 1`, Bye.`tput sgr0`\n"
                        exit
                done
        done
        echo -e "`tput setaf 3`Done `tput sgr0`"
        sleep 2
        if [ "$getCAEHhostname" == $hostname ];then
                mv /tango/config/AEH.cfg.temp /tango/config/AEH.cfg
                /tango/bin/mps | grep "CAEH" | awk '{print $4}' | xargs kill -9
        else
                ssh $getCAEHhostname "mv /tango/config/AEH.cfg.temp /tango/config/AEH.cfg"
                ssh $getCAEHhostname "/tango/bin/mps | grep "CAEH" | awk '{print \$4}' | xargs kill -9" 2> /dev/null
        fi
        echo -n "`tput setaf 3`Wait while alarms in CAEH is re-enabled`tput sgr0` * "
        for d in {1..5};do echo -n "* ";sleep 1;done; echo "`tput setaf 3`Done `tput sgr0`"
        /tango/bin/mps
        trap 2
else
        if [ -z "$1" ];then
                echo -e "\n`tput setaf 1`Sorry, you must append process name. Bye.`tput sgr0`\n"
                exit
        fi
        echo "`tput setaf 3``tput bold`-------------------------- Restarting `tput sgr0``tput setaf 6``tput bold`$1`tput sgr0``tput setaf 3``tput bold`--------------------------`tput sgr0`"
        echo "`tput setaf 2`sudo monit stop $1`tput setaf 3`"
        sudo monit stop $1
        for d in {1..5};do echo -n "* ";sleep 1;done; echo "`tput setaf 3`Done "
        echo "`tput setaf 2`sudo monit start $1`tput setaf 3`"
        echo -n "`tput setaf 3`Restarting now. Wait for $1 to be running completely`tput sgr0` * "
        sudo monit start $1
        for d in {1..5};do echo -n "* ";sleep 1;done; echo "`tput setaf 3`Done "
        sudo monit summary


fi