#!/usr/bin/perl

###############################################################################
# Filename:    spcm_daily_report_Dublin.pl
#
# Jiras:
# CO Scripts:  COSC-xxx
#
# gx_CCR_TPS_avarage_receivedByTheDRA.pl, perl script, is to report daily customer traffic reports that have consumed in each country / carrier.
# Details:
# Script caculates the avarage of requests per second (CCR per second received by the DRA) by diving the TOTAL by 300.
# The avarages are taken every 5 mins and stored in daily filesA
#
# Copyright (c) Tango Telecom 2020
# Author: Hector Barriga
#
# All rights reserved.
# This document contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or
# in part is expressly prohibited, except as may be specifically
# authorized by prior written agreement or permission of Tango Telecom.
##############################################################################
# version 0.1.0 - First version
# version 0.2.0 - Add Plan Activation Expiry Date report
 my $version="0.2.0";
#
###############################################################################

setpriority(0,0,19);
use Getopt::Std;
use strict;
use vars qw/$opt_d $opt_f $opt_v $opt_h $opt_u $opt_t $opt_z $opt_k $opt_o/;
use POSIX 'strftime';
use Cwd qw(abs_path);
use File::Basename;
my $scriptPath = File::Basename::dirname(abs_path($0));
my @arrayScriptPath = split '/', abs_path($0);
my $scriptName = $arrayScriptPath[$#arrayScriptPath]; #"per_msisdn_daily_report.pl";
my $VERBOSE_FLAG = 0;
my $DONT_ZIP_FILES_FLAG = 0;
my $DONT_HOUSE_KEEP_FILES_FLAG = 0;
my $LOG_INITIALISED_FLAG = 0;
my $fh_debug_log;

my %msisdn_record;
my %rules_record;
my %plans_record;
my %global_record;
$global_record{"total_purchases"} = 0;
$global_record{"total_revenue"} = 0;
my %usage_record;
my %expiry_date_plan_activation_record;
my @fields = ("MSISDN","COUNTER_NAME","IMSI","MNC/MCC","VOLUME","VISITED OPERATOR","VISITED COUNTRY");
my @MNC_MCC_FILE_ENTRIES;
my $FILE_MNC_MCC = $scriptPath."/plmnIdToMccMnc.csv";
my $DEBUG_FILE = "/tango/logs/reporting_scripts/".$scriptName."_".getDateString().".log";
my $DATE_REFERENCE = getReversedDateStringFromToday(1);
my $SOURCE_FOLDER ="";
my $FINAL_DESTINATION_FOLDER ="";
my $TMP_DESTINATION_FOLDER ="";
my $CAT_UNZIP_COMMAND = "unzip -c ";
my $ZIP_COMMAND = "zip";
my $TAR_COMMAND = "tar -cvf";
my $OUTPUT_FILE_TOTAL_ZIPPED = "daily_cubic_report_".$DATE_REFERENCE.".tar";
my $SELECTED_TENANT = "ALL";

# OUTPUT FILES
my $OUTPUT_FILE_NAME_PER_ZONE_COUNTER = "daily_cubic_report_per_msisdn_counters_".$DATE_REFERENCE .".csv";
my $OUTPUT_FILE_NAME_PER_COUNTRY = "daily_cubic_report_per_msisdn_per_country_".$DATE_REFERENCE .".csv";
my $OUTPUT_FILE_NAME_KPI = "daily_cubic_report_kpi_".$DATE_REFERENCE .".csv";
my $OUTPUT_FILE_NAME_RULES = "daily_cubic_report_rules_".$DATE_REFERENCE.".csv";
my $OUTPUT_FILE_NAME_PLANS = "daily_cubic_report_plans_".$DATE_REFERENCE.".csv";
my $OUTPUT_FILE_NAME_PER_PLANS = "daily_cubic_report_per_msisdn_per_country_purchased_plans_".$DATE_REFERENCE.".csv";
my $OUTPUT_FILE_NAME_USE_PER_NETWORK = "daily_cubic_report_per_country_network_".$DATE_REFERENCE.".csv";
my $OUTPUT_FILE_NAME_PLAN_ACTIVATION_EXPIRY_DATE = "daily_cubic_report_expiry_date_per_msisdn_per_plan_activation_".$DATE_REFERENCE.".csv";

my @FILES_GENERATED = ($OUTPUT_FILE_NAME_PER_COUNTRY, $OUTPUT_FILE_NAME_KPI, $OUTPUT_FILE_NAME_RULES, $OUTPUT_FILE_NAME_PLANS, $OUTPUT_FILE_NAME_USE_PER_NETWORK, $OUTPUT_FILE_NAME_PER_ZONE_COUNTER, $OUTPUT_FILE_NAME_PER_PLANS, $OUTPUT_FILE_NAME_PLAN_ACTIVATION_EXPIRY_DATE);

# CDR TYPE SELECTORS
my $PLAN_CDR_TYPE = "39";
my $PLAN_USAGE_CDR_TYPE = "45";
my $TRANSACTION_TYPE = "0",

# FIELD POSITIONS
my $CDR_PLMNID_POS = 19;
my $CDR_PURCHASE_PLMNID_POS = 20;
my $CDR_TOTAL_USAGE_POS = 5;
my $CDR_IMSI_POS = 20;
my $CDR_PURCHASE_IMSI_POS = 42;
my $CDR_COUNTER_NAME_POS = 4;
my $CDR_VARIABLE_PART_POS = 21;
my $CDR_PLAN_NAME_POS = 8;
my $CDR_USAGE_PLAN_NAME_POS = 17;
my $CDR_PLAN_COST_POS = 7;
my $CDR_TENANT_POS = 3;
my $CDR_DATE_POS = 4;
my $CDR_USAGE_POS = 10;
my $CDR_PLAN_ACTIVATION_EXPIRY_DATE_POS = 22;
my $CDR_PLAN_ACTIVATION_IMSI_POS = 43;
my $CDR_PLAN_ACTIVATION_MSISDN_POS = 0;
my $CDR_PLAN_ACTIVATION_TIME = 5;

### CONFIGURE THIS LINE WITH THE CORRECT NUMBER OF SPCM SERVERS
my @SPCM_SERVERS = ("dtangoA","dtangoB");

### CONFIGURE THIS LINE WITH THE CORRECT FOLDERS TO HOUSE KEEP
#my @FOLDERS_TO_HOUSE_KEEP = ($TMP_DESTINATION_FOLDER,
#                             "/tango/logs/reporting_scripts/");
my @FOLDERS_TO_HOUSE_KEEP = ();

### DELETES FILES FROM HOUSE KEEP FOLDERS OLDER THAN
my $CLEAN_FILES_OLDER_THAN_NUMBER_OF_DAYS = 7x

main();
exit(0);

# ===========================================================================
# Main sub routine
# ===========================================================================
sub main
{
    if ( 0 == getopts( "uh:d:f:t:o:kzv" ) )
    {
        usage();
        exit 0;
    }

    $VERBOSE_FLAG = $opt_v;
    $DONT_ZIP_FILES_FLAG = $opt_z;
    $DONT_HOUSE_KEEP_FILES_FLAG = $opt_k;
    if (defined( $opt_u ))
    {
        usage();
    }
    elsif (defined( $opt_h ))
    {
        help();
    }
    elsif (defined( $opt_d ) || defined( $opt_f ))
    {
        $SOURCE_FOLDER = $opt_f;
        $FINAL_DESTINATION_FOLDER = $opt_d;
                $SELECTED_TENANT = $opt_o if (defined( $opt_o ));
        if (!defined($opt_t))
        {
            $TMP_DESTINATION_FOLDER = $FINAL_DESTINATION_FOLDER."/tmp";
            my $result = executeCommand("mkdir $TMP_DESTINATION_FOLDER");
        }
        else
        {
            $TMP_DESTINATION_FOLDER = $opt_t if (defined( $opt_t ));
        }

        generateReport();
    }
    else
    {
        usage();
    }
    exit(0);
}

sub usage
{
print <<EO_USAGE;

Usage: $scriptName

    -f Source folder of the CDRS in ZIP format
    -d Destination folder of the reports

        OPTIONAL:

        -o OB - Tenant ID (DEFAULT IS ALL)
    -t Temporary folder for intermediate files

    Most common options:


    -v Verbose mode.
    -z Do not zip files

Copyright (c) 2007-2018 Tango Telecom Ltd.
EO_USAGE
}

sub help
{
    print <<EO_HELP;

    Help for script $scriptName (c) Tango Telecom 2007-2018

    This scripts take as parameter a CDR file and reads the contents
    and generates a report.


EO_HELP

    usage();
}
############### MAIN FUNCTIONS

sub generateReport
{
    printLog("Starting with source folder [$SOURCE_FOLDER] and destination folder [$FINAL_DESTINATION_FOLDER]");
    printLog("Temp folder [$TMP_DESTINATION_FOLDER]");
    copyCdrFilesToTmp();
    computeReport();
    printReport();
    zipReports() if (!$DONT_ZIP_FILES_FLAG);
    houseKeeping() if (!$DONT_HOUSE_KEEP_FILES_FLAG);
}

##############################################################################
# houseKeeping()
# Deletes old files from temporary folders
##############################################################################
sub houseKeeping
{
    foreach my $folder (@FOLDERS_TO_HOUSE_KEEP)
    {
        my $cmd = "find $folder -type f -name '*.zip' -mtime +$CLEAN_FILES_OLDER_THAN_NUMBER_OF_DAYS -exec rm {} \\; ";
        printLog("houseKeeping: $cmd");
        executeCommand($cmd);
    }
}

##############################################################################
# copyCdrFilesToTmp()
# copies the CDR files to a temporary folder
##############################################################################
sub copyCdrFilesToTmp
{
    foreach my $server (@SPCM_SERVERS)
    {
        #LOCAL FIRST
        my $cmd = "scp $server:$SOURCE_FOLDER/*".getReversedDateStringFromToday(1).".zip $TMP_DESTINATION_FOLDER";
        printLog("Copy files [$cmd]");
        executeCommand($cmd);
    }
}


##############################################################################
# zipReports()
# ZIPs the report files
##############################################################################
sub zipReports
{
    my $day_before = getReversedDateStringFromToday(1);
    my $cmd = "mkdir ".$FINAL_DESTINATION_FOLDER."/".$day_before;
    $FINAL_DESTINATION_FOLDER = $FINAL_DESTINATION_FOLDER."/".$day_before;
    printLog("Creating destination folder [$cmd]");
    executeCommand($cmd);
    foreach my $file (@FILES_GENERATED)
    {
      my $inputFile = $TMP_DESTINATION_FOLDER."/".$file;
      my $ouputFile = $FINAL_DESTINATION_FOLDER."/".$file.".zip";

      my $cmd = $ZIP_COMMAND." -j ".$ouputFile." ".$inputFile;
      printLog("Zipping $ouputFile, cmd [$cmd]");
      executeCommand($cmd);
    }

    my $cmd = $TAR_COMMAND." ".$FINAL_DESTINATION_FOLDER."/".$OUTPUT_FILE_TOTAL_ZIPPED." ".$TMP_DESTINATION_FOLDER."/*_".$DATE_REFERENCE.".*";
    printLog("Creating single tar file, cmd [$cmd]");
    executeCommand($cmd);
}



##############################################################################
# printReport()
# Prints the report data
##############################################################################
sub printReport
{
    if (open(f1,">".$TMP_DESTINATION_FOLDER."/".$OUTPUT_FILE_NAME_PER_ZONE_COUNTER)
        && open(f2,">".$TMP_DESTINATION_FOLDER."/".$OUTPUT_FILE_NAME_PER_COUNTRY)
        && open(f3,">".$TMP_DESTINATION_FOLDER."/".$OUTPUT_FILE_NAME_KPI)
        && open(f4,">".$TMP_DESTINATION_FOLDER."/".$OUTPUT_FILE_NAME_RULES)
        && open(f5,">".$TMP_DESTINATION_FOLDER."/".$OUTPUT_FILE_NAME_PLANS)
        && open(f6,">".$TMP_DESTINATION_FOLDER."/".$OUTPUT_FILE_NAME_PER_PLANS)
        && open(f7,">".$TMP_DESTINATION_FOLDER."/".$OUTPUT_FILE_NAME_USE_PER_NETWORK)
        && open(f8,">".$TMP_DESTINATION_FOLDER."/".$OUTPUT_FILE_NAME_PLAN_ACTIVATION_EXPIRY_DATE)
       )
    {
        my $TOTAL_NUMBER_OF_MB = 0;
        my %total_usage_per_network_mb;
        print f1 "MSISDN,IMSI,PLMN_ID,COUNTRY,NETWORK,USAGE_MEGABYTES\n";
        print f2 "MSISDN,IMSI,PLMN_ID,COUNTRY,NETWORK,RULE,USAGE_MEGABYTES\n";
        print f6 "DATE,MSISDN,IMSI,PLMN_ID,COUNTRY,NETWORK,PLAN,USAGE_MEGABYTES\n";
        foreach my $msisdn (sort keys %msisdn_record)
        {
            my %msisdn_data = %{$msisdn_record{$msisdn}};
            my $usage_mb_msisdn = $usage_record{$msisdn};
            $TOTAL_NUMBER_OF_MB += ($usage_mb_msisdn/1000000);
            foreach my $field (keys %msisdn_data)
            {
                my @field_components = split /,/,$field;
                my $cdr_date  = $field_components[0];
                my $imsi  = $field_components[1];
                my $network = findNetworkMNCMCC($field_components[2]);
                my $counter  = $field_components[3];
                my $planName = $field_components[4];
                my $usage = $msisdn_record{$msisdn}{$field};
                my $usage_in_mb = sprintf("%.2f",($usage/1000000));
                print "ERROR: $msisdn -> $usage_mb_msisdn != $usage =>  $field \n" if ($usage_mb_msisdn < $usage);

                if (!$counter && !$planName)
                {
                    my $line = convertNumber($msisdn).",$imsi,$network,$usage_in_mb\n";
                    $total_usage_per_network_mb{$network} += $usage_in_mb;
                    print $line if ($VERBOSE_FLAG);
                    print f1 $line;
                }

                if ($counter && !$planName)
                {
                    my $line = convertNumber($msisdn).",$imsi,$network,$counter,$usage_in_mb \n";
                    print $line if ($VERBOSE_FLAG);
                    print f2 $line;
                }

                if (!$counter && $planName)
                {
                    my $line = $cdr_date.",".convertNumber($msisdn).",$imsi,$network,$planName,$usage_in_mb\n";
                    print $line if ($VERBOSE_FLAG);
                    print f6 $line;
                }
            }
        }

        print "----- USAGE PER NETWORK ------ \n"  if ($VERBOSE_FLAG);
        print f7 "PLMN_ID,COUNTRY,NETWORK,USAGE_MEGABYTES\n";
        foreach my $field (keys %total_usage_per_network_mb)
        {
            my $line1 = "$field,".sprintf("%.2f",$total_usage_per_network_mb{$field})."\n";
            print $line1 if ($VERBOSE_FLAG);
            print f7 $line1;
        }

        print "----- RULES ------ \n"  if ($VERBOSE_FLAG);
        print f4 "RULE,RULE_TOTALS\n";
        foreach my $field (keys %rules_record)
        {
            my $line = "$field,$rules_record{$field}\n";
            print $line if ($VERBOSE_FLAG);
            print f4 $line;
        }

        my %plan_totals;
        foreach my $field (keys %plans_record)
        {
            my @field_components = split /,/,$field;
            my $plan = $field_components[0];
            $plan_totals{$plan}+= $plans_record{$field};
        }

        my $TOTAL_NUMER_OF_PURCHASES=0;
        print f5 "PLAN,NUMBER_OF_ACTIVATIONS\n";
        foreach my $plan (keys %plan_totals)
        {
            my $line1 = "$plan,$plan_totals{$plan}\n";
            print $line1 if ($VERBOSE_FLAG);
            print f5 $line1;

        }

        print "----- KPI(s) ------ \n"  if ($VERBOSE_FLAG);

        # OUTPUT KPI VALUES
        my $NUMBER_OF_UNIQUE_MSISDN = scalar keys %msisdn_record;
        my $kpi_line = "$NUMBER_OF_UNIQUE_MSISDN,";
           $kpi_line .= $global_record{"total_purchases"}.",";
           $kpi_line .= $global_record{"total_revenue"}.",";
           $kpi_line .= sprintf("%.2f", $TOTAL_NUMBER_OF_MB)."\n";
        print $kpi_line if ($VERBOSE_FLAG);
        print f3 "NUMBER_OF_UNIQUE_MSISDN,TOTAL_PURCHASES,TOTAL_REVENUE,TOTAL_NUMBER_OF_MB\n";
        print f3 $kpi_line;

        print "----- PLAN ACTIVATION EXPIRY DATE ------ \n"  if ($VERBOSE_FLAG);
        print f8 "PLAN ACTIVATION TIME,MSISDN,IMSI,PLAN NAME,PLAN EXPIRY DATE\n";
        foreach my $plan_activation_msisdn (sort keys %expiry_date_plan_activation_record)
        {
            my %plan_activation_msisdn_data = %{$expiry_date_plan_activation_record{$plan_activation_msisdn}};
            foreach my $plan_activation_field (keys %plan_activation_msisdn_data)
            {
                my @plan_activation_field_components = split /,/,$plan_activation_field;
                my $plan_activation_cdr_time  = $plan_activation_field_components[0];
                my $plan_activation_imsi  = $plan_activation_field_components[2];
                my $plan_activation_planName = $plan_activation_field_components[3];
                my $plan_activation_expiry_date = $plan_activation_field_components[4];
                my $plan_activation_line = "$plan_activation_cdr_time,".convertNumber($plan_activation_msisdn).",$plan_activation_imsi,$plan_activation_planName,$plan_activation_expiry_date\n";
                print f8 $plan_activation_line;
            }
        }

        close(f1);
        close(f2);
        close(f3);
        close(f4);
        close(f5);
        close(f6);
        close(f7);
        close(f8);
    }

}

##############################################################################
# computeReport()
# Computes the data
##############################################################################
sub computeReport
{
    my $list_files_command ="ls $TMP_DESTINATION_FOLDER/*".getReversedDateStringFromToday(1).".zip";
    my @files_to_process = executeCommandForReturn($list_files_command);

    printLog("Will process # files:".@files_to_process);

    my $current_line_number = 0;
    foreach(@files_to_process)
    {
        my $processing_file = $_;
        chop($processing_file);
        my $file_to_process = $processing_file;
        my $cmd_cat = "$CAT_UNZIP_COMMAND $file_to_process";
        my @current_file_content = executeCommandForReturn($cmd_cat);
        printLog("TProcessing file $cmd_cat for tenant: $SELECTED_TENANT with # of lines:". @current_file_content);
        foreach (@current_file_content)
        {

            ##00041005050301090907050405010600,45,0,brav1,30/05/2018,18:53:00,0,764,701-593,1,1887787,0,
            ##64524,1024000,,,0,BasePlanDefault,66.119.82.136:3870:1527706069:25,21407,724233603384599
            ##&0;0;2105;287;Plan Consumption Counter;53240190;0
            ##&1;;3410;449;ZoneROW Rule;5242880;
            ##&1;;3413;452;Zone1 Rule;20971520;
            ##&1;;3416;455;Zone2 Rule;52428800;
            ##&0;0;0;0;0;0;0
            ##00041005050301090907050405010600,40,1,brav1,2,30/05/2018,18:53:06,BasePlanDefault,0,Throttled Zone2,724233603384599&BasePlanDefault;0;;&0;0;0;0

            my $current_line = $_;
               $current_line_number++;
            my @current_line_fields = split /,/,$current_line;
            my $CURRENT_TENANT = $current_line_fields[$CDR_TENANT_POS];

            #SKIP THIS LINE IF THE TENANT IS NOT THE SELECTED TENANT
            if ($SELECTED_TENANT ne "ALL"){
                    next if ($CURRENT_TENANT ne $SELECTED_TENANT);
            }
            #PROCESS THE FILE
            my $CURRENT_MSISDN = $current_line_fields[0];
            my $CDR_DATE = $current_line_fields[$CDR_DATE_POS];

            # TRACK USAGE PER SUBSCRIBER
            if (($current_line_fields[1] == $PLAN_USAGE_CDR_TYPE) && $current_line_fields[2] == $TRANSACTION_TYPE)
            {
               ## TRACK USAGE PER SUBSCRIBER
               $usage_record{$CURRENT_MSISDN} += $current_line_fields[$CDR_USAGE_POS];
            }

            if (($current_line_fields[1] == $PLAN_CDR_TYPE && $current_line_fields[2] == 2) || ($current_line_fields[1] == $PLAN_USAGE_CDR_TYPE)  && $current_line_fields[2] == $TRANSACTION_TYPE)
            {
                my @variable_part_cdr = split /\&/,$current_line_fields[$CDR_VARIABLE_PART_POS];
                my $current_imsi =$variable_part_cdr[0];
                my $current_imsi_purchase_cdr =$current_line_fields[$CDR_PURCHASE_IMSI_POS];

                my $selectorStr2 = $CDR_DATE.",".$current_imsi;
                   $selectorStr2 .= ",".$current_line_fields[$CDR_PLMNID_POS];

                my $selectorStr4 = $current_line_fields[$CDR_PLAN_NAME_POS];
                   $selectorStr4 .= ",".$CURRENT_MSISDN;
                   $selectorStr4 .= ",".$current_imsi_purchase_cdr;
                   $selectorStr4 .= ",".$current_line_fields[$CDR_PURCHASE_PLMNID_POS];

                my $selectorStr5 = $CDR_DATE.",".$current_imsi;
                   $selectorStr5 .= ",".$current_line_fields[$CDR_PLMNID_POS];
                   $selectorStr5 .= ",";
                   $selectorStr5 .= ",".$current_line_fields[$CDR_USAGE_PLAN_NAME_POS];

                my $current_variable_part = 0;
                foreach my $variable_part_element (@variable_part_cdr)
                {
                    my @variable_part_cdr_fields = split /;/,$variable_part_element;

                    next if (!$variable_part_cdr_fields[$CDR_COUNTER_NAME_POS]);

                    my $selectorStr1 = $CDR_DATE.",".$current_imsi;
                       $selectorStr1 .= ",".$current_line_fields[$CDR_PLMNID_POS];
                       $selectorStr1 .= ",".$variable_part_cdr_fields[$CDR_COUNTER_NAME_POS];

                    my $selectorStr3 = $variable_part_cdr_fields[$CDR_COUNTER_NAME_POS];

                    my $bytes_used = $current_line_fields[$CDR_USAGE_POS];
                    if ($current_line_fields[1] == $PLAN_USAGE_CDR_TYPE)
                    {

                        # ALL COUNTERS AND RULES PER IMSI
                        if (!$msisdn_record{$CURRENT_MSISDN}{$selectorStr1})
                        {
                            # NEW MSISDN, NEW COUNTERS
                            $msisdn_record{$CURRENT_MSISDN}{$selectorStr1} = $bytes_used;
                        }
                        else
                        {
                            # ALREADY TRACKING THIS MSISDN, WE WILL UPDATE
                            $msisdn_record{$CURRENT_MSISDN}{$selectorStr1} += $bytes_used;
                #            print "Added $current_line_number selectorStr1 $bytes_used to ".$msisdn_record{$CURRENT_MSISDN}{$selectorStr1}."\n";
                        }

                        if ($current_variable_part == 0)
                        {
                           # PER RULE PER IMSI
                           if (!$msisdn_record{$CURRENT_MSISDN}{$selectorStr2})
                           {
                               # NEW MSISDN, NEW COUNTER - USAGE
                               $msisdn_record{$CURRENT_MSISDN}{$selectorStr2} = $bytes_used;
                               $msisdn_record{$CURRENT_MSISDN}{$selectorStr5} = $bytes_used;

                           }
                           else
                           {
                               # ALREADY TRACKING THIS MSISDN, WE WILL UPDATE
                               $msisdn_record{$CURRENT_MSISDN}{$selectorStr2} += $bytes_used;
                               $msisdn_record{$CURRENT_MSISDN}{$selectorStr5} += $bytes_used;
                              # print "Added $current_line_number selectorStr2 $bytes_used to ".$msisdn_record{$CURRENT_MSISDN}{$selectorStr2}."\n";
                              # print "Added $current_line_number selectorStr5 $bytes_used to ".$msisdn_record{$CURRENT_MSISDN}{$selectorStr5}."\n";
                           }
                        }
                        # COUNT THE NUMBER OF UNIQUE RULES
                        if (!$rules_record{$selectorStr3})
                        {
                            $rules_record{$selectorStr3} = 1;
                        }
                        else
                        {
                            $rules_record{$selectorStr3} += 1;
                        }

                     }
                     $current_variable_part++;
                }
                if ($current_line_fields[1] == $PLAN_CDR_TYPE )
                {
                    $global_record{"total_purchases"} += 1 if ($current_line_fields[$CDR_PLAN_COST_POS]>0);
                    $global_record{"total_revenue"} += $current_line_fields[$CDR_PLAN_COST_POS] if ($current_line_fields[$CDR_PLAN_COST_POS]>0);

                    # COUNT THE NUMBER OF UNIQUE PLANS
                    if (!$rules_record{$selectorStr4})
                    {
                        $plans_record{$selectorStr4} = 1;
                    }
                    else
                    {
                        $plans_record{$selectorStr4} += 1;
                    }

                    # GET EXPIRY DATE PER PLAN ACTIVATION PER MSISDN
                    my $plan_activation_expiry_date = "Default";
                    $plan_activation_expiry_date = $current_line_fields[$CDR_PLAN_ACTIVATION_EXPIRY_DATE_POS] if ($current_line_fields[$CDR_PLAN_ACTIVATION_EXPIRY_DATE_POS] ne '');
                    my $CURRENT_PLAN_ACTIVATION_MSISDN = $current_line_fields[$CDR_PLAN_ACTIVATION_MSISDN_POS];

                    my $selectorStr6 = $current_line_fields[$CDR_PLAN_ACTIVATION_TIME].",".$CURRENT_PLAN_ACTIVATION_MSISDN.",".$current_line_fields[$CDR_PLAN_ACTIVATION_IMSI_POS].",".$current_line_fields[$CDR_PLAN_NAME_POS].",".$plan_activation_expiry_date;
                    $expiry_date_plan_activation_record{$CURRENT_PLAN_ACTIVATION_MSISDN}{$selectorStr6} = 1;

                }
            }
        }
    }
}

############### HELPER FUNCTIONS
##############################################################################
# find MNC/MCC, COUNTRY AND NETWORK()
# Returns a single string
##############################################################################
sub findNetworkMNCMCC
{
    my $plmnid = shift;

    if ($plmnid)
    {
        my $mnc_mcc = quotemeta (substr($plmnid,0,3)."".substr($plmnid,3,length($plmnid)));

        if (!@MNC_MCC_FILE_ENTRIES){
           my $cmd = "cat $FILE_MNC_MCC";
           @MNC_MCC_FILE_ENTRIES = executeCommandForReturn($cmd);
        }
        my $counter = 0;
        foreach my $entry (@MNC_MCC_FILE_ENTRIES)
        {
            next if ($entry =~ /^#/);
            $entry =~ s/\n//;
            if ($entry =~ /$mnc_mcc/)
            {
                my $ret = $entry;
                return $ret
            }
        }
        return "$mnc_mcc,NOT FOUND,NOT FOUND";
    }
    return "N/A,N/A,N/A,N/A";
}

##############################################################################
# convertNumber()
# Converts the Tango format MSISDN to standard format
##############################################################################
sub convertNumber
{
     my $number = shift;
     my $len =length  $number;
     my $retNumber ="";

     for(my $i=$len-1;$i>=6;$i--)
     {
       $retNumber = $retNumber. substr($number,$i,1);
       $i--;
     }
     $retNumber = reverse($retNumber);
     $retNumber = $number if (length($retNumber)<1);
     return "$retNumber";
}

##############################################################################
# hex_to_ascii()
# Converts the Hex to ASCII representation
##############################################################################
sub hex_to_ascii
{
    my $str = shift;

    $str =~ s/000500//g;
    $str =~ s/([a-fA-F0-9]{2})/chr(hex $1)/eg;

    return $str;
}


##############################################################################
# getTimeStamp()
# will return the curent date and time
##############################################################################
sub getTimeStamp
{
   my ($Second, $Minute, $Hour, $Day, $Month, $Year, $ignore, $ignore, $ignore) = gmtime(time);

   if($Hour < 10)   {  $Hour = "0" . $Hour ; }
   if($Minute < 10) {  $Minute = "0" . $Minute ; }
   if($Second < 10) {  $Second = "0" . $Second ; }
   my $Month = $Month + 1 ;
   if($Month < 10)
   {
      $Month = "0" .$Month ;
   }
   if($Day < 10)
   {
      $Day = "0" . $Day ;
   }
   if($Year >= 100)
   {
      $Year = $Year - 100 ;
      if($Year < 10)
      {
         $Year = "0" .$Year ;
      }
   }
   # 08/09/29 19:39:22
   return  ("$Year$Month$Day$Hour$Minute$Second");
}

##############################################################################
# getTime()
# will return the curent date and time
##############################################################################
sub getTime
{
 my ($Second, $Minute, $Hour, $Day, $Month, $Year, $WeekDay, $DayOfYear, $IsDST) = localtime(time);

 if($Hour < 10)   {  $Hour = "0" . $Hour ; }
 if($Minute < 10) {  $Minute = "0" . $Minute ; }
 if($Second < 10) {  $Second = "0" . $Second ; }
 my $Month = $Month + 1 ;
 if($Month < 10)
 {
 $Month = "0" .
 $Month ;
 }
 if($Day < 10)
 {
  $Day = "0" . $Day ;
 }
 if($Year >= 100)
 {
  $Year = $Year - 100 ;
  $Year = $Year + 2000;
 }
 return  ($Second, $Minute, $Hour, $Day, $Month, $Year, $WeekDay, $DayOfYear, $IsDST);
}

##############################################################################
# getTimeString()
# will return the current date and time
##############################################################################
sub getDateTimeString
{
 my @all= getTime();
 return $all[3]."/".$all[4]."/".$all[5]." ".$all[2].":".$all[1].":".$all[0];
}


##############################################################################
# getDateString()
# will return the current date and time
##############################################################################
sub getDateString
{
 my @all= getTime();
 return $all[3]."".$all[4]."".$all[5];
}
##############################################################################
# getFormattedDateString()
# will return the current date and time formatted
##############################################################################
sub getFormattedDateString
{
 my @all= getTime();
 return $all[3]."/".$all[4]."/".$all[5];
}
##############################################################################
# getReversedDateString()
# will return the current date and time
##############################################################################
sub getReversedDateString
{
 my @all= getTime();
 return $all[5]."".$all[4]."".$all[3];
}

##############################################################################
# a day in the past()
# will return the current date and time
##############################################################################
sub getReversedDateStringFromToday
{
 my $days = shift;
 my $yesterday = time - ((60*60*24)*$days);
 return POSIX::strftime('%Y%m%d', localtime($yesterday));
}

##############################################################################
# printLog()
# Prints a log
##############################################################################
sub printLog
{
    my $line = shift;
    my $file = $DEBUG_FILE;
    my $date = getDateString();
    $file =~ s/<DATE>/$date/g;
    $line = $scriptName.":::[".getDateTimeString()."] -- ".$line."\n";


    if (!$LOG_INITIALISED_FLAG)
    {
        die "Can't divert STDERR to $file, please check the correct permissions" if (!open(STDERR, ">>$file"));
        die "Can't open $file, please create the relevant folders" if (!open($fh_debug_log,">>$file"));
                $LOG_INITIALISED_FLAG = 1;
    }
    else
    {
        print $fh_debug_log $line;
        print $line if ($VERBOSE_FLAG);
    }
}
##############################################################################
# executeCommand
# Will Execute a system command
##############################################################################
sub executeCommand
{
    my $cmd = shift;
    my @result = system ($cmd);
    printLog ("Executing command [$cmd] result: @result");
}

##############################################################################
# executeCommandForReturn
# Will Execute a system command and return the results in an array
##############################################################################
sub executeCommandForReturn
{
    my $cmd = shift;
    printLog ("Executing command [$cmd]");
    return `$cmd`;
}