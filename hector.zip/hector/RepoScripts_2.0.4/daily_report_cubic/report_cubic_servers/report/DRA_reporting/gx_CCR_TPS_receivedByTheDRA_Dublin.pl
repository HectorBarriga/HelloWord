#!/usr/bin/perl

###############################################################################
# Filename:    gx_CCR_TPS_receivedByTheDRA.pl
#
# Jiras:
# CO Scripts:  COSC-xxx
#
# gx_CCR_TPS_avarage_receivedByTheDRA.pl, perl script, is to count the Total number ccr_init plus ccr_updt plus ccr_term requests received by the DRA every 5 mins. i
# Details:
# Script caculates the AVERAGE of requests per second (CCR per second received by the DRA) by diving the TOTAL by 300. 
# The avarages are taken every 5 mins and stored in daily filesA
#
# Copyright (c) Tango Telecom 2020
# Author: Hector Barriga
#
# All rights reserved.
# This document contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or
# in part is expressly prohibited, except as may be specifically
# authorized by prior written agreement or permission of Tango Telecom.
##############################################################################
# version 0.1.0 - First version
my $version="0.1.0";
##
###############################################################################

# Intial
setpriority(0,0,19);
my $mkdircommand = qx(which mkdir);
chomp $mkdircommand;
my $catcommand = qx(which cat);
chomp $catcommand;
my $host_name = qx(hostname);
chomp $host_name;

#Libraries
use Getopt::Std;

#use strict;
use warnings;
use CGI qw( :standard );
use GD::Graph::lines;


#Parameters
use POSIX 'strftime';
use Cwd qw(abs_path);
use File::Basename;
my $scriptPath = File::Basename::dirname(abs_path($0));
my @arrayScriptPath = split '/', abs_path($0);
my $scriptName = $arrayScriptPath[$#arrayScriptPath];
my $DEBUG_FILE = "/tango/logs/reporting_scripts/gx_CCR_TPS_receivedByTheDRA"."_".getDateString().".log";
my $DATE_REFERENCE = getReversedDateStringFromToday(1);
my $FINAL_DESTINATION_FOLDER = "/tango/logs/stats/dra_reports/";
my $TMP_DESTINATION_FOLDER = "/tango/logs/stats/dra_reports/tmp";

# OUTPUT FILES
my $OUTPUT_FILE_CCR_TPS = "gx_CCR_TPS_received_by_ALL_DRAs";

### CONFIGURE THIS LINE WITH THE CORRECT NUMBER OF DRA SERVERS
my $DIAM_CMD_RXED_STATS_DIR = "/tango/logs/stats/local/DRA/";
my $DIAM_CMD_RXED_STATS_FILE_PREFIX = "diam_cmd_rxed_stats_by_peer-0";
my @DRA_SERVERS = ("dtangoA","dtangoB");

###### Get arguments
main();
exit(0);

sub main
{
	if ( 0 == getopts( "h:d:v" ) )
	{
		help();
		exit 0;
	}

	if ( defined( $opt_h ) )
	{
		help();
		exit(0);
	}

	if (defined( $opt_d ) )
	{
		$FINAL_DESTINATION_FOLDER = $opt_d;
		$TMP_DESTINATION_FOLDER = $opt_d."/tmp";
		system("$mkdircommand $FINAL_DESTINATION_FOLDER") unless ( -e $FINAL_DESTINATION_FOLDER);
		system("$mkdircommand $TMP_DESTINATION_FOLDER") unless ( -e $TMP_DESTINATION_FOLDER);
	}
	else
	{
		help();
		exit(0);
	}

	if ( defined( $opt_v ) )
	{
		$VERBOSE_FLAG = $opt_v;
	}
	else
	{
		my $VERBOSE_FLAG = 0;
	}

	copyCdrFilesToTmp();

	 foreach my $server (@DRA_SERVERS)
         {
		if (open(f1,">".$FINAL_DESTINATION_FOLDER."/".$OUTPUT_FILE_CCR_TPS."_".$server."_".getReversedDateStringFromToday(1).".csv"))
		{
			print f1 "Time,Num_of_CCRs_Per_Sec\n";
			close(f1);
		}
	 }
        


	for (my $h=0;$h<24;$h++)
	{
		my $HOUR=sprintf("%02d", $h);
		for (my $m=0;$m<60;$m+=5)
		{
			my $MIN=sprintf("%02d", $m);
    			foreach my $server (@DRA_SERVERS)
    			{
				my $getCCR_TPS_Average = "$catcommand $TMP_DESTINATION_FOLDER/$DIAM_CMD_RXED_STATS_FILE_PREFIX*$server*".getReversedDateStringFromToday(1).".stats | grep START,DRA,diam_cmd_rxed_stats_by_peer,".getReversedDateStringFromToday(1).",$HOUR-$MIN-00 -A10 | egrep -v ccr | egrep -v START | cut -d, -f2-4 | sed ':a;N;{s/\\n/,/};ba' | tr ',' '\\n' | awk 'BEGIN {total=0} {total += \$1 / 300} END {print total}' |  awk '{printf \"%.f\\n\", \$1}'";
                                my $CCR_TPS_Average = executeCommandForReturn($getCCR_TPS_Average);
				chomp $CCR_TPS_Average;
        			printLog("PRINTING LINE:    $HOUR:$MIN,$CCR_TPS_Average\n");
				if (open(f1,">>".$FINAL_DESTINATION_FOLDER."/".$OUTPUT_FILE_CCR_TPS."_".$server."_".getReversedDateStringFromToday(1).".csv"))	
				{
					print f1 "$HOUR:$MIN,$CCR_TPS_Average\n";
					close(f1);
				}
			}
		}
	}
	plotGraph($FINAL_DESTINATION_FOLDER."/".$OUTPUT_FILE_CCR_TPS."_".$DRA_SERVERS[0]."_".getReversedDateStringFromToday(1).".csv",$FINAL_DESTINATION_FOLDER."/".$OUTPUT_FILE_CCR_TPS."_".$DRA_SERVERS[1]."_".getReversedDateStringFromToday(1).".csv");
}


# SUBROUTINES


sub help
{
print <<EO_USAGE;

Jiras:
CO Scripts:  COSC-xxx

Help for script $scriptName 

It is to count the Total number ccr_init plus ccr_updt plus ccr_term requests received by the DRA every 5 mins. i

DETAILS:
Script caculates the AVERAGE of requests per second (CCR per second received by the DRA) by diving the TOTAL by 300.
The avarages are taken every 5 mins and stored in daily filesA

Copyright (c) Tango Telecom 2020
Author: Hector Barriga

All rights reserved.
This document contains confidential and proprietary information of
Tango Telecom and any reproduction, disclosure, or use in whole or
in part is expressly prohibited, except as may be specifically
authorized by prior written agreement or permission of Tango Telecom.

version $version - First version

USAGE:

    -d Destination folder of the reports

    OPTIONAL:

    -v Verbose mode.

EO_USAGE
}

##############################################################################
# copyCdrFilesToTmp()
# copies the CDR files to a temporary folder
##############################################################################
sub copyCdrFilesToTmp
{
    foreach my $server (@DRA_SERVERS)
    {
        #LOCAL FIRST
	if ( $server eq $host_name)
	{
        	my $cmd = "cp $DIAM_CMD_RXED_STATS_DIR/$DIAM_CMD_RXED_STATS_FILE_PREFIX*".getReversedDateStringFromToday(1).".stats $TMP_DESTINATION_FOLDER";
		printLog("Copy files [$cmd]");
		executeCommand($cmd);
	}
	else
	{
                my $cmd = "scp $server:$DIAM_CMD_RXED_STATS_DIR/$DIAM_CMD_RXED_STATS_FILE_PREFIX*".getReversedDateStringFromToday(1).".stats $TMP_DESTINATION_FOLDER";	
		printLog("SCP Transfering files [$cmd]");
		executeCommand($cmd);
	}
    }
}

##############################################################################
# plotGraph()
# Graph the reports into png files
#############################################################################
sub plotGraph
{
	open my $fh0, '<', $_[0] or die $!;
	my (@w, @x, @y, @z);
	while (<$fh0>) 
	{
	   next if $. == 1;            # skip header line
	   push @w, (split /,/)[0];   # push 'Time every 5 mins' into @w array
	   push @x, (split /,/)[1];   # push 'First machine CCR TPS' into @x array
	}
	close $fh0;

        open my $fh1, '<', $_[1] or die $!;
        while (<$fh1>) 
	{
           next if $. == 1;            # skip header line
           push @y, (split /,/)[1];   # push 'Secondary machine CCR TPS' into @x array
       	}
       	close $fh1;

	for ($i = 0; $i < 288; $i++) {
    		$z[$i] = $x[$i] + $y[$i];
	}


	# Read in the data from a file

	my $mygraph = GD::Graph::lines->new(600, 300);
	$mygraph->set(
	    x_label     => 'Time (EVERY 5 Minutes)',
	    y_label     => 'Num of CCRs per Second',
	    title       => "gx CCR TPS Received By The DRA [".getReversedDateStringFromToday(1)."]",
#	    # Draw datasets in 'solid', 'dashed' and 'dotted-dashed' lines
	    line_types  => [1, 1, 2],
	    # Set the thickness of line
	    line_width  => 1,
	    # Set colors for datasets
	    dclrs       => ['black','lorange','green'],
	    x_label_skip => 30,
	) or warn $mygraph->error;

	$mygraph->set_legend_font(GD::gdMediumBoldFont);
	$mygraph->set_legend($DRA_SERVERS[0],$DRA_SERVERS[1],'TOTAL TPS');
	my @data = (\@w, \@x, \@y, \@z);
	my $myimage = $mygraph->plot(\@data) or die $mygraph->error();


	# Open a file for writing
	open(PICTURE, ">$FINAL_DESTINATION_FOLDER/gx_CCR_TPS_received_by_DRAs_".getReversedDateStringFromToday(1).".png") or die("Cannot open file for writing");

	# Make sure we are writing to a binary stream
	binmode PICTURE;

	# Add .png to filename
	print PICTURE $myimage->png;
	close PICTURE;
}

##############################################################################
# printLog()
# Prints a log
##############################################################################
sub printLog
{
    my $line = shift;
    my $file = $DEBUG_FILE;
    my $date = getDateString();
    $file =~ s/<DATE>/$date/g;
    $line = $scriptName.":::[".getDateTimeString()."] -- ".$line."\n";


    if (!$LOG_INITIALISED_FLAG)
    {
        die "Can't divert STDERR to $file, please check the correct permissions" if (!open(STDERR, ">>$file"));
        die "Can't open $file, please create the relevant folders" if (!open($fh_debug_log,">>$file"));
                $LOG_INITIALISED_FLAG = 1;
    }
    else
    {
        print $fh_debug_log $line;
        print $line if ($VERBOSE_FLAG);
    }
}

##############################################################################
# getTime()
# will return the curent date and time
##############################################################################
sub getTime
{
 my ($Second, $Minute, $Hour, $Day, $Month, $Year, $WeekDay, $DayOfYear, $IsDST) = localtime(time);

 if($Hour < 10)   {  $Hour = "0" . $Hour ; }
 if($Minute < 10) {  $Minute = "0" . $Minute ; }
 if($Second < 10) {  $Second = "0" . $Second ; }
 my $Month = $Month + 1 ;
 if($Month < 10)
 {
 $Month = "0" .
 $Month ;
 }
 if($Day < 10)
 {
  $Day = "0" . $Day ;
 }
 if($Year >= 100)
 {
  $Year = $Year - 100 ;
  $Year = $Year + 2000;
 }
 return  ($Second, $Minute, $Hour, $Day, $Month, $Year, $WeekDay, $DayOfYear, $IsDST);
}

##############################################################################
# getTimeString()
# will return the current date and time
##############################################################################
sub getDateTimeString
{
 my @all= getTime();
 return $all[3]."/".$all[4]."/".$all[5]." ".$all[2].":".$all[1].":".$all[0];
}


##############################################################################
# getDateString()
# will return the current date and time
##############################################################################
sub getDateString
{
 my @all= getTime();
 return $all[3]."".$all[4]."".$all[5];
}
##############################################################################
# a day in the past()
# will return the current date and time
##############################################################################
sub getReversedDateStringFromToday
{
 my $days = shift;
 my $yesterday = time - ((60*60*24)*$days);
 return POSIX::strftime('%Y-%m-%d', localtime($yesterday));
}
##############################################################################
# executeCommand
# Will Execute a system command
##############################################################################
sub executeCommand
{
    my $cmd = shift;
    my @result = system ($cmd);
    printLog ("Executing command [$cmd] result: @result");
}

##############################################################################
# executeCommandForReturn
# Will Execute a system command and return the results in an array
##############################################################################
sub executeCommandForReturn
{
    my $cmd = shift;
    printLog ("Executing command [$cmd]");
    return `$cmd`;
}

