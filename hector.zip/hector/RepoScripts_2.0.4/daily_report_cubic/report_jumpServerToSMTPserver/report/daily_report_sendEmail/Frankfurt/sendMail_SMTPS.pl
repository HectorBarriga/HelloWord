#!/usr/bin/perl
##############################################################################
# Filename:    sendMail.pl
# Revision:    $Revision: 1.0
# Author:      Victor Reus
#              Modified By Hector for Telefonica
#
# This perl sends emails via SMTPS servers.
#
# Copyright (c) Tango Telecom 2018
#
# All rights reserved.
# This document contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or
# in part is expressly prohibited, except as may be specifically
# authorized by prior written agreement or permission of Tango Telecom.
##############################################################################

use Socket;
use Getopt::Std;
use Authen::SASL;
use MIME::Base64;
use Net::SMTPS;
use MIME::Lite;
use POSIX 'strftime';
use Net::Ping;

my @scriptPath = split '/', $0;
my $scriptName = $scriptPath[$#scriptPath];
my $dateNoForma = qx(date -d yesterday +%Y" "%b" "%d);
chomp $dateNoForma;
my $spcmReportDate = qx(date -d yesterday +%Y%m%d);
chomp $spcmReportDate;
my $pcrfReportDate = qx(date -d yesterday +%y%m%d);
chomp $pcrfReportDate;
my $DATE_REFERENCE = getReversedDateStringFromToday(1);

my $subVersion = "\nSend Mail Script version 0.1.0 \n";
$subVersion .= "Copyright by Tango Telecom 2018 (c)\n";
$subVersion .= "All rights reserved.\n\n\n";

# Settings
my $remoteSshHost="CUBICftangoB";
my $remoteSshHealthcheckPrimServer="CUBICftangoA";
my $remoteSshHealthcheckSecondServer="CUBICftangoB";
my $remoteSshPCRFHost="CUBICdtangoB";
my $remotePrimaryCluster="frankfurt";
my $primaryReportedServer="ftangoA";
my $secondaryReportedServer="ftangoB";

my $mailFrom    = 'tango.support.stats@tangotelecom.com';
my $mailTo      = 'hector.barriga@tangotelecom.com';
my $realName    = "Test Email";
my $subject     = '[Cubic] Daily Traffic Reports '.$dateNoForma;
my $body        = "Test Line One.\nTest Line Two.\n";
my $mailServer  = 'localhost';
my $domainSvr   = "secure.emailsrvr.com";
my $vebose = 0;
my $sendAsHtml = 1;
my $USERNAME = 'hector.barriga@tangotelecom.com';
my $PASSWORD = 'fer52Fhy';

if ( 0 == getopts( "uh:f:t:n:s:b:x:d:U:P:v" ) )
{
    usage();
    exit 0;
}

if ( defined($opt_f) && defined($opt_t) && defined($opt_n) && defined($opt_x))
{

 $mailFrom    = $opt_f;
 $mailTo      = $opt_t;
 $realName    = $opt_n;
 $mailServer  = $opt_x;
 $domainSvr   = $opt_d;
 $verbose     = 1 if ($opt_v);

 my $p = Net::Ping->new();
 if ($p->ping($mailServer))
 {
   print "Ping to SMTP Server $mailServer OK. Continue ...\n";
 }
 else
 {
   die "No connection to SMTP Server $mailServer. Ping Failed. Bye";
 }

`timeout 30 ssh $remoteSshHost true`;
 if ($? == 0)
 {
   print "Ssh to Target Server $remoteSshHost OK. Continue ...\n";
 }
 else
 {
    die "No connection to Target Server $remoteSshHost. Ssh failed, Bye";
 }

 if (defined($opt_b))
 {
  $body =  $opt_b;
 }
 else
 {
   my @allOutPut;
   foreach(@commands)
   {
    my $cmd = $_;
    print "Command $cmd \n" if ($verbose);
    my @output = `$cmd`;
    push (@allOutPut,@output);
   }

   $body = join("",@allOutPut);

 }

 unless ( -e "/tango/logs/stats/daily_report_sendEmail/$remotePrimaryCluster.done.".getReversedDateStringFromToday(1) )
 {
        main();
        system("touch /tango/logs/stats/daily_report_sendEmail/$remotePrimaryCluster.done.$DATE_REFERENCE");
        exit(0);
 }
 else
 {
        exit(0);
 }

}

usage();
exit(0);

sub usage
{
    print <<EO_USAGE;

$subVersion

Usage: $scriptName

    -f <from>
    -t <to@server.com>
    -n <Display Name>
    -x <smtp server IP>

     OPTIONS
     -b <body>

     With -b option script will send a simple text

    Most common options:
    -v Displays verbose


EO_USAGE
}

sub help
{
    print <<EO_HELP;

Help for script $scriptName (c) Tango Telecom 2018


    -f <from>
    -t <to@server.com>
    -n <Display Name>
    -x <smtp server IP>

     OPTIONS
     -b <body>

     With -b option script will send a simple text

    Most common options:
    -v Displays verbose



EO_HELP

    usage();
}



sub main()
{
        if (defined($opt_U) && defined($opt_P))
        {
                $USERNAME = $opt_U;
                $PASSWORD = $opt_P;
                sendMail_SMTPS();
        }
        else
        {
                sendMail();
        }
}

sub sendMail()
{

        $main::SIG{'INT'} = 'closeSocket';

        my($proto)      = getprotobyname("tcp")        || 6;
        my($port)       = getservbyname("SMTP", "tcp") || 465;


        my($name,$aliases,$addrtype,$length,$serverAddr) = gethostbyname($mailServer);


        if (! defined($length))
        {
         die('gethostbyname failed.');
        }

        print "Name: $name\n" if ($verbose);
        print "Alias: $aliases\n" if ($verbose);
        print "Type: $addrtype\n" if ($verbose);
        print "Length: $length\n" if ($verbose);
        print "Address: $serverAddr\n" if ($verbose);

        socket(SMTP, AF_INET(), SOCK_STREAM(), $proto)  or die("socket: $!");


        my $packFormat = 'S n a4 x8';   # Windows 95, SunOs 4.1+, Fedora

        connect(SMTP, pack($packFormat, AF_INET(), $port, $serverAddr)) or die("connect: $!");
        print "Connected\n" if ($verbose);

        sleep(1);

        print "Sending SMTP protocol...\n" if ($verbose);
#        sendSMTP(1, "HELO\r\n");
        sendSMTP(1, "HELO $domainSvr\r\n");
        sleep(6);
        sendSMTP(1, "MAIL From: <$mailFrom>\r\n");
        sleep(1);
#       sendSMTP(1, "RCPT To: <$mailTo>\r\n");
        @allRcpt = split /,/,$mailTo;
        foreach(@allRcpt)
        {
         my $mailRcpt = $_;
         sendSMTP(1, "RCPT To: <$mailRcpt>\r\n");
         sleep(1);
        }
        sendSMTP(1, "DATA\r\n");
        sleep(1);
        send(SMTP, "From: $realName\r\n", 0);
        sleep(1);
#       send(SMTP, "To: $mailTo\r\n", 0); # Disabled the to, to get undisclosed recipients.
        send(SMTP, "Subject: $subject\r\n\r\n", 0);
        sleep(1);
        if ($sendAsHtml)
        {
           send(SMTP, "MIME-Version: 1.0 \r\n", 0);
           send(SMTP, "Content-Type: text/html; \r\n", 0);
           $body = "<html><body><pre>$body</pre></body></html>";
        }
        else
        {
           send(SMTP, $body, 0);
        }
        sleep(2);
        sendSMTP(1, "\r\n.\r\n");
        sendSMTP(1, "QUIT\r\n");
        sleep(1);

        close(SMTP);
}

sub closeSocket
{
    close(SMTP);
    die("SMTP socket closed [SIGINT]\n");
}


sub sendSMTP
{
    my($debug)  = shift;
    my($buffer) = @_;


    print STDERR ("> $buffer") if $verbose;
    send(SMTP, $buffer, 0);


    recv(SMTP, $buffer, 200, 0);
    print STDERR ("< $buffer") if $verbose;


    return( (split(/ /, $buffer))[0] );
}

sub sendMail_SMTPS()
{
        system("mkdir /tango/logs/stats/healthcheck/$remotePrimaryCluster/") unless ( -e "/tango/logs/stats/healthcheck/$remotePrimaryCluster/" );
        system("mkdir /tango/logs/stats/healthcheck/$remotePrimaryCluster/$primaryReportedServer") unless ( -e "/tango/logs/stats/healthcheck/$remotePrimaryCluster/$primaryReportedServer" );
        system("mkdir /tango/logs/stats/healthcheck/$remotePrimaryCluster/$secondaryReportedServer") unless ( -e "/tango/logs/stats/healthcheck/$remotePrimaryCluster/$secondaryReportedServer" );
        system("mkdir /tango/logs/stats/spcm_reports/$remotePrimaryCluster/") unless ( -e "/tango/logs/stats/spcm_reports/$remotePrimaryCluster/" );
        system("mkdir /tango/logs/stats/spcm_reports/$remotePrimaryCluster/$spcmReportDate") unless ( -e "/tango/logs/stats/spcm_reports/$remotePrimaryCluster/$spcmReportDate" );
        system("mkdir /tango/logs/stats/dra_reports/$remotePrimaryCluster/") unless ( -e "/tango/logs/stats/dra_reports/$remotePrimaryCluster/" );
        system("mkdir /tango/logs/stats/pcrf_reports/$remotePrimaryCluster/") unless ( -e "/tango/logs/stats/pcrf_reports/$remotePrimaryCluster/");

        my $cmd = "scp $remoteSshHealthcheckPrimServer:/tango/logs/healthcheck/healthcheck*.log.*$spcmReportDate* /tango/logs/stats/healthcheck/$remotePrimaryCluster/$primaryReportedServer/";
        executeCommand($cmd);
        my $cmd = "scp $remoteSshHealthcheckSecondServer:/tango/logs/healthcheck/healthcheck*.log.*$spcmReportDate* /tango/logs/stats/healthcheck/$remotePrimaryCluster/$secondaryReportedServer/";
        executeCommand($cmd);
        my $cmd = "scp $remoteSshHost:/tango/logs/stats/spcm_reports/$remotePrimaryCluster/$spcmReportDate/*$spcmReportDate.csv.zip /tango/logs/stats/spcm_reports/$remotePrimaryCluster/$spcmReportDate/";
        executeCommand($cmd);
        my $cmd = "scp $remoteSshHost:/tango/logs/stats/dra_reports/$remotePrimaryCluster/*$DATE_REFERENCE* /tango/logs/stats/dra_reports/$remotePrimaryCluster/";
        executeCommand($cmd);
        my $cmd = "scp $remoteSshHost:/tango/logs/stats/pcrf_reports/$remotePrimaryCluster/*$DATE_REFERENCE* /tango/logs/stats/pcrf_reports/$remotePrimaryCluster/";
        executeCommand($cmd);
        my $cmd = "scp $remoteSshPCRFHost:/tango/logs/report/pcrf_report/*$pcrfReportDate.txt /tango/logs/stats/pcrf_reports/$remotePrimaryCluster/";
        executeCommand($cmd);

        my $getLastRedHealthcheck = "";
        my $getLastGreenHealthcheck = "";
        $getLastRedHealthcheckPrimServer = executeCommandForReturn("find /tango/logs/stats/healthcheck/$remotePrimaryCluster/$primaryReportedServer/ -name healthcheck_red.log*$spcmReportDate* | tail -1 | cut -f 9 -d' '");
        chomp $getLastRedHealthcheckPrimServer;
        $getLastGreenHealthcheckPrimServer = executeCommandForReturn("find /tango/logs/stats/healthcheck/$remotePrimaryCluster/$primaryReportedServer/ -name healthcheck_green.log*$spcmReportDate* | tail -1 | cut -f 9 -d' '") if ( $getLastRedHealthcheck eq "");
        chomp $getLastGreenHealthcheckPrimServer;
        if ( $getLastGreenHealthcheckPrimServer eq "" )
        {
                $getLastRedHealthcheckPrimServer = $getLastRedHealthcheckPrimServer;
                $healthcheckAlertsPrimServer = " There are some ALERTS/Failures. See healthcheck report below";
        }
        else
        {
                $getLastRedHealthcheckPrimServer = $getLastGreenHealthcheckPrimServer;
                $healthcheckAlertsPrimServer = " [OK] No Alerts or Failures";
        }
        $getLastRedHealthcheckSecondServer = executeCommandForReturn("find /tango/logs/stats/healthcheck/$remotePrimaryCluster/$secondaryReportedServer/ -name healthcheck_red.log*$spcmReportDate*  | tail -1 | cut -f 9 -d' '");
        chomp $getLastRedHealthcheckSecondServer;
        $getLastGreenHealthcheckSecondServer = executeCommandForReturn("find /tango/logs/stats/healthcheck/$remotePrimaryCluster/$secondaryReportedServer/ -name healthcheck_green.log*$spcmReportDate* | tail -1 | cut -f 9 -d' '") if ( $getLastRedHealthcheck eq "");
        chomp $getLastGreenHealthcheckSecondServer;
        if ( $getLastGreenHealthcheckSecondServer eq "" )
        {
                $getLastRedHealthcheckSecondServer = $getLastRedHealthcheckPrimServer;
                $healthcheckAlertsSecondServer = " There are some ALERTS/Failures. See healthcheck report below";
        }
        else
        {
                $getLastRedHealthcheckSecondServer = $getLastGreenHealthcheckSecondServer;
                $healthcheckAlertsSecondServer = " [OK] No Alerts or Failures";
        }
        my $getCPUusagePrimServer = executeCommandForReturn("ssh $remoteSshHealthcheckPrimServer '/usr/local/bin/healthCheck.sh | grep CPU | grep $primaryReportedServer' | cut -d':' -f2");
        chomp $getCPUusagePrimServer;
        my $getCPUusageSecondServer = executeCommandForReturn("ssh $remoteSshHealthcheckSecondServer '/usr/local/bin/healthCheck.sh | grep CPU | grep $secondaryReportedServer'| cut -d':' -f2");
        chomp $getCPUusageSecondServer;
        my $getMemmoryusagePrimServer = executeCommandForReturn("ssh $remoteSshHealthcheckPrimServer '/usr/local/bin/healthCheck.sh | grep MEMORY | grep $primaryReportedServer' | cut -d':' -f2");
        chomp $getMemmoryusagePrimServer;
        my $getMemmoryusageSecondServer = executeCommandForReturn("ssh $remoteSshHealthcheckSecondServer '/usr/local/bin/healthCheck.sh | grep MEMORY | grep $secondaryReportedServer'| cut -d':' -f2");
        chomp $getMemmoryusageSecondServer;
        my $getFreeMemmoryPrimServer = executeCommandForReturn("/usr/bin/cat $getLastRedHealthcheckPrimServer | grep 'Free Memmory'");
        chomp $getFreeMemmoryPrimServer;
        my $getSwapMemmoryPrimServer = executeCommandForReturn("/usr/bin/cat $getLastRedHealthcheckPrimServer | grep 'Swap Memmory'");
        chomp $getSwapMemmoryPrimServer;
        my $getFileSysPrimServer = executeCommandForReturn("/usr/bin/cat $getLastRedHealthcheckPrimServer | grep 'All FileSystems'");
        chomp $getFileSysPrimServer;
        my $getMysqlPrimServer = executeCommandForReturn("/usr/bin/cat $getLastRedHealthcheckPrimServer | grep 'MYSQL RUNNING'");
        chomp $getMysqlPrimServer;
        my $getSlaveStatusPrimServer = executeCommandForReturn("/usr/bin/cat $getLastRedHealthcheckPrimServer | awk '/Slave/ || /Error/' | awk '{print}' ORS='<br>'");
        chomp $getMysqlPrimServer;
        my $getFreeMemmorySecondServer = executeCommandForReturn("/usr/bin/cat $getLastRedHealthcheckSecondServer | grep 'Free Memmory'");
        chomp $getFreeMemmorySecondServer;
        my $getSwapMemmorySecondServer = executeCommandForReturn("/usr/bin/cat $getLastRedHealthcheckSecondServer | grep 'Swap Memmory'");
        chomp $getSwapMemmorySecondServer;
        my $getFileSysSecondServer = executeCommandForReturn("/usr/bin/cat $getLastRedHealthcheckSecondServer | grep 'All FileSystems'");
        chomp $getFileSysSecondServer;
        my $getMysqlSecondServer = executeCommandForReturn("/usr/bin/cat $getLastRedHealthcheckSecondServer | grep 'MYSQL RUNNING'");
        my $getSlaveStatusSecondServer = executeCommandForReturn("/usr/bin/cat $getLastRedHealthcheckSecondServer | awk '/Slave/ || /Error/' | awk '{print}' ORS='<br>'");
        chomp $getMysqlSecondServer;


        my $getMaxCCRTPSPrimaryServer = executeCommandForReturn("/usr/bin/cat /tango/logs/stats/dra_reports/$remotePrimaryCluster/gx_CCR_TPS_received_by_ALL_DRAs_*$primaryReportedServer*$DATE_REFERENCE.csv | egrep -v Num_of_CCRs_Per_Sec | cut -d, -f2 | sort -k1 -n | tail -1");
        chomp $getMaxCCRTPSPrimaryServer;
        my $getMaxCCRTPSHimePrimaryServer = executeCommandForReturn("/usr/bin/cat /tango/logs/stats/dra_reports/$remotePrimaryCluster/gx_CCR_TPS_received_by_ALL_DRAs_*$primaryReportedServer*$DATE_REFERENCE.csv | grep '$getMaxCCRTPSPrimaryServer' | cut -d, -f1 | tail -1");
        chomp $getMaxCCRTPSHimePrimaryServer;

        my $getMaxCCRTPSSecondaryServer = executeCommandForReturn("/usr/bin/cat /tango/logs/stats/dra_reports/$remotePrimaryCluster/gx_CCR_TPS_received_by_ALL_DRAs_*$secondaryReportedServer*$DATE_REFERENCE.csv | egrep -v Num_of_CCRs_Per_Sec | cut -d, -f2 | sort -k1 -n | tail -1");
        chomp $getMaxCCRTPSSecondaryServer;
        my $getMaxCCRTPSHimeSecondaryServer = executeCommandForReturn("/usr/bin/cat /tango/logs/stats/dra_reports/$remotePrimaryCluster/gx_CCR_TPS_received_by_ALL_DRAs_*$SecondaryReportedServer*$DATE_REFERENCE.csv | grep '$getMaxCCRTPSSecondaryServer' | cut -d, -f1 | tail -1");
        chomp $getMaxCCRTPSHimeSecondaryServer;


        my $getMaxActiveGxSessions = executeCommandForReturn("/usr/bin/cat /tango/logs/stats/pcrf_reports/$remotePrimaryCluster/MaxActiveGxSessions_$DATE_REFERENCE.txt");
        chomp $getMaxActiveGxSessions;
        my $getUniqueMsisdn = executeCommandForReturn("/usr/bin/zcat /tango/logs/stats/spcm_reports/$remotePrimaryCluster/$spcmReportDate/daily_cubic_report_kpi_$spcmReportDate.csv.zip | egrep -v NUMBER_OF_UNIQUE_MSISDN | cut -d, -f1");
        my $healthreport0 = executeCommandForReturn("/usr/bin/cat $getLastRedHealthcheckPrimServer | awk '{print}' ORS='<br>'");
        my $healthreport1 = executeCommandForReturn("/usr/bin/cat $getLastRedHealthcheckSecondServer | awk '{print}' ORS='<br>'");
        my $report0 = executeCommandForReturn("/usr/bin/zcat /tango/logs/stats/spcm_reports/$remotePrimaryCluster/$spcmReportDate/daily_cubic_report_kpi_$spcmReportDate.csv.zip | awk '{print}' ORS='<br>'");
        my $report1 = executeCommandForReturn("/usr/bin/zcat /tango/logs/stats/spcm_reports/$remotePrimaryCluster/$spcmReportDate/daily_cubic_report_plans_$spcmReportDate.csv.zip | awk '{print}' ORS='<br>'");
        my $report2 = executeCommandForReturn("/usr/bin/zcat /tango/logs/stats/spcm_reports/$remotePrimaryCluster/$spcmReportDate/daily_cubic_report_rules_$spcmReportDate.csv.zip | awk '{print}' ORS='<br>'");
        my $report3 = executeCommandForReturn("/usr/bin/zcat /tango/logs/stats/spcm_reports/$remotePrimaryCluster/$spcmReportDate/daily_cubic_report_per_country_network_$spcmReportDate.csv.zip | awk '{print}' ORS='<br>' | sed 's/ //g'");
        my $report4 = executeCommandForReturn("/usr/bin/cat /tango/logs/stats/pcrf_reports/$remotePrimaryCluster/PCRF_dtangoB_$pcrfReportDate.txt");
        my $report5 = executeCommandForReturn("/usr/bin/zcat /tango/logs/stats/spcm_reports/$remotePrimaryCluster/$spcmReportDate/daily_cubic_report_expiry_date_per_msisdn_per_plan_activation_$spcmReportDate.csv.zip | awk '{print}' ORS='<br>'");
        my $primaryReportedServerWithSlash = $primaryReportedServer."_".$DATE_REFERENCE;
        my $secondaryReportedServerWithSlash = $secondaryReportedServer."_".$DATE_REFERENCE;

        my @attached = ("/tango/logs/stats/dra_reports/$remotePrimaryCluster/gx_CCR_TPS_received_by_ALL_DRAs_$primaryReportedServerWithSlash.csv","/tango/logs/stats/dra_reports/$remotePrimaryCluster/gx_CCR_TPS_received_by_ALL_DRAs_$secondaryReportedServerWithSlash.csv","/tango/logs/stats/pcrf_reports/$remotePrimaryCluster/ACTIVE_GX_SESSIONS_received_by_ALL_PCRFs_$primaryReportedServerWithSlash.csv","/tango/logs/stats/pcrf_reports/$remotePrimaryCluster/ACTIVE_GX_SESSIONS_received_by_ALL_PCRFs_$secondaryReportedServerWithSlash.csv","/tango/logs/stats/spcm_reports/$remotePrimaryCluster/$spcmReportDate/daily_cubic_report_kpi_$spcmReportDate.csv.zip","/tango/logs/stats/spcm_reports/$remotePrimaryCluster/$spcmReportDate/daily_cubic_report_plans_$spcmReportDate.csv.zip","/tango/logs/stats/spcm_reports/$remotePrimaryCluster/$spcmReportDate/daily_cubic_report_rules_$spcmReportDate.csv.zip","/tango/logs/stats/spcm_reports/$remotePrimaryCluster/$spcmReportDate/daily_cubic_report_per_country_network_$spcmReportDate.csv.zip","/tango/logs/stats/pcrf_reports/$remotePrimaryCluster/PCRF_dtangoB_$pcrfReportDate.txt","/tango/logs/stats/spcm_reports/$remotePrimaryCluster/$spcmReportDate/daily_cubic_report_expiry_date_per_msisdn_per_plan_activation_$spcmReportDate.csv.zip");

        my $emailRepCluster = ucfirst $remotePrimaryCluster;

        @allRcpt = split /,/,$mailTo;

        foreach(@allRcpt)
        {
                if ($sendAsHtml)
                {
                        send(SMTP, "MIME-Version: 1.0 \r\n", 0);
                        send(SMTP, "Content-Type: text/html; \r\n", 0);
                        $body = "<html><body><pre>$body</pre></body></html>";

                }

                $smtps = Net::SMTPS->new("$mailServer", Port => 587,  doSSL => 'starttls', SSL_version=>'TLSv1', Debug => (1));
                $ret = $smtps->auth ($USERNAME, $PASSWORD, 'LOGIN' ) or die( "Could not authenticate with server [$!].\n");


                $mailRcpt = $_;
                $msg = MIME::Lite ->new (
                From => $mailFrom,
                To => $mailRcpt,
                Subject => $subject,
                Type    =>'multipart/related'
                );
                $msg->attach(
                Type => 'text/html',
                Data => qq{
                <body>
<h2>[<font color="blue">$emailRepCluster</font>] Daily Traffic Reports $dateNoForma</h2>
<pre style="color:green;"><b>Overall Information:</b>
 - Number Of Unique Msisdns = $getUniqueMsisdn - gx CCR Traffic Peak:<font color="blue" size="2"><i>     Report for both machines separately <b>New!</b></i></font>
      - $primaryReportedServer             = $getMaxCCRTPSPrimaryServer TPS at $getMaxCCRTPSHimePrimaryServer
      - $secondaryReportedServer             = $getMaxCCRTPSSecondaryServer TPS at $getMaxCCRTPSHimeSecondaryServer
 - Active GX Sessions       = $getMaxActiveGxSessions (Max peak - All PCRFs)
 - CPU Usage:
      - $primaryReportedServer             =$getCPUusagePrimServer
      - $secondaryReportedServer             =$getCPUusageSecondServer
 - Memmory Usage:
      - $primaryReportedServer             =$getMemmoryusagePrimServer
      - $primaryReportedServer             = $getFreeMemmoryPrimServer
      - $primaryReportedServer             = $getSwapMemmoryPrimServer
      - $secondaryReportedServer             =$getMemmoryusageSecondServer
      - $secondaryReportedServer             = $getFreeMemmorySecondServer
      - $secondaryReportedServer             = $getSwapMemmorySecondServer
 - FileSystem:
      - $primaryReportedServer             = $getFileSysPrimServer
      - $secondaryReportedServer             = $getFileSysSecondServer
 - MySQL Database:
      - $primaryReportedServer             = $getMysqlPrimServer
      - $secondaryReportedServer             = $getMysqlSecondServer
 - MySQL Slave Status:
      $getSlaveStatusPrimServer
$getSlaveStatusSecondServer
 - Healthcheck:
      - $primaryReportedServer             =$healthcheckAlertsPrimServer
      - $secondaryReportedServer             =$healthcheckAlertsSecondServer</pre><br>
<hr>
<h3> DRA REPORT: </h3>
<table cellpadding="8" style="white-space:nowrap;border:1px solid black;border-collapse:collapse">
<tr><th align="left"; bgcolor='#79BCF9'> gx CCR TPS Received by ALL DRAs [$emailRepCluster]</th></tr>
<tr><td><img src='gx_CCR_TPS_received_by_DRAs_$DATE_REFERENCE.png'</td></tr>
<tr><td><i> You can find csv files attached</i></td></tr>
</table>
<br><hr>
<h3> SIMULTANEUS GX ACTIVE SESSIONS REPORT: <font color="blue" size="2"><i>It now includes new four PCRF instances New!</i></font></h3>
<table cellpadding="8" style="white-space:nowrap;border:1px solid black;border-collapse:collapse">
<tr><th align="left"; bgcolor='#79BCF9'> Active gx Sessions Generated by ALL 4 PCRFs [$emailRepCluster]</th></tr>
<tr><td><img src='ACTIVE_GX_SESSIONS_generated_by_ALL_PCRFs_$DATE_REFERENCE.png'</td></tr>
<tr><td><i> You can find csv files attached</i></td></tr>
</table>
<br><hr>
<h3> SPCM REPORTS:</h3>
<table cellpadding="2" style="white-space:nowrap;border:1px solid black;border-collapse:collapse">
<tr><th align="left"; bgcolor='#79BCF9'>daily_cubic_report_expiry_date_per_msisdn_per_plan_activation_$spcmReportDate.csv [$emailRepCluster]</font></th></tr>
<tr><td><i> You can find csv file attached</i></td></tr>
</table>
<br>
<table cellpadding="2" style="white-space:nowrap;border:1px solid black;border-collapse:collapse">
<tr><th align="left"; bgcolor='#79BCF9'>daily_cubic_report_kpi_$spcmReportDate.csv [$emailRepCluster]</th></tr>
<tr><td>$report0</td></tr>
<tr><td><i> You can find csv file attached</i></td></tr>
</table>
<br>
<table cellpadding="2" style="white-space:nowrap;border:1px solid black;border-collapse:collapse">
<tr><th align="left"; bgcolor='#79BCF9'>daily_cubic_report_plans_$spcmReportDate.csv [$emailRepCluster]</th></tr>
<tr><td>$report1</td></tr>
<tr><td><i> You can find csv file attached</i></td></tr>
</table>
<br>
<table cellpadding="2" style="white-space:nowrap;border:1px solid black;border-collapse:collapse">
<tr><th align="left"; bgcolor='#79BCF9'>daily_cubic_report_rules_$spcmReportDate.csv [$emailRepCluster]</th></tr>
<tr><td>$report2</td></tr>
<tr><td><i> You can find csv file attached</i></td></tr>
</table>
<br>
<table cellpadding="2" style="white-space:nowrap;border:1px solid black;border-collapse:collapse">
<tr><th align="left"; bgcolor='#79BCF9'>daily_cubic_report_per_country_network_$spcmReportDate.csv [$emailRepCluster]</th></tr>
<tr><td><i> You can find csv file attached</i></td></tr>
</table>
<br>
<table cellpadding="2" style="white-space:nowrap;border:1px solid black;border-collapse:collapse">
<tr><th align="left"; bgcolor='#79BCF9'>daily_cubic_report_per_msisdn_counters_$spcmReportDate.csv [$emailRepCluster]</th></tr>
<tr><td>  <i>Big CSV file, find it at ftangoB:/tango/logs/stats/spcm_reports/$remotePrimaryCluster/</i>  </td></tr>
</table>
<br>
<table cellpadding="2" style="white-space:nowrap;border:1px solid black;border-collapse:collapse">
<tr><th align="left"; bgcolor='#79BCF9'>daily_cubic_report_per_msisdn_per_country_$spcmReportDate.csv [$emailRepCluster]</th></tr>
<tr><td>  <i>Big CSV file, find it at ftangoB:/tango/logs/stats/spcm_reports/$remotePrimaryCluster/</i>  </td></tr>
</table>
<br>
<table cellpadding="2" style="white-space:nowrap;border:1px solid black;border-collapse:collapse">
<tr><th align="left"; bgcolor='#79BCF9'>daily_cubic_report_per_msisdn_per_country_purchased_plans_$spcmReportDate.csv [$emailRepCluster]</th></tr>
<tr><td>  <i>Big CSV file, find it at ftangoB:/tango/logs/stats/spcm_reports/$remotePrimaryCluster/</i>  </td></tr>
</table>
<br><hr>
<h3> PCRF REPORT: </h3>
<table cellpadding="2" style="white-space:nowrap;border:1px solid black;border-collapse:collapse">
<tr><th align="left"; bgcolor='#79BCF9'>PCRF_dtangoB_$pcrfReportDate.txt</th></tr>
<tr><td><i> You can find csv file attached</i></td></tr>
</table>
<br><hr>
<h3> HEALTCHCHECK REPORT: </h3>
<table cellpadding="2" style="white-space:nowrap;border:1px solid black;border-collapse:collapse">
<tr><th align="left"; bgcolor='#79BCF9'>Healthcheck $primaryReportedServer [$emailRepCluster]</th></tr>
<tr><td>$healthreport0</td></tr>
</table>
<br>
<table cellpadding="2" style="white-space:nowrap;border:1px solid black;border-collapse:collapse">
<tr><th align="left"; bgcolor='#79BCF9'>Healthcheck $secondaryReportedServer [$emailRepCluster]</th></tr>
<tr><td>$healthreport1</td></tr>
</table>

                </body>
                },
                );

                while (@attached)
                {
                        $msg->attach('Type' => 'application/octet-stream',
                        'Encoding' => 'base64',
                        'Path' => shift @attached);
                }

                $msg->attach(
                    Type => 'image/png',
                    Id   => "gx_CCR_TPS_received_by_DRAs_$DATE_REFERENCE.png",
                    Path => "/tango/logs/stats/dra_reports/$remotePrimaryCluster/gx_CCR_TPS_received_by_DRAs_$DATE_REFERENCE.png",
                );
                $msg->attach(
                    Type => 'image/png',
                    Id   => "ACTIVE_GX_SESSIONS_generated_by_ALL_PCRFs_$DATE_REFERENCE.png",
                    Path => "/tango/logs/stats/pcrf_reports/$remotePrimaryCluster/ACTIVE_GX_SESSIONS_generated_by_ALL_PCRFs_$DATE_REFERENCE.png",
                );
                $smtps ->mail($mailFrom);
                $smtps->to($mailRcpt);
                $smtps->data();
                $smtps->datasend( $msg->as_string() );
                $smtps->dataend();
                $smtps->quit;
        }
}

##############################################################################
# a day in the past()
# will return the current date and time
##############################################################################
sub getReversedDateStringFromToday
{
 my $days = shift;
 my $yesterday = time - ((60*60*24)*$days);
 return POSIX::strftime('%Y-%m-%d', localtime($yesterday));
}
##############################################################################
# executeCommand
# Will Execute a system command
##############################################################################
sub executeCommand
{
    my $cmd = shift;
    my @result = system ($cmd);
}

##############################################################################
# executeCommandForReturn
# Will Execute a system command and return the results in an array
##############################################################################
sub executeCommandForReturn
{
    my $cmd = shift;
    return `$cmd`;
}