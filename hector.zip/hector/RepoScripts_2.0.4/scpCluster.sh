#!/bin/bash
# Initial Settings
site=TELEFONICA #MOBILYOCSTRIAL #TELEFONICA
whiteliststring=Hostname
blackliststring=
convertRemoteEtcHostAliasFrom=
convertRemoteEtcHostAliasTo=
convertRemoteEtcHostAliasFrom_2=
convertRemoteEtcHostAliasTo_2=
convertRemoteEtcHostAliasFrom_3=
convertRemoteEtcHostAliasTo_3=
etcHosts=/etc/hosts


if [ -z "$whiteliststring" ] || [ "$whiteliststring" == "none" ];then
        whiteliststring=''
fi
if [ -z "$blackliststring" ];then
        blackliststring='none'
fi

convertRemoteHost()
{
if [ "$in" == "$convertRemoteEtcHostAliasFrom" ];then
        in=$convertRemoteEtcHostAliasTo
elif [ "$in" == "$convertRemoteEtcHostAliasFrom_2" ];then
        in=$convertRemoteEtcHostAliasTo_2
elif [ "$in" == "$convertRemoteEtcHostAliasFrom_3" ];then
        in=$convertRemoteEtcHostAliasTo_3
fi

}

while getopts f:u:d:p:m:h option;
do
        case $option in
                f) file=$OPTARG;;
                u) user=$OPTARG;;
                d) destDir=$OPTARG;;
                p) pattern=$OPTARG;;
                m) etcHosts=$OPTARG;;
                h) echo "
        Usage: scpCluster.sh

        This sh script is to scp a file (only one file) accross all remote machines especified in $etcHosts
        to the same source directory

        Version:     0.1.0
        Author:      Hector Barriga
        Copyright (c) Tango Telecom 2017

               Options:

               -h <help>                Show help

               -d <Dest Dir>    Destination directory

               -u <Dest user>   Remote server's user. You will need to enter password for each transfer

               -f <Source file> File that is to be transfered

               -p <Dest host>   Destination hosts. Note, you can use a pattern from $etcHosts. It is
                                useful do you want to send file to all machines that belong to a cluster.
                                You can add multiple paterns or hostnames separated by commas

               -m <etc hosts>   Use another etc hosts in case $etcHosts is not compatible

               `tput setaf 1`IMPORTANT: flag \"-f\" is mandatory if using any other flags.
               Otherwise flags will be ignored and file will be transfered to all machines under the same
               source directory and tango user will be used`tput sgr0`

               Examples:

               e.g. /tango/logs/scpCluster.sh foo.txt
                    It transfers foo.txt to all machines under same source direcotry /tango/logs/
                    Note that dir and file have to have tango permissions

               e.g. ./scpCluster -f foo.txt -d /tmp -u root
                    It transfers foo.txt to all machines under /tmp directory.
                    Note /tmp and zoo.txt have to have root permissions

               e.g. /tango/logs/scpCluster.sh -f foo.txt -p NAC,DMZ -m /tango/logs/COSTAFF/hector/sh_scripts/hosts
                    It transfers foo.txt to ONLY those machines whose hostnames have patterns \"NAC\" and \"DMZ\" and are present in /tango/logs/COSTAFF/hector/sh_scripts/hosts
                    in the $etcHosts and under the same source directory /tango/logs/
                    Note dir and file have to have tango permissions

               "; h="true";;
        esac
done

if [ "$h" != "true" ];then
if [ ! -z "$file" ] && [ -z "$pattern" ] && [ -z "$destDir" ] && [ -z "$etcHosts" ];then
        echo -e "\n`tput setaf 1`Flag -p or -d or -m is not defined, bye`tput sgr0`\n"
        exit
fi
if [ ! -z "$file" -a $# -lt 3 -a ! -z "$etcHosts" ] || [  -z "$file"  -a $# -ne 1 ] || [  -z "$file"  -a "$1" == "-f" ];then
        echo -e "\n`tput setaf 1`Flag -f is not defined, bye`tput sgr0`\n"
        exit
fi
if [ "$1" == "-m" -o "$2" == "-m" -o "$3" == "-m" -o "$4" == "-m" ] && [ -z "$file" ];then
        echo -e "\n`tput setaf 1`Flag -f is not defined, bye`tput sgr0`\n"
        exit
fi
hostname=$(hostname)
if [ ! -z "$pattern" ];then
        listOfPatternsArray=(`echo ${pattern} | sed 's/,/ /g'`)
        listOfPatternsArrayLengh=${#listOfPatternsArray[@]}
else
        listOfPatternsArray="#"
        listOfPatternsArrayLengh=1
fi

if [ -z "$file" ];then
        file=$1
fi
if [ -z "$user" ];then
        user=$(whoami)
fi
if [ -z "$destDir" ];then
        realPath=$(realpath "$file")
        destDir=$(echo $realPath | rev | cut -d"/" -f 2- | rev)
fi
for (( j=0;j<$listOfPatternsArrayLengh;j++))
do
if [ "$site" == "ZainSudan" ];then
        if [ "$user" == "root" ];then
                cat $etcHosts | grep tango | egrep "#" | egrep -v NAC |  egrep -v DMZ | egrep "${listOfPatternsArray[$j]}" | egrep -v $hostname | awk '{print $4}' | while read in;do echo -e "\n`tput setaf 3`scp $file root@$in:$destDir`tput sgr0`";scp $file root@$in:$destDir;done
                if [ -z "$pattern" ] && [ "$site" == "TELEFONICA" ];then
                        echo -e "\n`tput setaf 3`scp $file root@IPXMIATCRTE1DMZ_drews:$destDir`tput sgr0`";scp $file root@IPXMIATCRTE1DMZ_drews:$destDir
                        echo -e "\n`tput setaf 3`scp $file root@TESTBEDRTE1_oam:$destDir`tput sgr0`";scp $file root@TESTBEDRTE1_oam:$destDir
                fi
        else
                cat $etcHosts | grep tango | egrep "#" | egrep -v NAC | egrep -v DMZ | egrep "${listOfPatternsArray[$j]}" | egrep -v $hostname | awk '{print $4}' | while read in;do echo -e "\n`tput setaf 3`scp $file $user@$in:$destDir`tput sgr0`";scp $file $user@$in:$destDir;done
                if [ -z "$pattern" ] && [ "$site" == "TELEFONICA" ];then
                        echo -e "\n`tput setaf 3`scp $file tango@IPXMIATCRTE1DMZ_drews:$destDir`tput sgr0`";scp $file tango@IPXMIATCRTE1DMZ_drews:$destDir
                        echo -e "\n`tput setaf 3`scp $file tango@TESTBEDRTE1_oam:$destDir`tput sgr0`";scp $file tango@TESTBEDRTE1_oam:$destDir
                fi
        fi
elif [ "$site" == "MOBILYOCSTRIAL" ];then
        if [ "$user" == "root" ];then
                echo -n "`tput setaf 1`root Password = UNKOWN`tput sgr0`"
                cat $etcHosts | grep tango | egrep "#" | egrep "${listOfPatternsArray[$j]}" | egrep -v $hostname | awk '{print $5}' | while read in;do echo -e "\n`tput setaf 3`scp $file root@$in:$destDir`tput sgr0`";scp $file root@$in:$destDir;done
        else
                cat $etcHosts | grep tango | egrep "#" | egrep "${listOfPatternsArray[$j]}" | egrep -v $hostname | awk '{print $5}' | while read in;do echo -e "\n`tput setaf 3`scp $file $user@$in:$destDir`tput sgr0`";scp $file $user@$in:$destDir;done
        fi
elif [ "$site" == "GITElSalvador" ] || [ "$site" == "Telcel" ] || [ "$site" == "TELEFONICA" ];then
        if [ "$user" == "root" ];then
                if [ "$site" == "TELEFONICA" ];then
                        echo -n "`tput setaf 2`root Password = bernabeuT0ur`tput sgr0`"
                else
                        echo -n "`tput setaf 1`root Password = UNKOWN`tput sgr0`"
                fi
                cat $etcHosts | grep "$whiteliststring" | egrep "#" | egrep "${listOfPatternsArray[$j]}" | egrep -v $hostname | egrep -v "$blackliststring" | awk '{print $5}' | while read in;do convertRemoteHost;echo -e "\n`tput setaf 3`scp $file root@$in:$destDir`tput sgr0`";scp $file root@$in:$destDir;done
        else
                cat $etcHosts | grep "$whiteliststring" | egrep "#" | egrep "${listOfPatternsArray[$j]}" | egrep -v $hostname | egrep -v "$blackliststring" | awk '{print $5}' | while read in;do convertRemoteHost;echo -e "\n`tput setaf 3`scp $file $user@$in:$destDir`tput sgr0`";scp $file $user@$in:$destDir;done
        fi
fi
done
fi