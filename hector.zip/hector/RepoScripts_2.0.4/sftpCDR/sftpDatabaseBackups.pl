#!/usr/bin/perl
#############################################################################
# Filename:    sftpCDR.pl
# Revision:    $Revision: 1.3 $
# Author:      Victor Reus, MH - secure part
#
# This perl script FTPs the CDRs and generates an output to a given folder.
#
# Copyright (c) Tango Telecom 2005
#
# All rights reserved.
# This document contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or
# in part is expressly prohibited, except as may be specifically
# authorized by prior written agreement or permission of Tango Telecom.
# History:
# 1.3 First try to FTP then copy into backup folder
# 1.4 DP - dont remove files: ftp yesterday's zip files (*yyyymmdd*.zip)
# 1.5 ***
# 1.6 - add configurable extention files (.zip,.bz2)...etc
# 	add sftp passwordless - configurable
# 	correction of bug- last file was not transfered missing chomp
# 	add proper log file
# 1.7 - add date format for Solaris. If running solaris check line 40-43!! and use the correct one
##############################################################################
use Getopt::Std;
use Expect;
use Sys::Hostname;
use Config::Simple
# Req IO::Pty !! please install


our $LOGINF=1;
our $LOGWRN=1;
our $LOGERR=1;
my $debug = 1;


my $cfgfile = "/tango/scripts/Generic/houseKeeping/sftpCDR/sftpCDR_DBtoNH.cfg";

if ( 0 == getopts( "uhc:o:r:b:l:dp:" ) )
{
    usage();
    exit 0;
}

if ( defined( $opt_h ) )
{
    usage();
    exit 0;
}

if ( defined( $opt_c ) )
{
    $cfgfile = $opt_c;
}

if ( defined( $opt_o ) )
{
    $daysOld = $opt_o;
}
else
{
    $daysOld = 1;
}

if ( defined( $opt_r ) )
{
    $destFileName = $opt_r;
}
else
{
    $destFileName = "FILE";
}

# This is the Date pattern to look for files... adjust as per your date format!!
# use this for Linux
my $date=`date --date='$daysOld days ago' '+%Y%m%d'`;
#use this for Solaris
#my $date=`TZ=GMT+24 date +%Y%m%d`;



my %cfg=();

$nodename = hostname();

print "DBG MAIN - Open cfg file $configfile\n" if($debugInParam);
my $cfg=new Config::Simple($cfgfile) or die Config::Simple->error();


my $originalFolder  = $cfg->param("General.Original_dir");
my $backUpFolder    = $cfg->param("General.Backup_dir") ;
#added log file and ext files
#$logFileFolder   = $cfg->param("General.sftpLogFile");
my $logFile      = $cfg->param("General.sftpLogFile");
my $ext             = $cfg->param("General.extentionFiles") ;

my $usePassword            = $cfg->param("FTP.passwordlessConn") ;
my $host            = $cfg->param("FTP.host") ;
my $port            = $cfg->param("FTP.port") ;
my $user            = $cfg->param("FTP.user") ;
my $password        = $cfg->param("FTP.password") ;
my $remoteFolder    = $cfg->param("FTP.remote_dir") ;



$usePassword+=0;
$debug          = $opt_d if ( defined( $opt_d) );
$backUpFolder   = $opt_b if ( defined( $opt_b) );
$logFileFolder  = $opt_l if ( defined( $opt_l) );
$port           = $opt_p if ( defined( $opt_p) );

#`mkdir -p $backUpFolder`;
#`/bin/find $logFileFolder -type f -name "sftpCDR*.log" -mtime +30 -exec /bin/rm -f {} \\;`;

#open the log file to record all transactions
unless(open (FH_LOG,">>$logFile"))
{
	print "Erro: unable to open logfile $logFile - $!\n";
	exit 1;
}


chomp($date);
my $date2=`date '+%Y%m%d_%H:%M:%S'`;
chomp($date2);
print FH_LOG "\n- --------------------------------------\n";
print FH_LOG "        sftp log event Start\n";
print FH_LOG "        Current DATE:$date2 \n";
print FH_LOG "        Files Date  :$date \n";
print FH_LOG "--------------------------------------\n";



my @allFiles = `cd $originalFolder 2>>/dev/null; ls *$date*$ext 2>>/dev/null`;


print FH_LOG "DBG: Target Files @allFiles\n" if ($debug);

my $Files2Do = @allFiles;
if ($Files2Do <= 0)
{
   print FH_LOG " WRN : No files found with date pattern $date and Extention = $ext in $originalFolder!\n" if ($LOGWRN);
	&closeLog;
   exit 0;
}
	my @FilesFtpied;
	print "Value of usePassword == $usePassword\n";
	if($usePassword==0)
	{
		@FilesFtpied =  &sftpcmd(@allFiles);
	}
	else
	{
		@FilesFtpied =  &sftpNopass(@allFiles);
	}
print FH_LOG "This is the number of files to do: $Files2Do\n" if ($debug);


&closeLog;
exit 0;



###################################### SUBS
#
sub closeLog
{
	print FH_LOG "\n-------------- END -------------------\n";
	print FH_LOG "----------------------------------------\n";
	close(FH_LOG);
}

sub sftpNopass
{
	my $result = "";
	my $nrOfFiles = 0;
	my $passwordPrompt = "ftpUser@20.20.101.47's password:";

	my @ftpFiles = @_;
	my @FileUploaded;

	$portStr = "";
 	$portStr = "-oPort=$port" if ($port ne "");


	print FH_LOG "DEBUG: Doing /usr/bin/sftp $portStr $user\@$host Passwordless\n" if ($debug);
	$command = Expect->spawn("/usr/bin/sftp $portStr $user\@$host") or die "Couldn't start program: sftp !$\n";

	
	if ($command->expect(100,"sftp>"))
	{
		$command->send("cd $remoteFolder \n");
                print FH_LOG "DEBUG: sftp in $remoteFolder\n";
		if ($command->expect(100,"sftp>"))
		{
			$command->send("lcd $originalFolder\n");
			if ($command->expect(100,"sftp>"))
			{

				foreach (@ftpFiles)
				{
					chomp($_);
					$command->send("put $_\n");
					if ($command->expect(24000,"sftp>"))
					{
						$result = $command->exp_before();
						if (($result !~ /Couldn/i) && ($result !~ /denied/i) && ($result !~ /error/i))
                     				{
                        				$upFILE{"$_"} = 1;
                        				chomp($result);
                        				print FH_LOG "INF: File $_ succesfully uploaded - .\n" if ($LOGINF);
                     				}
                     				else
                        			{
                                 			print FH_LOG "ERR: File $_ unsuccesfully uploaded. - $result\n" if ($LOGERR);
                        			}

                  			}						
					if ( defined( $opt_r ) )
					{
						$command->send("rename $_ $destFileName\n");
						print FH_LOG "INFO: rename $_ $destFileName\n" if ($LOGERR);
						print "rename $_ $destFileName\n";
					}
               			}
				sleep(5);
               			$command->send("bye\n");
            		}
         	}
      }

}

sub sftpcmd
{
   my $result = "";
   my $nrOfFiles = 0;
   my $passwordPrompt = "ftpUser@20.20.101.47's password:";

   my @ftpFiles = @_;
   my @FileUploaded;

   $portStr = "";
   $portStr = "-oPort=$port" if ($port ne "");


   print FH_LOG "DEBUG: Doing /usr/bin/sftp $portStr $user\@$host\n" if ($debug);
   $command = Expect->spawn("/usr/bin/sftp $portStr $user\@$host") or die "Couldn't start program: sftp !$\n";

#if($command->expect(55,$passwordPrompt)){
# i commented this because each server has a diff string expecting the password... so wait a bit and send the password
   $command->log_stdout(0);
	print FH_LOG "DEBUG: password is $password\n" if ($debug);
	sleep(10);
      $command->send("$password\n");
      if ($command->expect(100,"sftp>"))
      {
         $command->send("cd $remoteFolder \n");
		print FH_LOG "DEBUG: sftp in $remoteFolder\n";
         if ($command->expect(100,"sftp>"))
         {
            $command->send("lcd $originalFolder\n");
            if ($command->expect(100,"sftp>"))
            {

               foreach (@ftpFiles)
               {
                  $command->send("put $_\n");
			chomp($_);
                  if ($command->expect(24000,"sftp>"))
                  {
                     $result = $command->exp_before();
                     if (($result !~ /Couldn/i) && ($result !~ /denied/i) && ($result !~ /error/i))
                     {
                        $upFILE{"$_"} = 1;
			chomp($result);
                        print FH_LOG "INF: File $_ succesfully uploaded - .\n" if ($LOGINF);
                     }
		     else
			{
				 print FH_LOG "ERR: File $_ unsuccesfully uploaded. - $result\n" if ($LOGERR);
			}

                  }
		  if ( defined( $opt_r ) )
		  {
			$command->send("rename $_ $destFileName\n");
			print FH_LOG "INFO: rename $_ $destFileName\n" if ($LOGERR);
	     		print "rename $_ $destFileName\n";
		  }
               }
		sleep (5);
               $command->send("bye\n");
            }
         }
      }
# This will check for the presence of the file (not for the size or more things)

# first fill the array with
#   foreach $lsfile (@lsArr)
#   {
#      $upFILE{"$lsfile"} = 1;
#   }

   foreach $file (@ftpFiles)
   {
     if ($upFILE{"$file"})
     {
        $FileUploaded[$nrOfFiles] = 1;
     }
     $nrOfFiles++;

   }
   return @FileUploaded;
}



sub usage
{
    print "\nsftpCDR version 1.3 \n";
    print "(c) Copyright by Tango Telecom 2007 (c)\n";
    print "All rights reserved.\n\n\n";
    print "sftpCDR.pl parameters\n";
    print "Parameters:\n";
    print " -u = usage\n";
    print " -c CONFIGFILE\n";
    print " -d DEBUG_ON\n";
    print " -o Days Old\n";
    print " -b BACKUP DIR\n";
    print " -l LOG DIR\n";
    print " -r Rename uploaded file. Note: If multiple files, all will get renamed with same name\n";
    print "\n";

print <<EO_USAGE;
Sample config file:
[General]
Original dir     = /tango/data/cdr/repository
Backup dir       = /tango/data/cdr/repobck
Logs dir         = /tango/data/cdr/repobck

[FTP]
host             = 10.19.0.16
port             = 218
user             = tango
password         = silly_password
remote dir       = source/cdr

EO_USAGE
}


# sftp> put CDRtmssvr1.20070424_090014
# Uploading CDRtmssvr1.20070424_090014 to /CDRtmssvr1.20070424_090014
# Couldn't get handle: Permission denied
# sftp> bye

