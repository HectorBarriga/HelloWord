#!/bin/bash
time=$(perl -e '@d=localtime time()-86400; printf "%4d%02d%02d_%02d%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1]')
cd $1
getPullURL=$(git remote -v | grep origin | grep fetch | awk '{print $2}')
echo "Gitlab URL = $getPullURL"
getCommitHash=$(cat .git/logs/HEAD | tail -1 | awk '{print $2}')
echo "Commit hash cat .git/logs/HEAD = $getCommitHash)"
newDir=$1"_COMMIT_"$getCommitHash"_DATE_"$time
mv $1 $newDir
git clone "$getPullURL" "$1"