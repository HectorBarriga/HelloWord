#!/bin/bash

help()
{
echo "
        Usage: restartELK7.4.0.sh

        This sh script is to start, shutdown or check status for ELK7.4.0
        - Elastic Search
        - Kibana.private
        - Kibana.public
        - Logstash
        - Filebeat
        - Metricbeat

        Version:     0.1.0
        Author:      Hector Barriga
        Copyright (c) Tango Telecom 2020

               Flags:
               Notes: These are flags, so not need to add arguments

               -h <help>           Show help

               -s <Shutdown>       Shutdown all ELK services

               -r <Restart>        Restart all ELK services

               -c <Check Status>   Check status of all ELK services

               -m <move logs>      Move all ELK logs under /tango/logs/COSTAFF/trash/


               Examples:

               e.g. restartELK7.4.0.sh -s
                    It shuts down all ELK services
"
}

delay()
{
for (( i=0;i<=$1;i++ ))
do
        echo -n "* "
        sleep 1
done
echo -e "Done\n"
}

if [ "$1" == "-s" ];then
        echo -e "`tput setaf 6`\n====================================== Shutting Down Metricbeat ======================================"
        echo -e "`tput setaf 3`---------------------- RTE3 --------------------\n`tput setaf 2`ssh IPXMIATCRTE3 \"sudo systemctl stop metricbeat\""
        ssh IPXMIATCRTE3 "sudo systemctl stop metricbeat"
        echo -e "`tput setaf 3`---------------------- RTE4 --------------------\n`tput setaf 2`ssh IPXMIATCRTE4 \"sudo systemctl stop metricbeat\""
        ssh IPXMIATCRTE4 "sudo systemctl stop metricbeat"
        echo -e "`tput setaf 3`---------------------- DB5 --------------------\n`tput setaf 2`sudo systemctl stop metricbeat"
        sudo systemctl stop metricbeat
        echo -e "`tput setaf 3`---------------------- DB6 --------------------\n`tput setaf 2`ssh IPXMIATCDB6 \"sudo systemctl stop metricbeat\""
        ssh IPXMIATCDB6 "sudo systemctl stop metricbeat"
        echo -e "`tput setaf 3`---------------------- DB7 --------------------\n`tput setaf 2`ssh IPXMIATCDB7 \"sudo systemctl stop metricbeat\""
        ssh IPXMIATCDB7 "sudo systemctl stop metricbeat"
        echo -e "`tput setaf 6`\n====================================== Shutting Down Filebeat-7.4.0 ======================================"
        echo -e "`tput setaf 3`---------------------- NH1 --------------------\n`tput setaf 2`ssh IPXMIATCNH1 \"sudo systemctl stop filebeat-7.4.0\""
        ssh IPXMIATCNH1 "sudo systemctl stop filebeat-7.4.0"
        echo -e "`tput setaf 3`---------------------- NH2 --------------------\n`tput setaf 2`ssh IPXMIATCNH2 \"sudo systemctl stop filebeat-7.4.0\""
        ssh IPXMIATCNH2 "sudo systemctl stop filebeat-7.4.0"
        echo -e "`tput setaf 3`---------------------- RTE1 --------------------\n`tput setaf 2`ssh IPXMIATCRTE1 \"sudo systemctl stop filebeat-7.4.0\""
        ssh IPXMIATCRTE1 "sudo systemctl stop filebeat-7.4.0"
        echo -e "`tput setaf 3`---------------------- RTE2 --------------------\n`tput setaf 2`ssh IPXMIATCRTE2 \"sudo systemctl stop filebeat-7.4.0\""
        ssh IPXMIATCRTE2 "sudo systemctl stop filebeat-7.4.0"
        echo -e "`tput setaf 3`---------------------- RTE3 --------------------\n`tput setaf 2`ssh IPXMIATCRTE3 \"sudo systemctl stop filebeat\""
        ssh IPXMIATCRTE3 "sudo systemctl stop filebeat"
        echo -e "`tput setaf 3`---------------------- RTE4 --------------------\n`tput setaf 2`ssh IPXMIATCRTE4 \"sudo systemctl stop filebeat\""
        ssh IPXMIATCRTE4 "sudo systemctl stop filebeat"
        echo -e "`tput setaf 3`---------------------- SPCM1 --------------------\n`tput setaf 2`ssh IPXMIATCSPCM1 \"sudo systemctl stop filebeat-7.4.0\""
        ssh IPXMIATCSPCM1 "sudo systemctl stop filebeat-7.4.0"
        echo -e "`tput setaf 3`---------------------- SPCM2 --------------------\n`tput setaf 2`ssh IPXMIATCSPCM2 \"sudo systemctl stop filebeat-7.4.0\""
        ssh IPXMIATCSPCM2 "sudo systemctl stop filebeat-7.4.0"
        echo -e "`tput setaf 3`---------------------- GTP1 --------------------\n`tput setaf 2`ssh IPXMIATCGTP1 \"sudo systemctl stop filebeat-7.4.0\""
        ssh IPXMIATCGTP1 "sudo systemctl stop filebeat-7.4.0"
        echo -e "`tput setaf 3`---------------------- GTP2 --------------------\n`tput setaf 2`ssh IPXMIATCGTP2 \"sudo systemctl stop filebeat-7.4.0\""
        ssh IPXMIATCGTP2 "sudo systemctl stop filebeat-7.4.0"
        echo -e "`tput setaf 3`---------------------- GTP3 --------------------\n`tput setaf 2`ssh IPXMIATCGTP3 \"sudo systemctl stop filebeat-7.4.0\""
        ssh IPXMIATCGTP3 "sudo systemctl stop filebeat-7.4.0"
        echo -e "`tput setaf 3`---------------------- GTP4 --------------------\n`tput setaf 2`ssh IPXMIATCGTP4 \"sudo systemctl stop filebeat-7.4.0\""
        ssh IPXMIATCGTP4 "sudo systemctl stop filebeat-7.4.0"
        echo -e "`tput setaf 3`---------------------- GTP5 --------------------\n`tput setaf 2`ssh IPXMIATCGTP5 \"sudo systemctl stop filebeat-7.4.0\""
        ssh IPXMIATCGTP5 "sudo systemctl stop filebeat-7.4.0"
        echo -e "`tput setaf 3`---------------------- GTP6 --------------------\n`tput setaf 2`ssh IPXMIATCGTP6 \"sudo systemctl stop filebeat-7.4.0\""
        ssh IPXMIATCGTP6 "sudo systemctl stop filebeat-7.4.0"
        echo -e "`tput setaf 6`\n====================================== Shutting Down Logstash ======================================"
        echo -e "`tput setaf 3`---------------------- DB5 --------------------\n`tput setaf 2`sudo systemctl stop logstash"
        sudo systemctl stop logstash
        echo -e "`tput setaf 3`---------------------- DB6 --------------------\n`tput setaf 2`ssh IPXMIATCDB6 \"sudo systemctl stop logstash\""
        ssh IPXMIATCDB6 "sudo systemctl stop logstash"
        echo -e "`tput setaf 3`---------------------- RTE3 --------------------\n`tput setaf 2`ssh IPXMIATCDB6 \"sudo systemctl stop logstash\""
        ssh IPXMIATCRTE3 "sudo systemctl stop logstash"
        echo -e "`tput setaf 3`---------------------- RTE4 --------------------\n`tput setaf 2`ssh IPXMIATCDB6 \"sudo systemctl stop logstash\""
        ssh IPXMIATCRTE4 "sudo systemctl stop logstash"
        echo "`tput setaf 6`====================================== Shutting Down Kibana Private and Public ======================================"
        echo -e "`tput setaf 3`---------------------- DB5 --------------------\n`tput setaf 2`sudo systemctl stop kibana.private"
        sudo systemctl stop kibana.private
        echo -e "`tput setaf 3`---------------------- DB5 --------------------\n`tput setaf 2`sudo systemctl stop kibana.public"
        sudo systemctl stop kibana.public
        echo -e "`tput setaf 3`---------------------- DB6 --------------------\n`tput setaf 2`ssh IPXMIATCDB6 \"sudo systemctl stop kibana.private\""
        ssh IPXMIATCDB6 "sudo systemctl stop kibana.private"
        echo -e "`tput setaf 3`---------------------- DB6 --------------------\n`tput setaf 2`ssh IPXMIATCDB6 \"sudo systemctl stop kibana.public\""
        ssh IPXMIATCDB6 "sudo systemctl stop kibana.public"
        echo -e "`tput setaf 6`\n====================================== Shutting Down Elastc Search ======================================"
        echo -e "`tput setaf 3`---------------------- DB5 --------------------\n`tput setaf 2`sudo systemctl stop elasticsearch.master"
        sudo systemctl stop elasticsearch.master
        echo "sudo systemctl stop elasticsearch.data"
        sudo systemctl stop elasticsearch.data
        echo "sudo systemctl stop elasticsearch.coordinating"
        sudo systemctl stop elasticsearch.coordinating
        echo -e "`tput setaf 3`\n---------------------- DB6 --------------------\n`tput setaf 2`ssh IPXMIATCDB6 \"sudo systemctl stop elasticsearch.master\""
        ssh IPXMIATCDB6 "sudo systemctl stop elasticsearch.master"
        echo "ssh IPXMIATCDB6 \"sudo systemctl stop elasticsearch.data\""
        ssh IPXMIATCDB6 "sudo systemctl stop elasticsearch.data"
        echo "ssh IPXMIATCDB6 \"sudo systemctl stop elasticsearch.coordinating\""
        ssh IPXMIATCDB6 "sudo systemctl stop elasticsearch.coordinating"
        echo -e "`tput setaf 3`\n---------------------- DB7 --------------------\n`tput setaf 2`ssh IPXMIATCDB7 \"sudo systemctl stop elasticsearch.master\""
        ssh IPXMIATCDB7 "sudo systemctl stop elasticsearch.master"
        echo "ssh IPXMIATCDB7 \"sudo systemctl stop elasticsearch.data\""
        ssh IPXMIATCDB7 "sudo systemctl stop elasticsearch.data"
        echo "`tput sgr0`"
elif [ "$1" == "-r" ];then
        echo -e "`tput setaf 6`\n====================================== Restarting Elastc Search ======================================"
        echo -e "`tput setaf 3`---------------------- Master --------------------\n`tput setaf 2`sudo systemctl start elasticsearch.master"
        sudo systemctl start elasticsearch.master
        delay 60
        echo -e "ssh IPXMIATCDB6 \"sudo systemctl start elasticsearch.master\""
        ssh IPXMIATCDB6 "sudo systemctl start elasticsearch.master"
        delay 60
        echo -e "ssh IPXMIATCDB7 \"sudo systemctl start elasticsearch.master\""
        ssh IPXMIATCDB7 "sudo systemctl start elasticsearch.master"
        delay 60
        echo -e "`tput setaf 3`---------------------- Data --------------------\n`tput setaf 2`sudo systemctl start elasticsearch.data"
        sudo systemctl start elasticsearch.data
        delay 60
        echo "ssh IPXMIATCDB6 \"sudo systemctl start elasticsearch.data\""
        ssh IPXMIATCDB6 "sudo systemctl start elasticsearch.data"
        delay 60
        echo "ssh IPXMIATCDB7 \"sudo systemctl start elasticsearch.data\""
        ssh IPXMIATCDB7 "sudo systemctl start elasticsearch.data"
        delay 60
        echo -e "`tput setaf 3`---------------------- Coordinating --------------------\n`tput setaf 2`sudo systemctl start elasticsearch.coordinating"
        sudo systemctl start elasticsearch.coordinating
        delay 60
        echo "ssh IPXMIATCDB6 \"sudo systemctl start elasticsearch.coordinating\""
        ssh IPXMIATCDB6 "sudo systemctl start elasticsearch.coordinating"
        delay 60
        echo "`tput setaf 6`=================================== Restarting Kibana Private and Public =================================="
        echo -e "`tput setaf 3`---------------------- DB5 --------------------\n`tput setaf 2`sudo systemctl start kibana.private"
        sudo systemctl start kibana.private
        delay 10
        echo -e "`tput setaf 3`---------------------- DB5 --------------------\n`tput setaf 2`sudo systemctl start kibana.public"
        sudo systemctl start kibana.public
        delay 10
        echo -e "`tput setaf 3`---------------------- DB6 --------------------\n`tput setaf 2`ssh IPXMIATCDB6 \"sudo systemctl start kibana.private\""
        ssh IPXMIATCDB6 "sudo systemctl start kibana.private"
        delay 10
        echo -e "`tput setaf 3`---------------------- DB6 --------------------\n`tput setaf 2`ssh IPXMIATCDB6 \"sudo systemctl start kibana.public\""
        ssh IPXMIATCDB6 "sudo systemctl start kibana.public"
        delay 10
        echo "`tput setaf 6`=================================== Restarting Logstash =================================="
        echo -e "`tput setaf 3`---------------------- DB5 --------------------\n`tput setaf 2`sudo systemctl start logstash"
        sudo systemctl start logstash
        DB5LogstashPort5044=$(netstat -an | grep ":5044 " | wc -l)
        while [ $DB5LogstashPort5044 -eq 0 ]
        do
                echo -n "* "
                DB5LogstashPort5044=$(netstat -an | grep ":5044 " | wc -l)
                sleep 1
        done
        echo -e "Done\n"
        echo -e "`tput setaf 3`---------------------- DB6 --------------------\n`tput setaf 2`ssh IPXMIATCDB6 \"sudo systemctl start logstash\""
        ssh IPXMIATCDB6 "sudo systemctl start logstash"
        DB6LogstashPort5044=$(ssh IPXMIATCDB6 'netstat -an | grep ":5044 " | wc -l')
        while [ $DB6LogstashPort5044 -eq 0 ]
        do
                echo -n "* "
                DB6LogstashPort5044=$(ssh IPXMIATCDB6 'netstat -an | grep ":5044 "' | wc -l)
                sleep 1
        done
        echo -e "Done\n"
        echo -e "`tput setaf 3`---------------------- RTE3 --------------------\n`tput setaf 2`ssh IPXMIATCRTE3 \"sudo systemctl start logstash\""
        ssh IPXMIATCRTE3 "sudo systemctl start logstash"
        RTE3LogstashPort5044=$(ssh IPXMIATCRTE3 'netstat -an | grep ":5044 " | wc -l')
        while [ $RTE3LogstashPort5044 -eq 0 ]
        do
                echo -n "* "
                RTE3LogstashPort5044=$(ssh IPXMIATCRTE3 'netstat -an | grep ":5044 "' | wc -l)
                sleep 1
        done
        echo -e "Done\n"
        echo -e "`tput setaf 3`---------------------- RTE4 --------------------\n`tput setaf 2`ssh IPXMIATCRTE4 \"sudo systemctl start logstash\""
        ssh IPXMIATCRTE4 "sudo systemctl start logstash"
        RTE4LogstashPort5044=$(ssh IPXMIATCRTE4 'netstat -an | grep ":5044 " | wc -l')
        while [ $RTE4LogstashPort5044 -eq 0 ]
        do
                echo -n "* "
                RTE4LogstashPort5044=$(ssh IPXMIATCRTE4 'netstat -an | grep ":5044 "' | wc -l)
                sleep 1
        done
        echo -e "Done\n"
       delay 10
        echo "`tput setaf 6`=================================== Restarting Filebeat7.4.0 =================================="
        echo -e "`tput setaf 3`---------------------- NH1 --------------------\n`tput setaf 2`ssh IPXMIATCNH1 \"sudo systemctl start filebeat-7.4.0\""
        ssh IPXMIATCNH1 "sudo systemctl start filebeat-7.4.0"
        delay 1
        echo -e "`tput setaf 3`---------------------- NH2 --------------------\n`tput setaf 2`ssh IPXMIATCNH2 \"sudo systemctl start filebeat-7.4.0\""
        ssh IPXMIATCNH2 "sudo systemctl start filebeat-7.4.0"
        delay 1
        echo -e "`tput setaf 3`---------------------- RTE1 --------------------\n`tput setaf 2`ssh IPXMIATCRTE1 \"sudo systemctl start filebeat-7.4.0\""
        ssh IPXMIATCRTE1 "sudo systemctl start filebeat-7.4.0"
        delay 1
        echo -e "`tput setaf 3`---------------------- RTE2 --------------------\n`tput setaf 2`ssh IPXMIATCRTE2 \"sudo systemctl start filebeat-7.4.0\""
        ssh IPXMIATCRTE2 "sudo systemctl start filebeat-7.4.0"
        delay 1
        echo -e "`tput setaf 3`---------------------- RTE3 --------------------\n`tput setaf 2`ssh IPXMIATCRTE3 \"sudo systemctl start filebeat\""
        ssh IPXMIATCRTE3 "sudo systemctl start filebeat"
        delay 1
        echo -e "`tput setaf 3`---------------------- RTE4 --------------------\n`tput setaf 2`ssh IPXMIATCRTE4 \"sudo systemctl start filebeat\""
        ssh IPXMIATCRTE4 "sudo systemctl start filebeat"
        delay 1
        echo -e "`tput setaf 3`---------------------- SPCM1 --------------------\n`tput setaf 2`ssh IPXMIATCSPCM1 \"sudo systemctl start filebeat-7.4.0\""
        ssh IPXMIATCSPCM1 "sudo systemctl start filebeat-7.4.0"
        delay 1
        echo -e "`tput setaf 3`---------------------- SPCM2 --------------------\n`tput setaf 2`ssh IPXMIATCSPCM2 \"sudo systemctl start filebeat-7.4.0\""
        ssh IPXMIATCSPCM2 "sudo systemctl start filebeat-7.4.0"
        delay 1
        echo -e "`tput setaf 3`---------------------- GTP1 --------------------\n`tput setaf 2`ssh IPXMIATCGTP1 \"sudo systemctl start filebeat-7.4.0\""
        ssh IPXMIATCGTP1 "sudo systemctl start filebeat-7.4.0"
        delay 1
        echo -e "`tput setaf 3`---------------------- GTP2 --------------------\n`tput setaf 2`ssh IPXMIATCGTP2 \"sudo systemctl start filebeat-7.4.0\""
        ssh IPXMIATCGTP2 "sudo systemctl start filebeat-7.4.0"
        delay 1
        echo -e "`tput setaf 3`---------------------- GTP3 --------------------\n`tput setaf 2`ssh IPXMIATCGTP3 \"sudo systemctl start filebeat-7.4.0\""
        ssh IPXMIATCGTP3 "sudo systemctl start filebeat-7.4.0"
        delay 1
        echo -e "`tput setaf 3`---------------------- GTP4 --------------------\n`tput setaf 2`ssh IPXMIATCGTP4 \"sudo systemctl start filebeat-7.4.0\""
        ssh IPXMIATCGTP4 "sudo systemctl start filebeat-7.4.0"
        delay 1
        echo -e "`tput setaf 3`---------------------- GTP5 --------------------\n`tput setaf 2`ssh IPXMIATCGTP5 \"sudo systemctl start filebeat-7.4.0\""
        ssh IPXMIATCGTP5 "sudo systemctl start filebeat-7.4.0"
        delay 1
        echo -e "`tput setaf 3`---------------------- GTP6 --------------------\n`tput setaf 2`ssh IPXMIATCGTP6 \"sudo systemctl start filebeat-7.4.0\""
        ssh IPXMIATCGTP6 "sudo systemctl start filebeat-7.4.0"
        delay 10
        echo "`tput setaf 6`=================================== Restarting Metricbeat =================================="
        echo -e "`tput setaf 3`---------------------- DB5 --------------------\n`tput setaf 2`sudo systemctl start metricbeat\""
        sudo systemctl start metricbeat
        delay 1
        echo -e "`tput setaf 3`---------------------- DB6 --------------------\n`tput setaf 2`ssh IPXMIATCDB6 \"sudo systemctl start metricbeat\""
        ssh IPXMIATCDB6 "sudo systemctl start metricbeat"
        delay 1
        echo -e "`tput setaf 3`---------------------- DB7 --------------------\n`tput setaf 2`ssh IPXMIATCDB7 \"sudo systemctl start metricbeat\""
        ssh IPXMIATCDB7 "sudo systemctl start metricbeat"
        delay 1
        echo -e "`tput setaf 3`---------------------- RTE3 --------------------\n`tput setaf 2`ssh IPXMIATCRTE3 \"sudo systemctl start metricbeat\""
        ssh IPXMIATCRTE3 "sudo systemctl start metricbeat"
        delay 1
        echo -e "`tput setaf 3`---------------------- RTE4 --------------------\n`tput setaf 2`ssh IPXMIATCRTE4 \"sudo systemctl start metricbeat\""
        ssh IPXMIATCRTE4 "sudo systemctl start metricbeat"
        delay 1
        echo "`tput sgr0`"
elif [ "$1" == "-c" ];then
        echo -e "`tput setaf 6`\n====================================== Check Status Elastc Search ======================================"
        DB5Master1Status=$(sudo systemctl status elasticsearch.master | grep Active | grep running)
        if [ -z "$DB5Master1Status" ];then echo "`tput setaf 3`---- DB5-Master1 `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- DB5-Master1 `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";ESAcc1=yes;fi
        sudo systemctl status elasticsearch.master

        DB5Data1Status=$(sudo systemctl status elasticsearch.data | grep Active | grep running)
        if [ -z "$DB5Data1Status" ];then echo "`tput setaf 3`---- DB5-Data1 `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- DB5-Data1 `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";ESAcc2=yes;fi
        sudo systemctl status elasticsearch.data

        DB5Coord1Status=$(sudo systemctl status elasticsearch.coordinating | grep Active | grep running)
        if [ -z "$DB5Coord1Status" ];then echo "`tput setaf 3`---- DB5-Coord1 `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- DB5-Coord1 `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";ESAcc3=yes;fi
        sudo systemctl status elasticsearch.coordinating

        DB6Master2Status=$(ssh IPXMIATCDB6 "sudo systemctl status elasticsearch.master" | grep Active | grep running)
        if [ -z "$DB6Master2Status" ];then echo "`tput setaf 3`---- DB6-Master2 `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- DB6-Master2 `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";ESAcc4=yes;fi
        ssh IPXMIATCDB6 "sudo systemctl status elasticsearch.master"

        DB6Data2Status=$(ssh IPXMIATCDB6 "sudo systemctl status elasticsearch.data" | grep Active | grep running)
        if [ -z "$DB6Data2Status" ];then echo "`tput setaf 3`---- DB6-Data2 `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- DB6-Data2 `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";ESAcc5=yes;fi
        ssh IPXMIATCDB6 "sudo systemctl status elasticsearch.data"

        DB6Coord2Status=$(ssh IPXMIATCDB6 "sudo systemctl status elasticsearch.coordinating" | grep Active | grep running)
        if [ -z "$DB6Coord2Status" ];then echo "`tput setaf 3`---- DB6-Coord2 `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- DB6-Coord2 `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";ESAcc6=yes;fi
        ssh IPXMIATCDB6 "sudo systemctl status elasticsearch.coordinating"

        DB7Master3Status=$(ssh IPXMIATCDB7 "sudo systemctl status elasticsearch.master" | grep Active | grep running)
        if [ -z "$DB7Master3Status" ];then echo "`tput setaf 3`---- DB7-Master3 `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- DB7-Master3 `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";ESAcc7=yes;fi
        ssh IPXMIATCDB7 "sudo systemctl status elasticsearch.master"

        DB7Data3Status=$(ssh IPXMIATCDB7 "sudo systemctl status elasticsearch.data" | grep Active | grep running)
        if [ -z "$DB7Data3Status" ];then echo "`tput setaf 3`---- DB7-Data3 `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- DB7-Data3 `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";ESAcc8=yes;fi
        ssh IPXMIATCDB7 "sudo systemctl status elasticsearch.data"

        echo "`tput setaf 6`====================================== Check Status Kibiana Private and Public ======================================"
        DB5KibanaPrivateStatus=$(sudo systemctl status kibana.private | grep Active | grep running)
        if [ -z "$DB5KibanaPrivateStatus" ];then echo "`tput setaf 3`---- DB5-Kibana.Private `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- DB5-Kibana.Private `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";KAcc1=yes;fi
        sudo systemctl status kibana.private
        DB5KibanaPublicStatus=$(sudo systemctl status kibana.public | grep Active | grep running)
        if [ -z "$DB5KibanaPublicStatus" ];then echo "`tput setaf 3`---- DB5-Kibana.Public `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- DB5-Kibana.Public `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";KAcc2=yes;fi
        sudo systemctl status kibana.public
        DB6KibanaPrivateStatus=$(ssh IPXMIATCDB6 "sudo systemctl status kibana.private" | grep Active | grep running)
        if [ -z "$DB6KibanaPrivateStatus" ];then echo "`tput setaf 3`---- DB6-Kibana.Private `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- DB6-Kibana.Private `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";KAcc3=yes;fi
        ssh IPXMIATCDB6 "sudo systemctl status kibana.private"
        DB6KibanaPublicStatus=$(ssh IPXMIATCDB6 "sudo systemctl status kibana.public" | grep Active | grep running)
        if [ -z "$DB6KibanaPublicStatus" ];then echo "`tput setaf 3`---- DB6-Kibana.Public `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- DB6-Kibana.Public `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";KAcc4=yes;fi
        ssh IPXMIATCDB6 "sudo systemctl status kibana.public"
        echo "`tput setaf 6`====================================== Check Logstash ======================================"
        DB5LogstashStatus=$(sudo systemctl status logstash | grep Active | grep running)
        DB5LogstashPort5044=$(netstat -an | grep ":5044 ")
        if [ -z "$DB5LogstashStatus" ] || [ -z "$DB5LogstashPort5044" ];then echo "`tput setaf 3`---- DB5-Logstash `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- DB5-Logstash `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";LAcc1=yes;fi
        sudo systemctl status logstash
        DB6LogstashPort5044=$(ssh IPXMIATCDB6 'netstat -an | grep ":5044 "')
        DB6LogstashStatus=$(ssh IPXMIATCDB6 "sudo systemctl status logstash" | grep Active | grep running)
        if [ -z "$DB6LogstashStatus" ] || [ -z "$DB6LogstashPort5044" ];then echo "`tput setaf 3`---- DB6-Logstash `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- DB6-Logstash `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";LAcc2=yes;fi
        ssh IPXMIATCDB6 "sudo systemctl status logstash"
        RTE3LogstashPort5044=$(ssh IPXMIATCRTE3 'netstat -an | grep ":5044 "')
        RTE3LogstashStatus=$(ssh IPXMIATCRTE3 "sudo systemctl status logstash" | grep Active | grep running)
        if [ -z "$RTE3LogstashStatus" ] || [ -z "$RTE3LogstashPort5044" ];then echo "`tput setaf 3`---- RTE3-Logstash `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- RTE3-Logstash `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";LAcc3=yes;fi
        ssh IPXMIATCRTE3 "sudo systemctl status logstash"
        RTE4LogstashPort5044=$(ssh IPXMIATCRTE4 'netstat -an | grep ":5044 "')
        RTE4LogstashStatus=$(ssh IPXMIATCRTE4 "sudo systemctl status logstash" | grep Active | grep running)
        if [ -z "$RTE4LogstashStatus" ] || [ -z "$RTE4LogstashPort5044" ];then echo "`tput setaf 3`---- RTE4-Logstash `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- RTE4-Logstash `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";LAcc4=yes;fi
        ssh IPXMIATCRTE4 "sudo systemctl status logstash"
        echo "`tput setaf 6`====================================== Check Filebeat-7.4.0 ======================================"
        NH1FilebeatStatus=$(ssh IPXMIATCNH1 "sudo systemctl status filebeat-7.4.0" | grep Active | grep running)
        if [ -z "$NH1FilebeatStatus" ];then echo "`tput setaf 3`---- NH1-Filebeat-7.4.0 `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- NH1-Filebeat-7.4.0 `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";FAcc1=yes;fi
        ssh IPXMIATCNH1 "sudo systemctl status filebeat-7.4.0"
        NH2FilebeatStatus=$(ssh IPXMIATCNH2 "sudo systemctl status filebeat-7.4.0" | grep Active | grep running)
        if [ -z "$NH2FilebeatStatus" ];then echo "`tput setaf 3`---- NH2-Filebeat-7.4.0 `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- NH2-Filebeat-7.4.0 `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";FAcc2=yes;fi
        ssh IPXMIATCNH2 "sudo systemctl status filebeat-7.4.0"
        RTE1FilebeatStatus=$(ssh IPXMIATCRTE1 "sudo systemctl status filebeat-7.4.0" | grep Active | grep running)
        if [ -z "$RTE1FilebeatStatus" ];then echo "`tput setaf 3`---- RTE1-Filebeat-7.4.0 `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- RTE1-Filebeat-7.4.0 `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";FAcc3=yes;fi
        ssh IPXMIATCRTE1 "sudo systemctl status filebeat-7.4.0"
        RTE2FilebeatStatus=$(ssh IPXMIATCRTE2 "sudo systemctl status filebeat-7.4.0" | grep Active | grep running)
        if [ -z "$RTE2FilebeatStatus" ];then echo "`tput setaf 3`---- RTE2-Filebeat-7.4.0 `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- RTE2-Filebeat-7.4.0 `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";FAcc4=yes;fi
        ssh IPXMIATCRTE2 "sudo systemctl status filebeat-7.4.0"
        RTE3FilebeatStatus=$(ssh IPXMIATCRTE3 "sudo systemctl status filebeat" | grep Active | grep running)
        if [ -z "$RTE3FilebeatStatus" ];then echo "`tput setaf 3`---- RTE3-Filebeat `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- RTE3-Filebeat `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";FAcc5=yes;fi
        ssh IPXMIATCRTE3 "sudo systemctl status filebeat"
        RTE4FilebeatStatus=$(ssh IPXMIATCRTE4 "sudo systemctl status filebeat" | grep Active | grep running)
        if [ -z "$RTE4FilebeatStatus" ];then echo "`tput setaf 3`---- RTE4-Filebeat `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- RTE4-Filebeat `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";FAcc6=yes;fi
        ssh IPXMIATCRTE4 "sudo systemctl status filebeat"
        SPCM1FilebeatStatus=$(ssh IPXMIATCSPCM1 "sudo systemctl status filebeat-7.4.0" | grep Active | grep running)
        if [ -z "$SPCM1FilebeatStatus" ];then echo "`tput setaf 3`---- SPCM1-Filebeat-7.4.0 `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- SPCM1-Filebeat-7.4.0 `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";FAcc7=yes;fi
        ssh IPXMIATCSPCM1 "sudo systemctl status filebeat-7.4.0"
        SPCM2FilebeatStatus=$(ssh IPXMIATCSPCM2 "sudo systemctl status filebeat-7.4.0" | grep Active | grep running)
        if [ -z "$SPCM2FilebeatStatus" ];then echo "`tput setaf 3`---- SPCM2-Filebeat-7.4.0 `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- SPCM2-Filebeat-7.4.0 `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";FAcc8=yes;fi
        ssh IPXMIATCSPCM2 "sudo systemctl status filebeat-7.4.0"
        GTP1FilebeatStatus=$(ssh IPXMIATCGTP1 "sudo systemctl status filebeat-7.4.0" | grep Active | grep running)
        if [ -z "$GTP1FilebeatStatus" ];then echo "`tput setaf 3`---- GTP1-Filebeat-7.4.0 `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- GTP1-Filebeat-7.4.0 `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";FAcc9=yes;fi
        ssh IPXMIATCGTP1 "sudo systemctl status filebeat-7.4.0"
        GTP2FilebeatStatus=$(ssh IPXMIATCGTP2 "sudo systemctl status filebeat-7.4.0" | grep Active | grep running)
        if [ -z "$GTP2FilebeatStatus" ];then echo "`tput setaf 3`---- GTP2-Filebeat-7.4.0 `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- GTP2-Filebeat-7.4.0 `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";FAcc10=yes;fi
        ssh IPXMIATCGTP2 "sudo systemctl status filebeat-7.4.0"
        GTP3FilebeatStatus=$(ssh IPXMIATCGTP3 "sudo systemctl status filebeat-7.4.0" | grep Active | grep running)
        if [ -z "$GTP3FilebeatStatus" ];then echo "`tput setaf 3`---- GTP3-Filebeat-7.4.0 `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- GTP3-Filebeat-7.4.0 `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";FAcc11=yes;fi
        ssh IPXMIATCGTP3 "sudo systemctl status filebeat-7.4.0"
        GTP4FilebeatStatus=$(ssh IPXMIATCGTP4 "sudo systemctl status filebeat-7.4.0" | grep Active | grep running)
        if [ -z "$GTP4FilebeatStatus" ];then echo "`tput setaf 3`---- GTP4-Filebeat-7.4.0 `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- GTP4-Filebeat-7.4.0 `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";FAcc12=yes;fi
        ssh IPXMIATCGTP4 "sudo systemctl status filebeat-7.4.0"
        GTP5FilebeatStatus=$(ssh IPXMIATCGTP5 "sudo systemctl status filebeat-7.4.0" | grep Active | grep running)
        if [ -z "$GTP5FilebeatStatus" ];then echo "`tput setaf 3`---- GTP5-Filebeat-7.4.0 `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- GTP5-Filebeat-7.4.0 `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";FAcc13=yes;fi
        ssh IPXMIATCGTP5 "sudo systemctl status filebeat-7.4.0"
        GTP6FilebeatStatus=$(ssh IPXMIATCGTP6 "sudo systemctl status filebeat-7.4.0" | grep Active | grep running)
        if [ -z "$GTP6FilebeatStatus" ];then echo "`tput setaf 3`---- GTP6-Filebeat-7.4.0 `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- GTP6-Filebeat-7.4.0 `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";FAcc14=yes;fi
        ssh IPXMIATCGTP6 "sudo systemctl status filebeat-7.4.0"

        echo "`tput setaf 6`====================================== Check Metricbeat ======================================"
        DB5MetricbeatStatus=$(sudo systemctl status metricbeat | grep Active | grep running)
        if [ -z "$DB5MetricbeatStatus" ];then echo "`tput setaf 3`---- DB5-Metricbeat `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- DB5-Metricbeat `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";MAcc1=yes;fi
        sudo systemctl status metricbeat
        DB6MetricbeatStatus=$(ssh IPXMIATCDB6 "sudo systemctl status metricbeat" | grep Active | grep running)
        if [ -z "$DB6MetricbeatStatus" ];then echo "`tput setaf 3`---- DB6-Metricbeat `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- DB6-Metricbeat `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";MAcc2=yes;fi
        ssh IPXMIATCDB6 "sudo systemctl status metricbeat"
        DB7MetricbeatStatus=$(ssh IPXMIATCDB7 "sudo systemctl status metricbeat" | grep Active | grep running)
        if [ -z "$DB7MetricbeatStatus" ];then echo "`tput setaf 3`---- DB7-Metricbeat `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- DB7-Metricbeat `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";MAcc3=yes;fi
        ssh IPXMIATCDB7 "sudo systemctl status metricbeat"
        RTE3MetricbeatStatus=$(ssh IPXMIATCRTE3 "sudo systemctl status metricbeat" | grep Active | grep running)
        if [ -z "$RTE3MetricbeatStatus" ];then echo "`tput setaf 3`---- RTE3-Metricbeat `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- RTE3-Metricbeat `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";MAcc4=yes;fi
        ssh IPXMIATCRTE3 "sudo systemctl status metricbeat"
        RTE4MetricbeatStatus=$(ssh IPXMIATCRTE4 "sudo systemctl status metricbeat" | grep Active | grep running)
        if [ -z "$RTE4MetricbeatStatus" ];then echo "`tput setaf 3`---- RTE4-Metricbeat `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- RTE4-Metricbeat `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";MAcc5=yes;fi
        ssh IPXMIATCRTE4 "sudo systemctl status metricbeat"
        echo -e "`tput setaf 6`\n====================================== FINISHED ======================================"
        if [ "$ESAcc1" == "yes" ] && [ "$ESAcc2" == "yes" ] && [ "$ESAcc3" == "yes" ] && [ "$ESAcc4" == "yes" ] && [ "$ESAcc5" == "yes" ] && [ "$ESAcc6" == "yes" ] && [ "$ESAcc7" == "yes" ] && [ "$ESAcc8" == "yes" ] && [ "$KAcc1" == "yes" ] && [ "$KAcc2" == "yes" ] && [ "$KAcc3" == "yes" ] && [ "$KAcc4" == "yes" ] && [ "$LAcc1" == "yes" ] && [ "$LAcc2" == "yes" ] && [ "$LAcc3" == "yes" ] && [ "$LAcc4" == "yes" ] && [ "$FAcc1" == "yes" ] &&  [ "$FAcc2" == "yes" ] && [ "$FAcc3" == "yes" ] && [ "$FAcc4" == "yes" ] && [ "$FAcc5" == "yes" ] && [ "$FAcc6" == "yes" ] && [ "$FAcc7" == "yes" ] && [ "$FAcc8" == "yes" ] && [ "$FAcc9" == "yes" ] && [ "$FAcc10" == "yes" ] && [ "$FAcc11" == "yes" ] && [ "$FAcc12" == "yes" ] && [ "$FAcc13" == "yes" ] && [ "$FAcc14" == "yes" ] && [ "$MAcc1" == "yes" ] && [ "$MAcc2" == "yes" ] && [ "$MAcc3" == "yes" ] && [ "$MAcc4" == "yes" ] && [ "$MAcc5" == "yes" ];then
                echo "`tput setaf 2`ALL SERVICES ARE ACTIVE AND RUNNING"
        else
                echo "`tput setaf 1`SOME OR ALL SERVICES ARE INACTIVE AND DEAD"
        fi
        echo "`tput setaf 6`======================================================================================"
        echo "`tput sgr0`"
elif [ "$1" == "-m" ];then
        amiroot=$(whoami)
        if [ "$amiroot" != "root" ];then
                echo -e "\n`tput setaf 1`Sorry, restartELK7.4.0.sh -m must be run as root user, bye.`tput sgr0`\n"
        fi
        todayExt=$(perl -e '@d=localtime time(); printf "%4d%02d%02d_%02d%02d%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1],$d[0]')
        echo -e "`tput setaf 6`\n====================================== Move Logs Elastc Search ======================================"
        DB5Master1Status=$(systemctl status elasticsearch.master | grep Active | grep running)
        if [ -z "$DB5Master1Status" ];then echo "`tput setaf 3`---- DB5-Master1 `tput setaf 2`mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/elasticsearch.master/;mv /var/log/elasticsearch.master/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/elasticsearch.master/ `tput setaf 3`----`tput sgr0`";mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/elasticsearch.master/;mv /var/log/elasticsearch.master/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/elasticsearch.master/;else echo "`tput setaf 3`---- DB5-Master1 `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";ESAcc1=yes;fi


        DB5Data1Status=$(systemctl status elasticsearch.data | grep Active | grep running)
        if [ -z "$DB5Data1Status" ];then echo "`tput setaf 3`---- DB5-Data1 `tput setaf 2`mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/elasticsearch.data/;mv /var/log/elasticsearch.data/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/elasticsearch.data/ `tput setaf 3`----`tput sgr0`";mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/elasticsearch.data/;mv /var/log/elasticsearch.data/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/elasticsearch.data/;else echo "`tput setaf 3`---- DB5-Data1 `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";ESAcc2=yes;fi


        DB5Coord1Status=$(systemctl status elasticsearch.coordinating | grep Active | grep running)
        if [ -z "$DB5Coord1Status" ];then echo "`tput setaf 3`---- DB5-Coord1 `tput setaf 2`mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/elasticsearch.coordinating/;mv /var/log/elasticsearch.coordinating/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/elasticsearch.coordinating/ `tput setaf 3`----`tput sgr0`";mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/elasticsearch.coordinating/;mv /var/log/elasticsearch.coordinating/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/elasticsearch.coordinating/;else echo "`tput setaf 3`---- DB5-Coord1 `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";ESAcc3=yes;fi


        DB6Master2Status=$(ssh IPXMIATCDB6 "systemctl status elasticsearch.master" | grep Active | grep running)
        if [ -z "$DB6Master2Status" ];then echo "`tput setaf 3`---- DB6-Master2 `tput setaf 2` ssh IPXMIATCDB6 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/elasticsearch.master/;mv /var/log/elasticsearch.master/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/elasticsearch.master/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCDB6 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/elasticsearch.master/;mv /var/log/elasticsearch.master/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/elasticsearch.master/";else echo "`tput setaf 3`---- DB6-Master2 `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";ESAcc4=yes;fi


        DB6Data2Status=$(ssh IPXMIATCDB6 "systemctl status elasticsearch.data" | grep Active | grep running)
        if [ -z "$DB6Data2Status" ];then echo "`tput setaf 3`---- DB6-Data2 `tput setaf 2` ssh IPXMIATCDB6 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/elasticsearch.data/;mv /var/log/elasticsearch.data/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/elasticsearch.data/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCDB6 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/elasticsearch.data/;mv /var/log/elasticsearch.data/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/elasticsearch.data/";else echo "`tput setaf 3`---- DB6-Data2 `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";ESAcc5=yes;fi


        DB6Coord2Status=$(ssh IPXMIATCDB6 "systemctl status elasticsearch.coordinating" | grep Active | grep running)
        if [ -z "$DB6Coord2Status" ];then echo "`tput setaf 3`---- DB6-Coord2 `tput setaf 2` ssh IPXMIATCDB6 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/elasticsearch.coordinating/;mv /var/log/elasticsearch.coordinating/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/elasticsearch.coordinating/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCDB6 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/elasticsearch.coordinating/;mv /var/log/elasticsearch.coordinating/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/elasticsearch.coordinating/";else echo "`tput setaf 3`---- DB6-Coord2 `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";ESAcc6=yes;fi


        DB7Master3Status=$(ssh IPXMIATCDB7 "systemctl status elasticsearch.master" | grep Active | grep running)
        if [ -z "$DB7Master3Status" ];then echo "`tput setaf 3`---- DB7-Master3 `tput setaf 2` ssh IPXMIATCDB7 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/elasticsearch.master/;mv /var/log/elasticsearch.master/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/elasticsearch.master/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCDB7 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/elasticsearch.master/;mv /var/log/elasticsearch.master/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/elasticsearch.master/";else echo "`tput setaf 3`---- DB7-Master3 `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";ESAcc7=yes;fi


        DB7Data3Status=$(ssh IPXMIATCDB7 "systemctl status elasticsearch.data" | grep Active | grep running)
        if [ -z "$DB7Data3Status" ];then echo "`tput setaf 3`---- DB7-Data3 `tput setaf 2` ssh IPXMIATCDB7 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/elasticsearch.data/;mv /var/log/elasticsearch.data/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/elasticsearch.data/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCDB7 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/elasticsearch.data/;mv /var/log/elasticsearch.data/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/elasticsearch.data/";else echo "`tput setaf 3`---- DB7-Data3 `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";ESAcc8=yes;fi


        echo "`tput setaf 6`====================================== Move Logs Kibiana Private and Public ======================================"
        DB5KibanaPrivateStatus=$(systemctl status kibana.private | grep Active | grep running)
        if [ -z "$DB5KibanaPrivateStatus" ];then echo "`tput setaf 3`---- DB5-Kibana.Private `tput setaf 2` mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/kibana.private/;mv /var/log/kibana.private/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/kibana.private/ `tput setaf 3`----`tput sgr0`";mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/kibana.private/;mv /var/log/kibana.private/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/kibana.private/;else echo "`tput setaf 3`---- DB5-Kibana.Private `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";KAcc1=yes;fi

        DB5KibanaPublicStatus=$(systemctl status kibana.public | grep Active | grep running)
        if [ -z "$DB5KibanaPublicStatus" ];then echo "`tput setaf 3`---- DB5-Kibana.Public `tput setaf 2` mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/kibana.public/;mv /var/log/kibana.public/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/kibana.public/ `tput setaf 3`----`tput sgr0`";mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/kibana.public/;mv /var/log/kibana.public/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/kibana.public/;else echo "`tput setaf 3`---- DB5-Kibana.Public `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";KAcc2=yes;fi

        DB6KibanaPrivateStatus=$(ssh IPXMIATCDB6 "systemctl status kibana.private" | grep Active | grep running)
        if [ -z "$DB6KibanaPrivateStatus" ];then echo "`tput setaf 3`---- DB6-Kibana.Private `tput setaf 2` ssh IPXMIATCDB6 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/kibana.private/;mv /var/log/kibana.private/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/kibana.private/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCDB6 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/kibana.private/;mv /var/log/kibana.private/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/kibana.private/";else echo "`tput setaf 3`---- DB6-Kibana.Private `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";KAcc3=yes;fi

        DB6KibanaPublicStatus=$(ssh IPXMIATCDB6 "systemctl status kibana.public" | grep Active | grep running)
        if [ -z "$DB6KibanaPublicStatus" ];then echo "`tput setaf 3`---- DB6-Kibana.Public `tput setaf 2` ssh IPXMIATCDB6 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/kibana.public/;mv /var/log/kibana.public/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/kibana.public/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCDB6 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/kibana.public/;mv /var/log/kibana.public/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/kibana.public/";else echo "`tput setaf 3`---- DB6-Kibana.Public `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";KAcc4=yes;fi

        echo "`tput setaf 6`====================================== Check Logstash ======================================"
        DB5LogstashStatus=$(systemctl status logstash | grep Active | grep running)
        DB5LogstashPort5044=$(netstat -an | grep ":5044 ")
        if [ -z "$DB5LogstashStatus" ] || [ -z "$DB5LogstashPort5044" ];then echo "`tput setaf 3`---- DB5-Logstash `tput setaf 2` mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/logstash/;mv /var/log/logstash/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/logstash/ `tput setaf 3`----`tput sgr0`";mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/logstash/;mv /var/log/logstash/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/logstash/;else echo "`tput setaf 3`---- DB5-Logstash `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";LAcc1=yes;fi

        DB6LogstashPort5044=$(ssh IPXMIATCDB6 'netstat -an | grep ":5044 "')
        DB6LogstashStatus=$(ssh IPXMIATCDB6 "systemctl status logstash" | grep Active | grep running)
        if [ -z "$DB6LogstashStatus" ] || [ -z "$DB6LogstashPort5044" ];then echo "`tput setaf 3`---- DB6-Logstash `tput setaf 2` ssh IPXMIATCDB6 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/logstash/;mv /var/log/logstash/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/logstash/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCDB6 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/logstash/;mv /var/log/logstash/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/logstash/";else echo "`tput setaf 3`---- DB6-Logstash `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";LAcc2=yes;fi

        RTE3LogstashPort5044=$(ssh IPXMIATCRTE3 'netstat -an | grep ":5044 "')
        RTE3LogstashStatus=$(ssh IPXMIATCRTE3 "systemctl status logstash" | grep Active | grep running)
        if [ -z "$RTE3LogstashStatus" ] || [ -z "$RTE3LogstashPort5044" ];then echo "`tput setaf 3`---- RTE3-Logstash `tput setaf 2` sh IPXMIATCRTE3 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/logstash/;mv /var/log/logstash/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/logstash/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCRTE3 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/logstash/;mv /var/log/logstash/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/logstash/";else echo "`tput setaf 3`---- RTE3-Logstash `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";LAcc3=yes;fi

        RTE4LogstashPort5044=$(ssh IPXMIATCRTE4 'netstat -an | grep ":5044 "')
        RTE4LogstashStatus=$(ssh IPXMIATCRTE4 "systemctl status logstash" | grep Active | grep running)
        if [ -z "$RTE4LogstashStatus" ] || [ -z "$RTE4LogstashPort5044" ];then echo "`tput setaf 3`---- RTE4-Logstash `tput setaf 2` sh IPXMIATCRTE4 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/logstash/;mv /var/log/logstash/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/logstash/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCRTE4 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/logstash/;mv /var/log/logstash/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/logstash/";else echo "`tput setaf 3`---- RTE4-Logstash `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";LAcc4=yes;fi

        echo "`tput setaf 6`====================================== Check Filebeat-7.4.0 ======================================"
        NH1FilebeatStatus=$(ssh IPXMIATCNH1 "systemctl status filebeat-7.4.0" | grep Active | grep running)
        if [ -z "$NH1FilebeatStatus" ];then echo "`tput setaf 3`---- NH1-Filebeat-7.4.0 `tput setaf 2` ssh IPXMIATCNH1 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/;mv /var/log/filebeat-7.4.0/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCNH1 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/;mv /var/log/filebeat-7.4.0/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/";else echo "`tput setaf 3`---- NH1-Filebeat-7.4.0 `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";FAcc1=yes;fi

        NH2FilebeatStatus=$(ssh IPXMIATCNH2 "systemctl status filebeat-7.4.0" | grep Active | grep running)
        if [ -z "$NH2FilebeatStatus" ];then echo "`tput setaf 3`---- NH2-Filebeat-7.4.0 `tput setaf 2` ssh IPXMIATCNH2 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/;mv /var/log/filebeat-7.4.0/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCNH2 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/;mv /var/log/filebeat-7.4.0/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/";else echo "`tput setaf 3`---- NH2-Filebeat-7.4.0 `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";FAcc2=yes;fi

        RTE1FilebeatStatus=$(ssh IPXMIATCRTE1 "systemctl status filebeat-7.4.0" | grep Active | grep running)
        if [ -z "$RTE1FilebeatStatus" ];then echo "`tput setaf 3`---- RTE1-Filebeat-7.4.0 `tput setaf 2` ssh IPXMIATCRTE1 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/;mv /var/log/filebeat-7.4.0/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCRTE1 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/;mv /var/log/filebeat-7.4.0/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/";else echo "`tput setaf 3`---- RTE1-Filebeat-7.4.0 `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";FAcc3=yes;fi

        RTE2FilebeatStatus=$(ssh IPXMIATCRTE2 "systemctl status filebeat-7.4.0" | grep Active | grep running)
        if [ -z "$RTE2FilebeatStatus" ];then echo "`tput setaf 3`---- RTE2-Filebeat-7.4.0 `tput setaf 2` ssh IPXMIATCRTE2 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/;mv /var/log/filebeat-7.4.0/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCRTE2 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/;mv /var/log/filebeat-7.4.0/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/";else echo "`tput setaf 3`---- RTE2-Filebeat-7.4.0 `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";FAcc4=yes;fi

        RTE3FilebeatStatus=$(ssh IPXMIATCRTE3 "systemctl status filebeat" | grep Active | grep running)
        if [ -z "$RTE3FilebeatStatus" ];then echo "`tput setaf 3`---- RTE3-Filebeat `tput setaf 2` ssh IPXMIATCRTE3 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/;mv /var/log/filebeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCRTE3 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/;mv /var/log/filebeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/";else echo "`tput setaf 3`---- RTE3-Filebeat `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";FAcc5=yes;fi

        RTE4FilebeatStatus=$(ssh IPXMIATCRTE4 "systemctl status filebeat" | grep Active | grep running)
        if [ -z "$RTE4FilebeatStatus" ];then echo "`tput setaf 3`---- RTE4-Filebeat `tput setaf 2` ssh IPXMIATCRTE4 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/;mv /var/log/filebeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCRTE4 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/;mv /var/log/filebeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/";else echo "`tput setaf 3`---- RTE4-Filebeat `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";FAcc6=yes;fi

        SPCM1FilebeatStatus=$(ssh IPXMIATCSPCM1 "systemctl status filebeat-7.4.0" | grep Active | grep running)
        if [ -z "$SPCM1FilebeatStatus" ];then echo "`tput setaf 3`---- SPCM1-Filebeat-7.4.0 `tput setaf 2` ssh IPXMIATCSPCM1 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/;mv /var/log/filebeat-7.4.0/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCSPCM1 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/;mv /var/log/filebeat-7.4.0/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/";else echo "`tput setaf 3`---- SPCM1-Filebeat-7.4.0 `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";FAcc7=yes;fi

        SPCM2FilebeatStatus=$(ssh IPXMIATCSPCM2 "systemctl status filebeat-7.4.0" | grep Active | grep running)
        if [ -z "$SPCM2FilebeatStatus" ];then echo "`tput setaf 3`---- SPCM2-Filebeat-7.4.0 `tput setaf 2` ssh IPXMIATCSPCM2 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/;mv /var/log/filebeat-7.4.0/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCSPCM2 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/;mv /var/log/filebeat-7.4.0/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/";else echo "`tput setaf 3`---- SPCM2-Filebeat-7.4.0 `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";FAcc8=yes;fi

        GTP1FilebeatStatus=$(ssh IPXMIATCGTP1 "systemctl status filebeat-7.4.0" | grep Active | grep running)
        if [ -z "$GTP1FilebeatStatus" ];then echo "`tput setaf 3`---- GTP1-Filebeat-7.4.0 `tput setaf 2` ssh IPXMIATCGTP1 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/;mv /var/log/filebeat-7.4.0/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCGTP1 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/;mv /var/log/filebeat-7.4.0/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/";else echo "`tput setaf 3`---- GTP1-Filebeat-7.4.0 `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";FAcc9=yes;fi

        GTP2FilebeatStatus=$(ssh IPXMIATCGTP2 "systemctl status filebeat-7.4.0" | grep Active | grep running)
        if [ -z "$GTP2FilebeatStatus" ];then echo "`tput setaf 3`---- GTP2-Filebeat-7.4.0 `tput setaf 2` ssh IPXMIATCGTP2 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/;mv /var/log/filebeat-7.4.0/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCGTP2 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/;mv /var/log/filebeat-7.4.0/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/";else echo "`tput setaf 3`---- GTP2-Filebeat-7.4.0 `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";FAcc10=yes;fi

        GTP3FilebeatStatus=$(ssh IPXMIATCGTP3 "systemctl status filebeat-7.4.0" | grep Active | grep running)
        if [ -z "$GTP3FilebeatStatus" ];then echo "`tput setaf 3`---- GTP3-Filebeat-7.4.0 `tput setaf 2` ssh IPXMIATCGTP3 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/;mv /var/log/filebeat-7.4.0/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCGTP3 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/;mv /var/log/filebeat-7.4.0/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/";else echo "`tput setaf 3`---- GTP3-Filebeat-7.4.0 `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";FAcc11=yes;fi

        GTP4FilebeatStatus=$(ssh IPXMIATCGTP4 "systemctl status filebeat-7.4.0" | grep Active | grep running)
        if [ -z "$GTP4FilebeatStatus" ];then echo "`tput setaf 3`---- GTP4-Filebeat-7.4.0 `tput setaf 2` ssh IPXMIATCGTP4 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/;mv /var/log/filebeat-7.4.0/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCGTP4 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/;mv /var/log/filebeat-7.4.0/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/";else echo "`tput setaf 3`---- GTP4-Filebeat-7.4.0 `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";FAcc12=yes;fi

        GTP5FilebeatStatus=$(ssh IPXMIATCGTP5 "systemctl status filebeat-7.4.0" | grep Active | grep running)
        if [ -z "$GTP5FilebeatStatus" ];then echo "`tput setaf 3`---- GTP5-Filebeat-7.4.0 `tput setaf 2` ssh IPXMIATCGTP5 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/;mv /var/log/filebeat-7.4.0/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCGTP5 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/;mv /var/log/filebeat-7.4.0/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/";else echo "`tput setaf 3`---- GTP5-Filebeat-7.4.0 `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";FAcc13=yes;fi

        GTP6FilebeatStatus=$(ssh IPXMIATCGTP6 "systemctl status filebeat-7.4.0" | grep Active | grep running)
        if [ -z "$GTP6FilebeatStatus" ];then echo "`tput setaf 3`---- GTP6-Filebeat-7.4.0 `tput setaf 2` ssh IPXMIATCGTP6 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/;mv /var/log/filebeat-7.4.0/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCGTP6 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/;mv /var/log/filebeat-7.4.0/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat-7.4.0/";else echo "`tput setaf 3`---- GTP6-Filebeat-7.4.0 `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";FAcc14=yes;fi


        echo "`tput setaf 6`====================================== Check Metricbeat ======================================"
        DB5MetricbeatStatus=$(systemctl status metricbeat | grep Active | grep running)
        if [ -z "$DB5MetricbeatStatus" ];then echo "`tput setaf 3`---- DB5-Metricbeat `tput setaf 2` mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/metricbeat/;mv /var/log/metricbeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/metricbeat/ `tput setaf 3`----`tput sgr0`";mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/metricbeat/;mv /var/log/metricbeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/metricbeat/;else echo "`tput setaf 3`---- DB5-Metricbeat `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";MAcc1=yes;fi

        DB6MetricbeatStatus=$(ssh IPXMIATCDB6 "systemctl status metricbeat" | grep Active | grep running)
        if [ -z "$DB6MetricbeatStatus" ];then echo "`tput setaf 3`---- DB6-Metricbeat `tput setaf 2` ssh IPXMIATCDB6 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/metricbeat/;mv /var/log/metricbeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/metricbeat/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCDB6 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/metricbeat/;mv /var/log/metricbeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/metricbeat/";else echo "`tput setaf 3`---- DB6-Metricbeat `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";MAcc2=yes;fi

        DB7MetricbeatStatus=$(ssh IPXMIATCDB7 "systemctl status metricbeat" | grep Active | grep running)
        if [ -z "$DB7MetricbeatStatus" ];then echo "`tput setaf 3`---- DB7-Metricbeat `tput setaf 2` ssh IPXMIATCDB7 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/metricbeat/;mv /var/log/metricbeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/metricbeat/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCDB7 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/metricbeat/;mv /var/log/metricbeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/metricbeat/";else echo "`tput setaf 3`---- DB7-Metricbeat `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";MAcc3=yes;fi

        RTE3MetricbeatStatus=$(ssh IPXMIATCRTE3 "systemctl status metricbeat" | grep Active | grep running)
        if [ -z "$RTE3MetricbeatStatus" ];then echo "`tput setaf 3`---- RTE3-Metricbeat `tput setaf 2` ssh IPXMIATCRTE3 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/metricbeat/;mv /var/log/metricbeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/metricbeat/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCRTE3 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/metricbeat/;mv /var/log/metricbeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/metricbeat/";else echo "`tput setaf 3`---- RTE3-Metricbeat `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";MAcc4=yes;fi

        RTE4MetricbeatStatus=$(ssh IPXMIATCRTE4 "systemctl status metricbeat" | grep Active | grep running)
        if [ -z "$RTE4MetricbeatStatus" ];then echo "`tput setaf 3`---- RTE4-Metricbeat `tput setaf 2` ssh IPXMIATCRTE4 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/metricbeat/;mv /var/log/metricbeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/metricbeat\"/ `tput setaf 3`----`tput sgr0`";ssh IPXMIATCRTE4 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/metricbeat/;mv /var/log/metricbeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/metricbeat/";else echo "`tput setaf 3`---- RTE4-Metricbeat `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";MAcc5=yes;fi

        echo -e "`tput setaf 6`\n====================================== FINISHED ======================================"
        if [ "$ESAcc1" != "yes" ] && [ "$ESAcc2" != "yes" ] && [ "$ESAcc3" != "yes" ] && [ "$ESAcc4" != "yes" ] && [ "$ESAcc5" != "yes" ] && [ "$ESAcc6" != "yes" ] && [ "$ESAcc7" != "yes" ] && [ "$ESAcc8" != "yes" ] && [ "$KAcc1" != "yes" ] && [ "$KAcc2" != "yes" ] && [ "$KAcc3" != "yes" ] && [ "$KAcc4" != "yes" ] && [ "$LAcc1" != "yes" ] && [ "$LAcc2" != "yes" ] && [ "$LAcc3" != "yes" ] && [ "$LAcc4" != "yes" ] && [ "$FAcc1" != "yes" ] &&  [ "$FAcc2" != "yes" ] && [ "$FAcc3" != "yes" ] && [ "$FAcc4" != "yes" ] && [ "$FAcc5" != "yes" ] && [ "$FAcc6" != "yes" ] && [ "$FAcc7" != "yes" ] && [ "$FAcc8" != "yes" ] && [ "$FAcc9" != "yes" ] && [ "$FAcc10" != "yes" ] && [ "$FAcc11" != "yes" ] && [ "$FAcc12" != "yes" ] && [ "$FAcc13" != "yes" ] && [ "$FAcc14" != "yes" ] && [ "$MAcc1" != "yes" ] && [ "$MAcc2" != "yes" ] && [ "$MAcc3" != "yes" ] && [ "$MAcc4" != "yes" ] && [ "$MAcc5" != "yes" ];then
                echo "`tput setaf 2`ALL LOGS WERE MOVED OK"
        else
                echo "`tput setaf 1`SOME OR ALL SERVICES ARE ACTIVE AND RUNNING, so some logs didnt get moved. Check again"
        fi
        echo "`tput setaf 6`======================================================================================"
        echo "`tput sgr0`"
else
        help
        exit
fi