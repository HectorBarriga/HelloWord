#!/usr/bin/perl
##############################################################################
# Filename:    roamingOtpinDelay.cgi
# Revision:    $Revision: 3.0
# Author:      Alejandro Luna
# Updated:     Hector Barriga
# @ver 3:      Third version, 21 May, 2013
#
# This second version is to not only generate a delay for roamingoptin service but
# also to generate user choice CDRs
#
#  Copyright (c) Tango Telecom 2012
#
#  All rights reserved.
#  This document contains confidential and proprietary information of
#  Tango Telecom and any reproduction, disclosure, or use in whole or
#  in part is expressly prohibited, except as may be specifically
#  authorized by prior written agreement or permission of Tango
#  Telecom.
# ##############################################################################
#
# #################################### VERSION
# ############################
# my $VERSION = "3.0";
#
use Time::HiRes qw(usleep nanosleep);
use CGI;
my $cgi =new CGI;
#print $cgi->header();
print $cgi->header('text/xml');
#print "Content-type: text/xml;\n";

##############################################################################
# getDateTime
##############################################################################
my $delay = $cgi->param("delay");
my $msisdn = $cgi->param("msisdn");
my $choice = $cgi->param("choice");
my($sec,$min,$hour,$mday,$mon,$year,$ignore1,$ignore2,$ignore3) = localtime;
$year += 1900;
$mon++;
my $padMin = sprintf( "%2.2d", $min );
my $padSec = sprintf( "%2.2d", $sec );
my $padMon = sprintf( "%2.2d", $mon );
my $padDay = sprintf( "%2.2d", $mday );
my $padSec = sprintf( "%2.2d", $sec );

usleep($delay*1000);
print "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><data><message>OK</message></data>";

open (MYFILE, '>>/tango/data/user_data/hector/bsms_userchoice.cdr');
print MYFILE "$msisdn | $delay | $choice | $year-$padMon-$padDay,$hour:$padMin:$padSec\n";
close (MYFILE);