#!/bin/bash
##############################################################################
# Filename:    stop_sendmail.sh
# Revision:    $Revision: 0.2.0 $
# Author:      Hector Barriga
#
# Jiras:
# CO Scripts:  COSC-68
#
# This sh script stops enabled sendmail deamon once /var/spool/clientmqueue/ has
# reached a configurable threshold
# In order to prevent eventual CPU deterioration and reboots, it is recommended
# to call this script from a crontab job
# Note: You must have configured stop_sendmail.cfg in order for script to work
#
# Copyright (c) Tango Telecom 2016
#
# All rights reserved.
# This document contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or
# in part is expressly prohibited, except as may be specifically
# authorized by prior written agreement or permission of Tango Telecom.
##############################################################################
#
# version 0.1.0 - First version
# version 0.2.0 - Adding Warning messages to customer before stopping sendmail
#
##############################################################################


# Initial Arguments
getTERM=$(echo $TERM)
TERM=dtterm
hostname=$(hostname)
logtoday=$(perl -e '@d=localtime time(); printf "%4d-%02d-%02d\n", $d[5]+1900,$d[4]+1,$d[3]')
currenttime=$(perl -e '$d=localtime(); printf $d')
dateReport=$(perl -e '@d=localtime time(); printf "%4d/%02d/%02d %02d:%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1]')
red=`tput setaf 1`
green=`tput setaf 2`
yellow=`tput setaf 3`
pink=`tput setaf 5`
blue=`tput setaf 6`
reset=`tput sgr0`
bold="\033[1m"



# Subroutines

printhelp()
{
echo "
${green}Usage: stop_sendmail.sh${reset}

This sh script stops enabled sendmail deamon once /var/spool/clientmqueue/ has reached a configurable threshold
In order to prevent eventual CPU deterioration and reboots, it is recommended to call this script from a crontab job

1. This script should be used as root user
2. Use it only for Solaris Unix !!!

${red}NOTE: You must have configured stop_sendmail.cfg before using this script${reset}

Copyright (c) Tango Telecom 2016
Author: Hector Barriga

All rights reserved.
This document contains confidential and proprietary information of
Tango Telecom and any reproduction, disclosure, or use in whole or
in part is expressly prohibited, except as may be specifically
authorized by prior written agreement or permission of Tango Telecom.

Version 0.2.0


               Options:

               -c <config file>         Config File that contains all script configurable parameters
                                        It is important to include directory path

               -h <help>                Show help


               Crontab Job Exmaple:
               59 0  * * * /bin/nice /tango/scripts/Generic/HouseKeeping/stop_sendmail.sh -c /tango/scripts/Generic/HouseKeeping/stop_sendmail.cfg  > /dev/null 2>&1
               "
}

getParameters()
{
config_file=$DIR/temp/tmp.file
oldIFS="$IFS"
IFS=":"
while read name value
do
    eval $name="$value"
done < $config_file
IFS="$oldIFS"
}

printLog()
{
if [ `echo "$log_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$log_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
newlogFile=$(echo $logFile | cut -d. -f1)
logExt=$(echo $logFile | cut -d. -f2)
echo "[ $dateReport ] $1 $2" >> $logDir/$newlogFile.$logtoday.$logExt
fi
}

countfiles_clientmqueue()
{
countfiles=$(ls /var/spool/clientmqueue/ | wc -l | tr -s " ")
printLog "There are $countfiles files in /var/spool/clientmqueue/"
}


showWarningSshBanner()
{
printLog "Proceeding to set Warning in sshbanner ..."
hasMotdTheWarning=$(cat /etc/motd | grep "$1" | egrep -v "cannot open")
if [ ! -f "/etc/motd.orig" ] || [ -z "$hasMotdTheWarning" ];then
        printLog "cp -rfp /etc/motd /etc/motd.orig"
        cp -rfp /etc/motd /etc/motd.orig
        printLog "Updating Warning into /etc/motd = $1"
        echo "

#############################################################################################


 WARNING sendmail sendmail!!!

 Issue started: $currenttime

$1


#############################################################################################

" > /etc/motd

else
        printLog "Warning was already addeded into /etc/motd. It means /var/spool/clientmqueue/ hasnt been cleant"
fi
}

showAlertSshBanner()
{
printLog "Proceeding to set Alert in sshbanner ..."
hasMotdTheAlert=$(cat /etc/motd | grep "$1" | egrep -v "cannot open")
if [ ! -f "/etc/motd.orig" ] || [ -z "$hasMotdTheAlert" ];then
        printLog "Updating Alert into /etc/motd = $1"
        echo "
#############################################################################################


 ALERT sendmail sendmail!!!
 Issue started: $currenttime

$1


#############################################################################################

" >> /etc/motd

else
        printLog "Alert was already addeded into /etc/motd. It means /var/spool/clientmqueue/ hasnt been cleant"
fi
}

sendWarningOrAlertViaSMSC()
{
printLog "Proceeding to send SMS ..."
if [ `echo "$smsenable" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$smsenable" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
        if [ -f "$esmePerlScriptDir/esme.pl" ];then
                echo "Site Name: $SiteName. Hostname: $hostname. WARNING: $1" > $DIR/temp/esmemsg.txt
                printLog "Updating $DIR/temp/esmemsg.txt and $DIR/temp/esme.cfg"
                echo " [trace]
    enabled = 1
    dump = 1

[connection]
    host = $SMSC
    port = $SMSCport

[bind]
    type = transceiver
    system_id = $systemId
    password = $systemIdPassword
    system_type = TCP

[enquire]
    enabled = 1

[submit]
    rate = 1
    source_addr_ton = 0
    source_addr_npi = 0
    source_addr = $source_addr
    dest_addr_ton = 0
    dest_addr_npi = 0
    dest_addr_prefix = $listOfMsisdn

    dest_addr_padding = 0
    dest_addr_max = 1
    service_type = TCP
    replace_if_present_flag = 0
    registered_delivery = 1

[short_message]
    file_format = ascii
    file_name = $DIR/temp/esmemsg.txt
    segmentation = udh" > $DIR/temp/esme.cfg

        printLog "Running $esmePerlScriptDir/esme.pl -c $DIR/temp/esme.cfg"
        $esmePerlScriptDir/esme.pl -v -c $DIR/temp/esme.cfg

        else
                printLog "Sorry, $esmePerlScriptDir/esme.pl could not be found. Install esme.pl under $esmePerlScriptDir"
        fi
else
        printLog "Sorry, SMS cannot be sent since it is not enabled in $config_in"
fi
}

sendWarningOrAlertViaMail()
{
printLog "Proceeding to send email ..."
if [ `echo "$emailenable" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$emailenable" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
        if [ -f "$emailPerlScriptDir/sendMail.pl" ];then
                printLog "Updating $DIR/temp/emailmsg.txt"

                echo "WARNING sendmail deamon, please login to server and take action ASAP

Site Name: $SiteName
Hostname:  $hostname

#############################################################################################

$1

#############################################################################################

Kind Regards,
Tango Telecom Ltd.
Customer Operations
+353 872958622 Ireland


#### Tango Telecom Ltd. ####
Registered in Ireland - Number 307010
Registered Office - Walton House, Lonsdale Road, National Technology Park, Limerick, Ireland.
T: +353 61 501900, F: +353 61 501901, W: www.tangotelecom.com, E info@tangotelecom.com

Private, Confidential and Privileged. This e-mail and any files and attachments transmitted with it are confidential and/or privileged. They are intended solely for the use of the intended recipient. The content of this e-mail and any fi
le or attachment transmitted with it may have been changed or altered without the consent of the author. If you are not the intended recipient, please note that any review, dissemination, disclosure, alteration, printing, circulation or
transmission of this e-mail and/or any file or attachment transmitted with it, is prohibited and may be unlawful. If you have received this e-mail or any file or attachment transmitted with it in error please notify the sender.  Any view
s expressed in this message are those of the individual sender and do not necessarily reflect the views of Tango Telecom

" > $DIR/temp/emailmsg.txt

                /usr/bin/perl $emailPerlScriptDir/sendMail.pl -f "$from_mail" -t "$to_mails" -n "$display_mail" -s "[$SiteName:$hostname] WARNING sendmail deamon $logtoday" -x $smtp_server -a "/bin/cat $DIR/temp/emailmsg.txt" -v
                printLog "/usr/bin/perl $emailPerlScriptDir/sendMail.pl -f '$from_mail' -t '$to_mails' -n '$display_mail' -s '[$SiteName:$hostname] WARNING sendmail deamon $logtoday' -x '$smtp_server' -a '/bin/cat $DIR/temp/emailmsg.txt'"
        else
                printLog "Sorry, $emailPerlScriptDir/sendMail.pl could not be found. Install sendMail.pl under $emailPerlScriptDir"
        fi

else
        printLog "Sorry, mail cannot be sent since it is not enabled in $config_in"
fi
}

stop_sendmail()
{
if [ `echo "$stopsendmailenable" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$emailenable" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then

        clean_clientmqueue

        callCheckSendmail "First"
        if [ ! -z "$checkSendmail" ];then
                /etc/init.d/sendmail stop
                printLog "Running: /etc/init.d/sendmail stop"
                ps -ef | grep sendmail  | egrep -v "stop_" | egrep -v "grep" | tr -s " " | cut -d " " -f 3 | xargs kill -9
                printLog "Running:  ps -ef | grep sendmail  | egrep -v stop_ | egrep -v "grep" | tr -s ' ' | cut -d ' ' -f 3 | xargs kill -9"
                sleep 15
                callCheckSendmail "Second"
        fi
else
        printLog "Sorry, sendmail deamon cannot be stopped since it is not enabled in $config_in. Also, cleaning /var/spool/clientmqueue/ could not be done if sendmail deamon is not enabled"
fi
}


callCheckSendmail()
{
checkSendmail=$(/bin/svcs -a | grep -i mail | egrep -i online)
printLog "Running: /bin/svcs -a | grep -i mail | egrep -i online"
if [ -z "$checkSendmail" ];then
        if [ "$1" = "First" ];then
                printLog "Result:  sendmail deamon was already  disabled. Hence, it doesn't need to be stopped"
        else
                printLog "Result:  sendmail deamon has only just been stopped"
        fi
else
        printLog "$1 Result:  $checkSendmail"
fi
}

clean_clientmqueue()
{
printLog "Before stopping sendmail deamon, proceeding to clean /var/spool/clientmqueue first"
if [ `echo "$cleanclientmqueueDir" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$emailenable" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
        find /var/spool/clientmqueue -exec rm {} +
        printLog "find /var/spool/clientmqueue -exec rm {} +"
else
        printLog "/var/spool/clientmqueue/ was not cleant since it is not enabled in $config_in"
fi
}



# Flags
while getopts c:h option;
do
        case $option in
                c) config_in=$OPTARG;;
                h) printhelp; h="true";;
        esac
done

if [ ! -z "$config_in" ];then

#---------------------------------------------------------------
# If it doesnt exist, create temp directory in where all temporal CDRs and important files will be stored temporarely
#--------------------------------------------------------------
DIR=$(cat $config_in | tr -d " \t\r" | grep logDir | cut -d"#" -f1 | cut -d= -f2)
if [ ! -d "$DIR/temp" ];then
mkdir $DIR/temp
fi

#---------------------------------------------------------------
# get Logs Paramenters from stop_sendmail.cfg
#--------------------------------------------------------------
sed -n '/\[General]/,/\[/p' $config_in | awk  '!/\[General]/ && !/\[/' | tr -d " \t\r" | awk '/SiteName/ || /log_enable/ || /logDir/ || /logFile/' | cut -d"#" -f1 | sed "s/=/:/g" > $DIR/temp/tmp.file
getParameters
printLog ""
printLog "####################### START ##############################"
printLog "------------------- getParameters --------------------------"
printLog "Logs: log_enable=$log_enable logDir=$logDir logFile=$logFile"

#---------------------------------------------------------------
# Get Stop sendmail Parameters from  stop_sendmail.cfg
#--------------------------------------------------------------

sed -n '/\[Stop sendmail]/,/\[/p' $config_in | awk  '!/\[Stop sendmail]/ && !/\[/' | grep "stop sendmail notification" | sed "s/=/:/g" > $DIR/temp/tmp.file
stopsendmailnotification=$(cat $DIR/temp/tmp.file | cut -d: -f2)
sed -n '/\[Stop sendmail]/,/\[/p' $config_in | awk  '!/\[Stop sendmail]/ && !/\[/' | tr -d " \t\r" | awk '/stopsendmailenable/ || /numberofMailsThreshold/ || /cleanclientmqueueDir/ || /typeOfAlert/' | cut -d"#" -f1 | sed "s/=/:/g" > $DIR/temp/tmp.file
getParameters
printLog "Stopsendmail: stopsendmailenable=$stopsendmailenable numberofMailsThreshold=$numberofMailsThreshold cleanclientmqueueDir=$cleanclientmqueueDir typeOfAlert=$typeOfAlert"
printLog "stopsendmailnotification= $stopsendmailnotification"
typeOfAlertArray=(`echo ${typeOfAlert} | sed 's/,/ /g'`)
typeOfAlertArrayLength=${#typeOfAlertArray[@]}
printLog "typeOfAlertArrayLength=$typeOfAlertArrayLength"
for (( j=0;j<$typeOfAlertArrayLength;j++))
do
        printLog "typeOfAlert[$j]=${typeOfAlertArray[$j]}"
done

#---------------------------------------------------------------
# Get Pre Warning Parameters from  stop_sendmail.cfg
#--------------------------------------------------------------

sed -n '/\[Pre Warning]/,/\[/p' $config_in | awk  '!/\[Pre Warning]/ && !/\[/' | grep "warningMessage" | sed "s/=/:/g" > $DIR/temp/tmp.file
warningMessage=$(cat $DIR/temp/tmp.file | cut -d: -f2)
sed -n '/\[Pre Warning]/,/\[/p' $config_in | awk  '!/\[Pre Warning]/ && !/\[/' | tr -d " \t\r" | awk '/numberOfFilesThreshold/ || /typeOfNotifications/' | cut -d"#" -f1 | sed "s/=/:/g" > $DIR/temp/tmp.file
getParameters
printLog "Pre Warning: numberOfFilesThreshold=$numberOfFilesThreshold typeOfNotifications=$typeOfNotifications"
printLog "warningMessage= $warningMessage"
typeOfNotificationsArray=(`echo ${typeOfNotifications} | sed 's/,/ /g'`)
typeOfNotificationsArrayLength=${#typeOfNotificationsArray[@]}
printLog "typeOfNotificationsArrayLength=$typeOfNotificationsArrayLength"
for (( j=0;j<$typeOfNotificationsArrayLength;j++))
do
        printLog "typeOfNotifications[$j]=${typeOfNotificationsArray[$j]}"
done

#---------------------------------------------------------------
# get Warnings sendmail Paramenters from stop_sendmail.cfg
#--------------------------------------------------------------

sed -n '/\[Warnings sendmail]/,/\[/p' $config_in | awk  '!/\[Warnings sendmail]/ && !/\[/' | tr -d " \t\r" | awk '/emailenable/ || /emailPerlScriptDir/ || /from_mail/ || /to_mails/ || /display_mail/ || /smtp_server/' | cut -d"#" -f1 | sed "s/=/:/g" > $DIR/temp/tmp.file
getParameters
printLog "Warnings sendmail: emailenable=$emailenable emailPerlScriptDir=$emailPerlScriptDir from_mail=$from_mail to_mails=$to_mails display_mail=$display_mail"

#---------------------------------------------------------------
# Get Warnings SMS Parameters from  stop_sendmail.cfg
#--------------------------------------------------------------

sed -n '/\[Warnings SMS]/,/\[/p' $config_in | awk  '!/\[Warnings SMS]/ && !/\[/' | tr -d " \t\r" | awk '/esmePerlScriptDir/ || /smsenable/ || /SMSC/ || /SMSCport/ || /systemId/ || /systemIdPassword/ || /source_addr/ || /listOfMsisdn/' | cut -d"#" -f1 | sed "s/=/:/g" > $DIR/temp/tmp.file
getParameters
printLog "Warnings SMS: smsenable=$smsenable esmePerlScriptDir=$esmePerlScriptDir SMSC=$SMSC SMSCport=$SMSCport systemId=$systemId systemIdPassword=$systemIdPassword source_addr=$source_addr"


# Main ()

countfiles_clientmqueue
printLog "--------------------- Check clientmqueue--------------------"

if [ "$countfiles" -ge "$numberOfFilesThreshold" ]; then
        WasThresholdReached=yes
        printLog "Warning Threshold $numberOfFilesThreshold was reached. WasThresholdReached=$WasThresholdReached"

        printLog "------------------ Send Warnings handle --------------------"
        for (( j=0;j<$typeOfNotificationsArrayLength;j++))
        do
                case ${typeOfNotificationsArray[$j]} in
                        sshbanner) showWarningSshBanner "$warningMessage";;
                        SMS)       sendWarningOrAlertViaSMSC "$warningMessage";;
                        mail)      sendWarningOrAlertViaMail "$warningMessage";;
                        *)         printLog "Sorry, there are not type Of Notification configured $config_in. Hence, no notifications to be sent";;
                esac
        done

else
        WasThresholdReached=no
        printLog "Warning Threshold $numberOfFilesThreshold has not been reached. WasThresholdReached=$WasThresholdReached"
        hasMotdTheWarning=$(cat /etc/motd | grep "$warningMessage" | egrep -v "cannot open")
        if [ -f "/etc/motd.orig" ] || [ ! -z "$hasMotdTheWarning" ];then
                mv /etc/motd.orig /etc/motd
                printLog "Removing ssh banner warning. cp /etc/motd.orig /etc/motd"
        fi
fi

printLog "--------------- stop sendmail deamon handle ----------------"
if [ "$countfiles" -ge "$numberofMailsThreshold" ]; then
        printLog "Maximum Threshold $numberofMailsThreshold was reached. sendmail deamon must be stopped and /var/spool/clientmqueue must be cleant now. numberofMailsThreshold=$numberofMailsThreshold"
        stop_sendmail

        printLog "------------------- Send Alerts handle ---------------------"
        for (( j=0;j<$typeOfAlertArrayLength;j++))
        do
                case ${typeOfAlertArray[$j]} in
                        sshbanner) showAlertSshBanner "$stopsendmailnotification";;
                        SMS)       sendWarningOrAlertViaSMSC "$stopsendmailnotification";;
                        mail)      sendWarningOrAlertViaMail "$stopsendmailnotification";;
                        *)         printLog "Sorry, there are not type Of Notification configured $config_in. Hence, no notifications to be sent";;
                esac
        done


else
        printLog "Maximum Threshold $numberofMailsThreshold has not been reached."
fi



else
if [ -z "$h" ];then
printhelp
fi
fi

TERM=$getTERM