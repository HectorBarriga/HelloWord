#!/bin/bash
if [ -z "$1" ];then
        echo -n "Enter msisdn > "
        read msisdn
else
        msisdn=$1
fi
for gtpMachine in IPXMIATCGTP1 IPXMIATCGTP2 IPXMIATCGTP3 IPXMIATCGTP4 IPXMIATCGTP5 IPXMIATCGTP6
do
        echo "`tput setaf 3`-------------------------------------`tput sgr0`"
        echo "`tput setaf 2`ssh $gtpMachine \"cat /tango/data/cdr/active_proxy* | grep \"$msisdn\"\"`tput sgr0`"
        ssh $gtpMachine "cat /tango/data/cdr/active_proxy* | grep $msisdn"
done
echo -e "`tput setaf 3`-------------------------------------`tput sgr0`\nDone\n"
echo "`tput setaf 2`ssh -t $gtpMachine \"cd /tango/data/cdr/;ls -altr \&\& bash\" in 5 secs:"
for ((i=5; i>=0; i--))
do
        echo -n "$i "
        sleep 1
done
echo "Bye`tput sgr0`"
echo -e "`tput setaf 3`================ You are in $gtpMachine ================`tput sgr0`\n"
ssh -t $gtpMachine "cd /tango/data/cdr/;ls -altr && bash"