#!/bin/bash
DIR=$(echo "`dirname $0`")

#Configs
campaign="autoprovisioning"
SI_active_File_cdr="active_SI.cdr"
SI_active_Dir_cdr="/tango/data/cdr/"
SI_Rollover_Prefix_File_cdrs="ServiceInterpreter_"
SI_Rollover_Dir_cdrs="/tango/data/cdr/ServiceInterpreter"
feedfileDir="/tango/data/ingest/autoprovision/"
feedfilePrefixFile="MAP-TIWS-TDR-1-"
PCA_SI_ShortCode="8585"
LUA_SI_ShortCode="8484"
CDRremoteMachine=tangoD
SPCMmachine=IPXMIATCSPCM1
SPCMmachinePort=8091
mysql_machine=tangoI
go_mysql="mysql -u root"


################### Routines ###############

autoprovisioningRoutine()
{
if [ "$tailActive" != "true" ];then
        title=0
fi
if [ "$tailActiveTitle" == "NoYet" ];then
        title=0
        echo -e "\nTimeStamp             msisdn          imsi\t\tsessionID   SI-SC  VPLMN\t\tserviceKey\tsubType        \tSPCM-Plan\t Result"
        tailActiveTitle="Done"
fi
if [ "$startEndTime" == "false" ];then
        offSetTimeStamp=$(perl -e '@d=localtime time()-'$offset'; printf "%4d-%02d-%02d %02d:%02d:%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1],$d[0]')
        currentTimeStamp=$(perl -e '@d=localtime time(); printf "%4d-%02d-%02d,%02d:%02d:%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1],$d[0]')
else
        todayDate=$(perl -e '@d=localtime time(); printf "%4d-%02d-%02d\n", $d[5]+1900,$d[4]+1,$d[3]')
        offSetTimeStamp="$todayDate $starT"
        currentTimeStampValidate="$todayDate $end"
        if [[ $(date -d "$currentTimeStampValidate") < $(date -d "$offSetTimeStamp") ]];then
                if [ "$endWasNotDef" != "yes" ];then
                        echo -e "\n\n`tput setaf 1`Sorry, start timestamp in -s must be earlier than end timestamp in -e. Bye`tput sgr0`\n\n"
                else
                        echo -e "\n\n`tput setaf 1`Sorry, start timestamp in -s is later than now. Set -s must be in the past Bye`tput sgr0`\n\n"
                fi
                exit
        fi
        currentTimeStamp="$todayDate,$end"
fi
add1Sec="0"
while(true)
do
        if [ -z "$file" ];then
                secs=$(date +%s --date="$offSetTimeStamp")
                MinsAgo=$(date '+%Y-%m-%d,%H:%M:%S' --date="@$((secs + $add1Sec))")
                if [ "$currentTimeStamp" == $MinsAgo ] && [ "$tailActive" != "true" ];then
                        echo -e "\n\nFinished, bye\n\n"
                        exit
                elif [ "$currentTimeStamp" == $MinsAgo ] && [ "$tailActive" == "true" ];then
                        break
                fi
                if [ "$tailActive" != "true" ];then
                        if [ "$startEndTime" == "false" ];then
                                rolloverSITempExt=$(perl -e '@d=localtime time()-'$offset'; printf "%4d%02d%02d_%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2]')
                        else
                                todayDateRollover=$(perl -e '@d=localtime time(); printf "%4d%02d%02d\n", $d[5]+1900,$d[4]+1,$d[3]')
                                startHour=$(echo "$starT" | cut -d":" -f1)
                                rolloverSITempExt=$(echo "$todayDateRollover""_""$startHour")
                        fi
                else
                        rolloverSITempExtBackup=$(perl -e '@d=localtime time()-'$offset'; printf "%4d%02d%02d_%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2]')
                        rolloverSITempExt="NoNeeded"
                fi
                getAUTO_ActiveLinesLocalMachine=$(grep -h "$MinsAgo" $SI_active_Dir_cdr/$SI_active_File_cdr | awk "/$PCA_SI_ShortCode/ || /$LUA_SI_ShortCode/" | grep "result" | awk "/AUTO_PROVISION/ || /Subscriber Already Has A Plan/")
                isThereRolloverFile=$(find $SI_Rollover_Dir_cdrs -name "$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExt*" | wc -l)
                if [ "$isThereRolloverFile" != "0" ] && [ "$rolloverSITempExt" != "NoNeeded" ];then
                        getAUTO_PROVISIONLinesLocalMachine=$(grep -h "$MinsAgo" $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExt* | awk "/$PCA_SI_ShortCode/ || /$LUA_SI_ShortCode/" | grep "result" | awk "/AUTO_PROVISION/ || /Subscriber Already Has A Plan/")
                fi
                if [ ! -z "$CDRremoteMachine" ];then
                        if [ $(ssh -n tango@$CDRremoteMachine "ls -altr $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExt* | wc -l"  2> /dev/null) != "0" ] && [ "$rolloverSITempExt" != "NoNeeded" ];then
                                getCDRremoteMachine=$(ssh -n tango@$CDRremoteMachine "cat $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExt*")
                        fi
                        getAUTO_PROVISIONLinesRemoteMachine=$(echo "$getCDRremoteMachine" | grep "$MinsAgo" | awk "/$PCA_SI_ShortCode/ || /$LUA_SI_ShortCode/" | grep "result" | awk "/AUTO_PROVISION/ || /Subscriber Already Has A Plan/")
                        getCDRActiveRemoteMachine=$(ssh -n tango@$CDRremoteMachine "cat $SI_active_Dir_cdr/$SI_active_File_cdr")
                        getAUTO_PROVISIONActiveLinesRemoteMachine=$(echo "$getCDRActiveRemoteMachine" | grep "$MinsAgo" | awk "/$PCA_SI_ShortCode/ || /$LUA_SI_ShortCode/" | grep "result" | awk "/AUTO_PROVISION/ || /Subscriber Already Has A Plan/")
                fi
                getAUTO_PROVISIONLines=$(echo -e "$getAUTO_ActiveLinesLocalMachine\n$getAUTO_PROVISIONActiveLinesRemoteMachine\n$getAUTO_PROVISIONLinesLocalMachine\n$getAUTO_PROVISIONLinesRemoteMachine" | sed '/^\s*$/d')
        else
                if [ ! -z "$starT" ];then
                        secs=$(date +%s --date="$offSetTimeStamp")
                        MinsAgo=$(date '+%Y-%m-%d,%H:%M:%S' --date="@$((secs + $add1Sec))")
                        if [ "$currentTimeStamp" == $MinsAgo ];then
                                echo -e "\n\nFinished, bye\n\n"
                                break
                        fi

                fi
                getAUTO_PROVISIONLines=$(grep -h "$MinsAgo" | awk "/$PCA_SI_ShortCode/ || /$LUA_SI_ShortCode/" | grep "result" | awk "/AUTO_PROVISION/ || /Subscriber Already Has A Plan/")
        fi
                add1Sec=$(($add1Sec+1))
        if [ ! -z "$getAUTO_PROVISIONLines" ];then
                while read get_One_AUTO_PROVISIONLine
                do
                        if [ $title -eq 15 ];then
                                echo -e "\nTimeStamp             msisdn          imsi\t\tsessionID   SI-SC  VPLMN\t\tserviceKey\tsubType        \tSPCM-Plan\t Result"
                                title=0
                        else
                                title=$((title+1))
                        fi
                        sessionID=$(echo "$get_One_AUTO_PROVISIONLine" | cut -d, -f6)
                        if [[ $get_One_AUTO_PROVISIONLine == *"AUTO_PROVISION"* ]];then
                                result=$(echo "$get_One_AUTO_PROVISIONLine" | cut -d, -f12 | cut -d'"' -f4)
                                alreadyHasAPlan="no"
                        else
                                result=$(echo "$get_One_AUTO_PROVISIONLine" | cut -d, -f12 | cut -d"=" -f2 | tr -d ' ')
                                alreadyHasAPlan="yes"
                        fi
                        timestamp=$(echo "$get_One_AUTO_PROVISIONLine" | cut -d, -f4,5)
                        getcurrentDay=$(echo "$timestamp" | cut -d, -f1 | sed "s/-//g")
                        getcurrentHour=$(echo "$timestamp" | cut -d, -f2 | cut -d":" -f1 | sed 's/^0*//')
                        getREQCDR=$(grep -h "$sessionID" $SI_active_Dir_cdr/$SI_active_File_cdr | grep "msisdn" | grep "17,49" | grep "REQ")
                        if [ -z "$getREQCDR" ] && [ ! -z "$CDRremoteMachine" ];then
                                getRemoteREQCDR=$(ssh -n tango@$CDRremoteMachine "cat $SI_active_Dir_cdr/$SI_active_File_cdr")
                                getREQCDR=$(echo "$getRemoteREQCDR" | grep "$sessionID" | grep "msisdn" | grep "17,49" | grep "REQ")
                        fi
                        if [ -z "$getREQCDR" ] && [ "$rolloverSITempExt" != "NoNeeded" ];then
                                getREQCDR=$(grep -h "$sessionID" $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExt* | grep "msisdn" | grep "17,49" | grep "REQ")
                        fi
                        if [ -z "$getREQCDR" ] && [ "$rolloverSITempExt" != "NoNeeded" ] && [ ! -z "$CDRremoteMachine" ];then
                                getRemoteREQCDR=$(ssh -n tango@$CDRremoteMachine "cat $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExt*")
                                getREQCDR=$(echo "$getRemoteREQCDR" | grep "$sessionID" | grep "msisdn" | grep "17,49" | grep "REQ")
                        else
                                isThereRolloverFileBackup=$(find $SI_Rollover_Dir_cdrs -name "$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExtBackup*" | wc -l)
                        fi
                        if [ -z "$getREQCDR" ] && [ "$isThereRolloverFileBackup" != "0" ] ;then
                                        getREQCDR=$(grep -h "$sessionID" $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExtBackup* | grep "msisdn" | grep "17,49" | grep "REQ")
                        fi
                        if [ -z "$getREQCDR" ] && [ ! -z "$CDRremoteMachine" ] && [ $(ssh -n tango@$CDRremoteMachine "ls -altr $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExtBackup* | wc -l"  2> /dev/null) != "0" ] && [ "$rolloverSITempExt" != "NoNeeded" ];then
                                isThereRolloverFileBackupRemoteMachine="1"
                                getRemoteREQCDR=$(ssh -n tango@$CDRremoteMachine "cat $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExtBackup*")
                                getREQCDR=$(echo "$getRemoteREQCDR" | grep "$sessionID" | grep "msisdn" | grep "17,49" | grep "REQ")
                        else
                                isThereRolloverFileBackupRemoteMachine="0"
                        fi
                        SI_SC=$(echo "$getREQCDR" | cut -d, -f7)
                        isVplmnPresentInGetREQCDR=$(echo "$getREQCDR" | grep "vplmn")
                        if [ "$SI_SC" == $PCA_SI_ShortCode ]; then
                                msisdn=$(echo "$getREQCDR" | cut -d, -f12 | cut -d'"' -f8)
                                imsi=$(echo "$getREQCDR" | cut -d, -f12 | cut -d'"' -f12)
                                vplmnP=$(echo "$getREQCDR" | cut -d, -f12 | cut -d'"' -f24)
                        elif [ "$SI_SC" == $LUA_SI_ShortCode ] && [ ! -z "$isVplmnPresentInGetREQCDR" ]; then
                                msisdn=$(echo "$getREQCDR" | cut -d, -f12 | cut -d'"' -f4)
                                imsi=$(echo "$getREQCDR" | cut -d, -f12 | cut -d'"' -f24)
                                vplmnP=$(echo "$getREQCDR" | cut -d, -f12 | cut -d'"' -f16)
                        elif [ "$SI_SC" == $LUA_SI_ShortCode ] && [ -z "$isVplmnPresentInGetREQCDR" ]; then
                                msisdn=$(echo "$getREQCDR" | cut -d, -f12 | cut -d'"' -f4)
                                imsi=$(echo "$getREQCDR" | cut -d, -f12 | cut -d'"' -f20)
                                vplmnP="novplmnP"
                        fi
                        vplmnLong=$(grep "$vplmnP" /etc/logstash/plmnIdToMccMnc.csv | cut -d":" -f2 | cut -d";" -f1 | tr -d '[:space:]')
                        vplmn=${vplmnLong:0:16}
                        if [ -z "$vplmn" ] && [ "$vplmnP" != "novplmnP" ];then
                                vplmn="$vplmnP,-"
                        elif [ -z "$vplmn" ] && [ "$vplmnP" == "novplmnP" ];then
                                vplmn="-,-        "
                        fi
                        getSpcmPlan=$(grep -h "$sessionID" $SI_active_Dir_cdr/$SI_active_File_cdr | grep "SR SPCM-REST-WS Purchase Plan,planDefinitionName")
                        if [ -z "$getSpcmPlan" ] && [ ! -z "$CDRremoteMachine" ];then
                                getRemoteSpcmPlan=$(ssh -n tango@$CDRremoteMachine "cat $SI_active_Dir_cdr/$SI_active_File_cdr")
                                getSpcmPlan=$(echo "$getRemoteSpcmPlan"  | grep "$sessionID" | grep "SR SPCM-REST-WS Purchase Plan,planDefinitionName")
                        fi
                        if [ -z "$getSpcmPlan" ] && [ "$rolloverSITempExt" != "NoNeeded" ];then
                                getSpcmPlan=$(grep -h "$sessionID" $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExt* | grep "SR SPCM-REST-WS Purchase Plan,planDefinitionName")
                        elif [ -z "$getSpcmPlan" ] && [ "$rolloverSITempExt" == "NoNeeded" ] && [ "$isThereRolloverFileBackup" != "0" ];then
                                getSpcmPlan=$(grep -h "$sessionID" $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExtBackup* | grep "SR SPCM-REST-WS Purchase Plan,planDefinitionName")
                        fi
                        if [ -z "$getSpcmPlan" ] && [ "$rolloverSITempExt" != "NoNeeded" ] && [ ! -z "$CDRremoteMachine" ];then
                                getRemoteSpcmPlan=$(ssh -n tango@$CDRremoteMachine "cat $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExt*")
                                getSpcmPlan=$(echo "$getRemoteSpcmPlan" | grep "$sessionID" | grep "SR SPCM-REST-WS Purchase Plan,planDefinitionName")
                        elif [ -z "$getSpcmPlan" ] && [ "$rolloverSITempExt" == "NoNeeded" ] && [ ! -z "$CDRremoteMachine" ] && [ "$isThereRolloverFileBackupBackup" != "" ];then
                                getRemoteSpcmPlan=$(ssh -n tango@$CDRremoteMachine "cat $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExtBackup*")
                                getSpcmPlan=$(echo "$getRemoteSpcmPlan" | grep "$sessionID" | grep "SR SPCM-REST-WS Purchase Plan,planDefinitionName")
                        fi

                        getPurchaseSpcmPlanResp=$(grep -h "$sessionID" $SI_active_Dir_cdr/$SI_active_File_cdr | grep "SR SPCM-REST-WS Purchase Plan" | cut -d, -f20)
                        if [ -z "$getPurchaseSpcmPlanResp" ] && [ ! -z "$CDRremoteMachine" ];then
                                getRemotePurchaseSpcmPlanResp=$(ssh -n tango@$CDRremoteMachine "cat $SI_active_Dir_cdr/$SI_active_File_cdr")
                                getPurchaseSpcmPlanResp=$(echo "$getRemotePurchaseSpcmPlanResp"  | grep "$sessionID" | grep "SR SPCM-REST-WS Purchase Plan" | cut -d, -f20)
                        fi
                        if [ -z "$getPurchaseSpcmPlanResp" ] && [ "$rolloverSITempExt" != "NoNeeded" ];then
                                getPurchaseSpcmPlanResp=$(grep -h "$sessionID" $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExt* | grep "SR SPCM-REST-WS Purchase Plan" | cut -d, -f20)
                        elif [ -z "$getPurchaseSpcmPlanResp" ] && [ "$rolloverSITempExt" == "NoNeeded" ] && [ "$isThereRolloverFileBackup" != "0" ];then
                                getPurchaseSpcmPlanResp=$(grep -h "$sessionID" $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExtBackup* | grep "SR SPCM-REST-WS Purchase Plan" | cut -d, -f20)
                        fi
                        if [ -z "$getPurchaseSpcmPlanResp" ] && [ "$rolloverSITempExt" != "NoNeeded" ] && [ ! -z "$CDRremoteMachine" ];then
                                getRemotePurchaseSpcmPlanResp=$(ssh -n tango@$CDRremoteMachine "cat $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExt*")
                                getPurchaseSpcmPlanResp=$(echo "$getRemotePurchaseSpcmPlanResp" | grep "$sessionID" | grep "SR SPCM-REST-WS Purchase Plan" | cut -d, -f20)
                        elif [ -z "$getPurchaseSpcmPlanResp" ] && [ "$rolloverSITempExt" == "NoNeeded" ] && [ ! -z "$CDRremoteMachine" ] && [ "$isThereRolloverFileBackupRemoteMachine" != "0" ];then
                                getRemotePurchaseSpcmPlanResp=$(ssh -n tango@$CDRremoteMachine "cat $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExtBackup*")
                                getPurchaseSpcmPlanResp=$(echo "$getRemotePurchaseSpcmPlanResp" | grep "$sessionID" | grep "SR SPCM-REST-WS Purchase Plan" | cut -d, -f20)
                        fi
                        getSpcmCreateSubResp=$(grep -h "$sessionID" $SI_active_Dir_cdr/$SI_active_File_cdr | grep "SR_VIVO_SPCM_createSubscriber" | cut -d, -f20)
                        if [ -z "$getSpcmCreateSubResp" ] && [ ! -z "$CDRremoteMachine" ];then
                                getRemoteSpcmCreateSubResp=$(ssh -n tango@$CDRremoteMachine "cat $SI_active_Dir_cdr/$SI_active_File_cdr")
                                getSpcmCreateSubResp=$(echo "$getRemoteSpcmCreateSubResp"  | grep "$sessionID" | grep "SR_VIVO_SPCM_createSubscriber" | cut -d, -f20)
                        fi
                        if [ -z "$getSpcmCreateSubResp" ] && [ "$rolloverSITempExt" != "NoNeeded" ];then
                                getSpcmCreateSubResp=$(grep -h "$sessionID" $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExt* | grep "SR_VIVO_SPCM_createSubscriber" | cut -d, -f20)
                        elif [ -z "$getSpcmCreateSubResp" ] && [ "$rolloverSITempExt" == "NoNeeded" ] && [ "$isThereRolloverFileBackup" != "0" ];then
                                getSpcmCreateSubResp=$(grep -h "$sessionID" $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExtBackup* | grep "SR_VIVO_SPCM_createSubscriber" | cut -d, -f20)
                        fi
                        if [ -z "$getSpcmCreateSubResp" ] && [ "$rolloverSITempExt" != "NoNeeded" ] && [ ! -z "$CDRremoteMachine" ];then
                                getRemoteSpcmCreateSubResp=$(ssh -n tango@$CDRremoteMachine "cat $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExt*")
                                getSpcmCreateSubResp=$(echo "$getRemoteSpcmCreateSubResp" | grep "$sessionID" | grep "SR_VIVO_SPCM_createSubscriber" | cut -d, -f20)
                        elif [ -z "$getSpcmCreateSubResp" ] && [ "$rolloverSITempExt" == "NoNeeded" ] && [ ! -z "$CDRremoteMachine" ] && [ "$isThereRolloverFileBackupRemoveMachine" != "0" ];then
                                getRemoteSpcmCreateSubResp=$(ssh -n tango@$CDRremoteMachine "cat $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExtBackup*")
                                getSpcmCreateSubResp=$(echo "$getRemoteSpcmCreateSubResp" | grep "$sessionID" | grep "SR_VIVO_SPCM_createSubscriber" | cut -d, -f20)
                        fi

                        if [ -z "$getSpcmPlan" ] && [ "$SI_SC" == "8585" ];then
                                spcmPlan="Diverted      "
                        elif [ -z "$getSpcmPlan" ] && [ "$SI_SC" == "8484" ] && [ "$alreadyHasAPlan" == "no" ];then
                                spcmPlan="ToBeDiverted "
                        elif [ "$alreadyHasAPlan" == "yes" ];then
                                spcmPlan=$(curl -m 1 -s -i -X GET -H "Content-Type: application/json" -H "Accept: application/json" -H "tenant: brav1" "http://$SPCMmachine:$SPCMmachinePort/spcm-rest-ws/pcc/spcm/subscribers/$msisdn/plans"  | cut -d":" -f5 | cut -d'"' -f2 | tail -1)
                                if [ -z "$spcmPlan" ];then
                                        spcmPlan="-            "
                                fi
                        else
                                spcmPlan=$(echo "$getSpcmPlan" | cut -d, -f11 | cut -d":" -f2)
                        fi
                        breakNow="no"
                        while ((getcurrentHour>=0))
                        do
                                Hour=$(printf '%02d' $getcurrentHour)
                                isThereFeedfile=$(find $feedfileDir -name "$feedfilePrefixFile$getcurrentDay$Hour*" | wc -l)
                                if [ "$isThereFeedfile" != "0" ];then
                                        getAllFeedfileCDRs=$(grep -h "$msisdn" $feedfileDir/$feedfilePrefixFile$getcurrentDay$Hour*)
                                else
                                        getAllFeedfileCDRs=""
                                fi
                                if [ ! -z "$getAllFeedfileCDRs" ];then
                                        while read getFeedfileCDR
                                        do
                                                serviceKey=$(echo "$getFeedfileCDR" | cut -d, -f20)
                                                if [ "$serviceKey" != "_" ];then
                                                        breakNow="yes"
                                                        break
                                                fi
                                        done <<< "$getAllFeedfileCDRs"
                                fi
                                if [ "$breakNow" == "yes" ];then
                                        break
                                fi
                                getcurrentHour=$(($getcurrentHour-1))
                        done
                        if [ -z "$getAllFeedfileCDRs" ] && [ ! -z "$CDRremoteMachine" ];then
                        while ((getcurrentHour>=0))
                                do
                                        Hour=$(printf '%02d' $getcurrentHour)
                                        if [ $(ssh -n tango@$CDRremoteMachine "ls -altr $feedfileDir/$feedfilePrefixFile$getcurrentDay$Hour* | wc -l"  2> /dev/null) != "0" ];then
                                                getRemoteAllFeedfileCDRs=$(ssh -n tango@$CDRremoteMachine "cat $feedfileDir/$feedfilePrefixFile$getcurrentDay$Hour*")
                                                getAllFeedfileCDRs=$(echo "$getRemoteAllFeedfileCDRs" | grep "$msisdn")
                                                if [ ! -z "$getAllFeedfileCDRs" ];then
                                                        while read getFeedfileCDR
                                                        do
                                                                serviceKey=$(echo "$getFeedfileCDR" | cut -d, -f20)
                                                                if [ "$serviceKey" != "_" ];then
                                                                        breakNow="yes"
                                                                        break
                                                                fi
                                                        done <<< "$getAllFeedfileCDRs"
                                                fi
                                                if [ "$breakNow" == "yes" ];then
                                                        break
                                                fi
                                        fi
                                        getcurrentHour=$(($getcurrentHour-1))
                                done
                        fi
                        if [ -z "$getAllFeedfileCDRs" ];then
                                serviceKey="NoFeedfile      "
                        else
                                serviceKey="$serviceKey\t\t"
                        fi
                        getUserBasicProfileCDR=$(grep -h "$sessionID" $SI_active_Dir_cdr/$SI_active_File_cdr | grep "GetUserBasicProfile" | cut -d, -f20)
                        if [ -z "$getUserBasicProfileCDR" ] && [ ! -z "$CDRremoteMachine" ];then
                                getUserBasicProfileCDRRemote=$(ssh -n tango@$CDRremoteMachine "cat $SI_active_Dir_cdr/$SI_active_File_cdr")
                                getUserBasicProfileCDR=$(echo "$getUserBasicProfileCDRRemote" | grep "$sessionID" | grep "GetUserBasicProfile" | cut -d, -f20)
                        fi
                        if [ -z "$getUserBasicProfileCDR" ] && [ "$rolloverSITempExt" != "NoNeeded" ];then
                                getUserBasicProfileCDR=$(grep -h "$sessionID" $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExt* | grep "GetUserBasicProfile" | cut -d, -f20)
                        fi
                        if [ -z "$getUserBasicProfileCDR" ] && [ "$rolloverSITempExt" != "NoNeeded" ] && [ ! -z "$CDRremoteMachine" ];then
                                getUserBasicProfileCDRRemote=$(ssh -n tango@$CDRremoteMachine "cat $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExt*")
                                getUserBasicProfileCDR=$(echo "$getUserBasicProfileCDRRemote" | grep "$sessionID" | grep "GetUserBasicProfile" | cut -d, -f20)
                        else
                                isThereRolloverFileBackup=$(find $SI_Rollover_Dir_cdrs -name "$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExtBackup*" | wc -l)
                        fi
                        if [ -z "$getUserBasicProfileCDR" ] && [ "$isThereRolloverFileBackup" != "0" ];then
                                getUserBasicProfileCDR=$(grep -h "$sessionID" $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExtBackup* | grep "GetUserBasicProfile" | cut -d, -f20)
                        fi
                        if [ -z "$getUserBasicProfileCDR" ] && [ ! -z "$CDRremoteMachine" ] && [ $(ssh -n tango@$CDRremoteMachine "ls -altr $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExt* | wc -l"  2> /dev/null) != "0" ] && [ "$rolloverSITempExt" != "NoNeeded" ];then
                                getUserBasicProfileCDRRemote=$(ssh -n tango@$CDRremoteMachine "cat $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExtBackup*")
                                getUserBasicProfileCDR=$(echo "$getUserBasicProfileCDRRemote" | grep "$sessionID" | grep "GetUserBasicProfile" | cut -d, -f20)
                        fi
                        if [ "$getUserBasicProfileCDR" == "502" ] || [ "$getUserBasicProfileCDR" == "103" ];then
                                getSubType="-            "
                        else
                                getSubType=$(ssh -n $mysql_machine "echo 'select activity_name from activity_meter.activity where msisdn = $msisdn' | $go_mysql" | egrep -v activity_name | tail -1)
                                if [ -z "$getSubType" ] && [ "$alreadyHasAPlan" == "yes" ];then
                                getSubType="NoLonger in AM"
                                fi
                        fi
                        if [ "$result" == "AUTO_PROVISION_ERROR" ];then
                                if [ -z "$vplmnP" ];then
                                        echo -e "`tput setaf 1`$timestamp   $msisdn   $imsi\t$sessionID   $SI_SC   -                    $serviceKey$getSubType \t-             \t $result`tput setaf 5` No VPLMN provided by SGSN`tput sgr0`"
                                else
                                        if [ "$vplmnP" == "novplmnP" ];then
                                                checkVplmnIsInPCRFconf=0
                                        else
                                                checkVplmnIsInPCRFconf=$(ssh -n $mysql_machine "echo 'select count(*) from pmsdb_brav1.pcrf_location_info where location_info = $vplmnP' | $go_mysql" | egrep -v count)
                                        fi
                                        if [ "$checkVplmnIsInPCRFconf" != "1" ] && [ ! -z "$isVplmnPresentInGetREQCDR" ];then
                                                echo -e "`tput setaf 1`$timestamp   $msisdn   $imsi\t$sessionID   $SI_SC   $vplmn    \t$serviceKey$getSubType \t-             \t $result`tput setaf 5` No VPLMN - PCRF LocProf`tput sgr0`"
                                        elif [ "$checkVplmnIsInPCRFconf" != "1" ] && [ -z "$isVplmnPresentInGetREQCDR" ];then
                                                echo -e "`tput setaf 1`$timestamp   $msisdn   $imsi\t$sessionID   $SI_SC   $vplmn    \t$serviceKey$getSubType \t-             \t $result`tput setaf 5` purchasePlanSPCM Failed - No VPLMN`tput sgr0`"
                                        elif [ "$getUserBasicProfileCDR" == "502" ] || [ "$getUserBasicProfileCDR" == "103" ];then
                                                echo -e "`tput setaf 1`$timestamp   $msisdn   $imsi\t$sessionID   $SI_SC   $vplmn    \t$serviceKey$getSubType \t-             \t $result`tput setaf 5` GetUserBasicProfile Failed - SDP Error SV0001`tput sgr0`"
                                        elif [ "$getPurchaseSpcmPlanResp" == "204" ];then
                                                echo -e "`tput setaf 1`$timestamp   $msisdn   $imsi\t$sessionID   $SI_SC   $vplmn    \t$serviceKey$getSubType \t$spcmPlan\t $result`tput setaf 5` purchasePlanSPCM RespCode 412 - Precondition Failed`tput sgr0`"
                                        elif [ "$getPurchaseSpcmPlanResp" == "400" ];then
                                                echo -e "`tput setaf 1`$timestamp   $msisdn   $imsi\t$sessionID   $SI_SC   $vplmn    \t$serviceKey$getSubType \t$spcmPlan\t $result`tput setaf 5` purchasePlanSPCM Failed - Timeout`tput sgr0`"
                                        else
                                                if [ "$getSpcmCreateSubResp" != "500" ];then
                                                        echo -e "`tput setaf 1`$timestamp   $msisdn   $imsi\t$sessionID   $SI_SC   $vplmn    \t$serviceKey$getSubType \t$spcmPlan\t $result`tput sgr0`"
                                                else
                                                        echo -e "`tput setaf 1`$timestamp   $msisdn   $imsi\t$sessionID   $SI_SC   $vplmn    \t$serviceKey$getSubType \t-            \t $result`tput setaf 5` createSubscriberSPCM Failed`tput sgr0`"
                                                fi
                                        fi
                                fi
                        else
                                echo -e "$timestamp   $msisdn   $imsi\t$sessionID   $SI_SC   $vplmn    \t$serviceKey$getSubType \t`tput setaf 3`$spcmPlan\t `tput setaf 2`$result`tput sgr0`"
                        fi
                done <<< "$getAUTO_PROVISIONLines"
                if [ ! -z "$file" ] && [ -z "$starT" ];then
                        echo -e "\n\nFinished, bye\n\n"
                        break
                fi
        fi
done
}



#### Main()

# Flags and Mode
while getopts s:e:o:c:f:h option;
do
        case $option in
                f) file=$OPTARG;;
                c) campaign=$OPTARG;;
                o) offset=$OPTARG;offset=$((offset*60));;
                s) starT=$OPTARG;;
                e) end=$OPTARG;;
                h) Hits=$(cat $DIR/.hits);echo -e "
        Usage: rtemon


        Filename:    rtemon
        Revision:    0.1.0
        Visits:      `tput setaf 2`$Hits`tput sgr0`
        Author:      Hector Barriga

        Jiras:
        CO Scripts:  COSC-115
        CO Internal: COIT-19045

        This sh script is to monitor RTE campaign CDRs. Campaigns such as autoprovisioning, silent roamer, etc.

        This sh script is mainly used for Tango  CO internal  monitoring
        Copyright (c) Tango Telecom 2018

        All rights reserved.
        This document contains confidential and proprietary information of
        Tango Telecom and any reproduction, disclosure, or use in whole or
        in part is expressly prohibited, except as may be specifically
        authorized by prior written agreement or permission of Tango Telecom.


               Options:

               -h <help>                Show help

               -o <offset>              Number of minutes ago you want to monitor/trace from. It is useful to find serviceKey in feedfile CDRs. Otherwise, it will report \"NoFeedfile\"
                                        Note:   It will monitor CDR up to the time script is excuted.

               -s <start>               TimeStamp [HH:MM:SS] to monitor from (Similar to -o flag but here you can set the TimeStamp instead.
                                        Note:   -o and -s can be used together. You must use correct format [HH:MM:SS]

               -e <end>                 TimeStamp [HH:MM:SS] to monitor until. This will be used if -s is present
                                        Note:   This flag optional. Default = current time. You must use correct format [HH:MM:SS]

               -f <file>                To monitor old or a particulare Service Interpreter CDRs. Enter file which contains the CDRs.
                                        Note:   Wildcard can be used. Just use \"\"

               -c <campaign>            To monitor a particular campaign

                                        Options:
                                                - autoprovisioning
                                                - silentroamer (No working yet)

                                        Default: $campaign

                                        Note:    For autoprovisioning and silentroamer, rtemon will monitor CDRs from 10mins aga due to feedfile delay

               Examples:

                e.g. ./rtemon.sh -o 10
                     It will monotor autoprovisioning that have occured over the past 10 mins

                e.g. ./rtemon.sh -f old_SI.cdr -c silentroamer
                     It will monotore silentroamer CDRs from old_SI.cdr

                e.g. ./rtemon.sh -f "/tango/data/cdr/ServiceInterpreter/*" -c silentroamer -s 10:00:00 -e 11:00:00
                     It will monitor silentroamer CDRs from ALL files under /tango/data/cdr/ServiceInterpreter/ and only CDRs from 10:00:00am until 11:00:00am

               "; h="true";;
        esac
done


if [ "$h" != "true" ];then
################## Count visits ###########
        if [ ! -f $DIR/.hits ];then
                echo 0 > $DIR/.hits
        fi
        Hits=$(cat $DIR/.hits)
        Hits=$(($Hits+1))
        echo "$Hits" > $DIR/.hits
        echo ""
        echo "                                                         `tput setaf 2`               rtemon`tput sgr0`      "
        echo "                                                         `tput setaf 2`          Script Visits: $Hits`tput sgr0`      "
        echo

###################### Start Script ###########
        if [ $(ssh -n tango@$CDRremoteMachine "ls -altr $SI_active_Dir_cdr/$SI_active_File_cdr | wc -l"  2> /dev/null) == "0" ];then
                CDRremoteMachine=""
        fi
        if [ "$campaign" == "autoprovisioning" ];then
                if [ -z "$offset" ] && [ -z "$file" ] && [ -z "$starT" ];then
                        tailActiveTitle="NoYet"
                        while(true)
                        do
                                offset=1
                                tailActive="true"
                                startEndTime="false"
                                autoprovisioningRoutine
                                sleep 1
                        done
                elif [ -z "$offset" ] && [ ! -z "$file" ]&& [ -z "$starT" ];then
                        tailActiveTitle="NoYet"
                        tailActive="false"
                        startEndTime="false"
                        offset=1440
                        autoprovisioningRoutine
                elif [ -z "$offset" ] && [ ! -z "$starT" ];then
                        tailActiveTitle="NoYet"
                        if [ -z "$end" ];then
                                endWasNotDef="yes"
                                end=$(perl -e '@d=localtime time(); printf "%02d:%02d:%02d\n", $d[2],$d[1],$d[0]')
                        fi
                        startHH=$(echo "$starT" | cut -d":" -f1)
                        startMM=$(echo "$starT" | cut -d":" -f2)
                        startSS=$(echo "$starT" | cut -d":" -f3)
                        endHH=$(echo "$end" | cut -d":" -f1)
                        endMM=$(echo "$end" | cut -d":" -f2)
                        endSS=$(echo "$end" | cut -d":" -f3)
                        if [ ${#startHH} -ne 2 ] || [[ -n ${startHH//[0-9]/} ]] || [ $startHH -gt 59 ] || [ ${#startMM} -ne 2 ] || [[ -n ${startMM//[0-9]/} ]] || [ $startMM -gt 59 ] || [ ${#startSS} -ne 2 ] || [[ -n ${startSS//[0-9]/} ]] || [ $startSS -gt 59 ];then
                                echo -e "\n\n`tput setaf 1`Sorry, -s has wrong format [H:M:S]. Run rtemon -h, bye`tput sgr0`\n\n"
                                exit
                        fi
                        if [ ${#endHH} -ne 2 ] || [[ -n ${endHH//[0-9]/} ]] || [ $endHH -gt 59 ] || [ ${#endMM} -ne 2 ] || [[ -n ${endMM//[0-9]/} ]] || [ $endMM -gt 59 ] || [ ${#endSS} -ne 2 ] || [[ -n ${endSS//[0-9]/} ]] || [ $endSS -gt 59 ];then
                                echo -e "\n\n`tput setaf 1`Sorry, -e has wrong format [H:M:S]. Run rtemon -h, bye`tput sgr0`\n\n"
                                exit
                        fi
                        tailActive="false"
                        startEndTime="true"
                        autoprovisioningRoutine
                elif [ ! -z "$offset" ] && [ ! -z "$starT" ] && [ ! -z "$end" ];then
                        echo -e "\n\n`tput setaf 1`Sorry, -o and -s or -e can be together. Run rtemon -h, bye`tput sgr0`\n\n"
                        exit
                else
                        tailActiveTitle="NoYet"
                        tailActive="false"
                        startEndTime="false"
                        autoprovisioningRoutine
                fi
        fi

fi