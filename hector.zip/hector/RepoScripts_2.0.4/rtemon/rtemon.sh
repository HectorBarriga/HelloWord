#!/bin/bash
DIR=$(echo "`dirname $0`")

#Configs
default_campaign="autoprovisioning"            # autoprovisioning or wsms
SI_active_File_cdr="active_SI.cdr"
WSMS_SIBB_active_File_cdr="active_WSMS_SIBB.cdr"
SI_active_Dir_cdr="/tango/data/cdr/"
SI_Rollover_Prefix_File_cdrs="ServiceInterpreter_"
SI_Rollover_Dir_cdrs="/tango/data/cdr/ServiceInterpreter"
WSMS_logs_Dir="/tango/logs/sibb/"
WSMS_logs_File="sibb-service.log"
feedfileDir="/tango/data/ingest/autoprovision/"
feedfilePrefixFile="MAP-TIWS-TDR-1-"
PCA_SI_ShortCode="8585"
PCA_SI_Display="PDP_Context"
LUA_SI_ShortCode="8484"
LUA_SI_Display="Loc_Update"
SICDRremoteMachine=      # Leave it empty if you want to not use it/ deactive it
WSMSCDRremoteMachine=     # Leave it empty if you want to not use it/ deactive it
SPCMmachine=IPXMIATCSPCM1
SPCMmachinePort=8091
mysql_machine=tangoI
go_mysql="mysql -u root"
deltaTimeThreshold=100

#Initial Settings
getCurrentYear=$(date '+%Y')

################### Routines ###############

autoprovisioningRoutine()
{
if [ "$WelcomeWarning" != "done" ];then
        WelcomeWarning="done"
        echo "                                                         `tput setaf 1`  A bug is exposed first 5 mins after hour changes.`tput sgr0`      "
        echo "                                                         `tput setaf 1`             It will be fixed shortly.              `tput sgr0`      "
        echo "                                                         `tput setaf 1`            Dont give up rtemon though              `tput sgr0`      "
        echo
fi
if [ "$tailActive" != "true" ];then
        title=0
fi
if [ "$tailActiveTitle" == "NoYet" ];then
        title=0
        echo -e "\nTimeStamp             msisdn          imsi\t\tsessionID   ServiceDef\t VPLMN\t\t\tserviceKey\tsubType,userType,Profile\tDataSrc\tSPCM-Plan\t SI_Resp\t\t\tResult"
        tailActiveTitle="Done"
fi
if [ "$startEndTime" == "false" ];then
        offSetTimeStamp=$(perl -e '@d=localtime time()-'$offset'; printf "%4d-%02d-%02d %02d:%02d:%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1],$d[0]')
        currentTimeStamp=$(perl -e '@d=localtime time(); printf "%4d-%02d-%02d,%02d:%02d:%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1],$d[0]')
else
        todayDate=$(perl -e '@d=localtime time(); printf "%4d-%02d-%02d\n", $d[5]+1900,$d[4]+1,$d[3]')
        offSetTimeStamp="$todayDate $starT"
        currentTimeStampValidate="$todayDate $end"
        if [[ $(date -d "$currentTimeStampValidate") < $(date -d "$offSetTimeStamp") ]];then
                if [ "$endWasNotDef" != "yes" ];then
                        echo -e "\n\n`tput setaf 1`Sorry, start timestamp in -s must be earlier than end timestamp in -e. Bye`tput sgr0`\n\n"
                else
                        echo -e "\n\n`tput setaf 1`Sorry, start timestamp in -s is later than now. Set -s must be in the past Bye`tput sgr0`\n\n"
                fi
                exit
        fi
        currentTimeStamp="$todayDate,$end"
fi
add1Sec="0"
while(true)
do
        if [ -z "$file" ];then
                secs=$(date +%s --date="$offSetTimeStamp")
                MinsAgo=$(date '+%Y-%m-%d,%H:%M:%S' --date="@$((secs + $add1Sec))")
                add1Sec=$(($add1Sec+1))
                if [ "$currentTimeStamp" == $MinsAgo ] && [ "$tailActive" != "true" ];then
                        echo -e "\n\nFinished, bye\n\n"
                        exit
                elif [ "$currentTimeStamp" == $MinsAgo ] && [ "$tailActive" == "true" ];then
                        offSetTimeStamp=$(echo $MinsAgo | sed s/","/" "/g)
                        sleep 1
                        currentTimeStamp=$(perl -e '@d=localtime time(); printf "%4d-%02d-%02d,%02d:%02d:%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1],$d[0]')
                        add1Sec="1"
                        getOffSetTimeStampSecs=$(date +%s --date="$offSetTimeStamp")
                        currentTimeStamp_P=$(echo $currentTimeStamp | sed s/","/" "/g)
                        currentTimeStampSecs=$(date +%s --date="$currentTimeStamp_P")
                        deltaTime=$((currentTimeStampSecs - getOffSetTimeStampSecs))
                        deltaTimeMin=$((deltaTime / 60))
                        if [ $deltaTime -gt $deltaTimeThreshold ];then
                                echo -e "\n\n`tput setaf 1`deltatime is too long. The diff between current time and timestamp is longer than $deltaTimeMin mins. It means script is still printing CDRs from $deltaTimeMin mins ago.`tput sgr0`\n\n"
                                echo -n "Enter \"c\" or \"clear\" to refresh. \"q\" or \"quit\" or Ctrl+C to quit > "
                                read clear
                                if [ "$clear" == "c" ] || [ "$clear" == "clear" ] || [ "$clear" == "C" ];then
                                        break
                                elif [ "$clear" == "q" ] || [ "$clear" == "quit" ] || [ "$clear" == "Q" ];then
                                        exit
                                else
                                        echo -e "\n\n`tput setaf 2`Ok, I am happy to continue`tput sgr0`\n\n"
                                        deltaTimeThreshold=$((deltaTimeThreshold * 3))
                                fi
                        fi
                fi
                if [ "$tailActive" != "true" ];then
                        if [ "$startEndTime" == "false" ];then
                                rolloverSITempExt=$(perl -e '@d=localtime time()-'$offset'; printf "%4d%02d%02d_%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2]')
                        else
                                todayDateRollover=$(perl -e '@d=localtime time(); printf "%4d%02d%02d\n", $d[5]+1900,$d[4]+1,$d[3]')
                                startHour=$(echo "$starT" | cut -d":" -f1)
                                rolloverSITempExt=$(echo "$todayDateRollover""_""$startHour")
                        fi
                else
                        rolloverSITempExtBackup=$(perl -e '@d=localtime time()-'$offset'; printf "%4d%02d%02d_%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2]')
                        rolloverSITempExt="NoNeeded"
                fi
                getAUTO_ActiveLinesLocalMachine=$(grep -h "$MinsAgo" $SI_active_Dir_cdr/$SI_active_File_cdr | grep "$pattern" | awk "/$PCA_SI_ShortCode/ || /$LUA_SI_ShortCode/" | grep "result" | awk "/AUTO_PROVISION/ || /Subscriber already has a plan/")
                isThereRolloverFile=$(find $SI_Rollover_Dir_cdrs -name "$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExt*" | wc -l)
                if [ "$isThereRolloverFile" != "0" ] && [ "$rolloverSITempExt" != "NoNeeded" ];then
                        getAUTO_PROVISIONLinesLocalMachine=$(grep -h "$MinsAgo" $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExt* | grep "$pattern" | awk "/$PCA_SI_ShortCode/ || /$LUA_SI_ShortCode/" | grep "result" | awk "/AUTO_PROVISION/ || /Subscriber already has a plan/")
                fi
                if [ ! -z "$SICDRremoteMachine" ];then
                        if [ $(ssh -n tango@$SICDRremoteMachine "ls -altr $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExt* | wc -l"  2> /dev/null) != "0" ] && [ "$rolloverSITempExt" != "NoNeeded" ];then
                                getSICDRremoteMachine=$(ssh -n tango@$SICDRremoteMachine "cat $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExt*")
                        fi
                        getAUTO_PROVISIONLinesRemoteMachine=$(echo "$getSICDRremoteMachine" | grep "$pattern" | grep "$MinsAgo" | awk "/$PCA_SI_ShortCode/ || /$LUA_SI_ShortCode/" | grep "result" | awk "/AUTO_PROVISION/ || /Subscriber already has a plan/")
                        getCDRActiveRemoteMachine=$(ssh -n tango@$SICDRremoteMachine "cat $SI_active_Dir_cdr/$SI_active_File_cdr")
                        getAUTO_PROVISIONActiveLinesRemoteMachine=$(echo "$getCDRActiveRemoteMachine" | grep "$pattern" | grep "$MinsAgo" | awk "/$PCA_SI_ShortCode/ || /$LUA_SI_ShortCode/" | grep "result" | awk "/AUTO_PROVISION/ || /Subscriber already has a plan/")
                fi
                getAUTO_PROVISIONLines=$(echo -e "$getAUTO_ActiveLinesLocalMachine\n$getAUTO_PROVISIONActiveLinesRemoteMachine\n$getAUTO_PROVISIONLinesLocalMachine\n$getAUTO_PROVISIONLinesRemoteMachine" | sed '/^\s*$/d')
        else
                if [ ! -z "$starT" ];then
                        secs=$(date +%s --date="$offSetTimeStamp")
                        MinsAgo=$(date '+%Y-%m-%d,%H:%M:%S' --date="@$((secs + $add1Sec))")
                        add1Sec=$(($add1Sec+1))
                        if [ "$currentTimeStamp" == $MinsAgo ];then
                                echo -e "\n\nFinished, bye\n\n"
                                break
                        fi

                fi
                getAUTO_PROVISIONLines=$(grep -h "$MinsAgo" | grep "$pattern" | awk "/$PCA_SI_ShortCode/ || /$LUA_SI_ShortCode/" | grep "result" | awk "/AUTO_PROVISION/ || /Subscriber already has a plan/")
        fi
        if [ ! -z "$getAUTO_PROVISIONLines" ];then
                while read get_One_AUTO_PROVISIONLine
                do
                        if [ $title -eq 15 ];then
                                echo -e "\nTimeStamp             msisdn          imsi\t\tsessionID   ServiceDef\t VPLMN\t\t\tserviceKey\tsubType,userType,Profile\tDataSrc\tSPCM-Plan\t SI_Resp\t\t\tResult"
                                title=0
                        else
                                title=$((title+1))
                        fi
                        sessionID=$(echo "$get_One_AUTO_PROVISIONLine" | cut -d, -f6)
                        if [[ $get_One_AUTO_PROVISIONLine == *"AUTO_PROVISION"* ]];then
                                result=$(echo "$get_One_AUTO_PROVISIONLine" | cut -d, -f12 | cut -d'"' -f4)
                                alreadyHasAPlan="no"
                                LU_NOT_WHITELIST="no"
                                LU_PROVISION_DESABLED="no"
                        elif [[ $get_One_AUTO_PROVISIONLine == *"AUTO_PROVISION_NOT_WHITELIST"* ]];then
                                result=$(echo "$get_One_AUTO_PROVISIONLine" | cut -d, -f12 | cut -d'"' -f4)
                                LU_NOT_WHITELIST="yes"
                                LU_PROVISION_DESABLED="no"
                        elif [[ $get_One_AUTO_PROVISIONLine == *"AUTO_PROVISION_DESABLED"* ]];then
                                result=$(echo "$get_One_AUTO_PROVISIONLine" | cut -d, -f12 | cut -d'"' -f4)
                                LU_NOT_WHITELIST="no"
                                LU_PROVISION_DESABLED="yes"
                        else
                                result=$(echo "$get_One_AUTO_PROVISIONLine" | cut -d, -f12 | cut -d"=" -f2 | tr -d ' ')
                                alreadyHasAPlan="yes"
                                LU_NOT_WHITELIST="no"
                                LU_PROVISION_DESABLED="no"
                        fi
                        timestamp=$(echo "$get_One_AUTO_PROVISIONLine" | cut -d, -f4,5)
                        getcurrentDay=$(echo "$timestamp" | cut -d, -f1 | sed "s/-//g")
                        getcurrentHour=$(echo "$timestamp" | cut -d, -f2 | cut -d":" -f1 | sed 's/^0*//')
                        getREQCDR=$(grep -h "$sessionID" $SI_active_Dir_cdr/$SI_active_File_cdr | grep "msisdn" | grep "17,49" | grep "REQ")
                        if [ -z "$getREQCDR" ] && [ ! -z "$SICDRremoteMachine" ];then
                                getRemoteREQCDR=$(ssh -n tango@$SICDRremoteMachine "cat $SI_active_Dir_cdr/$SI_active_File_cdr")
                                getREQCDR=$(echo "$getRemoteREQCDR" | grep "$sessionID" | grep "msisdn" | grep "17,49" | grep "REQ")
                        fi
                        if [ -z "$getREQCDR" ] && [ "$rolloverSITempExt" != "NoNeeded" ];then
                                getREQCDR=$(grep -h "$sessionID" $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExt* | grep "msisdn" | grep "17,49" | grep "REQ")
                        fi
                        if [ -z "$getREQCDR" ] && [ "$rolloverSITempExt" != "NoNeeded" ] && [ ! -z "$SICDRremoteMachine" ];then
                                getRemoteREQCDR=$(ssh -n tango@$SICDRremoteMachine "cat $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExt*")
                                getREQCDR=$(echo "$getRemoteREQCDR" | grep "$sessionID" | grep "msisdn" | grep "17,49" | grep "REQ")
                        else
                                isThereRolloverFileBackup=$(find $SI_Rollover_Dir_cdrs -name "$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExtBackup*" | wc -l)
                        fi
                        if [ -z "$getREQCDR" ] && [ "$isThereRolloverFileBackup" != "0" ] ;then
                                        getREQCDR=$(grep -h "$sessionID" $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExtBackup* | grep "msisdn" | grep "17,49" | grep "REQ")
                        fi
                        if [ -z "$getREQCDR" ] && [ ! -z "$SICDRremoteMachine" ] && [ $(ssh -n tango@$SICDRremoteMachine "ls -altr $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExtBackup* | wc -l"  2> /dev/null) != "0" ] && [ "$rolloverSITempExt" != "NoNeeded" ];then
                                isThereRolloverFileBackupRemoteMachine="1"
                                getRemoteREQCDR=$(ssh -n tango@$SICDRremoteMachine "cat $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExtBackup*")
                                getREQCDR=$(echo "$getRemoteREQCDR" | grep "$sessionID" | grep "msisdn" | grep "17,49" | grep "REQ")
                        else
                                isThereRolloverFileBackupRemoteMachine="0"
                        fi
                        SI_SC=$(echo "$getREQCDR" | cut -d, -f7)
                        isVplmnPresentInGetREQCDR=$(echo "$getREQCDR" | grep "vplmn")
                        if [ "$SI_SC" == $PCA_SI_ShortCode ]; then
                                msisdn=$(echo "$getREQCDR" | cut -d, -f12 | cut -d'"' -f8)
                                imsi=$(echo "$getREQCDR" | cut -d, -f12 | cut -d'"' -f12)
                                vplmnP=$(echo "$getREQCDR" | cut -d, -f12 | cut -d'"' -f24)
                                SD=$PCA_SI_Display
                        elif [ "$SI_SC" == $LUA_SI_ShortCode ] && [ ! -z "$isVplmnPresentInGetREQCDR" ]; then
                                msisdn=$(echo "$getREQCDR" | cut -d, -f12 | cut -d'"' -f4)
                                imsi=$(echo "$getREQCDR" | cut -d, -f12 | cut -d'"' -f24)
                                vplmnP=$(echo "$getREQCDR" | cut -d, -f12 | cut -d'"' -f16)
                                SD=$LUA_SI_Display
                        elif [ "$SI_SC" == $LUA_SI_ShortCode ] && [ -z "$isVplmnPresentInGetREQCDR" ]; then
                                msisdn=$(echo "$getREQCDR" | cut -d, -f12 | cut -d'"' -f4)
                                imsi=$(echo "$getREQCDR" | cut -d, -f12 | cut -d'"' -f20)
                                vplmnP="novplmnP"
                                SD=$LUA_SI_Display
                        fi
                        vplmnLong=$(grep "$vplmnP" /etc/logstash/plmnIdToMccMnc.csv | cut -d":" -f2 | cut -d";" -f1 | tr -d '[:space:]')
                        vplmn=${vplmnLong:0:16}
                        if [ -z "$vplmn" ] && [ "$vplmnP" != "novplmnP" ];then
                                vplmn="$vplmnP,-"
                        elif [ -z "$vplmn" ] && [ "$vplmnP" == "novplmnP" ];then
                                vplmn="-,-        "
                        fi
                        getSpcmPlan=$(grep -h "$sessionID" $SI_active_Dir_cdr/$SI_active_File_cdr | grep "SR SPCM-REST-WS Purchase Plan,planDefinitionName")
                        if [ -z "$getSpcmPlan" ] && [ ! -z "$SICDRremoteMachine" ];then
                                getRemoteSpcmPlan=$(ssh -n tango@$SICDRremoteMachine "cat $SI_active_Dir_cdr/$SI_active_File_cdr")
                                getSpcmPlan=$(echo "$getRemoteSpcmPlan"  | grep "$sessionID" | grep "SR SPCM-REST-WS Purchase Plan,planDefinitionName")
                        fi
                        if [ -z "$getSpcmPlan" ] && [ "$rolloverSITempExt" != "NoNeeded" ];then
                                getSpcmPlan=$(grep -h "$sessionID" $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExt* | grep "SR SPCM-REST-WS Purchase Plan,planDefinitionName")
                        elif [ -z "$getSpcmPlan" ] && [ "$rolloverSITempExt" == "NoNeeded" ] && [ "$isThereRolloverFileBackup" != "0" ];then
                                getSpcmPlan=$(grep -h "$sessionID" $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExtBackup* | grep "SR SPCM-REST-WS Purchase Plan,planDefinitionName")
                        fi
                        if [ -z "$getSpcmPlan" ] && [ "$rolloverSITempExt" != "NoNeeded" ] && [ ! -z "$SICDRremoteMachine" ];then
                                getRemoteSpcmPlan=$(ssh -n tango@$SICDRremoteMachine "cat $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExt*")
                                getSpcmPlan=$(echo "$getRemoteSpcmPlan" | grep "$sessionID" | grep "SR SPCM-REST-WS Purchase Plan,planDefinitionName")
                        elif [ -z "$getSpcmPlan" ] && [ "$rolloverSITempExt" == "NoNeeded" ] && [ ! -z "$SICDRremoteMachine" ] && [ "$isThereRolloverFileBackupBackup" != "" ];then
                                getRemoteSpcmPlan=$(ssh -n tango@$SICDRremoteMachine "cat $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExtBackup*")
                                getSpcmPlan=$(echo "$getRemoteSpcmPlan" | grep "$sessionID" | grep "SR SPCM-REST-WS Purchase Plan,planDefinitionName")
                        fi

                        getSDPJsonDocument=$(grep -h "$sessionID" $SI_active_Dir_cdr/$SI_active_File_cdr | grep "SCR Map String To Json,SDPJsonDocument")
                        if [ -z "$getSDPJsonDocument" ] && [ ! -z "$SICDRremoteMachine" ];then
                                getRemoteSDPJsonDocument=$(ssh -n tango@$SICDRremoteMachine "cat $SI_active_Dir_cdr/$SI_active_File_cdr")
                                getSDPJsonDocument=$(echo "$getRemoteSDPJsonDocument"  | grep "$sessionID" | grep "SCR Map String To Json,SDPJsonDocument")
                        fi
                        if [ -z "$getSDPJsonDocument" ] && [ "$rolloverSITempExt" != "NoNeeded" ];then
                                getSDPJsonDocument=$(grep -h "$sessionID" $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExt* | grep "SCR Map String To Json,SDPJsonDocument")
                        elif [ -z "$getSDPJsonDocument" ] && [ "$rolloverSITempExt" == "NoNeeded" ] && [ "$isThereRolloverFileBackup" != "0" ];then
                                getSDPJsonDocument=$(grep -h "$sessionID" $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExtBackup* | grep "SCR Map String To Json,SDPJsonDocument")
                        fi
                        if [ -z "$getSDPJsonDocument" ] && [ "$rolloverSITempExt" != "NoNeeded" ] && [ ! -z "$SICDRremoteMachine" ];then
                                getRemoteSDPJsonDocument=$(ssh -n tango@$SICDRremoteMachine "cat $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExt*")
                                getSDPJsonDocument=$(echo "$getRemoteSDPJsonDocument" | grep "$sessionID" | grep "SCR Map String To Json,SDPJsonDocument")
                        elif [ -z "$getSDPJsonDocument" ] && [ "$rolloverSITempExt" == "NoNeeded" ] && [ ! -z "$SICDRremoteMachine" ] && [ "$isThereRolloverFileBackupBackup" != "" ];then
                                getRemoteSDPJsonDocument=$(ssh -n tango@$SICDRremoteMachine "cat $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExtBackup*")
                                getSDPJsonDocument=$(echo "$getRemoteSDPJsonDocument" | grep "$sessionID" | grep "SCR Map String To Json,SDPJsonDocument")
                        fi

                        getPurchaseSpcmPlanResp=$(grep -h "$sessionID" $SI_active_Dir_cdr/$SI_active_File_cdr | grep "SR SPCM-REST-WS Purchase Plan" | cut -d, -f20)
                        if [ -z "$getPurchaseSpcmPlanResp" ] && [ ! -z "$SICDRremoteMachine" ];then
                                getRemotePurchaseSpcmPlanResp=$(ssh -n tango@$SICDRremoteMachine "cat $SI_active_Dir_cdr/$SI_active_File_cdr")
                                getPurchaseSpcmPlanResp=$(echo "$getRemotePurchaseSpcmPlanResp"  | grep "$sessionID" | grep "SR SPCM-REST-WS Purchase Plan" | cut -d, -f20)
                        fi
                        if [ -z "$getPurchaseSpcmPlanResp" ] && [ "$rolloverSITempExt" != "NoNeeded" ];then
                                getPurchaseSpcmPlanResp=$(grep -h "$sessionID" $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExt* | grep "SR SPCM-REST-WS Purchase Plan" | cut -d, -f20)
                        elif [ -z "$getPurchaseSpcmPlanResp" ] && [ "$rolloverSITempExt" == "NoNeeded" ] && [ "$isThereRolloverFileBackup" != "0" ];then
                                getPurchaseSpcmPlanResp=$(grep -h "$sessionID" $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExtBackup* | grep "SR SPCM-REST-WS Purchase Plan" | cut -d, -f20)
                        fi
                        if [ -z "$getPurchaseSpcmPlanResp" ] && [ "$rolloverSITempExt" != "NoNeeded" ] && [ ! -z "$SICDRremoteMachine" ];then
                                getRemotePurchaseSpcmPlanResp=$(ssh -n tango@$SICDRremoteMachine "cat $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExt*")
                                getPurchaseSpcmPlanResp=$(echo "$getRemotePurchaseSpcmPlanResp" | grep "$sessionID" | grep "SR SPCM-REST-WS Purchase Plan" | cut -d, -f20)
                        elif [ -z "$getPurchaseSpcmPlanResp" ] && [ "$rolloverSITempExt" == "NoNeeded" ] && [ ! -z "$SICDRremoteMachine" ] && [ "$isThereRolloverFileBackupRemoteMachine" != "0" ];then
                                getRemotePurchaseSpcmPlanResp=$(ssh -n tango@$SICDRremoteMachine "cat $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExtBackup*")
                                getPurchaseSpcmPlanResp=$(echo "$getRemotePurchaseSpcmPlanResp" | grep "$sessionID" | grep "SR SPCM-REST-WS Purchase Plan" | cut -d, -f20)
                        fi
                        getSpcmCreateSubResp=$(grep -h "$sessionID" $SI_active_Dir_cdr/$SI_active_File_cdr | grep "SR_VIVO_SPCM_createSubscriber" | cut -d, -f20)
                        if [ -z "$getSpcmCreateSubResp" ] && [ ! -z "$SICDRremoteMachine" ];then
                                getRemoteSpcmCreateSubResp=$(ssh -n tango@$SICDRremoteMachine "cat $SI_active_Dir_cdr/$SI_active_File_cdr")
                                getSpcmCreateSubResp=$(echo "$getRemoteSpcmCreateSubResp"  | grep "$sessionID" | grep "SR_VIVO_SPCM_createSubscriber" | cut -d, -f20)
                        fi
                        if [ -z "$getSpcmCreateSubResp" ] && [ "$rolloverSITempExt" != "NoNeeded" ];then
                                getSpcmCreateSubResp=$(grep -h "$sessionID" $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExt* | grep "SR_VIVO_SPCM_createSubscriber" | cut -d, -f20)
                        elif [ -z "$getSpcmCreateSubResp" ] && [ "$rolloverSITempExt" == "NoNeeded" ] && [ "$isThereRolloverFileBackup" != "0" ];then
                                getSpcmCreateSubResp=$(grep -h "$sessionID" $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExtBackup* | grep "SR_VIVO_SPCM_createSubscriber" | cut -d, -f20)
                        fi
                        if [ -z "$getSpcmCreateSubResp" ] && [ "$rolloverSITempExt" != "NoNeeded" ] && [ ! -z "$SICDRremoteMachine" ];then
                                getRemoteSpcmCreateSubResp=$(ssh -n tango@$SICDRremoteMachine "cat $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExt*")
                                getSpcmCreateSubResp=$(echo "$getRemoteSpcmCreateSubResp" | grep "$sessionID" | grep "SR_VIVO_SPCM_createSubscriber" | cut -d, -f20)
                        elif [ -z "$getSpcmCreateSubResp" ] && [ "$rolloverSITempExt" == "NoNeeded" ] && [ ! -z "$SICDRremoteMachine" ] && [ "$isThereRolloverFileBackupRemoveMachine" != "0" ];then
                                getRemoteSpcmCreateSubResp=$(ssh -n tango@$SICDRremoteMachine "cat $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExtBackup*")
                                getSpcmCreateSubResp=$(echo "$getRemoteSpcmCreateSubResp" | grep "$sessionID" | grep "SR_VIVO_SPCM_createSubscriber" | cut -d, -f20)
                        fi

                        if [ -z "$getSpcmPlan" ] && [ "$SI_SC" == "8585" ];then
                                spcmPlan="Diverted      "
                        elif [ -z "$getSpcmPlan" ] && [ "$SI_SC" == "8484" ] && [ "$alreadyHasAPlan" == "no" ];then
                                if [ "$LU_NOT_WHITELIST" == "no" ] && [ "$LU_PROVISION_DESABLED" == "no" ];then
                                        spcmPlan="ToBeDiverted "
                                else
                                        spcmPlan="-            "
                                fi
                        elif [ "$alreadyHasAPlan" == "yes" ];then
                                spcmPlan=$(curl -m 1 -s -i -X GET -H "Content-Type: application/json" -H "Accept: application/json" -H "tenant: brav1" "http://$SPCMmachine:$SPCMmachinePort/spcm-rest-ws/pcc/spcm/subscribers/$msisdn/plans"  | cut -d":" -f5 | cut -d'"' -f2 | tail -1)
                                if [ -z "$spcmPlan" ];then
                                        spcmPlan="-            "
                                fi
                        else
                                spcmPlan=$(echo "$getSpcmPlan" | cut -d, -f11 | cut -d":" -f2)
                        fi
                        breakNow="no"
                        while ((getcurrentHour>=0))
                        do
                                Hour=$(printf '%02d' $getcurrentHour)
                                isThereFeedfile=$(find $feedfileDir -name "$feedfilePrefixFile$getcurrentDay$Hour*" | wc -l)
                                if [ "$isThereFeedfile" != "0" ];then
                                        getAllFeedfileCDRs=$(grep -h "$msisdn" $feedfileDir/$feedfilePrefixFile$getcurrentDay$Hour*)
                                else
                                        getAllFeedfileCDRs=""
                                fi
                                if [ ! -z "$getAllFeedfileCDRs" ];then
                                        while read getFeedfileCDR
                                        do
                                                serviceKey=$(echo "$getFeedfileCDR" | cut -d, -f20)
                                                if [ "$serviceKey" != "_" ];then
                                                        breakNow="yes"
                                                        break
                                                fi
                                        done <<< "$getAllFeedfileCDRs"
                                fi
                                if [ "$breakNow" == "yes" ];then
                                        break
                                fi
                                getcurrentHour=$(($getcurrentHour-1))
                        done
                        if [ -z "$getAllFeedfileCDRs" ] && [ ! -z "$SICDRremoteMachine" ];then
                        while ((getcurrentHour>=0))
                                do
                                        Hour=$(printf '%02d' $getcurrentHour)
                                        if [ $(ssh -n tango@$SICDRremoteMachine "ls -altr $feedfileDir/$feedfilePrefixFile$getcurrentDay$Hour* | wc -l"  2> /dev/null) != "0" ];then
                                                getRemoteAllFeedfileCDRs=$(ssh -n tango@$SICDRremoteMachine "cat $feedfileDir/$feedfilePrefixFile$getcurrentDay$Hour*")
                                                getAllFeedfileCDRs=$(echo "$getRemoteAllFeedfileCDRs" | grep "$msisdn")
                                                if [ ! -z "$getAllFeedfileCDRs" ];then
                                                        while read getFeedfileCDR
                                                        do
                                                                serviceKey=$(echo "$getFeedfileCDR" | cut -d, -f20)
                                                                if [ "$serviceKey" != "_" ];then
                                                                        breakNow="yes"
                                                                        break
                                                                fi
                                                        done <<< "$getAllFeedfileCDRs"
                                                fi
                                                if [ "$breakNow" == "yes" ];then
                                                        break
                                                fi
                                        fi
                                        getcurrentHour=$(($getcurrentHour-1))
                                done
                        fi
                        if [ -z "$getAllFeedfileCDRs" ];then
                                serviceKey="NoFeedfile      "
                        else
                                serviceKey="$serviceKey\t\t"
                        fi
                        getUserBasicProfileCDR=$(grep -h "$sessionID" $SI_active_Dir_cdr/$SI_active_File_cdr | grep "GetUserBasicProfile" | cut -d, -f20)
                        if [ -z "$getUserBasicProfileCDR" ] && [ ! -z "$SICDRremoteMachine" ];then
                                getUserBasicProfileCDRRemote=$(ssh -n tango@$SICDRremoteMachine "cat $SI_active_Dir_cdr/$SI_active_File_cdr")
                                getUserBasicProfileCDR=$(echo "$getUserBasicProfileCDRRemote" | grep "$sessionID" | grep "GetUserBasicProfile" | cut -d, -f20)
                        fi
                        if [ -z "$getUserBasicProfileCDR" ] && [ "$rolloverSITempExt" != "NoNeeded" ];then
                                getUserBasicProfileCDR=$(grep -h "$sessionID" $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExt* | grep "GetUserBasicProfile" | cut -d, -f20)
                        fi
                        if [ -z "$getUserBasicProfileCDR" ] && [ "$rolloverSITempExt" != "NoNeeded" ] && [ ! -z "$SICDRremoteMachine" ];then
                                getUserBasicProfileCDRRemote=$(ssh -n tango@$SICDRremoteMachine "cat $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExt*")
                                getUserBasicProfileCDR=$(echo "$getUserBasicProfileCDRRemote" | grep "$sessionID" | grep "GetUserBasicProfile" | cut -d, -f20)
                        else
                                isThereRolloverFileBackup=$(find $SI_Rollover_Dir_cdrs -name "$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExtBackup*" | wc -l)
                        fi
                        if [ -z "$getUserBasicProfileCDR" ] && [ "$isThereRolloverFileBackup" != "0" ];then
                                getUserBasicProfileCDR=$(grep -h "$sessionID" $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExtBackup* | grep "GetUserBasicProfile" | cut -d, -f20)
                        fi
                        if [ -z "$getUserBasicProfileCDR" ] && [ ! -z "$SICDRremoteMachine" ] && [ $(ssh -n tango@$SICDRremoteMachine "ls -altr $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExt* | wc -l"  2> /dev/null) != "0" ] && [ "$rolloverSITempExt" != "NoNeeded" ];then
                                getUserBasicProfileCDRRemote=$(ssh -n tango@$SICDRremoteMachine "cat $SI_Rollover_Dir_cdrs/$SI_Rollover_Prefix_File_cdrs*.$rolloverSITempExtBackup*")
                                getUserBasicProfileCDR=$(echo "$getUserBasicProfileCDRRemote" | grep "$sessionID" | grep "GetUserBasicProfile" | cut -d, -f20)
                        fi
                        if [ "$getUserBasicProfileCDR" == "502" ] || [ "$getUserBasicProfileCDR" == "103" ];then
                                getSubType="-                     "
                                DBsource="-   "
                        else
                                getSubTypeInit=$(ssh -n $mysql_machine "echo 'select activity_name,value from activity_meter.activity where msisdn = $msisdn' | $go_mysql" | grep subscriberInfo | egrep -v activity_name)
                                userType=$(echo "$getSubTypeInit" | cut -d, -f1 | cut -d":" -f2)
                                UserProfile=$(echo "$getSubTypeInit" | cut -d, -f2 | cut -d":" -f2 | cut -d"}" -f1)
                                if [ "$userType" == "1" ] || [ "$userType" == "8" ];then
                                        getSubType="POSTPAID,$userType,$UserProfile"
                                elif [ "$userType" == "2" ];then
                                        getSubType="PREPAID-cdma,$userType,$UserProfile"
                                elif [ "$userType" == "3" ];then
                                        getSubType="NOCLASSIFIED,$userType,$UserProfile"
                                elif [ "$userType" == "4" ];then
                                        getSubType="CONTROL-cdma,$userType,$UserProfile"
                                elif [ "$userType" == "5" ] && [ "$UserProfile" == "0" ];then
                                        getSubType="POSTPAID,$userType,$UserProfile"
                                elif [ "$userType" == "5" ] && [ "$UserProfile" == "1" ];then
                                        getSubType="POSTPAID-Ind,$userType,$UserProfile"
                                elif [ "$userType" == "5" ] && [ "$UserProfile" == "2" ];then
                                        getSubType="POSTPAID-Corp,$userType,$UserProfile"
                                elif [ "$userType" == "6" ] && [ "$UserProfile" == "0" ];then
                                        getSubType="PREPAID,$userType,$UserProfile"
                                elif [ "$userType" == "6" ] && [ "$UserProfile" == "1" ];then
                                        getSubType="PREPAID-Ind,$userType,$UserProfile"
                                elif [ "$userType" == "6" ] && [ "$UserProfile" == "2" ];then
                                        getSubType="PREPAID-Corp,$userType,$UserProfile"
                                elif [ "$userType" == "7" ] && [ "$UserProfile" == "0" ];then
                                        getSubType="CONTROL-gsm,$userType,$UserProfile"
                                elif [ "$userType" == "7" ] && [ "$UserProfile" == "1" ];then
                                        getSubType="CONTROL-Ind,$userType,$UserProfile"
                                elif [ "$userType" == "7" ] && [ "$UserProfile" == "2" ];then
                                        getSubType="CONTROL-Corp,$userType,$UserProfile"
                                else
                                        getSubType="UNKOWN,$userType,$UserProfile        "
                                fi

                                if [ -z "$getSubType" ] && [ "$alreadyHasAPlan" == "yes" ];then
                                        getSubType="NoLonger in AM"
                                        DBsource="-           "
                                else
                                        if [ ! -z "$getSDPJsonDocument" ];then
                                                DBsource="SDP"
                                        else
                                                DBsource="AM"
                                        fi
                                fi
                        fi
                        if [ "$result" == "AUTO_PROVISION_ERROR" ];then
                                if [ -z "$vplmnP" ];then
                                        echo -e "`tput setaf 1`$timestamp   $msisdn   $imsi\t$sessionID   $SD\t -                 $serviceKey$getSubType\t\t$DBsource \t-             \t $result`tput setaf 5`   No VPLMN provided by SGSN`tput sgr0`"
                                else
                                        if [ "$vplmnP" == "novplmnP" ];then
                                                checkVplmnIsInPCRFconf=0
                                        else
                                                checkVplmnIsInPCRFconf=$(ssh -n $mysql_machine "echo 'select count(*) from pmsdb_brav1.pcrf_location_info where location_info = $vplmnP' | $go_mysql" | egrep -v count)
                                        fi
                                        if [ "$checkVplmnIsInPCRFconf" != "1" ] && [ ! -z "$isVplmnPresentInGetREQCDR" ];then
                                                echo -e "`tput setaf 1`$timestamp   $msisdn   $imsi\t$sessionID   $SD\t $vplmn     \t$serviceKey$getSubType\t\t$DBsource\t-             \t $result`tput setaf 5`   No VPLMN - PCRF LocProf`tput sgr0`"
                                        elif [ "$checkVplmnIsInPCRFconf" != "1" ] && [ -z "$isVplmnPresentInGetREQCDR" ];then
                                                echo -e "`tput setaf 1`$timestamp   $msisdn   $imsi\t$sessionID   $SD\t $vplmn     \t$serviceKey$getSubType\t\t$DBsource\t-             \t $result`tput setaf 5`   purchasePlanSPCM Failed - No VPLMN`tput sgr0`"
                                        elif [ "$getUserBasicProfileCDR" == "502" ] || [ "$getUserBasicProfileCDR" == "103" ];then
                                                echo -e "`tput setaf 1`$timestamp   $msisdn   $imsi\t$sessionID   $SD\t $vplmn     \t$serviceKey$getSubType\t\t$DBsource\t-             \t $result`tput setaf 5`   GetUserBasicProfile Failed - SDP Error SV0001`tput sgr0`"
                                        elif [ "$getPurchaseSpcmPlanResp" == "204" ];then
                                                echo -e "`tput setaf 1`$timestamp   $msisdn   $imsi\t$sessionID   $SD\t $vplmn     \t$serviceKey$getSubType\t\t$DBsource\t$spcmPlan\t $result`tput setaf 5`   purchasePlanSPCM RespCode 412 - Precondition Failed`tput sgr0`"
                                        elif [ "$getPurchaseSpcmPlanResp" == "400" ];then
                                                echo -e "`tput setaf 1`$timestamp   $msisdn   $imsi\t$sessionID   $SD\t $vplmn     \t$serviceKey$getSubType\t\t$DBsource\t$spcmPlan\t $result`tput setaf 5`   purchasePlanSPCM Failed - Timeout`tput sgr0`"
                                        else
                                                if [ "$getSpcmCreateSubResp" != "500" ];then
                                                        echo -e "`tput setaf 1`$timestamp   $msisdn   $imsi\t$sessionID   $SD\t $vplmn     \t$serviceKey$getSubType\t\t$DBsource\t$spcmPlan\t $result\t\tFailed`tput sgr0`"
                                                else
                                                        echo -e "`tput setaf 1`$timestamp   $msisdn   $imsi\t$sessionID   $SD\t $vplmn     \t$serviceKey$getSubType\t\t$DBsource\t-            \t $result`tput setaf 5`   createSubscriberSPCM Failed`tput sgr0`"
                                                fi
                                        fi
                                fi
                        else
                                echo -e "$timestamp   $msisdn   $imsi\t$sessionID   $SD\t $vplmn     \t$serviceKey$getSubType \t\t$DBsource\t$spcmPlan\t `tput setaf 3`$result     \t`tput setaf 2`Completed OK`tput sgr0`"
                        fi
                done <<< "$getAUTO_PROVISIONLines"
                if [ ! -z "$file" ] && [ -z "$starT" ];then
                        echo -e "\n\nFinished, bye\n\n"
                        break
                fi
        fi
done
}



wsmsRoutine()
{
if [ ! -f /usr/bin/jq ];then
        echo -e "\n\n`tput setaf 1`Sorry, jq is not installed. Jusr run the following commands as root. Bye\n\ncp /tango/logs/COSTAFF/hector/RepoScripts/rtemon/jq /usr/bin\nchmod +x /usr/bin/jq`tput sgr0`\n\n"
exit
fi
getHourSibbLogExt=$(perl -e '@d=localtime time(); printf "%4d-%02d-%02d-%02d*\n", $d[5]+1900,$d[4]+1,$d[3],$d[2]')
if [ "$tailActive" != "true" ];then
        title=0
fi
if [ "$tailActiveTitle" == "NoYet" ];then
        title=0
        echo -e "\nTimeStamp             msisdn          imsi\t\tVPLMN\tCountry\t\tZone\t\tserviceKey\tsubType,userType,Profile\tDataSrc\t  List\t\tAction,NumOfSMS\t   OfferDef\t\t\tResult"
        tailActiveTitle="Done"
fi
if [ "$startEndTime" == "false" ];then
        offSetTimeStamp=$(perl -e '@d=localtime time()-'$offset'; printf "%4d-%02d-%02d %02d:%02d:%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1],$d[0]')
        currentTimeStamp=$(perl -e '@d=localtime time(); printf "%4d-%02d-%02d,%02d:%02d:%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1],$d[0]')
else
        todayDate=$(perl -e '@d=localtime time(); printf "%4d-%02d-%02d\n", $d[5]+1900,$d[4]+1,$d[3]')
        offSetTimeStamp="$todayDate $starT"
        currentTimeStampValidate="$todayDate $end"
        if [[ $(date -d "$currentTimeStampValidate") < $(date -d "$offSetTimeStamp") ]];then
                if [ "$endWasNotDef" != "yes" ];then
                        echo -e "\n\n`tput setaf 1`Sorry, start timestamp in -s must be earlier than end timestamp in -e. Bye`tput sgr0`\n\n"
                else
                        echo -e "\n\n`tput setaf 1`Sorry, start timestamp in -s is later than now. Set -s must be in the past Bye`tput sgr0`\n\n"
                fi
                exit
        fi
        currentTimeStamp="$todayDate,$end"
fi
add1Sec="0"
while(true)
do
        if [ -z "$file" ];then
                secs=$(date +%s --date="$offSetTimeStamp")
                hour=$(date +%H --date="$offSetTimeStamp")
                Min=$(date '+%M')
                HourAgo=$(date '+%H' --date="@$((hour - 1))")
                MinsAgo=$(date '+%Y-%m-%d,%H:%M:%S' --date="@$((secs + $add1Sec))")
                MinsAgoWithSpace=$(date '+%m-%d %H:%M:%S' --date="@$((secs + $add1Sec))")
                add1Sec=$(($add1Sec+1))
                if [ "$currentTimeStamp" == $MinsAgo ] && [ "$tailActive" != "true" ];then
                        echo -e "\n\nFinished, bye\n\n"
                        exit
                elif [ $currentTimeStamp == $MinsAgo ] && [ "$tailActive" == "true" ];then
                        offSetTimeStamp=$(echo $MinsAgo | sed s/","/" "/g)
                        sleep 1
                        currentTimeStamp=$(perl -e '@d=localtime time(); printf "%4d-%02d-%02d,%02d:%02d:%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1],$d[0]')
                        add1Sec="1"
                        getOffSetTimeStampSecs=$(date +%s --date="$offSetTimeStamp")
                        currentTimeStamp_P=$(echo $currentTimeStamp | sed s/","/" "/g)
                        currentTimeStampSecs=$(date +%s --date="$currentTimeStamp_P")
                        deltaTime=$((currentTimeStampSecs - getOffSetTimeStampSecs))
                        deltaTimeMin=$((deltaTime / 60))
                        if [ $deltaTime -gt $deltaTimeThreshold ];then
                                echo -e "\n\n`tput setaf 1`deltatime is too long. The diff between current time and timestamp is longer than $deltaTimeMin mins. It means script is still printing CDRs from $deltaTimeMin mins ago.`tput sgr0`\n\n"
                                echo -n "Enter \"c\" or \"clear\" to refresh. \"q\" or \"quit\" or Ctrl+C to quit > "
                                read clear
                                if [ "$clear" == "c" ] || [ "$clear" == "clear" ] || [ "$clear" == "C" ];then
                                        break
                                elif [ "$clear" == "q" ] || [ "$clear" == "quit" ] || [ "$clear" == "Q" ];then
                                        exit
                                else
                                        echo -e "\n\n`tput setaf 2`Ok, I am happy to continue`tput sgr0`\n\n"
                                        deltaTimeThreshold=$((deltaTimeThreshold * 3))
                                fi
                        fi
                fi
                getWSMSLogsLinesLocalMachine=$(grep -h "$MinsAgoWithSpace" $WSMS_logs_Dir/$WSMS_logs_File | grep "$pattern" | egrep -v "VplmnToLocationMap")
                if [ "$(ls $WSMS_logs_Dir/$WSMS_logs_File.$getHourSibbLogExt 2> /dev/null | wc -l)" != "0" ];then
                        getWSMSLogsLinesLocalMachineHour=$(grep -h "$MinsAgoWithSpace" $WSMS_logs_Dir/$WSMS_logs_File.$getHourSibbLogExt | grep "$pattern" | egrep -v "VplmnToLocationMap")
                fi

                if [ ! -z "$WSMSCDRremoteMachine" ];then
                        if [ $(ssh -n tango@$WSMSCDRremoteMachine "ls -altr $WSMS_logs_Dir/$WSMS_logs_File | wc -l"  2> /dev/null) != "0" ];then
                                getWSMSLogsLinesremoteMachine=$(ssh -n tango@$WSMSCDRremoteMachine "cat $WSMS_logs_Dir/$WSMS_logs_File | egrep -v VplmnToLocationMap")
                        fi
                        getWSMSLogsLinesRemoteMachine=$(echo "$getWSMSLogsLinesremoteMachine" | grep "$pattern" | grep "$MinsAgoWithSpace" | egrep -v "VplmnToLocationMap")
                fi
                getWSMSLogsLines=$(echo -e "$getWSMSLogsLinesLocalMachine\n$getWSMSLogsLinesRemoteMachine\n$getWSMSLogsLinesLocalMachineHour" | sed '/^\s*$/d')
        else
                if [ ! -z "$starT" ];then
                        secs=$(date +%s --date="$offSetTimeStamp")
                        MinsAgo=$(date '+%Y-%m-%d %H:%M:%S' --date="@$((secs + $add1Sec))")
                        add1Sec=$(($add1Sec+1))
                        if [ $currentTimeStamp == $MinsAgo ];then
                                echo -e "\n\nFinished, bye\n\n"
                                break
                        fi

                fi
                getWSMSLogsLines=$(grep -h "$MinsAgoWithSpace" $file | grep "$pattern" | egrep -v "VplmnToLocationMap")
        fi
        if [ ! -z "$getWSMSLogsLines" ];then
                getListOfMsisdnsLines1=$(echo "$getWSMSLogsLines" | grep com.tango.sibb.service.wsms.stages.GtmsStartTimer | grep "GTMS  execute")
                getListOfMsisdnsLines2=$(echo "$getWSMSLogsLines" | grep com.tango.sibb.service.wsms.stages.GetActivityMeterStageHttp | grep "response payload" | grep "value:1")
                getListOfMsisdnsLines3=$(echo "$getWSMSLogsLines" | grep wsmsDelay | grep com.tango.sibb.service.common.stages.GetLocationFromVplmn | grep "Found Map for PLMN")
                getListOfMsisdnsLines=$(echo -e "$getListOfMsisdnsLines1\n$getListOfMsisdnsLines2\n$getListOfMsisdnsLines3" | sed '/^\s*$/d')
        else
                getWSMSLogsLines=""
                sleep 0.1
        fi
        if [ ! -z "$getListOfMsisdnsLines" ];then
                while read getMSISDNLine
                do
                        getMSISDN=$(echo "$getMSISDNLine" | cut -d"]" -f3 | cut -d"[" -f2)
                        getWSMSLogsLinesForMSISDN=$(echo "$getWSMSLogsLines" | grep "$getMSISDN")

                        DBsource="SDP     "
                        WSMSDebounce="no"
                        NumOfSMS=0
                        if [ ! -z "$getWSMSLogsLinesForMSISDN" ];then
                                while read get_One_LogLine
                                do
                                        getAlreadyBounceLine=$(echo "$get_One_LogLine" | grep "$getMSISDN" | grep com.tango.sibb.service.wsms.stages.GetActivityMeterStageHttp | grep "response payload" | grep "value:1")
                                        if [ ! -z "$getAlreadyBounceLine" ];then
                                                getTimeStamp_p=$(echo "$getAlreadyBounceLine" | cut -d"." -f1 | sed 's/ /,/g')
                                                getTimeStamp="$getCurrentYear$getTimeStamp_p"
                                                getIMSI=$(cat $WSMS_logs_Dir/$WSMS_logs_File | grep "$getMSISDN" | grep com.tango.sibb.service.common.stages.GetListFromListManagerHrg | grep sending | tail -1 | cut -d"=" -f3 | cut -d"&" -f1)
                                                if [ "$(ls $WSMS_logs_Dir/$WSMS_logs_File.$getHourSibbLogExt 2> /dev/null | wc -l)" != "0" ] && [ -z "$getIMSI" ];then
                                                        getIMSI=$(cat $WSMS_logs_Dir/$WSMS_logs_File.$getHourSibbLogExt | grep "$getMSISDN" | grep com.tango.sibb.service.common.stages.GetListFromListManagerHrg | grep sending | tail -1 | cut -d"=" -f3 | cut -d"&" -f1)
                                                fi
                                                if [ -z "$getIMSI" ] && [ "$HourAgo" != "23" ];then
                                                        getTodaySibbLogExt=$(perl -e '@d=localtime time(); printf "%4d-%02d-%02d-*\n", $d[5]+1900,$d[4]+1,$d[3]')
                                                        getIMSI=$(cat $WSMS_logs_Dir/$WSMS_logs_File.$getTodaySibbLogExt | grep "$getMSISDN" | grep com.tango.sibb.service.common.stages.GetListFromListManagerHrg | grep sending | tail -1 | cut -d"=" -f3 | cut -d"&" -f1)
                                                        getBounceOtherParameters=$(cat $WSMS_logs_Dir/$WSMS_logs_File.$getTodaySibbLogExt | grep "$getMSISDN" | grep com.tango.sibb.service.common.stages.GetLocationFromVplmn | grep "Found Map for PLMN" | tail -1)
                                                else
                                                        getBounceOtherParameters=$(cat $WSMS_logs_Dir/$WSMS_logs_File | grep "$getMSISDN" | grep com.tango.sibb.service.common.stages.GetLocationFromVplmn | grep "Found Map for PLMN" | tail -1)
                                                        if [ "$(ls $WSMS_logs_Dir/$WSMS_logs_File.$getHourSibbLogExt 2> /dev/null | wc -l)" != "0" ] && [ -z "$getBounceOtherParameters" ];then
                                                                getBounceOtherParameters=$(cat $WSMS_logs_Dir/$WSMS_logs_File.$getHourSibbLogExt | grep "$getMSISDN" | grep com.tango.sibb.service.common.stages.GetLocationFromVplmn | grep "Found Map for PLMN" | tail -1)
                                                        fi
                                                fi
                                                getVPLMN=$(echo "$getBounceOtherParameters" | cut -d"[" -f5 | cut -d"]" -f1)
                                                getCountry=$(echo "$getBounceOtherParameters" | cut -d"[" -f7 | cut -d"]" -f1)
                                                getZone=$(echo "$getBounceOtherParameters" | cut -d"[" -f6 | cut -d"]" -f1)
                                                getServiceKey="_"
                                                getSubType="_,_,_            "
                                                DBsource="Feedfile"
                                                getList="_      "
                                                WSMSAction="AM Debounce,0 SMS "
                                                WSMSDebounce="yes"
                                                WSMSresult="WSMS Debounced Ok"
                                                break

                                        else
                                                getWsmsDelayLine=$(echo "$get_One_LogLine" | grep "$getMSISDN" | egrep wsmsDelay | grep com.tango.sibb.service.common.stages.GetLocationFromVplmn | grep "Found Map for PLMN" | egrep -v grep)
                                                if [ ! -z "$getWsmsDelayLine" ];then
                                                        getTimeStamp_p=$(echo "$getWsmsDelayLine" | cut -d"." -f1 | sed 's/ /,/g')
                                                        getTimeStamp="$getCurrentYear$getTimeStamp_p"
                                                        getWSMSLogsLinesLocalMachine=$(grep -h "$MinsAgoWithSpace" $WSMS_logs_Dir/$WSMS_logs_File | grep "$pattern" | egrep -v "VplmnToLocationMap")
                                                        getIMSI=$(cat $WSMS_logs_Dir/$WSMS_logs_File | grep "$getMSISDN" | grep com.tango.sibb.service.common.stages.GetListFromListManagerHrg | grep sending | tail -1 | cut -d"=" -f3 | cut -d"&" -f1)
                                                        if [ "$(ls $WSMS_logs_Dir/$WSMS_logs_File.$getHourSibbLogExt 2> /dev/null | wc -l)" != "0" ] && [ -z "$getIMSI" ];then
                                                                getIMSI=$(cat $WSMS_logs_Dir/$WSMS_logs_File.$getHourSibbLogExt | grep "$getMSISDN" | grep com.tango.sibb.service.common.stages.GetListFromListManagerHrg | grep sending | tail -1 | cut -d"=" -f3 | cut -d"&" -f1)
                                                        fi
                                                        if [ -z "$getIMSI" ] && [ "$HourAgo" != "23" ];then
                                                                getTodaySibbLogExt=$(perl -e '@d=localtime time(); printf "%4d-%02d-%02d-*\n", $d[5]+1900,$d[4]+1,$d[3]')
                                                                getIMSI=$(cat $WSMS_logs_Dir/$WSMS_logs_File.$getTodaySibbLogExt | grep "$getMSISDN" | grep com.tango.sibb.service.common.stages.GetListFromListManagerHrg | grep sending | tail -1 | cut -d"=" -f3 | cut -d"&" -f1)
                                                                getSOMJsonSend=$(cat $WSMS_logs_Dir/$WSMS_logs_File.$getTodaySibbLogExt | grep "$getMSISDN" | grep com.tango.sibb.common.stages.SomTriggerOffer | grep "SOM send request message" | tail -1 | cut -d"]" -f4 | cut -d"[" -f2)
                                                                getSOMJsonResp=$(cat $WSMS_logs_Dir/$WSMS_logs_File.$getTodaySibbLogExt | grep "$getMSISDN" | grep com.tango.sibb.common.stages.SomTriggerOffer | grep "SOM recieve response message" | tail -1 | cut -d"]" -f4 | cut -d"[" -f2)
                                                                if [ ! -z "$getSOMJsonResp" ];then
                                                                        getSOMJsonRespFixed="$getSOMJsonResp\"empty\"}"
                                                                        getOfferDef=$(echo "$getSOMJsonRespFixed" | jq ".offerDefinitionExternalId" | cut -d'"' -f2)
                                                                fi

                                                                getDBsource=$(cat $WSMS_logs_Dir/$WSMS_logs_File.$getTodaySibbLogExt | grep "$getMSISDN" | grep com.tango.sibb.service.wsms.stages.GetSubsProfileActivityMeterStageHttp | grep subscriberInfo | tail -1)
                                                                if [ ! -z "$getDBsource" ];then
                                                                        DBsource="AM      "
                                                                fi
                                                        else
                                                                getSOMJsonSend=$(cat $WSMS_logs_Dir/$WSMS_logs_File | grep "$getMSISDN" | grep com.tango.sibb.common.stages.SomTriggerOffer | grep "SOM send request message" | tail -1 | cut -d"]" -f4 | cut -d"[" -f2)
                                                                if [ "$(ls $WSMS_logs_Dir/$WSMS_logs_File.$getHourSibbLogExt 2> /dev/null | wc -l)" != "0" ] && [ -z "$getSOMJsonSend" ];then
                                                                        getSOMJsonSend=$(cat $WSMS_logs_Dir/$WSMS_logs_File.$getHourSibbLogExt | grep "$getMSISDN" | grep com.tango.sibb.common.stages.SomTriggerOffer | grep "SOM send request message" | tail -1 | cut -d"]" -f4 | cut -d"[" -f2)
                                                                fi
                                                                getSOMJsonResp=$(cat $WSMS_logs_Dir/$WSMS_logs_File | grep "$getMSISDN" | grep com.tango.sibb.common.stages.SomTriggerOffer | grep "SOM recieve response message" | tail -1 | cut -d"]" -f4 | cut -d"[" -f2)
                                                                if [ "$(ls $WSMS_logs_Dir/$WSMS_logs_File.$getHourSibbLogExt 2> /dev/null | wc -l)" != "0" ] && [ -z "$getSOMJsonResp" ];then
                                                                        getSOMJsonResp=$(cat $WSMS_logs_Dir/$WSMS_logs_File.$getHourSibbLogExt | grep "$getMSISDN" | grep com.tango.sibb.common.stages.SomTriggerOffer | grep "SOM recieve response message" | tail -1 | cut -d"]" -f4 | cut -d"[" -f2)
                                                                fi
                                                                if [ ! -z "$getSOMJsonResp" ];then
                                                                        getSOMJsonRespFixed="$getSOMJsonResp\"empty\"}"
                                                                        getOfferDef=$(echo "$getSOMJsonRespFixed" | jq ".offerDefinitionExternalId" | cut -d'"' -f2)
                                                                fi
                                                                getDBsource=$(cat $WSMS_logs_Dir/$WSMS_logs_File | grep "$getMSISDN" | grep com.tango.sibb.service.wsms.stages.GetSubsProfileActivityMeterStageHttp | grep subscriberInfo | tail -1)
                                                                if [ "$(ls $WSMS_logs_Dir/$WSMS_logs_File.$getHourSibbLogExt 2> /dev/null | wc -l)" != "0" ] && [ -z "$getDBsource" ];then
                                                                        getDBsource=$(cat $WSMS_logs_Dir/$WSMS_logs_File.$getHourSibbLogExt | grep "$getMSISDN" | grep com.tango.sibb.service.wsms.stages.GetSubsProfileActivityMeterStageHttp | grep subscriberInfo | tail -1)
                                                                fi
                                                                if [ ! -z "$getDBsource" ];then
                                                                        DBsource="AM      "
                                                                fi
                                                        fi
                                                        WSMSAction="GTMS-Submit,1 SMS "
                                                        WSMSresult="SMS Delivered Ok"
                                                else
                                                                getTimeStamp_p=$(echo "$get_One_LogLine" | grep "$getMSISDN" | grep com.tango.sibb.service.common.stages.GetListFromListManagerHrg | grep sending | cut -d"." -f1 | sed 's/ /,/g')
                                                                if [ ! -z "$getTimeStamp_p" ];then
                                                                        getTimeStamp="$getCurrentYear$getTimeStamp_p"
                                                                        getIMSI=$(echo "$get_One_LogLine" | grep "$getMSISDN" | grep com.tango.sibb.service.common.stages.GetListFromListManagerHrg | grep sending | cut -d"=" -f3 | cut -d"&" -f1)
                                                                fi
                                                                getSOMJsonSend=$(echo "$get_One_LogLine" | grep "$getMSISDN" | grep com.tango.sibb.common.stages.SomTriggerOffer | grep "SOM send request message" | cut -d"]" -f4 | cut -d"[" -f2)
                                                                getSOMJsonResp=$(echo "$get_One_LogLine" | grep "$getMSISDN" | grep com.tango.sibb.common.stages.SomTriggerOffer | grep "SOM recieve response message" | cut -d"]" -f4 | cut -d"[" -f2)
                                                                if [ ! -z "$getSOMJsonResp" ];then
                                                                        getSOMJsonRespFixed="$getSOMJsonResp\"empty\"}"
                                                                        getOfferDef=$(echo "$getSOMJsonRespFixed" | jq ".offerDefinitionExternalId" | cut -d'"' -f2)
                                                                fi

                                                                getDBsource=$(echo "$get_One_LogLine" | grep "$getMSISDN" | grep com.tango.sibb.service.wsms.stages.GetSubsProfileActivityMeterStageHttp | grep subscriberInfo)
                                                                if [ ! -z "$getDBsource" ] && [ "$DBsource" != "AM" ];then
                                                                        DBsource="AM      "
                                                                fi

                                                                NumOfSMS=$(echo "$get_One_LogLine" | grep "$getMSISDN" | grep com.tango.sibb.common.stages.SomTriggerOffer | grep "total action is" | rev | cut -c1 | rev)
                                                                if [ ! -z "$NumOfSMS" ];then
                                                                        WSMSAction="GTMS-Delay,$NumOfSMS SMS  "
                                                                        WSMSresult="WSMS Operation OK"
                                                                fi

                                                fi
                                                if [ ! -z "$getSOMJsonSend" ];then
                                                        getVPLMN=$(echo "$getSOMJsonSend" | jq ".vplmn" | cut -d'"' -f2)
                                                        getCountry=$(echo "$getSOMJsonSend" | jq ".country" | cut -d'"' -f2)
                                                        getZone=$(echo "$getSOMJsonSend" | jq ".region" | cut -d'"' -f2)
                                                        getList=$(echo "$getSOMJsonSend" | jq ".Lists" | cut -d'"' -f2 | sed 's/|//g')
                                                        if [ -z "$getList" ];then
                                                                getList="-     "
                                                        elif [ "$getList" == "VIP" ];then
                                                                getList="VIP   "
                                                        fi

                                                        getServiceKey=$(echo "$getSOMJsonSend" | jq ".serviceKey" | cut -d'"' -f2)
                                                        if [ "$getServiceKey" == "_" ];then
                                                                userType=$(echo "$getSOMJsonSend" | jq ".userType" | cut -d'"' -f2)
                                                                UserProfile=$(echo "$getSOMJsonSend" | jq ".profile" | cut -d'"' -f2)
                                                                if [ "$userType" == "1" ] || [ "$userType" == "8" ];then
                                                                        getSubType="POSTPAID,$userType,$UserProfile"
                                                                elif [ "$userType" == "2" ];then
                                                                        getSubType="PREPAID-cdma,$userType,$UserProfile"
                                                                elif [ "$userType" == "3" ];then
                                                                        getSubType="NOCLASSIFIED,$userType,$UserProfile"
                                                                elif [ "$userType" == "4" ];then
                                                                        getSubType="CONTROL-cdma,$userType,$UserProfile"
                                                                elif [ "$userType" == "5" ] && [ "$UserProfile" == "0" ];then
                                                                        getSubType="POSTPAID,$userType,$UserProfile"
                                                                elif [ "$userType" == "5" ] && [ "$UserProfile" == "1" ];then
                                                                        getSubType="POSTPAID-Ind,$userType,$UserProfile"
                                                                elif [ "$userType" == "5" ] && [ "$UserProfile" == "2" ];then
                                                                        getSubType="POSTPAID-Corp,$userType,$UserProfile"
                                                                elif [ "$userType" == "6" ] && [ "$UserProfile" == "0" ];then
                                                                        getSubType="PREPAID,$userType,$UserProfile"
                                                                elif [ "$userType" == "6" ] && [ "$UserProfile" == "1" ];then
                                                                        getSubType="PREPAID-Ind,$userType,$UserProfile"
                                                                elif [ "$userType" == "6" ] && [ "$UserProfile" == "2" ];then
                                                                        getSubType="PREPAID-Corp,$userType,$UserProfile"
                                                                elif [ "$userType" == "7" ] && [ "$UserProfile" == "0" ];then
                                                                        getSubType="CONTROL-gsm,$userType,$UserProfile"
                                                                elif [ "$userType" == "7" ] && [ "$UserProfile" == "1" ];then
                                                                        getSubType="CONTROL-Ind,$userType,$UserProfile"
                                                                elif [ "$userType" == "7" ] && [ "$UserProfile" == "2" ];then
                                                                        getSubType="CONTROL-Corp,$userType,$UserProfile"
                                                                else
                                                                        getSubType="UNKOWN,$userType,$UserProfile"
                                                                fi
                                                        elif [ "$getServiceKey" == "109a" ];then
                                                                getSubType="PREPAID,-,-     "
                                                                DBsource="Feedfile"
                                                        elif [ "$getServiceKey" == "1063" ];then
                                                                getSubType="POSTPAID-Corp,-,-     "
                                                                DBsource="Feedfile"
                                                        else
                                                                getSubType="POSTPAID,-,-    "
                                                                DBsource="Feedfile"
                                                        fi
                                                fi
                                                if [ ! -z "$getWsmsDelayLine" ] || [ ! -z "$getWSMSOperationOK" ];then
                                                        break
                                                fi
                                        fi




                                done <<< "$getWSMSLogsLinesForMSISDN"

                                if [ "$getCountry" == "United States" ];then
                                        getCountry="USA      "
                                elif [ "$getCountry" == "United Kingdom" ];then
                                        getCountry="UK       "
                                elif [ "$getCountry" == "United Arab Emirates" ];then
                                        getCountry="UA Emirates"
                                elif [ "$getCountry" == "Roaming_Aereo" ];then
                                        getCountry="RoamingAereo"
                                        if [ "$getZone" == "WSMS_RA" ];then
                                                getZone="WSMS_RA      "
                                        fi
                                elif [ "$getCountry" == "Dominican Republic" ];then
                                        getCountry="DominicanRep"
                                elif [ "$getCountry" == "Czech Republic" ];then
                                        getCountry="Czech Rep   "
                                elif [ "$getCountry" == "Russian Federation" ];then
                                        getCountry="Russian Fed "
                                fi

                                if [ "${#getCountry}" -gt 11 ]; then
                                        getCountry=${getCountry:0:12}
                                elif [ "${#getCountry}" -lt 5 ]; then
                                        getCountry="$getCountry     "
                                fi
                                if [ "${#getOfferDef}" -lt 23 ] && [ "${#getOfferDef}" -gt 12 ]; then
                                        getOfferDef="$getOfferDef        \t"
                                elif [ "${#getOfferDef}" -le 12 ]; then
                                        getOfferDef="$getOfferDef              \t"
                                elif [ "${#getOfferDef}" -eq 29 ]; then
                                        getOfferDef="$getOfferDef"
                                else
                                        getOfferDef="$getOfferDef\t"
                                fi
                                if [ -z "$getIMSI" ]; then
                                        getIMSI=$(cat $SI_active_Dir_cdr/$WSMS_SIBB_active_File_cdr | grep "$getMSISDN" | grep "Debounce Error" | cut -d, -f12 | head -1)
                                fi
                                if [ -z "$getIMSI" ]; then
                                        getIMSI="No Found   "
                                fi
                                if [ -z "$getVPLMN" ];then
                                        getVPLMN="-      "
                                        getCountry="-         "
                                        getZone="-         "
                                fi
                                if [ $title -eq 15 ];then
                                        echo -e "\nTimeStamp             msisdn          imsi\t\tVPLMN\tCountry\t\tZone\t\tserviceKey\tsubType,userType,Profile\tDataSrc\t  List\t\tAction,NumOfSMS\t   OfferDef\t\t\tResult"
                                        title=0
                                else
                                        title=$((title+1))
                                fi
                                if [ "$WSMSDebounce" == "yes" ];then
                                        echo -e "$getTimeStamp   $getMSISDN   $getIMSI\t$getVPLMN\t$getCountry   \t$getZone\t$getServiceKey\t\t$getSubType \t\t$DBsource  $getList\t$WSMSAction `tput setaf 5`NO_OFFER_DEFINITION      \t`tput setaf 2`$WSMSresult`tput sgr0`"
                                else
                                        echo -e "$getTimeStamp   $getMSISDN   $getIMSI\t$getVPLMN\t$getCountry   \t$getZone\t$getServiceKey\t\t$getSubType \t\t$DBsource  $getList\t$WSMSAction `tput setaf 3`$getOfferDef`tput setaf 2`$WSMSresult`tput sgr0`"
                                fi

                                if [ ! -z "$file" ] && [ -z "$starT" ];then
                                        echo -e "\n\nFinished, bye\n\n"
                                        break
                                fi
                        fi
                done <<< "$getListOfMsisdnsLines"
        fi
done
}


selectCampaignRoutine()
{
        if [ "$autoprovisioning" == "yes" ] && [ "$wsms" != "yes" ] && [ "$passport" != "yes" ];then
                autoprovisioningRoutine
        elif [ "$autoprovisioning" != "yes" ] && [ "$wsms" == "yes" ] && [ "$passport" != "yes" ];then
                wsmsRoutine
        elif [ "$autoprovisioning" == "yes" ] && [ "$wsms" == "yes" ] && [ "$passport" != "yes" ];then
                echo -e "\n`tput setaf 1`Sorry, flag -a and -w cannot be used simultaneously. Run rtemon -h`tput sgr0`\n"
                exit
        elif [ "$autoprovisioning" == "yes" ] && [ "$passport" == "yes" ] && [ "$wsms" != "yes" ];then
                echo -e "\n`tput setaf 1`Sorry, flag -a and -p cannot be used simultaneously. Run rtemon -h`tput sgr0`\n"
                exit
        elif [ "$wsms" == "yes" ] && [ "$passport" == "yes" ] && [ "$autoprovisioning" != "yes" ];then
                echo -e "\n`tput setaf 1`Sorry, flag -w and -p cannot be used simultaneously. Run rtemon -h`tput sgr0`\n"
                exit
        elif [ "$wsms" == "yes" ] && [ "$passport" == "yes" ] && [ "$autoprovisioning" == "yes" ];then
                echo -e "\n`tput setaf 1`Sorry, flag -a, -w and -p cannot be used simultaneously. Run rtemon -h`tput sgr0`\n"
                exit
        elif [ "$autoprovisioning" != "yes" ] && [ "$wsms" != "yes" ] && [ "$passport" != "yes" ];then
                case $default_campaign in
                        autoprovisioning) autoprovisioningRoutine;;
                        wsms) wsmsRoutine;;
                esac
        fi
}



#### Main()

# Flags and Mode
while getopts s:e:o:m:c:f:hawp option;
do
        case $option in
                f) file=$OPTARG;;
                o) offset=$OPTARG;offset=$((offset*60));;
                s) starT=$OPTARG;;
                e) end=$OPTARG;;
                m) pattern=$OPTARG;;
                a) autoprovisioning="yes";;
                w) wsms="yes";;
                p) passport="yes";;
                h|*) Hits=$(cat $DIR/.hits);echo -e "
        Usage: rtemon


        Filename:    rtemon
        Revision:    0.1.0
        Visits:      `tput setaf 2`$Hits`tput sgr0`
        Author:      Hector Barriga

        Jiras:
        CO Scripts:  COSC-115
        CO Internal: COIT-19045

        This sh script is to monitor RTE campaign CDRs. Campaigns such as autoprovisioning, silent roamer, etc.

        This sh script is mainly used for Tango  CO internal  monitoring
        Copyright (c) Tango Telecom 2018

        All rights reserved.
        This document contains confidential and proprietary information of
        Tango Telecom and any reproduction, disclosure, or use in whole or
        in part is expressly prohibited, except as may be specifically
        authorized by prior written agreement or permission of Tango Telecom.


               Options:

               -h <help>                Show help

               -o <offset>              Number of minutes ago you want to monitor/trace from. It is useful to find serviceKey in feedfile CDRs. Otherwise, it will report \"NoFeedfile\"
                                        Note:   It will monitor CDR up to the time script is excuted.

               -s <start>               TimeStamp [HH:MM:SS] to monitor from (Similar to -o flag but here you can set the TimeStamp instead.
                                        Note:   -o and -s can be used together. You must use correct format [HH:MM:SS]

               -e <end>                 TimeStamp [HH:MM:SS] to monitor until. This will be used if -s is present
                                        Note:   This flag optional. Default = current time. You must use correct format [HH:MM:SS]

               -f <file>                To monitor old or a particulare Service Interpreter CDRs. Enter file which contains the CDRs.
                                        Note:   Wildcard can be used. Just use \"\"

               -m <msisdn>              To filter (like grep) rtemon based on msisdn. This will make rtemon work faster instead of grep rtemon which is a slow process
                                        Note:   You can use this flag to filter other pattern. Case sensitive

               -a <autoprovisioning>   To monitor autoprovisioning

               -w <wsms>                To monitore WSMS

               -p <Passport>            To monitor Data Passport / C-level

               Notes:
               - If flags -a, -w or -p are not present, default monitoring is: $default_campaign
               - If flags -a, -w or -p cannot be together. (No in this version)

               Examples:

                e.g. ./rtemon.sh -o 10
                     It will monotor autoprovisioning that have occured over the past 10 mins

                e.g. ./rtemon.sh -f old_SI.cdr -c silentroamer -m 3538729587622
                     It will monitore silentroamer CDRs from old_SI.cdr only for msisdn (pattern) 3538729587622. Note, it can be any other pattern

                e.g. ./rtemon.sh -f "/tango/data/cdr/ServiceInterpreter/*" -c silentroamer -s 10:00:00 -e 11:00:00
                     It will monitor silentroamer CDRs from ALL files under /tango/data/cdr/ServiceInterpreter/ and only CDRs from 10:00:00am until 11:00:00am

               "; h="true";;
        esac
done


if [ "$h" != "true" ];then
################## Count visits ###########
        if [ ! -f $DIR/.hits ];then
                echo 0 > $DIR/.hits
        fi
        Hits=$(cat $DIR/.hits)
        Hits=$(($Hits+1))
        echo "$Hits" > $DIR/.hits
        echo ""
        echo "                                                         `tput setaf 2`               rtemon v3.0`tput sgr0`      "
        echo "                                                         `tput setaf 2`          Script Visits: $Hits`tput sgr0`      "
        echo

###################### Start Script ###########
        if [ ! -z "$SICDRremoteMachine" ];then
                if [ $(ssh -n tango@$SICDRremoteMachine "ls -altr $SI_active_Dir_cdr/$SI_active_File_cdr | wc -l"  2> /dev/null) == "0" ];then
                        SICDRremoteMachine=""
                fi
        fi
        if [ ! -z "$WSMSCDRremoteMachine" ];then
                if [ $(ssh -n tango@$WSMSCDRremoteMachine "ls -altr $WSMS_logs_Dir/$WSMS_logs_File | wc -l"  2> /dev/null) == "0" ];then
                        WSMSCDRremoteMachine=""
                fi
        fi
        if [ -z "$offset" ] && [ -z "$file" ] && [ -z "$starT" ];then
                while(true)
                do
                        tailActiveTitle="NoYet"
                        offset=1
                        tailActive="true"
                        startEndTime="false"
                        selectCampaignRoutine
                        echo -e "\n\n`tput setaf 2`............ Clear ...........`tput sgr0`\n\n"
                        sleep 1
                done
        elif [ -z "$offset" ] && [ ! -z "$file" ]&& [ -z "$starT" ];then
                tailActiveTitle="NoYet"
                tailActive="false"
                startEndTime="false"
                offset=1440
                selectCampaignRoutine
        elif [ -z "$offset" ] && [ ! -z "$starT" ];then
                tailActiveTitle="NoYet"
                if [ -z "$end" ];then
                        endWasNotDef="yes"
                        end=$(perl -e '@d=localtime time(); printf "%02d:%02d:%02d\n", $d[2],$d[1],$d[0]')
                fi
                startHH=$(echo "$starT" | cut -d":" -f1)
                startMM=$(echo "$starT" | cut -d":" -f2)
                startSS=$(echo "$starT" | cut -d":" -f3)
                endHH=$(echo "$end" | cut -d":" -f1)
                endMM=$(echo "$end" | cut -d":" -f2)
                endSS=$(echo "$end" | cut -d":" -f3)
                if [ ${#startHH} -ne 2 ] || [[ -n ${startHH//[0-9]/} ]] || [ $startHH -gt 59 ] || [ ${#startMM} -ne 2 ] || [[ -n ${startMM//[0-9]/} ]] || [ $startMM -gt 59 ] || [ ${#startSS} -ne 2 ] || [[ -n ${startSS//[0-9]/} ]] || [ $startSS -gt 59 ];then
                        echo -e "\n\n`tput setaf 1`Sorry, -s has wrong format [H:M:S]. Run rtemon -h, bye`tput sgr0`\n\n"
                        exit
                fi
                if [ ${#endHH} -ne 2 ] || [[ -n ${endHH//[0-9]/} ]] || [ $endHH -gt 59 ] || [ ${#endMM} -ne 2 ] || [[ -n ${endMM//[0-9]/} ]] || [ $endMM -gt 59 ] || [ ${#endSS} -ne 2 ] || [[ -n ${endSS//[0-9]/} ]] || [ $endSS -gt 59 ];then
                        echo -e "\n\n`tput setaf 1`Sorry, -e has wrong format [H:M:S]. Run rtemon -h, bye`tput sgr0`\n\n"
                        exit
                fi
                tailActive="false"
                startEndTime="true"
                selectCampaignRoutine
        elif [ ! -z "$offset" ] && [ ! -z "$starT" ] && [ ! -z "$end" ];then
                echo -e "\n\n`tput setaf 1`Sorry, -o and -s or -e can be together. Run rtemon -h, bye`tput sgr0`\n\n"
                exit
        else
                tailActiveTitle="NoYet"
                tailActive="false"
                startEndTime="false"
                selectCampaignRoutine
        fi

fi