#!/bin/bash

# Flags
while getopts crsh option;
do
        case $option in
                c) check="true";;
                r) Rstart="true";;
                s) shutdown="true";;
                h) echo "

                Options:
                -m <check>               crontab job: * * * * * /tango/logs/COSTAFF/hector/sh_scripts/startSshuttle.sh -c >/dev/null 2>&1
                -r <restart sshuttle>
                -s <shutdown sshuttle>
               "; h="true";;
        esac
done

if [ "$h" == "true" ];then exit;fi
if [ "$check" == "true" ];then
        isShuttleRunning=$(ps -ef | grep sshuttle | grep dns | grep NHvr | wc -l)
        if [ "$isShuttleRunning" == "1" ];then
                getAlivedSessions=$(/usr/bin/w | egrep -v TTY | egrep -v "load average" | wc -l)
#       /usr/bin/w >> /tango/logs/COSTAFF/hector/sh_scripts/checkSshuttle.log
                if [ "$getAlivedSessions" == "0" ];then
                        ps -ef | grep sshuttle | grep dns | grep NHvr | awk '{print $2}' | xargs kill -9
                fi
        fi
        exit
fi
if [ "$Rstart" == "true" ] || [[ $# -eq 0 ]];then
        (sshuttle --dns -NHvr atlas 0/0 -x 172.17.0.0/16 &) 2> /dev/null
        exit
fi
if [ "$shutdown" == "true" ];then
         ps -ef | grep sshuttle | grep dns | grep NHvr | awk '{print $2}' | xargs kill -9
fi