#!/bin/bash
##############################################################################
# Filename:    userAccountsTool.sh
# Revision:    0.4.0
# Author:      Hector Barriga
#
# This sh script is to admin Linux Console user
# This sh script is mainly used by Tango CO engineers
# Copyright (c) Tango Telecom 2018
#
# All rights reserved.
# This document contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or
# in part is expressly prohibited, except as may be specifically
# authorized by prior written agreement or permission of Tango Telecom.
##############################################################################
# version 1.0 - First version
# version 2.0 - Introduce Areas - OAM and Providers
# version 3.0 - Introduce sudoers
# version 4.0 - Introduce SFTP users
version="4.0"
#
##############################################################################



# Inital Variables
amiroot=$(whoami)
hostname=$(hostname)
today=`date +20%y%m%d_%H%M`
time=`date +20%y%m%d_%H%M%S`
scriptDir="/tango/scripts/Generic/tools/userAccountsTool/"

# Subroutines

createBashFiles()
{
echo "# .bashrc_tango
# .bashrc_tango

# Source any global definitions
if [ -f /etc/bashrc ]; then
                                . /etc/bashrc
fi

umask 007

export CPU=linux
export PORT=linux

# User specific aliases and functions

export SYSTEM=`uname -s`
export EBSHOME=/usr/local
export EDITOR=vi

export PATH=.:/usr/sbin:/usr/bin:/usr/local/bin:/bin:/tango/bin
export MANPATH=/usr/share/man:/usr/local/man


if [ $SYSTEM == \"SunOS\" ]; then
   export PATH=$PATH:/opt/sfw/bin
   export MANPATH=$MANPATH:/usr/sfw/man:/opt/sfw/man
   export LD_LIBRARY_PATH=/usr/j2se/jre/lib/sparc/:/usr/sfw/lib/:/opt/csw/lib:/usr/lib:/usr/local/lib:/usr/local/ssl/lib
   alias sigtran='netstat -Psctp -v'
   alias ps2='/usr/ucb/ps -auxwww'
else
   export LD_LIBRARY_PATH=/opt/csw/lib:/usr/lib:/usr/local/lib:/usr/local/ssl/lib:/usr/lib64:/lib64
   alias sigtran='netstat --sctp -nv'
   # RHEL/Centos7.3 > clear not only clears screen but also scrallback. Annoying. This will prevent scrollback to be cleared
   alias mps='function mps(){ if [ -z \"$1\" ];then origTERM=$TERM;TERM=linux;/tango/bin/mps;TERM=$origTERM;else origTERM=$TERM;TERM=linux;/tango/bin/mps -r;TERM=$origTERM;fi;};mps'
fi

# Java Parameters
export JAVA_HOME=/usr/java/latest
export JAVA_JRE=$JAVA_HOME/jre
export JAVA_OPTS=\"-Xms2048m -Xmx2584m -XX:MaxPermSize=1024m -Dfile.encoding=UTF-8\"
export CATALINA_HOME=/usr/share/tomcat1


# We have to make sure the link exists :
export CLASSPATH=/usr/share/java/mysql-connector-java.jar:$CLASSPATH


# HISTORY ADDON from http://blog.sanctum.geek.nz/better-bash-history/
shopt -s histappend
shopt -s cmdhist
HISTFILESIZE=1000000
HISTSIZE=1000000
HISTCONTROL=ignoreboth
HISTIGNORE='ls:bg:fg:history'
HISTTIMEFORMAT='%F %T '
PROMPT_COMMAND='history -a'
HISTFILE=~/.bash_history
############################# END of HISTORY ADDON

function do_lm {
                 if [ \"`whoami`\" == \"root\" ]; then
                   echo \"root user cannot run lm command !\"
                 elif [ \"`whoami`\" == \"$user\" ]; then
                   echo \"$user user cannot run lm command ! It must be done as tango user\"
                 else
                   /tango/bin/lm
                 fi
}
# User specific aliases and functions
alias vi='echo "You dont have permission to run this command, contact Administrator";denied'
alias chmod='echo "You dont have permission to run this command, contact Administrator";denied'
alias chown='echo "You dont have permission to run this command, contact Administrator";denied'
alias cp='echo "You dont have permission to run this command, contact Administrator";denied'
alias emacs='echo "You dont have permission to run this command, contact Administrator";denied'
alias edit='echo "You dont have permission to run this command, contact Administrator";denied'
alias ex='echo "You dont have permission to run this command, contact Administrator";denied'
alias kill='echo "You dont have permission to run this command, contact Administrator";denied'
alias ln='echo "You dont have permission to run this command, contact Administrator";denied'
alias mail='echo "You dont have permission to run this command, contact Administrator";denied'
alias mkdir='echo "You dont have permission to run this command, contact Administrator";denied'
alias mv='echo "You dont have permission to run this command, contact Administrator";denied'
alias pkill='echo "You dont have permission to run this command, contact Administrator";denied'
alias popd='echo "You dont have permission to run this command, contact Administrator";denied'
alias pushd='echo "You dont have permission to run this command, contact Administrator";denied'
alias rm='echo "You dont have permission to run this command, contact Administrator";denied'
alias rmdir='echo "You dont have permission to run this command, contact Administrator";denied'
alias view='echo "You dont have permission to run this command, contact Administrator";denied'
alias w='echo "You dont have permission to run this command, contact Administrator";denied'
alias who='echo "You dont have permission to run this command, contact Administrator";denied'
alias write='echo "You dont have permission to run this command, contact Administrator";denied'
$2

export PS1=\"[\u@\h \t \W]$ \"" > /home/$user/.bashrc


echo "# .bash_profile

# Get the aliases and functions
if [ -f ~/.bashrc ]; then
                                . ~/.bashrc
hostanme=$(hostname)
                                echo \"\`tput setaf 3\`
==================================================================================
    _     _    __  __    _____                                ___    ___   ___
   (_)   /_\   \ \/ /   |_   _|  __ _   _ _    __ _   ___    |   \  | _ \ | __|
   | |  / _ \   >  <      | |   / _' | | ' \  / _' | / _ \   | |) | |   / | _|
   |_| /_/ \_\ /_/\_\     |_|   \__,_| |_||_| \__, | \___/   |___/  |_|_\ |___|
                                              |___/

                                     TELEFONICA

$hostanme

\`tput setaf 2\`$1\`tput setaf 3\`

ACCESS TO THIS SYSTEM IS STRICTLY RESTRICTED TO AUTHORIZED PERSONS ONLY.
UNAUTHORIZED ACCESS TO THIS SYSTEM IS NOT ALLOWED AND EVERY ACTIVITY IS MONITORED.
==================================================================================\`tput sgr0\`
\"
fi

# User specific environment and startup programs
# are specified in ~/.bashrc
" >  /home/$user/.bash_profile
}


#Script
if [ "$amiroot" != "root" ];then
        echo -e "\n`tput setaf 1`Sorry, you must run this script as \"root\" user, bye`tput sgr0`\n"
        exit
fi

echo ""
echo "#############################################################################################################"
echo "#                                                                                                           #"
echo "#          __  __                  ___                               __          ______            __       #"
echo "#         / / / /_______  _____   /   | ______________  __  ______  / /______   /_  __/___  ____  / /       #"
echo "#        / / / / ___/ _ \/ ___/  / /| |/ ___/ ___/ __ \/ / / / __ \/ __/ ___/    / / / __ \/ __ \/ /        #"
echo "#       / /_/ (__  )  __/ /     / ___ / /__/ /__/ /_/ / /_/ / / / / /_(__  )    / / / /_/ / /_/ / /         #"
echo "#       \__,_/____/\___/_/     /_/  |_\___/\___/\____/\__,_/_/ /_/\__/____/    /_/  \____/\____/_/          #"
echo "#                                                                                                           #"
echo "#                                                                                                           #"
echo "#                                                  Shell  Script                                            #"
echo "#   ® Tango Telecom                                                                          Version $version    #"
echo "#                                                                                                           #"
echo "#############################################################################################################"
echo ""
echo ""
echo ""
echo "-------------------------------------------------------------------------------------------------------------"
echo "|                                                Main Menu                                                  |"
echo "|                                                                                                           |"
echo "|                                           1. Create a new User                                            |"
echo "|                                           2. Delete an User                                               |"
echo "|                                           3. Modify an User                                               |"
echo "|                                           4. Deactivate an User                                           |"
echo "|                                           5. Activate an User                                             |"
echo "|                                           6. List All Users                                               |"
echo "|                                           7. Exit                                                         |"
echo "|                                                                                                           |"
echo "| Control+C to Exit/Cancel                                                                                  |"
echo "-------------------------------------------------------------------------------------------------------------"
echo ""
echo -n " Enter option (Enter only number 1,2,3,4,5,6 or 7) > "
read mainopt


######################### Opt 1  ############################

if [ "$mainopt" == "1" ]; then
        echo ""
        echo "-------------------------------------------------------------------------------------------------------------"
        echo "|                                              1. Create a new User                                         |"
        echo "-------------------------------------------------------------------------------------------------------------"
        echo ""
        echo ""
        echo -n " Enter new username > "
        read user
        DoesUserExit=$(cat /etc/passwd | grep "$user" | egrep -v grep)
        if [ "$user" == "tango" ] || [ "$user" == "root" ] || [ "$user" == "elasticsearch" ] || [ "$user" == "mysql" ] || [ "$user" == "kibana" ];then
                echo "-------------------------------------------------------------------------------------------------------------"
                echo "|`tput setaf 1` Sorry, you cannot create \"$user\". You might either not be allowed to do that or user already exists, Bye.`tput sgr0`"
                echo "-------------------------------------------------------------------------------------------------------------"
                exit
        fi
        if [ ! -z "$DoesUserExit" ];then
                echo "-------------------------------------------------------------------------------------------------------------"
                echo  "|`tput setaf 1` Sorry, you cannot create \"$user\". It already exists, Bye.`tput sgr0`"
                echo "-------------------------------------------------------------------------------------------------------------"
                exit
        fi
        usernamelength=$(echo $user | wc -c | tr -s " ")
        if  [ "$usernamelength" -lt "15" ] && [ "$usernamelength" -gt "6" ]; then
                passwd="/etc/passwd"
                last_user_id=$(grep ":15" /etc/passwd | grep "home" | egrep -v "xymon" | egrep -v kibana |  egrep -v "elasticsearch" | /bin/tail -1  | cut -d: -f3)
                suggest_user_id=$((last_user_id+1))
                alreadyexit=$(/bin/cat $passwd | /bin/grep $suggest_user_id)
                echo ""
                echo "-----------------------------------------------------------------------"
                echo "|  /etc/passwd shows that last User ID is: $last_user_id.                      |"
                if [ -z "$alreadyexit" ];then
                                echo "|  `tput setaf 3`User ID `tput sgr0`$suggest_user_id `tput setaf 3`doesnt exist.                                        `tput sgr0` |"
                                echo "|  `tput setaf 3`I suggest you to Enter `tput sgr0`$suggest_user_id `tput setaf 3`as User ID to the new user $user `tput sgr0`      "
                                echo "-----------------------------------------------------------------------"
                        else
                                echo "| `tput setaf 1` !!!Important $suggest_user_id Already exists, DO NOT USE IT. Check /etc/passwd   `tput sgr0`          |"
                                echo "-----------------------------------------------------------------------"
                fi
                echo -n " Enter new User ID [Default = $suggest_user_id] > "
                read user_id
                if [ -z "$user_id" ];then
                        user_id="$suggest_user_id"
                fi
                if ! [[ "$user_id" =~ ^[0-9]+$ ]];then
                        echo ""
                        echo "------------------------------------------------------------------------------------------"
                        echo "|  `tput setaf 1`User ID is not an integer.                                                          `tput sgr0`  |"
                        echo "|  `tput setaf 1`I suggest you to Enter `tput sgr0`$suggest_user_id `tput setaf 1`as User ID to the new user $user, Please try again.    `tput sgr0` "
                        echo "------------------------------------------------------------------------------------------"
                        echo "Bye"
                        exit
                fi
                echo ""
                echo -n " Enter new user Full Name (Example: HECTOR BARRIGA) > "
                read wholename
                if [ -z "$wholename" ];then
                        echo ""
                        echo "---------------------------------------------------------------------------------"
                        echo "| `tput setaf 1`Sorry, Full Name can not be empty. Bye`tput sgr0`                                        |"
                        echo "---------------------------------------------------------------------------------"
                        exit
                fi
                echo ""
                echo "-----------------------------------------------------------------------"
                echo "| Enter which group $user $wholename belongs to:                       "
                echo "| 1. OAM                                                              |"
                echo "| 2. Provider                                                         |"
                echo "-----------------------------------------------------------------------"
                echo ""
                echo -n " Enter option (Enter only number 1 or 2) > "
                read area
                if  [ "$area" != "1" ] && [ "$area" != "2" ]; then
                        echo ""
                        echo "---------------------------------------------------------------------------------"
                        echo "|`tput setaf 1` You enter a wrong option, enter only number 1 or 2. Please try again. `tput sgr0`        |"
                        echo "---------------------------------------------------------------------------------"
                        echo "Bye"
                elif [ "$area" == "1" ]; then
                        echo ""
                        echo "-----------------------------------------------------------------------"
                        echo "| Enter which permissions $user $wholename will have                   "
                        echo "| 1. Read Only                                                        |"
                        echo "| 2. Sudoer                                                           |"
                        echo "| 3. FTP or SFTP                                                      |"
                        echo "-----------------------------------------------------------------------"
                        echo ""
                        echo -n " Enter option (Enter only number 1,2 or 3) > "
                        read permissions
                        if [ "$permissions" == "2" ];then
                                permissionsStr="Sudoer"
                        elif [ "$permissions" == "3" ];then
                                permissionsStr="FTP or SFTP"
                                cdalias="alias cd='denied'"
                        else
                                permissionsStr="Read Only"
                        fi
                        echo ""
                        echo "-----------------------------------------------------------------------"
                        echo "| `tput setaf 3`New user      = `tput sgr0`$user"
                        echo "| `tput setaf 3`user_id       = `tput sgr0`$user_id"
                        echo "| `tput setaf 3`New User Name = `tput sgr0`$wholename"
                        echo "| `tput setaf 3`Area          = `tput sgr0`OAM"
                        echo "| `tput setaf 3`Permissions   = `tput sgr0`$permissionsStr"
                        echo "-----------------------------------------------------------------------"
                        echo -n "  Are you sure you want to create it? Enter Y/N > "
                        read confirm
                        read confirmlowercase <<<$(echo $confirm | tr '[:upper:]' '[:lower:]')
                        if [ "$confirmlowercase" == "y" ]; then
                                if [ ! -f /tango/logs/COSTAFF/files_backups/ ];then
                                                                mkdir -p /tango/logs/COSTAFF/files_backups/
                                fi
                                /bin/cp -rfp /etc/passwd /tango/logs/COSTAFF/files_backups/passwd.back_$time
                                /bin/cp -rfp /etc/group /tango/logs/COSTAFF/files_backups/group.back_$time
                                echo ""
                                echo "-----------------------------------------------------------------------------------------------------"
                                echo "| Old /etc/passwd and /etc/group are backed up in /tango/logs/COSTAFF/files_backups/                |"
                                echo "-----------------------------------------------------------------------------------------------------"
                                echo ""
                                if [ "$permissions" == "2" ];then
                                                                /usr/sbin/useradd -c "OAM $wholename SUDOER" -d /home/$user -g wheel -G operator,readonly  -s /bin/bash -u $user_id $user
                                                                /usr/sbin/usermod -aG wheel $user
                                                                if [ ! -d /home/$user ];then
                                                                                                /bin/mkdir /home/$user
                                                                fi
                                                                /bin/chown root:wheel /home/$user
                                else
                                                                /usr/sbin/useradd -c "OAM $wholename" -d /home/$user -g tango -G operator,readonly  -s /bin/bash -u $user_id $user
                                                                if [ ! -d /home/$user ];then
                                                                                                /bin/mkdir /home/$user
                                                                fi
                                                                /bin/chown root:tango /home/$user
                                fi
                                /bin/chmod 770 /home/$user
                                echo ""
                                echo "-----------------------------------------------------------------------------------------------------"
                                echo "| The first 8 characters of the password must contain at least 1 numeric or special character(s).   |"
                                echo "| The password must have at least 8 characters                                                      |"
                                echo "| Password will be required to be changed every 90 days                                             |"
                                echo "-----------------------------------------------------------------------------------------------------"
                                echo ""
                                echo "changeme" | /usr/bin/passwd --stdin "$user"
                                /usr/bin/passwd -e $user >/dev/null 2>&1
                                echo ""
                                echo "Creating /home/$user/.bashrc /home/$user/.bash_profile    ......."
                                if [ "$permissions" == "2" ];then
                                                                createBashFiles "User:$user Group:OAM  [SUDOER]"
                                                                /bin/chmod 750 /home/$user/.bashrc /home/$user/.bash_profile
                                                                /bin/chown root:wheel /home/$user/.bashrc /home/$user/.bash_profile
                                        else
                                                                createBashFiles "User:$user Group:OAM  [READ ONLY ACCESS]" "$cdalias"
                                                                /bin/chmod 750 /home/$user/.bashrc /home/$user/.bash_profile
                                                                /bin/chown root:tango /home/$user/.bashrc /home/$user/.bash_profile
                                fi
                                source /home/$user/.bashrc
                                echo ""
                                echo "-----------------------------------------------------------------------"
                                echo "|`tput setaf 2` User was created successfully.   `tput sgr0`                                   |"
                                echo "-----------------------------------------------------------------------"
                                echo ""
                                echo ""
                                echo "--------------------------------------------------------------------------------------------------------------"
                                echo "|`tput setaf 2` New user = $user , user_id = $user_id, Area = OAM has been created successfully.`tput sgr0`"
                                echo "|`tput setaf 2` A new directory has been created for the new user. New directory = /home/$user/`tput sgr0`"
                                echo "|`tput setaf 2` Please provide username and password `tput setaf 5`changeme`tput setaf 2` to Mr(s) $wholename He will have to change it at first login`tput sgr0`"
                                echo "|                                                                                                   "
                                echo "|`tput setaf 2` @@@ Note that you will be able to monitor WHEN and WHAT actions this new user will do on the node @@@  `tput sgr0`"
                                echo "|                                                                                                   "
                                echo "|`tput setaf 2` All $wholename 's actions and date and time will be stored in /home/$user/.bash_history`tput sgr0`"
                                echo "|`tput setaf 2` Run these commands as root to see all actions together with their date and time`tput sgr0`"
                                echo "|                                                                                                   "
                                echo "|`tput setaf 2` su - $user `tput sgr0`"
                                echo "|`tput setaf 2` history `tput sgr0`"
                                echo "--------------------------------------------------------------------------------------------------------------"
                                echo "Bye"
                        else
                                echo ""
                                echo "-----------------------------"
                                echo "|`tput setaf 1` User was not created   `tput sgr0`   |"
                                echo "|`tput setaf 1` You did not enter Y     `tput sgr0`  |"
                                echo "-----------------------------"
                                echo "Bye"
                        fi
           elif [ "$area" == "2" ]; then
                        echo ""
                        echo "-----------------------------------------------------------------------"
                        echo "| Enter which permissions $user $wholename will have                   "
                        echo "| 1. Read Only                                                        |"
                        echo "| 2. Sudoer                                                           |"
                        echo "| 3. FTP or SFTP                                                      |"
                        echo "-----------------------------------------------------------------------"
                        echo ""
                        echo -n " Enter option (Enter only number 1,2 or 3) > "
                        read permissions
                        if [ "$permissions" == "2" ];then
                                permissionsStr="Sudoer"
                        elif [ "$permissions" == "3" ];then
                                permissionsStr="FTP or SFTP"
                                cdalias="alias cd='denied'"
                        else
                                permissionsStr="Read Only"
                        fi
                        echo ""
                        echo "-----------------------------------------------------------------------"
                        echo "| `tput setaf 3`New user      = `tput sgr0`$user"
                        echo "| `tput setaf 3`user_id       = `tput sgr0`$user_id"
                        echo "| `tput setaf 3`New User Name = `tput sgr0`$wholename"
                        echo "| `tput setaf 3`Group         = `tput sgr0`PROVIDER"
                        echo "| `tput setaf 3`Permissions   = `tput sgr0`$permissionsStr"
                        echo "-----------------------------------------------------------------------"
                        echo -n "Are you sure you want to create it? Enter Y/N > "
                        read confirm3
                        read confirmlowercase3 <<<$(echo $confirm3 | tr '[:upper:]' '[:lower:]')
                        if [ "$confirmlowercase3" == "y" ]; then
                                if [ ! -f /tango/logs/COSTAFF/files_backups/ ];then
                                        mkdir -p /tango/logs/COSTAFF/files_backups/
                                fi
                                /bin/cp -rfp /etc/passwd /tango/logs/COSTAFF/files_backups/passwd.back_$time
                                /bin/cp -rfp /etc/group /tango/logs/COSTAFF/files_backups/group.back_$time
                                echo ""
                                echo "-----------------------------------------------------------------------------------------------------"
                                echo "| Old /etc/passwd and /etc/group are backed up in /tango/logs/COSTAFF/files_backups/                |"
                                echo "-----------------------------------------------------------------------------------------------------"
                                echo ""
                                if [ "$permissions" == "2" ];then
                                        /usr/sbin/useradd -c "PROVIDER $wholename SUDOER" -d /home/$user -g wheel -G operator,readonly  -s /bin/bash -u $user_id $user
                                        /usr/sbin/usermod -aG wheel $user
                                        if [ ! -d /home/$user ];then
                                                /bin/mkdir /home/$user
                                        fi
                                        /bin/chown root:wheel /home/$user
                                else
                                        /usr/sbin/useradd -c "PROVIDER $wholename" -d /home/$user -g tango -G operator,readonly  -s /bin/bash -u $user_id $user
                                        if [ ! -d /home/$user ];then
                                                                        /bin/mkdir /home/$user
                                        fi
                                        /bin/chown root:tango /home/$user
                                fi
                                /bin/chmod 770 /home/$user
                                echo ""
                                echo "-----------------------------------------------------------------------------------------------------"
                                echo "| The first 8 characters of the password must contain at least 1 numeric or special character(s).   |"
                                echo "| The password must have at least 8 characters                                                      |"
                                echo "| Password will be required to be changed every 90 days                                             |"
                                echo "-----------------------------------------------------------------------------------------------------"
                                echo ""
                                echo "changeme" | /usr/bin/passwd --stdin "$user"
                                /usr/bin/passwd -e $user >/dev/null 2>&1
                                echo ""
                                echo "Creating /home/$user/.bashrc /home/$user/.bash_profile    ......."
                                if [ "$permissions" == "2" ];then
                                        createBashFiles "User:$user Group:PROVIDER  [SUDOER]"
                                        /bin/chmod 750 /home/$user/.bashrc /home/$user/.bash_profile
                                        /bin/chown root:wheel /home/$user/.bashrc /home/$user/.bash_profile
                                else
                                        createBashFiles "User:$user Group:PROVIDER  [READ ONLY ACCESS]" "$cdalias"
                                        /bin/chmod 750 /home/$user/.bashrc /home/$user/.bash_profile
                                        /bin/chown root:tango /home/$user/.bashrc /home/$user/.bash_profile
                                fi
                                source /home/$user/.bashrc
                                echo ""
                                echo "-----------------------------------------------------------------------"
                                echo "| User was created successfully.                                      |"
                                echo "-----------------------------------------------------------------------"
                                echo ""
                                echo ""
                                echo "--------------------------------------------------------------------------------------------------------------"
                                echo "|`tput setaf 2` New user = $user , user_id = $user_id, Area = Provider has been created successfully.`tput sgr0`"
                                echo "|`tput setaf 2` A new directory has been created for the new user. New directory = /home/$user/`tput sgr0`"
                                echo "|`tput setaf 2` Please provide username and password `tput setaf 5`changeme`tput setaf 2` to Mr(s) $wholename He will have to change it at first login`tput sgr0`"
                                echo "|                                                                                                   "
                                echo "|`tput setaf 2` @@@ Note that you will be able to monitor WHEN and WHAT actions this new user will do on the node @@@`tput sgr0`  "
                                echo "|                                                                                                   "
                                echo "|`tput setaf 2` All $wholename 's actions and date and time will be stored in /home/$user/.bash_history`tput sgr0`"
                                echo "|`tput setaf 2` Run these commands as root to see all actions together with their date and time`tput sgr0`"
                                echo "|                                                                                                   "
                                echo "|`tput setaf 2` su - $user `tput sgr0`"
                                echo "|`tput setaf 2` history `tput sgr0`"
                                echo "--------------------------------------------------------------------------------------------------------------"
                                echo "Bye"
                        else
                                echo ""
                                echo "---------------------------"
                                echo "|`tput setaf 3` User was not created    `tput sgr0`|"
                                echo "|`tput setaf 3` You did not enter Y     `tput sgr0`|"
                                echo "---------------------------"
                                echo "Bye"
                        fi
                fi
        else
                echo "--------------------------------------------------------------------"
                echo "|`tput setaf 1` $user username is too long or too short !!!    `tput sgr0`                  "
                echo "|`tput setaf 1` Username must have more than 5 and less than 15 characters `tput sgr0`      |"
                echo "|`tput setaf 1` Please start again                                             `tput sgr0`  |"
                echo "--------------------------------------------------------------------"
                echo " Bye "
        fi


######################### Opt 2  ############################

elif [ "$mainopt" == "2" ]; then
        echo ""
        echo "-------------------------------------------------------------------------------------------------------------"
        echo "|                                              2. Delete an User                                            |"
        echo "-------------------------------------------------------------------------------------------------------------"
        echo "| `tput setaf 3`Current Users:`tput sgr0`                                                                                            |"
        cat /etc/passwd | grep home | egrep -v tango | egrep -v root | egrep -v xymon | egrep -v kibana | egrep -v elasticsearch | grep "$username" | awk 'BEGIN{FS=":"}{print "| - " $1}'
        echo "-------------------------------------------------------------------------------------------------------------"
        echo ""
        echo -n "Enter username > "
        read username
        user=$(cat /etc/passwd | grep home | egrep -v tango | egrep -v root | egrep -v xymon | egrep -v kibana | egrep -v elasticsearch | grep "$username" | awk 'BEGIN{FS=":"}{print $1}')
        if [ -z "$user" -o "$user" != "$username" ]; then
                echo "--------------------------------------------------------"
                echo "|`tput setaf 1` User doesn't Exist or you are not allowed to delete  `tput sgr0`|"
                echo "--------------------------------------------------------"
                echo "Bye"
        else
                user_id=$(cat /etc/passwd | grep home | egrep -v tango | egrep -v root | egrep -v xymon | egrep -v kibana | egrep -v elasticsearch | grep "$username" | awk 'BEGIN{FS=":"}{print $3}')
                wholename=$(cat /etc/passwd | grep home | egrep -v tango | egrep -v root | egrep -v xymon | egrep -v kibana |  egrep -v elasticsearch | grep "$username" | awk 'BEGIN{FS=":"}{print $5}')
                userdir=/home/$username/
                echo ""
                echo "User      = $user"
                echo "user_id   = $user_id"
                echo "User Name = $wholename"
                echo ""
                echo "-------------------------------------------------------------------------------"
                echo "| `tput setaf 1`Make sure it is the user you want to delete!!!!!  If not, please Enter N `tput sgr0`  |"
                echo "-------------------------------------------------------------------------------"
                echo ""
                echo -n "Are you sure you want to delete it? Enter Y/N > "
                read confirm2
                read confirm2lowercase <<<$(echo $confirm2 | tr '[:upper:]' '[:lower:]')
                if [ "$confirm2lowercase" == "y" ]; then
                        if [ ! -f /tango/logs/COSTAFF/files_backups/ ];then
                                        mkdir -p /tango/logs/COSTAFF/files_backups/
                        fi
                        /bin/cp -rfp /etc/passwd /tango/logs/COSTAFF/files_backups/passwd.back_$time
                        /bin/cp -rfp /etc/group /tango/logs/COSTAFF/files_backups/group.back_$time
                        /bin/mv /home/$username /tango/logs/COSTAFF/files_backups/
                        mv /var/spool/mail/$user /tango/logs/COSTAFF/files_backups/$user_var_sopp_mail_file
                        userdel $username
                        echo ""
                        echo "---------------------------------------------------------------------"
                        echo "|`tput setaf 2` User was deleted successfully. `tput sgr0`                                    |"
                        echo "|`tput setaf 2` These commands were run:          `tput sgr0`                                 |"
                        echo "|`tput setaf 2` mv /home/$userdir /tango/logs/COSTAFF/files_backups/`tput sgr0`     "
                        echo "|`tput setaf 2` mv /var/spool/mail/$user /tango/logs/COSTAFF/files_backups/`tput sgr0` "
                        echo "|`tput setaf 2` cp -rfp /etc/passwd /tango/logs/COSTAFF/files_backups/`tput sgr0` "
                        echo "|`tput setaf 2` cp -rfp /etc/group /tango/logs/COSTAFF/files_backups/`tput sgr0` "
                        echo "|`tput setaf 2` userdel $username                           `tput sgr0` "
                        echo "---------------------------------------------------------------------"
                        echo ""
                        echo "Bye"

                else
                        echo "-----------------------------"
                        echo "|`tput setaf 3` User was not deleted.     `tput sgr0`"
                        echo "-----------------------------"
                        echo "Bye"
                fi
        fi




######################### Opt 3  ############################

elif [ "$mainopt" == "3" ]; then
        echo ""
        echo "-------------------------------------------------------------------------------------------------------------"
        echo "|                                              3. Modify an User                                            |"
        echo "-------------------------------------------------------------------------------------------------------------"
        echo ""
        echo ""
        echo "-----------------------------------------------------------------------"
        echo "| Groups user will belong to:                                         |"
        echo "| 1. OAM                                                              |"
        echo "| 2. Provider                                                         |"
        echo "-----------------------------------------------------------------------"
        echo ""
        echo -n " Enter option (Enter only number 1 or 2) > "
        read area
        if  [ "$area" != "1" ] && [ "$area" != "2" ]; then
                echo ""
                echo "---------------------------------------------------------------------------------"
                echo "| You enter a wrong option, enter only number 1 or 2. Please try again.         |"
                echo "---------------------------------------------------------------------------------"
                echo "Bye"
        elif [ "$area" == "1" ]; then
                echo ""
                echo "-------------------------------------------------------------------------------------------------------------"
                echo "|                                              Group OAM                                                    |"
                echo "|                                             User Modify                                                   |"
                echo "-------------------------------------------------------------------------------------------------------------"
        echo "| `tput setaf 3`Current Users:`tput sgr0`                                                                                            |"
                cat /etc/passwd | grep "OAM" | egrep "home" |  egrep -v "xymon" | egrep -v kibana |  egrep -v "elasticsearch" | awk 'BEGIN{FS=":"}{print "| - " $1}'
                echo "-------------------------------------------------------------------------------------------------------------"
                echo ""
                echo -n " Enter current username (The username you want to modify) > "
                read username
                user=$(cat /etc/passwd | grep "OAM" | grep -v ":30" | grep -v "bin:" | grep -v "daemon" | grep -v "sys" | grep -v "adm" | grep -v "lp" | grep -v "uucp" | grep -v "smmsp" | grep -v "listen" | grep -v "gdm" | grep -v "webservd" | grep -v "postgres" | grep -v "svctag" | grep -v "unknown" | grep -v "nobody" | grep -v "noaccess" | grep -v "tango" | grep -v "ftp" | grep -v "mysql" | grep "$username" | awk 'BEGIN{FS=":"}{print $1}')
                if [ -z "$user" -o "$user" != "$username" ]; then
                        echo "----------------------------------------------"
                        echo "| `tput setaf 1`User doesn't belong to OAM Group       `tput sgr0`    |"
                        echo "----------------------------------------------"
                        echo "Bye"
                else
                        echo ""
                        echo "--------------------------------------------"
                        echo "| Type of change:                          |"
                        echo "| 1. Change Password                       |"
                        echo "| 2. Change User                           |"
                        echo "--------------------------------------------"
                        echo ""
                        echo -n " Enter option (Enter only number 1 or 2) > "
                        read changetype
                        if [ "$changetype" != "2" -a "$changetype" != "1" ]; then
                                echo "-------------------------------------------------------------------------"
                                echo "|`tput setaf 1` You enter a wrong option, enter only number 1 or 2. Please try again. `tput sgr0`|"
                                echo "-------------------------------------------------------------------------"
                        elif [ "$changetype" == "1" ];then
                                echo ""
                                echo "-----------------------------------------------------------------------------------------------------"
                                echo "| The first 8 characters of the password must contain at least 1 numeric or special character(s).   |"
                                echo "| The password must have at least 8 characters                                                      |"
                                echo "| Password will be required to be changed every 90 days                                             |"
                                echo "-----------------------------------------------------------------------------------------------------"
                                echo ""
                                echo -n " Are you sure you want to modify $user password? (Enter Y or N) > "
                                read confirmChangePW
                                read confirmChangePWlowercase <<<$(echo $confirmChangePW | tr '[:upper:]' '[:lower:]')
                                if [ "$confirmChangePWlowercase" == "y" ]; then
                                        echo "changeme" | /usr/bin/passwd --stdin "$username"
                                        /usr/bin/passwd -e $username >/dev/null 2>&1
                                        echo "-----------------------------------------------------------------------"
                                        echo "| User Password was modified successfully.                            |"
                                        echo "-----------------------------------------------------------------------"
                                        echo ""
                                        echo ""
                                        echo "--------------------------------------------------------------------------------------------------------------"
                                        echo "|`tput setaf 2` User                = $user`tput sgr0`"
                                        echo "|`tput setaf 2` User_id             = $user_id`tput sgr0`"
                                        echo "|`tput setaf 2` User home directory = /home/$user/`tput sgr0`"
                                        echo "|`tput setaf 2` Group               = PROVIDER`tput sgr0`"
                                        echo "|`tput setaf 2` Temporal Password   = `tput setaf 5`changeme`tput sgr0`"
                                        echo "|`tput setaf 2` Please provide temporal password to Mr(s) $wholename. He will have to change it at first login`tput sgr0`"
                                        echo "|                                                                                                   "
                                        echo "|`tput setaf 2` @@@ Note that you will be able to monitor WHEN and WHAT actions this new user will do on the node @@@`tput sgr0`  "
                                        echo "|                                                                                                   "
                                        echo "|`tput setaf 2` All $wholename 's actions and date and time will be stored in /home/$user/.bash_history`tput sgr0`"
                                        echo "|`tput setaf 2` Run these commands as root to see all actions together with their date and time`tput sgr0`"
                                        echo "|                                                                                                   "
                                        echo "|`tput setaf 2` su - $user `tput sgr0`"
                                        echo "|`tput setaf 2` history `tput sgr0`"
                                        echo "--------------------------------------------------------------------------------------------------------------"
                                        echo "Bye"
                                else
                                        echo ""
                                        echo "--------------------------------"
                                        echo "| `tput setaf 1`Password was not modified    `tput sgr0`|"
                                        echo "| `tput setaf 1`You did not enter Y          `tput sgr0`|"
                                        echo "--------------------------------"
                                        echo "Bye"
                                fi
                        elif [ "$changetype" == "2" ];then
                                echo -n " Enter new username > "
                                read newuser
                                usernamelength=$(echo $newuser | wc -c | tr -s " ")
                                echo "$usernamelength"
                                if  [ "$usernamelength" -lt "15" ] && [ "$usernamelength" -gt "6" ]; then
                                        passwd="/etc/passwd"
                                        last_user_id=$(grep ":15" /etc/passwd | egrep -v ":30" | /bin/tail -1  | cut -d: -f3)
                                        suggest_user_id=$((last_user_id+1))
                                        alreadyexit=$(/bin/cat $passwd | /bin/grep $suggest_user_id)
                                        if [ -z "$alreadyexit" ]; then
                                                echo ""
                                                echo "----------------------------------------------------------------------"
                                                echo "|  `tput setaf 3`User ID `tput sgr0`$suggest_user_id `tput setaf 3`doesnt exist.                                       `tput sgr0`  |"
                                                echo "|  `tput setaf 3`I suggest you to Enter `tput sgr0`$suggest_user_id `tput setaf 3`as User ID to the new user $user    `tput sgr0` "
                                                echo "----------------------------------------------------------------------"
                                        else
                                                echo "----------------------------------------------------------------------"
                                                echo "| `tput setaf 3` !!!Important $suggest_user_id Already exists, DO NOT USE IT. Check /etc/passwd           `tput sgr0`  |"
                                                echo "----------------------------------------------------------------------"
                                        fi
                                        echo -n " Enter new User ID [Default = $suggest_user_id] > "
                                        read newuser_id
                                        if [ -z "$newuser_id" ];then
                                                  newuser_id="$suggest_user_id"
                                        fi
                                        if ! [[ "$newuser_id" =~ ^[0-9]+$ ]];then
                                                echo ""
                                                echo "------------------------------------------------------------------------------------------"
                                                echo "|  `tput setaf 1`User ID is not an integer.                                                          `tput sgr0`  |"
                                                echo "|  `tput setaf 1`I suggest you to Enter `tput sgr0`$suggest_user_id `tput setaf 1`as User ID to the new user $newuser, Please try again.    `tput sgr0` "
                                                echo "------------------------------------------------------------------------------------------"
                                                echo "Bye"
                                                exit
                                        fi
                                        echo -n " Enter new user Full Name (Example: ERIC COLON) > "
                                        read newwholename
                                        if [ -z "$newwholename" ];then
                                                echo ""
                                                echo "---------------------------------------------------------------------------------"
                                                echo "| `tput setaf 1`Sorry, Full Name can not be empty. Try Again.`tput sgr0`                      |"
                                                echo "---------------------------------------------------------------------------------"
                                                echo -n " Enter new user Full Name (Example: ERIC COLON) > "
                                                read newwholename
                                                if [ -z "$newwholename" ];then
                                                        echo ""
                                                        echo "---------------------------------------------------------------------------------"
                                                        echo "| `tput setaf 1`Sorry, Full Name can not be empty. Bye`tput sgr0`                             |"
                                                        echo "---------------------------------------------------------------------------------"
                                                        exit
                                                fi
                                        fi
                                        echo ""
                                        echo "-----------------------------------------------------------------------"
                                        echo "| Enter which permissions $newuser $newwholename will have                   "
                                        echo "| 1. Read Only                                                        |"
                                        echo "| 2. Sudoer                                                           |"
                                        echo "| 3. FTP or SFTP                                                      |"
                                        echo "-----------------------------------------------------------------------"
                                        echo ""
                                        echo -n " Enter option (Enter only number 1 or 2) > "
                                        read permissions
                                        if [ "$permissions" == "2" ];then
                                                permissionsStr="Sudoer"
                                        elif [ "$permissions" == "3" ];then
                                                permissionsStr="FTP or SFTP"
                                                cdalias="alias cd='denied'"
                                        else
                                                permissionsStr="Read Only"
                                        fi
                                        user_id=$(grep $username /etc/passwd |egrep -v tango | egrep -v ":30" | awk 'BEGIN{FS=":"}{print $3}')
                                        user_group=$(grep $username /etc/passwd |egrep -v tango | egrep -v ":30" | awk 'BEGIN{FS=":"}{print $5}' | awk '{print $1}')
                                        wholename=$(cat /etc/passwd | grep $username | awk 'BEGIN{FS=":"}{print $5}')
                                        userdir=/home/$username/
                                        echo ""
                                        echo "-------------------------------------------------------------------------------"
                                        echo "| Make sure it is the user your want to modify!!!!!  If not, please Enter N   |"
                                        echo "-------------------------------------------------------------------------------"
                                        echo " OLD USER:"
                                        echo "-------------------------------------------------------------------------------"
                                        echo "| Old User       = $user"
                                        echo "| Old user_id    = $user_id"
                                        echo "| Old User Name  = $wholename"
                                        echo "| Old User Group = $user_group"
                                        echo "-------------------------------------------------------------------------------"
                                        echo " NEW USER:"
                                        echo "-----------------------------------------------------------------------"
                                        echo "| `tput setaf 3`New user      = `tput sgr0`$newuser"
                                        echo "| `tput setaf 3`New user_id   = `tput sgr0`$newuser_id"
                                        echo "| `tput setaf 3`New User Name = `tput sgr0`$newwholename"
                                        echo "| `tput setaf 3`Group         = `tput sgr0`OAM"
                                        echo "| `tput setaf 3`Permissions   = `tput sgr0`$permissionsStr"
                                        echo "-----------------------------------------------------------------------"
                                        echo -n "Are you sure you want to modify $user? Enter Y/N > "
                                        read confirm3
                                        read confirm3lowercase <<<$(echo $confirm3 | tr '[:upper:]' '[:lower:]')
                                        if [ "$confirm3lowercase" == "y" ]; then
                                                echo ""
                                                if [ ! -f /tango/logs/COSTAFF/files_backups/ ];then
                                                        mkdir -p /tango/logs/COSTAFF/files_backups/
                                                fi
                                                /bin/cp -rfp /etc/passwd /tango/logs/COSTAFF/files_backups/passwd.back_$time
                                                /bin/cp -rfp /etc/group /tango/logs/COSTAFF/files_backups/group.back_$time
                                                /bin/mv /home/$username /tango/logs/COSTAFF/files_backups/
                                                mv /var/spool/mail/$user /tango/logs/COSTAFF/files_backups/$user_var_sopp_mail_file
                                                echo ""
                                                echo "-----------------------------------------------------------------------------------------------------"
                                                echo "| Old $username user backups are created in /tango/logs/COSTAFF/files_backups/                      |"
                                                echo "-----------------------------------------------------------------------------------------------------"
                                                echo ""
                                                userdel $username
                                                if [ "$permissions" == "2" ];then
                                                        /usr/sbin/useradd -c "OAM $newwholename SUDOER" -d /home/$newuser -g wheel -G operator,readonly  -s /bin/bash -u $newuser_id $newuser
                                                        /usr/sbin/usermod -aG wheel $newuser
                                                        if [ ! -d /home/$user ];then
                                                                        /bin/mkdir /home/$newuser
                                                        fi
                                                        /bin/chown root:wheel /home/$newuser
                                                        /bin/chmod 770 /home/$newuser
                                                else
                                                        /usr/sbin/useradd -c "OAM $newwholename" -d /home/$newuser -g tango -G operator,readonly  -s /bin/bash -u $newuser_id $newuser
                                                        if [ ! -d /home/$user ];then
                                                                        /bin/mkdir /home/$newuser
                                                        fi
                                                        /bin/chown root:tango /home/$newuser
                                                        /bin/chmod 770 /home/$newuser
                                                fi
                                                echo ""
                                                echo "-----------------------------------------------------------------------------------------------------"
                                                echo "| The first 8 characters of the password must contain at least 1 numeric or special character(s).   |"
                                                echo "| The password must have at least 8 characters                                                      |"
                                                echo "| Password will be required to be changed every 90 days                                             |"
                                                echo "-----------------------------------------------------------------------------------------------------"
                                                echo ""
                                                echo "changeme" | /usr/bin/passwd --stdin "$newuser"
                                                /usr/bin/passwd -e $newuser >/dev/null 2>&1
                                                echo ""
                                                echo "Creating /$newuser/.bashrc /$newuser/.bash_profile    ......."
                                                if [ "$permissions" == "2" ];then
                                                        createBashFiles "User:$user Group:OAM  [SUDOER]"
                                                        /bin/chmod 750 /home/$user/.bashrc /home/$user/.bash_profile
                                                        /bin/chown root:wheel /home/$user/.bashrc /home/$user/.bash_profile
                                                else
                                                        createBashFiles "User:$user Group:OAM  [READ ONLY ACCESS]" "$cdalias"
                                                        /bin/chmod 750 /home/$user/.bashrc /home/$user/.bash_profile
                                                        /bin/chown root:tango /home/$user/.bashrc /home/$user/.bash_profile
                                                fi
                                                source /home/$user/.bashrc
                                                echo ""
                                                echo "-----------------------------------------------------------------------"
                                                echo "| `tput setaf 2`User was modified successfully.  `tput sgr0`                                   |"
                                                echo "-----------------------------------------------------------------------"
                                                echo ""
                                                echo ""
                                                echo "--------------------------------------------------------------------------------------------------------------------------------------------"
                                                echo "| `tput setaf 2`Old user = $user , Old user_id = $user_id, Area = OAM has been modified successfully.`tput sgr0`"
                                                echo "| `tput setaf 2`New user details:`tput sgr0`"
                                                echo "| `tput setaf 2`user = $newuser , user_id = $newuser_id, Area = OAM`tput sgr0`"
                                                echo "| `tput setaf 2`A new directory has been created for the new user (If it didnt existed before). New directory = /$newuser/`tput sgr0`"
                                                echo "|`tput setaf 2` Please provide username and password `tput setaf 5`changeme`tput setaf 2` to Mr(s) $wholename He will have to change it at first login`tput sgr0`"
                                                echo "|                                                                                                   "
                                                echo "| `tput setaf 2`@@@ Note that you will be able to monitor WHEN and WHAT actions this new user will do on the node @@@ `tput sgr0` "
                                                echo "|                                                                                                   "
                                                echo "| `tput setaf 2`All $wholename 's actions and date and time will be stored in $user/.bash_history`tput sgr0`"
                                                echo "| `tput setaf 2`Run these commands as root to see all actions together with their date and time`tput sgr0`"
                                                echo "|                                                                                                   "
                                                echo "| `tput setaf 2`su - $newuser `tput sgr0`"
                                                echo "| `tput setaf 2`history `tput sgr0`"
                                                echo "--------------------------------------------------------------------------------------------------------------------------------------------"
                                                echo "Bye"
                                        else
                                                echo ""
                                                echo "----------------------------"
                                                echo "| `tput setaf 1`User was not modified    `tput sgr0`|"
                                                echo "| `tput setaf 1`You did not enter Y      `tput sgr0`|"
                                                echo "----------------------------"
                                                echo "Bye"
                                        fi
                                else
                                        echo "--------------------------------------------------------------------"
                                        echo "|`tput setaf 1` $user username is too long or too short !!!    `tput sgr0`                  "
                                        echo "|`tput setaf 1` Username must have more than 5 and less than 15 characters `tput sgr0`       |"
                                        echo "|`tput setaf 1` Please start again                                             `tput sgr0`  |"
                                        echo "--------------------------------------------------------------------"
                                        echo " Bye "
                                fi
                        fi
                fi

        elif  [ "$area" == "2" ]; then
                echo ""
                echo "-------------------------------------------------------------------------------------------------------------"
                echo "|                                                  Group PROVIDER                                           |"
                echo "|                                                    User Modify                                            |"
                echo "-------------------------------------------------------------------------------------------------------------"
                echo "| `tput setaf 3`Current Users:`tput sgr0`                                                                                            |"
                cat /etc/passwd | grep "PROVIDER" | egrep "home" | egrep -v "xymon" | egrep -v kibana |  egrep -v "elasticsearch" | awk 'BEGIN{FS=":"}{print "| - " $1}'
                echo "-------------------------------------------------------------------------------------------------------------"
                echo ""
                echo -n " Enter current username (The username you want to modify) > "
                read username
                user=$(cat /etc/passwd | grep "PROVIDER" | grep -v ":30" | grep -v "bin:" | grep -v "daemon" | grep -v "sys" | grep -v "adm" | grep -v "lp" | grep -v "uucp" | grep -v "smmsp" | grep -v "listen" | grep -v "gdm" | grep -v "webservd" | grep -v "postgres" | grep -v "svctag" | grep -v "unknown" | grep -v "nobody" | grep -v "noaccess" | grep -v "tango" | grep -v "ftp" | grep -v "mysql" | grep "$username" | awk 'BEGIN{FS=":"}{print $1}')
                if [ -z "$user" -o "$user" != "$username" ]; then
                        echo "----------------------------------------------------------"
                        echo "| `tput setaf 1` User doesn't belong to PROVIDER Group `tput sgr0`                 |"
                        echo "----------------------------------------------------------"
                        echo "Bye"
                else
                        echo ""
                        echo "--------------------------------------------"
                        echo "| Type of change:                          |"
                        echo "| 1. Change Password                       |"
                        echo "| 2. Change User                           |"
                        echo "--------------------------------------------"
                        echo ""
                        echo -n " Enter option (Enter only number 1 or 2) > "
                        read changetype
                        if [ "$changetype" != "2" -a "$changetype" != "1" ]; then
                                echo "-------------------------------------------------------------------------"
                                echo "|`tput setaf 1` You enter a wrong option, enter only number 1 or 2. Please try again. `tput sgr0`|"
                                echo "-------------------------------------------------------------------------"
                        elif [ "$changetype" == "1" ];then
                                echo ""
                                echo "-----------------------------------------------------------------------------------------------------"
                                echo "| The first 8 characters of the password must contain at least 1 numeric or special character(s).   |"
                                echo "| The password must have at least 8 characters                                                      |"
                                echo "| Password will be required to be changed every 90 days                                             |"
                                echo "-----------------------------------------------------------------------------------------------------"
                                echo ""
                                echo -n " Are you sure you want to modify $user password? (Enter Y or N) > "
                                read confirmChangePW
                                read confirmChangePWlowercase <<<$(echo $confirmChangePW | tr '[:upper:]' '[:lower:]')
                                if [ "$confirmChangePWlowercase" == "y" ]; then
                                        echo "changeme" | /usr/bin/passwd --stdin "$username"
                                        /usr/bin/passwd -e $username >/dev/null 2>&1
                                        echo "-----------------------------------------------------------------------"
                                        echo "| User Password was modified successfully.                            |"
                                        echo "-----------------------------------------------------------------------"
                                        echo ""
                                        echo ""
                                        echo "--------------------------------------------------------------------------------------------------------------"
                                        echo "|`tput setaf 2` User                = $user`tput sgr0`"
                                        echo "|`tput setaf 2` User_id             = $user_id`tput sgr0`"
                                        echo "|`tput setaf 2` User home directory = /home/$user/`tput sgr0`"
                                        echo "|`tput setaf 2` Group               = PROVIDER`tput sgr0`"
                                        echo "|`tput setaf 2` Temporal Password   = `tput setaf 5`changeme`tput sgr0`"
                                        echo "|`tput setaf 2` Please provide username and password `tput setaf 5`changeme`tput setaf 2` to Mr(s) $wholename He will have to change it at first login`tput sgr0`"
                                        echo "|                                                                                                   "
                                        echo "|`tput setaf 2` @@@ Note that you will be able to monitor WHEN and WHAT actions this new user will do on the node @@@`tput sgr0`  "
                                        echo "|                                                                                                   "
                                        echo "|`tput setaf 2` All $wholename 's actions and date and time will be stored in /home/$user/.bash_history`tput sgr0`"
                                        echo "|`tput setaf 2` Run these commands as root to see all actions together with their date and time`tput sgr0`"
                                        echo "|                                                                                                   "
                                        echo "|`tput setaf 2` su - $user `tput sgr0`"
                                        echo "|`tput setaf 2` history `tput sgr0`"
                                        echo "--------------------------------------------------------------------------------------------------------------"
                                        echo "Bye"
                                else
                                        echo ""
                                        echo "--------------------------------"
                                        echo "| `tput setaf 1`Password was not modified    `tput sgr0`|"
                                        echo "| `tput setaf 1`You did not enter Y          `tput sgr0`|"
                                        echo "--------------------------------"
                                        echo "Bye"
                                fi
                        elif [ "$changetype" == "2" ];then
                                echo -n " Enter new username > "
                                read newuser
                                usernamelength=$(echo $newuser | wc -c | tr -s " ")
                                echo "$usernamelength"
                                if  [ "$usernamelength" -lt "15" ] && [ "$usernamelength" -gt "6" ]; then
                                        passwd="/etc/passwd"
                                        last_user_id=$(grep ":15" /etc/passwd | egrep -v ":30" | /bin/tail -1  | cut -d: -f3)
                                        suggest_user_id=$((last_user_id+1))
                                        alreadyexit=$(/bin/cat $passwd | /bin/grep $suggest_user_id)
                                        if [ -z "$alreadyexit" ]; then
                                                echo ""
                                                echo "----------------------------------------------------------------------"
                                                echo "|  `tput setaf 3`User ID `tput sgr0`$suggest_user_id `tput setaf 3`doesnt exist.                                       `tput sgr0`  |"
                                                echo "|  `tput setaf 3`I suggest you to Enter `tput sgr0`$suggest_user_id `tput setaf 3`as User ID to the new user $user    `tput sgr0` "
                                                echo "----------------------------------------------------------------------"
                                        else
                                                echo "----------------------------------------------------------------------"
                                                echo "| `tput setaf 3` !!!Important $suggest_user_id Already exists, DO NOT USE IT. Check /etc/passwd           `tput sgr0`  |"
                                                echo "----------------------------------------------------------------------"
                                        fi
                                        echo -n " Enter new User ID [Default = $suggest_user_id] > "
                                        read newuser_id
                                        if [ -z "$newuser_id" ];then
                                                newuser_id="$suggest_user_id"
                                        fi
                                        if ! [[ "$newuser_id" =~ ^[0-9]+$ ]];then
                                                echo ""
                                                echo "------------------------------------------------------------------------------------------"
                                                echo "|  `tput setaf 1`User ID is not an integer.                                                          `tput sgr0`  |"
                                                echo "|  `tput setaf 1`I suggest you to Enter `tput sgr0`$suggest_user_id `tput setaf 1`as User ID to the new user $newuser, Please try again.    `tput sgr0` "
                                                echo "------------------------------------------------------------------------------------------"
                                                echo "Bye"
                                                exit
                                        fi
                                        echo -n " Enter new user Full Name (Example: ERIC COLON) > "
                                        read newwholename
                                        if [ -z "$newwholename" ];then
                                                echo ""
                                                echo "---------------------------------------------------------------------------------"
                                                echo "| `tput setaf 1`Sorry, Full Name can not be empty. Try Again.`tput sgr0`                      |"
                                                echo "---------------------------------------------------------------------------------"
                                                read newwholename
                                                if [ -z "$newwholename" ];then
                                                        echo ""
                                                        echo "---------------------------------------------------------------------------------"
                                                        echo "| `tput setaf 1`Sorry, Full Name can not be empty. Bye`tput sgr0`                             |"
                                                        echo "---------------------------------------------------------------------------------"
                                                        exit
                                                fi
                                        fi
                                        echo ""
                                        echo "-----------------------------------------------------------------------"
                                        echo "| Enter which permissions $newuser $newwholename will have                   "
                                        echo "| 1. Read Only                                                        |"
                                        echo "| 2. Sudoer                                                           |"
                                        echo "| 3. FTP or SFTP                                                      |"
                                        echo "-----------------------------------------------------------------------"
                                        echo ""
                                        echo -n " Enter option (Enter only number 1 or 2) > "
                                        read permissions
                                        if [ "$permissions" == "2" ];then
                                                permissionsStr="Sudoer"
                                        elif [ "$permissions" == "3" ];then
                                                permissionsStr="FTP or SFTP"
                                                cdalias="alias cd='denied'"
                                        else
                                                permissionsStr="Read Only"
                                        fi
                                        user_id=$(grep $username /etc/passwd |egrep -v tango | egrep -v ":30" | awk 'BEGIN{FS=":"}{print $3}')
                                        user_group=$(grep $username /etc/passwd |egrep -v tango | egrep -v ":30" | awk 'BEGIN{FS=":"}{print $5}' | awk '{print $1}')
                                        wholename=$(cat /etc/passwd | grep $username | awk 'BEGIN{FS=":"}{print $5}')
                                        userdir=/home/$username/
                                        echo ""
                                        echo "-------------------------------------------------------------------------------"
                                        echo "| Make sure it is the user your want to modify!!!!!  If not, please Enter N   |"
                                        echo "-------------------------------------------------------------------------------"
                                        echo ""
                                        echo "-------------------------------------------------------------------------------"
                                        echo "| Old User       = $user"
                                        echo "| Old user_id    = $user_id"
                                        echo "| Old User Name  = $wholename"
                                        echo "| Old User Group = $user_group"
                                        echo "-------------------------------------------------------------------------------"
                                        echo ""
                                        echo "-----------------------------------------------------------------------"
                                        echo "| `tput setaf 3`New user      = `tput sgr0`$newuser"
                                        echo "| `tput setaf 3`New user_id   = `tput sgr0`$newuser_id"
                                        echo "| `tput setaf 3`New User Name = `tput sgr0`$newwholename"
                                        echo "| `tput setaf 3`Group         = `tput sgr0`PROVIDER"
                                        echo "| `tput setaf 3`Permissions   = `tput sgr0`$permissionsStr"
                                        echo "-----------------------------------------------------------------------"
                                        echo -n "Are you sure you want to modify $user? Enter Y/N > "
                                        read confirm3
                                        read confirm3lowercase <<<$(echo $confirm3 | tr '[:upper:]' '[:lower:]')
                                        if [ "$confirm3lowercase" == "y" ]; then
                                                echo ""
                                                if [ ! -f /tango/logs/COSTAFF/files_backups/ ];then
                                                                                mkdir -p /tango/logs/COSTAFF/files_backups/
                                                fi
                                                /bin/cp -rfp /etc/passwd /tango/logs/COSTAFF/files_backups/passwd.back_$time
                                                /bin/cp -rfp /etc/group /tango/logs/COSTAFF/files_backups/group.back_$time
                                                /bin/mv /home/$username /tango/logs/COSTAFF/files_backups/
                                                mv /var/spool/mail/$user /tango/logs/COSTAFF/files_backups/$user_var_sopp_mail_file
                                                echo ""
                                                echo "-----------------------------------------------------------------------------------------------------"
                                                echo "| Old $username user backups are created in /tango/logs/COSTAFF/files_backups/                      |"
                                                echo "-----------------------------------------------------------------------------------------------------"
                                                echo ""
                                                userdel $username
                                                if [ "$permissions" == "2" ];then
                                                        /usr/sbin/useradd -c "PROVIDER $newwholename SUDOER" -d /home/$newuser -g wheel -G operator,readonly  -s /bin/bash -u $newuser_id $newuser
                                                        /usr/sbin/usermod -aG wheel $newuser
                                                        if [ ! -d /home/$user ];then
                                                                                        /bin/mkdir /home/$newuser
                                                        fi
                                                        /bin/chown root:wheel /home/$newuser
                                                        /bin/chmod 770 /home/$newuser
                                                else
                                                        /usr/sbin/useradd -c "PROVIDER $newwholename" -d /home/$newuser -g tango -G operator,readonly  -s /bin/bash -u $newuser_id $newuser
                                                        if [ ! -d /home/$user ];then
                                                                                        /bin/mkdir /home/$newuser
                                                        fi
                                                        /bin/chown root:tango /home/$newuser
                                                        /bin/chmod 770 /home/$newuser
                                                fi
                                                echo ""
                                                echo "-----------------------------------------------------------------------------------------------------"
                                                echo "| The first 8 characters of the password must contain at least 1 numeric or special character(s).   |"
                                                echo "| The password must have at least 8 characters                                                      |"
                                                echo "| Password will be required to be changed every 90 days                                             |"
                                                echo "-----------------------------------------------------------------------------------------------------"
                                                echo ""
                                                echo "changeme" | /usr/bin/passwd --stdin "$newuser"
                                                /usr/bin/passwd -e $newuser >/dev/null 2>&1
                                                echo ""
                                                echo "Creating /$newuser/.bashrc /$newuser/.bash_profile    ......."
                                                /bin/cp $scriptDir/.bashrc /$newuser/.bashrc
                                                /bin/cp $scriptDir/.bash_profile /$newuser/.bash_profile
                                                /bin/chmod 750 /$newuser/.bashrc /$newuser/.bash_profile
                                                /bin/chown root:tango /$newuser/.bashrc /$newuser/.bash_profile
                                                source /$newuser/.bashrc
                                                echo ""
                                                echo "-----------------------------------------------------------------------"
                                                echo "| `tput setaf 2`User was modified successfully.                                     |"
                                                echo "-----------------------------------------------------------------------"
                                                echo ""
                                                echo ""
                                                echo "--------------------------------------------------------------------------------------------------------------------------------------------"
                                                echo "| `tput setaf 2`Old user = $user , Old user_id = $user_id, Area = Provider has been modified successfully."
                                                echo "| `tput setaf 2`New user details:"
                                                echo "| `tput setaf 2`user = $newuser , user_id = $newuser_id, Area = Provider "
                                                echo "| `tput setaf 2`A new directory has been created for the new user (If it didnt existed before). New directory = /$newuser/"
                                                echo "|`tput setaf 2` Please provide username and password `tput setaf 5`changeme`tput setaf 2` to Mr(s) $newwholename He will have to change it at first login`tput sgr0`"
                                                echo "|                                                                                                   "
                                                echo "| `tput setaf 2`@@@ Note that you will be able to monitor WHEN and WHAT actions this new user will do on the node @@@  "
                                                echo "|                                                                                                   "
                                                echo "| `tput setaf 2`All $wholename 's actions and date and time will be stored in $user/.bash_history"
                                                echo "| `tput setaf 2`Run these commands as root to see all actions together with their date and time"
                                                echo "|                                                                                                   "
                                                echo "| `tput setaf 2`su - $user `tput sgr0`"
                                                echo "| `tput setaf 2`history `tput sgr0`"
                                                echo "--------------------------------------------------------------------------------------------------------------------------------------------"
                                                echo "Bye"
                                        else
                                                echo ""
                                                echo "----------------------------"
                                                echo "|`tput setaf 1` User was not modified  `tput sgr0`   |"
                                                echo "|`tput setaf 1` You did not enter Y     `tput sgr0`  |"
                                                echo "----------------------------"
                                                echo "Bye"
                                        fi
                                else
                                        echo "--------------------------------------------------------------------"
                                        echo "--------------------------------------------------------------------"
                                        echo "|`tput setaf 1` $newuser username is too long or too short !!!    `tput sgr0`                  "
                                        echo "|`tput setaf 1` Username must have more than 5 and less than 15 characters `tput sgr0`       |"
                                        echo "|`tput setaf 1` Please start again                                             `tput sgr0`  |"
                                        echo "--------------------------------------------------------------------"
                                        echo "--------------------------------------------------------------------"
                                        echo " Bye "
                                fi
                        fi
                fi
        fi







######################### Opt 4  ############################

elif [ "$mainopt" == "4" ]; then
        echo ""
        echo "-------------------------------------------------------------------------------------------------------------"
        echo "|                                              4. Deactivate an User                                        |"
        echo "|      This option is used to lock the password of specified account and it is available to root only.      |"
        echo "-------------------------------------------------------------------------------------------------------------"
        echo ""
        echo ""
        echo -n "Enter username > "
        read username
        user=$(cat /etc/passwd | grep ":15" | grep -v ":30" | grep -v "bin:" | grep -v "daemon" | grep -v "sys" | grep -v "adm" | grep -v "lp" | grep -v "uucp" | grep -v "smmsp" | grep -v "listen" | grep -v "gdm" | grep -v "webservd" | grep -v "postgres" | grep -v "svctag" | grep -v "unknown" | grep -v "nobody" | grep -v "noaccess" | grep -v "tango" | grep -v "ftp" | grep -v "mysql" | grep "$username" | awk 'BEGIN{FS=":"}{print $1}')
        if [ -z "$user" -o "$user" != "$username" ]; then
                echo "----------------------------------------------"
                echo "| User doesn't exist                         |"
                echo "----------------------------------------------"
                echo "Bye"
                else
                user_id=$(grep $username /etc/passwd | egrep ":15" | egrep -v ":30" | awk 'BEGIN{FS=":"}{print $3}')
                wholename=$(cat /etc/passwd | grep $username | awk 'BEGIN{FS=":"}{print $5}')
                userdir=/home/$username/
                echo ""
                echo "User      = $user"
                echo "user_id   = $user_id"
                echo "User Name = $wholename"
                echo ""
                echo "-------------------------------------------------------------------------------------------------"
                echo "| Make sure it is the user your want to deactivate!!!!!  If not, please Enter N                 |"
                echo "|                                                                                               |"
                echo "| If you Enter Y, it will only deactivate the password. The user will not be deleted            |"
                echo "|                                                                                               |"
                echo "| If you want to activate in future, go to Main Menu and select option 5. Activate an User      |"
                echo "-------------------------------------------------------------------------------------------------"
                echo ""
                echo -n "Are you sure you want to deactivate it? Enter Y/N > "
                read confirm4
                read confirm4lowercase <<<$(echo $confirm4 | tr '[:upper:]' '[:lower:]')
                if [ "$confirm4lowercase" == "y" ]; then
                        passwd -l $username
                        echo ""
                        echo "----------------------------------------------"
                        echo "| User has been deactivated successfully.    |"
                        echo "| This command was run:                      |"
                        echo "| passwd -l $username                         |"
                        echo "----------------------------------------------"
                        echo ""
                        echo "Bye"
                else
                        echo "--------------------------------"
                        echo "| User was not deactivated.    |"
                        echo "--------------------------------"
                        echo "Bye"
                fi
        fi





######################### Opt 5  ############################

elif [ "$mainopt" == "5" ]; then
        echo ""
        echo "-------------------------------------------------------------------------------------------------------------"
        echo "|                                              5. Activate an User                                          |"
        echo "-------------------------------------------------------------------------------------------------------------"
        echo ""
        echo ""
        echo -n "Enter username > "
        read username
        user=$(cat /etc/passwd | grep ":155555" | grep -v ":30" | grep -v "bin:" | grep -v "daemon" | grep -v "sys" | grep -v "adm" | grep -v "lp" | grep -v "uucp" | grep -v "smmsp" | grep -v "listen" | grep -v "gdm" | grep -v "webservd" | grep -v "postgres" | grep -v "svctag" | grep -v "unknown" | grep -v "nobody" | grep -v "noaccess" | grep -v "tango" | grep -v "ftp" | grep -v "mysql" | grep "$username" | awk 'BEGIN{FS=":"}{print $1}')
        if [ -z "$user" -o "$user" != "$username" ]; then
                echo "----------------------------------------------"
                echo "| User doesn't exist                          |"
                echo "----------------------------------------------"
                echo "Bye"
                else
                user_id=$(grep $username /etc/passwd | egrep ":15" | egrep -v ":30" | awk 'BEGIN{FS=":"}{print $3}')
                wholename=$(cat /etc/passwd | grep $username | awk 'BEGIN{FS=":"}{print $5}')
                userdir=/home/$username/
                echo ""
                echo "User      = $user"
                echo "user_id   = $user_id"
                echo "User Name = $wholename"
                echo ""
                echo "-------------------------------------------------------------------------------------------------"
                echo "| Make sure it is the user your want to activate!!!!!  If not, please Enter N                   |"
                echo "|                                                                                               |"
                echo "| If you Enter Y, it will only activate the password. User can then log in again                |"
                echo "-------------------------------------------------------------------------------------------------"
                echo ""
                echo -n "Are you sure you want to activate it? Enter Y/N > "
                read confirm5
                read confirm5lowercase <<<$(echo $confirm5 | tr '[:upper:]' '[:lower:]')
                if [ "$confirm5lowercase" == "y" ]; then
                        passwd -u $username
                        echo ""
                        echo "----------------------------------------------"
                        echo "| User has been activated successfully.      |"
                        echo "| This command was run:                      |"
                        echo "| passwd -u $username                         |"
                        echo "----------------------------------------------"
                        echo ""
                        echo "Bye"
                else
                        echo "------------------------------"
                        echo "| User was not activated.    |"
                        echo "------------------------------"
                        echo "Bye"
                fi
        fi


######################### Opt 6  ############################

elif [ "$mainopt" == "6" ]; then
        echo ""
        echo "-------------------------------------------------------------------------------------------------------------"
        echo "|                                              6. List All Users                                            |"
        echo "-------------------------------------------------------------------------------------------------------------"
        echo ""
        echo "-----------------------------------------------------------------------"
        echo "| 1. OAM                                                              |"
        echo "| 2. Provider                                                         |"
        echo "| 3. Sudoers                                                          |"
        echo "| 4. All                                                              |"
        echo "-----------------------------------------------------------------------"
        echo ""
        echo -n " Enter group (Enter only number 1 or 2) > "
        read ugroup
        if [ "$ugroup" == "1" ]; then
                        echo ""
                echo "---------------------------------------------"
                echo "|                 OAM Users                 |"
                echo "---------------------------------------------"
                user=$(cat /etc/passwd | grep "1500\|OAM" | egrep "home" | egrep -v "xymon" | egrep -v kibana |  egrep -v "elasticsearch")
                if [ ! -z "$user" ];then
                        cat /etc/passwd | grep "1500\|OAM" | egrep "home" | egrep -v "xymon" | egrep -v kibana |  egrep -v "elasticsearch" | while read passwdLine
                        do
                                getUserNamePasswd=$(echo "$passwdLine" | cut -d":" -f1)
                                passwdStatusLine=$(/bin/passwd -S "$getUserNamePasswd")
                                echo -e "\nUsername = $getUserNamePasswd"
                                echo -n -e "\nUser_Id = "
                                echo "$passwdLine" | cut -d":" -f3
                                echo -n -e "\nGroup_Id = "
                                echo "$passwdLine" | cut -d":" -f4
                                echo -n -e "\nFull Name = "
                                echo "$passwdLine" | cut -d":" -f5
                                getPasswdStatusDate=$(echo "$passwdStatusLine" | awk "{print \$3}")
                                passwdStatus=$(echo "$passwdStatusLine" | cut -d"(" -f2 | cut -d, -f1 | cut -d"." -f1)
                                echo -e "\nStatus = $passwdStatus on $getPasswdStatusDate"
                                echo -e "\n---------------------------------------------"
                        done
                else
                        echo -e "i`tput setaf 3`\nNone OAM Users have been created\n`tput sgr0`"
                fi

         elif [ "$ugroup" == "2" ]; then
                echo ""
                echo "---------------------------------------------"
                echo "|   Provider Users                           |"
                echo "---------------------------------------------"
                user=$(cat /etc/passwd | grep "PROVIDER" | egrep "home" | egrep -v "xymon" | egrep -v kibana | egrep -v "elasticsearch")
                if [ ! -z "$user" ];then
                        cat /etc/passwd | grep "PROVIDER" | egrep "home" | egrep -v "xymon" | egrep -v kibana | egrep -v "elasticsearch" | while read passwdLine
                        do
                                getUserNamePasswd=$(echo "$passwdLine" | cut -d":" -f1)
                                passwdStatusLine=$(/bin/passwd -S "$getUserNamePasswd")
                                echo -e "\nUsername = $getUserNamePasswd"
                                echo -n -e "\nUser_Id = "
                                echo "$passwdLine" | cut -d":" -f3
                                echo -n -e "\nGroup_Id = "
                                echo "$passwdLine" | cut -d":" -f4
                                echo -n -e "\nFull Name = "
                                echo "$passwdLine" | cut -d":" -f5
                                getPasswdStatusDate=$(echo "$passwdStatusLine" | awk "{print \$3}")
                                passwdStatus=$(echo "$passwdStatusLine" | cut -d"(" -f2 | cut -d, -f1 | cut -d"." -f1)
                                echo -e "\nStatus = $passwdStatus on $getPasswdStatusDate"
                                echo -e "\n---------------------------------------------"
                        done
                else
                        echo -e "`tput setaf 3`\nNone Provider Users have been created\n`tput sgr0`"
                fi
        elif [ "$ugroup" == "3" ]; then
                echo ""
                echo "---------------------------------------------"
                echo "|                 Sudoers                    |"
                echo "---------------------------------------------"
                user=$(cat /etc/passwd | grep "SUDOER" )
                if [ ! -z "$user" ];then
                        cat /etc/passwd | grep "SUDOER" | while read passwdLine
                        do
                                getUserNamePasswd=$(echo "$passwdLine" | cut -d":" -f1)
                                passwdStatusLine=$(/bin/passwd -S "$getUserNamePasswd")
                                echo -e "\nUsername = $getUserNamePasswd"
                                echo -n -e "\nUser_Id = "
                                echo "$passwdLine" | cut -d":" -f3
                                echo -n -e "\nGroup_Id = "
                                echo "$passwdLine" | cut -d":" -f4
                                echo -n -e "\nFull Name = "
                                echo "$passwdLine" | cut -d":" -f5
                                getPasswdStatusDate=$(echo "$passwdStatusLine" | awk "{print \$3}")
                                passwdStatus=$(echo "$passwdStatusLine" | cut -d"(" -f2 | cut -d, -f1 | cut -d"." -f1)
                                echo -e "\nStatus = $passwdStatus on $getPasswdStatusDate"
                                echo -e "\n---------------------------------------------"

                        done
                else
                        echo -e "`tput setaf 3`\nNone Sudoer Users have been created\n`tput sgr0`"
                fi
        else
                echo ""
                echo "---------------------------------------------"
                echo "|                All Users                  |"
                echo "---------------------------------------------"
                cat /etc/passwd | grep "home" | egrep -v "xymon" | egrep -v kibana | egrep -v "elasticsearch" | while read passwdLine
                do
                        getUserNamePasswd=$(echo "$passwdLine" | cut -d":" -f1)
                        passwdStatusLine=$(/bin/passwd -S "$getUserNamePasswd")
                        echo -e "\nUsername = $getUserNamePasswd"
                        echo -n -e "\nUser_Id = "
                        echo "$passwdLine" | cut -d":" -f3
                        echo -n -e "\nGroup_Id = "
                        echo "$passwdLine" | cut -d":" -f4
                        echo -n -e "\nFull Name = "
                        echo "$passwdLine" | cut -d":" -f5
                        getPasswdStatusDate=$(echo "$passwdStatusLine" | awk "{print \$3}")
                        passwdStatus=$(echo "$passwdStatusLine" | cut -d"(" -f2 | cut -d, -f1 | cut -d"." -f1)
                        echo -e "\nStatus = $passwdStatus on $getPasswdStatusDate"
                        echo -e "\n---------------------------------------------"
                done
        fi




######################### Opt 7  ############################

elif [ "$mainopt" == "7" ]; then
        echo ""
        echo "-----------------"
        echo "| Closing ..... |"
        echo "-----------------"
        echo "Bye"



######################### Wrong Opt  ############################

else
        echo "------------------------------------------------------------------------------------"
        echo "| `tput setaf 1` You enter a wrong option, enter only number 1,2,3,4,5,6 or 7. Please try again. `tput sgr0`|"
        echo "------------------------------------------------------------------------------------"
        echo "Bye"
fi