#!/bin/bash
databaseServer=localhost
if [ -z "$1" ];then
        echo "`tput setaf 3`ssh $databaseServer \"mysql -u root -e 'select * from activity_meter.activity order by id desc limit 10;'`tput sgr0`\""
        ssh $databaseServer "mysql -u root -e 'select * from activity_meter.activity order by id desc limit 10;'"
else
        echo "`tput setaf 3`ssh $databaseServer \"mysql -u root -e 'select * from activity_meter.activity where msisdn = \\\"$1\\\";'`tput sgr0`\""
        ssh $databaseServer "mysql -u root -e 'select * from activity_meter.activity where msisdn = \"$1\";'"
fi