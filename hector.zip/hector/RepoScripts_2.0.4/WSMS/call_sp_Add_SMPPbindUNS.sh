#!/bin/bash

#---------------------------------------------------------------
# Configurations
#---------------------------------------------------------------
mysqlmasterhost="IPXMIATCDB1"
mysqluser="root"

#---------------------------------------------------------------
# Set Initial variables
#---------------------------------------------------------------
whichmysql=$(ssh $mysqlmasterhost 'which mysql')
DIR=$(echo "`dirname $0`")

#---------------------------------------------------------------
# Flags
#---------------------------------------------------------------

#---------------------------------------------------------------
# Subroutines
#---------------------------------------------------------------
help()
{
echo -e "
Usage: call_sp_Add_SMPPbindUNS.sh

This sh is to add or delete UNS SMPP bind accounts on MySQL smpp database. You could do it manually by using insert sql queries directly on MySQL. However, the inserts need to be prepared and calculated carfully especially if using MySQL Percona with multiple multimasters. Well, this script will do it quickly and more important safely

        Copyright (c) Tango Telecom 2020

                Options:

                -n      <SMSC name> Mandatory
                                - For WSMS, this must match with /tango/config/uns_wsms/uns-rest-ws.properties parameter \"uns.smsc.tenants.<tenant>\" which should have the following format: <SMSC name>_<systemId>

                -i      <SMSC IP> Mandatory

                -b      <SMSC Port> Mandatory

                -s      <SystemID> Mandatory

                -p      <Password> Mandatory

                -e      <Encoding Text> Optional
                                Options (No case sensitive):
                                - SMSC
                                - UCS2
                                - If not present, existing settings in uns-rest-ws.properties will provide the default (uns.smpp.message.text.encoding).

                -m      <Message Segmentation> Optional
                                Options (No case sensitive):
                                - PAYLOAD
                                - UDH   (It also sets value esm_class to 64 as required by jira UNS-94)
                                - SAR
                                - If not present, existing settings in uns-rest-ws.properties will provide the default
                                  PAYLOAD corresponds to uns.smpp.message.payload.enabled=true
                                  UDH corresponds to uns.udh.enabled=true
                                  SAR corresponds to the default approach used when the two properties are false

                -t      <TON Destination Address> Optional
                                - If not present, existing settings in uns-rest-ws.properties will provide the default (uns.destination.address.ton)

                -d      <NPI Destination Address> Optional
                                - If not present, existing settings in uns-rest-ws.properties will provide the default (uns.destination.address.npi)

                -x      <TON Source Address> Optional
                                - If not present, existing settings in uns-rest-ws.properties will provide the default (uns.source.address.ton)

                -y      <NPI Source Address> Optional
                                - If not present, existing settings in uns-rest-ws.properties will provide the default (uns.source.address.npi)

                -z      <System Type> Optional
                                - TCP (Default)
                                - SMPP
                                - Any other sring

                -o      <Operation> Mandatory
                                Options (No case sensitive):
                                - add    => To Add a new SMPP link
                                - delete => To Delete an existing SMPP link
                                - find   => To display a SMPP links details as per -n flag.
                                            If flag -n is not present, it will desplay ALL SMPP links
                                - list   => To list all existing SMPP links
                                - check  => To check status of an existing SMPP Link


                -h      <help>


Example 1: call_sp_Add_SMPPbindUNS -o add -n SMSCUruguay_wsms20 -i 192.168.20.191 -b 5563 -s wsms20 -p roaming -m UDH
It will insert a new record in smpp.smsc and smpp.smpp_link as follows:
Notes:
- Flags -e, -t, -d, -x and -y are not present. Hence all values will be set to NULL. However, text Encoding is SMSC, dest and source NPI is 1, dest and source TON is 1 since they are set in uns-rest-ws.properties.
- Flag -z is also not present, hence it sets default value to TCP
- Flag -x is UDH, hence both segmentation and esm_class values are set to UDH and 64 respectively"
}


checkIfThereIsTraffic()
{
getTenant=$(cat /tango/config/uns_wsms/uns-rest-ws.properties | cut -d"#" -f1 | grep "SMSCUruguay_wsms23" | cut -d"." -f4 | cut -d"=" -f1)
getACDR=$(grep "91,1,$getTenant" /tango/data/cdr/active_UNS_WSMS.cdr | grep ",2,0,0" | head -1 | cut -d, -f17,18,19)
if [ "$getACDR" == "2,0,0" ];then
        echo -e "\n[`tput setaf 2`OK`tput sgr0`] `tput setaf 2`SMPP Bind `tput setaf 3`$SMSCname `tput setaf 2`exists AND it seems to have a bind established and carrying traffic successfully on this machine. It seems another bind connection is trying to connect. `tput setaf 5`NOTE: smpp.smpp_link.bind_time=$checkSMSCBind\n`tput sgr0`"
else
        echo -e "\n[`tput setaf 1`NO ESTABLISHED`tput sgr0`] `tput setaf 1`SMPP Bind `tput setaf 3`$SMSCname`tput setaf 1` exists.However, at least one bind connection is not establiashed yet. `tput setaf 3`smpp.smpp_link.bind_time=$checkSMSCBind`tput setaf 1`\nRun call_sp_Add_SMPPbindUNS -h for help or check configuration in smpp.smsc and smpp.smpp_link MySQL tables.\n`tput sgr0`"
fi
}


while getopts  n:i:b:s:p:o:e:t:d:m:x:y:z:h option;
do
        case $option in
                n) SMSCname=$OPTARG;;
                i) smscHost=$OPTARG;;
                b) port=$OPTARG;;
                s) systemId=$OPTARG;;
                p) password=$OPTARG;;
                e) encodingp=$OPTARG;;
                t) dest_ton=$OPTARG;;
                d) dest_npi=$OPTARG;;
                m) msgsegmentationp=$OPTARG;;
                x) source_ton=$OPTARG;;
                y) source_npi=$OPTARG;;
                z) systemType=$OPTARG;;
                o) operation=$OPTARG;;
                h) help="true";;
        esac
done

if [ "$help" == "true" ];then
        help
        echo ""
else
        operationLowercase=$(echo "$operation" | tr '[:upper:]' '[:lower:]')
        encoding=$(echo "$encodingp" | tr '[:lower:]' '[:upper:]')
        msgsegmentation=$(echo "$msgsegmentationp" | tr '[:lower:]' '[:upper:]')

        if [ "$show" != "true" ] && [ "$operationLowercase" == "add" ];then
                if [ -z "$SMSCname" ] || [ -z "$smscHost" ] || [ -z "$port" ] || [ -z "$systemId" ] || [ -z "$password" ] || [ -z "$operation" ];then
                        help
                        echo -e "\n\n`tput setaf 1`There is a flag missing, please check (above) the help, bye`tput sgr0`\n"
                        echo ""
                        exit
                fi
                if [ -z "$encoding" ];then
                        encoding="NULL"
                fi
                if [ -z "$msgsegmentation" ];then
                        msgsegmentation="NULL"
                fi
                if [ -z "$systemType" ];then
                        systemType="TCP"
                fi
                if [ "$msgsegmentation" == "UDH" ];then
                        esmClass=64
                else
                        esmClass=0
                fi
                if [ -z "$dest_ton" ];then
                        dest_ton="NULL"
                        checkDestTon="NULL"
                else
                        checkDestTon=$(echo "$dest_ton" | grep -E ^\-?[0-9]+$)
                fi
                if [ -z "$dest_npi" ];then
                        dest_npi="NULL"
                        checkDestNpi="NULL"
                else
                        checkDestNpi=$(echo "$dest_npi" | grep -E ^\-?[0-9]+$)
                fi
                if [ -z "$source_ton" ];then
                        source_ton="NULL"
                        checkSourceTon="NULL"
                else
                        checkSourceTon=$(echo "$source_ton" | grep -E ^\-?[0-9]+$)
                fi
                if [ -z "$source_npi" ];then
                        source_npi="NULL"
                        checkSourceNpi="NULL"
                else
                        checkSourceNpi=$(echo "$source_npi" | grep -E ^\-?[0-9]+$)
                fi
                if [ -z "$checkDestTon" ]; then
                        echo -e "\n[`tput setaf 1`Failed`tput sgr0`] `tput setaf 1`Destination Ton must be integer. Run call_sp_Add_SMPPbindUNS -h for help`tput sgr0`"
                        echo ""
                        exit
                fi
                if [ -z "$checkDestNpi" ]; then
                        echo -e "\n[`tput setaf 1`Failed`tput sgr0`] `tput setaf 1`Destination Npi must be integer. Run call_sp_Add_SMPPbindUNS -h for help`tput sgr0`"
                        echo ""
                        exit
                fi
                if [ -z "$checkSourceTon" ]; then
                        echo -e "\n[`tput setaf 1`Failed`tput sgr0`] `tput setaf 1`Source Ton must be integer. Run call_sp_Add_SMPPbindUNS -h for help`tput sgr0`"
                        echo ""
                        exit
                fi
                if [ -z "$checkSourceNpi" ]; then
                        echo -e "\n[`tput setaf 1`Failed`tput sgr0`] `tput setaf 1`Source Npi must be integer. Run call_sp_Add_SMPPbindUNS -h for help`tput sgr0`"
                        echo ""
                        exit
                fi
                checkAddSMSC=$(ssh $mysqlmasterhost "echo 'select * from smsc where name =\"$SMSCname\"\G;' | $whichmysql -u $mysqluser smpp")
                getSmsc_oid=$(ssh $mysqlmasterhost "echo 'select id from smsc where name =\"$SMSCname\"\G;' | $whichmysql -u $mysqluser smpp" | egrep -v row | cut -d":" -f2 | tr -d ' ')
                checkAddSMPPLink=$(ssh $mysqlmasterhost "echo 'select * from smpp_link where smsc_oid =\"$getSmsc_oid\"\G;' | $whichmysql -u $mysqluser smpp")
                if [ ! -z "$checkAddSMSC" ] && [ ! -z "$checkAddSMPPLink" ];then
                        echo -e "\n[`tput setaf 1`Failed`tput sgr0`] SMPP Bind `tput setaf 1`$SMSCname`tput sgr0` already exists. Update is not available in this version yet. If you need to update any settings, first delete SMPP bind and add it again from scratch. Run call_sp_Add_SMPPbindUNS -h for help"
                        echo ""
                        exit
                fi
                ssh $mysqlmasterhost "echo 'call sp_Add_SMPPbindUNS(\"$SMSCname\",\"$smscHost\",\"$password\",\"$port\",\"$systemId\",$dest_ton,$dest_npi,\"$encoding\",$source_ton,$source_npi,\"$msgsegmentation\",$esmClass,\"$systemType\");' | $whichmysql -u $mysqluser smpp"
                checkAddSMSC=$(ssh $mysqlmasterhost "echo 'select * from smsc where name =\"$SMSCname\"\G;' | $whichmysql -u $mysqluser smpp")
                getSmsc_oid=$(ssh $mysqlmasterhost "echo 'select id from smsc where name =\"$SMSCname\"\G;' | $whichmysql -u $mysqluser smpp" | egrep -v row | cut -d":" -f2 | tr -d ' ')
                checkAddSMPPLink=$(ssh $mysqlmasterhost "echo 'select * from smpp_link where smsc_oid =\"$getSmsc_oid\"\G;' | $whichmysql -u $mysqluser smpp")
                if [ ! -z "$checkAddSMSC" ] && [ ! -z "$checkAddSMPPLink" ];then
                        echo "$checkAddSMSC"
                        echo "$checkAddSMPPLink"
                        echo -e "\n[`tput setaf 2`OK`tput sgr0`] `tput setaf 2`SMPP Bind `tput setaf 3`$SMSCname`tput setaf 2` has been added successfully. Don't forget UNS needs to be restarted to pickup new values, bye.`tput sgr0`\n"
                else
                        echo -e "\n[`tput setaf 1`Failed`tput sgr0`] SMPP Bind `tput setaf 1`$SMSCname`tput sgr0` was not added. Run call_sp_Add_SMPPbindUNS -h for help"
                        echo ""
                        exit
                fi
        elif [ "$show" != "true" ] && [ "$operationLowercase" == "delete" ];then
                if [ -z "$SMSCname" ];then
                        help
                        echo -e "\n\n`tput setaf 1`Flag -n is missing, please check (above) the help, bye`tput sgr0`\n"
                        echo ""
                        exit
                fi
                ssh $mysqlmasterhost "echo 'DELETE FROM smsc WHERE name = \"$SMSCname\";' | $whichmysql -u $mysqluser smpp"
                checkDelete=$(ssh $mysqlmasterhost "echo 'select * from smsc where name =\"$SMSCname\";' | $whichmysql -u $mysqluser smpp")
                if [ -z $checkDelete ];then
                        echo -e "\n[`tput setaf 2`OK`tput sgr0`] SMPP Bind `tput setaf 3`$SMSCname`tput sgr0` has been removed successfully, bye\n"
                else
                        echo -e "\n[`tput setaf 1`Failed`tput sgr0`] SMPP Bind `tput setaf 1`$SMSCname`tput sgr0` was not removed. Run call_sp_Add_SMPPbindUNS -h for help"
                        echo ""
                        exit
                fi
        elif [ "$show" != "true" ] && [ "$operationLowercase" == "find" ];then
                if [ -z "$SMSCname" ];then
                        getSMSCname=$(ssh $mysqlmasterhost "echo 'select name from smsc' | $whichmysql -u $mysqluser smpp" | egrep -v name)
                        while read SMSCname
                        do
                                echo -e "\n\033[1m=================================== [`tput setaf 6`\033[1m$SMSCname`tput sgr0`\033[1m] ===================================\n`tput sgr0`"
                                checkFindSMSC=$(ssh -n $mysqlmasterhost "echo 'select * from smsc where name =\"$SMSCname\"\G;' | $whichmysql -u $mysqluser smpp")
                                getSmsc_oid=$(ssh -n $mysqlmasterhost "echo 'select id from smsc where name =\"$SMSCname\"\G;' | $whichmysql -u $mysqluser smpp" | egrep -v row | cut -d":" -f2 | tr -d ' ')
                                checkSMSCBind=$(ssh -n $mysqlmasterhost "echo 'select bind_time from smpp_link where smsc_oid =\"$getSmsc_oid\";' | $whichmysql -u $mysqluser smpp" | grep -v bind_time)
                                IsCheckSMSCBindNull=$(echo "$checkSMSCBind" | grep NULL | wc -l)
                                checkFindSMPPLink=$(ssh -n $mysqlmasterhost "echo 'select * from smpp_link where smsc_oid =\"$getSmsc_oid\"\G;' | $whichmysql -u $mysqluser smpp")
                                if [ ! -z "$checkFindSMSC" ] && [ ! -z "$checkFindSMPPLink" ];then
                                        echo "$checkFindSMSC"
                                        echo "$checkFindSMPPLink"
                                        if [ "$IsCheckSMSCBindNull" != "0" ];then
                                                checkIfThereIsTraffic "$SMSCname" "$checkSMSCBind"
                                        else
                                                checkSMSCBind=$(echo "$checkSMSCBind" | tail -1)
                                                echo -e "\n[`tput setaf 2`OK`tput sgr0`] `tput setaf 2`SMPP Bind `tput setaf 3`$SMSCname `tput setaf 2`exists and bind has been established successfully since `tput setaf 3`$checkSMSCBind`tput sgr0`.`tput sgr0`\n"
                                        fi
                                else
                                        echo -e "\n[`tput setaf 5`NO EXISTS`tput sgr0`] SMPP Bind `tput setaf 5`$SMSCname`tput sgr0` does not exist. Run call_sp_Add_SMPPbindUNS -h for help"
                                        echo ""
                                fi
                        done <<<"$getSMSCname"
                else
                        checkFindSMSC=$(ssh $mysqlmasterhost "echo 'select * from smsc where name =\"$SMSCname\"\G;' | $whichmysql -u $mysqluser smpp")
                        getSmsc_oid=$(ssh $mysqlmasterhost "echo 'select id from smsc where name =\"$SMSCname\"\G;' | $whichmysql -u $mysqluser smpp" | egrep -v row | cut -d":" -f2 | tr -d ' ')
                        checkSMSCBind=$(ssh $mysqlmasterhost "echo 'select bind_time from smpp_link where smsc_oid =\"$getSmsc_oid\";' | $whichmysql -u $mysqluser smpp" | grep -v bind_time)
                        IsCheckSMSCBindNull=$(echo "$checkSMSCBind" | grep NULL | wc -l)
                        checkFindSMPPLink=$(ssh $mysqlmasterhost "echo 'select * from smpp_link where smsc_oid =\"$getSmsc_oid\"\G;' | $whichmysql -u $mysqluser smpp")
                        if [ ! -z "$checkFindSMSC" ] && [ ! -z "$checkFindSMPPLink" ];then
                                echo "$checkFindSMSC"
                                echo "$checkFindSMPPLink"
                                if [ "$IsCheckSMSCBindNull" != "0" ];then
                                        checkIfThereIsTraffic "$SMSCname" "$checkSMSCBind"
                                else
                                        checkSMSCBind=$(echo "$checkSMSCBind" | tail -1)
                                        echo -e "\n[`tput setaf 2`OK`tput sgr0`] `tput setaf 2`SMPP Bind `tput setaf 3`$SMSCname `tput setaf 2`exists and bind has been established successfully since `tput setaf 3`$checkSMSCBind`tput sgr0`, bye.`tput sgr0`\n"
                                fi
                        else
                                echo -e "\n[`tput setaf 5`NO EXISTS`tput sgr0`] SMPP Bind `tput setaf 5`$SMSCname`tput sgr0` does not exist. Run call_sp_Add_SMPPbindUNS -h for help"
                                echo ""
                                exit
                        fi
                fi
        elif [ "$show" != "true" ] && [ "$operationLowercase" == "list" ];then
                getAllSMSC=$(ssh $mysqlmasterhost "echo 'select name from smsc;' | $whichmysql -u $mysqluser smpp" | grep -v name)
                if [ ! -z "$getAllSMSC" ];then
                        echo ""
                        i=1
                        while read -r smsclist
                        do
                                echo "$i. $smsclist"
                                i=$((i+1))
                        done  <<< "$getAllSMSC"
                        echo -e "\n[`tput setaf 2`OK`tput sgr0`] Run `tput setaf 3`call_sp_Add_SMPPbindUNS -n <SMSCname_SystemID> -o find/check`tput sgr0` to display details, bye\n"
                else
                        echo -e "\n[`tput setaf 5`NO EXISTS`tput sgr0`] There are not SMPP Binds. Run call_sp_Add_SMPPbindUNS -h for help"
                        echo ""
                        exit
                fi
        elif [ "$show" != "true" ] && [ "$operationLowercase" == "check" ];then
                if [ -z "$SMSCname" ];then
                        help
                        echo -e "\n\n`tput setaf 1`Flag -n is missing, please check (above) the help, bye`tput sgr0`\n"
                        echo ""
                        exit
                fi
                getSmsc_oid=$(ssh $mysqlmasterhost "echo 'select id from smsc where name =\"$SMSCname\"\G;' | $whichmysql -u $mysqluser smpp" | egrep -v row | cut -d":" -f2 | tr -d ' ')
                checkSMSCBind=$(ssh $mysqlmasterhost "echo 'select bind_time from smpp_link where smsc_oid =\"$getSmsc_oid\";' | $whichmysql -u $mysqluser smpp" | grep -v bind_time)
                IsCheckSMSCBindNull=$(echo "$checkSMSCBind" | grep NULL | wc -l)
                if [ ! -z "$checkSMSCBind" ] && [ "$IsCheckSMSCBindNull" == "0" ];then
                        echo -e "\n[`tput setaf 2`OK`tput sgr0`] SMPP Bind `tput setaf 3`$SMSCname`tput sgr0` has been established successfully since `tput setaf 3`$checkSMSCBind`tput sgr0`, bye\n"
                else
                        checkSMSCBind=$(echo "$checkSMSCBind" | tail -1)
                        echo -e "\n[`tput setaf 1`NO ESTABLISHED`tput sgr0`] `tput setaf 1`SMPP Bind `tput setaf 3`$SMSCname`tput setaf 1` is not establiashed yet. `tput setaf 3`smpp.smpp_link.bind_time=$checkSMSCBind`tput setaf 1` Run call_sp_Add_SMPPbindUNS -h for help`tput sgr0`"
                        echo ""
                        exit
                fi
        elif [ -z "$operation" ];then
                help
                echo -e "\n\n`tput setaf 1`Flag -o is missing, please check (above) the help, bye`tput sgr0`\n"
                echo ""
                exit
        fi
fi