#!/bin/bash
#############################################################################
# Filename:    feedfile.sh
#
# This sh script is to run End-To-End tests for Roamer Telefonica
#
# Copyright (c) Tango Telecom 2017
# Author: Hector Barriga
#
# All rights reserved.
# This document contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or
# in part is expressly prohibited, except as may be specifically
# authorized by prior written agreement or permission of Tango Telecom.
##############################################################################
# version 0.1.0 - First version
# version 0.1.2 - Add multitenancy
# version 0.1.3 - Add Offer Acceptance
version=0.1.3
#
##############################################################################

#---------------------------------------------------------------
# Configurations
#---------------------------------------------------------------
scriptDir=$1
mysqlmasterhost1="IPXMIATCDB1"
mysqlmasterhost2="IPXMIATCDB2"
mysqluser="root"
mysqlpw="t3il3achum"
logstashMachine=IPXMIATCRTE_flfeed
spcmMachine=IPXMIATCSPCMext
askToEnterNewEpochTime=no

if [ -z "$1" ];then scriptDir="/tango/logs/COSTAFF/hector/sh_scripts/WSMS/";fi
ncat -w 1 $mysqlmasterhost1 3306 </dev/null > $scriptDir/.tmp
if [ ! -s $scriptDir/.tmp ];then
        mysqlmasterhost=$mysqlmasterhost2
else
        mysqlmasterhost=$mysqlmasterhost1
fi
#subroutines

showfeedfile()
{
columnnames=$(echo "Start_Date_and_time,End_Date_and_time,DATA_RECORD_TYPE,VIOLATION,TIMEOUT,LABEL_OPC,LABEL_DPC,GTCALLING_NO,GTCALLED_NO,MS_ISDN,MSC,BACKCLG_NO,MS_RN,IMSI,SUBSCRIBER_OPERATOR_NAME,SUBSCRIBER_OPERATOR_COUNTRY,IMEI,TAC,SS_CODE,SERVICE_KEY,SUPPORT_CAMEL_PH,ER_CODE,TCAP_ABORT_CAUSE,SCCP_RETCAUSE,SERVCENT_ADDR,USRERR_REASON,NUMOF_SCCPMSG,SCCP_MSGLEN,TP_MTI,DCH,LINKSET_NAME,NUMOF_MO_SMSMSG,NUMOF_MT_SMSMSG,TP_OA_ALPHANUM,CAMEL_CAPABILITY_HANDLING,TP_OA,TP_DA,TRANS_TIME,OP_CODE,DIRECTION,DESTIN_OPERATOR_NAME,DESTIN_OPERATOR_COUNTRY,ORIG_OPERATOR_NAME,ORIG_OPERATOR_COUNTRY,VLR_NUMBER,SGSN_NUMBER,SGSN_ADDRESS,Call_Trace_Jump")
file=$(cat $1 | grep $msisdnorig)
ofile=$(cat $1 | grep $msisdnorig | paste -sd' ')
echo ""
echo "`tput setaf 5`TDR:"
echo "`tput setaf 3`$file"
echo "`tput sgr0`"
echo "`tput setaf 5`List of Fields:`tput sgr0`"
c=0
IFS=","
for i in $ofile
do
        if [ "$c" == "48" ];then
                c=0
                echo ""
        fi
        d=$((c+1))
        getColumnname=$(echo "$columnnames" | cut -d, -f"$d")
        if [ "$c" == "0" ] || [ "$c" == "1" ];then
                getEpochTime=$(echo "base=10; $i" | bc)
                getEpochTime=$(echo $((0x${i})))
                getNormalTime=$(date -d @$((getEpochTime/1000)))
                outputprintf=$(printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-1s \033[32m %-3s\n' $c. $getColumnname "=" $i "=> ")
                echo -en "$outputprintf $getNormalTime\033[1m"
                echo ""
        else
                printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-1s \033[0;39m\n' $c. $getColumnname "=" $i
        fi
        let ++c
done
echo ""
}

showfeedfileLTE()
{
columnnamesLTE=$(echo "Start_Date_and_time,End_Date_and_time,REQUEST_TYPE,IMSI,MSISDN,DIAMETER_RESULT_CODE,DIAMETER_PLMN_ID(vplmn),DIAM_ORIGIN_REALM(vplmn),DIAM_DESTINATION_REALM(hplmn)")
file=$(cat $1 | grep $msisdnorig)
ofile=$(cat $1 | grep $msisdnorig | paste -sd' ')
echo ""
echo "`tput setaf 5`LTE TDR:"
echo "`tput setaf 3`$file"
echo "`tput sgr0`"
echo "`tput setaf 5`List of Fields:`tput sgr0`"
c=0
IFS=","
for i in $ofile
do
        if [ "$c" == "48" ];then
                c=0
                echo ""
        fi
        d=$((c+1))
        getColumnname=$(echo "$columnnamesLTE" | cut -d, -f"$d")
        if [ "$c" == "0" ] || [ "$c" == "1" ];then
                getEpochTime=$(echo "base=10; $i")
                getEpochTime=$(echo $((0x${i})))
                getNormalTime=$(date -d @$((getEpochTime/1000)))
                outputprintf=$(printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-1s \033[32m %-3s\n' $c. $getColumnname "=" $i "=> ")
                echo -en "$outputprintf $getNormalTime\033[1m"
                echo ""
        else
                printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-1s \033[0;39m\n' $c. $getColumnname "=" $i
        fi
        let ++c
done
echo ""
}


showWSMScdrs()
{
if [ ! -d "$scriptDir/temp" ];then
        mkdir $scriptDir/temp
fi
echo "--------------------------------------------------------------------------------------------------------------------------------"
echo "`tput setaf 3`cp /tango/data/cdr/active_WSMS_SIBB.cdr $scriptDir/temp/active_WSMS_SIBB_tangoC.cdr`tput sgr0`"
#echo "`tput setaf 3`scp tangoD:/tango/data/cdr/active_WSMS_SIBB.cdr $scriptDir/temp/active_WSMS_SIBB_tangoD.cdr`tput sgr0`"
cp /tango/data/cdr/active_WSMS_SIBB.cdr $scriptDir/temp/active_WSMS_SIBB_tangoC.cdr
#scp tangoD:/tango/data/cdr/active_WSMS_SIBB.cdr $scriptDir/temp/active_WSMS_SIBB_tangoD.cdr
ls -altr $scriptDir/temp/active_WSMS_SIBB*
echo "`tput setaf 3`cat  $scriptDir/temp/active_WSMS_SIBB* | grep $msisdnorig`tput sgr0`"
wsmsCDRs=$(cat  $scriptDir/temp/active_WSMS_SIBB* | grep "$msisdnorig")
if [ -z "$wsmsCDRs" ];then
        echo ""
        echo "`tput setaf 1`No WSMS CDRs!!!`tput setaf 5` It seems CDR didnt pass the filters as per SIBB conditions
Very likely \"`tput setaf 1`Current EPOCH time in Hex\"`tput setaf 5` is too old"
        echo "HOWEVER!!! check /tango/logs/sibb/sibb$tenantlog.log`tput sgr0`"
        echo ""
else
        echo "$wsmsCDRs"
fi
}

showUNScdrs()
{
echo "--------------------------------------------------------------------------------------------------------------------------------"
echo "`tput setaf 3`cp /tango/data/cdr/active_UNS_WSMS.cdr $scriptDir/temp/active_UNS_WSMS_tangoC.cdr`tput sgr0`"
#echo "`tput setaf 3`scp tangoD:/tango/data/cdr/active_UNS_WSMS.cdr $scriptDir/temp/active_UNS_WSMS_tangoD.cdr`tput sgr0`"
cp /tango/data/cdr/active_UNS_WSMS.cdr $scriptDir/temp/active_UNS_WSMS_tangoC.cdr
#scp tangoD:/tango/data/cdr/active_UNS_WSMS.cdr $scriptDir/temp/active_UNS_WSMS_tangoD.cdr
ls -altr $scriptDir/temp/active_UNS_WSMS*
echo "`tput setaf 3`cat $scriptDir/temp/active_UNS_WSMS* | grep $msisdnorig | egrep \"$timeSiCdrs\"`tput sgr0`"
IsThereunsCDRs=$(cat $scriptDir/temp/active_UNS_WSMS* | grep "$msisdnorig" | egrep "$timeSiCdrs" | tail -2)
unsCDRs=$(cat $scriptDir/temp/active_UNS_WSMS* | grep "$msisdnorig" | egrep "$timeSiCdrs" | tail -2)
if [ -z "$IsThereunsCDRs" ];then
        echo ""
        echo -e "`tput setaf 1`No CDRs!!!`tput setaf 5` It seems NO SMS was sent to subscriber. Either:\n   1. Subscriber must have received it already\n 2. active_UNS_WSMS.cdr file rolled over\n   3. GTMS is still processing delivery of SMSs\n 4. UNS is not running or something`tput sgr0`"
        echo ""
else
        echo "$unsCDRs"
fi
}

showHRGcdrs()
{
echo "--------------------------------------------------------------------------------------------------------------------------------"
echo "`tput setaf 3`cp /tango/data/cdr/active_HRG_WSMS.cdr $scriptDir/temp/active_HRG_WSMS_tangoC.cdr`tput sgr0`"
#echo "`tput setaf 3`scp tangoD:/tango/data/cdr/active_HRG_WSMS.cdr $scriptDir/temp/active_HRG_WSMS_tangoD.cdr`tput sgr0`"
cp /tango/data/cdr/active_HRG_WSMS.cdr $scriptDir/temp/active_HRG_WSMS_tangoC.cdr
#scp tangoD:/tango/data/cdr/active_HRG_WSMS.cdr $scriptDir/temp/active_HRG_WSMS_tangoD.cdr
ls -altr $scriptDir/temp/active_HRG_WSMS*
echo "`tput setaf 3`cat $scriptDir/temp/active_HRG_WSMS* | grep $msisdnin | egrep \"$timeSiCdrs\"`tput sgr0`"
IsTherehrgCDRs=$(cat $scriptDir/temp/active_HRG_WSMS* | grep "$msisdnin" | egrep "$timeSiCdrs" | tail -2)
hrgCDRs=$(cat $scriptDir/temp/active_HRG_WSMS* | grep "$msisdnin" | egrep "$timeSiCdrs" | tail -2)
if [ -z "$IsTherehrgCDRs" ];then
        echo ""
        echo -e "`tput setaf 1`No CDRs!!!`tput setaf 5` It seems NO SMS was sent to subscriber. Either:\n   1. Subscriber must have received it already\n 2. active_HRG_WSMS.cdr file rolled over\n   3. GTMS is still processing delivery of SMSs\n 4. HRG is not running or something`tput sgr0`"
        echo ""
else
        echo "$hrgCDRs"
fi
}

getSIBBlogs()
{
sleep 5
echo "--------------------------------------------------------------------------------------------------------------------------------"
echo "`tput setaf 3`cat /tango/logs/sibb/sibb-wsms$tenantlog | grep \"$msisdnorig\"`tput sgr0`"
IsTherehrgLogs=$(cat /tango/logs/sibb/sibb-wsms$tenantlog | grep "$msisdnorig")
if [ -z "$IsTherehrgLogs" ];then
        echo ""
        echo -e "`tput setaf 1`No Logs!!!`tput setaf 5` It seems NO SMS was sent to subscriber. Either:\n   1. Logstash is not running\n 2. Filebeat is not running\n 3. SIBB_WSMS is not running`tput sgr0`"
        echo ""
else
        echo "$IsTherehrgLogs"
fi
}

showSOMcdrs()
{
echo "--------------------------------------------------------------------------------------------------------------------------------"
echo "`tput setaf 3`cp /tango/data/cdr/active_SOM.cdr $scriptDir/temp/active_SOM_tangoC.cdr`tput sgr0`"
#echo "`tput setaf 3`scp tangoD:/tango/data/cdr/active_SOM.cdr $scriptDir/temp/active_SOM_tangoD.cdr`tput sgr0`"
cp /tango/data/cdr/active_SOM.cdr $scriptDir/temp/active_SOM_tangoC.cdr
#scp tangoD:/tango/data/cdr/active_SOM.cdr $scriptDir/temp/active_SOM_tangoD.cdr
ls -altr $scriptDir/temp/active_SOM*
echo "`tput setaf 3`cat $scriptDir/temp/active_SOM* | grep $msisdnorig | egrep \"$sessionIdSiCdrs\"`tput sgr0`"
somcdrs=$(cat $scriptDir/temp/active_SOM* | grep "$msisdnorig" | egrep "$sessionIdSiCdrs")
IsTheresomcdrs=$(cat $scriptDir/temp/active_SOM* | grep "$msisdnorig" | egrep "$sessionIdSiCdrs" | cut -d, -f1)
if [ -z $IsTheresomcdrs ];then
        echo ""
        echo "`tput setaf 1`No CDRs!!!`tput setaf 5` It seems cdr file rolled over or CDRH (SOM) process is not running or something`tput sgr0`"
        echo ""
else
        echo "$somcdrs"
fi
}

checkAMDB()
{
namehost=$(hostname)
if [ "$mysqlmasterhost" == "$namehost" ];then
        whichmysql=$(which mysql)
        isPWinMyCnf=$(cat /etc/my.cnf | grep $mysqlpw | egrep -v grep)
        if [ ! -z "$isPWinMyCnf" ];then
                gomysql=$(echo "$whichmysql -u$mysqluser")
        else
                gomysql=$(echo "$whichmysql -u$mysqluser -p$mysqlpw")
        fi
        echo "--------------------------------------------------------------------------------------------------------------------------------"
        echo "`tput setaf 3`echo \"select * from activity where msisdn = '$msisdnorig'\G;\" | $gomysql activity_meter`tput sgr0`"
        subType=$(echo "select * from activity where msisdn = '$msisdnorig'\G;" | $gomysql activity_meter)
else
        whichmysql=$(ssh tango@$mysqlmasterhost 'which mysql')
        echo "`tput setaf 3`ssh tango@$mysqlmasterhost '$whichmysql -u$mysqluser -p$mysqlpw activity_meter -e \"select * from activity where msisdn = '$msisdnorig'\G;\"'`tput sgr0`"
        subType=$(ssh tango@$mysqlmasterhost "$whichmysql -u '$mysqluser' -p'$mysqlpw' activity_meter -e 'select * from activity where msisdn = $msisdnorig\G;'" 2>/dev/null)
fi
echo "$subType"
echo "--------------------------------------------------------------------------------------------------------------------------------"
}


echo "--------------------------------------------------------------------------------------------------------------------------------"
echo "`tput setaf 2`                               Welcome to \"feedfile.sh\" simulator for Telefonica
                                                version: $version             `tput sgr0`"
echo "--------------------------------------------------------------------------------------------------------------------------------"
cd $scriptDir
echo "`tput setaf 3`Going to $scriptDir/`tput sgr0`"
echo "--------------------------------------------------------------------------------------------------------------------------------"
ls -alrt | egrep -v feedfile
echo "--------------------------------------------------------------------------------------------------------------------------------"
defaultfeedfile=$(ls -altr $scriptDir/ | egrep -v feedfile | egrep -v total | egrep -v "drwxr" | egrep -v tmp | egrep -v oldTenant |  egrep -v temp | tail -1 | awk "{print \$9}")
echo -n "`tput setaf 3`Enter feed file [Default = $defaultfeedfile] > `tput sgr0`"
read feedfile
if [ -z $feedfile ];then
        feedfile=$defaultfeedfile
fi
if [ ! -f ./$feedfile ];then
        echo ""
        echo "`tput setaf 1`File doesnt exist!!!`tput sgr0` Nothing done, Bye"
        echo ""
else
iSItLTEFeedfile=$(echo "$feedfile" |  cut -c1-5 | grep eoNGN)
echo "--------------------------------------------------------------------------------------------------------------------------------"
oldTenant=$(cat $scriptDir/.oldTenant)
echo -n "`tput setaf 3`Enter tenant  (Default = $oldTenant) > `tput sgr0`"
read tenant
if [ "$tenant" != "$oldTenant" ] && [ ! -z "$tenant" ]; then
        echo "$tenant" > $scriptDir/.oldTenant
else
        tenant=$oldTenant
fi
if [ -z "$tenant" ] && [ -z "$oldTenant" ]; then
        echo ""
        echo "`tput setaf 1`You didnt enter a tenant!!!`tput sgr0` Try again, Bye"
        echo ""
        exit
elif [ "$tenant" == "brav1" ];then
        tenantlog="Brav1.log"
        SUB_OPERATOR_NAME="VIVO (BR)"
elif [ "$tenant" == "uruguay" ];then
        SUB_OPERATOR_NAME="MOVISTAR (UY)"
        DIAMETER_DESTINATION_REALM="748007"
        tenantlog="Uruguay.log"
elif [ "$tenant" == "COSTARICA" ];then
        SUB_OPERATOR_NAME="MOVISTAR (CR)"
        DIAMETER_DESTINATION_REALM="712004"
        tenantlog="Costarica.log"
elif [ "$tenant" == "colombia" ];then
        SUB_OPERATOR_NAME="MOVISTAR (CO)"
        DIAMETER_DESTINATION_REALM="732123"
        tenantlog="Colombia.log"
elif [ "$tenant" == "mexico" ];then
        SUB_OPERATOR_NAME="TELEFONICA MOVILES (MX)"
        DIAMETER_DESTINATION_REALM="334030"
        tenantlog="Mexico.log"
elif [ "$tenant" == "salvador" ];then
        SUB_OPERATOR_NAME="MOVISTAR (SV)"
        DIAMETER_DESTINATION_REALM="706004"
        tenantlog="Salvador.log"
elif [ "$tenant" == "chile" ];then
        SUB_OPERATOR_NAME="TELEFONICA (CL)"
        DIAMETER_DESTINATION_REALM="730007"
        tenantlog="Chile.log"
fi
if [ "$tenant" == "brav1" ];then
        tenantlog="$(echo "${tenant^}")"".log"
fi
if [ -z "$SUB_OPERATOR_NAME" ] && [ -z "$iSItLTEFeedfile" ];then
        echo "--------------------------------------------------------------------------------------------------------------------------------"
        echo -n "`tput setaf 3`Enter the SUBSRIBER_OPERATOR_NAME  (Default = VIVO (BR)) > `tput sgr0`"
        read SUB_OPERATOR_NAME
        if [ -z "$SUB_OPERATOR_NAME" ]; then
                SUB_OPERATOR_NAME="VIVO (BR)"
        fi
elif [ -z "$DIAMETER_DESTINATION_REALM" ] && [ ! -z "$iSItLTEFeedfile" ];then
        echo "--------------------------------------------------------------------------------------------------------------------------------"
        echo -n "`tput setaf 3`Enter the HPLMN in the 9th field of TDR DIAMETER_DESTINATION_REALM (Subscriber Home PLMN)  (Default = 724010 which is for VIVO BRAV1) > `tput sgr0`"
        read DIAMETER_DESTINATION_REALM
                if [ -z "$DIAMETER_DESTINATION_REALM" ]; then
                DIAMETER_DESTINATION_REALM="724010"
        fi
fi
echo "--------------------------------------------------------------------------------------------------------------------------------"

echo -n "`tput setaf 3`Do you wanna edit the file? [y/n] (Default n) > `tput sgr0`"
read confirm
if [ -z "$confirm" ]; then
        sleep 0
else
        if [ "$confirm" == "y" ];then
                vi $feedfile
        fi
fi
echo "--------------------------------------------------------------------------------------------------------------------------------"
echo "`tput setaf 3`List of Roamers:`tput sgr0`"
gettadigMappings=$(ssh $logstashMachine 'cat /etc/logstash/tadigMappings.csv')
cat $feedfile | while read in
do
if [ -z "$iSItLTEFeedfile" ];then
        getmsisdn=$(echo $in | cut -d"," -f10)
        getopcode=$(echo $in | cut -d"," -f39)
        if [ -z $getmsisdn ] || [ "$getmsisdn" == "_" ]; then
                part1=$(echo "MSISDN= <empty>\t\t")
        else
                part1=$(echo "MSISDN= $getmsisdn\t")
        fi
        homeSubCountry=$(echo $in | cut -d"," -f15)
        srcountry=$(echo "$gettadigMappings" | grep "$homeSubCountry" | tail -1 | rev | cut -d',' -f1 | rev)
        color=2
        TDRdisplay="GOOD"
        if [ -z "$getmsisdn" ] || [ "$getmsisdn" == "_" ] || [ "$homeSubCountry" != "$SUB_OPERATOR_NAME" ];then
                color=1
                TDRdisplay="[NO GOOD TDR for $SUB_OPERATOR_NAME, SIBB $tenant wont be triggered]"
        fi
        if [ "$getopcode" != 2 ];then
                color=1
                TDRdisplay='[NO GOOD OP_CODE. It is not 2, any SIBB wont be triggered]'

        fi
        if [ -z "$srcountry" ];then
                color=1
                TDRdisplay='[NO GOOD TDR, VISITOR COUNTRY OPERATOR is not in /etc/logstash/tadigMappings.csv. SIBB might be triggered but CMCG wont find an OFFER]'
        fi
        echo -e "$part1""\tSUBSCRIBER_OPERATOR_NAME=$homeSubCountry""\t\tTENANT=$tenant""\t\tTDR=`tput setaf $color`$TDRdisplay`tput sgr0`"
else
        getmsisdn=$(echo $in | cut -d"," -f5)
        echo $in | cut -d, -f9 | awk -F'.' '{print substr($3,4,3) substr($2,4,3)}' > $scriptDir/.tmp
        getHplmn=$(cat $scriptDir/.tmp)
        if [ -z $getmsisdn ] || [ "$getmsisdn" == "_" ]; then
                part1=$(echo "MSISDN= <empty>\t\t")
        else
                part1=$(echo "MSISDN= $getmsisdn\t")
        fi
        color=2
        TDRdisplay="GOOD"
        compareHplmn1=$(cat /etc/logstash/hplmnToTenant.csv | grep "$getHplmn")
        compareHplmn2=$(cat /etc/logstash/hplmnToTenant.csv | grep "$DIAMETER_DESTINATION_REALM")
        if [ -z "$compareHplmn1" ];then
                color=1
                TDRdisplay="[NO GOOD TDR, 9th field $getHplmn is not configured in /etc/logstash/hplmnToTenant.csv. SIBB $tenant wont be triggered]"
        fi
        if [ -z "$compareHplmn2" ];then
                color=1
                TDRdisplay="[NO GOOD TDR, Your HPLMN in TDR 9th field DIAMETER_DESTINATION_REALM $DIAMETER_DESTINATION_REALM is not configured in /etc/logstash/hplmnToTenant.csv. SIBB $tenant wont be triggered]"
        fi

        if [ -z "$getmsisdn" ] || [ "$getmsisdn" == "_" ] || [ "$getHplmn" != "$DIAMETER_DESTINATION_REALM" ];then
                color=1
                TDRdisplay="[GOOD TDR but your HPLMN in DIAMETER_DESTINATION_REALM $DIAMETER_DESTINATION_REALM that you want to monitor does not match with TDR's HPLMN in 9th field $getHplmnSIBB]"
        fi
        echo -e "$part1""\tHPLMN (TDR 9th field) = $DIAMETER_DESTINATION_REALM""\t\tTENANT = $tenant""\t\tTDR = `tput setaf $color`$TDRdisplay`tput sgr0`"
fi
done

echo "--------------------------------------------------------------------------------------------------------------------------------"
if [ -z "$iSItLTEFeedfile" ];then
        lastmsisdnin=$(cat $feedfile | head -1 | cut -d"," -f10)
else
        lastmsisdnin=$(cat $feedfile | head -1 | cut -d"," -f5)
fi

echo -n "`tput setaf 3`Enter msisdn you would like to monitor [Default = First on the list $lastmsisdnin]  = > `tput sgr0`"
read selectedmsisdn
if [ -z "$iSItLTEFeedfile" ];then
        if [ -z "$selectedmsisdn" ];then
                msisdnin=$(cat $feedfile | grep $lastmsisdnin | cut -d"," -f10 | sed 's/./&0/g' | cut -d= -f2 | sed 's/0 020403/20403/' | sed 's/.$//' | head -1)
                msisdnorig=$lastmsisdnin
        else
                msisdnin=$(cat $feedfile | grep $selectedmsisdn | cut -d"," -f10 | sed 's/./&0/g' | cut -d= -f2 | sed 's/0 020403/20403/' | sed 's/.$//' | head -1)
                msisdnorig=$selectedmsisdn
        fi
else
        if [ -z "$selectedmsisdn" ];then
                msisdnin=$(cat $feedfile | grep $lastmsisdnin | cut -d"," -f5 | sed 's/./&0/g' | cut -d= -f2 | sed 's/0 020403/20403/' | sed 's/.$//' | head -1)
                msisdnorig=$lastmsisdnin
        else
                msisdnin=$(cat $feedfile | grep $selectedmsisdn | cut -d"," -f5 | sed 's/./&0/g' | cut -d= -f2 | sed 's/0 020403/20403/' | sed 's/.$//' | head -1)
                msisdnorig=$selectedmsisdn
        fi
fi
if [ -z "$iSItLTEFeedfile" ];then
        fhomeSubCountry=$(cat $feedfile | grep $msisdnorig | cut -d"," -f15)
        fvisitplmnNum=$(ssh $logstashMachine 'cat /etc/logstash/tadigMappings.csv' | grep "$fhomeSubCountry" | wc -l)
        if [ $fvisitplmnNum -eq 1 ];then
                fvisitplmn=$(ssh $logstashMachine 'cat /etc/logstash/tadigMappings.csv' | grep "$fhomeSubCountry" | rev | cut -d',' -f1 | rev)
        else
                defaultfvisitplmn=$(ssh $logstashMachine 'cat /etc/logstash/tadigMappings.csv' | grep "$fhomeSubCountry" | tail -1 | rev | cut -d',' -f1 | rev)
                echo "----------------------"
                ssh $logstashMachine 'cat /etc/logstash/tadigMappings.csv' | grep "$fhomeSubCountry" | rev | cut -d',' -f1 | rev
                echo "----------------------"
                echo -n "`tput setaf 3`As seen, there are 3 tagids in $logstashMachine:/etc/logstash/tadigMappings.csv!! Please select one of them [Default = $defaultfvisitplmn]  = > `tput sgr0`"
                read fvisitplmn
        fi
else
        getHplmn=$(cat $scriptDir/.tmp)
        fvisitplmn=$(cat /etc/logstash/hplmnToTenant.csv | grep "$getHplmn" | cut -d, -f2)
fi



tenant=$(echo "$fvisitplmn" | tr '[:upper:]' '[:lower:]')
echo ""
echo "`tput setaf 5`############################### NOTE: ####################################
# You selected `tput sgr0`$msisdnorig`tput setaf 5` to be monitored.
# You will see results only for that subscriber in particular (below).   #
# NOTE: The other GOOD TDRs will ALSO be processed if EPOCH time is ok   #
##########################################################################
`tput sgr0`"
if [ -z "$iSItLTEFeedfile" ];then
        date1=$(echo "$feedfile" | cut -d"-" -f5)
        sec1=$(echo "$date1" | rev | cut -c1-2 | rev)
        date2=$(echo "$feedfile" | cut -d"-" -f6)
        sec2=$(echo "$date2" | rev | cut -c1-2 | rev)
else
        date1=$(echo "$feedfile" | cut -d"-" -f4)
        sec1=$(echo "$date1" | rev | cut -c1-2 | rev)
        date2=$(echo "$feedfile" | cut -d"-" -f5)
        sec2=$(echo "$date2" | rev | cut -c1-2 | rev)
fi
if [[ $sec1 -eq 59 ]];then
        newdate1=$(($date1 + 41))
else
        newdate1=$(($date1 + 1))
fi
if [[ $sec2 -eq 59 ]];then
        newdate2=$(($date2 + 41))
else
        newdate2=$(($date2 + 1))
fi
anothernewdate=$(($date + 2))
prefixnewfile=$(echo "$feedfile" | rev | cut -c30- | rev)
newfeedfile=$(echo "$prefixnewfile""$newdate1""-""$newdate2")
echo "--------------------------------------------------------------------------------------------------------------------------------"
mv $feedfile $newfeedfile
feedfile=$(echo "$newfeedfile")
echo "`tput setaf 3`Feed file is now: `tput sgr0`$feedfile"
echo ""
currentEpoch=$(date +"%s")
currentEpochmillisec=$((currentEpoch*1000))
hexCuerrentEpoch=$(echo "obase=16; $currentEpochmillisec" | bc)
if [ $askToEnterNewEpochTime = "yes" ] || [ $askToEnterNewEpochTime = "true" ]; then
        if [ -z "$iSItLTEFeedfile" ];then
                showfeedfile "$feedfile"
        else
                showfeedfileLTE "$feedfile"
        fi
        echo "--------------------------------------------------------------------------------------------------------------------------------"
        echo "`tput setaf 2`FYI : Current EPOCH time is (in Hex) = `tput sgr0` $hexCuerrentEpoch"
        echo "--------------------------------------------------------------------------------------------------------------------------------"
        echo -n "`tput setaf 3`Do you wanna re-edit it? [y/n] (Default n) > `tput sgr0`"
        read confirm
        if [ -z "$confirm" ]; then
                sleep 0
        else
                if [ "$confirm" == "y" ];then
                        vi $feedfile
                        if [ -z "$iSItLTEFeedfile" ];then
                                showfeedfile "$feedfile"
                        else
                                showfeedfileLTE "$feedfile"
                        fi
                        echo "--------------------------------------------------------------------------------------------------------------------------------"
                fi
        fi
else
        getFirstFieldEpochTime=$(cat $feedfile | grep "$msisdnorig" | grep "$homeSubCountry" | grep "$srcountry" | cut -d"," -f1)
        sed "s/$getFirstFieldEpochTime/$hexCuerrentEpoch/g" $feedfile > $scriptDir/.tmp
        mv $scriptDir/.tmp $feedfile
        echo "--------------------------------------------------------------------------------------------------------------------------------"
        echo "`tput setaf 2`FYI : Old EPOCH time was (in HEX) = `tput sgr0` $getFirstFieldEpochTime"
        echo "`tput setaf 2`FYI : New EPOCH time is (in HEX)  = `tput sgr0` $hexCuerrentEpoch"
        echo "--------------------------------------------------------------------------------------------------------------------------------"
fi
if [ -z "$iSItLTEFeedfile" ];then
        showfeedfile "$feedfile"
else
        showfeedfileLTE "$feedfile"
fi
echo "--------------------------------------------------------------------------------------------------------------------------------"
checkAMDB
isItToBeBounce=$(echo $subType | grep location)
if [ ! -z "$isItToBeBounce" ];then
        echo -n "`tput setaf 3`Do you wanna delele $msisdnorig \"location\" record from AM? [y/n] (Default y) > `tput sgr0`"
        read confirmDelAM
        if [ "$confirmDelAM" == "y" ] || [ -z "$confirmDelAM" ];then
                echo "`tput setaf 3`ssh $mysqlmasterhost \"mysql -u root -e 'delete from activity_meter.activity where msisdn = \"$msisdnorig\" and activity_name = \"location\"`tput sgr0`;'"
                ssh $mysqlmasterhost "mysql -u root -e 'delete from activity_meter.activity where msisdn = \"$msisdnorig\" and activity_name = \"location\";'"
                echo "--------------------------------------------------------------------------------------------------------------------------------"
                checkAMDB
        fi
fi
isItToBeBounce=$(echo $subType | grep SUBSCRIBER_LOCATION)
if [ ! -z "$isItToBeBounce" ];then
        echo -n "`tput setaf 3`Do you wanna delele $msisdnorig activity_name LIKE \"%SUBSCRIBER_LOCATION\" record from AM? [y/n] (Default y) > `tput sgr0`"
        read confirmDelAM
        if [ "$confirmDelAM" == "y" ] || [ -z "$confirmDelAM" ];then
                echo "`tput setaf 3`ssh $mysqlmasterhost \"mysql -u root -e 'delete from activity_meter.activity where msisdn = \"$msisdnorig\" and activity_name like \"%SUBSCRIBER_LOCATION\"`tput sgr0`;'"
                ssh $mysqlmasterhost "mysql -u root -e 'delete from activity_meter.activity where msisdn = \"$msisdnorig\" and activity_name like \"%SUBSCRIBER_LOCATION\";'"
                echo "--------------------------------------------------------------------------------------------------------------------------------"
                checkAMDB
        fi
fi
isItToBeBounce=$(echo $subType | grep SMS)
if [ ! -z "$isItToBeBounce" ];then
        echo -n "`tput setaf 3`Do you wanna delele $msisdnorig activity_name LIKE \"%SMS%\" record from AM? [y/n] (Default y) > `tput sgr0`"
        read confirmDelAM
        if [ "$confirmDelAM" == "y" ] || [ -z "$confirmDelAM" ];then
                echo "`tput setaf 3`ssh $mysqlmasterhost \"mysql -u root -e 'delete from activity_meter.activity where msisdn = \"$msisdnorig\" and activity_name like \"%SMS%\"`tput sgr0`;'"
                ssh $mysqlmasterhost "mysql -u root -e 'delete from activity_meter.activity where msisdn = \"$msisdnorig\" and activity_name like \"%SMS%\";'"
                echo "--------------------------------------------------------------------------------------------------------------------------------"
                checkAMDB
        fi
fi
isItToBeBounce=$(echo $subType | grep subscriberInfo)
if [ ! -z "$isItToBeBounce" ];then
        echo -n "`tput setaf 3`Do you wanna delele $msisdnorig activity_name LIKE \"%subscriberInfo%\" record from AM? [y/n] (Default y) > `tput sgr0`"
        read confirmDelAM
        if [ "$confirmDelAM" == "y" ] || [ -z "$confirmDelAM" ];then
                echo "`tput setaf 3`ssh $mysqlmasterhost \"mysql -u root -e 'delete from activity_meter.activity where msisdn = \"$msisdnorig\" and activity_name like \"%subscriberInfo%\"`tput sgr0`;'"
                ssh $mysqlmasterhost "mysql -u root -e 'delete from activity_meter.activity where msisdn = \"$msisdnorig\" and activity_name like \"%subscriberInfo%\";'"
                echo "--------------------------------------------------------------------------------------------------------------------------------"
                checkAMDB
        fi
fi
echo -n "`tput setaf 3`Do you wanna drop it in /tango/data/ingest/wsms/ [y/n] > `tput sgr0`"
read confirm
if [ "$confirm" == "y" ] || [ -z "$confirm" ];then
        echo "--------------------------------------------------------------------------------------------------------------------------------"
        cp $feedfile /tango/data/ingest/wsms/
        chmod 777 /tango/data/ingest/wsms/$feedfile
        echo -en "\n`tput setaf 3`Wait until LOGSTASH processes $feedfile and triggers SI API * "
        finishedprocessed="false"
        isSIBB_WSMCDRsReady=0
        a=0
        while [ "$isSIBB_WSMCDRsReady" == "0" ]
        do
                isSIBB_WSMCDRsReady=$(grep $msisdnorig /tango/data/cdr/active_WSMS_SIBB.cdr | wc -l)
                sleep 1
                echo -n "* "
                if [ $a -eq 30 -o $a -eq 60 -o $a -eq 120 -o $a -eq 180 -o $a -eq 240 ];then
                        echo -n "No CDRs in active_WSMS_SIBB.cdr yet "
                fi
                let a++
        done
        echo -n " Done. `tput sgr0`Time = $a secs."
        echo ""
        echo "--------------------------------------------------------------------------------------------------------------------------------`tput setaf 2`"
        echo "`tput setaf 3`ls -atlr /tango/data/ingest/wsms/ | grep $newfeedfile `tput sgr0`"
        ls -atlr /tango/data/ingest/wsms/ | grep "$newfeedfile"
        showWSMScdrs
        sleep 10
        checkAMDB
        getSIBBlogs
        showSOMcdrs
        echo -en "\n`tput setaf 3`Wait until GTMS delay is completed and 1st SMS ist submitted * "
        finishedprocessed="false"
        a=0
        while [ $a -lt 120 ]
        do
                sleep 1
                echo -n "* "
                let a++
        done
        showUNScdrs
        showHRGcdrs
else
        echo "Nothing done, Bye"
fi

fi