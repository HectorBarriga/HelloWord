#!/bin/bash
#############################################################################
# Filename:    cdrfind.sh
# Revision:    $Revision: 0.3.2 $
# Author:      Hector Barriga
#
# Jiras:
# CO Scripts:  COSC-xx
# CO Internal: COIT-xx
#
# This sh script finds cdrmon old cdr for an specific msisdn
# user has to enter the number of days he wansts find including today
# If not days is entered, Default is Today
# User can only search MAXIMUM 8 DAYS ago
#
# Copyright (c) Tango Telecom 2016
# Author: Hector Barriga
#
# All rights reserved.
# This document contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or
# in part is expressly prohibited, except as may be specifically
# authorized by prior written agreement or permission of Tango Telecom.
##############################################################################
# version 0.1.0 - First version
# version 0.2.0 - Add Second pattern to search and add possibility to select hours if searching "today"
# version 0.3.0 - Add USSD cdrs
# version 0.3.1 - Add SSRV cdrs
# version 0.3.2 - Add config file for settings
#
##############################################################################


# Config Parameters

#---------------------------------------------------------------
# get cdrfind.cfg file
#--------------------------------------------------------------
findConfigFile=$(find /tango/scripts/ -name cdrfind.cfg)
DIR=$(cat "$findConfigFile" | tr -d " \t\r" | grep "scriptdir=" | cut -d"#" -f1 | cut -d= -f2)
scriptdir=$(cat "$findConfigFile" | tr -d " \t\r" | grep "scriptdir=" | cut -d"#" -f1 | cut -d= -f2 | rev | rev)

#---------------------------------------------------------------
# Set Initial variables
#---------------------------------------------------------------
today=`date +20%y%m%d`
todaydate=$(perl -e '@d=localtime time(); printf "%02d%02d%02d\n", $d[5]-100,$d[4]+1,$d[3]')
if [ ! -d "$scriptdir/temp" ];then
mkdir $scriptdir/temp
fi
operativesystem=$(uname)
if [ "$operativesystem" == "SunOS" ]; then
export TERM=xtermc
fi

#---------------------------------------------------------------
# get General Paramenters from cdrfind.cfg
#--------------------------------------------------------------
sed -n '/\[General]/,/\[/p' $findConfigFile | awk  '!/\[General]/ && !/\[/' | tr -d " \t\r" | awk '/Sitename/ || /scriptdir/ || /default_mainpage_opt/' | cut -d"#" -f1 > $DIR/temp/tmp.file
config_file=$DIR/temp/tmp.file
oldIFS="$IFS"
IFS="="
while read name value
do
        if [ ! -z "$name" ] && [ ! -z "$value" ];then
                eval $name="$value"
        fi
done < $config_file
IFS="$oldIFS"

#---------------------------------------------------------------
# get servers Paramenters from cdrfind.cfg
#--------------------------------------------------------------
sed -n '/\[servers]/,/\[/p' $findConfigFile | awk  '!/\[servers]/ && !/\[/' | tr -d " \t\r" | awk '/cdr_server1/ || /cdr_server2/' | cut -d"#" -f1 > $DIR/temp/tmp.file
config_file=$DIR/temp/tmp.file
oldIFS="$IFS"
IFS="="
while read name value
do
        if [ ! -z "$name" ] && [ ! -z "$value" ];then
                eval $name="$value"
        fi
done < $config_file
IFS="$oldIFS"

#---------------------------------------------------------------
# get smsc Paramenters from cdrfind.cfg
#--------------------------------------------------------------
sed -n '/\[smsc]/,/\[/p' $findConfigFile | awk  '!/\[smsc]/ && !/\[/' | tr -d " \t\r" | awk '/activecdrname/ || /backcdrprefixname/ || /cdrbackdir/ || /cdrmonscript/' | cut -d"#" -f1 > $DIR/temp/tmp.file
config_file=$DIR/temp/tmp.file
oldIFS="$IFS"
IFS="="
while read name value
do
        if [ ! -z "$name" ] && [ ! -z "$value" ];then
                eval $name="$value"
        fi
done < $config_file
IFS="$oldIFS"

# Subroutines

check_exit()
{
if [ ! -z "$1" ];then
        if [ "$1" == "exit" ] || [ "$1" == "EXIT" ];then
                exit_page "Bye." $2
                exit
        fi
fi
}

mainbanner()
{
if [ "$5" == "bold" ];then
        tput bold
fi

echo -en "\e[$3;48;5;$4m"

if [ "$2" == "C" ]; then
        leftspaces=$(((116-${#1}) / 2))
else
        leftspaces=6
fi

for (( n=0; n<$leftspaces; n++ ))
do
        echo -en " "
done

if [ "$6" == "underline" ];then
        tput smul
        echo -en "$1\e[0m\e[34;48;5;153m"
else
        if [ "$2" == "Q" ]; then
                echo -en "$1 \e[0m   \e[$3;48;5;$4m"
        else
                echo -n "$1"
        fi
fi
if [ "$2" == "Q" ]; then
        rightspaces=$(($leftspaces + ${#1} + 4))
else
        rightspaces=$(($leftspaces + ${#1}))
fi
for (( n=$rightspaces; n<116; n++ ))
do
        echo -en " "
done

echo -e "\e[0m"
}

mainbanner_questionAnswered()
{
echo -en "\e[$3;48;5;$4m"
for (( n=0; n<6; n++ ))
do
        echo -en " "
done
echo -en "$1 \e[0m $2 \e[$3;48;5;$4m"
rightspaces=$(($leftspaces + ${#1} + ${#2}))
for (( n=$rightspaces; n<113; n++ ))
do
        echo -en " "
done
echo -e "\e[0m"
}

mainbanner_menu_tab()
{
echo -en "\e[34;48;5;153m"
for (( n=0; n<6; n++ ))
do
        echo -en " "
done
case $5 in
        0) prespaces=107;tput smul;echo -en "$1                                                                                         \e[0m\e[94;48;5;153m";;
        1) prespaces=106;tput smul;echo -en "$1   =>   $2                                                                        \e[0m\e[94;48;5;153m";;
        2) prespaces=113;tput smul;echo -en "$1   =>   $2   =>   $3                                                       \e[0m\e[94;48;5;153m";;
        3) prespaces=120;tput smul;echo -en "$1   =>   $2   =>   $3   =>   $4                                        \e[0m\e[94;48;5;153m";;
esac
for (( n=$prespaces; n<116; n++ ))
do
        echo -en " "
done

echo -e "\e[0m"
}

banner()
{
echo ""
mainbanner "                                           _           __   _               _                               " C 97 27 bold
mainbanner "                                          | |         / _| (_)             | |                              " C 97 27 bold
mainbanner "                                 ___    __| |  _ __  | |_   _   _ __     __| |                              " C 97 27 bold
mainbanner "                                / __|  / _  | | '__| |  _| | | | '_ \   / _  |                              " C 97 27 bold
mainbanner "                               | (__  | (_| | | |    | |   | | | | | | | (_| |                              " C 97 27 bold
mainbanner "                                \___|  \__,_| |_|    |_|   |_| |_| |_|  \__,_|                              " C 97 27 bold
mainbanner "" C 97 27
mainbanner "$Sitename" C 97 27 bold
mainbanner "$1" C 97 27 bold
mainbanner "                                                                                             CTRL+C to Cancel" L 31 27 bold
mainbanner "" C 97 27
mainbanner "" L 94 153
}

exit_page()
{
clear
banner "SMSC  CDRs"
mainbanner_menu_tab "TYPE OF CDRs" "PATTERNS" "LENGTH OF SEARCH" "FOUND CDRs" $2
mainbanner "" L 34 153
mainbanner "" L 34 153
mainbanner "" L 34 153
mainbanner "$1" C 31 153
mainbanner "" L 34 153
mainbanner "" L 34 153
mainbanner "                                                                                                    " L 34 153 bold underline
mainbanner "Version 0.3.1                                                                 copyright 2017 Tango Telecom Ltd." C 30 153
mainbanner "" L 94 153
echo ""
}


processing_page()
{
clear
banner "SMSC  CDRs"
mainbanner_menu_tab "TYPE OF CDRs" "PATTERNS" "LENGTH OF SEARCH" "FOUND CDRs" 0
mainbanner "" L 34 153
mainbanner "" L 34 153
mainbanner "" L 34 153
mainbanner "$1" C 32 153
mainbanner "" L 34 153
mainbanner "" L 34 153
mainbanner "                                                                                                    " L 34 153 bold underline
mainbanner "Version 0.3.1                                                                 copyright 2017 Tango Telecom Ltd." C 30 153
mainbanner "" L 94 153
echo ""
}

smsc_page()
{
clear
banner "SMSC  CDRs"
mainbanner_menu_tab "TYPE OF CDRs" "PATTERNS" "LENGTH OF SEARCH" "FOUND CDRs" 1
mainbanner "" L 34 153
mainbanner "" L 34 153
mainbanner "Enter MSISDN(aNum or bNum) or SystemID :" Q 94 153
mainbanner "" L 34 153
mainbanner "Do you want to add another pattern (MSISDN or SystemID) ? [y/n]" Q 94 153
mainbanner "" L 34 153
mainbanner "" L 34 153
mainbanner "" L 34 153
mainbanner "To exit, enter exit" L 31 153
mainbanner "                                                                                                    " L 34 153 bold underline
mainbanner "Version 0.3.1                                                                 copyright 2017 Tango Telecom Ltd." C 30 153
mainbanner "" L 94 153
echo ""

for i in {0..10};do tput cuu1;done
tput cuf 48
read -e msisdn
check_exit "$msisdn" 1
if [ -z "$msisdn" ];then
        exit_page "Sorry, it cannot be empty. Please try again, Bye." 1
        exit
fi
tput cup 18 71
read -e confirmation
check_exit "$confirmation" 1
if [ "$confirmation" == "y" ] || [ "$confirmation" == "Y" ];then
        smsc_page_secondQuestion
        smsc_length_page
else
        smsc_length_page
fi
}

smsc_page_secondQuestion()
{
clear
banner "SMSC  CDRs"
mainbanner_menu_tab "TYPE OF CDRs" "PATTERNS" "LENGTH OF SEARCH" "FOUND CDRs" 1
mainbanner "" L 34 153
mainbanner "" L 34 153
mainbanner_questionAnswered "Enter MSISDN(aNum or bNum) or SystemID :" "$msisdn" 94 153
mainbanner "" L 34 153
mainbanner_questionAnswered "Do you want to add another pattern (MSISDN or SystemID) ? [y/n]" "$confirmation" 94 153
mainbanner "" L 34 153
mainbanner "Enter MSISDN(aNum or bNum) or SystemID :" Q 94 153
mainbanner "" L 34 153
mainbanner "" L 34 153
mainbanner "" L 34 153
mainbanner "To exit, enter exit" L 31 153
mainbanner "                                                                                                    " L 34 153 bold underline
mainbanner "Version 0.3.1                                                                 copyright 2017 Tango Telecom Ltd." C 30 153
mainbanner "" L 94 153
echo ""

tput cup 20 48
read -e msisdn2
check_exit "$msisdn2" 1
}

smsc_length_processing_page()
{

clear
banner "SMSC  CDRs"
mainbanner_menu_tab "TYPE OF CDRs" "PATTERNS" "LENGTH OF SEARCH" "PROCESSING" 3
mainbanner "" L 34 153
mainbanner "" L 34 153
mainbanner_questionAnswered "Enter number of days you want to search (MAXIMUM 8 DAYS) ? [Default = 1 Day (Today)] >" "$idays" 94 153
mainbanner "" L 34 153
mainbanner_questionAnswered "Enter START Hour (HH fomat) [Default = 00] >" "$startime" 94 153
mainbanner "" L 34 153
mainbanner_questionAnswered "Enter END Hour   (HH fomat) [Default = 23] >" "$endtime" 94 153
mainbanner "" L 34 153
mainbanner "Got it, please wait few seconds, processing ...." C 32 153
mainbanner "" L 34 153
mainbanner "                                                                                                    " L 94 153 bold underline
mainbanner "Version 0.3.1                                                                 copyright 2017 Tango Telecom Ltd." C 30 153
mainbanner "" L 94 153
echo ""

}

smsc_length_withHours_page()
{

clear
banner "SMSC  CDRs"
mainbanner_menu_tab "TYPE OF CDRs" "PATTERNS" "LENGTH OF SEARCH" "FOUND CDRs" 2
mainbanner "" L 34 153
mainbanner "" L 34 153
mainbanner_questionAnswered "Enter number of days you want to search (MAXIMUM 8 DAYS) ? [Default = 1 Day (Today)] >" "$idays" 94 153
mainbanner "" L 34 153
mainbanner "Enter START Hour (HH fomat) [Default = 00] >" Q 94 153
mainbanner "" L 34 153
mainbanner "Enter END Hour   (HH fomat) [Default = 23] >" Q 94 153
mainbanner "" L 34 153
mainbanner "" L 34 153
mainbanner "" L 34 153
mainbanner "To exit, enter exit" L 31 153
mainbanner "                                                                                                    " L 94 153 bold underline
mainbanner "Version 0.3.1                                                                 copyright 2017 Tango Telecom Ltd." C 30 153
mainbanner "" L 94 153
echo ""

tput cup 18 52
read startime
check_exit "$startime" 2
if [ -z "$startime" ];then
        startime="0"
else
        startime=$(printf %01d $startime)
fi

tput cup 20 52
read endtime
check_exit "$endtime" 2
if [ -z "$endtime" ];then
        endtime="23"
else
        endtime=$(printf %01d $endtime)
fi

if [ "$startime" -gt "$endtime" ];then
    exit_page "Sorry, START Hour can not be earlier (<) than END Hour, try again. Bye. " $2
    exit
else
        smsc_length_processing_page
fi
}

smsc_length_page()
{

clear
banner "SMSC  CDRs"
mainbanner_menu_tab "TYPE OF CDRs" "PATTERNS" "LENGTH OF SEARCH" "FOUND CDRs" 2
mainbanner "" L 34 153
mainbanner "" L 34 153
mainbanner "Enter number of days to search (MAXIMUM 8 DAYS - including today) ? [Default = 1 Day (Today)] >" Q 94 153
mainbanner "" L 34 153
mainbanner "" L 34 153
mainbanner "" L 34 153
mainbanner "To exit, enter exit" L 31 153
mainbanner "                                                                                                    " L 94 153 bold underline
mainbanner "Version 0.3.1                                                                 copyright 2017 Tango Telecom Ltd." C 30 153
mainbanner "" L 94 153
echo ""
tput cup 16 103
read -e idays
check_exit "$idays" 2
if [ -z $idays ];then
        idays=1
fi
days=$(($idays - 1))
if [ "$idays" -gt 8 ]; then
        exit_page "Sorry, it cannot be more than 7 Days. Please try again, Bye. " 2
        exit
fi

if [ "$idays" == "1" ];then
        smsc_length_withHours_page
else
        processing_page "Got it, please wait few seconds, processing ...."
fi
}

smsc_parsed_cdr()
{
banner "SMSC  CDRs"
mainbanner_menu_tab "TYPE OF CDRs" "PATTERNS" "LENGTH OF SEARCH" "FOUND CDRs" 3
mainbanner "" L 34 153
mainbanner "" L 34 153
mainbanner "CDR Found  (Parsed)" C 32 153
mainbanner "" L 34 153
mainbanner "                                                                                                    " L 94 153 bold underline
mainbanner "Version 0.3.1                                                                 copyright 2017 Tango Telecom Ltd." C 30 153
mainbanner "" L 94 153
echo ""
/tango/bin/cdrsearch.pl -f $scriptdir/temp/filteredCDRs.txt
}

smsc_cdrmon()
{
banner "SMSC  CDRs"
mainbanner_menu_tab "TYPE OF CDRs" "PATTERNS" "LENGTH OF SEARCH" "FOUND CDRs" 3
mainbanner "" L 34 153
mainbanner "" L 34 153
mainbanner "MAP Error Result Summary:" L 32 153 normal
mainbanner "" L 34 153
mainbanner "Total   Error Code   " L 32 153 normal underline
/tango/bin/cdrsearch.pl -f $scriptdir/temp/filteredCDRs.txt | grep "MAP Error" | awk '{print $4$5$6$7$8$9$10;}' | sort | uniq -c | while read mapErrorResultLine
do
        mainbanner " $mapErrorResultLine" L 32 153
done
mainbanner "" L 34 153
mainbanner "                                                                                                    " L 94 153 bold underline
mainbanner "Version 0.3.1                                                                 copyright 2017 Tango Telecom Ltd." C 30 153
mainbanner "" L 94 153
echo ""
$cdrmonscript -f $scriptdir/temp/filteredCDRs.txt
}



get_backcdrs()
{
tput setaf 5
echo "Coping all files $cdrbackdir/*$backcdrprefixname$cdr_server1.$1* in $scriptdir/temp/ ...................."
tput setaf 4
cp $cdrbackdir/*$backcdrprefixname$cdr_server1.$1* $scriptdir/temp/
tput setaf 5
echo "Coping files from $cdr_server2: $cdrbackdir/*$backcdrprefixname$cdr_server2.$1* in $scriptdir/temp/ ................."
tput setaf 4
scp $cdr_server2:$cdrbackdir/*$backcdrprefixname$cdr_server2.$1* $scriptdir/temp/
tput sgr0
}

get_zipfile()
{
tput setaf 5
echo "Coping zip files $cdrbackdir/*$backcdrprefixname$1.zip in $scriptdir/temp/ ...................."
tput setaf 4
cp $cdrbackdir/*$backcdrprefixname$1.zip $scriptdir/temp/
tput setaf 5
echo "Coping zip files from $cdr_server2: $cdrbackdir/$backcdrprefixname$1.zip in $scriptdir/temp/$backcdrprefixname$1.$cdr_server2.zip ................."
tput setaf 4
scp $cdr_server2:$cdrbackdir/$backcdrprefixname$1.zip $scriptdir/temp/$backcdrprefixname$1.$cdr_server2.zip
tput sgr0
}

grepcdrs()
{
cat $scriptdir/temp/* | grep $msisdn > $scriptdir/temp/filteredCDRs_temp.txt
if [ ! -z "$msisdn2" ];then
        cat $scriptdir/temp/filteredCDRs_temp.txt | grep $msisdn2 > $scriptdir/temp/filteredCDRs_temp2.txt
        mv $scriptdir/temp/filteredCDRs_temp2.txt $scriptdir/temp/filteredCDRs_temp.txt
fi
touch $scriptdir/temp/filteredCDRs.txt

for i in {0..23}
do
   j=$(printf %02d $i)
   pattern=$(echo "lgn""$todaydate""$j")
   if [ "$startime" -le "$i" ] && [ "$endtime" -ge "$i" ];then
        getfilteredcdrs=$(cat $scriptdir/temp/filteredCDRs_temp.txt | grep $pattern)
        if [ ! -z "$getfilteredcdrs" ];then
                echo "$getfilteredcdrs" >> $scriptdir/temp/filteredCDRs.txt
        fi
   else
        getfilteredcdrs=$(cat $scriptdir/temp/filteredCDRs_temp.txt | egrep -v $pattern)
                echo "$getfilteredcdrs" > $scriptdir/temp/filteredCDRs_temp.txt
   fi
done
}

smsc_cdrs()
{
smsc_page
tput setaf 5
echo "coping $activecdrname in $scriptdir/temp/ ...................."
tput setaf 4
cp /tango/data/cdr/$activecdrname $scriptdir/temp/
tput setaf 5
echo "coping from $cdr_server2 $activecdrname in $scriptdir/temp/ ...................."
tput setaf 4
scp $cdr_server2:/tango/data/cdr/$activecdrname $scriptdir/temp/active_sms_$cdr_server2.cdr
tput sgr0
get_backcdrs "$today"

if [ ! -z "$days" ]; then
   if [ "$days" -lt 3 ];then
       for ((i=1; i<=$days ; i++ )) ;
       do
               usethisdate=$(date +%Y%m%d -d "$today - $i day")
               get_backcdrs "$usethisdate"
       done
   else
       for ((i=1; i<=2 ; i++ )) ;
       do
               usethisdate=$(date +%Y%m%d -d "$today - $i day")
               get_backcdrs "$usethisdate"
       done
       for ((i=3; i<=$days ; i++ )) ;
       do
               usethisdate=$(date +%Y%m%d -d "$today - $i day")
               get_zipfile "$usethisdate"
       done
                          tput setaf 5
                          echo "Uncompressing all *.zip files ....................."
                          tput setaf 4
                          echo "unzip $scriptdir/temp/*$backcdrprefixname$usethisdate.zip"
                          echo "unzip $scriptdir/temp/*$backcdrprefixname$usethisdate.$cdr_server2.zip*"
                          tput sgr0
  fi
fi

grepcdrs
smsc_parsed_cdr
smsc_cdrmon

}

# Start Script
rm $scriptdir/temp/*


clear
echo ""
mainbanner "                                           _           __   _               _                               " C 97 27 bold
mainbanner "                                          | |         / _| (_)             | |                              " C 97 27 bold
mainbanner "                                 ___    __| |  _ __  | |_   _   _ __     __| |                              " C 97 27 bold
mainbanner "                                / __|  / _  | | '__| |  _| | | | '_ \   / _  |                              " C 97 27 bold
mainbanner "                               | (__  | (_| | | |    | |   | | | | | | | (_| |                              " C 97 27 bold
mainbanner "                                \___|  \__,_| |_|    |_|   |_| |_| |_|  \__,_|                              " C 97 27 bold
mainbanner "" C 97 27
mainbanner "$Sitename" C 97 27 bold
mainbanner "                                                                                          CTRL+C to Cancel   " L 31 27 bold
mainbanner "" C 97 27
mainbanner "" L 94 153
mainbanner_menu_tab "TYPE OF CDRs" "PATTERNS" "DATE/TIME" "FOUND CDRs" 0
mainbanner "" L 34 153
mainbanner "" L 34 153
mainbanner "Select type of CDRs to be searched" L 94 153
mainbanner "1. SMSC" L 94 153
mainbanner "2. USSD" L 94 153
mainbanner "3. SSRV" L 94 153
mainbanner "4. SOM CMC" L 94 153
mainbanner "5. PCC & PCRF" L 94 153
mainbanner "" L 34 153
mainbanner "Enter number [Default $default_mainpage_opt]:" Q 94 153
mainbanner "" L 34 153
mainbanner "" L 34 153
mainbanner "" L 34 153
mainbanner "To exit, enter exit" L 31 153
mainbanner "                                                                                                    " L 94 153 bold underline
mainbanner "Version 0.3.1                                                                 copyright 2017 Tango Telecom Ltd." C 30 153
mainbanner "" L 94 153
echo ""
for i in {0..8};do tput cuu1;done
tput cuf 33
read -e mainpage_opt
check_exit "$mainpage_opt" 0
if [ -z "$mainpage_opt" ];then
        mainpage_opt=$(echo $default_mainpage_opt)
fi
case $mainpage_opt in
        1) smsc_cdrs;;
        2) echo "In construction, bye";;
        3) echo "In construction, bye";;
        4) echo "In construction, bye";;
        5) echo "In construction, bye";;
        exit) exit_page "Bye." 0;exit;;
        Exit) exit_page "Bye." 0;exit;;
        EXIT) exit_page "Bye." 0;exit;;
        *) smsc_cdrs;;
esac