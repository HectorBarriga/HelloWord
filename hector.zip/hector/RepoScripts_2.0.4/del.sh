#!/bin/bash
trash_size=2000000

now=$(perl -e '@d=localtime time(); printf "%4d%02d%02d_%02d%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1]')

checkTrashSize()
{
        getTrashSize=$(du -s /tango/logs/COSTAFF/trash | awk '{print $1}')
        if [ $getTrashSize -gt $trash_size ];then
                echo -e "\n\t\t`tput setaf 2`Trash Space = `tput setaf 1`"100%"`tput sgr0`\n"
        else
                getSizePercentage=$(((getTrashSize * 100) / trash_size))
                echo -e "\n\t\t`tput setaf 2`Trash Space = "$getSizePercentage""%"`tput sgr0`\n"
        fi
        if [ $getTrashSize -gt $trash_size ];then
                echo -e "\n`tput setaf 1`[ALERT] trash has reached 2G size`tput sgr0`\n"
                echo -n "`tput setaf 2`Would you like to empty it now (y/n)? [Default: n] > `tput sgr0`"
                read emptyNow
                echo ""
                if [ "$emptyNow" == "Yes" ] || [ "$emptyNow" == "yes" ] || [ "$emptyNow" == "y" ] || [ "$emptyNow" == "Y" ];then
                        echo "rm -rf /tango/logs/COSTAFF/trash/*"
                        echo "find /tango/logs/COSTAFF/trash/ -type f -name ".*" -delete"
                        rm -rf /tango/logs/COSTAFF/trash/*
                        find /tango/logs/COSTAFF/trash/ -type f -name ".*" -delete
                        echo -e "\n`tput setaf 3`Done, by\n`tput sgr0`"
                        exit
                fi
        fi
}


main()
{
getStar=$(echo "$1" | grep "\*" | wc -l)
fileIn=$(echo "$1" | sed 's/\/$//')

if [ "$getStar" == "0" ];then
        fileDest=$(echo "$fileIn" | awk -F '/' '{print $NF}')
        echo "`tput setaf 3`mv $fileIn /tango/logs/COSTAFF/trash/$fileDest.$now`tput sgr0`"
        mv $fileIn /tango/logs/COSTAFF/trash/$fileDest.$now
else
        while read file
        do
                fileDest=$(echo "$file" | awk -F '/' '{print $NF}')
                echo "`tput setaf 3`mv $file /tango/logs/COSTAFF/trash/$fileDest.$now`tput sgr0`"
                mv $file /tango/logs/COSTAFF/trash/$fileDest.$now
        done < <(ls -altr $fileIn | awk '{print $9}')
fi
}

if [ $# -eq 0 ];then
        echo -e "\n`tput setaf 1`Missing file or directory after del command, bye`tput sgr0`\n"
        exit
fi

checkTrashSize
for fileOrDir in "$@"
do
        main "$fileOrDir"
done