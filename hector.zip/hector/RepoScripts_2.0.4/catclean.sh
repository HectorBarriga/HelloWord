isThereDirPath=$(echo "$1" | grep "/" | wc -l)
if [ ! -z "$1" ] && [ "$isThereDirPath" -eq 0 ];then
        if [ ! -f "$1" ];then
                echo "cat: $1 No such file or directory"
        else
                pwd=$(pwd)
                cat "$pwd/$1" | cut -d'#' -f1 | awk 'NF>0' | sed '/^[[:space:]]*$/d'
        fi
elif [ ! -z "$1" ] || [ "$isThereDirPath" -ne 0 ];then
        cat "$1" | cut -d'#' -f1 | awk 'NF>0' | sed '/^[[:space:]]*$/d'
else
        echo -e "\n`tput setaf 1`Sorry, you need to enter file, cat file.txt, bye.\n`tput sgr0`"
fi