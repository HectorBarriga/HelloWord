#!/bin/bash

# Flags and Mode
while getopts s:n:d:h option;
do
        case $option in
                s) DELAY_BETWEEN_FILES=$OPTARG;;
                n) CDR_NAME_PREFIX=$OPTARG;;
                d) CDR_ARCHIVE_DIR_NAME=$OPTARG;;
                h) echo "
        Usage: indices_recovery.sh


        Revision:    0.1.0
        Author:      Hector Barriga


               Options:

               -h <help>                Show help

               -s <sleep>               Delay after a cdr file is moved to archive directory

               -n <CDR Name prefix>     Run ls -altr /tango/data/cdr/xxx to get the CDR rollover name prefix

               -d <CDR rollover dir>     Run ls -altr /tango/data/cdr to get the CDR rollover directory
               "; h="true";;
        esac
done


#################### healthchcek normal#################
if [ "$h" != "true" ];then

if [ -z $DELAY_BETWEEN_FILES ];then DELAY_BETWEEN_FILES=1;fi
if [ -z $CDR_NAME_PREFIX ];then CDR_NAME_PREFIX="USSD_SI_production";fi
if [ -z $CDR_ARCHIVE_DIR_NAME ];then CDR_ARCHIVE_DIR_NAME="USSD_SI_production";fi

ls -altr /tango/data/cdr/$CDR_ARCHIVE_DIR_NAME/archive/
echo -e -n "\n`tput setaf 3`Enter archived zip file [To skip, enter no] > `tput sgr0`"
read  zipFile
i=0

if [ ! -d /tango/logs/COSTAFF/hector/INDICES_RECOVERY/ ];then
        mkdir -p /tango/logs/COSTAFF/hector/INDICES_RECOVERY/
fi
if [ $(ls -A /tango/data/cdr/$CDR_ARCHIVE_DIR_NAME/archive/RECOVERY/ | wc -l) -gt 0 ];then
        rm /tango/data/cdr/$CDR_ARCHIVE_DIR_NAME/archive/RECOVERY/*
fi
if [ "$zipFile" != "no" ] && [ ! -z "$zipFile" ];then
        cp /tango/data/cdr/$CDR_ARCHIVE_DIR_NAME/archive/$zipFile /tango/logs/COSTAFF/hector/INDICES_RECOVERY/
        cd /tango/logs/COSTAFF/hector/INDICES_RECOVERY/
        unzip /tango/logs/COSTAFF/hector/INDICES_RECOVERY/$zipFile
        rm /tango/logs/COSTAFF/hector/INDICES_RECOVERY/$zipFile
fi
totalList=$(ls -altr /tango/logs/COSTAFF/hector/INDICES_RECOVERY/ | grep $CDR_NAME_PREFIX | awk "{print \$9}" | wc -l)
ls -altr /tango/logs/COSTAFF/hector/INDICES_RECOVERY/ | grep $CDR_NAME_PREFIX | awk '{print $9}' | while read in
do
        mv /tango/logs/COSTAFF/hector/INDICES_RECOVERY/$in /tango/data/cdr/$CDR_ARCHIVE_DIR_NAME/archive/RECOVERY/
        echo -n "mv /tango/logs/COSTAFF/hector/INDICES_RECOVERY/$in /tango/data/cdr/$CDR_ARCHIVE_DIR_NAME/archive/RECOVERY/"
        percentageProgress=$((100 * $i / $totalList))
        echo " `tput setaf 2`$percentageProgress%`tput sgr0`"
        i=$((i+1))
        sleep $DELAY_BETWEEN_FILES
done

fi