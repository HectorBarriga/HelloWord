#!/bin/bash
##############################################################################
# Filename:    OSAndTangoSW_SystemBackup.sh
# Revision:    $Revision: 0.1.0 $
# Author:      Hector Barriga
#
# Jiras:
# CO Scripts:  COSC-96
# CO Internal: COIT-15435
#
# This sh script is to take HEALTHY backups of the following:
# 1. Tango Software configurations
# 2. Importantant OS directories
# 3. Capture current OS and Tango SoftWare status
#
# This sh script is mainly used for housekeeping.
# Copyright (c) Tango Telecom 2017
#
# All rights reserved.
# This document contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or
# in part is expressly prohibited, except as may be specifically
# authorized by prior written agreement or permission of Tango Telecom.
##############################################################################
# version 0.1.0 - First version
#
##############################################################################

# Initial Arguments
dryRun=0
today=$(perl -e '@d=localtime time(); printf "%4d%02d%02d\n", $d[5]+1900,$d[4]+1,$d[3]')
todate=$(perl -e '@d=localtime time(); printf "%4d%02d%02d_%02d%02d%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1],$d[0]')
timenow=$(perl -e '@d=localtime time(); printf "%4d%02d%02d %02d:%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1]')
lognow=$(perl -e '@d=localtime time(); printf "%4d-%02d-%02d\n", $d[5]+1900,$d[4]+1,$d[3]')
amiroot=$(whoami)
hostname=$(hostname)
spawnFilesh="spawn_ProcessVersion.sh"
red=`tput setaf 1`
green=`tput setaf 2`
yellow=`tput setaf 3`
pink=`tput setaf 5`
blue=`tput setaf 6`
reset=`tput sgr0`

# Subroutines

printhelp()
{
echo "
${green}Usage: OSAndTangoSW_SystemBackup${reset}

Jiras:
CO Scripts:  COSC-xxx
CO Internal: COIT-xxxxx

This sh script is to take HEALTHY backups of the following:
1. Tango Software configurations
2. Importantant OS directories
3. Capture current OS and Tango SoftWare status

Copyright (c) Tango Telecom 2016
Author: Hector Barriga

All rights reserved.
This document contains confidential and proprietary information of
Tango Telecom and any reproduction, disclosure, or use in whole or
in part is expressly prohibited, except as may be specifically
authorized by prior written agreement or permission of Tango Telecom.

Version 0.1.0


               Options:

               -c <config file>         Config File that contains all script configurable parameters
                                        It is important to include directory path

               -h <help>                Show help


               ${yellow}Crontab Job Exmaple:
               10 22 * * * /tango/scripts/Generic/Others/OSAndTangoSWSystemBackup/OSAndTangoSW_SystemBackup.sh -c /tango/scripts/Generic/Others/OSAndTangoSWSystemBackup/OSAndTangoSW_SystemBackup.cfg /dev/null 2>&1${reset}
               "
exit
}

printLog()
{
if [ `echo "$log_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$log_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
        newlogFile=$(echo $logFile | cut -d. -f1)
        logExt=$(echo $logFile | cut -d. -f2)
        if [ "$1" == "cleanlog" ];then
                echo -e "$2" >> $logDir/$newlogFile.$lognow.$logExt
        else
                echo -e "[ $timenow ] $1 $2" >> $logDir/$newlogFile.$lognow.$logExt
        fi
fi
}

initChecks()
{
if [ "$createTempDirFlag" == "yes" ];then
        printLog "cleanlog" ""
        printLog "cleanlog" ""
        printLog "cleanlog" "##################################### Start Backup process #####################################"
        printLog "------------------- Initial Checks --------------------------"
        printLog "cleanlog" "Creating $logDir/ and $DIR/temp directories because they didnt exist"
else
        printLog "cleanlog" ""
        printLog "cleanlog" ""
        printLog "[INFO]" "##################################### Start Backup process #####################################"
        printLog "------------------- Initial Checks --------------------------"
        printLog "[INFO]" "$logDir and $DIR/temp directories exist. Ok"
fi
if [ ! -d "/tango/data/archive/" ];then
        echo -e "\n${red}Sorry, /tango/data/archive/ doesn't exist, you must create it first. Bye\n${reset}"
        printLog "[ERROR]" "/tango/data/archive/ doesn't exist, you must create it first. Bye"
        exit
else
        printLog "[INFO]" "/tango/data/archive/  exists. Ok"
fi
if [ "$amiroot" != "root" ];then
        echo -e "\n${red}Sorry, you must run this script as \"root\" user. Bye\n${reset}"
        printLog "[ERROR]" "you must run this script as \"root\" user. Bye"
        exit
else
        printLog "[INFO]" "Running script as \"root\" user. Ok"
fi
}

getParameters()
{
config_file=$DIR/temp/tmp.file
oldIFS="$IFS"
IFS=":"
while read name value
do
    eval $name="$value"
done < $config_file
IFS="$oldIFS"
}

getParametersFromConfigFile()
{

#---------------------------------------------------------------
# If it doesnt exist, create temp directory in where all temporal important files will be stored temporarely
#--------------------------------------------------------------
DIR=$(cat $config_in | tr -d " \t\r" | grep logDir | cut -d"#" -f1 | cut -d= -f2)
if [ ! -d "$DIR/temp" ];then
        mkdir -p $DIR/temp
        createTempDirFlag="yes"
else
        createTempDirFlag="no"
fi

#---------------------------------------------------------------
# get [General] Paramenters from OSAndTangoSW_SystemBackup.cfg
#--------------------------------------------------------------
sed -n '/\[General]/,/\[/p' $config_in | awk  '!/\[General]/ && !/\[/' | tr -d " \t\r" | awk '/log_enable/ || /logDir/ || /logFile/ || /BackupFileName/' | cut -d"#" -f1 | sed "s/=/:/g" > $DIR/temp/tmp.file
getParameters
initChecks
printLog "------------------- Get Parameters --------------------------"
printLog "[INFO]" "General:\nlog_enable=$log_enable\nlogDir=$logDir\nlogFile=$logFile\nBackupFileName=$BackupFileName"

#---------------------------------------------------------------
# get [Use Percona XtraBackup] Paramenters from OSAndTangoSW_SystemBackup.cfg
#--------------------------------------------------------------
sed -n '/\[Use Percona XtraBackup]/,/\[/p' $config_in | awk  '!/\[Use Percona XtraBackup]/ && !/\[/' | tr -d " \t\r" | awk '/enable/ || /SubDirectoryName/ || /user/ || /password/ || /FullBackupFrequency/ || /IncrementalBackupFrequency/' | cut -d"#" -f1 | sed "s/=/:/g" > $DIR/temp/tmp.file
getParameters
perconaxtrabackup_enable=$(echo "$enable")
printLog "[INFO]" "Use Percona XtraBackup:\nenable=$enable\nSubDirectoryName=$SubDirectoryName\nuser=$user\nFullBackupFrequency=$FullBackupFrequency\nIncrementalBackupFrequency=$IncrementalBackupFrequency"

#---------------------------------------------------------------
# get [use MySQL mysqldump] Paramenters from OSAndTangoSW_SystemBackup.cfg
#--------------------------------------------------------------
sed -n '/\[use MySQL mysqldump]/,/\[/p' $config_in | awk  '!/\[use MySQL mysqldump]/ && !/\[/' | tr -d " \t\r" | awk '/enable/ || /user/ || /password/ || /databases/ || /Frequency/' | cut -d"#" -f1 | sed "s/=/:/g" > $DIR/temp/tmp.file
getParameters
getDay_FromFrequency "$Frequency"
mysql_Frequency="$Frequency"
if [ "$BackupEnabled" == "yes" ];then
        mysqldump_enable=$(echo "$enable")
else
        mysqldump_enable="no"
fi
printLog "[INFO]" "use MySQL mysqldump:\nenable=$enable\nmysqldump_enable=$mysqldump_enable\nuser=$user\npassword=$password\nmysql_Frequency=$mysql_Frequency"
mysqlDatabasesArray=(`echo ${databases} | sed 's/,/ /g'`)
mysqlDatabasesArrayLength=${#mysqlDatabasesArray[@]}
printLog "cleanlog" "mysqlDatabasesArrayLength=$mysqlDatabasesArrayLength"
for (( j=0;j<$mysqlDatabasesArrayLength;j++))
do
        printLog "cleanlog" "mysqlDatabases[$j]=${mysqlDatabasesArray[$j]}"
done

#---------------------------------------------------------------
# get [Elastic Search] Paramenters from OSAndTangoSW_SystemBackup.cfg
#--------------------------------------------------------------
sed -n '/\[Elastic Search]/,/\[/p' $config_in | awk  '!/\[Elastic Search]/ && !/\[/' | tr -d " \t\r" | awk '/enable/ || /Frequency/' | cut -d"#" -f1 | sed "s/=/:/g" > $DIR/temp/tmp.file
getParameters
getDay_FromFrequency "$Frequency"
ES_Frequency="$Frequency"
if [ "$BackupEnabled" == "yes" ];then
        ES_enable=$(echo "$enable")
else
        ES_enable="no"
fi
printLog "[INFO]" "Elastic Search:\nenable=$enable\nES_enable=$ES_enable\nES_Frequency=$ES_Frequency"

#---------------------------------------------------------------
# get [Directories To Get Backed Up]  Paramenters from OSAndTangoSW_SystemBackup.cfg
#--------------------------------------------------------------
sed -n '/\[tomcat]/,/\[/p' $config_in | awk  '!/\[tomcat]/ && !/\[/' | tr -d " \t\r" | awk '/enable/ || /BackupDirectory/ || /Frequency/' | cut -d"#" -f1 | sed "s/=/:/g" > $DIR/temp/tmp.file
getParameters
getDay_FromFrequency "$Frequency"
tomcat_Frequency="$Frequency"
if [ "$BackupEnabled" == "yes" ];then
        tomcat_enable=$(echo "$enable")
else
        tomcat_enable="no"
fi
printLog "[INFO]" "tomcat:\nenable=$enable\ntomcat_enable=$tomcat_enable\ntomcat_Frequency=$tomcat_Frequency"
tomcatBackupDirectoryArray=(`echo ${BackupDirectory} | sed 's/,/ /g'`)
tomcatBackupDirectoryArrayLength=${#tomcatBackupDirectoryArray[@]}
printLog "cleanlog" "tomcatBackupDirectoryArrayLength=$tomcatBackupDirectoryArrayLength"
for (( j=0;j<$tomcatBackupDirectoryArrayLength;j++))
do
        printLog "cleanlog" "tomcatBackupDirectory[$j]=${tomcatBackupDirectoryArray[$j]}"
done


#---------------------------------------------------------------
# get [Especial directories]  Paramenters from OSAndTangoSW_SystemBackup.cfg
#--------------------------------------------------------------
sed -n '/\[Backup Especial Directories]/,/\[/p' $config_in | awk  '!/\[Backup Especial Directories]/ && !/\[/' | tr -d " \t\r" | awk '/enable/ || /Directories/ || /Frequency/' | cut -d"#" -f1 | sed "s/=/:/g" > $DIR/temp/tmp.file
getParameters
getDay_FromFrequency "$Frequency"
EspecialDir_Frequency="$Frequency"
if [ "$BackupEnabled" == "yes" ];then
        EspecialDir_enable=$(echo "$enable")
else
        EspecialDir_enable="no"
fi
printLog "[INFO]" "Backup Especial directories:\nenable=$enable\nEspecialDir_enable=$EspecialDir_enable\nEspecialDir_Frequency=$EspecialDir_Frequency"
EspecialDirArray=(`echo ${Directories} | sed 's/,/ /g'`)
EspecialDirArrayLength=${#EspecialDirArray[@]}
printLog "cleanlog" "EspecialDirArrayLength=$EspecialDirArrayLength"
for (( j=0;j<$EspecialDirArrayLength;j++))
do
        printLog "cleanlog" "EspecialDir[$j]=${EspecialDirArray[$j]}"
done

#---------------------------------------------------------------
# get [Operative System]  Paramenters from OSAndTangoSW_SystemBackup.cfg
#--------------------------------------------------------------
sed -n '/\[Operative System]/,/\[/p' $config_in | awk  '!/\[Operative System]/ && !/\[/' | tr -d " \t\r" | awk '/enable/ || /IncludeusrDirectory/ || /Frequency/' | cut -d"#" -f1 | sed "s/=/:/g" > $DIR/temp/tmp.file
getParameters
getDay_FromFrequency "$Frequency"
OS_Frequency="$Frequency"
if [ "$BackupEnabled" == "yes" ];then
       OS_enable=$(echo "$enable")
else
       OS_enable="no"
fi
printLog "[INFO]" "Operative System:\nenable=$enable\nOS_enable=$OS_enable\nIncludeusrDirectory=$IncludeusrDirectory\nOS_Frequency=$OS_Frequency"

#---------------------------------------------------------------
# get [Tango SW]  Paramenters from OSAndTangoSW_SystemBackup.cfg
#--------------------------------------------------------------
sed -n '/\[Tango SW]/,/\[/p' $config_in | awk  '!/\[Tango SW]/ && !/\[/' | tr -d " \t\r" | awk '/enable/ || /Includebinaries/ || /IncludeServiceInterpreter/ || /ServiceInterpreterports/ || /IncludeSMPP_router/ || /SMPP_routerports/ || /Includesigtran/ || /M3UAports/ || /Frequency/' | cut -d"#" -f1 | sed "s/=/:/g" > $DIR/temp/tmp.file
getParameters
getDay_FromFrequency "$Frequency"
tangoSW_Frequency="$Frequency"
if [ "$BackupEnabled" == "yes" ];then
       tangoSW_enable=$(echo "$enable")
else
       tangoSW_enable="no"
fi
printLog "[INFO]" "Tango SW:\nenable=$enable\ntangoSW_enable=$tangoSW_enable\nIncludebinaries=$Includebinaries\nIncludeServiceInterpreter=$IncludeServiceInterpreter\nIncludeSMPP_router=$IncludeSMPP_router\nIncludesigtran=$Includesigtran\ntangoSW_Frequency=$tangoSW_Frequency"
SIportArray=(`echo ${ServiceInterpreterports} | sed 's/,/ /g'`)
SIportArrayLength=${#SIportArray[@]}
printLog "cleanlog" "SIportArrayLength=$SIportArrayLength"
for (( j=0;j<$SIportArrayLength;j++))
do
        printLog "cleanlog" "SIport[$j]=${SIportArray[$j]}"
done

SMPP_routerportArray=(`echo ${SMPP_routerports} | sed 's/,/ /g'`)
SMPP_routerportArrayLength=${#SMPP_routerportArray[@]}
printLog "cleanlog" "SMPP_routerportArrayLength=$SMPP_routerportArrayLength"
for (( j=0;j<$SMPP_routerportArrayLength;j++))
do
        printLog "cleanlog" "SMPP_routerport[$j]=${SMPP_routerportArray[$j]}"
done

M3UAportArray=(`echo ${M3UAports} | sed 's/,/ /g'`)
M3UAportArrayLength=${#M3UAportArray[@]}
printLog "cleanlog" "M3UAportArrayLength=$M3UAportArrayLength"
for (( j=0;j<$M3UAportArrayLength;j++))
do
        printLog "cleanlog" "M3UAports[$j]=${M3UAportArray[$j]}"
done
}


getDay_FromFrequency()
{
BackupEnabled="no"
if [ "$1" == "daily" ];then
        BackupEnabled="yes"
elif [ "$1" == "weekly" ];then
        MonStr=$(date +"%a")
        if [ "$MonStr" == "Mon" ];then
                BackupEnabled="yes"
        fi
elif [ "$1" == "fortnightly" ];then
        dayStr=$(date +"%d")
        if [ "$dayStr" == "29" ] || [ "$dayStr" == "14" ];then
                BackupEnabled="yes"
        fi
elif [ "$1" == "monthly" ];then
        dayStr=$(date +"%d")
        if [ "$dayStr" == "01" ];then
                BackupEnabled="yes"
        fi
fi
}


# Flags
while getopts c:h option;
do
        case $option in
                c) config_in=$OPTARG;;
                h) printhelp;;
        esac
done
if [ -z "$config_in" ];then
        echo -e "\n${red}Sorry, You must include -c flag with config file. ${yellow}Run ./OSAndTangoSW_SystemBackup.sh -h${red} Bye\n${reset}"
        exit
fi


# Script Main()
getParametersFromConfigFile

#--- Create backup directories ---
backupSubDir="/tango/data/archive/$BackupFileName.$hostname.$today/$BackupFileName.$todate/"
backupDir="/tango/data/archive/$BackupFileName.$hostname.$today"
if [ -f "$backupDir.tar" ];then
        cd /tango/data/archive/
        tar -xf $backupDir.tar
        printLog "[INFO]" "$backupDir.tar already exists. Hence, I am untaring it"
fi
mkdir -p $backupSubDir
cd $backupSubDir
printLog "--------------------- Creating Backup Directory ------------------------"
printLog "[INFO]" "Creating $backupSubDir"


#####################################################
######## Start 3rd Party SW  backups ################
#####################################################
printLog "------------------- Genearting 3rd Party SW Backups --------------------"

#--- Get list of tomcat webapps ---
if [ `echo "$tomcat_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$tomcat_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
  for (( j=0;j<$tomcatBackupDirectoryArrayLength;j++))
  do
        if [ ! -d "${tomcatBackupDirectoryArray[$j]}" ];then
                echo -e "\n${red}Sorry, tomcat is not installed. Configure ${yellow}./OSAndTangoSW_SystemBackup.cfg ${red}correctly and try again, Bye\n${reset}"
                printLog "[ERROR]" "${tomcatBackupDirectoryArray[$j]} doesnt exist. Configure /OSAndTangoSW_SystemBackup.cfg correctly and try again, Bye"
                exit
        fi
        backupFilePrefix=$(echo "${tomcatBackupDirectoryArray[$j]}" | cut -d"/" -f4)
        webappsList=$(ls -altr ${tomcatBackupDirectoryArray[$j]}/webapps/)
        echo "$webappsList" > $backupSubDir/$backupFilePrefix.webapps_$hostname.$todate.txt
        printLog "[INFO]" "Generate $backupFilePrefix.webapps_$hostname.$todate.txt"
        cp -rfp ${tomcatBackupDirectoryArray[$j]}/logs/catalina.out $backupSubDir/$backupFilePrefix.catalinaOutLogs.$hostname.$todate.txt
        printLog "[INFO]" "Backup $backupFilePrefix.catalinaOutLogs.$hostname.$todate.txt"
        warFiles=$(echo "$webappsList" | grep war | egrep -v grep | awk '{print $9}')
        if [ ! -z "$warFiles" ];then
                echo "$warFiles" | while read warList
                do
                        cp -rfp ${tomcatBackupDirectoryArray[$j]}/webapps/$warList $backupSubDir/
                        printLog "[INFO]" "Backup ${tomcatBackupDirectoryArray[$j]}/webapps/$warList"
                getWarName=$(echo "$warList" | cut -d"." -f1)
                isTherePMI=$(echo "$warList" | grep -i pmi | egrep -v grep)
                if [ ! -z $isTherePMI ];then
                        cat ${tomcatBackupDirectoryArray[$j]}/webapps/$getWarName/WEB-INF/classes/ApplicationResources.properties | grep "webapp.version" > $backupSubDir/$getWarName.$backupFilePrefix.version_$hostname.$todate.txt
                else
                        getPomProperties=$(find ${tomcatBackupDirectoryArray[$j]}/webapps/$getWarName/ -name pom.properties)
                        cat $getPomProperties  > $backupSubDir/$getWarName.$backupFilePrefix.version_$hostname.$todate.txt
                fi
                printLog "[INFO]" "Generate  $getWarName.$backupFilePrefix.version_$hostname.$todate.txt"
                done
        else
                printLog "[INFO]" "No war files to backup in ${tomcatBackupDirectoryArray[$j]}/webapps/"
        fi
  done
else
        printLog "[INFO]" "Tomcat backups disabled"
fi

#---- Get Database Full Base Backup via Percona XtraBackup--
printLog "------ Genearting databases Backups via Percona XtraBackup ----------"
if [ `echo "$perconaxtrabackup_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$mysqldump_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
if [ ! -f "/usr/bin/mysql" ];then
        echo -e "\n${red}Sorry, Percona (MySQL) is not running on this machine. Configure ${yellow}./OSAndTangoSW_SystemBackup.cfg ${red}correctly and try again, Bye\n${reset}"
        printLog "[ERROR]" " Percona (MySQL) is not running on this machine. Configure /OSAndTangoSW_SystemBackup.cfg correctly and try again, Bye"
        exit
fi
if  [ ! -d "/tango/data/archive/$SubDirectoryName/" ];then
        mkdir /tango/data/archive/$SubDirectoryName/
        printLog "[INFO]" "/tango/data/archive/$SubDirectoryName/ didnt exist. Im creating it now. Its ok"
        isThereMysqlDir="no"
else
        isThereMysqlDir="yes"
fi

if  [ ! -d "/tango/data/archive/OLD_$SubDirectoryName/" ];then
        mkdir /tango/data/archive/OLD_$SubDirectoryName/
        printLog "[INFO]" "/tango/data/archive/OLD_$SubDirectoryName/ didnt exist. Im creating it now. Its ok"
fi

getDay_FromFrequency "$FullBackupFrequency"
if [ "$BackupEnabled" == "yes" ] || [ "$isThereMysqlDir" == "no" ];then
        if [ -f "/tango/data/archive/OLD_$SubDirectoryName/$SubDirectoryName.OLD.$today.tar" ];then
                echo -e "\n${red}Sorry, /tango/data/archive/OLD_$SubDirectoryName/$SubDirectoryName.OLD.$today.tar already exists. Only one full backup per day, remove that directory manually. Bye\n${reset}"
                printLog "[ERROR]" "/tango/data/archive/OLD_$SubDirectoryName/$SubDirectoryName.OLD.$today.tar already exists. Only one full backup per day, remove that directory manually. Bye"
        fi

        mv /tango/data/archive/$SubDirectoryName/ /tango/data/archive/OLD_$SubDirectoryName/$SubDirectoryName.OLD.$today/
        tar -cf /tango/data/archive/OLD_$SubDirectoryName/$SubDirectoryName.OLD.$today.tar  --remove-files /tango/data/archive/OLD_$SubDirectoryName/$SubDirectoryName.OLD.$today -P
        printLog "[INFO]" "Yes!! a new Full base backup is to be taken today. Moving and compressing OLD Full and its incremental backups to get a new fresh full and incremental backups. $SubDirectoryName.OLD.$today.tar"

        mkdir /tango/data/archive/$SubDirectoryName/
        /usr/bin/xtrabackup --user=$user --password=$password --backup --target-dir=/tango/data/archive/$SubDirectoryName/FULL_DATABASE_BACKUP_base/ &>/dev/null
        printLog "[INFO]" "Creating Base Full Backup = /usr/bin/xtrabackup --user=$user --password=$password --backup --target-dir=/tango/data/archive/$SubDirectoryName/FULL_DATABASE_BACKUP_base/"
        checkpointsFromLNS=$(cat /tango/data/archive/$SubDirectoryName/FULL_DATABASE_BACKUP_base/xtrabackup_checkpoints | grep from_lsn | egrep -v grep)
        checkpointsToLNS=$(cat /tango/data/archive/$SubDirectoryName/FULL_DATABASE_BACKUP_base/xtrabackup_checkpoints | grep to_lsn | egrep -v grep)
        printLog "[INFO]" "checkpoints:\nfrom_lsn=$checkpointsFromLNS\nto_lsn=$checkpointsToLNS"
        /usr/bin/xtrabackup --user=$user --password=$password --backup --target-dir=/tango/data/archive/$SubDirectoryName/LAST_TODAY-Incremental.$hostname.$todate/ --incremental-basedir=/tango/data/archive/$SubDirectoryName/FULL_DATABASE_BACKUP_base/ &>/dev/null
        printLog "[INFO]" "Creating First Incremental Backup = /usr/bin/xtrabackup --user=$user --password=$password --backup --target-dir=/tango/data/archive/$SubDirectoryName/LAST_TODAY-Incremental.$hostname.$todate/ --incremental-basedir=/tango/data/archive/$SubDirectoryName/FULL_DATABASE_BACKUP_base/"
        checkpointsFromLNS=$(cat /tango/data/archive/$SubDirectoryName/LAST_TODAY-Incremental.*/xtrabackup_checkpoints | grep from_lsn | egrep -v grep)
        checkpointsToLNS=$(cat /tango/data/archive/$SubDirectoryName/LAST_TODAY-Incremental.*/xtrabackup_checkpoints | grep to_lsn | egrep -v grep)
        printLog "[INFO]" "checkpoints:\nfrom_lsn=$checkpointsFromLNS\nto_lsn=$checkpointsToLNS"
        FullBackupAndIncAlreadyTaken="true"

        cd /tango/data/archive/$SubDirectoryName/
        tar -cf FULL_DATABASE_BACKUP_base.$hostname.$today.tar --remove-files FULL_DATABASE_BACKUP_base -P
        chown tango:tango /tango/data/archive/$SubDirectoryName/FULL_DATABASE_BACKUP_base.$hostname.$today.tar
        printLog "[INFO]" "Compress FULL_DATABASE_BACKUP_base.$hostname.$today.tar"
        tar -cf LAST_TODAY-Incremental.$hostname.$todate.tar --remove-files LAST_TODAY-Incremental.$hostname.$todate -P
        chown tango:tango /tango/data/archive/$SubDirectoryName/LAST_TODAY-Incremental.$hostname.$todate.tar
        printLog "[INFO]" "Compress LAST_TODAY-Incremental.$hostname.$todate.tar"

else
        printLog "[INFO]" "Percona XtraBackup Full Base  Backup wont be taken today since FullBackupFrequency is $FullBackupFrequency"
fi

getDay_FromFrequency "$IncrementalBackupFrequency"
if [ "$BackupEnabled" == "yes" ] && [ "$FullBackupAndIncAlreadyTaken" != "true" ];then
        cd /tango/data/archive/$SubDirectoryName/
        FullBackupAndIncAlreadyTaken="false"
        getLastIncrementalTar=$(ls -alrt /tango/data/archive/$SubDirectoryName/ | grep LAST | awk '{print $9}')
        tar -xf $getLastIncrementalTar -P
        rm $getLastIncrementalTar
        getLastIncrementalDir=$(ls -alrt /tango/data/archive/$SubDirectoryName/ | grep LAST | awk '{print $9}')
        RenameLastIncrementalDirName=$(ls -alrt /tango/data/archive/$SubDirectoryName/ | grep LAST | awk '{print $9}' | cut -d"-" -f2)
        mv /tango/data/archive/$SubDirectoryName/$getLastIncrementalDir /tango/data/archive/$SubDirectoryName/$RenameLastIncrementalDirName
        printLog "[INFO]" "Renaming  directory = mv /tango/data/archive/$SubDirectoryName/$getLastIncrementalDir /tango/data/archive/$SubDirectoryName/$RenameLastIncrementalDirName"
        /usr/bin/xtrabackup --user=$user --password=$password --backup --target-dir=/tango/data/archive/$SubDirectoryName/LAST_TODAY-Incremental.$hostname.$todate/ --incremental-basedir=/tango/data/archive/$SubDirectoryName/$RenameLastIncrementalDirName/ &>/dev/null
        printLog "[INFO]" "Creating a new Incremental Backup = /usr/bin/xtrabackup --user=$user --password=$password --backup --target-dir=/tango/data/archive/$SubDirectoryName/LAST_TODAY-Incremental.$hostname.$todate/ --incremental-basedir=/tango/data/archive/$SubDirectoryName/$RenameLastIncrementalDirName/"
        checkpointsFromLNS=$(cat /tango/data/archive/$SubDirectoryName/LAST_TODAY-Incremental*/xtrabackup_checkpoints | grep from_lsn | egrep -v grep)
        checkpointsToLNS=$(cat /tango/data/archive/$SubDirectoryName/LAST_TODAY-Incremental*/xtrabackup_checkpoints | grep to_lsn | egrep -v grep)
        printLog "[INFO]" "checkpoints:\nfrom_lsn=$checkpointsFromLNS\nto_lsn=$checkpointsToLNS"

        cd /tango/data/archive/$SubDirectoryName/
        tar -cf /tango/data/archive/$SubDirectoryName/$RenameLastIncrementalDirName.tar --remove-files /tango/data/archive/$SubDirectoryName/$RenameLastIncrementalDirName -P
        chown tango:tango /tango/data/archive/$SubDirectoryName/$RenameLastIncrementalDirName.tar
        printLog "[INFO]" "Compress $RenameLastIncrementalDirName.tar"
        tar -cf /tango/data/archive/$SubDirectoryName/LAST_TODAY-Incremental.$hostname.$todate.tar --remove-files /tango/data/archive/$SubDirectoryName/LAST_TODAY-Incremental.$hostname.$todate -P
        chown tango:tango /tango/data/archive/$SubDirectoryName/LAST_TODAY-Incremental.$hostname.$todate.tar
        printLog "[INFO]" "Compress LAST_TODAY-Incremental.$hostname.$todate.tar"

else
        printLog "[INFO]" "Percona XtraBackup Incremental  Backup wont be taken today either becouse IncrementalBackupFrequency is $IncrementalBackupFrequency or FullBackupAndIncAlreadyTaken is true"
fi

else
        printLog "[INFO]" "Percona XtraBackup backups disabled"
fi


#---- Get Database Dumps --

printLog "------------ Genearting databases Backups via mysqldump ------------------"
if [ `echo "$mysqldump_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$mysqldump_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
if [ ! -f "/usr/bin/mysql" ];then
        echo -e "\n${red}Sorry, MySQL is not running on this machine. Configure ${yellow}./OSAndTangoSW_SystemBackup.cfg ${red}correctly and try again, Bye\n${reset}"
        printLog "[ERROR]" " MySQL is not running on this machine. Configure /OSAndTangoSW_SystemBackup.cfg correctly and try again, Bye"
        exit
fi
echo "show slave status\G;" | /usr/bin/mysql -u $user -p$password > $backupSubDir/slave_status_$hostname.$todate.txt
printLog "[INFO]" "Generate slave_status_$hostname.$todate.txt"
echo "show master status\G;" | /usr/bin/mysql -u $user -p$password > $backupSubDir/master_status_$hostname.$todate.txt
printLog "[INFO]" "Generate master_status_$hostname.$todate.txt"
getDatabasesList=$(echo "show databases;" | /usr/bin/mysql -u $user -p$password)
echo "$getDatabasesList" > $backupSubDir/databases_$hostname.$todate.txt
printLog "[INFO]" "Generate databases_$hostname.$todate.txt"


#--- mysql version, stored procedures(ROUTINES), users and all grants (privilages) ---
/usr/bin/mysql --version > $backupSubDir/mysql_version_$hostname.$todate.txt
printLog "[INFO]" "Generate mysql_version_$hostname.$todate.txt"
echo "select * from ROUTINES\G;" | /usr/bin/mysql -u $user -p$password information_schema > $backupSubDir/ROUTINES_$hostname.$todate.txt
printLog "[INFO]" "Generate ROUTINES_$hostname.$todate.txt"
echo "select * from user;" | /usr/bin/mysql -u $user -p$password mysql > $backupSubDir/mysql_user_$hostname.$todate.txt
printLog "[INFO]" "Generate mysql_user_$hostname.$todate.txt"
echo "SELECT User, Host,authentication_string FROM mysql.user;" | /usr/bin/mysql -u $user -p$password mysql > $backupSubDir/mysql_user_host_password_$hostname.$todate.txt
printLog "[INFO]" "Generate mysql_user_host_password_$hostname.$todate.txt"
echo "SELECT * FROM information_schema.user_privileges;" | /usr/bin/mysql -u $user -p$password > $backupSubDir/information_schema_user_privileges_$hostname.$todate.txt
printLog "[INFO]" "Generate information_schema_user_privileges_$hostname.$todate.txt"
showgrantsList=$(echo "SELECT CONCAT('SHOW GRANTS FOR ''',user,'''@''',host,''';') FROM mysql.user;" | /usr/bin/mysql -u $user -p$password)
echo "$showgrantsList" > $backupSubDir/List_of_SHOWGRANTSFOR_$hostname.$todate.txt
echo "$showgrantsList" | while read in; do echo "------------"; echo "$in" | /usr/bin/mysql -u $user -p$password; done > $backupSubDir/GRANTS_commands_$hostname.$todate.txt
printLog "[INFO]" "Generate GRANTS_commands_$hostname.$todate.txt"

#DONT WORRY ABOUT THIS ERROR
# ERROR 1064 (42000) at line 1: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'CONCAT('SHOW GRANTS FOR ''',user,'''@''',host,''';')' at line 1

#----Dump all databases: (Dont worry about the warnings, ignore them. They are just mysql 5.7 harmless warnings)----
for (( j=0;j<$mysqlDatabasesArrayLength;j++))
do
        /usr/bin/mysqldump -u root -pt3il3achum --routines ${mysqlDatabasesArray[$j]} > ${mysqlDatabasesArray[$j]}.$hostname.$todate.dump
        printLog "[INFO]" "Generate ${mysqlDatabasesArray[$j]}.$hostname.$todate.dump"
done

printLog "----------------- Get imortant Files -------------------"
ls -altr /tango/data/mysql > $backupSubDir/tango_data_mysql_files_$hostname.$todate.txt
printLog "[INFO]" "Generate tango_data_mysql_files_$hostname.$todate.txt"

#--- Backup my.cnf ---
cp -rfp /etc/my.cnf $backupSubDir/my.cnf.$hostname.$todate.txt
printLog "[INFO]" "Backup my.cnf.$hostname.$todate.txt"

else
        printLog "[INFO]" "MySQL mysqldump backups disabled"
fi


########################################################
############## Elastic Search ##########################
########################################################
if [ `echo "$ES_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$ES_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then

curl -u elastic:t3il3achum 172.19.1.52:9201/_cluster/health?pretty &> $backupSubDir/curl_cluster_health_pretty_$hostname.$todate.txt
printLog "[INFO]" "Generate curl_cluster_health_pretty_$hostname.$todate.txt"
curl -XGET -u elastic:t3il3achum '172.19.1.52:9202/_cat/indices' &> $backupSubDir/curl_cat_indices_$hostname.$todate.txt
printLog "[INFO]" "Generate curl_cat_indices_$hostname.$todate.txt"
curl -u elastic:t3il3achum 172.19.1.52:9201/_template?pretty &> $backupSubDir/curl_template_pretty_$hostname.$todate.txt
printLog "[INFO]" "Generate curl_template_pretty_$hostname.$todate.txt"

else
        printLog "[INFO]" "Elastic Search disabled"
fi

########################################################
############ Get Tango SW and APP Backups  #############
########################################################

if [ `echo "$tangoSW_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$tangoSW_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then

#--- Get current and actual tango SW versions ---
printLog "----------------- Get tango SW versions -------------------------"
spawnShOutFile="$DIR/temp/$spawnFilesh"
if [ ! -f $spawnShOutFile ];then
        echo "#!/bin/bash
if [ \"\$1\" == \"10100\" ];then
expect <<'EOF'
spawn telnet 0 10100
expect \"assistance.\"
send \"\r\"
expect \"mon>\"
send \"a OAM_version;s display;\r\"
expect \"mon>\"
send \"quit\r\"
EOF
elif [ \"\$1\" == \"17010\" ];then
expect <<'EOF'
spawn telnet 0 17010
expect \"assistance.\"
send \"\r\"
expect \"mon>\"
send \"a OAM_version;s display;\r\"
expect \"mon>\"
send \"quit\r\"
EOF
elif [ \"\$1\" == \"17011\" ];then
expect <<'EOF'
spawn telnet 0 17011
expect \"assistance.\"
send \"\r\"
expect \"mon>\"
send \"a OAM_version;s display;\r\"
expect \"mon>\"
send \"quit\r\"
EOF
elif [ \"\$1\" == \"13030\" ];then
expect <<'EOF'
spawn telnet 0 13030
expect \"assistance.\"
send \"\r\"
expect \"mon>\"
send \"a SMPP_router;s display;\r\"
expect \"mon>\"
send \"quit\r\"
EOF
elif [ \"\$1\" == \"13031\" ];then
expect <<'EOF'
spawn telnet 0 13031
expect \"assistance.\"
send \"\r\"
expect \"mon>\"
send \"a SMPP_router;s display;\r\"
expect \"mon>\"
send \"quit\r\"
EOF
elif [ \"\$1\" == \"13032\" ];then
expect <<'EOF'
spawn telnet 0 13032
expect \"assistance.\"
send \"\r\"
expect \"mon>\"
send \"a SMPP_router;s display;\r\"
expect \"mon>\"
send \"quit\r\"
EOF
elif [ \"\$1\" == \"13033\" ];then
expect <<'EOF'
spawn telnet 0 13033
expect \"assistance.\"
send \"\r\"
expect \"mon>\"
send \"a SMPP_router;s display;\r\"
expect \"mon>\"
send \"quit\r\"
EOF
elif [ \"\$1\" == \"2000\" ];then
expect <<'EOF'
spawn telnet 0 2000
expect \"assistance.\"
send \"\r\"
expect \"mon>\"
send \"a M3UA_OM_oamIf;s display;s displayConfigFileEntries;s displayProvisionEntityTable\r\"
expect \"mon>\"
send \"quit\r\"
EOF
fi
" > $spawnShOutFile
chmod 775 $spawnShOutFile
printLog "[INFO]" "Createing $spawnShOutFile . It didnt exist. Its ok now"
fi

$spawnShOutFile "10100" > $backupSubDir/tango_software_version_$hostname.$todate.txt
printLog "[INFO]" " Generate tango_software_version_$hostname.$todate.txt"

if [ `echo "$IncludeServiceInterpreter" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$IncludeServiceInterpreter" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
for (( j=0;j<$SIportArrayLength;j++))
do
        $spawnShOutFile "${SIportArray[$j]}" > $backupSubDir/SI_${SIportArray[$j]}_software_version_$hostname.$todate.txt
        printLog "[INFO]" "Generate SI_${SIportArray[$j]}_software_version_$hostname.$todate.txt"
done
else
        printLog "[INFO]" "SI Version is disabled"
fi


#--- Get tango SW versions ---
cdTangoDir=$(ls -altr /tango/ | grep config | awk '{print $11}')
cd $cdTangoDir
cd ..
cp -rfp installed_versions.txt $backupSubDir/installed_versions_$hostname.$todate.txt
cd $backupSubDir/
printLog "[INFO]" "Backup installed_versions_$hostname.$todate.txt"

#--- Get SMPP binds. Run it only on NH nodes ---
printLog "--------------------- Get SMPP Binds ---------------------------------"
if [ `echo "$IncludeSMPP_router" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$IncludeSMPP_router" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
for (( j=0;j<$SMPP_routerportArrayLength;j++))
do
        $spawnShOutFile "${SMPP_routerportArray[$j]}" > $backupSubDir/Binds_SMPP_router_${SMPP_routerportArray[$j]}_$hostname.$todate.txt
        printLog "[INFO]" "Generate Binds_SMPP_router_${SMPP_routerportArray[$j]}_$hostname.$todate.txt"
done
else
        printLog "[INFO]" "SMPP router Binds is disabled"
fi

#--- Get SMPP binds. Run it only on NH nodes ---
printLog "--------------------- Generate Sigtran Associations--------------------"
if [ `echo "$Includesigtran" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$Includesigtran" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
for (( j=0;j<$M3UAportArrayLength;j++))
do
        $spawnShOutFile "${M3UAportArray[$j]}" > $backupSubDir/M3UA_${M3UAportArray[$j]}_$hostname.$todate.txt
        printLog "[INFO]" "Generate M3UA_${M3UAportArray[$j]}_$hostname.$todate.txt"
done
        netstat --sctp -n > $backupSubDir/sigtranAssociations_$hostname.$todate.txt
        printLog "[INFO]" "Generate sigtranAssociations_$hostname.$todate.txt"
else
        printLog "[INFO]" "Sigtran Status is disabled"
fi

#--- Get tango SW softlinks
printLog "----------------- Generate tango SW softlinks-----------------------"
ls -altr /tango/ > $backupSubDir/TangoSoftlinks_$hostname.$todate.txt

printLog "[INFO]" "Generate TangoSoftlinks_$hostname.$todate.txt"

#--- Backup pmlogs
printLog "-----------------Backup Last pm.log -------------------------------------"
cp -rfp /tango/logs/process/pm.log $backupSubDir/pm.log_$hostname.$todate.txt
printLog "[INFO]" "Backup pmlogs_$hostname.$todate.txt"

#--- Backup /tango/config ---
printLog "----------------- Backup /tango/config/ And /tango/bin/ -------------"
cd /tango/config
nice tar -cf config_$hostname.$todate.tar *
cd $backupSubDir
mv /tango/config/config_$hostname.*.tar $backupSubDir/
printLog "[INFO]" "Backup config_$hostname.$todate.tar"

if [ `echo "$Includebinaries" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$Includebinaries" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
        cd /tango/bin
        nice tar -cf bin_$hostname.$todate.tar *
        cd $backupSubDir
        mv /tango/bin/bin_$hostname.* $backupSubDir/
        nice bzip2 $backupSubDir/bin_$hostname.$todate.tar
        printLog "[INFO]" "Backup bin_$hostname.$todate.tar.bz2"
else
        printLog "[INFO]" "Backing up /tango/bin directory disabled"
fi


#--- Get binaries list. It is not a backup since it would be too big and binaries are available at thor. Just get the list of them ---
ls -altr /tango/bin/ > $backupSubDir/binaries_$hostname.$todate.txt;
printLog "[INFO]" "Get list of tango binaries /tango/bin/"

#--- Get status of processes running ---
/tango/bin/mps > $backupSubDir/mps_$hostname.$todate.txt
printLog "[INFO]" "Get mps status"

#--- backup tango scripts ---
printLog "----------------- Backup /tango/scripts/ -------------------------"
cd /tango/scripts/
nice tar -cf scripts_$hostname.$todate.tar *d
cd $backupSubDir
mv /tango/scripts/scripts_$hostname.$todate.tar $backupSubDir/
nice bzip2 $backupSubDir/scripts_$hostname.$todate.tar
printLog "[INFO]" "Backup scripts_$hostname.$todate.tar.bz2"

#--- backup tango .ssh tango directory ---
printLog "----------------- Backup /home/tango/.ssh/ -----------------------"
cd /home/tango/.ssh/
nice tar -cf sshDir_$hostname.$todate.tar *
cd $backupSubDir
mv /home/tango/.ssh/sshDir_$hostname.$todate.tar $backupSubDir/
printLog "[INFO]" "sshDir_$hostname.$todate.tar"

#--- List all subdirectories that exist under user_data, cdr and root directories ---
printLog "------------------ List important directories --------------------"
ls -altr /tango/data/user_data/ > $backupSubDir/user_data_$hostname.$todate.txt
printLog "[INFO]" "Generate user_data_$hostname.$todate.txt"
ls -altr /tango/data/cdr/ > $backupSubDir/cdr_directory_$hostname.$todate.txt
printLog "[INFO]" "Generate cdr_directory_$hostname.$todate.txt"
ls -altr / > $backupSubDir/root_directory_$hostname.$todate.txt
printLog "[INFO]" "Generate root_directory_$hostname.$todate.txt"

#--- Backup tango license ----
printLog "------------------ Backup tango license --------------------------"
cd /tango/license/
nice tar -cf TangoLicense_$hostname.$todate.tar *
cd $backupSubDir
mv /tango/license/TangoLicense_$hostname.$todate.tar $backupSubDir/
printLog "[INFO]" "Backup TangoLicense_$hostname.$todate.tar"

#--- backup tango .bashrc and .bash_profile files
printLog "---------- Backup .bashrc .bash_history and .bash_profile --------"
cp -rfp /home/tango/.bashrc $backupSubDir/bashrc_tango_$hostname.$todate.txt
printLog "[INFO]" "Backup bashrc_tango_$hostname.$todate.txt"
cp -rfp /home/tango/.bash_history $backupSubDir/bash_history_tango_$hostname.$todate.txt
printLog "[INFO]" "Backup bash_history_tango_$hostname.$todate.txt"
cp -rfp /home/tango/.bash_profile $backupSubDir/bash_profile_tango_$hostname.$todate.txt
printLog "[INFO]" "Backup bash_profile_tango_$hostname.$todate.txt"

#--- Backup tngo crontab ---
printLog "------------------- Backup Tango Crontab -------------------------"
cp -rfp /var/spool/cron/tango $backupSubDir/tango_crontab_$hostname.$todate.txt
printLog "[INFO]" "Backup tango_crontab_$hostname.$todate.txt"

printLog "-------------------- Backup S70tangonet --------------------------"
#--- Backup S70tangonet startup script ---
cat /etc/rc2.d/S70tangonet > $backupSubDir/S70tangonet_$hostname.$todate.txt
printLog "[INFO]" "Backup S70tangonet_$hostname.$todate.txt"

else
        printLog "------------------ Backup tango SW --------------------------"
        printLog "[INFO]" "Tango SW disabled"

fi


#########################################################################################
####################### Backup Operative System #########################################
#########################################################################################

if [ `echo "$OS_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$OS_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then

printLog "----------- Genearting Operative System Backups & Captures ----------"
#--- Operative System Details ---
uname -a > $backupSubDir/uname_a_$hostname.$todate.txt
printLog "[INFO]" "Generate uname_a_$hostname.$todate.txt"

cat /etc/redhat-release > $backupSubDir/redhad_release_$hostname.$todate.txt
printLog "[INFO]" "Backup redhad_release_$hostname.$todate.txt"

#--- Java details ---
which java > $backupSubDir/which_java_$hostname.$todate.txt
printLog "[INFO]" "Generate which_java_$hostname.$todate.txt"
java -fullversion 2>&1|awk "{print $NF}" > $backupSubDir/javaFullVersion_$hostname.$todate.txt

#--- Get current disk status ---
df -h > $backupSubDir/disk_space_$hostname.$todate.txt
printLog "[INFO]" "Generate disk_space_$hostname.$todate.txt"

#--- Get ip rules ---
/usr/sbin/ip rule show > $backupSubDir/ip_rule_show_$hostname.$todate.txt
printLog "[INFO]" "Generate ip_rule_show_$hostname.$todate.txt"

#--- Get current arp table ---
/usr/sbin/arp 2>&1|awk "{print $NF}" > $backupSubDir/arp_table_$hostname.$todate.txt
printLog "[INFO]" "Generate arp_table_$hostname.$todate.txt"

#--- Get current memory status ---
free -m > $backupSubDir/free_a_$hostname.$todate.txt
printLog "[INFO]" "Generate free_a_$hostname.$todate.txt"

#--- Get current systemctl_services ---
systemctl -t service --state=active > $backupSubDir/systemctl_servcies_$hostname.$todate.txt
printLog "[INFO]" "Generate systemctl_servcies_$hostname.$todate.txt"
systemctl get-default > $backupSubDir/systemctl_get-default_$hostname.$todate.txt
printLog "[INFO]" "Generate systemctl_get-default_$hostname.$todate.txt"
who -r > $backupSubDir/who-r_$hostname.$todate.txt
printLog "[INFO]" "Generate who-r_$hostname.$todate.txt"
journalctl > $backupSubDir/journalctl_$hostname.$todate.txt
printLog "[INFO]" "Generate journalctl_$hostname.$todate.txt"
sysctl -a > $backupSubDir/sysctl-a_$hostname.$todate.txt
printLog "[INFO]" "Generate sysctl-a_$hostname.$todate.txt"






#--- Backup etc directory ---
printLog "----------------- Backup /etc/ Directory -----------------------"
cd /etc/
nice tar -cf etcDirectory_$hostname.$todate.tar *
cd $backupSubDir
mv /etc/etcDirectory_$hostname.$todate.tar $backupSubDir/
nice bzip2 $backupSubDir/etcDirectory_$hostname.$todate.tar
printLog "[INFO]" "Backup etcDirectory_$hostname.$todate.tar.bz2"

#--- Backup etc directory ---
printLog "----------------- Backup /usr/ Directory -----------------------"
if [ `echo "$IncludeusrDirectory" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$IncludeusrDirectory" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
cd /usr/
nice tar -cf usrDirectory_$hostname.$todate.tar *
cd $backupSubDir
mv /usr/usrDirectory_$hostname.$todate.tar $backupSubDir/
nice bzip2 $backupSubDir/usrDirectory_$hostname.$todate.tar
printLog "[INFO]" "Backup usrDirectory_$hostname.$todate.tar.bz2"
else
printLog "[INFO]" "Backup /usr/ is not enabled. So, it wont be backed up"
fi


#--- Backup crontab files ---
printLog "----------------- Backup Crontab Files  -----------------------"
cd /var/spool/cron/
nice tar -cf crontabs_$hostname.$todate.tar *
cd $backupSubDir
mv /var/spool/cron/crontabs_$hostname.$todate.tar $backupSubDir/
printLog "[INFO]" "Backup crontabs_$hostname.$todate.tar"

#--- backup root .bashrc and .bash_profile files
printLog "----- Backup root .bashrc .bash_history and .bash_profile ------"
cp -rfp /root/.bashrc $backupSubDir/bashrc_root_$hostname.$todate.txt
printLog "[INFO]" "Backup bashrc_root_$hostname.$todate.txt"
cp -rfp /root/.bash_history $backupSubDir/bash_history_root_$hostname.$todate.txt
printLog "[INFO]" "Backup bash_history_root_$hostname.$todate.txt"
cp -rfp /root/.bash_profile $backupSubDir/bash_profile_root_$hostname.$todate.txt
printLog "[INFO]" "Backup bash_profile_root_$hostname.$todate.txt"

printLog "-------- Backup interfaces -----------------------------------"
#--- Get interfaces status ---
/usr/sbin/ip addr | grep "^ *inet " > $backupSubDir/ip_addr_grep_inet_$hostname.$todate.txt
printLog "[INFO]" "Generate ip_addr_grep_inet_$hostname.$todate.txt"
/usr/sbin/ip addr show > $backupSubDir/ip_addr_show_$hostname.$todate.txt
printLog "[INFO]" "Generate ip_addr_show_$hostname.$todate.txt"
/usr/sbin/ifconfig -a > $backupSubDir/ifconfga_$hostname.$todate.txt
printLog "[INFO]" "Generate ifconfga_$hostname.$todate.txt"

#--- Backup all ifcfg files
cd $backupSubDir/
ls -altr /etc/sysconfig/network-scripts/ifcfg* | awk '{print $9}' | while read in
do
        getifcfgname=$(echo "$in" | rev | cut -d"/" -f1 | rev)
        cp -rfp $in $backupSubDir/$getifcfgname.$hostname.$todate.back
        printLog "[INFO]" "Backup $getifcfgname.$hostname.$todate.back"
done

#--- Generate dmesg status
dmesg > $backupSubDir/dmesg_$hostname.$todate.txt
printLog "[INFO]" " Generate dmesg_$hostname.$todate.txt"

printLog "-------- Backup routing configuration ------------------------"
#--- Backup routing table ---
netstat -rn > $backupSubDir/netstat_rn_routes_$hostname.$todate.txt
printLog "[INFO]" "Generate netstat_rn_routes_$hostname.$todate.txt"
/usr/sbin/ip route show table main > ip_route_show_table_main_weights_$hostname.$todate.txt
printLog "[INFO]" "Generate ip_route_show_table_main_weights_$hostname.$todate.txt"

#--- Backup all persisten route files
printLog "-------- Backup persisten route files ------------------------"
cd $backupSubDir/
isThereRouteFiles=$(ls -altr /etc/sysconfig/network-scripts/ | grep "route-"  | egrep -v grep)
if [ -z "$isThereRouteFiles" ];then
        printLog "[INFO]" "No route-xxx files under network-scripts"
else
        ls -altr /etc/sysconfig/network-scripts/route* | awk '{print $9}' | while read in
        do
                getroutename=$(echo "$in" | rev | cut -d"/" -f1 | rev)
                cp -rfp $in $backupSubDir/$getroutename.$hostname.$todate.back
                printLog "[INFO]" "Backup $getroutename.$hostname.$todate.back"
        done
fi

#--- Get NTP status. ---
printLog "-------- Generate ntp status ---------------------------------"
/usr/sbin/ntpq -p > $backupSubDir/ntp_$hostname.$todate.txt
printLog "[INFO]" "Generate ntp_$hostname.$todate.txt"

#--- Measure Command Speed
printLog "--------  Measure Command Speed -----------------------------"
sar 5 2 > $backupSubDir/sar_55_toMeasureCommandsSpeed_$hostname.$todate.txt
printLog "[INFO]" "Generate sar_55_toMeasureCommandsSpeed_$hostname.$todate.txt"

else
        printLog "------------------ Backup Operative System --------------------------"
        printLog "[INFO]" "Backing up main OS Files and captures disabled"

fi

##########################################################################################################
############# Backup Espeial Directories configured in OSAndTangoSW_SystemBackup.cfg #####################
##########################################################################################################

printLog "--------------------- Backup Especial Directories configured in OSAndTangoSW_SystemBackup.cfg  ---------------------------------"
if [ `echo "$EspecialDir_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$EspecialDir_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
for (( j=0;j<$EspecialDirArrayLength;j++))
do
        cd ${EspecialDirArray[$j]}
        EspecialDirString=$(echo "${EspecialDirArray[$j]}")
        EspecialDirLastChar=$(echo "${EspecialDirString: -1}")
        if [ "$EspecialDirLastChar" != "/" ];then
                EspecialDirString=$(echo "${EspecialDirArray[$j]}""/")
        fi
        getDirName=$(echo "$EspecialDirString" | rev | cut -d"/" -f2 | rev)
        nice tar -cf EspecialDir_$getDirName.$hostname.$todate.tar *
        cd $backupSubDir
        mv ${EspecialDirArray[$j]}/EspecialDir_$getDirName.$hostname.$todate.tar $backupSubDir/
        printLog "[INFO]" "Backup EspecialDir_$getDirName.$hostname.$todate.tar"
done
else
        printLog "[INFO]" "Backup Especial Directories is disabled"
fi


##########################################################################################################
#################################### Compress $backupDir/  ###############################################
##########################################################################################################
printLog "-----------------  Compress $backupDir/ -------------------------------"
cd /tango/data/archive/
tar -cf $backupDir.tar --remove-files $BackupFileName.$hostname.$today -P
chown tango:tango $backupDir.tar
printLog "[INFO]" "Compress $backupDir.tar"


printLog "cleanlog" "##################################### End Backup process #####################################\n\n"