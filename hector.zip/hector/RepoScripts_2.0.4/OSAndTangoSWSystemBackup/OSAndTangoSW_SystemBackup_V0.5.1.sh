#!/bin/bash
source $HOME/.bashrc
##############################################################################
# Filename:    OSAndTangoSW_SystemBackup.sh
# Author:      Hector Barriga
#
# Jiras:
# CO Scripts:  COSC-96
# CO Internal: COIT-17303
#
# This sh script is to take HEALTHY backups of the following:
# 1. Tango Software configurations
# 2. Importantant OS directories
# 3. Capture current OS and Tango SoftWare status
#
# This sh script is mainly used for housekeeping.
# Copyright (c) Tango Telecom 2017
#
# All rights reserved.
# This document contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or
# in part is expressly prohibited, except as may be specifically
# authorized by prior written agreement or permission of Tango Telecom.
##############################################################################
# version 0.1.0 - First version
# version 0.1.1 - Minor Fixes
# version 0.1.2 - Support Percona mysqldumps
# version 0.2.0 - Support RHEL 7
# version 0.3.0 - Support RHEL 8
# version 0.3.1 - Abort backups if there is not enough space on disk partition
# version 0.3.2 - Add elkInfo, Extra Files, mysqldupm all-databases and other improvments
# version 0.4.0 - Add more improvements and resolve Minor Fixes
# version 0.4.0 - Introduce sudo to run script as tango user
version="0.5.0"
#
##############################################################################

# Initial Arguments
dryRun=0
today=$(perl -e '@d=localtime time(); printf "%4d%02d%02d\n", $d[5]+1900,$d[4]+1,$d[3]')
todate=$(perl -e '@d=localtime time(); printf "%4d%02d%02d_%02d%02d%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1],$d[0]')
todatemin=$(perl -e '@d=localtime time(); printf "%4d%02d%02d_%02d%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1]')
lognow=$(perl -e '@d=localtime time(); printf "%4d-%02d-%02d\n", $d[5]+1900,$d[4]+1,$d[3]')
iam=$(whoami)
hostname=$(hostname)
spawnFilesh="spawn_ProcessVersion.sh"
red=`tput setaf 1`
green=`tput setaf 2`
yellow=`tput setaf 3`
pink=`tput setaf 5`
blue=`tput setaf 6`
reset=`tput sgr0`
mysqlcommand="/usr/bin/mysql"
mysqlcommanddump="/usr/bin/mysqldump"
scriptDIR=$(echo "`dirname $0`")

# SubRoutines

printhelp()
{
echo "
${green}Usage: OSAndTangoSW_SystemBackup${reset}

Jiras:
CO Scripts:  COSC-96
CO Internal: COIT-17303

This sh script is to take HEALTHY backups of the following:
1. Tango Software configurations
2. Importantant OS directories
3. Capture current OS and Tango SoftWare status

Copyright (c) Tango Telecom 2016
Author: Hector Barriga

All rights reserved.
This document contains confidential and proprietary information of
Tango Telecom and any reproduction, disclosure, or use in whole or
in part is expressly prohibited, except as may be specifically
authorized by prior written agreement or permission of Tango Telecom.

Version 0.1.0


               Options:

               -c <config file>         Config File that contains all script configurable parameters
                                        It is important to include directory path

               -p <tango password>      This is to setup tango password that will be used by sudo. Password will be persisent and entrypted for security reasons

               -h <help>                Show help


               ${yellow}Crontab Job Exmaple:
               10 22 * * * /tango/scripts/Generic/Others/OSAndTangoSWSystemBackup/OSAndTangoSW_SystemBackup.sh -c /tango/scripts/Generic/Others/OSAndTangoSWSystemBackup/OSAndTangoSW_SystemBackup.cfg /dev/null 2>&1${reset}
               "
exit
}

setupPassword()
{
        echo -e "\n${green}████████████████████████████████████████████"
        echo -e "${green}██          Setup Tango Password          ██"
        echo -e "${green}██               Used by Sudo             ██"
        echo -e "${green}██                                        ██"
        echo -e "${green}██ Notes:                                 ██"
        echo -e "${green}██ - Password will be encrypted           ██"
        echo -e "${green}██ - It will be stored persistently       ██"
        echo -e "${green}████████████████████████████████████████████"
        echo -e -n "${yellow}Enter tango password > ${reset}"
        read passwordIn
        getOpensslPkg=$(yum list openssl | grep Installed)
        if [ -z "$getOpensslPkg" ];then
                echo -e "\n${red}[FAILED] openssl package is not installed. Run yum install openssl, Bye\n${reset}"
                exit
        fi
        openssl genrsa -out $scriptDIR/rsa_key.pri 2048; openssl rsa -in $scriptDIR/rsa_key.pri -out $scriptDIR/rsa_key.pub -outform PEM -pubout
        echo "$passwordIn" | openssl rsautl -encrypt -inkey $scriptDIR/rsa_key.pub -pubin -out $scriptDIR/secret.dat
        exit
}

printLog()
{
if [ `echo "$log_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$log_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
        newlogFile=$(echo $logFile | cut -d. -f1)
        logExt=$(echo $logFile | cut -d. -f2)
        if [ "$1" == "cleanlog" ];then
                echo -e "$2" >> $logDir/$newlogFile.$lognow.$logExt
        else
                timenow=$(perl -e '@d=localtime time(); printf "%4d%02d%02d %02d:%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1]')
                echo -e "[ $timenow ] $1 $2" >> $logDir/$newlogFile.$lognow.$logExt
        fi
fi
}

validateSudoPassword()
{
        if [ ! -f $scriptDIR/secret.dat ];then
                echo -e "\n${red}[FAILED] Sorry, tango password is not setup yet. OSAndTangoSWSystemBackup is run as tango user. Hence, it needs to excecute several commands via sudo. Password must be set up. Just run 'OSAndTangoSWSystemBackup.sh -p' to setup tango password. Note: Password will be encripted and stored persistently. Bye\n${reset}"
                printLog "[FAILED]" "Sorry, tango password is not setup yet. OSAndTangoSWSystemBackup is run as tango user. Hence, it needs to excecute several commands via sudo. Password must be set up. Just run 'OSAndTangoSWSystemBackup.sh -p' to setup tango password. Note: Password will be encripted and stored persistently. Aborting"
                exit
        fi
        decrypPW=$(openssl rsautl -decrypt -inkey $scriptDIR/rsa_key.pri -in $scriptDIR/secret.dat)
        echo "$decrypPW" | sudo -S -v
        if [ `sudo date | wc -l` == "0" ];then
                echo -e "\n${red}[FAILED] Sorry, tango password failed. OSAndTangoSWSystemBackup is run as tango user. Hence, it needs to excecute several commands via sudo. Password must be set up correctly. Just run 'OSAndTangoSWSystemBackup.sh -p' to setup tango password. Note: Password will be encripted and stored persistently. Bye\n${reset}"
                printLog "[FAILED]" "Sorry, tango password failed. OSAndTangoSWSystemBackup is run as tango user. Hence, it needs to excecute several commands via sudo. Password must be set up correctly. Just run 'OSAndTangoSWSystemBackup.sh -p' to setup tango password. Note: Password will be encripted and stored persistently. Aborting"
                exit
        else
                 printLog "[INFO]" "Sudo is working. OK"
        fi
}

validateSudo()
{
        if [ $(grep "wheel" /etc/group | grep "tango" | wc -l) -gt 0 ];then
                validateSudoPassword
        else
                echo -e "\n${red}[FAILED] Sorry, \"sudo\" is disabled. OSAndTangoSWSystemBackup is run as tango user. Hence, it needs to excecute several commands via sudo.\nTo enable sudo for tango user ID on RHEL, add tango ID to the \"wheel\" group. \"wheel\" group enables all its users to use sudo as default /etc/sudoers has the following line by default:\n${yellow}%wheel  ALL=(ALL)  ALL\n${red}To add tango ID to the wheel group, you must run the following command as root:\n${yellow}usermod -aG wheel tango\n${red}Bye\n${reset}"
                printLog "[FAILED]" "Sorry, sudo is disabled. OSAndTangoSWSystemBackup is run as tango user. Hence, it needs to excecute several commands via sudo. To enable sudo for tango user ID on RHEL, add tango ID to the wheel group. wheel group enables all its users to use sudo as default /etc/sudoers has the following line by default:    %wheel  ALL=(ALL)  ALL. To add tango ID to the wheel group, you must run the following command as root: usermod -aG wheel tango"
                exit
        fi
}

defineCommands()
{
        wtar=$(which tar)
        wcp=$(which cp)
        wmv=$(which mv)
        wchown=$(which chown)
        wchmod=$(which chmod)
        wcat=$(which cat)
        wtree=$(which tree)
        wsysctl=$(which sysctl)
        if [ "$1" == "root" ];then
                tarCmd=$wtar
                cpCmd=$wcp
                mvCmd=$wmv
                chownCmd=$wchown
                chmodCmd=$wchmod
                catCmd=$wcat
                treeCmd=$wtree
                llCmd="ls -altr"
                sysctlCmd=$wsysctl
                cdCmd="cd"
        elif [ "$1" == "tango" ];then
                tarCmd="sudo $wtar"
                cpCmd="sudo $wcp"
                mvCmd="sudo $wmv"
                chownCmd="sudo $wchown"
                chmodCmd="sudo $wchmod"
                catCmd="sudo $wcat"
                treeCmd="sudo $wtree"
                llCmd="sudo ls -altr"
                sysctlCmd="sudo $wsysctl"
                cdCmd="sudo /usr/bin/cd"
        fi
}

initChecks()
{
if [ "$createTempDirFlag" == "yes" ];then
        printLog "cleanlog" ""
        printLog "cleanlog" ""
        printLog "cleanlog" "##################################### Start Backup process #####################################"
        printLog "------------------- Initial Checks --------------------------"
        printLog "cleanlog" "Creating $logDir/ and $DIR/temp directories because they didnt exist"
else
        printLog "cleanlog" ""
        printLog "cleanlog" ""
        printLog "[INFO]" "##################################### Start Backup process #####################################"
        printLog "------------------- Initial Checks --------------------------"
        printLog "[INFO]" "$logDir and $DIR/temp directories exist. Ok"
fi
if [ ! -d "$BackupSubDirectory/" ];then
        printLog "[ERROR]" "$BackupSubDirectory/ doesn't exist, you must create it first. Bye"
        echo -e "\n${red}Sorry, $BackupSubDirectory/ doesn't exist, you must create it first. Bye\n${reset}"
        exit
else
        printLog "[INFO]" "$BackupSubDirectory/  exists. Ok"
fi

printLog "[INFO]" "Running script as \"$iam\" user. Ok"
if [ "$iam" == "tango" ];then
        validateSudo
elif [ "$iam" != "tango" ] && [ "$iam" != "root" ];then
        printLog "[ERROR]" "This script must be run as \"root\" or \"tango\" user. Bye"
        echo -e "\n${red}Sorry, this script must be run as \"root\" or \"tango\" user. Bye\n${reset}"
        exit
fi

defineCommands "$iam"
}

getParameters()
{
config_file=$DIR/temp/tmp.file
oldIFS="$IFS"
IFS=":"
while read name value
do
    eval $name="$value"
done < $config_file
IFS="$oldIFS"
}

getParametersFromConfigFile()
{
#---------------------------------------------------------------
# If it doesnt exist, create temp directory in where all temporal important files will be stored temporarely
#--------------------------------------------------------------
if [ ! -f $config_in ];then
        echo -e "\n${red}Sorry, $config_in/ doesn't exist, you must create or use flag '-c' correctly. Bye\n${reset}"
        exit
fi
DIR=$(cat $config_in | tr -d " \t\r" | grep logDir | cut -d"#" -f1 | cut -d= -f2)
if [ ! -d "$DIR/temp" ];then
        mkdir -p $DIR/temp
        createTempDirFlag="yes"
else
        createTempDirFlag="no"
fi

#---------------------------------------------------------------
# get [General] Paramenters from OSAndTangoSW_SystemBackup.cfg
#--------------------------------------------------------------
sed -n '/\[General]/,/\[/p' $config_in | awk  '!/\[General]/ && !/\[/' | tr -d " \t\r" | awk '/log_enable/ || /logDir/ || /logFile/ || /BackupSubDirectory/ || /BackupFileName/ || /ProductReleaseVersion/ || /usedPartitionPercentageLimit/' | cut -d"#" -f1 | sed "s/=/:/g" > $DIR/temp/tmp.file
getParameters
initChecks
printLog "------------------- Get Parameters --------------------------"
printLog "[INFO]" "General:\nlog_enable=$log_enable\nlogDir=$logDir\nlogFile=$logFile\nBackupSubDirectory=$BackupSubDirectory\nBackupFileName=$BackupFileName\nProductReleaseVersion=$ProductReleaseVersion\nusedPartitionPercentageLimit=$usedPartitionPercentageLimit"
BackupFileVersionAndName="$ProductReleaseVersion--$BackupFileName"

#---------------------------------------------------------------
# get [Use Percona XtraBackup] Paramenters from OSAndTangoSW_SystemBackup.cfg
#--------------------------------------------------------------
sed -n '/\[Use Percona XtraBackup]/,/\[/p' $config_in | awk  '!/\[Use Percona XtraBackup]/ && !/\[/' | tr -d " \t\r" | awk '/enable/ || /SubDirectoryName/ || /user/ || /password/ || /FullBackupFrequency/ || /KeepOLDBackups/|| /IncrementalBackupFrequency/' | cut -d"#" -f1 | sed "s/=/:/g" > $DIR/temp/tmp.file
getParameters
perconaxtrabackup_enable=$(echo "$enable")
printLog "[INFO]" "Use Percona XtraBackup:\nenable=$enable\nSubDirectoryName=$SubDirectoryName\nuser=$user\nFullBackupFrequency=$FullBackupFrequency\nKeepOLDBakup=$KeepOLDBackup\nIncrementalBackupFrequency=$IncrementalBackupFrequency"

#---------------------------------------------------------------
# get [use MySQL mysqldump] Paramenters from OSAndTangoSW_SystemBackup.cfg
#--------------------------------------------------------------
sed -n '/\[use MySQL mysqldump]/,/\[/p' $config_in | awk  '!/\[use MySQL mysqldump]/ && !/\[/' | tr -d " \t\r" | awk '/enable/ || /user/ || /password/ || /mysqlpercona/ || /usepxc_strict_mode/ || /usepassword/ || /databases/ || /AllDatabasesDump/ || /mysqlDir/ || /Frequency/' | cut -d"#" -f1 | sed "s/=/:/g" > $DIR/temp/tmp.file
getParameters
getDay_FromFrequency "$Frequency"
mysql_Frequency="$Frequency"
if [ "$BackupEnabled" == "yes" ];then
        mysqldump_enable=$(echo "$enable")
else
        mysqldump_enable="no"
fi
printLog "[INFO]" "use MySQL mysqldump:\nenable=$enable\nmysqldump_enable=$mysqldump_enable\nuser=$user\npassword=$password\nmysqlpercona=$mysqlpercona\nusepxc_strict_mode=$usepxc_strict_mode\nusepassword=**********\ndatabases=$databases\nAllDatabasesDump=$AllDatabasesDump\nmysqlDir=$mysqlDir\nmysql_Frequency=$mysql_Frequency"
mysqlDatabasesArray=(`echo ${databases} | sed 's/,/ /g'`)
mysqlDatabasesArrayLength=${#mysqlDatabasesArray[@]}
printLog "cleanlog" "mysqlDatabasesArrayLength=$mysqlDatabasesArrayLength"
for (( j=0;j<$mysqlDatabasesArrayLength;j++))
do
        printLog "cleanlog" "mysqlDatabases[$j]=${mysqlDatabasesArray[$j]}"
done

#---------------------------------------------------------------
# get [Elastic Search] Paramenters from OSAndTangoSW_SystemBackup.cfg
#--------------------------------------------------------------
sed -n '/\[Elastic Search]/,/\[/p' $config_in | awk  '!/\[Elastic Search]/ && !/\[/' | tr -d " \t\r" | awk '/enable/ || /ELKVersion/ || /cacert/ || /ESmasterIP/ || /ESmasterport/ || /ESUser/ || /ESPassword/ || /Frequency/' | cut -d"#" -f1 | sed "s/=/:/g" > $DIR/temp/tmp.file
if [ $(grep "ES Password" $config_in | cut -d"#" -f1 | grep '"' | wc -l) -gt 0 ];then
        getActualESpassword=$(grep "ES Password" $config_in | cut -d'"' -f2)
        sed -i "/ESPassword/c ESPassword:$getActualESpassword" $DIR/temp/tmp.file
fi
getParameters
getDay_FromFrequency "$Frequency"
ES_Frequency="$Frequency"
if [ "$BackupEnabled" == "yes" ];then
        ES_enable=$(echo "$enable")
else
        ES_enable="no"
fi
printLog "[INFO]" "Elastic Search:\nenable=$enable\nES_enable=$ES_enable\nELKVersion=$ELKVersion\ncacert=$cacert\nESmasterIP=$ESmasterIP\nESmasterport=$ESmasterport\nESUser=$ESUser\nESPassword=********\nES_Frequency=$ES_Frequency"

#---------------------------------------------------------------
# get [Directories To Get Backed Up]  Paramenters from OSAndTangoSW_SystemBackup.cfg
#--------------------------------------------------------------
sed -n '/\[tomcat]/,/\[/p' $config_in | awk  '!/\[tomcat]/ && !/\[/' | tr -d " \t\r" | awk '/enable/ || /BackupwarFiles/ || /BackupDirectory/ || /Frequency/' | cut -d"#" -f1 | sed "s/=/:/g" > $DIR/temp/tmp.file
getParameters
getDay_FromFrequency "$Frequency"
tomcat_Frequency="$Frequency"
if [ "$BackupEnabled" == "yes" ];then
        tomcat_enable=$(echo "$enable")
else
        tomcat_enable="no"
fi
printLog "[INFO]" "tomcat:\nenable=$enable\ntomcat_enable=$tomcat_enable\nBackupwarFiles=$BackupwarFiles\nBackupDirectory=$BackupDirectory\ntomcat_Frequency=$tomcat_Frequency"
tomcatBackupDirectoryArray=(`echo ${BackupDirectory} | sed 's/,/ /g'`)
tomcatBackupDirectoryArrayLength=${#tomcatBackupDirectoryArray[@]}
printLog "cleanlog" "tomcatBackupDirectoryArrayLength=$tomcatBackupDirectoryArrayLength"
for (( j=0;j<$tomcatBackupDirectoryArrayLength;j++))
do
        printLog "cleanlog" "tomcatBackupDirectory[$j]=${tomcatBackupDirectoryArray[$j]}"
done


#---------------------------------------------------------------
# get [Backup Extra Directories And Files]  Paramenters from OSAndTangoSW_SystemBackup.cfg
#--------------------------------------------------------------
sed -n '/\[Backup Extra Directories And Files]/,/\[/p' $config_in | awk  '!/\[Backup Extra Directories And Files]/ && !/\[/' | tr -d " \t\r" | awk '/enable/ || /ExtraDirectories/ || /ExtraFiles/ || /Frequency/' | cut -d"#" -f1 | sed "s/=/:/g" > $DIR/temp/tmp.file
getParameters
getDay_FromFrequency "$Frequency"
ExtraDir_Frequency="$Frequency"
if [ "$BackupEnabled" == "yes" ];then
        ExtraDir_enable=$(echo "$enable")
else
        ExtraDir_enable="no"
fi
printLog "[INFO]" "Backup Extra Directories And Files:\nenable=$enable\nExtraDir_enable=$ExtraDir_enable\nExtraDir_Frequency=$ExtraDir_Frequency"
ExtraDirArray=(`echo ${ExtraDirectories} | sed 's/,/ /g'`)
ExtraDirArrayLength=${#ExtraDirArray[@]}
printLog "cleanlog" "ExtraDirArrayLength=$ExtraDirArrayLength"
for (( j=0;j<$ExtraDirArrayLength;j++))
do
        printLog "cleanlog" "ExtraDirArray[$j]=${ExtraDirArray[$j]}"
done
ExtraFilesArray=(`echo ${ExtraFiles} | sed 's/,/ /g'`)
ExtraFilesArrayLength=${#ExtraFilesArray[@]}
printLog "cleanlog" "ExtraFilesArrayLength=$ExtraFilesArrayLength"
for (( j=0;j<$ExtraFilesArrayLength;j++))
do
        printLog "cleanlog" "ExtraFilesArray[$j]=${ExtraFilesArray[$j]}"
done


#---------------------------------------------------------------
# get [Operative System]  Paramenters from OSAndTangoSW_SystemBackup.cfg
#--------------------------------------------------------------
sed -n '/\[Operative System]/,/\[/p' $config_in | awk  '!/\[Operative System]/ && !/\[/' | tr -d " \t\r" | awk '/enable/ ||/OSversion/ || /IncludeusrDirectory/ || /Frequency/' | cut -d"#" -f1 | sed "s/=/:/g" > $DIR/temp/tmp.file
getParameters
getDay_FromFrequency "$Frequency"
OS_Frequency="$Frequency"
if [ "$BackupEnabled" == "yes" ];then
       OS_enable=$(echo "$enable")
else
       OS_enable="no"
fi
printLog "[INFO]" "Operative System:\nenable=$enable\nOS_enable=$OS_enable\nOSversion=$OSversion\nIncludeusrDirectory=$IncludeusrDirectory\nOS_Frequency=$OS_Frequency"

#---------------------------------------------------------------
# get [Tango SW]  Paramenters from OSAndTangoSW_SystemBackup.cfg
#--------------------------------------------------------------
sed -n '/\[Tango SW]/,/\[/p' $config_in | awk  '!/\[Tango SW]/ && !/\[/' | tr -d " \t\r" | awk '/enable/ || /homeDirectory/ || /IncludeTangoBinaries/ || /IncludeTangoScripts/ || /IncludeServiceInterpreter/ || /ServiceInterpreterports/ || /IncludeSMPP_router/ || /SMPP_routerports/ || /Includesigtran/ || /M3UAports/ || /Frequency/' | cut -d"#" -f1 | sed "s/=/:/g" > $DIR/temp/tmp.file
getParameters
getDay_FromFrequency "$Frequency"
tangoSW_Frequency="$Frequency"
if [ "$BackupEnabled" == "yes" ];then
       tangoSW_enable=$(echo "$enable")
else
       tangoSW_enable="no"
fi
printLog "[INFO]" "Tango SW:\nenable=$enable\ntangoSW_enable=$tangoSW_enable\nhomeDirectory=$homeDirectory\nIncludeTangoBinaries=$IncludeTangoBinaries\nIncludeTangoScripts=$IncludeTangoScripts\nIncludeServiceInterpreter=$IncludeServiceInterpreter\nIncludeSMPP_router=$IncludeSMPP_router\nIncludesigtran=$Includesigtran\ntangoSW_Frequency=$tangoSW_Frequency"
SIportArray=(`echo ${ServiceInterpreterports} | sed 's/,/ /g'`)
SIportArrayLength=${#SIportArray[@]}
printLog "cleanlog" "SIportArrayLength=$SIportArrayLength"
for (( j=0;j<$SIportArrayLength;j++))
do
        printLog "cleanlog" "SIport[$j]=${SIportArray[$j]}"
done

SMPP_routerportArray=(`echo ${SMPP_routerports} | sed 's/,/ /g'`)
SMPP_routerportArrayLength=${#SMPP_routerportArray[@]}
printLog "cleanlog" "SMPP_routerportArrayLength=$SMPP_routerportArrayLength"
for (( j=0;j<$SMPP_routerportArrayLength;j++))
do
        printLog "cleanlog" "SMPP_routerport[$j]=${SMPP_routerportArray[$j]}"
done

M3UAportArray=(`echo ${M3UAports} | sed 's/,/ /g'`)
M3UAportArrayLength=${#M3UAportArray[@]}
printLog "cleanlog" "M3UAportArrayLength=$M3UAportArrayLength"
for (( j=0;j<$M3UAportArrayLength;j++))
do
        printLog "cleanlog" "M3UAports[$j]=${M3UAportArray[$j]}"
done
}


getDay_FromFrequency()
{
BackupEnabled="no"
if [ "$1" == "daily" ];then
        BackupEnabled="yes"
elif [ "$1" == "weekly" ];then
        MonStr=$(date +"%a")
        if [ "$MonStr" == "Mon" ];then
                BackupEnabled="yes"
        fi
elif [ "$1" == "fortnightly" ];then
        dayStr=$(date +"%d")
        if [ "$dayStr" == "29" ] || [ "$dayStr" == "14" ];then
                BackupEnabled="yes"
        fi
elif [ "$1" == "monthly" ];then
        dayStr=$(date +"%d")
        if [ "$dayStr" == "01" ];then
                BackupEnabled="yes"
        fi
fi
}


checkTargetPartitionFreeSpace()
{
skipBackupFlag=0
usedPartitionPercentLimit=$(echo "$usedPartitionPercentageLimit" | tr -d %)
getUsedPartitionPercent=$(df -k $BackupSubDirectory | awk 'NR==2 {print $5}' | tr -d %)
getPartitionSize=$(df -k $BackupSubDirectory | awk 'NR==2 {print $2}')
usedPartitionLimitSize=$((getPartitionSize*usedPartitionPercentLimit/100))
getUsedPartitionSize=$(df -k $BackupSubDirectory | awk 'NR==2 {print $3}')
if [ $getUsedPartitionPercent -gt $usedPartitionPercentLimit ];then
        echo -e "\n${red}Sorry, backup is TERMINATED. $BackupSubDirectory's target partition doesn't have enough space. Used space is higher than $usedPartitionPercentageLimit. Clean or used a different partition, ${red} Bye\n${reset}"
        printLog "[ERROR]" "OSAndTangoSWSystemBackup is TERMINATED. $BackupSubDirectory's target partition doesn't have enough space. Used space is higher than $usedPartitionPercentageLimit. Clean or used a different partition"
        printLog "-----------------  Compress $backupDir/ -------------------------------"
        printLog "[INFO]" "Set tango permissions recursevely for $BackupFileVersionAndName.$hostname.$today and Compress it => $backupDir.tar"
        cd $BackupSubDirectory
        chown -R tango:tango $BackupFileVersionAndName.$hostname.$today
        tar -cf $backupDir.tar --remove-files $BackupFileVersionAndName.$hostname.$today -P 2> >(grep -v 'socket ignored' >&2)
        chown tango:tango $backupDir.tar
        exit
elif [ "$1" == "copy" ];then
        if [ "$iam" == "root" ];then
                if [ -f "$2" ];then
                        getFileSize=$(du $2 | awk '{print $1}')
                        getNewPartitionSize=$((getUsedPartitionSize+getFileSize))
                        if [ $getNewPartitionSize -gt $usedPartitionLimitSize ];then
                                echo -e "\n${red}Sorry, backup is SKIPPED. $BackupSubDirectory's target partition doesn't have enough space. $2 backup will exceed the configured limit of $usedPartitionPercentageLimit space used. Clean or use a different partition ${red} Bye\n${reset}"
                                printLog "[ERROR]" "Backup is SKIPPED. $BackupSubDirectory's target partition doesn't have enough space. $2 backup will exceed the configured limit of $usedPartitionPercentageLimit space used. Clean or use a different partition"
                                skipBackupFlag=1
                        fi
                else
                        printLog "[WARNING]" "File $2 is not found, backup is SKIPPED"
                        echo -e "\n${red}[WARNING] File $2 is not found, backup is SKIPPED\n${reset}"
                        skipBackupFlag=1
                fi
        else
                if sudo test -f "$2";then
                        getFileSize=$(sudo du $2 | awk '{print $1}')
                        getNewPartitionSize=$((getUsedPartitionSize+getFileSize))
                        if [ $getNewPartitionSize -gt $usedPartitionLimitSize ];then
                                echo -e "\n${red}Sorry, backup is SKIPPED. $BackupSubDirectory's target partition doesn't have enough space. $2 backup will exceed the configured limit of $usedPartitionPercentageLimit space used. Clean or use a different partition ${red} Bye\n${reset}"
                                printLog "[ERROR]" "Backup is SKIPPED. $BackupSubDirectory's target partition doesn't have enough space. $2 backup will exceed the configured limit of $usedPartitionPercentageLimit space used. Clean or use a different partition"
                                skipBackupFlag=1
                        fi
                else
                        printLog "[ERROR]" "Backup $2 is SKIPPED. File is not found"
                        echo -e "\n${red}Backup $2 is SKIPPED. File is not found\n${reset}"
                        skipBackupFlag=1
                fi
        fi
elif [ "$1" == "mysqldump" ];then
        if [ "$2" == "AllDatabasesDump" ];then
                if [ `echo "$3" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$3" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
                        getDBSize=$(echo "select sum(data_length)/POWER(1024,1) from information_schema.tables;" | $mysqlcommand -u root -p$password -N)
                else
                        getDBSize=$(echo "select sum(data_length)/POWER(1024,1) from information_schema.tables;" | $mysqlcommand -u root -N)
                fi
        else
                if [ `echo "$3" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$3" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
                        getDBSize=$(echo "select sum(data_length)/POWER(1024,1) from information_schema.tables where TABLE_SCHEMA = '$2';" | $mysqlcommand -u root -p$password -N)
                else
                        getDBSize=$(echo "select sum(data_length)/POWER(1024,1) from information_schema.tables where TABLE_SCHEMA = '$2';" | $mysqlcommand -u root -N)
                fi
        fi
        getNewPartitionSize=$((getUsedPartitionSize+getDBSize))
        if [ $getNewPartitionSize -gt $usedPartitionLimitSize ];then
                echo -e "\n${red}Sorry, backup is SKIPPED. $BackupSubDirectory's target partition doesn't have enough space. Database $2 mysqldump will exceed the configured limit of $usedPartitionPercentageLimit space used. Clean or use a different partition ${red} Bye\n${reset}"
                printLog "[ERROR]" "Backup is SKIPPED. $BackupSubDirectory's target partition doesn't have enough space. Database $2 mysqldump will exceed the configured limit of $usedPartitionPercentageLimit space used. Clean or use a different partition"
                skipBackupFlag=1
        fi
elif [ "$1" == "tar" ];then
        if [ -d "$2" ];then
                getTarFileSizeBytes=$($tarCmd -cP $2 2> >(grep -v 'socket ignored' >&2) | wc -c)
                getTarFileSize=$((getTarFileSizeBytes/1024))
                getNewPartitionSize=$((getUsedPartitionSize+getTarFileSize))
                if [ $getNewPartitionSize -gt $usedPartitionLimitSize ];then
                        echo -e "\n${red}Sorry, backup is SKIPPED. $BackupSubDirectory's target partition doesn't have enough space. Tar compressing $2 will exceed the configured limit of $usedPartitionPercentageLimit space used. Clean or use a different partition ${red} Bye\n${reset}"
                        printLog "[ERROR]" "Backup is SKIPPED. $BackupSubDirectory's target partition doesn't have enough space. Tar compressing $2 will exceed the configured limit of $usedPartitionPercentageLimit space used. Clean or use a different partition"
                        skipBackupFlag=1
                fi
        else
                printLog "[ERROR]" "Backup $2 is SKIPPED. Directory is not found"
                echo -e "\n${red}Backup $2 is SKIPPED. Directory is not found\n${reset}"
                skipBackupFlag=1
        fi
fi
}

setGlobalPxc_strict_mode()
{
if [ `echo "$usepxc_strict_mode" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$usepxc_strict_mode" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
        if [ -z "$usepassword" ];then
                echo "SET GLOBAL pxc_strict_mode=$1;" | $mysqlcommand -u $user
        elif [ `echo "$usepassword" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$usepassword" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
                echo "SET GLOBAL pxc_strict_mode=$1;" | $mysqlcommand -u $user -p$password
        else
                echo "SET GLOBAL pxc_strict_mode=$1;" | $mysqlcommand -u $user
        fi
fi
}

checkExpectPackage()
{
        getExpectPkg=$(yum list expect | grep Installed)
        if [ -z "$getExpectPkg" ];then
                printLog "[WARNING] expect package is not installed. Run yum install expect"
                echo -e "\n${red}[WARNING]expect package is not installed. Run yum install expect\n${reset}"
        fi
}

isPortOpen()
{
        isPortOpen=$(netstat -an | grep "0.0.0.0:$1" | wc -l)
        if [ "$isPortOpen" == "0" ];then
                printLog "[WARNING]" "There is not connection to port $1. Capture info via port $1 is SKIPPED"
                echo -e "\n${red}[WARNING] There is not connection to port $1. Capture info via port $1 is SKIPPED\n${reset}"
                isPortOpen=0
        else
                isPortOpen=1
        fi
}

# Flags
while getopts c:ph option;
do
        case $option in
                c) config_in=$OPTARG;;
                p) setupPassword;;
                h) printhelp;;
        esac
done
if [ -z "$config_in" ];then
        echo -e "\n${red}Sorry, You must include -c flag with config file. ${yellow}Run ./OSAndTangoSW_SystemBackup.sh -h${red} Bye\n${reset}"
        exit
fi

#####################################################
############### Script Main() #######################
#####################################################

getParametersFromConfigFile
printLog "cleanlog" ""
printLog "============================================= Initial Checks and Get Script Inputs ============================================="


#--- Create backup directories ---
if [ -z "$BackupSubDirectory" ];then
        BackupSubDirectory="/tango/data/archive"
else
        if [ "${BackupSubDirectory: -1}" == "/" ];then
                BackupSubDirectory=$(echo "$BackupSubDirectory" | sed 's/.$//')
        fi
fi

if [ `echo "$perconaxtrabackup_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$perconaxtrabackup_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
        backupSubDir="$BackupSubDirectory/$BackupFileVersionAndName.$hostname.$today/$BackupFileVersionAndName.$todate/"
        backupDir="$BackupSubDirectory/$BackupFileVersionAndName.$hostname.$today"
        if [ -f "$backupDir.tar" ];then
                cd $BackupSubDirectory
                printLog "[INFO]" "$backupDir.tar already exists. Hence, I am untaring it"
                tar -xf $backupDir.tar
        fi
        printLog "--------------------- Creating Backup Directory ------------------------"
        printLog "[INFO]" "Creating $backupSubDir"
else
        today=$todatemin
        backupSubDir="$BackupSubDirectory/$BackupFileVersionAndName.$hostname.$today/"
        backupDir=$BackupSubDirectory/$BackupFileVersionAndName.$hostname.$today
fi
mkdir -p $backupSubDir
cd $backupSubDir

checkTargetPartitionFreeSpace


#####################################################
######## Start 3rd Party SW  backups ################
#####################################################
printLog "cleanlog" ""
printLog "============================================== 3rd Party SW Backups and Captures =============================================="

mkdir $backupSubDir/3rdPartySW_backups/
$chownCmd tango:tango $backupSubDir/3rdPartySW_backups/
#--- Get list of tomcat webapps ---
printLog "------------------- Backup tomcat and captures -------------------"
if [ `echo "$tomcat_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$tomcat_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
  for (( j=0;j<$tomcatBackupDirectoryArrayLength;j++))
  do
        if [ ! -d "${tomcatBackupDirectoryArray[$j]}" ];then
                echo -e "\n${red}Sorry, tomcat is not installed. Configure ${yellow}./OSAndTangoSW_SystemBackup.cfg ${red}correctly and try again, Bye\n${reset}"
                printLog "[ERROR]" "${tomcatBackupDirectoryArray[$j]} doesnt exist. Configure /OSAndTangoSW_SystemBackup.cfg correctly and try again, Bye"
                exit
        fi
        backupFilePrefix=$(echo "${tomcatBackupDirectoryArray[$j]}" | cut -d"/" -f4)
        webappsList=$($llCmd ${tomcatBackupDirectoryArray[$j]}/webapps/)
        printLog "[INFO]" "Capture $backupFilePrefix.webapps_$hostname.$todate.txt"
        echo "$webappsList" > $backupSubDir/3rdPartySW_backups/$backupFilePrefix.webapps_$hostname.$todate.txt
        checkTargetPartitionFreeSpace "copy" "${tomcatBackupDirectoryArray[$j]}/logs/catalina.out"
        if [ "$skipBackupFlag" == "0" ];then
                printLog "[INFO]" "Backup $backupFilePrefix.catalinaOutLogs.$hostname.$todate.txt"
                $cpCmd -rfp ${tomcatBackupDirectoryArray[$j]}/logs/catalina.out $backupSubDir/3rdPartySW_backups/$backupFilePrefix.catalinaOutLogs.$hostname.$todate.txt
        fi
        warFiles=$(echo "$webappsList" | grep war | egrep -v grep | awk '{print $9}')
        if [ ! -z "$warFiles" ];then
                echo "$warFiles" | while read warList
                do
                        if [ `echo "$BackupwarFiles" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$BackupwarFiles" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
                                checkTargetPartitionFreeSpace "copy" "${tomcatBackupDirectoryArray[$j]}/webapps/$warList"
                                if [ "$skipBackupFlag" == "0" ];then
                                        printLog "[INFO]" "Backup ${tomcatBackupDirectoryArray[$j]}/webapps/$warList"
                                        $cpCmd -rfp ${tomcatBackupDirectoryArray[$j]}/webapps/$warList $backupSubDir/3rdPartySW_backups/
                                fi
                        fi
                        printLog "[INFO]" "Capture  $getWarName.$backupFilePrefix.version_$hostname.$todate.txt"
                        getWarName=$(echo "$warList" | cut -d"." -f1)
                        isTherePMI=$(echo "$warList" | grep -i pmi | egrep -v grep)
                        if [ ! -z $isTherePMI ];then
                                $catCmd ${tomcatBackupDirectoryArray[$j]}/webapps/$getWarName/WEB-INF/classes/ApplicationResources.properties | grep "webapp.version" > $backupSubDir/3rdPartySW_backups/$getWarName.$backupFilePrefix.version_$hostname.$todate.txt
                        else
                                getPomProperties=$(find ${tomcatBackupDirectoryArray[$j]}/webapps/$getWarName/ -name pom.properties)
                                $catCmd $getPomProperties  > $backupSubDir/3rdPartySW_backups/$getWarName.$backupFilePrefix.version_$hostname.$todate.txt
                        fi
                done
        else
                printLog "[INFO]" "No war files to backup in ${tomcatBackupDirectoryArray[$j]}/webapps/"
        fi
  done
else
        printLog "[INFO]" "Tomcat backups disabled"
fi


printLog "cleanlog" ""
printLog "============================================== MySQL Backups and Captures =============================================="
#---- Get Database Full Base Backup via Percona XtraBackup--
printLog "------ MySQL databases Backups via Percona XtraBackup ----------"
if [ `echo "$perconaxtrabackup_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$perconaxtrabackup_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
if [ ! -f "$mysqlcommand" ];then
        echo -e "\n${red}Sorry, Percona (MySQL) is not running on this machine. Configure ${yellow}./OSAndTangoSW_SystemBackup.cfg ${red}correctly and try again, Bye\n${reset}"
        printLog "[ERROR]" " Percona (MySQL) is not running on this machine. Configure /OSAndTangoSW_SystemBackup.cfg correctly and try again, Bye"
        exit
fi
if  [ ! -d "$BackupSubDirectory/$SubDirectoryName/" ];then
        printLog "[INFO]" "$BackupSubDirectory/$SubDirectoryName/ doesn't exist. I am creating it now"
        mkdir $BackupSubDirectory/$SubDirectoryName/
        isThereMysqlDir="no"
else
        isThereMysqlDir="yes"
fi

if  [ ! -d "$BackupSubDirectory/OLD_$SubDirectoryName/" ];then
        printLog "[INFO]" "$BackupSubDirectory/OLD_$SubDirectoryName/ doesn't exist. I am creating it now"
        mkdir $BackupSubDirectory/OLD_$SubDirectoryName/
fi

getDay_FromFrequency "$FullBackupFrequency"
if [ "$BackupEnabled" == "yes" ] || [ "$isThereMysqlDir" == "no" ];then

        if [ -f "$BackupSubDirectory/OLD_$SubDirectoryName/$SubDirectoryName.OLD.$today.tar" ];then
                echo -e "\n${red}Sorry, $BackupSubDirectory/OLD_$SubDirectoryName/$SubDirectoryName.OLD.$today.tar already exists. Only one full backup per day, remove that directory manually. Bye\n${reset}"
                printLog "[ERROR]" "$BackupSubDirectory/OLD_$SubDirectoryName/$SubDirectoryName.OLD.$today.tar already exists. Only one full backup per day, remove that directory manually. Bye"
        fi

        if [ `echo "$KeepOLDBackup" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$KeepOLDBackup" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
                printLog "[INFO]" "Yes!! a new Full base backup is to be taken today. Moving and compressing OLD Full and its incremental backups to get a new fresh full and incremental backups. $SubDirectoryName.OLD.$today.tar"
                mv $BackupSubDirectory/$SubDirectoryName/ $BackupSubDirectory/OLD_$SubDirectoryName/$SubDirectoryName.OLD.$today/
                tar -cf $BackupSubDirectory/OLD_$SubDirectoryName/$SubDirectoryName.OLD.$today.tar  --remove-files $BackupSubDirectory/OLD_$SubDirectoryName/$SubDirectoryName.OLD.$today -P
        else
                if [ -d $BackupSubDirectory/ ];then
                        rm $BackupSubDirectory/$SubDirectoryName/*
                        printLog "[INFO]" "Yes!! a new Full base backup is to be taken today. However, since KeepOLDBackup is set $KeepOLDBackup, FULL Backup and Incrementals have been removed"
                else
                        printLog "[ERROR]" "Sorry, FULL Backup and Incrementals have not been removed. $BackupSubDirectory/ doesnt exit. Check OSAndTangoSW_SystemBackup.cfg Backup Directory. Note KeepOLDBackup is set $KeepOLDBackup"
                fi
        fi

        mkdir $BackupSubDirectory/$SubDirectoryName/
        printLog "[INFO]" "Creating Base Full Backup = /usr/bin/xtrabackup --user=$user --password=$password --backup --target-dir=$BackupSubDirectory/$SubDirectoryName/FULL_DATABASE_BACKUP_base/"
        /usr/bin/xtrabackup --user=$user --password=$password --backup --target-dir=$BackupSubDirectory/$SubDirectoryName/FULL_DATABASE_BACKUP_base/ &>/dev/null
        checkpointsFromLNS=$($catCmd $BackupSubDirectory/$SubDirectoryName/FULL_DATABASE_BACKUP_base/xtrabackup_checkpoints | grep from_lsn | egrep -v grep)
        checkpointsToLNS=$($catCmd $BackupSubDirectory/$SubDirectoryName/FULL_DATABASE_BACKUP_base/xtrabackup_checkpoints | grep to_lsn | egrep -v grep)
        printLog "[INFO]" "checkpoints:\nfrom_lsn=$checkpointsFromLNS\nto_lsn=$checkpointsToLNS"
        /usr/bin/xtrabackup --user=$user --password=$password --backup --target-dir=$BackupSubDirectory/$SubDirectoryName/LAST_TODAY-Incremental.$hostname.$todate/ --incremental-basedir=$BackupSubDirectory/$SubDirectoryName/FULL_DATABASE_BACKUP_base/ &>/dev/null
        printLog "[INFO]" "Creating First Incremental Backup = /usr/bin/xtrabackup --user=$user --password=$password --backup --target-dir=$BackupSubDirectory/$SubDirectoryName/LAST_TODAY-Incremental.$hostname.$todate/ --incremental-basedir=$BackupSubDirectory/$SubDirectoryName/FULL_DATABASE_BACKUP_base/"
        checkpointsFromLNS=$($catCmd $BackupSubDirectory/$SubDirectoryName/LAST_TODAY-Incremental.*/xtrabackup_checkpoints | grep from_lsn | egrep -v grep)
        checkpointsToLNS=$($catCmd $BackupSubDirectory/$SubDirectoryName/LAST_TODAY-Incremental.*/xtrabackup_checkpoints | grep to_lsn | egrep -v grep)
        printLog "[INFO]" "checkpoints:\nfrom_lsn=$checkpointsFromLNS\nto_lsn=$checkpointsToLNS"
        FullBackupAndIncAlreadyTaken="true"

        cd $BackupSubDirectory/$SubDirectoryName/
        printLog "[INFO]" "Compress FULL_DATABASE_BACKUP_base.$hostname.$today.tar"
        tar -cf FULL_DATABASE_BACKUP_base.$hostname.$today.tar --remove-files FULL_DATABASE_BACKUP_base -P
        chown tango:tango $BackupSubDirectory/$SubDirectoryName/FULL_DATABASE_BACKUP_base.$hostname.$today.tar
        printLog "[INFO]" "Compress LAST_TODAY-Incremental.$hostname.$todate.tar"
        tar -cf LAST_TODAY-Incremental.$hostname.$todate.tar --remove-files LAST_TODAY-Incremental.$hostname.$todate -P
        chown tango:tango $BackupSubDirectory/$SubDirectoryName/LAST_TODAY-Incremental.$hostname.$todate.tar

else
        printLog "[INFO]" "Percona XtraBackup Full Base  Backup wont be taken today since FullBackupFrequency is $FullBackupFrequency"
fi

getDay_FromFrequency "$IncrementalBackupFrequency"
if [ "$BackupEnabled" == "yes" ] && [ "$FullBackupAndIncAlreadyTaken" != "true" ];then
        cd $BackupSubDirectory/$SubDirectoryName/
        FullBackupAndIncAlreadyTaken="false"
        getLastIncrementalTar=$(ls -alrt $BackupSubDirectory/$SubDirectoryName/ | grep LAST | awk '{print $9}')
        tar -xf $getLastIncrementalTar -P
        rm $getLastIncrementalTar
        getLastIncrementalDir=$(ls -alrt $BackupSubDirectory/$SubDirectoryName/ | grep LAST | awk '{print $9}')
        RenameLastIncrementalDirName=$(ls -alrt $BackupSubDirectory/$SubDirectoryName/ | grep LAST | awk '{print $9}' | cut -d"-" -f2)
        printLog "[INFO]" "Renaming  directory = $mvCmd $BackupSubDirectory/$SubDirectoryName/$getLastIncrementalDir $BackupSubDirectory/$SubDirectoryName/$RenameLastIncrementalDirName"
        mv $BackupSubDirectory/$SubDirectoryName/$getLastIncrementalDir $BackupSubDirectory/$SubDirectoryName/$RenameLastIncrementalDirName
        printLog "[INFO]" "Creating a new Incremental Backup = /usr/bin/xtrabackup --user=$user --password=$password --backup --target-dir=$BackupSubDirectory/$SubDirectoryName/LAST_TODAY-Incremental.$hostname.$todate/ --incremental-basedir=$BackupSubDirectory/$SubDirectoryName/$RenameLastIncrementalDirName/"
        /usr/bin/xtrabackup --user=$user --password=$password --backup --target-dir=$BackupSubDirectory/$SubDirectoryName/LAST_TODAY-Incremental.$hostname.$todate/ --incremental-basedir=$BackupSubDirectory/$SubDirectoryName/$RenameLastIncrementalDirName/ &>/dev/null
        checkpointsFromLNS=$($catCmd $BackupSubDirectory/$SubDirectoryName/LAST_TODAY-Incremental*/xtrabackup_checkpoints | grep from_lsn | egrep -v grep)
        checkpointsToLNS=$($catCmd $BackupSubDirectory/$SubDirectoryName/LAST_TODAY-Incremental*/xtrabackup_checkpoints | grep to_lsn | egrep -v grep)
        printLog "[INFO]" "checkpoints:\nfrom_lsn=$checkpointsFromLNS\nto_lsn=$checkpointsToLNS"

        cd $BackupSubDirectory/$SubDirectoryName/
        printLog "[INFO]" "Compress $RenameLastIncrementalDirName.tar"
        tar -cf $BackupSubDirectory/$SubDirectoryName/$RenameLastIncrementalDirName.tar --remove-files $BackupSubDirectory/$SubDirectoryName/$RenameLastIncrementalDirName -P
        chown tango:tango $BackupSubDirectory/$SubDirectoryName/$RenameLastIncrementalDirName.tar
        printLog "[INFO]" "Compress LAST_TODAY-Incremental.$hostname.$todate.tar"
        tar -cf $BackupSubDirectory/$SubDirectoryName/LAST_TODAY-Incremental.$hostname.$todate.tar --remove-files $BackupSubDirectory/$SubDirectoryName/LAST_TODAY-Incremental.$hostname.$todate -P
        chown tango:tango $BackupSubDirectory/$SubDirectoryName/LAST_TODAY-Incremental.$hostname.$todate.tar

else
        printLog "[INFO]" "Percona XtraBackup Incremental  Backup wont be taken today either becouse IncrementalBackupFrequency is $IncrementalBackupFrequency or FullBackupAndIncAlreadyTaken is true"
fi

else
        printLog "[INFO]" "Percona XtraBackup backups disabled"
fi


#---- Get Database Dumps --

printLog "------------ Capture MySQL important information ------------------"
if [ `echo "$mysqldump_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$mysqldump_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
if [ ! -f "$mysqlcommand" ];then
        echo -e "\n${red}Sorry, MySQL is not running on this machine. Configure ${yellow}./OSAndTangoSW_SystemBackup.cfg ${red}correctly and try again, Bye\n${reset}"
        printLog "[ERROR]" " MySQL is not running on this machine. Configure /OSAndTangoSW_SystemBackup.cfg correctly and try again, Bye"
        exit
fi
mkdir $backupSubDir/MySQL_backups/
chown tango:tango $backupSubDir/MySQL_backups/
isPXC=$(yum list percona-xtradb-cluster* 2> /dev/null | grep Installed)
if [ -z "$isPXC" ];then
        if [ -z "$usepassword" ];then
                printLog "[INFO]" "Capture slave_status_$hostname.$todate.txt"
                echo "show slave status\G;" | $mysqlcommand -u $user -p$password > $backupSubDir/MySQL_backups/slave_status_$hostname.$todate.txt
                printLog "[INFO]" "Capture master_status_$hostname.$todate.txt"
                echo "show master status\G;" | $mysqlcommand -u $user -p$password > $backupSubDir/MySQL_backups/master_status_$hostname.$todate.txt
        elif [ `echo "$usepassword" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$usepassword" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
                printLog "[INFO]" "Capture slave_status_$hostname.$todate.txt"
                echo "show slave status\G;" | $mysqlcommand -u $user -p$password > $backupSubDir/MySQL_backups/slave_status_$hostname.$todate.txt
                printLog "[INFO]" "Capture master_status_$hostname.$todate.txt"
                echo "show master status\G;" | $mysqlcommand -u $user -p$password > $backupSubDir/MySQL_backups/master_status_$hostname.$todate.txt
        else
                printLog "[INFO]" "Capture slave_status_$hostname.$todate.txt"
                echo "show slave status\G;" | $mysqlcommand -u $user > $backupSubDir/MySQL_backups/slave_status_$hostname.$todate.txt
                printLog "[INFO]" "Capture master_status_$hostname.$todate.txt"
                echo "show master status\G;" | $mysqlcommand -u $user > $backupSubDir/MySQL_backups/master_status_$hostname.$todate.txt
        fi
fi

if [ -z "$usepassword" ];then
        printLog "[INFO]" "Capture show_databases_list_$hostname.$todate.txt"
        getDatabasesList=$(echo "show databases;" | $mysqlcommand -u $user -p$password)
        echo "$getDatabasesList" > $backupSubDir/MySQL_backups/show_databases_list_$hostname.$todate.txt
elif [ `echo "$usepassword" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$usepassword" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
        printLog "[INFO]" "Capture show_databases_list_$hostname.$todate.txt"
        getDatabasesList=$(echo "show databases;" | $mysqlcommand -u $user -p$password)
        echo "$getDatabasesList" > $backupSubDir/MySQL_backups/show_databases_list_$hostname.$todate.txt
else
        printLog "[INFO]" "Capture show_databases_list_$hostname.$todate.txt"
        getDatabasesList=$(echo "show databases;" | $mysqlcommand -u $user)
        echo "$getDatabasesList" > $backupSubDir/MySQL_backups/show_databases_list_$hostname.$todate.txt
fi

#--- mysql version, imortant Files, stored procedures(ROUTINES), users and all grants (privilages) ---
if [ -z "$usepassword" ];then
        printLog "[INFO]" "Capture mysql_version_$hostname.$todate.txt"
        $mysqlcommand --version > $backupSubDir/MySQL_backups/mysql_version_$hostname.$todate.txt
        printLog "[INFO]" "Capture MySQL_StoredProcedures_ROUTINES_$hostname.$todate.txt"
        echo "select * from ROUTINES\G;" | $mysqlcommand -u $user -p$password information_schema > $backupSubDir/MySQL_backups/MySQL_StoredProcedures_ROUTINES_$hostname.$todate.txt
        printLog "[INFO]" "Capture mysql_user_$hostname.$todate.txt"
        echo "select * from user;" | $mysqlcommand -u $user -p$password mysql > $backupSubDir/MySQL_backups/mysql_user_$hostname.$todate.txt
        printLog "[INFO]" "Capture mysql_user_host_password_$hostname.$todate.txt"
        echo "SELECT User, Host,authentication_string FROM mysql.user;" | $mysqlcommand -u $user -p$password mysql > $backupSubDir/MySQL_backups/mysql_user_host_password_$hostname.$todate.txt
        printLog "[INFO]" "Capture information_schema_user_privileges_$hostname.$todate.txt"
        echo "SELECT * FROM information_schema.user_privileges;" | $mysqlcommand -u $user -p$password > $backupSubDir/MySQL_backups/information_schema_user_privileges_$hostname.$todate.txt
        printLog "[INFO]" "Capture GRANTS_commands_$hostname.$todate.txt"
        showgrantsList=$(echo "SELECT CONCAT('SHOW GRANTS FOR ''',user,'''@''',host,''';') FROM mysql.user;" | $mysqlcommand -u $user -p$password -N)
        echo "$showgrantsList" > $backupSubDir/MySQL_backups/List_of_SHOWGRANTSFOR_$hostname.$todate.txt
        echo "$showgrantsList" | while read in; do echo "------------"; echo "$in" | $mysqlcommand -u $user -p$password; done > $backupSubDir/MySQL_backups/GRANTS_commands_$hostname.$todate.txt
        printLog "----------------- Get important MySQL Files -------------------"
        printLog "[INFO]" "Capture mysql_data directory tree and permissions"
        $treeCmd -pug $mysqlDir > $backupSubDir/MySQL_backups/mysql_data_directory_tree_$hostname.$todate.txt

elif [ `echo "$usepassword" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$usepassword" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
        printLog "[INFO]" "Capture mysql_version_$hostname.$todate.txt"
        $mysqlcommand --version > $backupSubDir/MySQL_backups/mysql_version_$hostname.$todate.txt
        printLog "[INFO]" "Capture MySQL_StoredProcedures_ROUTINES_$hostname.$todate.txt"
        echo "select * from ROUTINES\G;" | $mysqlcommand -u $user -p$password information_schema > $backupSubDir/MySQL_backups/MySQL_StoredProcedures_ROUTINES_$hostname.$todate.txt
        printLog "[INFO]" "Capture mysql_user_$hostname.$todate.txt"
        echo "select * from user;" | $mysqlcommand -u $user -p$password mysql > $backupSubDir/MySQL_backups/mysql_user_$hostname.$todate.txt
        printLog "[INFO]" "Capture mysql_user_host_password_$hostname.$todate.txt"
        echo "SELECT User, Host,authentication_string FROM mysql.user;" | $mysqlcommand -u $user -p$password mysql > $backupSubDir/MySQL_backups/mysql_user_host_password_$hostname.$todate.txt
        printLog "[INFO]" "Capture information_schema_user_privileges_$hostname.$todate.txt"
        echo "SELECT * FROM information_schema.user_privileges;" | $mysqlcommand -u $user -p$password > $backupSubDir/MySQL_backups/information_schema_user_privileges_$hostname.$todate.txt
        printLog "[INFO]" "Capture GRANTS_commands_$hostname.$todate.txt"
        showgrantsList=$(echo "SELECT CONCAT('SHOW GRANTS FOR ''',user,'''@''',host,''';') FROM mysql.user;" | $mysqlcommand -u $user -p$password -N)
        echo "$showgrantsList" > $backupSubDir/MySQL_backups/List_of_SHOWGRANTSFOR_$hostname.$todate.txt
        echo "$showgrantsList" | while read in; do echo "------------"; echo "$in" | $mysqlcommand -u $user -p$password; done > $backupSubDir/MySQL_backups/GRANTS_commands_$hostname.$todate.txt
        printLog "----------------- Get important MySQL Files -------------------"
        printLog "[INFO]" "Capture mysql_data directory tree and permissions"
        $treeCmd -pug $mysqlDir > $backupSubDir/MySQL_backups/mysql_data_directory_tree_$hostname.$todate.txt
else
        printLog "[INFO]" "Capture mysql_version_$hostname.$todate.txt"
        $mysqlcommand --version > $backupSubDir/MySQL_backups/mysql_version_$hostname.$todate.txt
        printLog "[INFO]" "Capture MySQL_StoredProcedures_ROUTINES_$hostname.$todate.txt"
        echo "select * from ROUTINES\G;" | $mysqlcommand -u $user information_schema > $backupSubDir/MySQL_backups/MySQL_StoredProcedures_ROUTINES_$hostname.$todate.txt
        printLog "[INFO]" "Capture mysql_user_$hostname.$todate.txt"
        echo "select * from user;" | $mysqlcommand -u $user mysql > $backupSubDir/MySQL_backups/mysql_user_$hostname.$todate.txt
        printLog "[INFO]" "Capture mysql_user_host_password_$hostname.$todate.txt"
        echo "SELECT User, Host,authentication_string FROM mysql.user;" | $mysqlcommand -u $user mysql > $backupSubDir/MySQL_backups/mysql_user_host_password_$hostname.$todate.txt
        printLog "[INFO]" "Capture information_schema_user_privileges_$hostname.$todate.txt"
        echo "SELECT * FROM information_schema.user_privileges;" | $mysqlcommand -u $user > $backupSubDir/MySQL_backups/information_schema_user_privileges_$hostname.$todate.txt
        printLog "[INFO]" "Capture GRANTS_commands_$hostname.$todate.txt"
        showgrantsList=$(echo "SELECT CONCAT('SHOW GRANTS FOR ''',user,'''@''',host,''';') FROM mysql.user;" | $mysqlcommand -u $user -N)
        echo "$showgrantsList" > $backupSubDir/MySQL_backups/List_of_SHOWGRANTSFOR_$hostname.$todate.txt
        echo "$showgrantsList" | while read in; do echo "------------"; echo "$in" | $mysqlcommand -u $user; done > $backupSubDir/MySQL_backups/GRANTS_commands_$hostname.$todate.txt
        printLog "----------------- Get important MySQL Files -------------------"
        printLog "[INFO]" "Capture mysql_data directory tree and permissions"
        $treeCmd -pug $mysqlDir > $backupSubDir/MySQL_backups/mysql_data_directory_tree_$hostname.$todate.txt
fi

isTherePtShowGrants=$(which pt-show-grants 2> /dev/null)
if [ -f /usr/bin/pt-show-grants ] || [ -f /bin/pt-show-grants ];then
        printLog "----------------- Get GRANTS via pt-show-grants -------------------"
        printLog "[INFO]" "Capture PT-SHOW-GRANTS_commands_$hostname.$todate.txt"
        pt-show-grants > $backupSubDir/MySQL_backups/PT-SHOW-GRANTS_commands_$hostname.$todate.txt
fi

#--- Backup my.cnf ---
printLog "[INFO]" "Backup my.cnf.$hostname.$todate.txt"
$cpCmd -rfp /etc/my.cnf $backupSubDir/MySQL_backups/my.cnf.$hostname.$todate.txt

#--- Backup mysql logs ---
checkTargetPartitionFreeSpace "copy" /var/log/mysqld.log
if [ "$skipBackupFlag" == "0" ];then
        printLog "[INFO]" "Backup /var/log/mysqld.log"
        $cpCmd -rfp /var/log/mysqld.log $backupSubDir/MySQL_backups/
fi
for i in {0..9}
do
        if [ -f /var/log/mysqld.log.$i.gz ];then
                checkTargetPartitionFreeSpace "copy" "/var/log/mysqld.log.$i.gz"
                if [ "$skipBackupFlag" == "0" ];then
                        printLog "[INFO]" "Backup /var/log/mysqld.log.$i.gz"
                        $cpCmd -rfp /var/log/mysqld.log.$i.gz $backupSubDir/MySQL_backups/
                fi
        fi
done

if [ `echo "$mysqlpercona" | tr -s '[:upper:]' '[:lower:]'` == `echo "no" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$mysqlpercona" | tr -s '[:upper:]' '[:lower:]'` == `echo "false" | tr -s '[:upper:]' '[:lower:]'` ];then
        if [ -f $mysqlDir/mysql-slow-query.log ];then
			checkTargetPartitionFreeSpace "copy" $mysqlDir/mysql-slow-query.log
		else
			skipBackupFlag=1
		fi
        if [ "$skipBackupFlag" == "0" ];then
                printLog "[INFO]" "Backup $mysqlDir/mysql-slow-query.log"
                $cpCmd -rfp $mysqlDir/mysql-slow-query.log $backupSubDir/MySQL_backups/
        fi
fi



printLog "----------------- MySQL databases Backups via mysqldump -------------------"
cd $backupSubDir/MySQL_backups/
for (( j=0;j<$mysqlDatabasesArrayLength;j++))
do
        checkTargetPartitionFreeSpace "mysqldump" "${mysqlDatabasesArray[$j]}" "$usepassword"
        if [ "$skipBackupFlag" == "0" ];then
                if [ -z "$mysqlpercona" ];then
                        printLog "[INFO]" "$mysqlcommanddump -u root -p$password --routines ${mysqlDatabasesArray[$j]} > ${mysqlDatabasesArray[$j]}.$hostname.$todate.dump"
                        $mysqlcommanddump -u root -p$password --routines ${mysqlDatabasesArray[$j]} > ${mysqlDatabasesArray[$j]}.$hostname.$todate.dump
                elif [ `echo "$mysqlpercona" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$mysqlpercona" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
                        if [ -z "$usepxc_strict_mode" ];then
                                usepxc_strict_mode=no
                        fi
                        setGlobalPxc_strict_mode "PERMISSIVE"
                        if [ -z "$usepassword" ];then
                                printLog "[INFO]" "$mysqlcommanddump -u root -p$password --routines --triggers --events --set-gtid-purged=OFF ${mysqlDatabasesArray[$j]} > ${mysqlDatabasesArray[$j]}.$hostname.$todate.dump"
                                $mysqlcommanddump -u root -p$password --routines --triggers --events --set-gtid-purged=OFF ${mysqlDatabasesArray[$j]} > ${mysqlDatabasesArray[$j]}.$hostname.$todate.dump
                        elif [ `echo "$usepassword" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$usepassword" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
                                printLog "[INFO]" "$mysqlcommanddump -u root -p$password --routines --triggers --events --set-gtid-purged=OFF ${mysqlDatabasesArray[$j]} > ${mysqlDatabasesArray[$j]}.$hostname.$todate.dump"
                                $mysqlcommanddump -u root -p$password --routines --triggers --events --set-gtid-purged=OFF ${mysqlDatabasesArray[$j]} > ${mysqlDatabasesArray[$j]}.$hostname.$todate.dump
                        else
                                printLog "[INFO]" "$mysqlcommanddump -u root --routines --triggers --events --set-gtid-purged=OFF ${mysqlDatabasesArray[$j]} > ${mysqlDatabasesArray[$j]}.$hostname.$todate.dump"
                                $mysqlcommanddump -u root --routines --triggers --events --set-gtid-purged=OFF ${mysqlDatabasesArray[$j]} > ${mysqlDatabasesArray[$j]}.$hostname.$todate.dump
                        fi
                        setGlobalPxc_strict_mode "ENFORCING"
                else
                        printLog "[INFO]" "$mysqlcommanddump -u root -p$password --routines ${mysqlDatabasesArray[$j]} > ${mysqlDatabasesArray[$j]}.$hostname.$todate.dump"
                        if [ `echo "$usepassword" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$usepassword" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
                                $mysqlcommanddump -u root -p$password --routines ${mysqlDatabasesArray[$j]} > ${mysqlDatabasesArray[$j]}.$hostname.$todate.dump
                        else
                                $mysqlcommanddump -u root --routines ${mysqlDatabasesArray[$j]} > ${mysqlDatabasesArray[$j]}.$hostname.$todate.dump
                        fi
                fi
        fi
done

# Get Full Databases Dump
if [ `echo "$AllDatabasesDump" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$AllDatabasesDump" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
        printLog "----------------- Get Full Backup dump via mysqldump all-databases -------------------"
        checkTargetPartitionFreeSpace "mysqldump" "AllDatabasesDump" "$usepassword"
        if [ "$skipBackupFlag" == "0" ];then
                if [ -z "$mysqlpercona" ];then
                        printLog "[INFO]" "$mysqlcommanddump -u root -p$password --routines --all-databases > all-databases.$hostname.$todate.dump"
                        $mysqlcommanddump -u root -p$password --routines --all-databases > all-databases.$hostname.$todate.dump
                elif [ `echo "$mysqlpercona" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$mysqlpercona" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
                        if [ -z "$usepxc_strict_mode" ];then
                                usepxc_strict_mode=no
                        fi
                        setGlobalPxc_strict_mode "PERMISSIVE"
                        if [ -z "$usepassword" ];then
                                printLog "[INFO]" "$mysqlcommanddump -u root -p$password --routines --triggers --events --set-gtid-purged=OFF --all-databases > all-databases.$hostname.$todate.dump"
                                $mysqlcommanddump -u root -p$password --routines --triggers --events --set-gtid-purged=OFF --all-databases > all-databases.$hostname.$todate.dump
                        elif [ `echo "$usepassword" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$usepassword" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
                                printLog "[INFO]" "$mysqlcommanddump -u root -p$password --routines --triggers --events --set-gtid-purged=OFF --all-databases > all-databases.$hostname.$todate.dump"
                                $mysqlcommanddump -u root -p$password --routines --triggers --events --set-gtid-purged=OFF --all-databases > all-databases.$hostname.$todate.dump
                        else
                                printLog "[INFO]" "$mysqlcommanddump -u root --routines --triggers --events --set-gtid-purged=OFF --all-databases > all-databases.$hostname.$todate.dump"
printLog "[INFO]" "Capture dmesg_$hostname.$todate.txt"
                                $mysqlcommanddump -u root --routines --triggers --events --set-gtid-purged=OFF --all-databases > all-databases.$hostname.$todate.dump
                        fi
                        setGlobalPxc_strict_mode "ENFORCING"
                else
						if [ -z "$usepassword" ];then
							printLog "[INFO]" "$mysqlcommanddump -u root -p$password --routines --all-databases > all-databases.$hostname.$todate.dump"
							$mysqlcommanddump -u root -p$password --routines --all-databases > all-databases.$hostname.$todate.dump
						elif [ `echo "$usepassword" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$usepassword" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
							printLog "[INFO]" "$mysqlcommanddump -u root -p$password --routines --all-databases > all-databases.$hostname.$todate.dump"
							$mysqlcommanddump -u root -p$password --routines --all-databases > all-databases.$hostname.$todate.dump
						else
							printLog "[INFO]" "$mysqlcommanddump -u root --routines --all-databases > all-databases.$hostname.$todate.dump"
							$mysqlcommanddump -u root --routines --all-databases > all-databases.$hostname.$todate.dump
						fi
                fi
        fi
fi

else
        printLog "[INFO]" "MySQL mysqldump backups disabled"
fi


########################################################
############## Elastic Search ##########################
########################################################
printLog "cleanlog" ""
printLog "============================================== ELK Backups and Captures =============================================="
if [ `echo "$ES_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$ES_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
printLog "----------------- Elastic Search -------------------"

ELKversionTrunk=$(echo "$ELKVersion" | cut -d"." -f1)
mkdir $backupSubDir/ElasticSearch_backups/
chown tango:tango $backupSubDir/ElasticSearch_backups/
if [ "$ELKversionTrunk" == "8" ];then
        printLog "[INFO]" "Capture curl_ES_cluster_versions_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword --cacert $cacert https://$ESmasterIP:$ESmasterport &> $backupSubDir/ElasticSearch_backups/curl_ES_cluster_versions_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_cluster_health_pretty_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword --cacert $cacert https://$ESmasterIP:$ESmasterport/_cluster/health?pretty &> $backupSubDir/ElasticSearch_backups/curl_ES_cluster_health_pretty_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_cat_indices_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword --cacert $cacert https://$ESmasterIP:$ESmasterport/_cat/indices &> $backupSubDir/ElasticSearch_backups/curl_ES_cat_indices_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_template_pretty_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword --cacert $cacert https://$ESmasterIP:$ESmasterport/_template?pretty &> $backupSubDir/ElasticSearch_backups/curl_ES_template_pretty_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_cat_templates_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword --cacert $cacert https://$ESmasterIP:$ESmasterport/_cat/templates?v &> $backupSubDir/ElasticSearch_backups/curl_ES_cat_templates_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_cat_aliases_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword --cacert $cacert https://$ESmasterIP:$ESmasterport/_cat/aliases &> $backupSubDir/ElasticSearch_backups/curl_ES_cat_aliases_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_cat_nodes_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword --cacert $cacert https://$ESmasterIP:$ESmasterport/_cat/nodes?v &> $backupSubDir/ElasticSearch_backups/curl_ES_cat_nodes_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_xpack_license_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword --cacert $cacert https://$ESmasterIP:$ESmasterport/_xpack/license &> $backupSubDir/ElasticSearch_backups/curl_ES_xpack_license_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_xpack_license_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword --cacert $cacert https://$ESmasterIP:$ESmasterport/_xpack?pretty &> $backupSubDir/ElasticSearch_backups/curl_ES_xpack_pretty_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_cat_shards_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword --cacert $cacert https://$ESmasterIP:$ESmasterport/_cat/shards?v &> $backupSubDir/ElasticSearch_backups/curl_ES_cat_shards_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_settings_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword --cacert $cacert https://$ESmasterIP:$ESmasterport/_settings?pretty &> $backupSubDir/ElasticSearch_backups/curl_ES_settings_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_cluster_settings_pretty_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword --cacert $cacert https://$ESmasterIP:$ESmasterport/_cluster/settings?pretty &> $backupSubDir/ElasticSearch_backups/curl_ES_cluster_settings_pretty_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_all_settings_pretty_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword --cacert $cacert https://$ESmasterIP:$ESmasterport/_all/settings?pretty &> $backupSubDir/ElasticSearch_backups/curl_ES_all_settings_pretty_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_nodes_stats_process_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword --cacert $cacert https://$ESmasterIP:$ESmasterport/_nodes/stats/process?pretty &> $backupSubDir/ElasticSearch_backups/curl_ES_nodes_stats_process_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_nodes_stats_process_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword --cacert $cacert https://$ESmasterIP:$ESmasterport/_cluster/stats?pretty &> $backupSubDir/ElasticSearch_backups/curl_ES_cluster_stats_pretty_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_cat_allocation_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword --cacert $cacert https://$ESmasterIP:$ESmasterport/_cat/allocation &> $backupSubDir/ElasticSearch_backups/curl_cat_ES_allocation_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_cat_pending_tasks_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword --cacert $cacert https://$ESmasterIP:$ESmasterport/_cat/pending_tasks?v=true &> $backupSubDir/ElasticSearch_backups/curl_ES_cat_pending_tasks_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_cat_tasks_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword --cacert $cacert https://$ESmasterIP:$ESmasterport/_cat/tasks?v=true &> $backupSubDir/ElasticSearch_backups/curl_ES_cat_tasks_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_cluster_allocation_explain_pretty_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword --cacert $cacert https://$ESmasterIP:$ESmasterport/_cluster/allocation/explain?pretty &> $backupSubDir/ElasticSearch_backups/curl_ES_cluster_allocation_explain_pretty_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_ilm_policy_pretty_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword --cacert $cacert https://$ESmasterIP:$ESmasterport/_ilm/policy?pretty &> $backupSubDir/ElasticSearch_backups/curl_ES_ilm_policy_pretty_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_cat_count_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword --cacert $cacert https://$ESmasterIP:$ESmasterport/_cat/count?v=true &> $backupSubDir/ElasticSearch_backups/curl_ES_cat_count_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_tasks_actions_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword --cacert $cacert "https://$ESmasterIP:$ESmasterport/_tasks?actions=*search&detailed&pretty" &> $backupSubDir/ElasticSearch_backups/curl_ES_cat_count_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_nodes_all_hot_threads_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword --cacert $cacert https://$ESmasterIP:$ESmasterport/_nodes/_all/hot_threads &> $backupSubDir/ElasticSearch_backups/curl_ES_nodes_all_hot_threads_$hostname.$todate.txt
else
        printLog "[INFO]" "Capture curl_ES_cluster_versions_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword $ESmasterIP:$ESmasterport &> $backupSubDir/ElasticSearch_backups/curl_ES_cluster_versions_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_cluster_health_pretty_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword $ESmasterIP:$ESmasterport/_cluster/health?pretty &> $backupSubDir/ElasticSearch_backups/curl_ES_cluster_health_pretty_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_cat_indices_$hostname.$todate.txt"
        curl -XGET -u $ESUser:$ESPassword $ESmasterIP:$ESmasterport/_cat/indices &> $backupSubDir/ElasticSearch_backups/curl_ES_cat_indices_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_template_pretty_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword $ESmasterIP:$ESmasterport/_template?pretty &> $backupSubDir/ElasticSearch_backups/curl_ES_template_pretty_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_cat_templates_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword $ESmasterIP:$ESmasterport/_cat/templates?v &> $backupSubDir/ElasticSearch_backups/curl_ES_cat_templates_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_cat_aliases_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword $ESmasterIP:$ESmasterport/_cat/aliases &> $backupSubDir/ElasticSearch_backups/curl_ES_cat_aliases_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_cat_nodes_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword $ESmasterIP:$ESmasterport/_cat/nodes?v &> $backupSubDir/ElasticSearch_backups/curl_ES_cat_nodes_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_xpack_license_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword $ESmasterIP:$ESmasterport/_xpack/license &> $backupSubDir/ElasticSearch_backups/curl_ES_xpack_license_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_xpack_license_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword $ESmasterIP:$ESmasterport/_xpack?pretty &> $backupSubDir/ElasticSearch_backups/curl_ES_xpack_pretty_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_cat_shards_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword $ESmasterIP:$ESmasterport/_cat/shards?v &> $backupSubDir/ElasticSearch_backups/curl_ES_cat_shards_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_settings_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword $ESmasterIP:$ESmasterport/_settings?pretty &> $backupSubDir/ElasticSearch_backups/curl_ES_settings_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_cluster_settings_pretty_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword $ESmasterIP:$ESmasterport/_cluster/settings?pretty &> $backupSubDir/ElasticSearch_backups/curl_ES_cluster_settings_pretty_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_all_settings_pretty_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword $ESmasterIP:$ESmasterport/_all/settings?pretty &> $backupSubDir/ElasticSearch_backups/curl_ES_all_settings_pretty_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_nodes_stats_process_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword $ESmasterIP:$ESmasterport/_nodes/stats/process?pretty &> $backupSubDir/ElasticSearch_backups/curl_ES_nodes_stats_process_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_nodes_stats_process_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword $ESmasterIP:$ESmasterport/_cluster/stats?pretty &> $backupSubDir/ElasticSearch_backups/curl_ES_cluster_stats_pretty__$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_cat_pending_tasks_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword $ESmasterIP:$ESmasterport/_cat/allocation &> $backupSubDir/ElasticSearch_backups/curl_ES_cat_allocation_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_cat_tasks_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword $ESmasterIP:$ESmasterport/_cat/pending_tasks?v=true &> $backupSubDir/ElasticSearch_backups/curl_ES_cat_pending_tasks_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_cluster_allocation_explain_pretty_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword $ESmasterIP:$ESmasterport/_cluster/allocation/explain?pretty &> $backupSubDir/ElasticSearch_backups/curl_ES_cluster_allocation_explain_pretty_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_ilm_policy_pretty_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword $ESmasterIP:$ESmasterport/_ilm/policy?pretty &> $backupSubDir/ElasticSearch_backups/curl_ES_ilm_policy_pretty_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_cat_count_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword $ESmasterIP:$ESmasterport/_cat/count?v=true &> $backupSubDir/ElasticSearch_backups/curl_ES_cat_count_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_tasks_actions_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword "$ESmasterIP:$ESmasterport/_tasks?actions=*search&detailed&pretty" &> $backupSubDir/ElasticSearch_backups/curl_ES_cat_count_$hostname.$todate.txt
        printLog "[INFO]" "Capture curl_ES_nodes_all_hot_threads_$hostname.$todate.txt"
        curl -u $ESUser:$ESPassword $ESmasterIP:$ESmasterport/_nodes/_all/hot_threads &> $backupSubDir/ElasticSearch_backups/curl_ES_nodes_all_hot_threads_$hostname.$todate.txt
fi


else
        printLog "[INFO]" "Elastic Search disabled"
fi

########################################################
############ Get Tango SW and APP Backups  #############
########################################################

printLog "cleanlog" ""
printLog "============================================== Tango SW and APP Backups and Captures =============================================="

if [ `echo "$tangoSW_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$tangoSW_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then

#--- Get current and actual tango SW versions ---
printLog "----------------- Get tango SW versions -------------------------"
printLog "[INFO]" "Createing $spawnShOutFile . It didnt exist. Its ok now"
spawnShOutFile="$DIR/temp/$spawnFilesh"
if [ ! -f $spawnShOutFile ];then
        echo "#!/bin/bash
if [ \"\$1\" == \"10100\" ];then
expect <<'EOF'
spawn telnet 0 10100
expect \"assistance.\"
send \"\r\"
expect \"mon>\"
send \"a OAM_version;s display;\r\"
expect \"mon>\"
send \"quit\r\"
EOF
elif [ \"\$1\" == \"17010\" ];then
expect <<'EOF'
spawn telnet 0 17010
expect \"assistance.\"
send \"\r\"
expect \"mon>\"
send \"a OAM_version;s display;\r\"
expect \"mon>\"
send \"quit\r\"
EOF
elif [ \"\$1\" == \"17011\" ];then
expect <<'EOF'
spawn telnet 0 17011
expect \"assistance.\"
send \"\r\"
expect \"mon>\"
send \"a OAM_version;s display;\r\"
expect \"mon>\"
send \"quit\r\"
EOF
elif [ \"\$1\" == \"13030\" ];then
expect <<'EOF'
spawn telnet 0 13030
expect \"assistance.\"
send \"\r\"
expect \"mon>\"
send \"a SMPP_router;s display;\r\"
expect \"mon>\"
send \"quit\r\"
EOF
elif [ \"\$1\" == \"13031\" ];then
expect <<'EOF'
spawn telnet 0 13031
expect \"assistance.\"
send \"\r\"
expect \"mon>\"
send \"a SMPP_router;s display;\r\"
expect \"mon>\"
send \"quit\r\"
EOF
elif [ \"\$1\" == \"13032\" ];then
expect <<'EOF'
spawn telnet 0 13032
expect \"assistance.\"
send \"\r\"
expect \"mon>\"
send \"a SMPP_router;s display;\r\"
expect \"mon>\"
send \"quit\r\"
EOF
elif [ \"\$1\" == \"13033\" ];then
expect <<'EOF'
spawn telnet 0 13033
expect \"assistance.\"
send \"\r\"
expect \"mon>\"
send \"a SMPP_router;s display;\r\"
expect \"mon>\"
send \"quit\r\"
EOF
elif [ \"\$1\" == \"2000\" ];then
expect <<'EOF'
spawn telnet 0 2000
expect \"assistance.\"
send \"\r\"
expect \"mon>\"
send \"a M3UA_OM_oamIf;s display;s displayConfigFileEntries;s displayProvisionEntityTable\r\"
expect \"mon>\"
send \"quit\r\"
EOF
fi
" > $spawnShOutFile
chmod 775 $spawnShOutFile
fi

mkdir $backupSubDir/tango_software_backups/
chown tango:tango $backupSubDir/tango_software_backups/
printLog "[INFO]" "Capture tango_software_version_$hostname.$todate.txt"
checkExpectPackage
isPortOpen "10100"
if [ "isPortOpen" == "1" ];then
        $spawnShOutFile "10100" > $backupSubDir/tango_software_backups/tango_software_version_$hostname.$todate.txt
fi

if [ `echo "$IncludeServiceInterpreter" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$IncludeServiceInterpreter" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
for (( j=0;j<$SIportArrayLength;j++))
do
        printLog "[INFO]" "Capture SI_${SIportArray[$j]}_software_version_$hostname.$todate.txt"
        checkExpectPackage
        isPortOpen "${SIportArray[$j]}"
        if [ "isPortOpen" == "1" ];then
                $spawnShOutFile "${SIportArray[$j]}" > $backupSubDir/tango_software_backups/SI_${SIportArray[$j]}_software_version_$hostname.$todate.txt
        fi
done
else
        printLog "[INFO]" "SI Version is disabled"
fi


#--- Get tango SW versions ---
cdTangoDir=$(ls -altr /tango/ | grep config | egrep -v rollback | tail -1 | awk '{print $11}')
cd $cdTangoDir
cd ..
if [ -f installed_versions.txt ];then
        printLog "[INFO]" "Backup installed_versions_$hostname.$todate.txt"
        $cpCmd -rfp installed_versions.txt $backupSubDir/tango_software_backups/installed_versions_$hostname.$todate.txt
else
        printLog "[INFO]" "No backup of installed_versions_$hostname.$todate.txt, file was not found"
fi
cd $backupSubDir/tango_software_backups/

#--- Get SMPP binds. Run it only on NH nodes ---
printLog "--------------------- Get SMPP Binds ---------------------------------"
if [ `echo "$IncludeSMPP_router" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$IncludeSMPP_router" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
for (( j=0;j<$SMPP_routerportArrayLength;j++))
do
        printLog "[INFO]" "Capture Binds_SMPP_router_${SMPP_routerportArray[$j]}_$hostname.$todate.txt"
        checkExpectPackage
        isPortOpen "${SMPP_routerportArray[$j]}"
        if [ "isPortOpen" == "1" ];then
                $spawnShOutFile "${SMPP_routerportArray[$j]}" > $backupSubDir/tango_software_backups/Binds_SMPP_router_${SMPP_routerportArray[$j]}_$hostname.$todate.txt
        fi
done
else
        printLog "[INFO]" "SMPP router Binds is disabled"
fi

#--- Get SMPP binds. Run it only on NH nodes ---
printLog "--------------------- Capture Sigtran Associations--------------------"
if [ `echo "$Includesigtran" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$Includesigtran" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
for (( j=0;j<$M3UAportArrayLength;j++))
do
        printLog "[INFO]" "Capture M3UA_${M3UAportArray[$j]}_$hostname.$todate.txt"
        checkExpectPackage
        isPortOpen "${M3UAportArray[$j]}"
        if [ "isPortOpen" == "1" ];then
                $spawnShOutFile "${M3UAportArray[$j]}" > $backupSubDir/tango_software_backups/M3UA_${M3UAportArray[$j]}_$hostname.$todate.txt
        fi
done
        printLog "[INFO]" "Capture sigtranAssociations_$hostname.$todate.txt"
        netstat --sctp -n > $backupSubDir/tango_software_backups/sigtranAssociations_$hostname.$todate.txt
else
        printLog "[INFO]" "Sigtran Status is disabled"
fi

#--- Get tango SW softlinks
printLog "----------------- Capture tango SW softlinks-----------------------"
printLog "[INFO]" "Capture TangoSoftlinks_$hostname.$todate.txt"
ls -altr /tango/ > $backupSubDir/tango_software_backups/TangoSoftlinks_$hostname.$todate.txt


#--- Backup pmlogs
printLog "-----------------Backup Last pm.log -------------------------------------"
checkTargetPartitionFreeSpace "copy" "/tango/logs/process/pm.log"
if [ "$skipBackupFlag" == "0" ];then
        printLog "[INFO]" "Backup pmlogs_$hostname.$todate.txt"
        $cpCmd -rfp /tango/logs/process/pm.log $backupSubDir/tango_software_backups/pm.log_$hostname.$todate.txt
fi

#--- Backup /tango/config ---
printLog "----------------- Backup /tango/config/ And /tango/bin/ -------------"
checkTargetPartitionFreeSpace "tar" "/tango/config/"
if [ "$skipBackupFlag" == "0" ];then
        printLog "[INFO]" "Capture /tango/config/ tree and permissions"
        $treeCmd -pug /tango/config/ > $backupSubDir/tango_software_backups/tango_config_directory_tree_permissions_$hostname.$todate.txt;
        printLog "[INFO]" "Backup config_$hostname.$todate.tar"
        cd /tango/config
        tar -cf config_$hostname.$todate.tar *
        cd $backupSubDir/tango_software_backups
        mv /tango/config/config_$hostname.$todate.tar $backupSubDir/tango_software_backups/
fi

if [ `echo "$IncludeTangoBinaries" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$IncludeTangoBinaries" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
        checkTargetPartitionFreeSpace "tar" "/tango/bin/"
        if [ "$skipBackupFlag" == "0" ];then
                printLog "[INFO]" "Backup bin_$hostname.$todate.tar.bz2"
                cd /tango/bin
                tar -cf bin_$hostname.$todate.tar *
                cd $backupSubDir/tango_software_backups
                mv /tango/bin/bin_$hostname.* $backupSubDir/tango_software_backups/
                bzip2 $backupSubDir/tango_software_backups/bin_$hostname.$todate.tar
        fi
else
        printLog "[INFO]" "Backing up /tango/bin directory is disabled. However, perl and /tango/bin/*.sh scripts will be backed up under $backupSubDir/tango_software_backups/tango_binaries_shell_binaries/"
        mkdir $backupSubDir/tango_software_backups/tango_binaries_shell_binaries/
        cp -rfp /tango/bin/*.sh $backupSubDir/tango_software_backups/tango_binaries_shell_binaries/
        cp -rfp /tango/bin/*.pl $backupSubDir/tango_software_backups/tango_binaries_shell_binaries/
fi


#--- Get binaries list. It is not a backup since it would be too big and binaries are available at thor. Just get the list of them ---
printLog "[INFO]" "Capture list of tango binaries /tango/bin/ tree and permissions"
$treeCmd -pug /tango/bin/ > $backupSubDir/tango_software_backups/tango_binaries_directory_tree_$hostname.$todate.txt;

#--- Get status of processes running ---
printLog "[INFO]" "Get mps status"
if [ -f /tango/bin/mps ];then
        /tango/bin/mps > $backupSubDir/tango_software_backups/mps_$hostname.$todate.txt
else
        printLog "[ERROR]" "/tango/bin/mps cannot be found. mps status cannot be captured"
        echo -e "\n${red}/tango/bin/mps cannot be found. mps status cannot be captured\n${reset}"
fi

#--- backup tango scripts ---
printLog "----------------- Backup /tango/scripts/ -------------------------"
if [ `echo "$IncludeTangoScripts" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$IncludeTangoScripts" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
        checkTargetPartitionFreeSpace "tar" "/tango/scripts/"
        if [ "$skipBackupFlag" == "0" ];then
                printLog "[INFO]" "Capture /tango/scripts/ tree and permissions"
                $treeCmd -pug /tango/scripts/ > $backupSubDir/tango_software_backups/tango_scripts_directory_tree_permissions_$hostname.$todate.txt;
                printLog "[INFO]" "Backup tango_scripts_$hostname.$todate.tar.bz2"
                cd /tango/scripts/
                $tarCmd -cf tango_scripts_$hostname.$todate.tar --exclude={*.log,*/*.log,*/*/*.log,*/*/*/*.log,*/*/*/*/*.log} *
                $chownCmd tango:tango tango_scripts_$hostname.$todate.tar
                cd $backupSubDir/tango_software_backups
                mv /tango/scripts/tango_scripts_$hostname.$todate.tar $backupSubDir/tango_software_backups/
                bzip2 $backupSubDir/tango_software_backups/tango_scripts_$hostname.$todate.tar
        fi
else
        printLog "[INFO]" "Backing up /tango/scripts directory is disabled"
fi

#--- backup tango .ssh tango directory ---
printLog "----------------- Backup $homeDirectory/.ssh/ -----------------------"
checkTargetPartitionFreeSpace "tar" "$homeDirectory/.ssh/"
if [ "$skipBackupFlag" == "0" ];then
        printLog "[INFO]" "tango_sshDir_$hostname.$todate.tar"
        cd $homeDirectory/.ssh/
        tar -cf tango_sshDir_$hostname.$todate.tar *
        cd $backupSubDir/tango_software_backups
        mv $homeDirectory/.ssh/tango_sshDir_$hostname.$todate.tar $backupSubDir/tango_software_backups/
fi

#--- List all subdirectories that exist under user_data, cdr and root directories ---
printLog "------------------ Capture trees for important directories --------------------"
printLog "[INFO]" "Capture user_data_directory_tree_$hostname.$todate.txt"
$treeCmd -pug /tango/data/user_data/ > $backupSubDir/tango_software_backups/user_data_directory_tree_$hostname.$todate.txt
printLog "[INFO]" "Capture cdr_directory_$hostname.$todate.txt"
$treeCmd -pug /tango/data/cdr/ > $backupSubDir/tango_software_backups/cdr_directory_$hostname.$todate.txt

#--- Backup tango license ----
printLog "------------------ Backup tango license --------------------------"
checkTargetPartitionFreeSpace "tar" "/tango/license/"
if [ "$skipBackupFlag" == "0" ];then
        cd /tango/license/
        tar -cf TangoLicense_$hostname.$todate.tar *
        cd $backupSubDir/tango_software_backups
        mv /tango/license/TangoLicense_$hostname.$todate.tar $backupSubDir/tango_software_backups/
        printLog "[INFO]" "Backup TangoLicense_$hostname.$todate.tar"
fi

#--- backup tango .bashrc and .bash_profile files
printLog "---------- Backup .bashrc .bash_history and .bash_profile --------"
checkTargetPartitionFreeSpace "copy" "$homeDirectory/.bashrc"
if [ "$skipBackupFlag" == "0" ];then
        printLog "[INFO]" "Backup bashrc_tango_$hostname.$todate.txt"
        $cpCmd -rfp $homeDirectory/.bashrc $backupSubDir/tango_software_backups/bashrc_tango_$hostname.$todate.txt
fi
checkTargetPartitionFreeSpace "copy" "$homeDirectory/.bash_history"
if [ "$skipBackupFlag" == "0" ];then
        printLog "[INFO]" "Backup bash_history_tango_$hostname.$todate.txt"
        $cpCmd -rfp $homeDirectory/.bash_history $backupSubDir/tango_software_backups/bash_history_tango_$hostname.$todate.txt
fi
checkTargetPartitionFreeSpace "copy" "$homeDirectory/.bash_profile"
if [ "$skipBackupFlag" == "0" ];then
        printLog "[INFO]" "Backup bash_profile_tango_$hostname.$todate.txt"
        $cpCmd -rfp $homeDirectory/.bash_profile $backupSubDir/tango_software_backups/bash_profile_tango_$hostname.$todate.txt
fi

#--- Backup tango crontab ---
printLog "------------------- Backup Tango Crontab -------------------------"
checkTargetPartitionFreeSpace "copy" "/var/spool/cron/tango"
if [ "$skipBackupFlag" == "0" ];then
        printLog "[INFO]" "Backup tango_crontab_$hostname.$todate.txt"
        $cpCmd -rfp /var/spool/cron/tango $backupSubDir/tango_software_backups/tango_crontab_$hostname.$todate.txt
fi

printLog "-------------------- Backup S70tangonet --------------------------"
#--- Backup S70tangonet startup script ---
if [ "$iam" == "root" ];then
        if [ -f /etc/rc2.d/S70tangonet ];then
                printLog "[INFO]" "Backup S70tangonet_$hostname.$todate.txt"
                $catCmd /etc/rc2.d/S70tangonet > $backupSubDir/tango_software_backups/S70tangonet_$hostname.$todate.txt
        else
                 printLog "[INFO]" "/etc/rc2.d/S70tangonet does not exist. Backup S70tangonet is skipped"
        fi
else
        if sudo test -f "/etc/rc2.d/S70tangonet";then
                printLog "[INFO]" "Backup S70tangonet_$hostname.$todate.txt"
                $catCmd /etc/rc2.d/S70tangonet > $backupSubDir/tango_software_backups/S70tangonet_$hostname.$todate.txt
        else
                 printLog "[INFO]" "/etc/rc2.d/S70tangonet does not exist. Backup S70tangonet is skipped"
        fi
fi

else
        printLog "------------------ Backup tango SW --------------------------"
        printLog "[INFO]" "Tango SW disabled"

fi


#########################################################################################
####################### Backup Operative System #########################################
#########################################################################################
printLog "cleanlog" ""
printLog "============================================== Operative System Backups and Captures =============================================="

if [ `echo "$OS_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$OS_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
mkdir $backupSubDir/OperativeSystem_backups/
$chownCmd tango:tango $backupSubDir/OperativeSystem_backups/
printLog "[INFO]" "Capture root_directory_tree_depth2_$hostname.$todate.txt"
$treeCmd -pug -L 2 / > $backupSubDir/OperativeSystem_backups/root_directory_tree_depth2_$hostname.$todate.txt

printLog "----------- Genearting Operative System Backups & Captures ----------"
#--- Operative System Details ---
printLog "[INFO]" "Capture uname_a_$hostname.$todate.txt"
uname -a > $backupSubDir/OperativeSystem_backups/uname_a_$hostname.$todate.txt

printLog "[INFO]" "Backup redhad_release_$hostname.$todate.txt"
$catCmd /etc/redhat-release > $backupSubDir/OperativeSystem_backups/redhad_release_$hostname.$todate.txt

#--- Java details ---
printLog "[INFO]" "Capture which_java_$hostname.$todate.txt"
which java > $backupSubDir/3rdPartySW_backups/which_java_$hostname.$todate.txt
java -fullversion 2>&1|awk "{print $NF}" > $backupSubDir/3rdPartySW_backups/javaFullVersion_$hostname.$todate.txt

#--- Get current disk status ---
printLog "[INFO]" "Capture disk_space_$hostname.$todate.txt"
df -h > $backupSubDir/OperativeSystem_backups/disk_space_$hostname.$todate.txt

#--- Get ip rules ---
printLog "[INFO]" "Capture ip_rule_show_$hostname.$todate.txt"
ip rule show > $backupSubDir/OperativeSystem_backups/ip_rule_show_$hostname.$todate.txt

#--- Get current arp table ---
printLog "[INFO]" "Capture arp_table_$hostname.$todate.txt"
arp 2>&1|awk "{print $NF}" > $backupSubDir/OperativeSystem_backups/arp_table_$hostname.$todate.txt

#--- Get current memory status ---
printLog "[INFO]" "Capture free_a_$hostname.$todate.txt"
free -m > $backupSubDir/OperativeSystem_backups/free_a_$hostname.$todate.txt
if [ "$OSversion" == "rhel7" ] || [ "$OSversion" == "rhel8" ];then
        #--- Get current systemctl_services ---
        printLog "[INFO]" "Capture systemctl_servcies_$hostname.$todate.txt"
        systemctl -t service --state=active > $backupSubDir/OperativeSystem_backups/systemctl_servcies_$hostname.$todate.txt
        printLog "[INFO]" "Capture systemctl_get-default_$hostname.$todate.txt"
        systemctl get-default > $backupSubDir/OperativeSystem_backups/systemctl_get-default_$hostname.$todate.txt
        printLog "[INFO]" "Capture who-r_$hostname.$todate.txt"
        who -r > $backupSubDir/OperativeSystem_backups/who-r_$hostname.$todate.txt
        printLog "[INFO]" "Capture last 1000 lines journalctl_$hostname.$todate.txt"
        journalctl -n 1000 --no-pager > $backupSubDir/OperativeSystem_backups/capture_last_1000lines_journalctl_$hostname.$todate.txt
        printLog "[INFO]" "Capture sysctl-a_$hostname.$todate.txt"
        $sysctlCmd -a > $backupSubDir/OperativeSystem_backups/sysctl-a_$hostname.$todate.txt
else
        #--- Get current service_status_all ---
        printLog "[INFO]" "Capture service_status_all_$hostname.$todate.txt"
        service --status-all > $backupSubDir/OperativeSystem_backups/service_status_all_$hostname.$todate.txt
        printLog "[INFO]" "Capture who-r_$hostname.$todate.txt"
        who -r > $backupSubDir/OperativeSystem_backups/who-r_$hostname.$todate.txt
        printLog "[INFO]" "Capture sysctl-a_$hostname.$todate.txt"
        $sysctlCmd -a > $backupSubDir/OperativeSystem_backups/sysctl-a_$hostname.$todate.txt
fi




#--- Backup etc directory ---
printLog "----------------- Backup /etc/ Directory -----------------------"
checkTargetPartitionFreeSpace "tar" "/etc/"
if [ "$skipBackupFlag" == "0" ];then
        printLog "[INFO]" "Capture / etc directory tree and permissions"
        $treeCmd -pug /etc/ > $backupSubDir/OperativeSystem_backups/etcDirectory_tree_$hostname.$todate.txt
        printLog "[INFO]" "Backup etcDirectory_$hostname.$todate.tar.bz2"
        cd /etc/
        $tarCmd -cf etcDirectory_$hostname.$todate.tar * 2> >(grep -v 'socket ignored' >&2)
        cd $backupSubDir/OperativeSystem_backups
        $mvCmd /etc/etcDirectory_$hostname.$todate.tar $backupSubDir/OperativeSystem_backups/
        bzip2 $backupSubDir/OperativeSystem_backups/etcDirectory_$hostname.$todate.tar
fi

#--- Backup usr directory ---
printLog "----------------- Backup /usr/ Directory -----------------------"
if [ `echo "$IncludeusrDirectory" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$IncludeusrDirectory" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
        checkTargetPartitionFreeSpace "tar" "/usr/"
        if [ "$skipBackupFlag" == "0" ];then
                printLog "[INFO]" "Backup usrDirectory_$hostname.$todate.tar.bz2"
                cd /usr/
                $tarCmd -cf usrDirectory_$hostname.$todate.tar *
                cd $backupSubDir/OperativeSystem_backups
                $mvCmd /usr/usrDirectory_$hostname.$todate.tar $backupSubDir/OperativeSystem_backups/
                bzip2 $backupSubDir/OperativeSystem_backups/usrDirectory_$hostname.$todate.tar
        fi
else
        printLog "[INFO]" "Backup /usr/ is not enabled. So, it wont be backed up"
fi


#--- Backup crontab files ---
printLog "----------------- Backup Crontab Files  -----------------------"
checkTargetPartitionFreeSpace "tar" "/var/spool/cron/"
if [ "$skipBackupFlag" == "0" ];then
        cd $backupSubDir/OperativeSystem_backups
        printLog "[INFO]" "Backup crontabs_$hostname.$todate.tar"
        $tarCmd -cf crontabs_$hostname.$todate.tar -P -C $backupSubDir/OperativeSystem_backups /var/spool/cron/
fi
#--- backup root .bashrc and .bash_profile files
printLog "----- Backup root .bashrc .bash_history and .bash_profile ------"
checkTargetPartitionFreeSpace "copy" "/root/.bashrc"
if [ "$skipBackupFlag" == "0" ];then
        printLog "[INFO]" "Backup bashrc_root_$hostname.$todate.txt"
        $cpCmd -rfp /root/.bashrc $backupSubDir/OperativeSystem_backups/bashrc_root_$hostname.$todate.txt
fi
checkTargetPartitionFreeSpace "copy" "/root/.bash_history"
if [ "$skipBackupFlag" == "0" ];then
        printLog "[INFO]" "Backup bash_history_root_$hostname.$todate.txt"
        $cpCmd -rfp /root/.bash_history $backupSubDir/OperativeSystem_backups/bash_history_root_$hostname.$todate.txt
fi
checkTargetPartitionFreeSpace "copy" "/root/.bash_profile"
if [ "$skipBackupFlag" == "0" ];then
        printLog "[INFO]" "Backup bash_profile_root_$hostname.$todate.txt"
        $cpCmd -rfp /root/.bash_profile $backupSubDir/OperativeSystem_backups/bash_profile_root_$hostname.$todate.txt
fi

printLog "-------- Backup interfaces -----------------------------------"
#--- Get interfaces status ---
printLog "[INFO]" "Capture ip_addr_grep_inet_$hostname.$todate.txt"
ip addr | grep "^ *inet " > $backupSubDir/OperativeSystem_backups/ip_addr_grep_inet_$hostname.$todate.txt
printLog "[INFO]" "Capture ip_addr_show_$hostname.$todate.txt"
ip addr show > $backupSubDir/OperativeSystem_backups/ip_addr_show_$hostname.$todate.txt
printLog "[INFO]" "Capture ifconfga_$hostname.$todate.txt"
ifconfig -a > $backupSubDir/OperativeSystem_backups/ifconfga_$hostname.$todate.txt

#--- Backup all ifcfg files
cd $backupSubDir/OperativeSystem_backups/
$llCmd /etc/sysconfig/network-scripts/ifcfg* | awk '{print $9}' | while read in
do
        getifcfgname=$(echo "$in" | rev | cut -d"/" -f1 | rev)
        checkTargetPartitionFreeSpace "copy" "$in"
        if [ "$skipBackupFlag" == "0" ];then
                printLog "[INFO]" "Backup $getifcfgname.$hostname.$todate.back"
                $cpCmd -rfp $in $backupSubDir/OperativeSystem_backups/$getifcfgname.$hostname.$todate.back
        fi
done

#--- Capture dmesg status
dmesg > $backupSubDir/OperativeSystem_backups/dmesg_$hostname.$todate.txt

printLog "-------- Backup routing configuration ------------------------"
#--- Backup routing table ---
printLog "[INFO]" "Capture netstat_rn_routes_$hostname.$todate.txt"
netstat -rn > $backupSubDir/OperativeSystem_backups/netstat_rn_routes_$hostname.$todate.txt
printLog "[INFO]" "Capture ip_route_show_table_main_weights_$hostname.$todate.txt"
ip route show table main > ip_route_show_table_main_weights_$hostname.$todate.txt

#--- Backup all persistent route files
printLog "-------- Backup persisten route files ------------------------"
cd $backupSubDir/OperativeSystem_backups/
isThereRouteFiles=$($llCmd /etc/sysconfig/network-scripts/ | grep "route-"  | egrep -v grep)
if [ -z "$isThereRouteFiles" ];then
        printLog "[INFO]" "No route-xxx files under network-scripts"
else
        $llCmd /etc/sysconfig/network-scripts/route* | awk '{print $9}' | while read in
        do
                getroutename=$(echo "$in" | rev | cut -d"/" -f1 | rev)
                checkTargetPartitionFreeSpace "copy" "$in"
                if [ "$skipBackupFlag" == "0" ];then
                        printLog "[INFO]" "Backup $getroutename.$hostname.$todate.back"
                        $cpCmd -rfp $in $backupSubDir/OperativeSystem_backups/$getroutename.$hostname.$todate.back
                fi
        done
fi

#--- Get NTP/Chrony status. ---
if [ "$OSversion" != "rhel8" ];then
        printLog "-------- Capture ntp status ---------------------------------"
        /usr/sbin/ntpq -p > $backupSubDir/3rdPartySW_backups/ntp_$hostname.$todate.txt
        printLog "[INFO]" "Capture ntp_$hostname.$todate.txt"
elif [ "$OSversion" == "rhel8" ];then
        getChronyPkg=$(yum list chrony | grep Installed)
        if [ -z "$getChronyPkg" ];then
                printLog "[WARNING] chrony is not installed. Run yum install chrony"
                echo -e "\n${red}[WARNING] chrony is not installed. Run yum install chrony\n${reset}"
        else
                printLog "[INFO]" "Capture chronyc_tracking_$hostname.$todate.txt"
                /usr/bin/chronyc tracking > $backupSubDir/3rdPartySW_backups/chronyc_tracking_$hostname.$todate.txt
                printLog "[INFO]" "Capture chronyc_sources_$hostname.$todate.txt"
                /usr/bin/chronyc sources > $backupSubDir/3rdPartySW_backups/chronyc_sources_$hostname.$todate.txt
                printLog "[INFO]" "Capture chronyc_sourcestats_$hostname.$todate.txt"
                /usr/bin/chronyc sourcestats > $backupSubDir/3rdPartySW_backups/chronyc_sourcestats_$hostname.$todate.txt
        fi
fi

#--- Measure Command Speed
printLog "--------  Measure Command Speed -----------------------------"
getSarPkg=$(yum list sysstat | grep Installed)
if [ -z "$getSarPkg" ];then
    printLog "[WARNING] sar is not installed. Run yum install sysstat. Capture info is SKIPPED"
    echo -e "\n${red}[WARNING] sar is not installed. Run yum install sysstat. Capture info is SKIPPED\n${reset}"
else
	sar 5 2 > $backupSubDir/OperativeSystem_backups/sar_55_toMeasureCommandsSpeed_$hostname.$todate.txt
	printLog "[INFO]" "Capture sar_55_toMeasureCommandsSpeed_$hostname.$todate.txt"
fi

else
        printLog "------------------ Backup Operative System --------------------------"
        printLog "[INFO]" "Backing up main OS Files and captures disabled"

fi

##########################################################################################################
############# Backup Extra Directories And Files configured in OSAndTangoSW_SystemBackup.cfg #####################
##########################################################################################################

printLog "cleanlog" ""
printLog "============================================= Extra Directories and Extra Files Backups ============================================="

printLog "--------------------- Backup Extra Directories And Files configured in OSAndTangoSW_SystemBackup.cfg  ---------------------------------"
if [ `echo "$ExtraDir_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "yes" | tr -s '[:upper:]' '[:lower:]'` ] || [ `echo "$ExtraDir_enable" | tr -s '[:upper:]' '[:lower:]'` == `echo "true" | tr -s '[:upper:]' '[:lower:]'` ];then
mkdir $backupSubDir/ExtraDirectoriesAndFiles_backups/
$chownCmd tango:tango $backupSubDir/ExtraDirectoriesAndFiles_backups/
for (( j=0;j<$ExtraDirArrayLength;j++))
do
        cd ${ExtraDirArray[$j]}
        ExtraDirString=$(echo "${ExtraDirArray[$j]}")
        ExtraDirLastChar=$(echo "${ExtraDirString: -1}")
        if [ "$ExtraDirLastChar" != "/" ];then
                ExtraDirString=$(echo "${ExtraDirArray[$j]}""/")
        fi
        getDirName=$(echo "$ExtraDirString" | rev | cut -d"/" -f2 | rev)
        checkTargetPartitionFreeSpace "tar" "${ExtraDirArray[$j]}"
        if [ "$skipBackupFlag" == "0" ];then
                printLog "[INFO]" "Capture ${ExtraDirArray[$j]} directory tree and permissions"
                $treeCmd -pug ${ExtraDirArray[$j]} > $backupSubDir/ExtraDirectoriesAndFiles_backups/$getDirName\_directory_tree_and_permissions_$hostname.$todate.txt
                printLog "[INFO]" "Backup ExtraDir_$getDirName.$hostname.$todate.tar"
                $tarCmd -cf ExtraDir_$getDirName.$hostname.$todate.tar --exclude={*.log,*/*.log,*/*/*.log,*/*/*/*.log,*/*/*/*/*.log} *
                cd $backupSubDir/ExtraDirectoriesAndFiles_backups
                $mvCmd ${ExtraDirArray[$j]}/ExtraDir_$getDirName.$hostname.$todate.tar $backupSubDir/ExtraDirectoriesAndFiles_backups/
        fi
done
for (( j=0;j<$ExtraFilesArrayLength;j++))
do
        checkTargetPartitionFreeSpace "copy" "${ExtraFilesArray[$j]}"
        if [ "$skipBackupFlag" == "0" ];then
                printLog "[INFO]" "Backup ${ExtraFilesArray[$j]}.$hostname.$todate.tar"
                $cpCmd ${ExtraFilesArray[$j]} $backupSubDir/ExtraDirectoriesAndFiles_backups/
        fi
done
else
        printLog "[INFO]" "Backup Extra Directories And Files is disabled"
fi


##########################################################################################################
#################################### Compress $backupDir/  ###############################################
##########################################################################################################
printLog "cleanlog" ""
printLog "============================================= Compress $backupDir/ ============================================="
printLog "[INFO]" "Set tango permissions recursevely for $BackupFileVersionAndName.$hostname.$today and Compress it => $backupDir.tar"
cd $BackupSubDirectory
$chownCmd -R tango:tango $BackupFileVersionAndName.$hostname.$today
tar -cf $backupDir.tar --remove-files $BackupFileVersionAndName.$hostname.$today -P
chown tango:tango $backupDir.tar


printLog "cleanlog" "##################################### End Backup process #####################################\n\n"