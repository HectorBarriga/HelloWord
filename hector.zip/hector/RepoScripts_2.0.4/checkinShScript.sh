#!/bin/bash

# Initial Settings
site=MOBILYOCSTRIAL #TELEFONICA
#gitServerName=GIT_SERVER_ansible_playbooks_roles_iAX-Platform
gitServerName=GIT_SERVER_ansible_playbooks_roles_PCF_smpc-cicd
#gitServerName=GIT_SERVER_ansible_playbooks_roles_ELK
gitSite=Mobily
checkContainersEtcHosts=yes
dockerServerIP=10.14.38.112
randomRange='A-N'
blackliststring1=NAC
blackliststring2=DMZ
blackliststring3=NAC
if [ -z "$blackliststring1" ];then
        blackliststring1='none'
fi
if [ -z "$blackliststring2" ];then
        blackliststring2='none'
fi
if [ -z "$blackliststring3" ];then
        blackliststring3='none'
fi


todayExt=$(perl -e '@d=localtime time()-84600; printf "%4d%02d%02d%02d%02d%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1],$d[0]')
hostname=$(hostname)
argument=$(echo "$1" | tr '[:upper:]' '[:lower:]')

chkContainersEtcHosts()
{
        getGitLabEtcHosts=$(docker exec -it --user 0 gitlab-server sh -c "grep $dockerServerIP /etc/hosts | wc -l")
        getJenkinsEtcHosts=$(docker exec -it --user 0 jenkinks-server sh -c "grep $dockerServerIP /etc/hosts | wc -l")
        GitLabEtcHosts="${getGitLabEtcHosts/$'\r'/}"
        JenkinsEtcHosts="${getJenkinsEtcHosts/$'\r'/}"
        if [ "$GitLabEtcHosts" -ne 1 ];then
                echo -e "\n`tput setaf 1`Sorry, GitLab container /etc/hosts is not Ok. $dockerServerIP is missing. Bye`tput sgr0`\n"
                exit
        elif [ "$JenkinsEtcHosts" -ne 1 ];then
                echo -e "\n`tput setaf 1`Sorry, Jenkins container /etc/hosts is not Ok. $dockerServerIP is missing. Bye`tput sgr0`\n"
                exit
        fi
}

gitSub()
{
echo "`tput setaf 3`---------------------------------------------------------------`tput sgr0`"
versionT=$(cd /tango/logs/COSTAFF/hector/RepoScripts/;git log | grep RepoScripts | egrep -v -i merge | head -1 | cut -d'_' -f3)
version=$(echo "$versionT" | awk -F'.' '{print "_"$1"."$2"."}')
versionTag=$(echo "$versionT" | awk -F'.' '{print $1"."$2"."}')
newVersionP=$(echo "$versionT" | awk -F'.' '{print $3}')
newVersion=$((newVersionP+1))
echo "`tput setaf 6`
 ██████  ██ ████████ 
██       ██    ██    
██   ███ ██    ██ 
██    ██ ██    ██ 
 ██████  ██    ██ 

"
echo "# ADD AND COMMIT"
echo "cd /tango/logs/COSTAFF/hector/RepoScripts/;"
echo "git diff;"
echo "git log;"
echo "git status -s;"
echo "git add $realFile;"
echo "git status -s;"
echo "git commit -m 'RepoScripts_$hostname$version$newVersion';"
echo "git tag -a $versionTag$newVersion -m \"RepoScripts_$hostname$version$newVersion\";"
echo "git tag -l;"
echo "git log;"
echo "# MERGE MASTER REPO WITH LOCAL REPO (PULL)"
echo "git branch -r;"
echo "git branch -a;"
echo "git pull GIT_SERVER_RepoScripts master;"
echo "# PUSH (CHECK IN)"
echo "git branch -r;"
echo "git branch -a;"
echo "git push GIT_SERVER_RepoScripts master"
echo "ssh IPXMIATCNH1 \"git --git-dir /tango/logs/COSTAFF/hector/GIT_SERVER_RepoScripts/ log\""
lastCommit=$(git --git-dir /tango/logs/COSTAFF/hector/RepoScripts/.git/ log | grep commit | head -1 | awk '{print $2}')
echo "git show"
}

gitLabSub()
{
getLastTagVersion=$(git log | grep $hostname | head -1 | rev | cut -d'.' -f 1 | rev )
getFirstPartTagVersion=$(git log | grep $hostname | head -1 | rev | cut -d'.' -f 2- | rev | sed 's/^ *//g' )
newTagVersion=$((getLastTagVersion+1))
getLastTagVersion=$(git log | grep $hostname | head -1 | sed 's/^ *//g')
echo -n -e  "`tput setaf 3`\nLast commit was `tput setaf 2`$getLastTagVersion `tput setaf 3` Enter new version [Default = `tput sgr0`$getFirstPartTagVersion.$newTagVersion `tput setaf 3`] > `tput sgr0`"
read respNewTagVersion
if [ -z "$respNewTagVersion" ];then
        respNewTagVersion="$getFirstPartTagVersion"".""$newTagVersion"
fi
newVersion=$(echo "$getFirstPartTagVersion.$newTagVersion" | rev | cut -d'_' -f 1 | rev)
checkLocalGitServer=$(git remote -v | grep "$gitServerName" | wc -l)
echo ""
echo "`tput setaf 6`
 ██████  ██ ████████ ██       █████  ██████
██       ██    ██    ██      ██   ██ ██   ██
██   ███ ██    ██    ██      ███████ ██████
██    ██ ██    ██    ██      ██   ██ ██   ██
 ██████  ██    ██    ███████ ██   ██ ██████

"
echo "-------------------------------------------------------------"
echo "`tput setaf 5`The following lines have not been run. You can run them manually`tput sgr0`"
echo "-------------------------------------------------------------"
echo "git add .;
git commit -m \"$respNewTagVersion\";
git tag -a $newVersion -m \"$respNewTagVersion\";"
if [ "$checkLocalGitServer" -eq "0" ];then
        echo "git remote add $gitServerName /tango/data/user_data/$gitSite/$gitServerName;
git push $gitServerName master;"
fi
echo "git push -u origin master;"
echo "-------------------------------------------------------------"
}

if [ "$1" == "-h" ];then
        echo "
        Usage: checkinShScript.sh

        This sh script is to checkin Hector RepoScripts

        Version:     0.1.0
        Author:      Hector Barriga
        Copyright (c) Tango Telecom 2021

               Options:

               -h <help>                Show help

               NoSCP         It does not scp new script to all clusters. Default = SCP to all cluster under /tango/logs/COSTAFF/hector/sh_scripts/ and /tango/logs/COSTAFF/hector/BackupRepoScripts/

               gitlab        It checks in repositories onto gitlab

               Examples:

               e.g. checkinShScript.sh
                    Copy and propagate new script all over the clusters and Git commands

               e.g. checkinShScript.sh NoSCP
                    Only Git commands and copy new script under RepScripts GIT dir. It does not scp new script to all clusters

               e.g. checkinShScript.sh gitlab
                    It checks in repositories onto gitlab

               "
        exit
elif [ "$argument" == "gitlab" ];then
        if [ "$checkContainersEtcHosts" == "yes" ];then
                chkContainersEtcHosts
        fi
        pwdDir=$(pwd)
        echo -n -e "`tput setaf 3`\nYou are going to PUSH from this current path $pwdDir/ Are you sure you want to push from this directory? [Default = y] (y/n) >`tput sgr0` "
        read response
        if [ -z "$response" ] || [ "$response" == "y" ];then
                gitLabSub
        else
                echo "You didn't enter \"y\", Bye."
        fi
        exit
fi

cd /tango/logs/COSTAFF/hector/sh_scripts/
ls -altr /tango/logs/COSTAFF/hector/sh_scripts/
echo "`tput setaf 3`---------------------------------------------------------------`tput sgr0`"
lastFile=$(ls -altr /tango/logs/COSTAFF/hector/sh_scripts/ | egrep -v "drw" | tail -1 | awk '{print $9}')
echo -n "Enter file you would like to checkin [Default = $lastFile] > "
read file
if [ -z "$file" ];then
        file=$lastFile
fi
echo "`tput setaf 3`---------------------------------------------------------------`tput sgr0`"
if [ ! -d /tango/logs/COSTAFF/hector/BackupRepoScripts/ ];then
        mkdir /tango/logs/COSTAFF/hector/BackupRepoScripts/
fi

if [ "$site" == "TELEFONICA" ];then
        #localtangoname=$(cat /etc/hosts | grep "$hostname" | grep tango | egrep '#' | awk '/IPXMIATCNAC/ || /DMZ/' | egrep -v "# RTE" | awk '{print $4'})
        localtangoname=$(cat /etc/hosts | grep "$hostname" | grep tango | egrep '#' | egrep -v $blacklistsrting1 | egrep -v $blacklistsrting2 | egrep -v $blacklistsrting3 | awk '{print $4'})
        i=0
        while [ $i = 0 ];
        do
                #randomLetter=$(cat /dev/urandom| tr -dc 'S-V'|head -c 1)
                randomLetter=$(cat /dev/urandom| tr -dc "$randomRange" |head -c 1)
                remHost="tango$randomLetter"
                if [ "$remHost" != "$localtangoname" ];then
                        i=1
                fi
        done
elif [ "$site" == "MOBILYOCSTRIAL" ];then
        localtangoname=$(cat /etc/hosts | grep "$hostname" | grep tango | egrep '#' | awk '{print $5'})
        i=0
        while [ $i = 0 ];
        do
                randomLetter=$(cat /dev/urandom| tr -dc 'A-C'|head -c 1)
                remHost="tango$randomLetter"
                if [ "$remHost" != "$localtangoname" ];then
                        i=1
                fi
        done
fi
echo "`tput setaf 3`---------------------------------------------------------------`tput sgr0`"
echo "`tput setaf 2`Backing up FROM ramdon remote machine = $remHost. Note, backing up FROM local machine $hostname doesnt make sence since original file has been already modified and you must have already backed it up`tput sgr0`"
echo "`tput setaf 3`---------------------------------------------------------------`tput sgr0`"
realPath=$(realpath "$file")
realPathDir=$(echo $realPath | rev | cut -d"/" -f 2- | rev)
realFile=$(echo $realPath | rev | cut -d"/" -f1 | rev)
echo "`tput setaf 2`scp  tango@$remHost:$realPathDir/$realFile /tango/logs/COSTAFF/hector/BackupRepoScripts/$realFile.$remHost.$todayExt`tput sgr0`"
scp  tango@$remHost:$realPathDir/$realFile /tango/logs/COSTAFF/hector/BackupRepoScripts/$realFile.$remHost.$todayExt
echo "`tput setaf 3`---------------------------------------------------------------`tput sgr0`"
if [ "$1" != "NoSCP" ];then
        echo "`tput setaf 6`
        ███████  ██████ ██████      ███    ██ ███████ ██     ██     ███████  ██████ ██████  ██ ██████  ████████ 
        ██      ██      ██   ██     ████   ██ ██      ██     ██     ██      ██      ██   ██ ██ ██   ██    ██    
        ███████ ██      ██████      ██ ██  ██ █████   ██  █  ██     ███████ ██      ██████  ██ ██████     ██ 
             ██ ██      ██          ██  ██ ██ ██      ██ ███ ██          ██ ██      ██   ██ ██ ██         ██ 
        ███████  ██████ ██          ██   ████ ███████  ███ ███      ███████  ██████ ██   ██ ██ ██         ██ 
        "
        echo "`tput setaf 2`/tango/logs/COSTAFF/hector/sh_scripts/scpCluster.sh $realPathDir/$realFile`tput sgr0`"
        /tango/logs/COSTAFF/hector/sh_scripts/scpCluster.sh $realPathDir/$realFile
        echo "`tput setaf 3`---------------------------------------------------------------`tput sgr0`"
fi
if [ "$1" != "NoSCP" ];then
        echo "`tput setaf 2`/tango/logs/COSTAFF/hector/sh_scripts/scpCluster.sh -f $realPathDir/$realFile -d /tango/logs/COSTAFF/hector/RepoScripts/`tput sgr0`"
        /tango/logs/COSTAFF/hector/sh_scripts/scpCluster.sh -f $realPathDir/$realFile -d /tango/logs/COSTAFF/hector/RepoScripts/
        echo "`tput setaf 3`---------------------------------------------------------------`tput sgr0`"
fi
echo "`tput setaf 3`---------------------------------------------------------------`tput sgr0`"
echo "`tput setaf 2`ls -altr /tango/logs/COSTAFF/hector/RepoScripts/`tput sgr0`"
ls -altr /tango/logs/COSTAFF/hector/RepoScripts/
echo "`tput setaf 3`---------------------------------------------------------------`tput sgr0`"
echo "`tput setaf 2`ls -altr $realPathDir/`tput sgr0`"
ls -altr $realPathDir
echo "`tput setaf 3`---------------------------------------------------------------`tput sgr0`"
echo "`tput setaf 2`ls -altr /tango/logs/COSTAFF/hector/BackupRepoScripts/`tput sgr0`"
ls -altr /tango/logs/COSTAFF/hector/BackupRepoScripts/
echo "`tput setaf 3`---------------------------------------------------------------`tput sgr0`"
echo "`tput setaf 2`cat $realPathDir/$realFile`tput sgr0`"
cat $realPathDir/$realFile
echo "`tput setaf 3`---------------------------------------------------------------`tput sgr0`"
echo "`tput setaf 2`diff /tango/logs/COSTAFF/hector/BackupRepoScripts/$realFile.$remHost.$todayExt $file`tput sgr0`"
diff /tango/logs/COSTAFF/hector/BackupRepoScripts/$realFile.$remHost.$todayExt $realPathDir/$realFile
gitSub
echo "`tput setaf 3`---------------------------------------------------------------`tput sgr0`"
echo "Finished, bye"
echo ""