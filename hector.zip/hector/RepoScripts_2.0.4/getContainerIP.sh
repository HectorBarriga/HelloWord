#!/bin/bash
getContainers=$(docker ps | egrep -v "CONTAINER ID" | awk '{print $(NF)'})
echo "`tput setaf 3`===================================================
CONTAINERS (NAME)`tput sgr0`"
echo "$getContainers" | while read containerName
do
        echo "- $containerName"
done
echo "`tput setaf 3`==================================================="
echo -n -e "Enter CONTAINER Name or ID [Default ALL] > `tput sgr0`"
read container
if [ -z "$container" ] || [ "$container" == "All" ] || [ "$container" == "ALL" ] || [ "$container" == "all" ];then
        echo "$getContainers" | while read containerId
        do
                echo -n -e "\n`tput setaf 2`$containerId = `tput sgr0`"
                docker inspect -f "{{ .NetworkSettings.IPAddress }}" $containerId
        done
else
        echo -n -e "\n`tput setaf 2`$container = `tput sgr0`"
        docker inspect -f "{{ .NetworkSettings.IPAddress }}" $container
fi
echo ""