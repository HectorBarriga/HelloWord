#!/bin/bash
##############################################################################
# Filename:    messagesTableAging.sh
# Revision:    $Revision: 0.1.0 $
# Author:      Hector Barriga
#
# This sh script remove all messages_xxx tables without removing the reports/statistics.
# It also gives the option to dump the tables
# However, the "Detailed Report" will be removed which is not generally needed for old jobs.
# It is recommended then to dump the tables in case the "Detailed Report" is needed at some point
#
# This sh script also gives the option to remove 1 or ALL old jobs together with reports/statistics
# It is recommended to use the GUI but if you need to remove ALL jobs faster, you can use this script
#
# This sh script is mainly used for housekeeping.
# Copyright (c) Tango Telecom 2015
#
# All rights reserved.
# This document contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or
# in part is expressly prohibited, except as may be specifically
# authorized by prior written agreement or permission of Tango Telecom.
##############################################################################
# version 0.1.0 - First version
#
##############################################################################

# Initial Arguments
today=$(perl -e '@d=localtime time(); printf "__%4d-%02d-%02d\n", $d[5]+1900,$d[4]+1')
timenow=$(perl -e '@d=localtime time(); printf "%4d%02d%02d %02d%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1]')
lognow=$(perl -e '@d=localtime time(); printf "%4d-%02d-%02d\n", $d[5]+1900,$d[4]+1')

# Subroutines
printLog()
{
echo "[ $timenow ] $1" >> /tango/data/user_data/COStaff/hector/messagesTableAging$lognow.log
}



# Start Script

#----------------------------------- Main Menu ----------------------------------------------
echo ""
echo "---------------------------------------------"
echo "|              Menu messages_xxx            |"
echo "|                                           |"
echo "| 1. List all tables                        |"
echo "| 2. Remove a whole job and its reports     |"
echo "| 3. Remove range of tables                 |"
echo "| 4. Exit                                   |"
echo "|                                           |"
echo "| control+C to Cancel                       |"
echo "---------------------------------------------"


#----------------------------------- MYSQL Authentication ----------------------------------
echo ""
echo "Before you select an option, I must validate mysql authentication"
echo ""
echo -n "Enter mysql user > "
read mysqluser
echo -n "Enter mysql password > "
read password
checkmysqluser=$(echo "select 1;" | mysql -u $mysqluser -p$password broadcast | tail -1)
if [ "$checkmysqluser" == "1" ]; then



echo ""
echo -n "Enter option > "
read option
printLog "Enter option >  $option"


if [ "$option" != "4" ]; then

        if [ "$option" == "1" ]; then
                echo ""
                echo "----------------------------------- 1. List all tables ----------------------------------"
                echo ""
                echo ""
                echo ""
                echo "show tables like 'messages_%';" | mysql -u $mysqluser -p$password broadcast
                echo ""



        elif [ "$option" == "2" ]; then
                echo ""
                echo "------------------------- 2. Remove a whole job and its reports -------------------------"
                echo ""

                echo -n "Enter jobid or ALL > "
                read jobid
                printLog "Enter jobid or ALL > $jobid"
                printLog "Enter jobid or ALL > $jobid Enter mysql user >  $mysqluser Enter mysql password > $password"
                if [ "$jobid" == "ALL" ]; then
                        echo "You entered: $jobid"
                        echo "##################### TABLES ####################################;"
                        echo "show tables like 'messages_%';" | mysql -u $mysqluser -p$password broadcast;
                        echo "################# job_message_info JOBID=$jobid ##################"
                        echo "SELECT * FROM job_message_info;" | mysql -u $mysqluser -p$password broadcast;
                        echo "#################### campaign_jobs JOBID=$jobid ##################"
                        echo "SELECT * FROM campaign_jobs;" | mysql -u $mysqluser -p$password broadcast;
                        echo "######################## jobs JOBID=$jobid #######################"
                        echo "SELECT * FROM jobs\G;" | mysql -u $mysqluser -p$password broadcast;
                else
                        echo "You entered: $jobid"
                        echo "##################### TABLES ####################################;"
                        echo "show tables like 'messages_$jobid';" | mysql -u $mysqluser -p$password broadcast;
                        echo "################# job_message_info JOBID=$jobid ##################"
                        echo "SELECT * FROM job_message_info WHERE job_oid=$jobid;" | mysql -u $mysqluser -p$password broadcast;
                        echo "#################### campaign_jobs JOBID=$jobid ##################"
                        echo "SELECT * FROM campaign_jobs WHERE job_id=$jobid;" | mysql -u $mysqluser -p$password broadcast;
                        echo "######################## jobs JOBID=$jobid #######################"
                        echo "SELECT * FROM jobs WHERE id=$jobid\G;" | mysql -u $mysqluser -p$password broadcast;

                        echo -n "To  delete this JOB enter y/n > "
                        read confirm
                        printLog "To  delete this JOB enter y/n > $confirm"
                        if [ "$confirm" == "y" ]; then
                                        echo "DELETE FROM job_message_info WHERE job_oid=$jobid;" | mysql -u $mysqluser -p$password broadcast;
                                        echo "DELETE FROM  campaign_jobs WHERE job_id=$jobid;" | mysql -u $mysqluser -p$password broadcast;
                                        echo "DELETE FROM jobs WHERE id=$jobid;" | mysql -u $mysqluser -p$password broadcast;
                                        echo "DROP TABLE messages_$jobid;" | mysql -u $mysqluser -p$password broadcast;
                                        echo "##################### TABLES ####################################;"
                                        echo "show tables like 'messages_$jobid';" | mysql -u $mysqluser -p$password broadcast;
                                        echo "################# job_message_info JOBID=$jobid ##################"
                                        echo "SELECT * FROM job_message_info WHERE job_oid=$jobid;" | mysql -u $mysqluser -p$password broadcast;
                                        echo "#################### campaign_jobs JOBID=$jobid ##################"
                                        echo "SELECT * FROM campaign_jobs WHERE job_id=$jobid;" | mysql -u $mysqluser -p$password broadcast;
                                        echo "######################## jobs JOBID=$jobid #######################"
                                        echo "SELECT * FROM jobs WHERE id=$jobid\G;" | mysql -u $mysqluser -p$password broadcast;
                                        echo "Done, All jobs where dropped"
                                        echo "Bye."
                                        printLog "echo DELETE FROM job_message_info WHERE job_oid=$jobid | mysql -u $mysqluser -p$password broadcast"
                                        printLog "echo DELETE FROM  campaign_jobs WHERE job_id=$jobid | mysql -u $mysqluser -p$password broadcast"
                                        printLog "echo DELETE FROM jobs WHERE id=$jobid | mysql -u $mysqluser -p$password broadcast"
                                        printLog "echo DROP TABLE messages_$jobid | mysql -u $mysqluser -p$password broadcast"
                                        printLog "echo show tables like 'messages_$jobid' | mysql -u $mysqluser -p$password broadcast"
                                        printLog "echo SELECT * FROM job_message_info WHERE job_oid=$jobid | mysql -u $mysqluser -p$password broadcast"
                                        printLog "echo SELECT * FROM campaign_jobs WHERE job_id=$jobid | mysql -u $mysqluser -p$password broadcast"
                                        printLog "echo SELECT * FROM jobs WHERE id=$jobid\G | mysql -u $mysqluser -p$password broadcast"
                                        printLog "echo Done, All jobs where dropped"

                        else
                                        echo "No JOB was deleted, bye"
                                        printLog "No JOB was deleted, bye"
                        fi
                fi



        elif [ "$option" == "3" ]; then

                echo ""
                echo "------------------------- 3. Remove range of message_xxxx tables -------------------------"
                echo ""

                echo -n "Enter Initial jobid > "
                read jobinit
                echo -n "Enter Last jobd > "
                read joblast
                printLog "Enter Initial jobid > $jobinit Enter Last jobd > $joblast Enter mysql user >  $mysqluser Enter mysql password > $password"
                echo ""
                echo "--------------------------|"
                echo "| This will drop:         |"
                echo "| From  messages_$jobinit     |"
                echo "| To    messages_$joblast     |"
                echo "--------------------------|"
                printLog "This will drop: From  messages_$jobinit To    messages_$joblast"
                echo ""
                echo -n "Do you want to export tables? y/n > "
                read export
                printLog "Do you want to export tables? y/n > $export"
                echo ""
                echo -n "Are you sure you want to drop them? y/n > "
                read conf1
                printLog "Are you sure you want to drop them? y/n > $conf1"
                echo ""
                if [ "$conf1" == "y" ]; then

                        if [ "$export" == "y" ]; then
                                        echo -n "Enter destination Directory > "
                                        read destDir
                                        printLog "Enter destination Directory > $destDir"
                                        printLog "------------------------ Exporting -----------------------"
                                        echo ""
                        fi

                        COUNTER=$jobinit
                        while [  $COUNTER -le $joblast ]; do
                                        if [ "$export" == "y" ]; then
                                                        echo "mysqldump broadcast -u $mysqluser -p$password messages_$COUNTER > $destDir/messages_$COUNTER$today.dump"
                                                        printLog "mysqldump broadcast -u $mysqluser -p$password messages_$COUNTER > $destDir/messages_$COUNTER$today.dump"
                                                        mysqldump broadcast -u $mysqluser -p$password messages_$COUNTER > $destDir/messages_$COUNTER$today.dump
                                        fi
                                        echo "drop table messages_$COUNTER;"
                                        printLog "echo drop table messages_$COUNTER; | mysql -u $mysqluser -p$password broadcast;"
                                        echo "drop table messages_$COUNTER;" | mysql -u $mysqluser -p$password broadcast;
                                        let COUNTER=COUNTER+1
                                        sleep 1
                        done

                        echo ""
                        if [ "$export" == "y" ]; then
                                        echo "Done, All tables between messages_$jobinit to messages_$joblast were successfully exported into $destDir"
                                        printLog "-------------------- Finished Exportin -------------------"
                                        printLog "Done, All tables between messages_$jobinit to messages_$joblast were successfully exported into $destDir"
                        fi
                        echo "Done, All tables between messages_$jobinit to messages_$joblast were successfully dropped"
                        printLog "Done, All tables between messages_$jobinit to messages_$joblast were successfully dropped"
                        echo "Bye."

                else
                                echo "No table messages_xxx was dropped, bye"
                                printLog "No table messages_xxx was dropped, bye"
                fi
        fi

else
    echo "Nothing done, Bye"
    printLog "Nothing done, Bye"
fi


else
    echo "Wrong MYSQL user=$mysqluser password=$password"
    echo "Bye."
    echo ""
    printLog "Wrong MYSQL user=$mysqluser password=$password"
    printLog "Bye"
fi