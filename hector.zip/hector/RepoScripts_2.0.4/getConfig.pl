i#!/usr/bin/perl
setpriority(0, 0, 19);
use Sys::Hostname;

### You may put your defaults here into these settings. 
### Doing this you will disable interactive mode for each of the items:
$customer = "";
$cluster  = "";
$cfgrel   = "";
############################

@ConfSubdirs = ("sfg_rt", "SFG_antispam",  "SmsForwProvApp", "ISMSC_aNumberAnalysis", "ISMSC_bNumberAnalysis", 
             "iSmscMoRoutingClass", "iSmscMoRoutingList", "ISMSC_stripAndReplace",
           "IWF_SMS_MT_ANTI_SPAM", "smi" ,"gprs" , "ISMSC_aBlackList", 
           "iSmsc_sl_CDR", "ISMSC_stripAndReplace_A", "ISMSC_stripAndReplace_B", 
           "SAS_digitDiff", "SAS_hotlistBlock", "SAS_lengthChecksum", 
           "SAS_moAnalysisSequence", "SAS_moRules", "SAS_profiles", 
           "SAS_rateMonitor", "SAS_scanContent", "SAS_screening", 
           "SAS_smsVirus", "SMS_mtScreener" ,"ISMSC_stripAndReplace_appHo_A" , "ISMSC_stripAndReplace_appHo_B" , 
           "capProxy" , "lbr" , "USSD_SI_SD" , "SCCP_GTT_GSM" ,
           "ISMSC_antiSpoofing", "ISMSC_localNumberAnalysis", "IWF_whiteList", "SMS_mtIf_calling_na", "SMS_mtIf_oloRoamingList",
           "M2P_Classify" , "ssrv", "pmi", "isp" , "jca"
           );

$date = `date '+%Y%m%d_%H%M'`;
$date =~ s/\n//;
$clusterEqualHostnameLessOneTrailingChar = 0; # set this to one if you want to disable interactive mode
$verbose = 1;

system("clear");

if ($customer eq "")
{
   print "Please enter the customer name: ";
   $customer = <STDIN>;
   $customer =~ s/\n//;
}


open (LOG, ">/tmp/info.log"); 

$node = hostname();
if ($cluster eq "") 
{
   if ($clusterEqualHostnameLessOneTrailingChar)
   {
      $cluster = substr ($node,0, length($node) -1);
   }
   else
   {
      print "Please enter the cluster name: ";
      $cluster = <STDIN>;
      $cluster =~ s/\n//;
   }
}
@allSubdirs = `ls -la /tango/config/ | grep "^d" `;

$subdirs = "";

foreach $dir (@allSubdirs)
{
   next if ($dir =~ /\.$/) ; 
   @allParts = split (/\s/,$dir);
   $subdir = $allParts[$#allParts];
   if (NotInArr($subdir,@ConfSubdirs))
   {
      print "Do you want to add the subdir: $subdir into the config package? (y/n) ";
      $yesOrNo = <STDIN>;
      $yesOrNo =~ s/\n//;
      if ($yesOrNo =~ /^y/i)
      {
         $subdirs .= $subdir ." "; 
      }   
   }
   else
   {
      $subdirs .= $subdir ." ";   
   }
}

print "All subdirs are : $subdirs;\n";

$sdelim = "_===_";
$edelim = "----------";

if ($cfgrel eq "")
{
   $releaseLine = `ls -la /tango/config`;
   @relArr = split /\// , $releaseLine;
   $lastPart = $relArr[$#relArr - 2] . $relArr[$#relArr - 1] . $relArr[$#relArr] ;
   if ($lastPart =~ /(\d+)[_\-\.](\d+)[_\-\.](\d+)[_\-\.](\d+)([_\-\.]*)(\d*)/)
   {
      $cfgrel = $1.".".$2.".".$3.".".$4 ;
      if ($6 ne "") { $cfgrel .= "_" . $6 ;}
   }
   else
   {  
      print "This is the config directory: \n $releaseLine \n";
      print "The release was not recognized. Please specify it { in format A.B.C.D[_E]}:\n\[$lastPart\]\n ";
      while (! ($lastPart =~ /(\d+)[_\-\.](\d+)[_\-\.](\d+)[_\-\.](\d+)([_\-\.]*)(\d*)/))
      {
         $lastPart = <STDIN>;
         if ($lastPart =~ /(\d+)[_\-\.](\d+)[_\-\.](\d+)[_\-\.](\d+)([_\-\.]*)(\d*)/)
         {
            $cfgrel = $1.".".$2.".".$3.".".$4 ;
            if ($6 ne "") { $cfgrel .= "_" . $6 ;}
         }
         else
         {
            print "Bad format. Not A.B.C.D[_E] where [A-E] are numbers !\n Try another one: ";
         }
      }
   }
}

$cmd  = "Date = $date\n";
$cmd .= "Customer = $customer\n";
$cmd .= "Cluster = $cluster\n";
$cmd .= "Node = $node\n";
$cmd .= "Config release = $cfgrel\n";
$cmd .= "Release line = $releaseLine\n";
$cmd .= "HostID = ";
$cmd .= `hostid`;

print "Adding general\n" if ($verbose);
print LOG "[General]\n";
print LOG $cmd;
print LOG "$edelim\n";

print "Adding uname\n" if ($verbose);
$cmd = `uname -X`;
print LOG $sdelim."Uname".$sdelim . "\n";
print LOG $cmd;
print LOG "$edelim\n";

print "Adding /etc/release\n" if ($verbose);
$cmd = `cat /etc/release`;
print LOG $sdelim."SolarisRelease".$sdelim . "\n";
print LOG $cmd;
print LOG "$edelim\n";

print "Adding psrinfo\n" if ($verbose);
$cmd = `psrinfo -v`;
print LOG $sdelim."psrinfo-v".$sdelim . "\n";
print LOG $cmd;
print LOG "$edelim\n";

print "Adding isainfo\n" if ($verbose);
$cmd = `isainfo -v`;
print LOG $sdelim."isainfo-v".$sdelim . "\n";
print LOG $cmd;
print LOG "$edelim\n";

print "Adding prtdiag\n" if ($verbose);
$cmd = `prtdiag`;
print LOG $sdelim."prtdiag".$sdelim . "\n";
print LOG $cmd;
print LOG "$edelim\n";

print "Adding prtconf\n" if ($verbose);
$cmd = `prtconf -p`;
print LOG $sdelim."prtconf-p".$sdelim . "\n";
print LOG $cmd;
print LOG "$edelim\n";

print "Adding ifconfig\n" if ($verbose);
$cmd = `ifconfig -a`;
print LOG $sdelim."ifconfig-a".$sdelim . "\n";
print LOG $cmd;
print LOG "$edelim\n";

print "Adding netstat -nrv\n" if ($verbose);
$cmd = `netstat -nrv`;
print LOG $sdelim."netstat-nrv".$sdelim . "\n";
print LOG $cmd;
print LOG "$edelim\n";


close (LOG);

print "Adding crontab \n" if ($verbose);
`crontab -l > /tmp/crontab.txt`;

$package = "$node\_config_r$cfgrel.tar";
$pwd = `pwd`;
$pwd =~ s/\n//;
#$cmd = "cd /tango/config/ ; tar cvf $package * /tmp/info.log ; mv $package $pwd ; cd $pwd";
print "Doing tar \n" if ($verbose);
`cd /tango/config/ ;tar cvf /tmp/$package *.cfg $subdirs /tmp/info.log /tmp/crontab.txt ; mv /tmp/$package $pwd ; cd $pwd ` ;
print "gzip-ed package is: $package\.gz\n" if ($verbose);
`gzip $package`;

##############################################################################
# NotInArr (element $e, array @A)
# Will return 1 if element $e is member of an Array @A, else will return 0
##############################################################################
sub NotInArr
{
   $temp = shift;
   @tempArr = @_;
   $returnVal = 1;
   foreach $p (@tempArr)
   {
      if ($temp eq $p)
      {
         $returnVal = 0;
      }
   }
   return $returnVal;
}

