#!/bin/bash
#############################################################################
# Filename:    replicationrecovery.sh
# Revision:    $Revision: 0.1.0 $
# Author:      Hector Barriga
#
# This sh script displays the commands that should be run to recover database
# replication for DRC and DRCM databases
#
# Copyright (c) Tango Telecom 2016
# Author: Hector Barriga
#
# All rights reserved.
# This document contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or
# in part is expressly prohibited, except as may be specifically
# authorized by prior written agreement or permission of Tango Telecom.
##############################################################################
# version 0.1.0 - First version
#
##############################################################################

# Configurations
mysqlmasterhost="IPXMIATCDB3"
mysqlslavehost="IPXMIATCDB4"
mysqluser="root"
mysqlpw="t3il3achum"
perconaServer="true"

# Initial Arguments
namehost=$(hostname)
whichmysql=$(which mysql)
gomysql=$(echo "$whichmysql -u$mysqluser -p$mysqlpw")
gomysqlslave=$(echo "$whichmysql -u$mysqluser -p$mysqlpw" -h $mysqlslavehost)
gomysqlmaster=$(echo "$whichmysql -u$mysqluser -p$mysqlpw" -h $mysqlmasterhost)

# Subroutines

getReplicationDB()
{
mysqlbin=$(echo "show master status;" | $gomysqlmaster | egrep -v File | awk '{print $1}')
mysqlpos=$(echo "show master status;" | $gomysqlmaster | egrep -v File | awk '{print $2}')
if [ "$perconaServer" == "true" ];then
        mysqldb=$(echo "show databases;" | $gomysqlmaster | egrep -v sys | egrep -v Database | egrep -v mysql | egrep -v information_schema | egrep -v performance_schema | xargs | sed -e 's/ /,/g')
else
        mysqldb=$(echo "show master status;" | $gomysqlmaster | egrep -v File | awk '{print $3}')
fi
mysqldbarray=(`echo $mysqldb | sed 's/,/\n/g'`)
mysqldbarraylength=${#mysqldbarray[@]}
echo "DEBUG: getReplicationDB"
i=0
for (( i=0;i<$mysqldbarraylength;i++))
do
        echo "DEBUG: "${mysqldbarray[$i]}
done
}

stoptomkilltom()
{
echo "NOTE!!!!!! Stop tomcat on master node !!!"
echo "stoptom;"
echo "killtom;"
}

locktables()
{
echo "echo \"FLUSH TABLES WITH READ LOCK;\" | $gomysqlslave;"
echo "master_status -h $mysqlmasterhost;"
echo "echo \"FLUSH TABLES WITH READ LOCK;\" | $gomysqlmaster;"
}

backupDBslave()
{
i=0
mysqldbarraylength=${#mysqldbarray[@]}
for (( i=0;i<$mysqldbarraylength;i++))
do
        echo "mysqldump ${mysqldbarray[$i]} -u $mysqluser --routines -p$mysqlpw -h $mysqlmasterhost > replicationrecovery_${mysqldbarray[$i]}_$mysqlmasterhost.dump;"
done
i=0
for (( i=0;i<$mysqldbarraylength;i++))
do
        echo "mysqldump ${mysqldbarray[$i]} -u $mysqluser --routines -p$mysqlpw -h $mysqlslavehost > replicationrecovery_${mysqldbarray[$i]}_$mysqlslavehost.dump;"
done
}

dropAndCreateReplicationDBonSlave()
{
mysqldbarraylength=${#mysqldbarray[@]}
i=0
for (( i=0;i<$mysqldbarraylength;i++))
do
        echo "echo \"drop database ${mysqldbarray[$i]};\" | $gomysqlslave;"
        echo "echo \"create database ${mysqldbarray[$i]};\" | $gomysqlslave;"
done
}

recoverDumps()
{
mysqldbarraylength=${#mysqldbarray[@]}
i=0
for (( i=0;i<$mysqldbarraylength;i++))
do
        echo "$gomysqlslave  ${mysqldbarray[$i]} < replicationrecovery_${mysqldbarray[$i]}_$mysqlmasterhost.dump;"
done
}

startreplication()
{
echo "echo \"SLAVE STOP;\" | $gomysqlmaster;"
echo "echo \"SLAVE STOP;CHANGE MASTER TO MASTER_HOST='LIM_DB', MASTER_USER='$mysqluser', MASTER_PASSWORD='$mysqlpw', MASTER_LOG_FILE='$mysqlbin', MASTER_LOG_POS=$mysqlpos;START SLAVE;\" | $gomysqlslave;"
}

unlocktables()
{
echo "echo \"UNLOCK TABLES;\" | $gomysqlslave;"
echo "echo \"UNLOCK TABLES;\" | $gomysqlmaster;"
echo "slave_status;"
echo "slave_status -h $mysqlmasterhost;"
}

startom()
{
echo "startom;"
echo "NOTE!!!!!! Start tomcat on master node !!!"
}



# main()
echo "---------------------- START ---------------------------"
getReplicationDB
echo "--------------------------------------------------------"
stoptomkilltom
echo "--------------------------------------------------------"
locktables
echo "--------------------------------------------------------"
backupDBslave
echo "--------------------------------------------------------"
dropAndCreateReplicationDBonSlave
echo "--------------------------------------------------------"
recoverDumps
echo "--------------------------------------------------------"
startreplication
echo "--------------------------------------------------------"
unlocktables
echo "--------------------------------------------------------"
startom
echo "------------------- FINISHED ---------------------------"