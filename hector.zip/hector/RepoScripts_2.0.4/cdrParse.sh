#!/bin/bash
DIR=$(echo "`dirname $0`")

printResponseCodeCDRField()
{
        if [ "$1" == "200" ];then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[32m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [OK] Successful"
        elif [ "$1" == "201" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[32m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [OK] Created"
        elif [ "$1" == "202" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[32m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [OK] Accepted"
        elif [ "$1" == "203" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[32m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [OK] Non-Authoritative Information"
        elif [ "$1" == "204" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[32m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [OK] No Content"
        elif [ "$1" == "205" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[32m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [OK] Reset Content"
        elif [ "$1" == "206" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[32m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [OK] Partial Content"
         elif [ "$1" == "207" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[32m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [OK] Multi-Status"
        elif [ "$1" == "208" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[32m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [OK] Already Reported"
        elif [ "$1" == "103" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [ERROR] 3rd Party Server Bad Response"
        elif [[ "$1" =~ "^3" ]] && [ $2 -eq $3 ];then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [CLIENT ERROR] 3xx Redirection"
        elif [ "$1" == "400" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [CLIENT ERROR] Bad Request"
        elif [ "$1" == "401" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [CLIENT ERROR] Unauthorized"
        elif [ "$1" == "403" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [CLIENT ERROR] Forbidden"
        elif [ "$1" == "404" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [CLIENT ERROR] Not Found"
        elif [ "$1" == "405" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [CLIENT ERROR] Method Not Allowed"
        elif [ "$1" == "406" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [CLIENT ERROR] Not Acceptable"
        elif [ "$1" == "407" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [CLIENT ERROR] Proxy Authentication Required"
        elif [ "$1" == "408" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [CLIENT ERROR] Request Timeout"
        elif [ "$1" == "409" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [CLIENT ERROR] Conflict"
        elif [ "$1" == "410" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [CLIENT ERROR] Gone - Resource Not Available"
        elif [ "$1" == "411" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [CLIENT ERROR] Length Required"
        elif [ "$1" == "412" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [CLIENT ERROR] Precondition Failed"
        elif [ "$1" == "413" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [CLIENT ERROR] Payload Too Large"
        elif [ "$1" == "414" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [CLIENT ERROR] URI Too Long"
        elif [ "$1" == "415" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [CLIENT ERROR] Unsupported Media Type"
        elif [ "$1" == "416" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [CLIENT ERROR] Range Not Satisfiable"
        elif [ "$1" == "417" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [CLIENT ERROR] Expectation Failed"
        elif [ "$1" == "429" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [CLIENT ERROR] Tooo May Requests"
        elif [ "$1" == "451" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [CLIENT ERROR] Request Header Fields Too Large"
        elif [ "$1" == "421" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [CLIENT ERROR] Misdirected Request"
        elif [ "$1" == "444" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [NGINX ERROR] No Response"
        elif [ "$1" == "494" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [NGINX ERROR] Request header too large"
        elif [ "$1" == "495" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [NGINX ERROR] SSL Certificate Error"
        elif [ "$1" == "496" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [NGINX ERROR] SSL Certificate Required"
        elif [ "$1" == "497" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [NGINX ERROR] HTTP Request Sent to HTTPS Port"
        elif [ "$1" == "499" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [NGINX ERROR] Client Closed Request"
        elif [ "$1" == "500" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [SERVER ERROR] Internal Server Error"
        elif [ "$1" == "501" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [SERVER ERROR] Not Implemented"
        elif [ "$1" == "502" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [SERVER ERROR] Bad Gateway"
        elif [ "$1" == "503" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [SERVER ERROR] Service Unavailable"
        elif [ "$1" == "504" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [SERVER ERROR] Gateway Timeout"
        elif [ "$1" == "505" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [SERVER ERROR] HTTP Version Not Supported"
        elif [ "$1" == "506" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [SERVER ERROR] Variant Also Negotiates"
        elif [ "$1" == "507" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [SERVER ERROR] Insufficient Storage"
        elif [ "$1" == "508" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [SERVER ERROR] Loop Detected"
        elif [ "$1" == "510" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [SERVER ERROR] Not Extended"
        elif [ "$1" == "511" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [SERVER ERROR] Network Authentication Required"
        elif [ "$1" == "509" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [SERVER ERROR] Bandwidth Limit Exceeded"
        elif [ "$1" == "526" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [SERVER ERROR] Invalid SSL Certificate"
        elif [ "$1" == "529" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [SERVER ERROR] Site is overloaded"
        elif [ "$1" == "530" ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [SERVER ERROR] Site is frozen"
        else
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$2] $3 "=" $4 "   [UNOWN ERROR] Error is not in cdrParse script. Pls add it"
        fi
}

parseCDR()
{
columnnames=$1
ocdr=$(echo "$cdr"  | paste -sd' ')
c=0
getServiceID=$(echo "$getCDRtype" | cut -d, -f1)
oldIFS=$IFS
printf '\n\033[32m %-30s \033[0;32m %-30s\n\n' "" $2
echo "`tput setaf 2`--------------------------------------------------------------------------------------------------"
echo "   $3"
echo "   $4"
echo "`tput setaf 2`--------------------------------------------------------------------------------------------------`tput sgr0`"
IFS=","
checkLastField=$(echo $ocdr | cut -c $((${#ocdr})))
if [ -z "$checkLastField" ];then
        ocdr="$ocdr""-"
fi
if [ "$getServiceID" == "39" ];then
        ocdr="$ocdr"",-"
fi
for i in $ocdr
do
        d=$((c+1))
        getColumnname=$(echo "$columnnames" | cut -d, -f"$d")
        if [ "$getServiceID" == "7" ] && [ $d -lt 49 ];then
                printf '\033[35m %-5s \033[0;39m %-43s  %-3s \033[33m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i
        elif [ "$getServiceID" == "7" ] && [ $d -eq 49 ];then
                echo "`tput setaf 2`--------------------------------------------------------------------------------------------------`tput sgr0`"
                columnnames="Traffic Class,Upstream byte count,Downstream byte count,Charging units consumed"
                ocdr=$i
                c=0
                echo "`tput setaf 2`Variable Part Data Proxy CDR `tput sgr0`"
                IFS=";"
                checkLastField=$(echo $ocdr | cut -c $((${#ocdr})))
                if [ -z "$checkLastField" ];then
                        ocdr="$ocdr""-"
                fi
                for i in $ocdr
                do
                        d=$((c+1))
                        getColumnname=$(echo "$columnnames" | cut -d, -f"$d")
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-1s \033[0;39m\n' "                                           " $getColumnname "=" $i
                        let ++c
                done
                IFS=$oldIFS
        elif [ "$getServiceID" == "90" ] || [ "$getServiceID" == "105" ];then
                getServerRespCode=$(echo "$cdr" | cut -d, -f11 | cut -d"|" -f1)
                getErrorCode=$(echo "$cdr" | cut -d, -f12)
                if [ "$getServerRespCode" == "200" -a $d -eq 11 ];then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[32m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "   [OK] Successful"
                elif [ "$getServerRespCode" == "400" -a $d -eq 11 ];then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "   [CLIENT ERROR] Bad Request"
                elif [ "$getServerRespCode" == "401" -a $d -eq 11 ];then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "   [CLIENT ERROR] Unauthorized"
                elif [ "$getServerRespCode" == "403" -a $d -eq 11 ];then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "   [CLIENT ERROR] Forbidden"
                elif [ "$getServerRespCode" == "404" -a $d -eq 11 ];then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "   [CLIENT ERROR] Not Found"
                elif [ "$getServerRespCode" == "406" -a $d -eq 11 ];then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "   [CLIENT ERROR] Not Acceptable"
                elif [ "$getServerRespCode" == "408" -a $d -eq 11 ];then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "   [CLIENT ERROR] Request Timeout"
                elif [ "$getServerRespCode" == "500" -a $d -eq 11 ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "   [SERVER ERROR] Internal Server Error"
                elif [ "$getServerRespCode" == "501" -a $d -eq 11 ];then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "    [SERVER ERROR] Not Implemented"
                elif [ "$getServerRespCode" == "502" -a $d -eq 11 ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "   [SERVER ERROR] Bad Gateway"
                elif [ "$getErrorCode" == "0" -a $d -eq 12 ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[32m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "   Successful operation"
                elif [ "$getErrorCode" == "1" -a $d -eq 12 ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "   Failure - SE resource unavailable"
                elif [ "$getErrorCode" == "2" -a $d -eq 12 ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "   Failure - SE timer not started"
                elif [ "$getErrorCode" == "3" -a $d -eq 12 ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "   Failure - SE encoding error"
                elif [ "$getErrorCode" == "4" -a $d -eq 12 ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "   Failure - SE send failure"
                elif [ "$getErrorCode" == "5" -a $d -eq 12 ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "   Failure - SE response timeout"
                elif [ "$getErrorCode" == "6" -a $d -eq 12 ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "   Failure - Unknown error"
                elif [ $d -ne 11 ] || [ $d -ne 12 ];then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i
                fi
        elif [ "$getServiceID" == "87" ];then
                getServerRespCode=$(echo "$cdr" | cut -d, -f14 | cut -d"|" -f1)
                getHrgRespCode=$(echo "$cdr" | cut -d, -f15)
                if [ "$d" == "14" ];then
                        printResponseCodeCDRField "$getServerRespCode" "$d" "$getColumnname" "$i"
                elif [ "$d" == "15" ];then
                        printResponseCodeCDRField "$getHrgRespCode" "$d" "$getColumnname" "$i"
                elif [ $d -ne 14 ] || [ $d -ne 15 ];then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i
                fi
        elif [ "$getServiceID" == "177" ];then
                getServerRespCode=$(echo "$cdr" | cut -d, -f12)
                if [ "$d" == "12" ];then
                        printResponseCodeCDRField "$getServerRespCode" "$d" "$getColumnname" "$i"
                else
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[0;39m\n' "["$d"]" $getColumnname "=" $i
                fi
        elif [ "$getServiceID" == "91" ];then
                getReqStatus=$(echo "$cdr" | cut -d, -f17)
                getReqFailReason=$(echo "$cdr" | cut -d, -f18)
                if [ "$getReqStatus" == "0" ] && [ $d -eq 17 ];then
                         printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[32m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[OK] Request Sent"
                elif [ "$getReqStatus" == "1" ] && [ $d -eq 17 ];then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Request not sent or no response received"
                elif [ "$getReqStatus" == "2" ] && [ $d -eq 17 ];then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[32m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[OK] Req Resp Received"
                elif [ "$getReqFailReason" == "0" ] && [ $d -eq 18 ];then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[32m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[OK] Successful"
# As per https://www.openmarket.com/docs/Content/apis/v3smpp/smpp-error-codes.htm ---------
                elif [ "$getReqFailReason" == "2" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Command length is invalid"
                elif [ "$getReqFailReason" == "3" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Invalid Command ID"
                elif [ "$getReqFailReason" == "4" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Incorrect BIND Status for given command"
                elif [ "$getReqFailReason" == "5" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] ESME Already in Bound State"
                elif [ "$getReqFailReason" == "6" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Invalid Priority Flag"
                elif [ "$getReqFailReason" == "7" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Invalid Registered Delivery Flag"
                elif [ "$getReqFailReason" == "8" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] System Error"
                elif [ "$getReqFailReason" == "9" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Reserved"
                elif [ "$getReqFailReason" == "10" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Invalid Source Address"
                elif [ "$getReqFailReason" == "11" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Invalid Dest Addr"
                elif [ "$getReqFailReason" == "12" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Message ID is invalid"
                elif [ "$getReqFailReason" == "13" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Bind Failed"
                elif [ "$getReqFailReason" == "14" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Invalid Password"
                elif [ "$getReqFailReason" == "15" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Invalid System ID"
                elif [ "$getReqFailReason" == "17" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Cancel SM Failed"
                elif [ "$getReqFailReason" == "19" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Replace SM Failed"
                elif [ "$getReqFailReason" == "20" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Message Queue Full"
                elif [ "$getReqFailReason" == "21" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Invalid Service Type"
                elif [ "$getReqFailReason" == "51" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Invalid number of destinations"
                elif [ "$getReqFailReason" == "52" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Invalid Distribution List name"
                elif [ "$getReqFailReason" == "64" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Destination flag is invalid (submit_multi)"
                elif [ "$getReqFailReason" == "66" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Invalid submit with replace request; submit_sm with replace_if_present_flag set"
                elif [ "$getReqFailReason" == "67" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Invalid esm_class field data"
                elif [ "$getReqFailReason" == "68" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Cannot Submit to Distribution List"
                elif [ "$getReqFailReason" == "69" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] submit_sm or submit_multi failed"
                elif [ "$getReqFailReason" == "72" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Invalid Source address TON"
                elif [ "$getReqFailReason" == "73" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Invalid Source address NPI"
                elif [ "$getReqFailReason" == "80" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Invalid Destination address TON"
                elif [ "$getReqFailReason" == "81" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Invalid Destination address NPI"
                elif [ "$getReqFailReason" == "83" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Invalid system_type field"
                elif [ "$getReqFailReason" == "84" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Invalid replace_if_present flag"
                elif [ "$getReqFailReason" == "85" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Invalid number of messages"
                elif [ "$getReqFailReason" == "88" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Throttling error; ESME has exceeded allowed message limits"
                elif [ "$getReqFailReason" == "97" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Invalid Scheduled Delivery Time"
                elif [ "$getReqFailReason" == "98" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Invalid message validity period (Expiry time)."
                elif [ "$getReqFailReason" == "99" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Predefined Message Invalid or Not Found Does not support canned messages; set to NULL"
                elif [ "$getReqFailReason" == "100" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] ESME Receiver Temporary App Error Code"
                elif [ "$getReqFailReason" == "101" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] ESME Receiver Permanent App Error Code"
                elif [ "$getReqFailReason" == "102" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] ESME Receiver Reject Message Error Code"
                elif [ "$getReqFailReason" == "103" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] query_sm request failed"
                elif [ "$getReqFailReason" == "192" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Error in the optional part of the PDU Body"
                elif [ "$getReqFailReason" == "193" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Optional Parameter not allowed"
                elif [ "$getReqFailReason" == "194" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Invalid Parameter Length"
                elif [ "$getReqFailReason" == "195" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Expected Optional Parameter missing"
                elif [ "$getReqFailReason" == "196" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Invalid Optional Parameter Value"
                elif [ "$getReqFailReason" == "245" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Delivery Failure, used for data_sm_resp"
                elif [ "$getReqFailReason" == "255" ] && [ $d -eq 18 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Unknown Error";
                elif [ $d -ne 18 ] || [ $d -ne 17 ];then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i
                fi

# SCF SCP
        elif [ "$getServiceID" == "19" ];then
                getTransactionType=$(echo "$cdr" | cut -d, -f3)
                if [ "$getTransactionType" == "1" ] || [ "$getTransactionType" == "2" ];then
                        getCauseCode=$(echo "$cdr" | cut -d, -f4)
                        getChargingErrorCode=$(echo "$cdr" | cut -d, -f5)
                        if [ "$getCauseCode" == "0" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[32m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[OK] Normal call termination";
                        elif [ "$getCauseCode" == "1" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[32m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] No answer from called party";
                        elif [ "$getCauseCode" == "2" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[32m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] Calling or called party is busy";
                        elif [ "$getCauseCode" == "3" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] Call abandoned by the SSF";
                        elif [ "$getCauseCode" == "4" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] Route failure (on MSC) when setting up the call";
                        elif [ "$getCauseCode" == "5" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] Timeout waiting for an announcement to finish";
                        elif [ "$getCauseCode" == "6" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] Timeout waiting for a call answer notification from the SSF";
                        elif [ "$getCauseCode" == "7" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] Invalid initial DP message received from the SSF";
                        elif [ "$getCauseCode" == "8" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] Invalid call answer notification received from the SSF";
                        elif [ "$getCauseCode" == "9" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] Invalid call disconnect notification received from the SSF";
                        elif [ "$getCauseCode" == "10" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] Invalid apply-charging-report message from the SSF";
                        elif [ "$getCauseCode" == "11" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] Timeout waiting for apply-charging-report message from the SSF";
                        elif [ "$getCauseCode" == "12" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] Timeout waiting for a call disconnect notification from the SSF";
                        elif [ "$getCauseCode" == "13" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] Call terminated due to charging failure. (This may be as a result of zero balance, service denied, user error, charging error or charge server failure)";
                        elif [ "$getCauseCode" == "14" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] Network abort during call setup";
                        elif [ "$getCauseCode" == "15" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] Network abort while waiting for announcement to finish";
                        elif [ "$getCauseCode" == "16" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] Network abort while waiting for call answer";
                        elif [ "$getCauseCode" == "17" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] Network abort while monitoring call";
                        elif [ "$getCauseCode" == "18" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] Network abort while waiting for call to terminate";
                        elif [ "$getCauseCode" == "19" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] Timeout waiting for connect message from network SCF";
                        elif [ "$getCauseCode" == "20" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] Timeout waiting for answer respone from network SCF";
                        elif [ "$getCauseCode" == "21" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] Timeout waiting for release message from network SCF";
                        elif [ "$getCauseCode" == "22" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] Timeout waiting for charge control message for call-back call";
                        elif [ "$getCauseCode" == "23" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] Timeout waiting for IVR call disconnection";
                        elif [ "$getCauseCode" == "24" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] Invalid request report BCSM message received from the network SCF";
                        elif [ "$getCauseCode" == "25" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] Invalid connect message received from the network SCF";
                        elif [ "$getCauseCode" == "26" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] Invalid request report BCSM message received from the network SCF";
                        elif [ "$getCauseCode" == "27" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] Invalid charge control message received for call-back call";
                        elif [ "$getCauseCode" == "28" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] Network abort while waiting for connect from network SCF";
                        elif [ "$getCauseCode" == "29" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] Network abort while waiting for answer response from network SCF";
                        elif [ "$getCauseCode" == "30" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] Network abort while waiting for release from network SCF";
                        elif [ "$getCauseCode" == "31" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] Network abort while waiting for IVR call disconnection";
                        elif [ "$getCauseCode" == "32" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] Network abort while waiting for charge control message";
                        elif [ "$getCauseCode" == "33" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] Number portability resource failure.";
                        elif [ "$getCauseCode" == "34" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] Number portability failure.";
                        elif [ "$getCauseCode" == "35" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] Call forced to terminate because there was a configured maximum call duration allowed.";
                        elif [ "$getCauseCode" == "36" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] No Charging as the OCS has instructed the SCP to set up a call without the charging dialogue.";
                        elif [ "$getCauseCode" == "37" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] No answer; the call is forwarded.";
                        elif [ "$getCauseCode" == "38" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[TERMINATION] No answer; the call is busy.";
                        elif [ "$getChargingErrorCode" == "-1" ] && [ $d -eq 5 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[32m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[OK] -1 No error";
                        elif [ "$getChargingErrorCode" == "0" ] && [ $d -eq 5 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] 0 Charging Error undefined";
                        elif [ "$getChargingErrorCode" == "2" ] && [ $d -eq 5 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] 2 Invalid user error";
                        elif [ "$getChargingErrorCode" == "3" ] && [ $d -eq 5 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] 3 Charging parameter error";
                        elif [ "$getChargingErrorCode" == "6" ] && [ $d -eq 5 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] 6 Charging volume error";
                        elif [ "$getChargingErrorCode" == "13" ] && [ $d -eq 5 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] 13 Charge server resource unavailable";
                        elif [ "$getChargingErrorCode" == "52" ] && [ $d -eq 5 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] 52 Subscriber has insufficient balance to continue";
                        elif [ "$getChargingErrorCode" == "53" ] && [ $d -eq 5 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] 53 Service denied to the user";
                        elif [ "$getChargingErrorCode" == "54" ] && [ $d -eq 5 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] 54 Charging protocol error";
                        elif [ "$getChargingErrorCode" == "57" ] && [ $d -eq 5 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] 57 Rating error";
                        elif [ "$getChargingErrorCode" == "1000" ] && [ $d -eq 5 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] 1000 Charge reservation validity time expired";
                        elif [ "$getChargingErrorCode" == "1002" ] && [ $d -eq 5 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] 1002 Timeout waiting for a response from the SDF";


                        else
                                printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i
                        fi

# 3GPP Diameter Client
                elif [ "$getTransactionType" == "14" ] || [ "$getTransactionType" == "15" ] || [ "$getTransactionType" == "16" ] || [ "$getTransactionType" == "17" ] || [ "$getTransactionType" == "18" ];then
                        getResultCode=$(echo "$cdr" | cut -d, -f4)
                        if [ "$getResultCode" == "2001" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[32m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[OK] Diameter Success";
                        elif [ "$getResultCode" == "-1" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Diameter Charge Server Timeout";
                        elif [ "$getResultCode" == "1" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Diameter Server Timeout";
                        elif [ "$getResultCode" == "2" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Diameter Client Processing Error";
                        elif [ "$getResultCode" == "3" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Diameter Server Bad Parameter";
                        elif [ "$getResultCode" == "4010" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Diameter End User Service Denied";
                        elif [ "$getResultCode" == "4011" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Diameter Credit Control Not Applicable";
                        elif [ "$getResultCode" == "4012" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Diameter Credit Limit Reached";
                        elif [ "$getResultCode" == "5003" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Diameter Authorisation Rejected";
                        elif [ "$getResultCode" == "5004" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Diameter Invalid AVP Value";
                        elif [ "$getResultCode" == "5030" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Diameter User Unknown";
                        elif [ "$getResultCode" == "5031" ] && [ $d -eq 4 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Diameter Rating Failed";

                        else
                                printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i
                        fi
                else
                        printf '\033[35m %-5s \033[0;39m %-30s  %-1s \033[33m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i
                fi

        elif [ "$getServiceID" == "88" ];then
                getAnnouncementReportStatus=$(echo "$cdr" | cut -d, -f6)
                getResponseType=$(echo "$cdr" | cut -d, -f7)
                if [ "$getAnnouncementReportStatus" == "0" ] && [ $d -eq 6 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[32m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[OK] Status OK";
                elif [ "$getResponseType" == "0" ] && [ $d -eq 7 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[32m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[OK] Status OK";
                elif [ "$getAnnouncementReportStatus" == "1" ] && [ $d -eq 6 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Invalid Message ID";
                elif [ "$getAnnouncementReportStatus" == "2" ] && [ $d -eq 6 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Invalide Language ID";
                elif [ "$getResponseType" == "3" ] && [ $d -eq 7 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Invalid Correlation ID";
                elif [ "$getResponseType" == "4" ] && [ $d -eq 7 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Status Unknown";
                else
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i
                fi
        elif [ "$getServiceID" == "17" ];then
                getTransactionType=$(echo "$cdr" | cut -d, -f3)
                if [ "$getTransactionType" == "31" ];then
                        getStatus=$(echo "$cdr" | cut -d, -f16)
                        getErrorCode=$(echo "$cdr" | cut -d, -f17)
                        if [ "$getStatus" == "0" ] && [ $d -eq 16 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[32m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[OK] Status OK";
                        elif [ "$getStatus" == "-1" ] && [ $d -eq 16 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[FAILED] Dialogue Failed";
                        elif [ "$getErrorCode" == "0" ] && [ $d -eq 17 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[32m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[USSD_DIALOG_STATUS_OK] Dialogue finished normally";
                        elif [ "$getErrorCode" == "1" ] && [ $d -eq 17 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[USSD_DIALOG_STATUS_APP_RELEASE] Dialog was released by application before completion";
                        elif [ "$getErrorCode" == "2" ] && [ $d -eq 17 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[USSD_DIALOG_STATUS_APP_TIMEOUT] Dialog ended due to a timeout waiting for the application";
                        elif [ "$getErrorCode" == "3" ] && [ $d -eq 17 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[USSD_DIALOG_STATUS_MAP_ERROR] A successful response was not received from the MAP layer";
                        elif [ "$getErrorCode" == "4" ] && [ $d -eq 17 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[USSD_DIALOG_ENDED_MAP_LAYER] Dialog was ended early by the MAP layer";
                        else
                                printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i
                        fi

                elif [ "$getTransactionType" == "41" ];then
                        getCauseOfTermination=$(echo "$cdr" | cut -d, -f20)
                        if [ "$getCauseOfTermination" == "0" ] && [ $d -eq 20 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[32m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[SUCCESSFUL] Normal session end";
                        elif [ "$getCauseOfTermination" == "1" ] && [ $d -eq 20 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[35m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[FAILED] User timeout";
                        elif [ "$getCauseOfTermination" == "2" ] && [ $d -eq 20 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[35m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[FAILED] User teardown";
                        elif [ "$getCauseOfTermination" == "3" ] && [ $d -eq 20 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] User error";
                        elif [ "$getCauseOfTermination" == "4" ] && [ $d -eq 20 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] User is Busy";
                        elif [ "$getCauseOfTermination" == "5" ] && [ $d -eq 20 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Charging error";
                        elif [ "$getCauseOfTermination" == "6" ] && [ $d -eq 20 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Other error";
                        elif [ "$getCauseOfTermination" == "7" ] && [ $d -eq 20 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Dialogue rejected due to process level throttling";
                        elif [ "$getCauseOfTermination" == "8" ] && [ $d -eq 20 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Dialogue rejected due to service definition level throttling";
                        elif [ "$getCauseOfTermination" == "9" ] && [ $d -eq 20 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Whitelist Error";
                        elif [ "$getCauseOfTermination" == "10" ] && [ $d -eq 20 ];then printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "[ERROR] Dialogue failed due to server request throttling";
                        else
                                printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i
                        fi


                elif [ "$getTransactionType" == "46" -a "$d" == "22" ];then
                        getServerRespCode=$(echo "$cdr" | cut -d, -f22)
                        printResponseCodeCDRField "$getServerRespCode" "$d" "$getColumnname" "$i"
                elif [ "$getTransactionType" == "48" -a "$d" == "22" ];then
                        printf '\033[35m %-5s \033[0;39m %-7s \033[0;36m[Resp Map Value]\033[0;39m %-3s \033[33m %-6s \033[0;39m\n' [$d] $getColumnname "=" $i
                else
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[0;39m\n' "["$d"]" $getColumnname "=" $i
                fi

        elif [ "$getServiceID" == "1063" ];then
                getErrorCode=$(echo "$cdr" | cut -d, -f9)
                if [ "$getErrorCode" == "200" -a $d -eq 9 ];then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[32m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "   [OK] Successful"
                elif [ "$getErrorCode" == "400" -a $d -eq 9 ];then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "   [CLIENT ERROR] Bad Request"
                elif [ "$getErrorCode" == "401" -a $d -eq 9 ];then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "   [CLIENT ERROR] Unauthorized"
                elif [ "$getErrorCode" == "403" -a $d -eq 9 ];then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "   [CLIENT ERROR] Forbidden"
                elif [ "$getErrorCode" == "404" -a $d -eq 9 ];then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "   [CLIENT ERROR] Not Found"
                elif [ "$getErrorCode" == "406" -a $d -eq 9 ];then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "   [CLIENT ERROR] Not Acceptable"
                elif [ "$getErrorCode" == "408" -a $d -eq 9 ];then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "   [CLIENT ERROR] Request Timeout"
                elif [ "$getErrorCode" == "500" -a $d -eq 9 ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "   [SERVER ERROR] Internal Server Error"
                elif [ "$getErrorCode" == "501" -a $d -eq 9 ];then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "    [SERVER ERROR] Not Implemented"
                elif [ "$getErrorCode" == "502" -a $d -eq 9 ] ;then
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-6s \033[31m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i "   [SERVER ERROR] Bad Gateway"
                else
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i
                fi




#--------------------------------------------------

        else
                printf '\033[35m %-5s \033[0;39m %-30s  %-1s \033[33m %-1s \033[0;39m\n' [$d] $getColumnname "=" $i
        fi


        let ++c
done
IFS=$oldIFS
echo "`tput setaf 2`--------------------------------------------------------------------------------------------------`tput sgr0`"
if [ ! -z "$5" ];then
        if [ "$getServiceID" == "28" ];then
                columnnames="Rule Name,Rule Precedence,Rule Type,Rule Event Type,Plan Name,Service ID,Service Flow Status,Min UL Bitrate,Max UL Bitrate,Min DL Bitrate,Max DL Bitrate,Rating Group,SP Usage Key,Gx Monitor Key,Metering Type,Usage Report Status,Usage Reported,Discount Rate,Discount Type,Usage Sent"
                ocdr=$5
                c=0
                echo "`tput setaf 2`Variable Part PCRF CDR (After \"&\")`tput sgr0`"
                IFS=";"
                checkLastField=$(echo $ocdr | cut -c $((${#ocdr})))
                if [ -z "$checkLastField" ];then
                        ocdr="$ocdr""-"
                fi
                for i in $ocdr
                do
                        d=$((c+1))
                        getColumnname=$(echo "$columnnames" | cut -d, -f"$d")
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-1s \033[0;39m\n' "                                       " $getColumnname "=" $i
                        let ++c
                done
                IFS=$oldIFS
                echo "`tput setaf 2`--------------------------------------------------------------------------------------------------`tput sgr0`"
        elif [ "$getServiceID" == "45" ];then
                columnnames="Entity Type,Entity Metering Type,Entity ID,Entity Definition ID,Entity Name,Entity Value,Entity Transaction Type"
                ocdr=$(echo "$5" | cut -d'&' -s -f1)
                c=0
                echo "`tput setaf 2`Variable Part Data Usage SPCM CDR (After \"&\")`tput sgr0`"
                IFS=";"
                checkLastField=$(echo $ocdr | cut -c $((${#ocdr})))
                if [ -z "$checkLastField" ];then
                        ocdr="$ocdr""-"
                fi
                for i in $ocdr
                do
                        d=$((c+1))
                        getColumnname=$(echo "$columnnames" | cut -d, -f"$d")
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-1s \033[0;39m\n' "                                       " $getColumnname "=" $i
                        let ++c
                done
                IFS=$oldIFS
                echo "`tput setaf 2`--------------------------------------------------------------------------------------------------`tput sgr0`"
                ocdr=$(echo "$5" | cut -d'&' -s -f2)
                if [ ! -z "$ocdr" ];then
                        c=0
                        echo "`tput setaf 2`Second Variable Part Data Usage SPCM CDR (After \"&\")`tput sgr0`"
                        IFS=";"
                        checkLastField=$(echo $ocdr | cut -c $((${#ocdr})))
                        if [ -z "$checkLastField" ];then
                                ocdr="$ocdr""-"
                        fi
                        for i in $ocdr
                        do
                                d=$((c+1))
                                getColumnname=$(echo "$columnnames" | cut -d, -f"$d")
                                printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-1s \033[0;39m\n' "                                       " $getColumnname "=" $i
                                let ++c
                        done
                        IFS=$oldIFS
                        echo "`tput setaf 2`--------------------------------------------------------------------------------------------------`tput sgr0`"
                fi
                ocdr=$(echo "$5" | cut -d'&' -s -f3)
                if [ ! -z "$ocdr" ];then
                        c=0
                        echo "`tput setaf 2`Thir Variable Part Data Usage SPCM CDR (After \"&\")`tput sgr0`"
                        IFS=";"
                        checkLastField=$(echo $ocdr | cut -c $((${#ocdr})))
                        if [ -z "$checkLastField" ];then
                                ocdr="$ocdr""-"
                        fi
                        for i in $ocdr
                        do
                                d=$((c+1))
                                getColumnname=$(echo "$columnnames" | cut -d, -f"$d")
                                printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-1s \033[0;39m\n' "                                       " $getColumnname "=" $i
                                let ++c
                        done
                        IFS=$oldIFS
                        echo "`tput setaf 2`--------------------------------------------------------------------------------------------------`tput sgr0`"
                fi
        elif [ "$getServiceID" == "7" ];then
                columnnames="Traffic Class,Upstream byte count,Downstream byte count,Charging units consumed"
                ocdr=$(echo "$5" | cut -d'&' -s -f1)
                if [ ! -z "$ocdr" ];then
                        c=0
                        echo "`tput setaf 2`Second Variable Part Data Proxy CDR (After \"&\")`tput sgr0`"
                        IFS=";"
                        checkLastField=$(echo $ocdr | cut -c $((${#ocdr})))
                        if [ -z "$checkLastField" ];then
                                ocdr="$ocdr""-"
                        fi
                        for i in $ocdr
                        do
                                d=$((c+1))
                                getColumnname=$(echo "$columnnames" | cut -d, -f"$d")
                                printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-1s \033[0;39m\n' "                                           " $getColumnname "=" $i
                                let ++c
                        done
                        IFS=$oldIFS
                        echo "`tput setaf 2`--------------------------------------------------------------------------------------------------`tput sgr0`"
                fi
                ocdr=$(echo "$5" | cut -d'&' -s -f2)
                if [ ! -z "$ocdr" ];then
                        c=0
                        echo "`tput setaf 2`Third Variable Part Data Proxy CD (After \"&\")`tput sgr0`"
                        IFS=";"
                        checkLastField=$(echo $ocdr | cut -c $((${#ocdr})))
                        if [ -z "$checkLastField" ];then
                                ocdr="$ocdr""-"
                        fi
                        for i in $ocdr
                        do
                                d=$((c+1))
                                getColumnname=$(echo "$columnnames" | cut -d, -f"$d")
                                printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-1s \033[0;39m\n' "                                           " $getColumnname "=" $i
                                let ++c
                        done
                        IFS=$oldIFS
                        echo "`tput setaf 2`--------------------------------------------------------------------------------------------------`tput sgr0`"
                fi
                IFS=$oldIFS
                ocdr=$(echo "$5" | cut -d'&' -s -f3)
                if [ ! -z "$ocdr" ];then
                        c=0
                        echo "`tput setaf 2`Fourth Variable Part Data Proxy CD (After \"&\")`tput sgr0`"
                        IFS=";"
                        checkLastField=$(echo $ocdr | cut -c $((${#ocdr})))
                        if [ -z "$checkLastField" ];then
                                ocdr="$ocdr""-"
                        fi
                        for i in $ocdr
                        do
                                d=$((c+1))
                                getColumnname=$(echo "$columnnames" | cut -d, -f"$d")
                                printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-1s \033[0;39m\n' "                                           " $getColumnname "=" $i
                                let ++c
                        done
                        IFS=$oldIFS
                        echo "`tput setaf 2`--------------------------------------------------------------------------------------------------`tput sgr0`"
                fi
                IFS=$oldIFS
                ocdr=$(echo "$5" | cut -d'&' -s -f4)
                if [ ! -z "$ocdr" ];then
                        c=0
                        echo "`tput setaf 2`Fifth Variable Part Data Proxy CD (After \"&\")`tput sgr0`"
                        IFS=";"
                        checkLastField=$(echo $ocdr | cut -c $((${#ocdr})))
                        if [ -z "$checkLastField" ];then
                                ocdr="$ocdr""-"
                        fi
                        for i in $ocdr
                        do
                                d=$((c+1))
                                getColumnname=$(echo "$columnnames" | cut -d, -f"$d")
                                printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-1s \033[0;39m\n' "                                           " $getColumnname "=" $i
                                let ++c
                        done
                        IFS=$oldIFS
                        echo "`tput setaf 2`--------------------------------------------------------------------------------------------------`tput sgr0`"
                fi
                IFS=$oldIFS
                if [ ! -z "$ocdr" ];then
                        c=0
                        echo "`tput setaf 2`Sixth Variable Part Data Proxy CD (After \"&\")`tput sgr0`"
                        IFS=";"
                        checkLastField=$(echo $ocdr | cut -c $((${#ocdr})))
                        if [ -z "$checkLastField" ];then
                                ocdr="$ocdr""-"
                        fi
                        for i in $ocdr
                        do
                                d=$((c+1))
                                getColumnname=$(echo "$columnnames" | cut -d, -f"$d")
                                printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-1s \033[0;39m\n' "                                           " $getColumnname "=" $i
                                let ++c
                        done
                        IFS=$oldIFS
                        echo "`tput setaf 2`--------------------------------------------------------------------------------------------------`tput sgr0`"
                fi
        elif [ "$getServiceID" == "108" ];then
                columnnames="Name,Type,Status,Activation Time,Deactivation Time"
                ocdr=$5
                c=0
                echo "`tput setaf 2`Variable Part SPR CDR (After \"&\")`tput sgr0`"
                IFS=";"
                checkLastField=$(echo $ocdr | cut -c $((${#ocdr})))
                if [ -z "$checkLastField" ];then
                        ocdr="$ocdr""-"
                fi
                for i in $ocdr
                do
                        d=$((c+1))
                        getColumnname=$(echo "$columnnames" | cut -d, -f"$d")
                        printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-1s \033[0;39m\n' "                                       " $getColumnname "=" $i
                        let ++c
                done
                IFS=$oldIFS
                echo "`tput setaf 2`--------------------------------------------------------------------------------------------------`tput sgr0`"

        fi

fi
echo ""
}

legasyparseCDR()
{
echo "`tput setaf 2`--------------------------------------------------------------------------------------------------`tput sgr0`"
x=1
oldIFS=$IFS
IFS=","
for in in $cdr
do
        echo "$x) $in"
        x=$(expr $x + 1)
done
IFS=$oldIFS
echo "`tput setaf 2`--------------------------------------------------------------------------------------------------`tput sgr0`"
}


getCDR()
{
cdr=$1
getCDRtype=$(echo "$cdr" | cut -d, -f2,3)
case $getCDRtype in
        17,40)cdr=$(echo "$cdr" | sed -e 's/,17,40,/,17,40,,,/');parseCDR "Subscriber ID,Service ID,Transaction Type,Unused,Unused,Date,Time,CDR Correlation ID,Service Code,Sequence Number,Session Type,Service Definition Index,Service Definition Name,HLR Global Title,IMSI,Location" "iAX-USSD-CDRv2.0.pdf" "USSD SI" "Session Start CDR (17,40)";;
        17,41)cdr=$(echo "$cdr" | sed -e 's/,17,41,/,17,41,,,/');parseCDR "Subscriber ID,Service ID,Transaction Type,Unused,Unused,Date,Time,CDR Correlation ID,Service Code,Total Operation CDRs,Total Content CDRs,Total Session time,Total User Requests,Total User Notifies,Total Service Requests,Total Script Requests,Total Alternative User Request,Total alternative User Notifys,Total TCAP Dialogs,Cause of Termination," "iAX-USSD-CDRv2.0.pdf" "USSD SI" "Session End CDR (17,41)";;
        17,42)cdr=$(echo "$cdr" | sed -e 's/,17,42,/,17,42,,,/');parseCDR "Subscriber ID,Service ID,Transaction Type,Unused,Unused,Date,Time,CDR Correlation ID,Service Code,Sequence Number,Request Bytes,Request Encoding,Request Characters,Response Bytes,Response Encoding,Response Characters,Alternative user MSISDN,Service Instruction Node Index,Service Instruction Node Name,Operation Response Time,Operation Result Code,Raw Error Code,Mapped Error Code,Raw Error Code Type" "iAX-USSD-CDRv2.0.pdf" "USSD SI" "Operation CDR - PROCESS USSD REQUEST";;
        17,43)cdr=$(echo "$cdr" | sed -e 's/,17,43,/,17,43,,,/');parseCDR "Subscriber ID,Service ID,Transaction Type,Unused,Unused,Date,Time,CDR Correlation ID,Service Code,Sequence Number,Request Bytes,Request Encoding,Request Characters,Response Bytes,Response Encoding,Response Characters,Alternative user MSISDN,Service Instruction Node Index,Service Instruction Node Name,Operation Response Time,Operation Result Code,Raw Error Code,Mapped Error Code,Raw Error Code Type" "iAX-USSD-CDRv2.0.pdf" "USSD SI" "Operation CDR - PROCESS USSD RESPONSE";;
        17,44)cdr=$(echo "$cdr" | sed -e 's/,17,44,/,17,44,,,/');parseCDR "Subscriber ID,Service ID,Transaction Type,Unused,Unused,Date,Time,CDR Correlation ID,Service Code,Sequence Number,Request Bytes,Request Encoding,Request Characters,Response Bytes,Response Encoding,Response Characters,Alternative user MSISDN,Service Instruction Node Index,Service Instruction Node Name,Operation Response Time,Operation Result Code,Raw Error Code,Mapped Error Code,Raw Error Code Type" "iAX-USSD-CDRv2.0.pdf" "USSD SI" "Operation CDR - USER REQUEST";;
        17,45)cdr=$(echo "$cdr" | sed -e 's/,17,45,/,17,45,,,/');parseCDR "Subscriber ID,Service ID,Transaction Type,Unused,Unused,Date,Time,CDR Correlation ID,Service Code,Sequence Number,Request Bytes,Request Encoding,Request Characters,Response Bytes,Response Encoding,Response Characters,Alternative user MSISDN,Service Instruction Node Index,Service Instruction Node Name,Operation Response Time,Operation Result Code,Raw Error Code,Mapped Error Code,Raw Error Code Type" "iAX-USSD-CDRv2.0.pdf" "USSD SI" "Operation CDR - USER NOTIFY";;
        17,46)cdr=$(echo "$cdr" | sed -e 's/,17,46,/,17,46,,,/');parseCDR "Subscriber ID,Service ID,Transaction Type,Unused,Unused,Date,Time,CDR Correlation ID,Service Code,Sequence Number,Request Bytes,Request Encoding,Request Characters,Response Bytes,Response Encoding,Response Characters,Alternative user MSISDN,Service Instruction Node Index,Service Instruction Node Name,Operation Response Time,Operation Result Code,Raw Error Code,Mapped Error Code,Raw Error Code Type" "iAX-USSD-CDRv2.0.pdf" "USSD SI" "Operation CDR - SERVER REQUEST";;
        17,47)cdr=$(echo "$cdr" | sed -e 's/,17,47,/,17,47,,,/');parseCDR "Subscriber ID,Service ID,Transaction Type,Unused,Unused,Date,Time,CDR Correlation ID,Service Code,Sequence Number,Request Bytes,Request Encoding,Request Characters,Response Bytes,Response Encoding,Response Characters,Alternative user MSISDN,Service Instruction Node Index,Service Instruction Node Name,Operation Response Time,Operation Result Code,Raw Error Code,Mapped Error Code,Raw Error Code Type" "iAX-USSD-CDRv2.0.pdf" "USSD SI" "Operation CDR - HANDOVER";;
        17,48)cdr=$(echo "$cdr" | sed -e 's/,17,48,/,17,48,,,/');parseCDR "Subscriber ID,Service ID,Transaction Type,Unused,Unused,Date,Time,CDR Correlation ID,Service Code,Sequence Number,Request Bytes,Request Encoding,Request Characters,Response Bytes,Response Encoding,Response Characters,Alternative user MSISDN,Service Instruction Node Index,Service Instruction Node Name,Operation Response Time,Operation Result Code,Raw Error Code,Mapped Error Code,Raw Error Code Type" "iAX-USSD-CDRv2.0.pdf" "USSD SI" "Operation CDR - SCRIPT";;
        17,49)cdr=$(echo "$cdr" | sed -e 's/,17,49,/,17,49,,,/');parseCDR "Subscriber ID,Service ID,Transaction Type,Unused,Unused,Date,Time,CDR Correlation ID,Service Code,Sequence Number,Direction,Number of characters,Num of control chars replaced,USSD Content" "iAX-USSD-CDRv2.0.pdf" "USSD SI" "Content CDR (17,49)";;
        17,60)cdr=$(echo "$cdr" | sed -e 's/,17,60,/,17,60,,,/');parseCDR "Subscriber ID,Service ID,Transaction Type,Unused,Unused,Date,Time,CDR Correlation ID,MSISDN" "iAX-USSD-CDRv2.0.pdf" "MI USSD Egress Dialogue" "Start CDR (17,60)";;
        17,61)cdr=$(echo "$cdr" | sed -e 's/,17,61,/,17,61,,,/');parseCDR "Subscriber ID,Service ID,Transaction Type,Unused,Unused,Date,Time,Source IP,Service Code,?,CDR Correlation ID,?,Error Code" "iAX-USSD-CDRv2.0.pdf" "MI USSD Egress Dialogue" "End CDR (17,61)";;
                17,30)cdr=$(echo "$cdr" | sed -e 's/,17,30,/,17,30,,,/');parseCDR "Subscriber ID,Service ID,Transaction Type,Unused,Unused,MSISDN,Date,Time,CDR Correlation ID" "iAX-USSD-CDRv2.0.pdf" "NI USSD Dialogue" "Start CDR (17,30)";;
        17,25)cdr=$(echo "$cdr" | sed -e 's/,17,25,/,17,26,,,/');parseCDR "Subscriber ID,Service ID,Transaction Type,Unused,Unused,MSISDN,Date,Time,CDR Correlation ID,MSISDN,Sequence Number,Status,Error Code,Application Description,Client Reference" "iAX-USSD-CDRv2.0.pdf" "NI USSD Operation" "USSD Response CDR (17,25)";;
        17,26)cdr=$(echo "$cdr" | sed -e 's/,17,26,/,17,26,,,/');parseCDR "Subscriber ID,Service ID,Transaction Type,Unused,Unused,MSISDN,Date,Time,CDR Correlation ID,Sequence Number,Status,Error Code,Application Description,Client Reference" "iAX-USSD-CDRv2.0.pdf" "NI USSD Operation" "USSD Notify Response CDR (17,26)";;
        17,27)cdr=$(echo "$cdr" | sed -e 's/,17,27,/,17,27,,,/');parseCDR "Subscriber ID,Service ID,Transaction Type,Unused,Unused,MSISDN,Date,Time,CDR Correlation ID,Sequence Number,Content Length,USSD Content,Data Encoding,Reverted Characters,Encoded String" "iAX-USSD-CDRv2.0.pdf" "NI USSD Dialogue Content" "USSD Request Content CDR (17,27)";;
        17,28)cdr=$(echo "$cdr" | sed -e 's/,17,28,/,17,28,,,/');parseCDR "Subscriber ID,Service ID,Transaction Type,Unused,Unused,MSISDN,Date,Time,CDR Correlation ID,Sequence Number,Content Length,USSD Content,Data Encoding,Reverted Characters,Encoded String" "iAX-USSD-CDRv2.0.pdf" "NI USSD Dialogue Content" "USSD Response Content CDR (17,28)";;
        17,29)cdr=$(echo "$cdr" | sed -e 's/,17,29,/,17,29,,,/');parseCDR "Subscriber ID,Service ID,Transaction Type,Unused,Unused,MSISDN,Date,Time,CDR Correlation ID,Sequence Number,Content Length,USSD Content,Data Encoding,Reverted Characters,Encoded String" "iAX-USSD-CDRv2.0.pdf" "NI USSD Dialogue Content" "USSD Notify Content CDR (17,29)";;
        17,31)cdr=$(echo "$cdr" | sed -e 's/,17,31,/,17,31,,,/');parseCDR "Subscriber ID,Service ID,Transaction Type,Unused,Unused,MSISDN,Date,Time,CDR Correlation ID,Dialogue Duration,USSD Notifications Sent,USSD Requests Sent,USSD Responses Received,Bytes Transmitted,Bytes Received,Status,Error Code" "iAX-USSD-CDRv2.0.pdf" "NI USSD Dialogue" "End CDR (17,31)";;
        1063,2)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,MSISDN,Date,Time,Push Message Content,Http Error Code" "Document_no_available_yet" "TMF USSD" "USSD Notification (1063,2)";;
        63,1)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,MSISDN,Date,Time,Trigger,Service Code,Action,Error Code,Campaign ID,Campaign Name,Campaign Type,Campaign Objective,Offer Internal ID,Offer Definition External ID,Offer Message,Cost,Push Channel,Segment,HPLMN,VPLMN,Response Time,Consume Channel,Country,Zone,Offer State" "RTE-CDR-Reference-v7.2.x" "SOM" "No Offer Applicable (63,1)";;
        63,2)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,MSISDN,Date,Time,Trigger,Service Code,Action,Error Code,Campaign ID,Campaign Name,Campaign Type,Campaign Objective,Offer Internal ID,Offer Definition External ID,Offer Message,Cost,Push Channel,Segment,HPLMN,VPLMN,Response Time,Consume Channel,Country,Zone,Offer State" "RTE-CDR-Reference-v7.2.x" "SOM" "Offer Added (63,2)";;
        63,3)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,MSISDN,Date,Time,Trigger,Service Code,Action,Error Code,Campaign ID,Campaign Name,Campaign Type,Campaign Objective,Offer Internal ID,Offer Definition External ID,Offer Message,Cost,Push Channel,Segment,HPLMN,VPLMN,Response Time,Consume Channel,Country,Zone,Offer State" "RTE-CDR-Reference-v7.2.x" "SOM" "Offer Accepted (63,3)";;
        63,4)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,MSISDN,Date,Time,Trigger,Service Code,Action,Error Code,Campaign ID,Campaign Name,Campaign Type,Campaign Objective,Offer Internal ID,Offer Definition External ID,Offer Message,Cost,Push Channel,Segment,HPLMN,VPLMN,Response Time,Consume Channel,Country,Zone,Offer State" "RTE-CDR-Reference-v7.2.x" "SOM" "Offer Expired (63,4)";;
        63,5)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,MSISDN,Date,Time,Trigger,Service Code,Action,Error Code,Campaign ID,Campaign Name,Campaign Type,Campaign Objective,Offer Internal ID,Offer Definition External ID,Offer Message,Cost,Push Channel,Segment,HPLMN,VPLMN,Response Time,Consume Channel,Country,Zone,Offer State" "RTE-CDR-Reference-v7.2.x" "SOM" "Offer Does Not Exist (63,5)";;
        63,6)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,MSISDN,Date,Time,Trigger,Service Code,Action,Error Code,Campaign ID,Campaign Name,Campaign Type,Campaign Objective,Offer Internal ID,Offer Definition External ID,Offer Message,Cost,Push Channel,Segment,HPLMN,VPLMN,Response Time,Consume Channel,Country,Zone,Offer State" "RTE-CDR-Reference-v7.2.x" "SOM" "Offer Already Accepted (63,6)";;
        63,7)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,MSISDN,Date,Time,Trigger,Service Code,Action,Error Code,Campaign ID,Campaign Name,Campaign Type,Campaign Objective,Offer Internal ID,Offer Definition External ID,Offer Message,Cost,Push Channel,Segment,HPLMN,VPLMN,Response Time,Consume Channel,Country,Zone,Offer State" "RTE-CDR-Reference-v7.2.x" "SOM" "Subscriber Daily Limit (63,7)";;
        63,8)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,MSISDN,Date,Time,Trigger,Service Code,Action,Error Code,Campaign ID,Campaign Name,Campaign Type,Campaign Objective,Offer Internal ID,Offer Definition External ID,Offer Message,Cost,Push Channel,Segment,HPLMN,VPLMN,Response Time,Consume Channel,Country,Zone,Offer State" "RTE-CDR-Reference-v7.2.x" "SOM" "Subscriber Weekly Limit (63,8)";;
        63,9)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,MSISDN,Date,Time,Trigger,Service Code,Action,Error Code,Campaign ID,Campaign Name,Campaign Type,Campaign Objective,Offer Internal ID,Offer Definition External ID,Offer Message,Cost,Push Channel,Segment,HPLMN,VPLMN,Response Time,Consume Channel,Country,Zone,Offer State" "RTE-CDR-Reference-v7.2.x" "SOM" "Subscriber Not in Cache (63,9)";;
        63,11)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,MSISDN,Date,Time,Trigger,Service Code,Action,Error Code,Campaign ID,Campaign Name,Campaign Type,Campaign Objective,Offer Internal ID,Offer Definition External ID,Offer Message,Cost,Push Channel,Segment,HPLMN,VPLMN,Response Time,Consume Channel,Country,Zone,Offer State" "RTE-CDR-Reference-v7.2.x" "SOM" "Offer Viewed (63,11)";;
        63,12)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,MSISDN,Date,Time,Trigger,Service Code,Action,Error Code,Campaign ID,Campaign Name,Campaign Type,Campaign Objective,Offer Internal ID,Offer Definition External ID,Offer Message,Cost,Push Channel,Segment,HPLMN,VPLMN,Response Time,Consume Channel,Country,Zone,Offer State" "RTE-CDR-Reference-v7.2.x" "SOM" "Offer Cancelled (63,12)";;
        63,13)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,MSISDN,Date,Time,Trigger,Service Code,Action,Error Code,Campaign ID,Campaign Name,Campaign Type,Campaign Objective,Offer Internal ID,Offer Definition External ID,Offer Message,Cost,Push Channel,Segment,HPLMN,VPLMN,Response Time,Consume Channel,Country,Zone,Offer State" "RTE-CDR-Reference-v7.2.x" "SOM" "Offer Rejected (63,13)";;
        63,15)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,MSISDN,Date,Time,Trigger,Service Code,Action,Error Code,Campaign ID,Campaign Name,Campaign Type,Campaign Objective,Offer Internal ID,Offer Definition External ID,Offer Message,Cost,Push Channel,Segment,HPLMN,VPLMN,Response Time,Consume Channel,Country,Zone,Offer State" "RTE-CDR-Reference-v7.2.x" "SOM" "Offer terminated (63,15)";;
        80,1)parseCDR "Subscriber ID,Service ID,Transaction Type,Service Name,Setting Type,Validity Start,Validity End" "iAX-CM-SDv3.0.pdf" "DND" "Do Not Disturb Manager CDR (80,1)";;
         87,1)parseCDR "msisdn,serviceId,transactionType,tenant,datestamp,timestamp,callReference,parametersMatched,requestHandlerName,requestedReceivedTime,connectionGroupName,connectionNames,connectionRetries,serverResponseCodes,hrgResponseCodes,hrgResponseCode,hrgResponseTime,authConnectionGroupName,authConnectionNames,authConnectionRetries,authServerResponseTimes,authhrgResponseCodes" "http://iel-doc-web-vm1:80/nac-docs/3/cdr/hrg-cdr.html" "HRG" "Request Successful (87,1)";;
        87,2)parseCDR "msisdn,serviceId,transactionType,tenant,datestamp,timestamp,callReference,parametersMatched,requestHandlerName,requestedReceivedTime,connectionGroupName,connectionNames,connectionRetries,serverResponseCodes,hrgResponseCodes,hrgResponseCode,hrgResponseTime,authConnectionGroupName,authConnectionNames,authConnectionRetries,authServerResponseTimes,authhrgResponseCodes" "http://iel-doc-web-vm1:80/nac-docs/3/cdr/hrg-cdr.html" "HRG" "Request Unsuccessful: No Handler Matched (87,2)";;
        87,3)parseCDR "msisdn,serviceId,transactionType,tenant,datestamp,timestamp,callReference,parametersMatched,requestHandlerName,requestedReceivedTime,connectionGroupName,connectionNames,connectionRetries,serverResponseCodes,hrgResponseCodes,hrgResponseCode,hrgResponseTime,authConnectionGroupName,authConnectionNames,authConnectionRetries,authServerResponseTimes,authhrgResponseCodes" "http://iel-doc-web-vm1:80/nac-docs/3/cdr/hrg-cdr.html" "HRG" "Request Unsuccessful: Server Error (87,3)";;
        87,4)parseCDR "msisdn,serviceId,transactionType,tenant,datestamp,timestamp,callReference,parametersMatched,requestHandlerName,requestedReceivedTime,connectionGroupName,connectionNames,connectionRetries,serverResponseCodes,hrgResponseCodes,hrgResponseCode,hrgResponseTime,authConnectionGroupName,authConnectionNames,authConnectionRetries,authServerResponseTimes,authhrgResponseCodes" "http://iel-doc-web-vm1:80/nac-docs/3/cdr/hrg-cdr.html" "HRG" "Request Unsuccessful: Internal Error (87,4)";;
        89,1)parseCDR "subscriberId,serviceId,transactionType,msisdn,activityName,timeToLive,Value,transactionType,createDate" "iAX-CM-SDv3.0.pdf" "Activity Meter" "Request Successful (89,1)";;
        89,2)parseCDR "subscriberId,serviceId,transactionType,msisdn,activityName,timeToLive,Value,transactionType,createDate" "iAX-CM-SDv3.0.pdf" "Activity Meter" "Delete AM Record (89,2)";;
        89,3)parseCDR "subscriberId,serviceId,transactionType,msisdn,activityName,timeToLive,Value,transactionType,createDate" "iAX-CM-SDv3.0.pdf" "Activity Meter" "Request Unsuccessful: Server Error (89,3)";;
        89,4)parseCDR "subscriberId,serviceId,transactionType,msisdn,activityName,timeToLive,Value,transactionType,createDate" "iAX-CM-SDv3.0.pdf" "Activity Meter" "Request Unsuccessful: Internal Error (89,4)";;
        30,1)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,Result Code,CDR Generation Date,CDR Generation Time,Payment Method,Session ID,IMSI,Location Info,Event Info,VAT Rate,Unit Type,Units,Total Cost without Exponent,Loan,Retry Count,Total Cost with Exponent" "iAX-PCC-CDRv7.4.pdf" "OCI Server" "Reservation (charge reservation)(30,1)";;
        30,2)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,Result Code,CDR Generation Date,CDR Generation Time,Payment Method,Session ID,IMSI,Location Info,Event Info,VAT Rate,Unit Type,Units,Total Cost without Exponent,Loan,Retry Count,Total Cost with Exponent" "iAX-PCC-CDRv7.4.pdf" "OCI Server" "Debit (debit of a charge reservation)(30,2)";;
        30,3)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,Result Code,CDR Generation Date,CDR Generation Time,Payment Method,Session ID,IMSI,Location Info,Event Info,VAT Rate,Unit Type,Units,Total Cost without Exponent,Loan,Retry Count,Total Cost with Exponent" "iAX-PCC-CDRv7.4.pdf" "OCI Server" "Direct Debit (direct debit of a charge)(30,3)";;
        30,4)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,Result Code,CDR Generation Date,CDR Generation Time,Payment Method,Session ID,IMSI,Location Info,Event Info,VAT Rate,Unit Type,Units,Total Cost without Exponent,Loan,Retry Count,Total Cost with Exponent" "iAX-PCC-CDRv7.4.pdf" "OCI Server" "Direct Credit (direct credit of a charge)(30,4)";;
        30,5)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,Result Code,CDR Generation Date,CDR Generation Time,Payment Method,Session ID,IMSI,Location Info,Event Info,VAT Rate,Unit Type,Units,Total Cost without Exponent,Loan,Retry Count,Total Cost with Exponent" "iAX-PCC-CDRv7.4.pdf" "OCI Server" "Loan request to Jhotpot interface(30,5)";;
        92,0)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,System,IMSI,Session ID,ICI Cause Code,Cost,Date,Time,HRG Response Type,HRG Response Code,HRG Response String" "iAX-PCC-CDRv7.4.pdf" "OCI Server" "ICI HRG Adaptor CDR(92)";;
        91,1)parseCDR "Subscriber ID,Service ID,UNS Channel,Tenant ID,Created date,Created time,From,User,To,Message,Expiry Date,Expiry Time,Connection ID,Sequence Number,Part Number,Total Parts,Request Status,Request Fail Reason,Request Target" "iAX-PCC-CDRv7.4.pdf" "UNS" "SMS (91,1)";;
        91,2)parseCDR "Subscriber ID,Service ID,UNS Channel,Tenant ID,Created date,Created time,From,User,To,Message,Expiry Date,Expiry Time,Connection ID,Sequence Number,Part Number,Total Parts,Request Status,Request Fail Reason,Request Target" "iAX-PCC-CDRv7.4.pdf" "UNS" "USSD (91,2)";;
        28,1)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "subscriberId,serviceId,transactionType,Tenant ID,Instance ID,Termination Cause Code,Failure Code,Gx Termination Cause,SPR Error Code,SPR Termination Result,DPS Response Code,DS Response Code,CDR Generation Date,CDR Generation Time,CDR Sequence Number,CDR Segment,UE IP Address,UE Info,PDN ID,IP-CAN Type,RAT Type,AN-GW Address,SGSN Address,PLMN ID,User Location Info,RAI,Update Cause,Event Trigger ID,Application Identifier,AF Session ID,PCEF Session ID,Gx Charging ID,AF Session Start Time,AF Session Duration,PCEF Session Start Time,PCEF Session Duration,PCRF Session Start Time,SPR Response Delay,PCRF Session Duration,Total Volume Reported,Total Volume Sent,Total Time Reported,Total Time Sent,Total Session Volume Counted,Cell Load Percent,UEM Profile Key,Requested AAMBR,Authorised AAMBR,Subscriber Plan State,MS Time Zone,UE-IP-Address (IPv6),ANGW_Ipv6_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,IMSI,Dummy Field #1,Dummy Field #2,Dummy Field #3,UE-IP-Address (IPv6)0" "iAX-PCC-CDRv7.4.pdf" "PCRF" "Start Gx CDR (at start of rules-handling session) (28,1)" "$variableCDR";;
        28,2)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "subscriberId,serviceId,transactionType,Tenant ID,Instance ID,Termination Cause Code,Failure Code,Gx Termination Cause,SPR Error Code,SPR Termination Result,DPS Response Code,DS Response Code,CDR Generation Date,CDR Generation Time,CDR Sequence Number,CDR Segment,UE IP Address,UE Info,PDN ID,IP-CAN Type,RAT Type,AN-GW Address,SGSN Address,PLMN ID,User Location Info,RAI,Update Cause,Event Trigger ID,Application Identifier,AF Session ID,PCEF Session ID,Gx Charging ID,AF Session Start Time,AF Session Duration,PCEF Session Start Time,PCEF Session Duration,PCRF Session Start Time,SPR Response Delay,PCRF Session Duration,Total Volume Reported,Total Volume Sent,Total Time Reported,Total Time Sent,Total Session Volume Counted,Cell Load Percent,UEM Profile Key,Requested AAMBR,Authorised AAMBR,Subscriber Plan State,MS Time Zone,UE-IP-Address (IPv6),ANGW_Ipv6_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,IMSI,Dummy Field #1,Dummy Field #2,Dummy Field #3,UE-IP-Address (IPv6)0" "iAX-PCC-CDRv7.4.pdf" "PCRF" "Stop CDR (at end of rules-handling session) (28,2)" "$variableCDR";;
        28,3)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "subscriberId,serviceId,transactionType,Tenant ID,Instance ID,Termination Cause Code,Failure Code,Gx Termination Cause,SPR Error Code,SPR Termination Result,DPS Response Code,DS Response Code,CDR Generation Date,CDR Generation Time,CDR Sequence Number,CDR Segment,UE IP Address,UE Info,PDN ID,IP-CAN Type,RAT Type,AN-GW Address,SGSN Address,PLMN ID,User Location Info,RAI,Update Cause,Event Trigger ID,Application Identifier,AF Session ID,PCEF Session ID,Gx Charging ID,AF Session Start Time,AF Session Duration,PCEF Session Start Time,PCEF Session Duration,PCRF Session Start Time,SPR Response Delay,PCRF Session Duration,Total Volume Reported,Total Volume Sent,Total Time Reported,Total Time Sent,Total Session Volume Counted,Cell Load Percent,UEM Profile Key,Requested AAMBR,Authorised AAMBR,Subscriber Plan State,MS Time Zone,UE-IP-Address (IPv6),ANGW_Ipv6_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,IMSI,Dummy Field #1,Dummy Field #2,Dummy Field #3,UE-IP-Address (IPv6)0" "iAX-PCC-CDRv7.4.pdf" "PCRF" "Interim message CDR (at rules installation/update/removal) (28,3)" "$variableCDR";;
        28,4)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "subscriberId,serviceId,transactionType,Tenant ID,Instance ID,Termination Cause Code,Failure Code,Gx Termination Cause,SPR Error Code,SPR Termination Result,DPS Response Code,DS Response Code,CDR Generation Date,CDR Generation Time,CDR Sequence Number,CDR Segment,UE IP Address,UE Info,PDN ID,IP-CAN Type,RAT Type,AN-GW Address,SGSN Address,PLMN ID,User Location Info,RAI,Update Cause,Event Trigger ID,Application Identifier,AF Session ID,PCEF Session ID,Gx Charging ID,AF Session Start Time,AF Session Duration,PCEF Session Start Time,PCEF Session Duration,PCRF Session Start Time,SPR Response Delay,PCRF Session Duration,Total Volume Reported,Total Volume Sent,Total Time Reported,Total Time Sent,Total Session Volume Counted,Cell Load Percent,UEM Profile Key,Requested AAMBR,Authorised AAMBR,Subscriber Plan State,MS Time Zone,UE-IP-Address (IPv6),ANGW_Ipv6_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,IMSI,Dummy Field #1,Dummy Field #2,Dummy Field #3,UE-IP-Address (IPv6)0" "iAX-PCC-CDRv7.4.pdf" "PCRF" "Restart CDR (at restart of a rules-handling session) (28,4)" "$variableCDR";;
        28,5)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "subscriberId,serviceId,transactionType,Tenant ID,Instance ID,Termination Cause Code,Failure Code,Gx Termination Cause,SPR Error Code,SPR Termination Result,DPS Response Code,DS Response Code,CDR Generation Date,CDR Generation Time,CDR Sequence Number,CDR Segment,UE IP Address,UE Info,PDN ID,IP-CAN Type,RAT Type,AN-GW Address,SGSN Address,PLMN ID,User Location Info,RAI,Update Cause,Event Trigger ID,Application Identifier,AF Session ID,PCEF Session ID,Gx Charging ID,AF Session Start Time,AF Session Duration,PCEF Session Start Time,PCEF Session Duration,PCRF Session Start Time,SPR Response Delay,PCRF Session Duration,Total Volume Reported,Total Volume Sent,Total Time Reported,Total Time Sent,Total Session Volume Counted,Cell Load Percent,UEM Profile Key,Requested AAMBR,Authorised AAMBR,Subscriber Plan State,MS Time Zone,UE-IP-Address (IPv6),ANGW_Ipv6_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,IMSI,Dummy Field #1,Dummy Field #2,Dummy Field #3,UE-IP-Address (IPv6)0" "iAX-PCC-CDRv7.4.pdf" "PCRF" "Heartbeat CDR (28,5)" "$variableCDR";;
        28,10)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "subscriberId,serviceId,transactionType,Tenant ID,Instance ID,Termination Cause Code,Failure Code,Gx Termination Cause,SPR Error Code,SPR Termination Result,DPS Response Code,DS Response Code,CDR Generation Date,CDR Generation Time,CDR Sequence Number,CDR Segment,UE IP Address,UE Info,PDN ID,IP-CAN Type,RAT Type,AN-GW Address,SGSN Address,PLMN ID,User Location Info,RAI,Update Cause,Event Trigger ID,Application Identifier,AF Session ID,PCEF Session ID,Gx Charging ID,AF Session Start Time,AF Session Duration,PCEF Session Start Time,PCEF Session Duration,PCRF Session Start Time,SPR Response Delay,PCRF Session Duration,Total Volume Reported,Total Volume Sent,Total Time Reported,Total Time Sent,Total Session Volume Counted,Cell Load Percent,UEM Profile Key,Requested AAMBR,Authorised AAMBR,Subscriber Plan State,MS Time Zone,UE-IP-Address (IPv6),ANGW_Ipv6_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,IMSI,Dummy Field #1,Dummy Field #2,Dummy Field #3,UE-IP-Address (IPv6)0" "iAX-PCC-CDRv7.4.pdf" "PCRF" "Unexpected CDR (28,10)" "$variableCDR";;
        28,11)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "subscriberId,serviceId,transactionType,Tenant ID,Instance ID,Termination Cause Code,Failure Code,Gx Termination Cause,SPR Error Code,SPR Termination Result,DPS Response Code,DS Response Code,CDR Generation Date,CDR Generation Time,CDR Sequence Number,CDR Segment,UE IP Address,UE Info,PDN ID,IP-CAN Type,RAT Type,AN-GW Address,SGSN Address,PLMN ID,User Location Info,RAI,Update Cause,Event Trigger ID,Application Identifier,AF Session ID,PCEF Session ID,Gx Charging ID,AF Session Start Time,AF Session Duration,PCEF Session Start Time,PCEF Session Duration,PCRF Session Start Time,SPR Response Delay,PCRF Session Duration,Total Volume Reported,Total Volume Sent,Total Time Reported,Total Time Sent,Total Session Volume Counted,Cell Load Percent,UEM Profile Key,Requested AAMBR,Authorised AAMBR,Subscriber Plan State,MS Time Zone,UE-IP-Address (IPv6),ANGW_Ipv6_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,IMSI,Dummy Field #1,Dummy Field #2,Dummy Field #3,UE-IP-Address (IPv6)0" "iAX-PCC-CDRv7.4.pdf" "PCRF" "Queued CDR (28,11)" "$variableCDR";;
        28,101)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "subscriberId,serviceId,transactionType,Tenant ID,Instance ID,Termination Cause Code,Failure Code,Gx Termination Cause,SPR Error Code,SPR Termination Result,DPS Response Code,DS Response Code,CDR Generation Date,CDR Generation Time,CDR Sequence Number,CDR Segment,UE IP Address,UE Info,PDN ID,IP-CAN Type,RAT Type,AN-GW Address,SGSN Address,PLMN ID,User Location Info,RAI,Update Cause,Event Trigger ID,Application Identifier,AF Session ID,PCEF Session ID,Gx Charging ID,AF Session Start Time,AF Session Duration,PCEF Session Start Time,PCEF Session Duration,PCRF Session Start Time,SPR Response Delay,PCRF Session Duration,Total Volume Reported,Total Volume Sent,Total Time Reported,Total Time Sent,Total Session Volume Counted,Cell Load Percent,UEM Profile Key,Requested AAMBR,Authorised AAMBR,Subscriber Plan State,MS Time Zone,UE-IP-Address (IPv6),ANGW_Ipv6_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,IMSI,Dummy Field #1,Dummy Field #2,Dummy Field #3,UE-IP-Address (IPv6)0" "iAX-PCC-CDRv7.4.pdf" "PCRF" "Rx Session Start (28,101)" "$variableCDR";;
        28,102)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "subscriberId,serviceId,transactionType,Tenant ID,Instance ID,Termination Cause Code,Failure Code,Gx Termination Cause,SPR Error Code,SPR Termination Result,DPS Response Code,DS Response Code,CDR Generation Date,CDR Generation Time,CDR Sequence Number,CDR Segment,UE IP Address,UE Info,PDN ID,IP-CAN Type,RAT Type,AN-GW Address,SGSN Address,PLMN ID,User Location Info,RAI,Update Cause,Event Trigger ID,Application Identifier,AF Session ID,PCEF Session ID,Gx Charging ID,AF Session Start Time,AF Session Duration,PCEF Session Start Time,PCEF Session Duration,PCRF Session Start Time,SPR Response Delay,PCRF Session Duration,Total Volume Reported,Total Volume Sent,Total Time Reported,Total Time Sent,Total Session Volume Counted,Cell Load Percent,UEM Profile Key,Requested AAMBR,Authorised AAMBR,Subscriber Plan State,MS Time Zone,UE-IP-Address (IPv6),ANGW_Ipv6_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,IMSI,Dummy Field #1,Dummy Field #2,Dummy Field #3,UE-IP-Address (IPv6)0" "iAX-PCC-CDRv7.4.pdf" "PCRF" "Rx Session Stop (28,102)" "$variableCDR";;
        28,103)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "subscriberId,serviceId,transactionType,Tenant ID,Instance ID,Termination Cause Code,Failure Code,Gx Termination Cause,SPR Error Code,SPR Termination Result,DPS Response Code,DS Response Code,CDR Generation Date,CDR Generation Time,CDR Sequence Number,CDR Segment,UE IP Address,UE Info,PDN ID,IP-CAN Type,RAT Type,AN-GW Address,SGSN Address,PLMN ID,User Location Info,RAI,Update Cause,Event Trigger ID,Application Identifier,AF Session ID,PCEF Session ID,Gx Charging ID,AF Session Start Time,AF Session Duration,PCEF Session Start Time,PCEF Session Duration,PCRF Session Start Time,SPR Response Delay,PCRF Session Duration,Total Volume Reported,Total Volume Sent,Total Time Reported,Total Time Sent,Total Session Volume Counted,Cell Load Percent,UEM Profile Key,Requested AAMBR,Authorised AAMBR,Subscriber Plan State,MS Time Zone,UE-IP-Address (IPv6),ANGW_Ipv6_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,IMSI,Dummy Field #1,Dummy Field #2,Dummy Field #3,UE-IP-Address (IPv6)0" "iAX-PCC-CDRv7.4.pdf" "PCRF" "Rx Session Interim message (28,103)" "$variableCDR";;
        28,201)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "subscriberId,serviceId,transactionType,Tenant ID,Instance ID,Termination Cause Code,Failure Code,Gx Termination Cause,SPR Error Code,SPR Termination Result,DPS Response Code,DS Response Code,CDR Generation Date,CDR Generation Time,CDR Sequence Number,CDR Segment,UE IP Address,UE Info,PDN ID,IP-CAN Type,RAT Type,AN-GW Address,SGSN Address,PLMN ID,User Location Info,RAI,Update Cause,Event Trigger ID,Application Identifier,AF Session ID,PCEF Session ID,Gx Charging ID,AF Session Start Time,AF Session Duration,PCEF Session Start Time,PCEF Session Duration,PCRF Session Start Time,SPR Response Delay,PCRF Session Duration,Total Volume Reported,Total Volume Sent,Total Time Reported,Total Time Sent,Total Session Volume Counted,Cell Load Percent,UEM Profile Key,Requested AAMBR,Authorised AAMBR,Subscriber Plan State,MS Time Zone,UE-IP-Address (IPv6),ANGW_Ipv6_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,IMSI,Dummy Field #1,Dummy Field #2,Dummy Field #3,UE-IP-Address (IPv6)0" "iAX-PCC-CDRv7.4.pdf" "PCRF" "Gy Session Start  (28,201)" "$variableCDR";;
        28,202)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "subscriberId,serviceId,transactionType,Tenant ID,Instance ID,Termination Cause Code,Failure Code,Gx Termination Cause,SPR Error Code,SPR Termination Result,DPS Response Code,DS Response Code,CDR Generation Date,CDR Generation Time,CDR Sequence Number,CDR Segment,UE IP Address,UE Info,PDN ID,IP-CAN Type,RAT Type,AN-GW Address,SGSN Address,PLMN ID,User Location Info,RAI,Update Cause,Event Trigger ID,Application Identifier,AF Session ID,PCEF Session ID,Gx Charging ID,AF Session Start Time,AF Session Duration,PCEF Session Start Time,PCEF Session Duration,PCRF Session Start Time,SPR Response Delay,PCRF Session Duration,Total Volume Reported,Total Volume Sent,Total Time Reported,Total Time Sent,Total Session Volume Counted,Cell Load Percent,UEM Profile Key,Requested AAMBR,Authorised AAMBR,Subscriber Plan State,MS Time Zone,UE-IP-Address (IPv6),ANGW_Ipv6_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,IMSI,Dummy Field #1,Dummy Field #2,Dummy Field #3,UE-IP-Address (IPv6)0" "iAX-PCC-CDRv7.4.pdf" "PCRF" "Gy Session Stop  (28,202)" "$variableCDR";;
        28,203)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "subscriberId,serviceId,transactionType,Tenant ID,Instance ID,Termination Cause Code,Failure Code,Gx Termination Cause,SPR Error Code,SPR Termination Result,DPS Response Code,DS Response Code,CDR Generation Date,CDR Generation Time,CDR Sequence Number,CDR Segment,UE IP Address,UE Info,PDN ID,IP-CAN Type,RAT Type,AN-GW Address,SGSN Address,PLMN ID,User Location Info,RAI,Update Cause,Event Trigger ID,Application Identifier,AF Session ID,PCEF Session ID,Gx Charging ID,AF Session Start Time,AF Session Duration,PCEF Session Start Time,PCEF Session Duration,PCRF Session Start Time,SPR Response Delay,PCRF Session Duration,Total Volume Reported,Total Volume Sent,Total Time Reported,Total Time Sent,Total Session Volume Counted,Cell Load Percent,UEM Profile Key,Requested AAMBR,Authorised AAMBR,Subscriber Plan State,MS Time Zone,UE-IP-Address (IPv6),ANGW_Ipv6_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,IMSI,Dummy Field #1,Dummy Field #2,Dummy Field #3,UE-IP-Address (IPv6)0" "iAX-PCC-CDRv7.4.pdf" "PCRF" "Gy Session Interim  (28,203)" "$variableCDR";;
        28,204)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "subscriberId,serviceId,transactionType,Tenant ID,Instance ID,Termination Cause Code,Failure Code,Gx Termination Cause,SPR Error Code,SPR Termination Result,DPS Response Code,DS Response Code,CDR Generation Date,CDR Generation Time,CDR Sequence Number,CDR Segment,UE IP Address,UE Info,PDN ID,IP-CAN Type,RAT Type,AN-GW Address,SGSN Address,PLMN ID,User Location Info,RAI,Update Cause,Event Trigger ID,Application Identifier,AF Session ID,PCEF Session ID,Gx Charging ID,AF Session Start Time,AF Session Duration,PCEF Session Start Time,PCEF Session Duration,PCRF Session Start Time,SPR Response Delay,PCRF Session Duration,Total Volume Reported,Total Volume Sent,Total Time Reported,Total Time Sent,Total Session Volume Counted,Cell Load Percent,UEM Profile Key,Requested AAMBR,Authorised AAMBR,Subscriber Plan State,MS Time Zone,UE-IP-Address (IPv6),ANGW_Ipv6_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,IMSI,Dummy Field #1,Dummy Field #2,Dummy Field #3,UE-IP-Address (IPv6)0" "iAX-PCC-CDRv7.4.pdf" "PCRF" "Gy Session Event message (28,204)" "$variableCDR";;
        38,0)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,CDR Generation Date,CDR Generation Time,IMSI,Payment Type,Subscriber Class,Subscriber Language,Subscriber State,Group Flag,Group Identifier,Discount Flag,DPS Notification Flag,EOS Notification Flag,PAYG Notification Flag,Home Location Zone,Renewal Date,Qos Category Name,Subscriber ID,Tag field" "iAX-PCC-CDRv7.4.pdf" "SPCM" "SUBSCRIBER LIFECYCLE - Subscriber Creation (38,0)";;
        38,1)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,CDR Generation Date,CDR Generation Time,IMSI,Payment Type,Subscriber Class,Subscriber Language,Subscriber State,Group Flag,Group Identifier,Discount Flag,DPS Notification Flag,EOS Notification Flag,PAYG Notification Flag,Home Location Zone,Renewal Date,Qos Category Name,Subscriber ID,Tag field" "iAX-PCC-CDRv7.4.pdf" "SPCM" "SUBSCRIBER LIFECYCLE - Subscriber Creation Failure (38,1)";;
        38,2)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,CDR Generation Date,CDR Generation Time,IMSI,Payment Type,Subscriber Class,Subscriber Language,Subscriber State,Group Flag,Group Identifier,Discount Flag,DPS Notification Flag,EOS Notification Flag,PAYG Notification Flag,Home Location Zone,Renewal Date,Qos Category Name,Subscriber ID,Tag field" "iAX-PCC-CDRv7.4.pdf" "SPCM" "SUBSCRIBER LIFECYCLE - Subscriber Update (38,2)";;
        38,3)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,CDR Generation Date,CDR Generation Time,IMSI,Payment Type,Subscriber Class,Subscriber Language,Subscriber State,Group Flag,Group Identifier,Discount Flag,DPS Notification Flag,EOS Notification Flag,PAYG Notification Flag,Home Location Zone,Renewal Date,Qos Category Name,Subscriber ID,Tag field" "iAX-PCC-CDRv7.4.pdf" "SPCM" "SUBSCRIBER LIFECYCLE - Subscriber Update Failure (38,3)";;
        38,4)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,CDR Generation Date,CDR Generation Time,IMSI,Payment Type,Subscriber Class,Subscriber Language,Subscriber State,Group Flag,Group Identifier,Discount Flag,DPS Notification Flag,EOS Notification Flag,PAYG Notification Flag,Home Location Zone,Renewal Date,Qos Category Name,Subscriber ID,Tag field" "iAX-PCC-CDRv7.4.pdf" "SPCM" "SUBSCRIBER LIFECYCLE - Subscriber Deletion (38,4)";;
        38,5)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,CDR Generation Date,CDR Generation Time,IMSI,Payment Type,Subscriber Class,Subscriber Language,Subscriber State,Group Flag,Group Identifier,Discount Flag,DPS Notification Flag,EOS Notification Flag,PAYG Notification Flag,Home Location Zone,Renewal Date,Qos Category Name,Subscriber ID,Tag field" "iAX-PCC-CDRv7.4.pdf" "SPCM" "SUBSCRIBER LIFECYCLE - Subscriber Deletion Failure (38,5)";;
        39,0)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,CDR Generation Date,CDR Generation Time,Payment Type,Cost,Plan Name,Plan Version,Plan ID,Plan Type,Plan Classification,Shared Plan Flag,Max Occurrence Count,Plan Precedence,Plan State,Plan Purchase Source,Plan Purchase Date,Plan Purchase Time,Plan Activation Date,Plan Activation Time,Plan Expiry Date,Plan Expiry Time,Plan Deactivation Count,Plan Recurrence Flag,Plan Recurrence Count,Plan Metering Type,Plan Volume/Time Limit,Plan Purchase Type,Plan Limit Adjustments,Discount Type,Cancellation Cause,Number Validity Boosters,Number Volume Boosters,Booster Source,Booster Cost,Plan Cost,VAT Rate,Chargeable Subscriber,Purchase Tags,Loan Amount,Validity Carry Forward Count,IMSI,Unit Amount,Validity Period" "iAX-PCC-CDRv7.4.pdf" "SPCM" "SUBSCRIBER PLAN - Plan purchased (39,0)";;
        39,1)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,CDR Generation Date,CDR Generation Time,Payment Type,Cost,Plan Name,Plan Version,Plan ID,Plan Type,Plan Classification,Shared Plan Flag,Max Occurrence Count,Plan Precedence,Plan State,Plan Purchase Source,Plan Purchase Date,Plan Purchase Time,Plan Activation Date,Plan Activation Time,Plan Expiry Date,Plan Expiry Time,Plan Deactivation Count,Plan Recurrence Flag,Plan Recurrence Count,Plan Metering Type,Plan Volume/Time Limit,Plan Purchase Type,Plan Limit Adjustments,Discount Type,Cancellation Cause,Number Validity Boosters,Number Volume Boosters,Booster Source,Booster Cost,Plan Cost,VAT Rate,Chargeable Subscriber,Purchase Tags,Loan Amount,Validity Carry Forward Count,IMSI,Unit Amount,Validity Period" "iAX-PCC-CDRv7.4.pdf" "SPCM" "SUBSCRIBER PLAN - Plan purchase failure (39,1)";;
        39,2)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,CDR Generation Date,CDR Generation Time,Payment Type,Cost,Plan Name,Plan Version,Plan ID,Plan Type,Plan Classification,Shared Plan Flag,Max Occurrence Count,Plan Precedence,Plan State,Plan Purchase Source,Plan Purchase Date,Plan Purchase Time,Plan Activation Date,Plan Activation Time,Plan Expiry Date,Plan Expiry Time,Plan Deactivation Count,Plan Recurrence Flag,Plan Recurrence Count,Plan Metering Type,Plan Volume/Time Limit,Plan Purchase Type,Plan Limit Adjustments,Discount Type,Cancellation Cause,Number Validity Boosters,Number Volume Boosters,Booster Source,Booster Cost,Plan Cost,VAT Rate,Chargeable Subscriber,Purchase Tags,Loan Amount,Validity Carry Forward Count,IMSI,Unit Amount,Validity Period" "iAX-PCC-CDRv7.4.pdf" "SPCM" "SUBSCRIBER PLAN - Plan activation (39,2)";;
        39,3)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,CDR Generation Date,CDR Generation Time,Payment Type,Cost,Plan Name,Plan Version,Plan ID,Plan Type,Plan Classification,Shared Plan Flag,Max Occurrence Count,Plan Precedence,Plan State,Plan Purchase Source,Plan Purchase Date,Plan Purchase Time,Plan Activation Date,Plan Activation Time,Plan Expiry Date,Plan Expiry Time,Plan Deactivation Count,Plan Recurrence Flag,Plan Recurrence Count,Plan Metering Type,Plan Volume/Time Limit,Plan Purchase Type,Plan Limit Adjustments,Discount Type,Cancellation Cause,Number Validity Boosters,Number Volume Boosters,Booster Source,Booster Cost,Plan Cost,VAT Rate,Chargeable Subscriber,Purchase Tags,Loan Amount,Validity Carry Forward Count,IMSI,Unit Amount,Validity Period" "iAX-PCC-CDRv7.4.pdf" "SPCM" "SUBSCRIBER PLAN - Plan de-activation (39,3)";;
        39,4)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,CDR Generation Date,CDR Generation Time,Payment Type,Cost,Plan Name,Plan Version,Plan ID,Plan Type,Plan Classification,Shared Plan Flag,Max Occurrence Count,Plan Precedence,Plan State,Plan Purchase Source,Plan Purchase Date,Plan Purchase Time,Plan Activation Date,Plan Activation Time,Plan Expiry Date,Plan Expiry Time,Plan Deactivation Count,Plan Recurrence Flag,Plan Recurrence Count,Plan Metering Type,Plan Volume/Time Limit,Plan Purchase Type,Plan Limit Adjustments,Discount Type,Cancellation Cause,Number Validity Boosters,Number Volume Boosters,Booster Source,Booster Cost,Plan Cost,VAT Rate,Chargeable Subscriber,Purchase Tags,Loan Amount,Validity Carry Forward Count,IMSI,Unit Amount,Validity Period" "iAX-PCC-CDRv7.4.pdf" "SPCM" "SUBSCRIBER PLAN - Usage consumed (39,4)";;
        39,5)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,CDR Generation Date,CDR Generation Time,Payment Type,Cost,Plan Name,Plan Version,Plan ID,Plan Type,Plan Classification,Shared Plan Flag,Max Occurrence Count,Plan Precedence,Plan State,Plan Purchase Source,Plan Purchase Date,Plan Purchase Time,Plan Activation Date,Plan Activation Time,Plan Expiry Date,Plan Expiry Time,Plan Deactivation Count,Plan Recurrence Flag,Plan Recurrence Count,Plan Metering Type,Plan Volume/Time Limit,Plan Purchase Type,Plan Limit Adjustments,Discount Type,Cancellation Cause,Number Validity Boosters,Number Volume Boosters,Booster Source,Booster Cost,Plan Cost,VAT Rate,Chargeable Subscriber,Purchase Tags,Loan Amount,Validity Carry Forward Count,IMSI,Unit Amount,Validity Period" "iAX-PCC-CDRv7.4.pdf" "SPCM" "SUBSCRIBER PLAN - Plan expiry (39,5)";;
        39,6)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,CDR Generation Date,CDR Generation Time,Payment Type,Cost,Plan Name,Plan Version,Plan ID,Plan Type,Plan Classification,Shared Plan Flag,Max Occurrence Count,Plan Precedence,Plan State,Plan Purchase Source,Plan Purchase Date,Plan Purchase Time,Plan Activation Date,Plan Activation Time,Plan Expiry Date,Plan Expiry Time,Plan Deactivation Count,Plan Recurrence Flag,Plan Recurrence Count,Plan Metering Type,Plan Volume/Time Limit,Plan Purchase Type,Plan Limit Adjustments,Discount Type,Cancellation Cause,Number Validity Boosters,Number Volume Boosters,Booster Source,Booster Cost,Plan Cost,VAT Rate,Chargeable Subscriber,Purchase Tags,Loan Amount,Validity Carry Forward Count,IMSI,Unit Amount,Validity Period" "iAX-PCC-CDRv7.4.pdf" "SPCM" "SUBSCRIBER PLAN - Plan cancellation (39,6)";;
        39,7)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,CDR Generation Date,CDR Generation Time,Payment Type,Cost,Plan Name,Plan Version,Plan ID,Plan Type,Plan Classification,Shared Plan Flag,Max Occurrence Count,Plan Precedence,Plan State,Plan Purchase Source,Plan Purchase Date,Plan Purchase Time,Plan Activation Date,Plan Activation Time,Plan Expiry Date,Plan Expiry Time,Plan Deactivation Count,Plan Recurrence Flag,Plan Recurrence Count,Plan Metering Type,Plan Volume/Time Limit,Plan Purchase Type,Plan Limit Adjustments,Discount Type,Cancellation Cause,Number Validity Boosters,Number Volume Boosters,Booster Source,Booster Cost,Plan Cost,VAT Rate,Chargeable Subscriber,Purchase Tags,Loan Amount,Validity Carry Forward Count,IMSI,Unit Amount,Validity Period" "iAX-PCC-CDRv7.4.pdf" "SPCM" "SUBSCRIBER PLAN - Plan provisioning failure (39,7)";;
        39,8)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,CDR Generation Date,CDR Generation Time,Payment Type,Cost,Plan Name,Plan Version,Plan ID,Plan Type,Plan Classification,Shared Plan Flag,Max Occurrence Count,Plan Precedence,Plan State,Plan Purchase Source,Plan Purchase Date,Plan Purchase Time,Plan Activation Date,Plan Activation Time,Plan Expiry Date,Plan Expiry Time,Plan Deactivation Count,Plan Recurrence Flag,Plan Recurrence Count,Plan Metering Type,Plan Volume/Time Limit,Plan Purchase Type,Plan Limit Adjustments,Discount Type,Cancellation Cause,Number Validity Boosters,Number Volume Boosters,Booster Source,Booster Cost,Plan Cost,VAT Rate,Chargeable Subscriber,Purchase Tags,Loan Amount,Validity Carry Forward Count,IMSI,Unit Amount,Validity Period" "iAX-PCC-CDRv7.4.pdf" "SPCM" "SUBSCRIBER PLAN - Plan termination (39,8)";;
        39,9)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,CDR Generation Date,CDR Generation Time,Payment Type,Cost,Plan Name,Plan Version,Plan ID,Plan Type,Plan Classification,Shared Plan Flag,Max Occurrence Count,Plan Precedence,Plan State,Plan Purchase Source,Plan Purchase Date,Plan Purchase Time,Plan Activation Date,Plan Activation Time,Plan Expiry Date,Plan Expiry Time,Plan Deactivation Count,Plan Recurrence Flag,Plan Recurrence Count,Plan Metering Type,Plan Volume/Time Limit,Plan Purchase Type,Plan Limit Adjustments,Discount Type,Cancellation Cause,Number Validity Boosters,Number Volume Boosters,Booster Source,Booster Cost,Plan Cost,VAT Rate,Chargeable Subscriber,Purchase Tags,Loan Amount,Validity Carry Forward Count,IMSI,Unit Amount,Validity Period" "iAX-PCC-CDRv7.4.pdf" "SPCM" "SUBSCRIBER PLAN - Plan volume top up (39,9)";;
        39,10)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,CDR Generation Date,CDR Generation Time,Payment Type,Cost,Plan Name,Plan Version,Plan ID,Plan Type,Plan Classification,Shared Plan Flag,Max Occurrence Count,Plan Precedence,Plan State,Plan Purchase Source,Plan Purchase Date,Plan Purchase Time,Plan Activation Date,Plan Activation Time,Plan Expiry Date,Plan Expiry Time,Plan Deactivation Count,Plan Recurrence Flag,Plan Recurrence Count,Plan Metering Type,Plan Volume/Time Limit,Plan Purchase Type,Plan Limit Adjustments,Discount Type,Cancellation Cause,Number Validity Boosters,Number Volume Boosters,Booster Source,Booster Cost,Plan Cost,VAT Rate,Chargeable Subscriber,Purchase Tags,Loan Amount,Validity Carry Forward Count,IMSI,Unit Amount,Validity Period" "iAX-PCC-CDRv7.4.pdf" "SPCM" "SUBSCRIBER PLAN - Plan validity period top up (39,10)";;
        39,11)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,CDR Generation Date,CDR Generation Time,Payment Type,Cost,Plan Name,Plan Version,Plan ID,Plan Type,Plan Classification,Shared Plan Flag,Max Occurrence Count,Plan Precedence,Plan State,Plan Purchase Source,Plan Purchase Date,Plan Purchase Time,Plan Activation Date,Plan Activation Time,Plan Expiry Date,Plan Expiry Time,Plan Deactivation Count,Plan Recurrence Flag,Plan Recurrence Count,Plan Metering Type,Plan Volume/Time Limit,Plan Purchase Type,Plan Limit Adjustments,Discount Type,Cancellation Cause,Number Validity Boosters,Number Volume Boosters,Booster Source,Booster Cost,Plan Cost,VAT Rate,Chargeable Subscriber,Purchase Tags,Loan Amount,Validity Carry Forward Count,IMSI,Unit Amount,Validity Period" "iAX-PCC-CDRv7.4.pdf" "SPCM" "SUBSCRIBER PLAN - Plan top up time (39,11)";;
        39,12)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,CDR Generation Date,CDR Generation Time,Payment Type,Cost,Plan Name,Plan Version,Plan ID,Plan Type,Plan Classification,Shared Plan Flag,Max Occurrence Count,Plan Precedence,Plan State,Plan Purchase Source,Plan Purchase Date,Plan Purchase Time,Plan Activation Date,Plan Activation Time,Plan Expiry Date,Plan Expiry Time,Plan Deactivation Count,Plan Recurrence Flag,Plan Recurrence Count,Plan Metering Type,Plan Volume/Time Limit,Plan Purchase Type,Plan Limit Adjustments,Discount Type,Cancellation Cause,Number Validity Boosters,Number Volume Boosters,Booster Source,Booster Cost,Plan Cost,VAT Rate,Chargeable Subscriber,Purchase Tags,Loan Amount,Validity Carry Forward Count,IMSI,Unit Amount,Validity Period" "iAX-PCC-CDRv7.4.pdf" "SPCM" "SUBSCRIBER PLAN - Usage available (39,12)";;
        39,13)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,CDR Generation Date,CDR Generation Time,Payment Type,Cost,Plan Name,Plan Version,Plan ID,Plan Type,Plan Classification,Shared Plan Flag,Max Occurrence Count,Plan Precedence,Plan State,Plan Purchase Source,Plan Purchase Date,Plan Purchase Time,Plan Activation Date,Plan Activation Time,Plan Expiry Date,Plan Expiry Time,Plan Deactivation Count,Plan Recurrence Flag,Plan Recurrence Count,Plan Metering Type,Plan Volume/Time Limit,Plan Purchase Type,Plan Limit Adjustments,Discount Type,Cancellation Cause,Number Validity Boosters,Number Volume Boosters,Booster Source,Booster Cost,Plan Cost,VAT Rate,Chargeable Subscriber,Purchase Tags,Loan Amount,Validity Carry Forward Count,IMSI,Unit Amount,Validity Period" "iAX-PCC-CDRv7.4.pdf" "SPCM" "SUBSCRIBER PLAN - Plan renewal parked (39,13)";;
        39,14)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,CDR Generation Date,CDR Generation Time,Payment Type,Cost,Plan Name,Plan Version,Plan ID,Plan Type,Plan Classification,Shared Plan Flag,Max Occurrence Count,Plan Precedence,Plan State,Plan Purchase Source,Plan Purchase Date,Plan Purchase Time,Plan Activation Date,Plan Activation Time,Plan Expiry Date,Plan Expiry Time,Plan Deactivation Count,Plan Recurrence Flag,Plan Recurrence Count,Plan Metering Type,Plan Volume/Time Limit,Plan Purchase Type,Plan Limit Adjustments,Discount Type,Cancellation Cause,Number Validity Boosters,Number Volume Boosters,Booster Source,Booster Cost,Plan Cost,VAT Rate,Chargeable Subscriber,Purchase Tags,Loan Amount,Validity Carry Forward Count,IMSI,Unit Amount,Validity Period" "iAX-PCC-CDRv7.4.pdf" "SPCM" "SUBSCRIBER PLAN - Plan refunded (39,14)";;
        39,15)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,CDR Generation Date,CDR Generation Time,Payment Type,Cost,Plan Name,Plan Version,Plan ID,Plan Type,Plan Classification,Shared Plan Flag,Max Occurrence Count,Plan Precedence,Plan State,Plan Purchase Source,Plan Purchase Date,Plan Purchase Time,Plan Activation Date,Plan Activation Time,Plan Expiry Date,Plan Expiry Time,Plan Deactivation Count,Plan Recurrence Flag,Plan Recurrence Count,Plan Metering Type,Plan Volume/Time Limit,Plan Purchase Type,Plan Limit Adjustments,Discount Type,Cancellation Cause,Number Validity Boosters,Number Volume Boosters,Booster Source,Booster Cost,Plan Cost,VAT Rate,Chargeable Subscriber,Purchase Tags,Loan Amount,Validity Carry Forward Count,IMSI,Unit Amount,Validity Period" "iAX-PCC-CDRv7.4.pdf" "SPCM" "SUBSCRIBER PLAN - Plan refund deferred (39,15)";;
        39,16)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,CDR Generation Date,CDR Generation Time,Payment Type,Cost,Plan Name,Plan Version,Plan ID,Plan Type,Plan Classification,Shared Plan Flag,Max Occurrence Count,Plan Precedence,Plan State,Plan Purchase Source,Plan Purchase Date,Plan Purchase Time,Plan Activation Date,Plan Activation Time,Plan Expiry Date,Plan Expiry Time,Plan Deactivation Count,Plan Recurrence Flag,Plan Recurrence Count,Plan Metering Type,Plan Volume/Time Limit,Plan Purchase Type,Plan Limit Adjustments,Discount Type,Cancellation Cause,Number Validity Boosters,Number Volume Boosters,Booster Source,Booster Cost,Plan Cost,VAT Rate,Chargeable Subscriber,Purchase Tags,Loan Amount,Validity Carry Forward Count,IMSI,Unit Amount,Validity Period" "iAX-PCC-CDRv7.4.pdf" "SPCM" "SUBSCRIBER PLAN - Not in use (39,16)";;
        39,17)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,CDR Generation Date,CDR Generation Time,Payment Type,Cost,Plan Name,Plan Version,Plan ID,Plan Type,Plan Classification,Shared Plan Flag,Max Occurrence Count,Plan Precedence,Plan State,Plan Purchase Source,Plan Purchase Date,Plan Purchase Time,Plan Activation Date,Plan Activation Time,Plan Expiry Date,Plan Expiry Time,Plan Deactivation Count,Plan Recurrence Flag,Plan Recurrence Count,Plan Metering Type,Plan Volume/Time Limit,Plan Purchase Type,Plan Limit Adjustments,Discount Type,Cancellation Cause,Number Validity Boosters,Number Volume Boosters,Booster Source,Booster Cost,Plan Cost,VAT Rate,Chargeable Subscriber,Purchase Tags,Loan Amount,Validity Carry Forward Count,IMSI,Unit Amount,Validity Period" "iAX-PCC-CDRv7.4.pdf" "SPCM" "SUBSCRIBER PLAN - Plan Activation Pending Timeout (39,17)";;
        39,18)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,CDR Generation Date,CDR Generation Time,Payment Type,Cost,Plan Name,Plan Version,Plan ID,Plan Type,Plan Classification,Shared Plan Flag,Max Occurrence Count,Plan Precedence,Plan State,Plan Purchase Source,Plan Purchase Date,Plan Purchase Time,Plan Activation Date,Plan Activation Time,Plan Expiry Date,Plan Expiry Time,Plan Deactivation Count,Plan Recurrence Flag,Plan Recurrence Count,Plan Metering Type,Plan Volume/Time Limit,Plan Purchase Type,Plan Limit Adjustments,Discount Type,Cancellation Cause,Number Validity Boosters,Number Volume Boosters,Booster Source,Booster Cost,Plan Cost,VAT Rate,Chargeable Subscriber,Purchase Tags,Loan Amount,Validity Carry Forward Count,IMSI,Unit Amount,Validity Period" "iAX-PCC-CDRv7.4.pdf" "SPCM" "SUBSCRIBER PLAN - Plan Validity Carried Forward (39,18)";;
        39,19)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,CDR Generation Date,CDR Generation Time,Payment Type,Cost,Plan Name,Plan Version,Plan ID,Plan Type,Plan Classification,Shared Plan Flag,Max Occurrence Count,Plan Precedence,Plan State,Plan Purchase Source,Plan Purchase Date,Plan Purchase Time,Plan Activation Date,Plan Activation Time,Plan Expiry Date,Plan Expiry Time,Plan Deactivation Count,Plan Recurrence Flag,Plan Recurrence Count,Plan Metering Type,Plan Volume/Time Limit,Plan Purchase Type,Plan Limit Adjustments,Discount Type,Cancellation Cause,Number Validity Boosters,Number Volume Boosters,Booster Source,Booster Cost,Plan Cost,VAT Rate,Chargeable Subscriber,Purchase Tags,Loan Amount,Validity Carry Forward Count,IMSI,Unit Amount,Validity Period" "iAX-PCC-CDRv7.4.pdf" "SPCM" "SUBSCRIBER PLAN - Plan Volume has been boosted (39,19)";;
        39,20)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,CDR Generation Date,CDR Generation Time,Payment Type,Cost,Plan Name,Plan Version,Plan ID,Plan Type,Plan Classification,Shared Plan Flag,Max Occurrence Count,Plan Precedence,Plan State,Plan Purchase Source,Plan Purchase Date,Plan Purchase Time,Plan Activation Date,Plan Activation Time,Plan Expiry Date,Plan Expiry Time,Plan Deactivation Count,Plan Recurrence Flag,Plan Recurrence Count,Plan Metering Type,Plan Volume/Time Limit,Plan Purchase Type,Plan Limit Adjustments,Discount Type,Cancellation Cause,Number Validity Boosters,Number Volume Boosters,Booster Source,Booster Cost,Plan Cost,VAT Rate,Chargeable Subscriber,Purchase Tags,Loan Amount,Validity Carry Forward Count,IMSI,Unit Amount,Validity Period" "iAX-PCC-CDRv7.4.pdf" "SPCM" "SUBSCRIBER PLAN - Plan Validity has been boosted (39,20)";;
        39,21)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,CDR Generation Date,CDR Generation Time,Payment Type,Cost,Plan Name,Plan Version,Plan ID,Plan Type,Plan Classification,Shared Plan Flag,Max Occurrence Count,Plan Precedence,Plan State,Plan Purchase Source,Plan Purchase Date,Plan Purchase Time,Plan Activation Date,Plan Activation Time,Plan Expiry Date,Plan Expiry Time,Plan Deactivation Count,Plan Recurrence Flag,Plan Recurrence Count,Plan Metering Type,Plan Volume/Time Limit,Plan Purchase Type,Plan Limit Adjustments,Discount Type,Cancellation Cause,Number Validity Boosters,Number Volume Boosters,Booster Source,Booster Cost,Plan Cost,VAT Rate,Chargeable Subscriber,Purchase Tags,Loan Amount,Validity Carry Forward Count,IMSI,Unit Amount,Validity Period" "iAX-PCC-CDRv7.4.pdf" "SPCM" "SUBSCRIBER PLAN - Failure to charge for plan booster (39,21)";;
        39,22)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,CDR Generation Date,CDR Generation Time,Payment Type,Cost,Plan Name,Plan Version,Plan ID,Plan Type,Plan Classification,Shared Plan Flag,Max Occurrence Count,Plan Precedence,Plan State,Plan Purchase Source,Plan Purchase Date,Plan Purchase Time,Plan Activation Date,Plan Activation Time,Plan Expiry Date,Plan Expiry Time,Plan Deactivation Count,Plan Recurrence Flag,Plan Recurrence Count,Plan Metering Type,Plan Volume/Time Limit,Plan Purchase Type,Plan Limit Adjustments,Discount Type,Cancellation Cause,Number Validity Boosters,Number Volume Boosters,Booster Source,Booster Cost,Plan Cost,VAT Rate,Chargeable Subscriber,Purchase Tags,Loan Amount,Validity Carry Forward Count,IMSI,Unit Amount,Validity Period" "iAX-PCC-CDRv7.4.pdf" "SPCM" "SUBSCRIBER PLAN - Booster charged successfully;however, application of the booster failed (39,22)";;
        40,0)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,Update Cause,CDR Generation Date,CDR Generation Time,Plan Name,Plan Precedence,Rule Name,IMSI,Parent Plan Name,Parent Plan Precedence,PCC Profile Name,PCC Profile Precedence" "iAX-PCC-CDRv7.4.pdf" "SPCM" "SUBSCRIBER PROFILE - Subscriber profile creation (40,0)";;
        40,1)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,Update Cause,CDR Generation Date,CDR Generation Time,Plan Name,Plan Precedence,Rule Name,IMSI,Parent Plan Name,Parent Plan Precedence,PCC Profile Name,PCC Profile Precedence" "iAX-PCC-CDRv7.4.pdf" "SPCM" "SUBSCRIBER PROFILE - Subscriber profile update (40,1)";;
        45,0)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2,3,4);parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,CDR Generation Date,CDR Generation Time,Failure Code,Plan Name/ID,Usage Key,Discount Type,Used Volume Units,Used Time Units,Used Credit Units,Granted Volume Units,Granted Time Units,Granted Credit Units,Plan Activated,Plan Name,Session ID,PLMN ID,IMSI,Allowed Amount" "iAX-PCC-CDRv7.4.pdf" "SPCM" "DATA USAGE - Usage report (45,0)" "$variableCDR";;
        45,1)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2,3,4);parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,CDR Generation Date,CDR Generation Time,Failure Code,Plan Name/ID,Usage Key,Discount Type,Used Volume Units,Used Time Units,Used Credit Units,Granted Volume Units,Granted Time Units,Granted Credit Units,Plan Activated,Plan Name,Session ID,PLMN ID,IMSI,Allowed Amount" "iAX-PCC-CDRv7.4.pdf" "SPCM" "DATA USAGE - Usage report failure (45,1)" "$variableCDR";;
        45,2)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2,3,4);parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,CDR Generation Date,CDR Generation Time,Failure Code,Plan Name/ID,Usage Key,Discount Type,Used Volume Units,Used Time Units,Used Credit Units,Granted Volume Units,Granted Time Units,Granted Credit Units,Plan Activated,Plan Name,Session ID,PLMN ID,IMSI,Allowed Amount" "iAX-PCC-CDRv7.4.pdf" "SPCM" "DATA USAGE - Usage on plan expiry (45,2)" "$variableCDR";;
        90,1)parseCDR "CDR Subscriber ID,CDR Service ID,CDR Transaction Type,Tenant ID,Subscriber IP,CDR Creation Date,CDR Creation Time,Service Code,Transaction UUID,IMSI,Service Response Code,Error Code,Request String" "iAX-NAC-SDv1.2.pdf" "Captive Portal - NAC" "HRG FreeFormSibb Interface";;
        90,2)parseCDR "CDR Subscriber ID,CDR Service ID,CDR Transaction Type,Tenant ID,Subscriber IP,CDR Creation Date,CDR Creation Time,Service Code,Transaction UUID,IMSI,Service Response Code,Error Code,Request String" "iAX-NAC-SDv1.2.pdf" "Captive Portal - NAC" "Orchestrator SessionService Service Interpreter (SI)";;
        105,1)parseCDR "MSISDN,CDR Service ID,CDR Transaction Type,Tenant ID,Subscriber IP,CDR Creation Date,CDR Creation Time,Service Code,Transaction UUID,IMSI,Service Response Code,Error Code,HRG Operation,Token,Request Attributes" "http://confluence:8090/display/TD/Business+Connect+Portal+Monitoring" "Business Connect Portal - NAC" "HRG FreeFormSibb Interface";;
        105,2)parseCDR "MSISDN,CDR Service ID,CDR Transaction Type,Tenant ID,Subscriber IP,CDR Creation Date,CDR Creation Time,Service Code,Transaction UUID,IMSI,Service Response Code,Error Code,HRG Operation,Token,Request Attributes" "http://confluence:8090/display/TD/Business+Connect+Portal+Monitoring" "Business Connect Portal - NAC" "SessionService";;
        7,81)parseCDR "Subscriber ID,Service ID,Tenant ID,Transaction Type,GTP Message ID,GTP Version,GSN Cause Code,CCN Return Code,Control Proxy Closure Cause Code,IMSI,IMEI,APN,qosId,qosSetId,Requested QoS (raw),Modified QoS (raw),Negotiated QoS (raw),Requested Bearer QoS,Modified Bearer QoS,Negotiated Bearer QoS,Requested AMBR,Modified AMBR,Negotiated AMBR,PDP IP Address (Subscriber IP),Roaming Indicator,Date,Time,TEIDc,CDR Sequence Number,GTP Charging ID,NSAPI,Subscriber Type,Serving MCC,Serving MNC,SGSN/SGW IP Address,GGSN/PGW IP Address,RAI MCC,RAI MNC,RAI Not Present,Creation Date,Creation Time,Duration in Seconds" "iAX-Data-SDv4.0.pdf" "GTP" "Create (7,81)";;
        7,82)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,GTP Message ID,GTP Version,GSN Cause Code,CCN Return Code,Control Proxy Closure Cause Code,IMSI,IMEI,APN,qosId,qosSetId,Requested QoS (raw),Modified QoS (raw),Negotiated QoS (raw),Requested Bearer QoS,Modified Bearer QoS,Negotiated Bearer QoS,Requested AMBR,Modified AMBR,Negotiated AMBR,PDP IP Address (Subscriber IP),Roaming Indicator,Date,Time,TEIDc,CDR Sequence Number,GTP Charging ID,NSAPI,Subscriber Type,Serving MCC,Serving MNC,SGSN/SGW IP Address,GGSN/PGW IP Address,RAI MCC,RAI MNC,RAI Not Present,Creation Date,Creation Time,Duration in Seconds" "iAX-Data-SDv4.0.pdf" "GTP" "Update (7,82)";;
        7,83)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,GTP Message ID,GTP Version,GSN Cause Code,CCN Return Code,Control Proxy Closure Cause Code,IMSI,IMEI,APN,qosId,qosSetId,Requested QoS (raw),Modified QoS (raw),Negotiated QoS (raw),Requested Bearer QoS,Modified Bearer QoS,Negotiated Bearer QoS,Requested AMBR,Modified AMBR,Negotiated AMBR,PDP IP Address (Subscriber IP),Roaming Indicator,Date,Time,TEIDc,CDR Sequence Number,GTP Charging ID,NSAPI,Subscriber Type,Serving MCC,Serving MNC,SGSN/SGW IP Address,GGSN/PGW IP Address,RAI MCC,RAI MNC,RAI Not Present,Creation Date,Creation Time,Duration in Seconds" "iAX-Data-SDv4.0.pdf" "GTP" "Delete (7,83)";;
        7,1)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2,3,4,5,6);parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,GGSN/PGW Cause Code,CCN Return Code,IMSI,APN,Requested QoS,Negotiated QoS,PDP IP Address (Subscriber IP),RAT Type,Serving MCC,Serving MNC,User Location Information,Roaming Indicator,Redirection,Date,Time,CDR Sequence Number,CDR Segment,Tango Session ID,GTP Charging ID,NSAPI,SGSN/SGW Zone Map ID,Destination Address Map ID,IP Analysis Table ID,IP Rating Table ID,Subscription Type,SGSN/SGW IP Address,GGSN/PGW IP Address,Creation Date(Data Tunnel),Creation Time(Data Tunnel),Rating Type,Tax,Default Rate,Rate Percentage,Current Rating Parameter,Duration in Seconds,Upstream Packet Count,Upstream Byte Count,Downstream Packet Count,Downstream Byte Count,Charging Units Consumed - Prepaid,Charging Units Consumed - Bundle,Charging Units Consumed - Postpaid,Charging Units Consumed - Bypass,Charging Units Consumed - Emergency session" "iAX-Data-SDv4.0.pdf" "GTP" "Create a PDP context (7,1)" "$variableCDR";;
        7,2)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2,3,4,5,6);parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,GGSN/PGW Cause Code,CCN Return Code,IMSI,APN,Requested QoS,Negotiated QoS,PDP IP Address (Subscriber IP),RAT Type,Serving MCC,Serving MNC,User Location Information,Roaming Indicator,Redirection,Date,Time,CDR Sequence Number,CDR Segment,Tango Session ID,GTP Charging ID,NSAPI,SGSN/SGW Zone Map ID,Destination Address Map ID,IP Analysis Table ID,IP Rating Table ID,Subscription Type,SGSN/SGW IP Address,GGSN/PGW IP Address,Creation Date(Data Tunnel),Creation Time(Data Tunnel),Rating Type,Tax,Default Rate,Rate Percentage,Current Rating Parameter,Duration in Seconds,Upstream Packet Count,Upstream Byte Count,Downstream Packet Count,Downstream Byte Count,Charging Units Consumed - Prepaid,Charging Units Consumed - Bundle,Charging Units Consumed - Postpaid,Charging Units Consumed - Bypass,Charging Units Consumed - Emergency session" "iAX-Data-SDv4.0.pdf" "GTP" "Update a PDP context (7,2)" "$variableCDR";;
        7,3)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2,3,4,5,6);parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,GGSN/PGW Cause Code,CCN Return Code,IMSI,APN,Requested QoS,Negotiated QoS,PDP IP Address (Subscriber IP),RAT Type,Serving MCC,Serving MNC,User Location Information,Roaming Indicator,Redirection,Date,Time,CDR Sequence Number,CDR Segment,Tango Session ID,GTP Charging ID,NSAPI,SGSN/SGW Zone Map ID,Destination Address Map ID,IP Analysis Table ID,IP Rating Table ID,Subscription Type,SGSN/SGW IP Address,GGSN/PGW IP Address,Creation Date(Data Tunnel),Creation Time(Data Tunnel),Rating Type,Tax,Default Rate,Rate Percentage,Current Rating Parameter,Duration in Seconds,Upstream Packet Count,Upstream Byte Count,Downstream Packet Count,Downstream Byte Count,Charging Units Consumed - Prepaid,Charging Units Consumed - Bundle,Charging Units Consumed - Postpaid,Charging Units Consumed - Bypass,Charging Units Consumed - Emergency session" "iAX-Data-SDv4.0.pdf" "GTP" "Delete a PDP context (7,3)" "$variableCDR";;
        7,6)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2,3,4,5,6);parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,GGSN/PGW Cause Code,CCN Return Code,IMSI,APN,Requested QoS,Negotiated QoS,PDP IP Address (Subscriber IP),RAT Type,Serving MCC,Serving MNC,User Location Information,Roaming Indicator,Redirection,Date,Time,CDR Sequence Number,CDR Segment,Tango Session ID,GTP Charging ID,NSAPI,SGSN/SGW Zone Map ID,Destination Address Map ID,IP Analysis Table ID,IP Rating Table ID,Subscription Type,SGSN/SGW IP Address,GGSN/PGW IP Address,Creation Date(Data Tunnel),Creation Time(Data Tunnel),Rating Type,Tax,Default Rate,Rate Percentage,Current Rating Parameter,Duration in Seconds,Upstream Packet Count,Upstream Byte Count,Downstream Packet Count,Downstream Byte Count,Charging Units Consumed - Prepaid,Charging Units Consumed - Bundle,Charging Units Consumed - Postpaid,Charging Units Consumed - Bypass,Charging Units Consumed - Emergency session" "iAX-Data-SDv4.0.pdf" "GTP" "Interim GTP CDR - Time Trigger (7,6)" "$variableCDR";;
        7,8)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2,3,4,5,6);parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,GGSN/PGW Cause Code,CCN Return Code,IMSI,APN,Requested QoS,Negotiated QoS,PDP IP Address (Subscriber IP),RAT Type,Serving MCC,Serving MNC,User Location Information,Roaming Indicator,Redirection,Date,Time,CDR Sequence Number,CDR Segment,Tango Session ID,GTP Charging ID,NSAPI,SGSN/SGW Zone Map ID,Destination Address Map ID,IP Analysis Table ID,IP Rating Table ID,Subscription Type,SGSN/SGW IP Address,GGSN/PGW IP Address,Creation Date(Data Tunnel),Creation Time(Data Tunnel),Rating Type,Tax,Default Rate,Rate Percentage,Current Rating Parameter,Duration in Seconds,Upstream Packet Count,Upstream Byte Count,Downstream Packet Count,Downstream Byte Count,Charging Units Consumed - Prepaid,Charging Units Consumed - Bundle,Charging Units Consumed - Postpaid,Charging Units Consumed - Bypass,Charging Units Consumed - Emergency session" "iAX-Data-SDv4.0.pdf" "GTP" "Interim GTP CDR - Delta CDR (7,8)" "$variableCDR";;
        7,90)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2,3,4,5,6);parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,GGSN/PGW Cause Code,CCN Return Code,IMSI,APN,Requested QoS,Negotiated QoS,PDP IP Address (Subscriber IP),RAT Type,Serving MCC,Serving MNC,User Location Information,Roaming Indicator,Redirection,Date,Time,CDR Sequence Number,CDR Segment,Tango Session ID,GTP Charging ID,NSAPI,SGSN/SGW Zone Map ID,Destination Address Map ID,IP Analysis Table ID,IP Rating Table ID,Subscription Type,SGSN/SGW IP Address,GGSN/PGW IP Address,Creation Date(Data Tunnel),Creation Time(Data Tunnel),Rating Type,Tax,Default Rate,Rate Percentage,Current Rating Parameter,Duration in Seconds,Upstream Packet Count,Upstream Byte Count,Downstream Packet Count,Downstream Byte Count,Charging Units Consumed - Prepaid,Charging Units Consumed - Bundle,Charging Units Consumed - Postpaid,Charging Units Consumed - Bypass,Charging Units Consumed - Emergency session" "iAX-Data-SDv4.0.pdf" "GTP" "Bundle recharge (topup) (7,90)" "$variableCDR";;
        7,91)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2,3,4,5,6);parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,GGSN/PGW Cause Code,CCN Return Code,IMSI,APN,Requested QoS,Negotiated QoS,PDP IP Address (Subscriber IP),RAT Type,Serving MCC,Serving MNC,User Location Information,Roaming Indicator,Redirection,Date,Time,CDR Sequence Number,CDR Segment,Tango Session ID,GTP Charging ID,NSAPI,SGSN/SGW Zone Map ID,Destination Address Map ID,IP Analysis Table ID,IP Rating Table ID,Subscription Type,SGSN/SGW IP Address,GGSN/PGW IP Address,Creation Date(Data Tunnel),Creation Time(Data Tunnel),Rating Type,Tax,Default Rate,Rate Percentage,Current Rating Parameter,Duration in Seconds,Upstream Packet Count,Upstream Byte Count,Downstream Packet Count,Downstream Byte Count,Charging Units Consumed - Prepaid,Charging Units Consumed - Bundle,Charging Units Consumed - Postpaid,Charging Units Consumed - Bypass,Charging Units Consumed - Emergency session" "iAX-Data-SDv4.0.pdf" "GTP" "Bundle expired (7,91)" "$variableCDR";;
        7,92)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2,3,4,5,6);parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant ID,GGSN/PGW Cause Code,CCN Return Code,IMSI,APN,Requested QoS,Negotiated QoS,PDP IP Address (Subscriber IP),RAT Type,Serving MCC,Serving MNC,User Location Information,Roaming Indicator,Redirection,Date,Time,CDR Sequence Number,CDR Segment,Tango Session ID,GTP Charging ID,NSAPI,SGSN/SGW Zone Map ID,Destination Address Map ID,IP Analysis Table ID,IP Rating Table ID,Subscription Type,SGSN/SGW IP Address,GGSN/PGW IP Address,Creation Date(Data Tunnel),Creation Time(Data Tunnel),Rating Type,Tax,Default Rate,Rate Percentage,Current Rating Parameter,Duration in Seconds,Upstream Packet Count,Upstream Byte Count,Downstream Packet Count,Downstream Byte Count,Charging Units Consumed - Prepaid,Charging Units Consumed - Bundle,Charging Units Consumed - Postpaid,Charging Units Consumed - Bypass,Charging Units Consumed - Emergency session" "iAX-Data-SDv4.0.pdf" "GTP" "Subscriber information update (7,92)" "$variableCDR";;
        66,0)parseCDR "CDR Subscriber ID,CDR Service ID,CDR Transaction Type,Tenant ID,MSISDN,Location Update Reference ID,CDR Generation Date,CDR Generation Time,Container Name,Result Code,Result Description,IMSI,ServiceKey,VPLMN,Network Name,Country Name,Zone Name,List Names,Offer Lookup Status,Offer Name,Number of Offer Actions,Number of Delayed Offer Action,Campaign Name,Offer Name" "http://iel-doc-web-vm1/rte-docs/7.2.0/index.html" "Welcome SMS" "WSMS Location CDR (66,0)";;
        66,1)parseCDR "CDR Subscriber ID,CDR Service ID,CDR Transaction Type,Tenant ID,MSISDN,Location Update Reference ID,CDR Generation Date,CDR Generation Time,Container Name,Result Code,Result Description,IMSI,ServiceKey,VPLMN,Network Name,Country Name,Zone Name,List Names,Offer Lookup Status,Offer Name,Number of Offer Actions,Number of Delayed Offer Action,Campaign Name,Offer Name" "http://iel-doc-web-vm1/rte-docs/7.2.0/index.html" "Welcome SMS" "WSMS Location CDR (66,1)";;
        67,0)parseCDR "CDR Subscriber ID,CDR Service ID,CDR Transaction Type,Tenant ID,MSISDN,Location Update Reference ID,CDR Generation Date,CDR Generation Time,Container Name,Result Code,Result Description,IMSI,ServiceKey,VPLMN,Network Name,Country Name,Zone Name,Offer Action Delay,Offer Action Position,Notification Status Code" "https://iel-doc-web-vm1/rte-docs/7.2.0/index.html" "Welcome SMS" "WSMS Notification CDR - Immediate Notification (67,0)";;
        67,1)parseCDR "CDR Subscriber ID,CDR Service ID,CDR Transaction Type,Tenant ID,MSISDN,Location Update Reference ID,CDR Generation Date,CDR Generation Time,Container Name,Result Code,Result Description,IMSI,ServiceKey,VPLMN,Network Name,Country Name,Zone Name,Offer Action Delay,Offer Action Position,Notification Status Code" "http://iel-doc-web-vm1/rte-docs/7.2.0/index.html" "Welcome SMS" "WSMS Notification CDR - Delayed Message (67,1)";;
        102,1)parseCDR "msisdn,serviceId,transactionType,datestamp,timestamp,token,transactionStatus" "Confluence" "TOKEN-WS" "Successful";;
        106,0)parseCDR "Subscriber ID (msisdn),Service code,Transaction Type,Tenant ID,Call Reference,CDR Generation Date,CDR Generation Time,Error Code,Error Description,Offer ID,Subscriber Info,Zone,Country,Network,List Info" "RTE-CDR-Reference-v7.2.x.pdf" "Business Connect SIBB" "Offer Lookup (106,0)";;
        106,1)parseCDR "Subscriber ID (msisdn),Service code,Transaction Type,Tenant ID,Call Reference,CDR Generation Date,CDR Generation Time,Error Code,Error Description,Offer ID,Action,Client ID,Channel,Metadata,Reserved" "RTE-CDR-Reference-v7.2.x.pdf" "Business Connect SIBB" "Offer Update (106,1)";;
        106,2)parseCDR "Subscriber ID (msisdn),Service code,Transaction Type,Tenant ID,Call Reference,CDR Generation Date,CDR Generation Time,HTTP Error Code,Description" "RTE-CDR-Reference-v7.2.x.pdf" "Business Connect SIBB" "SIBB Notification (106,2)";;
        71,2)parseCDR "Subscriber ID (msisdn),Service ID,Transaction Type,Tenant ID,Call Reference,Date,Time,errorCode,errorDescription,UNS Short Code" "http://confluence.localnet:8090/display/DEV/Interactive+SMS+SIBB#InteractiveSMSSIBB-CDR" "Interactive SMS" "notification sent (71,2)";;
        71,1)parseCDR "Subscriber ID (msisdn),Service ID,Transaction Type,Tenant ID,Destination Number,Call Reference,Date,Time,errorCode,errorDescription,SMS text,UNS Short Code,Campaign Id,Offer Name,Key Words" "RTE-CDR-Reference-v7.2.x.pdf" "Business Connect SIBB" "SIBB Notification (106,2)";;

# SCP - SCF
        19,1)parseCDR "Subscriber ID,Service ID,Transaction Type,Cause Code,Charging Error Code,CDR Generation Date,CDR Generation Time,MSC Address,Location Number,Service Key,Call Reference Number,Call Type,Calling Party Number,Called Party Number,Redirecting Party Number,Original Called Party Number,Service Number,Subscriber IMSI,Service Zone,Basic Service Code,Location Info,VLR Number,Time Zone Info,Connect-To Number,Account Type,Language ID,Prompt ID,Low Balance Tone Indicator,Call Answer Indicator,Service Logic Start Date,Service Logic Start Time,Call Answer Date,Call Answer Time,Call Release Date,Call Release Time,Normal Usage,Bypass Usage,Uncharged Usage,Non-CAP IVR Call CorrelationID" "SCF-SDV4.0.pdf" "SCF Service" "Voice Start CDR (19,1)";;
        19,2)parseCDR "Subscriber ID,Service ID,Transaction Type,Cause Code,Charging Error Code,CDR Generation Date,CDR Generation Time,MSC Address,Location Number,Service Key,Call Reference Number,Call Type,Calling Party Number,Called Party Number,Redirecting Party Number,Original Called Party Number,Service Number,Subscriber IMSI,Service Zone,Basic Service Code,Location Info,VLR Number,Time Zone Info,Connect-To Number,Account Type,Language ID,Prompt ID,Low Balance Tone Indicator,Call Answer Indicator,Service Logic Start Date,Service Logic Start Time,Call Answer Date,Call Answer Time,Call Release Date,Call Release Time,Normal Usage,Bypass Usage,Uncharged Usage,Non-CAP IVR Call CorrelationID" "SCF-SDV4.0.pdf" "SCF Service" "Voice Stop CDR (19,2)";;

# DIAM CLIENT - AMM/SV
        19,14)parseCDR "Subscriber ID,Service ID,Transaction Type,Result Code,IMSI,Session Create Date,Session Create Time,CDR Creation Date,CDR Creation Time,CDR Sequence Number,CDR Segment,Session ID,Origin Host,Destination Host,Termination Cause,Limited Credit Left,Unit Type Identifier,Requested Service Unit,Granted Service Unit,Used Service Unit,Service Context ID,Calling Party Number,Called Party Number,MSC Address,Traffic Case,Extra Field #1,Extra Field #2,Extra Field #3,Extra Field #4,Extra Field #5,Extra Field #6,Extra Field #7,Extra Field #8" "iAX-SMS=CDRv9.0.pdf" "3GPP DIAM CLIENT" "Initiate (19,14)";;
        19,15)parseCDR "Subscriber ID,Service ID,Transaction Type,Result Code,IMSI,Session Create Date,Session Create Time,CDR Creation Date,CDR Creation Time,CDR Sequence Number,CDR Segment,Session ID,Origin Host,Destination Host,Termination Cause,Limited Credit Left,Unit Type Identifier,Requested Service Unit,Granted Service Unit,Used Service Unit,Service Context ID,Calling Party Number,Called Party Number,MSC Address,Traffic Case,Extra Field #1,Extra Field #2,Extra Field #3,Extra Field #4,Extra Field #5,Extra Field #6,Extra Field #7,Extra Field #8" "iAX-SMS=CDRv9.0.pdf" "3GPP DIAM CLIENT" "Update (19,15)";;
        19,16)parseCDR "Subscriber ID,Service ID,Transaction Type,Result Code,IMSI,Session Create Date,Session Create Time,CDR Creation Date,CDR Creation Time,CDR Sequence Number,CDR Segment,Session ID,Origin Host,Destination Host,Termination Cause,Limited Credit Left,Unit Type Identifier,Requested Service Unit,Granted Service Unit,Used Service Unit,Service Context ID,Calling Party Number,Called Party Number,MSC Address,Traffic Case,Extra Field #1,Extra Field #2,Extra Field #3,Extra Field #4,Extra Field #5,Extra Field #6,Extra Field #7,Extra Field #8" "iAX-SMS=CDRv9.0.pdf" "3GPP DIAM CLIENT" "Terminate (19,16)";;
        19,17)parseCDR "Subscriber ID,Service ID,Transaction Type,Result Code,IMSI,Session Create Date,Session Create Time,CDR Creation Date,CDR Creation Time,CDR Sequence Number,CDR Segment,Session ID,Origin Host,Destination Host,Termination Cause,Limited Credit Left,Unit Type Identifier,Requested Service Unit,Granted Service Unit,Used Service Unit,Service Context ID,Calling Party Number,Called Party Number,MSC Address,Traffic Case,Extra Field #1,Extra Field #2,Extra Field #3,Extra Field #4,Extra Field #5,Extra Field #6,Extra Field #7,Extra Field #8" "iAX-SMS=CDRv9.0.pdf" "3GPP DIAM CLIENT" "Direct Debit (19,17)";;
        19,18)parseCDR "Subscriber ID,Service ID,Transaction Type,Result Code,IMSI,Session Create Date,Session Create Time,CDR Creation Date,CDR Creation Time,CDR Sequence Number,CDR Segment,Session ID,Origin Host,Destination Host,Termination Cause,Limited Credit Left,Unit Type Identifier,Requested Service Unit,Granted Service Unit,Used Service Unit,Service Context ID,Calling Party Number,Called Party Number,MSC Address,Traffic Case,Extra Field #1,Extra Field #2,Extra Field #3,Extra Field #4,Extra Field #5,Extra Field #6,Extra Field #7,Extra Field #8" "iAX-SMS=CDRv9.0.pdf" "3GPP DIAM CLIENT" "Refund Account (19,18)";;
        108,101)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "Subscriber_ID,Service_ID,Transaction_Type,Tenant ID,CDR_Generation_Date,CDR_Generation_Time,Instance_ID,CDR_Segment_Number,CDR_Sequence_Number,PCRF_Session_ID,PCRF_Session_Start_Time,PCRF_Session_Duration,PCRF_Response_Code,PCRF_Event_Trigger,IMSI,UE_IP_Address,UE_IPv6_Prefix,UE_Info,PDN_ID,ANGW_Ipv6_Address,ANGW_Ipv4_Address,SGSN_Ipv4_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,PLMN_ID,RAI,IP_CAN_Type,RAT_Type,User_Location_Info,Ms_Time_Zone,NW_Charging_ID,SPR_Session_ID,SPR_Session_Start_Time,SPR_Session_Duration,SPR_Response_Delay,SPR_Response_Code,SPR_Customer-Status,SPR_Classification,SPR_Tenant-Name,SPR_Service-Status,SPR_Instance-Name,OCS_Session_ID,OCS_Session_Start_Time,OCS_Session_Duration,OCS_Response_Delay,OCS_Response_Code" "PCC-CDR-Reference-Guide-v7.x" "SPR Adaptor" "Session Init Request from the PCRF (108,101)" "$variableCDR";;
        108,102)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "Subscriber_ID,Service_ID,Transaction_Type,Tenant ID,CDR_Generation_Date,CDR_Generation_Time,Instance_ID,CDR_Segment_Number,CDR_Sequence_Number,PCRF_Session_ID,PCRF_Session_Start_Time,PCRF_Session_Duration,PCRF_Response_Code,PCRF_Event_Trigger,IMSI,UE_IP_Address,UE_IPv6_Prefix,UE_Info,PDN_ID,ANGW_Ipv6_Address,ANGW_Ipv4_Address,SGSN_Ipv4_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,PLMN_ID,RAI,IP_CAN_Type,RAT_Type,User_Location_Info,Ms_Time_Zone,NW_Charging_ID,SPR_Session_ID,SPR_Session_Start_Time,SPR_Session_Duration,SPR_Response_Delay,SPR_Response_Code,SPR_Customer-Status,SPR_Classification,SPR_Tenant-Name,SPR_Service-Status,SPR_Instance-Name,OCS_Session_ID,OCS_Session_Start_Time,OCS_Session_Duration,OCS_Response_Delay,OCS_Response_Code" "PCC-CDR-Reference-Guide-v7.x" "SPR Adaptor" "Session Init Response to the PCRF (108,102)" "$variableCDR";;
        108,103)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "Subscriber_ID,Service_ID,Transaction_Type,Tenant ID,CDR_Generation_Date,CDR_Generation_Time,Instance_ID,CDR_Segment_Number,CDR_Sequence_Number,PCRF_Session_ID,PCRF_Session_Start_Time,PCRF_Session_Duration,PCRF_Response_Code,PCRF_Event_Trigger,IMSI,UE_IP_Address,UE_IPv6_Prefix,UE_Info,PDN_ID,ANGW_Ipv6_Address,ANGW_Ipv4_Address,SGSN_Ipv4_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,PLMN_ID,RAI,IP_CAN_Type,RAT_Type,User_Location_Info,Ms_Time_Zone,NW_Charging_ID,SPR_Session_ID,SPR_Session_Start_Time,SPR_Session_Duration,SPR_Response_Delay,SPR_Response_Code,SPR_Customer-Status,SPR_Classification,SPR_Tenant-Name,SPR_Service-Status,SPR_Instance-Name,OCS_Session_ID,OCS_Session_Start_Time,OCS_Session_Duration,OCS_Response_Delay,OCS_Response_Code" "PCC-CDR-Reference-Guide-v7.x" "SPR Adaptor" "Session Update Request from the PCRF (108,103)" "$variableCDR";;
        108,104)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "Subscriber_ID,Service_ID,Transaction_Type,Tenant ID,CDR_Generation_Date,CDR_Generation_Time,Instance_ID,CDR_Segment_Number,CDR_Sequence_Number,PCRF_Session_ID,PCRF_Session_Start_Time,PCRF_Session_Duration,PCRF_Response_Code,PCRF_Event_Trigger,IMSI,UE_IP_Address,UE_IPv6_Prefix,UE_Info,PDN_ID,ANGW_Ipv6_Address,ANGW_Ipv4_Address,SGSN_Ipv4_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,PLMN_ID,RAI,IP_CAN_Type,RAT_Type,User_Location_Info,Ms_Time_Zone,NW_Charging_ID,SPR_Session_ID,SPR_Session_Start_Time,SPR_Session_Duration,SPR_Response_Delay,SPR_Response_Code,SPR_Customer-Status,SPR_Classification,SPR_Tenant-Name,SPR_Service-Status,SPR_Instance-Name,OCS_Session_ID,OCS_Session_Start_Time,OCS_Session_Duration,OCS_Response_Delay,OCS_Response_Code" "PCC-CDR-Reference-Guide-v7.x" "SPR Adaptor" "Session Update Response to the PCRF (108,104)" "$variableCDR";;
        108,105)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "Subscriber_ID,Service_ID,Transaction_Type,Tenant ID,CDR_Generation_Date,CDR_Generation_Time,Instance_ID,CDR_Segment_Number,CDR_Sequence_Number,PCRF_Session_ID,PCRF_Session_Start_Time,PCRF_Session_Duration,PCRF_Response_Code,PCRF_Event_Trigger,IMSI,UE_IP_Address,UE_IPv6_Prefix,UE_Info,PDN_ID,ANGW_Ipv6_Address,ANGW_Ipv4_Address,SGSN_Ipv4_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,PLMN_ID,RAI,IP_CAN_Type,RAT_Type,User_Location_Info,Ms_Time_Zone,NW_Charging_ID,SPR_Session_ID,SPR_Session_Start_Time,SPR_Session_Duration,SPR_Response_Delay,SPR_Response_Code,SPR_Customer-Status,SPR_Classification,SPR_Tenant-Name,SPR_Service-Status,SPR_Instance-Name,OCS_Session_ID,OCS_Session_Start_Time,OCS_Session_Duration,OCS_Response_Delay,OCS_Response_Code" "PCC-CDR-Reference-Guide-v7.x" "SPR Adaptor" "Session Term Request from the PCRF (108,105)" "$variableCDR";;
        108,106)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "Subscriber_ID,Service_ID,Transaction_Type,Tenant ID,CDR_Generation_Date,CDR_Generation_Time,Instance_ID,CDR_Segment_Number,CDR_Sequence_Number,PCRF_Session_ID,PCRF_Session_Start_Time,PCRF_Session_Duration,PCRF_Response_Code,PCRF_Event_Trigger,IMSI,UE_IP_Address,UE_IPv6_Prefix,UE_Info,PDN_ID,ANGW_Ipv6_Address,ANGW_Ipv4_Address,SGSN_Ipv4_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,PLMN_ID,RAI,IP_CAN_Type,RAT_Type,User_Location_Info,Ms_Time_Zone,NW_Charging_ID,SPR_Session_ID,SPR_Session_Start_Time,SPR_Session_Duration,SPR_Response_Delay,SPR_Response_Code,SPR_Customer-Status,SPR_Classification,SPR_Tenant-Name,SPR_Service-Status,SPR_Instance-Name,OCS_Session_ID,OCS_Session_Start_Time,OCS_Session_Duration,OCS_Response_Delay,OCS_Response_Code" "PCC-CDR-Reference-Guide-v7.x" "SPR Adaptor" "Session Term Response to the PCRF (108,106)" "$variableCDR";;
        108,107)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "Subscriber_ID,Service_ID,Transaction_Type,Tenant ID,CDR_Generation_Date,CDR_Generation_Time,Instance_ID,CDR_Segment_Number,CDR_Sequence_Number,PCRF_Session_ID,PCRF_Session_Start_Time,PCRF_Session_Duration,PCRF_Response_Code,PCRF_Event_Trigger,IMSI,UE_IP_Address,UE_IPv6_Prefix,UE_Info,PDN_ID,ANGW_Ipv6_Address,ANGW_Ipv4_Address,SGSN_Ipv4_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,PLMN_ID,RAI,IP_CAN_Type,RAT_Type,User_Location_Info,Ms_Time_Zone,NW_Charging_ID,SPR_Session_ID,SPR_Session_Start_Time,SPR_Session_Duration,SPR_Response_Delay,SPR_Response_Code,SPR_Customer-Status,SPR_Classification,SPR_Tenant-Name,SPR_Service-Status,SPR_Instance-Name,OCS_Session_ID,OCS_Session_Start_Time,OCS_Session_Duration,OCS_Response_Delay,OCS_Response_Code" "PCC-CDR-Reference-Guide-v7.x" "SPR Adaptor" "Update Notification to the PCRF (108,107)" "$variableCDR";;
        108,201)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "Subscriber_ID,Service_ID,Transaction_Type,Tenant ID,CDR_Generation_Date,CDR_Generation_Time,Instance_ID,CDR_Segment_Number,CDR_Sequence_Number,PCRF_Session_ID,PCRF_Session_Start_Time,PCRF_Session_Duration,PCRF_Response_Code,PCRF_Event_Trigger,IMSI,UE_IP_Address,UE_IPv6_Prefix,UE_Info,PDN_ID,ANGW_Ipv6_Address,ANGW_Ipv4_Address,SGSN_Ipv4_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,PLMN_ID,RAI,IP_CAN_Type,RAT_Type,User_Location_Info,Ms_Time_Zone,NW_Charging_ID,SPR_Session_ID,SPR_Session_Start_Time,SPR_Session_Duration,SPR_Response_Delay,SPR_Response_Code,SPR_Customer-Status,SPR_Classification,SPR_Tenant-Name,SPR_Service-Status,SPR_Instance-Name,OCS_Session_ID,OCS_Session_Start_Time,OCS_Session_Duration,OCS_Response_Delay,OCS_Response_Code" "PCC-CDR-Reference-Guide-v7.x" "SPR Adaptor" "Session Init Request to the SPR (i.e. Sp SNR-Subscribe) (108,201)" "$variableCDR";;
        108,202)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "Subscriber_ID,Service_ID,Transaction_Type,Tenant ID,CDR_Generation_Date,CDR_Generation_Time,Instance_ID,CDR_Segment_Number,CDR_Sequence_Number,PCRF_Session_ID,PCRF_Session_Start_Time,PCRF_Session_Duration,PCRF_Response_Code,PCRF_Event_Trigger,IMSI,UE_IP_Address,UE_IPv6_Prefix,UE_Info,PDN_ID,ANGW_Ipv6_Address,ANGW_Ipv4_Address,SGSN_Ipv4_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,PLMN_ID,RAI,IP_CAN_Type,RAT_Type,User_Location_Info,Ms_Time_Zone,NW_Charging_ID,SPR_Session_ID,SPR_Session_Start_Time,SPR_Session_Duration,SPR_Response_Delay,SPR_Response_Code,SPR_Customer-Status,SPR_Classification,SPR_Tenant-Name,SPR_Service-Status,SPR_Instance-Name,OCS_Session_ID,OCS_Session_Start_Time,OCS_Session_Duration,OCS_Response_Delay,OCS_Response_Code" "PCC-CDR-Reference-Guide-v7.x" "SPR Adaptor" "Session Init Response from the SPR (i.e. Sp SNA-Subscribe) (108,202)" "$variableCDR";;
        108,203)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "Subscriber_ID,Service_ID,Transaction_Type,Tenant ID,CDR_Generation_Date,CDR_Generation_Time,Instance_ID,CDR_Segment_Number,CDR_Sequence_Number,PCRF_Session_ID,PCRF_Session_Start_Time,PCRF_Session_Duration,PCRF_Response_Code,PCRF_Event_Trigger,IMSI,UE_IP_Address,UE_IPv6_Prefix,UE_Info,PDN_ID,ANGW_Ipv6_Address,ANGW_Ipv4_Address,SGSN_Ipv4_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,PLMN_ID,RAI,IP_CAN_Type,RAT_Type,User_Location_Info,Ms_Time_Zone,NW_Charging_ID,SPR_Session_ID,SPR_Session_Start_Time,SPR_Session_Duration,SPR_Response_Delay,SPR_Response_Code,SPR_Customer-Status,SPR_Classification,SPR_Tenant-Name,SPR_Service-Status,SPR_Instance-Name,OCS_Session_ID,OCS_Session_Start_Time,OCS_Session_Duration,OCS_Response_Delay,OCS_Response_Code" "PCC-CDR-Reference-Guide-v7.x" "SPR Adaptor" "Session Update Request to the SPR (i.e. Sp SNR) (108,203)" "$variableCDR";;
        108,204)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "Subscriber_ID,Service_ID,Transaction_Type,Tenant ID,CDR_Generation_Date,CDR_Generation_Time,Instance_ID,CDR_Segment_Number,CDR_Sequence_Number,PCRF_Session_ID,PCRF_Session_Start_Time,PCRF_Session_Duration,PCRF_Response_Code,PCRF_Event_Trigger,IMSI,UE_IP_Address,UE_IPv6_Prefix,UE_Info,PDN_ID,ANGW_Ipv6_Address,ANGW_Ipv4_Address,SGSN_Ipv4_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,PLMN_ID,RAI,IP_CAN_Type,RAT_Type,User_Location_Info,Ms_Time_Zone,NW_Charging_ID,SPR_Session_ID,SPR_Session_Start_Time,SPR_Session_Duration,SPR_Response_Delay,SPR_Response_Code,SPR_Customer-Status,SPR_Classification,SPR_Tenant-Name,SPR_Service-Status,SPR_Instance-Name,OCS_Session_ID,OCS_Session_Start_Time,OCS_Session_Duration,OCS_Response_Delay,OCS_Response_Code" "PCC-CDR-Reference-Guide-v7.x" "SPR Adaptor" "Session Update Response from the SPR (i.e. Sp SNA) (108,204)" "$variableCDR";;
        108,205)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "Subscriber_ID,Service_ID,Transaction_Type,Tenant ID,CDR_Generation_Date,CDR_Generation_Time,Instance_ID,CDR_Segment_Number,CDR_Sequence_Number,PCRF_Session_ID,PCRF_Session_Start_Time,PCRF_Session_Duration,PCRF_Response_Code,PCRF_Event_Trigger,IMSI,UE_IP_Address,UE_IPv6_Prefix,UE_Info,PDN_ID,ANGW_Ipv6_Address,ANGW_Ipv4_Address,SGSN_Ipv4_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,PLMN_ID,RAI,IP_CAN_Type,RAT_Type,User_Location_Info,Ms_Time_Zone,NW_Charging_ID,SPR_Session_ID,SPR_Session_Start_Time,SPR_Session_Duration,SPR_Response_Delay,SPR_Response_Code,SPR_Customer-Status,SPR_Classification,SPR_Tenant-Name,SPR_Service-Status,SPR_Instance-Name,OCS_Session_ID,OCS_Session_Start_Time,OCS_Session_Duration,OCS_Response_Delay,OCS_Response_Code" "PCC-CDR-Reference-Guide-v7.x" "SPR Adaptor" "Session Term Request to the SPR (i.e. Sp SNR-Cancel)(108,205)" "$variableCDR";;
        108,206)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "Subscriber_ID,Service_ID,Transaction_Type,Tenant ID,CDR_Generation_Date,CDR_Generation_Time,Instance_ID,CDR_Segment_Number,CDR_Sequence_Number,PCRF_Session_ID,PCRF_Session_Start_Time,PCRF_Session_Duration,PCRF_Response_Code,PCRF_Event_Trigger,IMSI,UE_IP_Address,UE_IPv6_Prefix,UE_Info,PDN_ID,ANGW_Ipv6_Address,ANGW_Ipv4_Address,SGSN_Ipv4_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,PLMN_ID,RAI,IP_CAN_Type,RAT_Type,User_Location_Info,Ms_Time_Zone,NW_Charging_ID,SPR_Session_ID,SPR_Session_Start_Time,SPR_Session_Duration,SPR_Response_Delay,SPR_Response_Code,SPR_Customer-Status,SPR_Classification,SPR_Tenant-Name,SPR_Service-Status,SPR_Instance-Name,OCS_Session_ID,OCS_Session_Start_Time,OCS_Session_Duration,OCS_Response_Delay,OCS_Response_Code" "PCC-CDR-Reference-Guide-v7.x" "SPR Adaptor" "Session Term Response from the SPR (i.e. Sp SNA-Cancel)(108,206)" "$variableCDR";;
        108,207)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "Subscriber_ID,Service_ID,Transaction_Type,Tenant ID,CDR_Generation_Date,CDR_Generation_Time,Instance_ID,CDR_Segment_Number,CDR_Sequence_Number,PCRF_Session_ID,PCRF_Session_Start_Time,PCRF_Session_Duration,PCRF_Response_Code,PCRF_Event_Trigger,IMSI,UE_IP_Address,UE_IPv6_Prefix,UE_Info,PDN_ID,ANGW_Ipv6_Address,ANGW_Ipv4_Address,SGSN_Ipv4_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,PLMN_ID,RAI,IP_CAN_Type,RAT_Type,User_Location_Info,Ms_Time_Zone,NW_Charging_ID,SPR_Session_ID,SPR_Session_Start_Time,SPR_Session_Duration,SPR_Response_Delay,SPR_Response_Code,SPR_Customer-Status,SPR_Classification,SPR_Tenant-Name,SPR_Service-Status,SPR_Instance-Name,OCS_Session_ID,OCS_Session_Start_Time,OCS_Session_Duration,OCS_Response_Delay,OCS_Response_Code" "PCC-CDR-Reference-Guide-v7.x" "SPR Adaptor" "Update Notification from the SPR (i.e. Sp PNR)(108,207)" "$variableCDR";;
        108,208)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "Subscriber_ID,Service_ID,Transaction_Type,Tenant ID,CDR_Generation_Date,CDR_Generation_Time,Instance_ID,CDR_Segment_Number,CDR_Sequence_Number,PCRF_Session_ID,PCRF_Session_Start_Time,PCRF_Session_Duration,PCRF_Response_Code,PCRF_Event_Trigger,IMSI,UE_IP_Address,UE_IPv6_Prefix,UE_Info,PDN_ID,ANGW_Ipv6_Address,ANGW_Ipv4_Address,SGSN_Ipv4_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,PLMN_ID,RAI,IP_CAN_Type,RAT_Type,User_Location_Info,Ms_Time_Zone,NW_Charging_ID,SPR_Session_ID,SPR_Session_Start_Time,SPR_Session_Duration,SPR_Response_Delay,SPR_Response_Code,SPR_Customer-Status,SPR_Classification,SPR_Tenant-Name,SPR_Service-Status,SPR_Instance-Name,OCS_Session_ID,OCS_Session_Start_Time,OCS_Session_Duration,OCS_Response_Delay,OCS_Response_Code" "PCC-CDR-Reference-Guide-v7.x" "SPR Adaptor" "Update Notification Response to the SPR (i.e. Sp PNa)(108,208)" "$variableCDR";;
        108,301)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "Subscriber_ID,Service_ID,Transaction_Type,Tenant ID,CDR_Generation_Date,CDR_Generation_Time,Instance_ID,CDR_Segment_Number,CDR_Sequence_Number,PCRF_Session_ID,PCRF_Session_Start_Time,PCRF_Session_Duration,PCRF_Response_Code,PCRF_Event_Trigger,IMSI,UE_IP_Address,UE_IPv6_Prefix,UE_Info,PDN_ID,ANGW_Ipv6_Address,ANGW_Ipv4_Address,SGSN_Ipv4_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,PLMN_ID,RAI,IP_CAN_Type,RAT_Type,User_Location_Info,Ms_Time_Zone,NW_Charging_ID,SPR_Session_ID,SPR_Session_Start_Time,SPR_Session_Duration,SPR_Response_Delay,SPR_Response_Code,SPR_Customer-Status,SPR_Classification,SPR_Tenant-Name,SPR_Service-Status,SPR_Instance-Name,OCS_Session_ID,OCS_Session_Start_Time,OCS_Session_Duration,OCS_Response_Delay,OCS_Response_Code" "PCC-CDR-Reference-Guide-v7.x" "SPR Adaptor" "Session Init Request to the OCS (i.e. Sy SLR)(108,301)" "$variableCDR";;
        108,302)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "Subscriber_ID,Service_ID,Transaction_Type,Tenant ID,CDR_Generation_Date,CDR_Generation_Time,Instance_ID,CDR_Segment_Number,CDR_Sequence_Number,PCRF_Session_ID,PCRF_Session_Start_Time,PCRF_Session_Duration,PCRF_Response_Code,PCRF_Event_Trigger,IMSI,UE_IP_Address,UE_IPv6_Prefix,UE_Info,PDN_ID,ANGW_Ipv6_Address,ANGW_Ipv4_Address,SGSN_Ipv4_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,PLMN_ID,RAI,IP_CAN_Type,RAT_Type,User_Location_Info,Ms_Time_Zone,NW_Charging_ID,SPR_Session_ID,SPR_Session_Start_Time,SPR_Session_Duration,SPR_Response_Delay,SPR_Response_Code,SPR_Customer-Status,SPR_Classification,SPR_Tenant-Name,SPR_Service-Status,SPR_Instance-Name,OCS_Session_ID,OCS_Session_Start_Time,OCS_Session_Duration,OCS_Response_Delay,OCS_Response_Code" "PCC-CDR-Reference-Guide-v7.x" "SPR Adaptor" "Session Init Response from the OCS (i.e. Sy SLA)(108,302)" "$variableCDR";;
        108,303)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "Subscriber_ID,Service_ID,Transaction_Type,Tenant ID,CDR_Generation_Date,CDR_Generation_Time,Instance_ID,CDR_Segment_Number,CDR_Sequence_Number,PCRF_Session_ID,PCRF_Session_Start_Time,PCRF_Session_Duration,PCRF_Response_Code,PCRF_Event_Trigger,IMSI,UE_IP_Address,UE_IPv6_Prefix,UE_Info,PDN_ID,ANGW_Ipv6_Address,ANGW_Ipv4_Address,SGSN_Ipv4_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,PLMN_ID,RAI,IP_CAN_Type,RAT_Type,User_Location_Info,Ms_Time_Zone,NW_Charging_ID,SPR_Session_ID,SPR_Session_Start_Time,SPR_Session_Duration,SPR_Response_Delay,SPR_Response_Code,SPR_Customer-Status,SPR_Classification,SPR_Tenant-Name,SPR_Service-Status,SPR_Instance-Name,OCS_Session_ID,OCS_Session_Start_Time,OCS_Session_Duration,OCS_Response_Delay,OCS_Response_Code" "PCC-CDR-Reference-Guide-v7.x" "SPR Adaptor" "Session Update Request to the OCS (i.e. Sy SLR)(108,303)" "$variableCDR";;
        108,304)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "Subscriber_ID,Service_ID,Transaction_Type,Tenant ID,CDR_Generation_Date,CDR_Generation_Time,Instance_ID,CDR_Segment_Number,CDR_Sequence_Number,PCRF_Session_ID,PCRF_Session_Start_Time,PCRF_Session_Duration,PCRF_Response_Code,PCRF_Event_Trigger,IMSI,UE_IP_Address,UE_IPv6_Prefix,UE_Info,PDN_ID,ANGW_Ipv6_Address,ANGW_Ipv4_Address,SGSN_Ipv4_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,PLMN_ID,RAI,IP_CAN_Type,RAT_Type,User_Location_Info,Ms_Time_Zone,NW_Charging_ID,SPR_Session_ID,SPR_Session_Start_Time,SPR_Session_Duration,SPR_Response_Delay,SPR_Response_Code,SPR_Customer-Status,SPR_Classification,SPR_Tenant-Name,SPR_Service-Status,SPR_Instance-Name,OCS_Session_ID,OCS_Session_Start_Time,OCS_Session_Duration,OCS_Response_Delay,OCS_Response_Code" "PCC-CDR-Reference-Guide-v7.x" "SPR Adaptor" "Session Update Response from the OCS (i.e. Sy SLA)(108,304)" "$variableCDR";;
        108,305)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "Subscriber_ID,Service_ID,Transaction_Type,Tenant ID,CDR_Generation_Date,CDR_Generation_Time,Instance_ID,CDR_Segment_Number,CDR_Sequence_Number,PCRF_Session_ID,PCRF_Session_Start_Time,PCRF_Session_Duration,PCRF_Response_Code,PCRF_Event_Trigger,IMSI,UE_IP_Address,UE_IPv6_Prefix,UE_Info,PDN_ID,ANGW_Ipv6_Address,ANGW_Ipv4_Address,SGSN_Ipv4_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,PLMN_ID,RAI,IP_CAN_Type,RAT_Type,User_Location_Info,Ms_Time_Zone,NW_Charging_ID,SPR_Session_ID,SPR_Session_Start_Time,SPR_Session_Duration,SPR_Response_Delay,SPR_Response_Code,SPR_Customer-Status,SPR_Classification,SPR_Tenant-Name,SPR_Service-Status,SPR_Instance-Name,OCS_Session_ID,OCS_Session_Start_Time,OCS_Session_Duration,OCS_Response_Delay,OCS_Response_Code" "PCC-CDR-Reference-Guide-v7.x" "SPR Adaptor" "Session Term Request to the OCS (i.e. Sy STR)(108,305)" "$variableCDR";;
        108,306)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "Subscriber_ID,Service_ID,Transaction_Type,Tenant ID,CDR_Generation_Date,CDR_Generation_Time,Instance_ID,CDR_Segment_Number,CDR_Sequence_Number,PCRF_Session_ID,PCRF_Session_Start_Time,PCRF_Session_Duration,PCRF_Response_Code,PCRF_Event_Trigger,IMSI,UE_IP_Address,UE_IPv6_Prefix,UE_Info,PDN_ID,ANGW_Ipv6_Address,ANGW_Ipv4_Address,SGSN_Ipv4_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,PLMN_ID,RAI,IP_CAN_Type,RAT_Type,User_Location_Info,Ms_Time_Zone,NW_Charging_ID,SPR_Session_ID,SPR_Session_Start_Time,SPR_Session_Duration,SPR_Response_Delay,SPR_Response_Code,SPR_Customer-Status,SPR_Classification,SPR_Tenant-Name,SPR_Service-Status,SPR_Instance-Name,OCS_Session_ID,OCS_Session_Start_Time,OCS_Session_Duration,OCS_Response_Delay,OCS_Response_Code" "PCC-CDR-Reference-Guide-v7.x" "SPR Adaptor" "Session Term Response from the OCS (i.e. Sy STA)(108,306)" "$variableCDR";;
        108,307)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "Subscriber_ID,Service_ID,Transaction_Type,Tenant ID,CDR_Generation_Date,CDR_Generation_Time,Instance_ID,CDR_Segment_Number,CDR_Sequence_Number,PCRF_Session_ID,PCRF_Session_Start_Time,PCRF_Session_Duration,PCRF_Response_Code,PCRF_Event_Trigger,IMSI,UE_IP_Address,UE_IPv6_Prefix,UE_Info,PDN_ID,ANGW_Ipv6_Address,ANGW_Ipv4_Address,SGSN_Ipv4_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,PLMN_ID,RAI,IP_CAN_Type,RAT_Type,User_Location_Info,Ms_Time_Zone,NW_Charging_ID,SPR_Session_ID,SPR_Session_Start_Time,SPR_Session_Duration,SPR_Response_Delay,SPR_Response_Code,SPR_Customer-Status,SPR_Classification,SPR_Tenant-Name,SPR_Service-Status,SPR_Instance-Name,OCS_Session_ID,OCS_Session_Start_Time,OCS_Session_Duration,OCS_Response_Delay,OCS_Response_Code" "PCC-CDR-Reference-Guide-v7.x" "SPR Adaptor" "Update Notification from the OCS (i.e. Sy SNR)(108,307)" "$variableCDR";;
        108,308)newCDR=$cdr;cdr=$(echo "$cdr" | cut -d'&' -f1);variableCDR=$(echo "$newCDR" | cut -d'&' -s -f2);parseCDR "Subscriber_ID,Service_ID,Transaction_Type,Tenant ID,CDR_Generation_Date,CDR_Generation_Time,Instance_ID,CDR_Segment_Number,CDR_Sequence_Number,PCRF_Session_ID,PCRF_Session_Start_Time,PCRF_Session_Duration,PCRF_Response_Code,PCRF_Event_Trigger,IMSI,UE_IP_Address,UE_IPv6_Prefix,UE_Info,PDN_ID,ANGW_Ipv6_Address,ANGW_Ipv4_Address,SGSN_Ipv4_Address,SGSN_Ipv6_Address,GGSN_Ipv4_Address,GGSN_Ipv6_Address,PLMN_ID,RAI,IP_CAN_Type,RAT_Type,User_Location_Info,Ms_Time_Zone,NW_Charging_ID,SPR_Session_ID,SPR_Session_Start_Time,SPR_Session_Duration,SPR_Response_Delay,SPR_Response_Code,SPR_Customer-Status,SPR_Classification,SPR_Tenant-Name,SPR_Service-Status,SPR_Instance-Name,OCS_Session_ID,OCS_Session_Start_Time,OCS_Session_Duration,OCS_Response_Delay,OCS_Response_Code" "PCC-CDR-Reference-Guide-v7.x" "SPR Adaptor" "Update Notification Response to the OCS (i.e. Sy SNA)(108,308)" "$variableCDR";;
        88,1)parseCDR "CDR Call Correlation ID,CDR Service ID,CDR Transaction Type,CDR Creation Date,CDR Creation Time,Announcement Report Status,Response Type,Message ID,Language ID" "SCF-SDV4.0.pdf" "ISA Web Service" "Request Instructions (88,1)";;
        88,2)parseCDR "CDR Call Correlation ID,CDR Service ID,CDR Transaction Type,CDR Creation Date,CDR Creation Time,Announcement Report Status,Response Type,Message ID,Language ID" "SCF-SDV4.0.pdf" "ISA Web Service" "Request Instructions (88,2)";;
        17,1)cdr=$(echo "$cdr" | sed -e 's/,17,1,/,17,1,-,-,/');parseCDR "Subscriber ID,Service ID,Transaction Type,Unused,Unused,Date,Time,CDR Correlation ID,Service Code,MSISDN,IMSI,Session ID,USSD Content" "iAX-USSD-CDRv2.0.pdf" "USSD Handler" "MI USSD Request CDR (17,1)";;
        17,2)cdr=$(echo "$cdr" | sed -e 's/,17,2,/,17,2,-,-,/');parseCDR "Subscriber ID,Service ID,Transaction Type,Unused,Unused,Date,Time,CDR Correlation ID,Service Code,MSISDN,Session ID,USSD Content,Status,Error Code" "iAX-USSD-CDRv2.0.pdf" "USSD Handler" "MI USSD Response CDR (17,2)";;
        171,1)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant,MSISDN,Correlation ID,Date,Time,Result Code,Result Message,Campaign ID,Offer Name" "https://confluence-ie.csgicorp.com:8443/display/DEV/Single+View+Event+Handler" "SV Event Services" "Flow CDR (71,1)";;
        171,2)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant,MSISDN,Correlation ID,Date,Time,Result Code,Result Message,Short Code,Channel" "https://confluence-ie.csgicorp.com:8443/display/DEV/Single+View+Event+Handler" "SV Event Services" "Flow CDR (71,2)";;
        172,1)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant,MSISDN,Correlation ID,Date,Time,Result Code,Result Message,Campaign ID,Offer Name" "https://confluence-ie.csgicorp.com:8443/display/DEV/Single+View+Event+Handler" "SV Accept Services" "Flow CDR (72,1)";;
        172,2)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant,MSISDN,Correlation ID,Date,Time,Result Code,Result Message,Short Code,Channel" "https://confluence-ie.csgicorp.com:8443/display/DEV/Single+View+Event+Handler" "SV Accept Services" "Notification Flow CDR (72,2)";;
        80,1)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant,MSISDN,Session ID,Date,Time,Event,State,Error Code,Error message" "https://confluence-ie.csgicorp.com:8443/display/DEV/USSD+Promotion+Service" "USSD Promotion Service" "Start USSD NI CDR (80,1)";;
# NGINX CDRs
        177,1)parseCDR "Subscriber ID,Service ID,Transaction Type,Tenant,Time,HRG context,imsi,expiryTimestamp,Source HRG Req Generator,Source address,request URL,HTTP errorCode" "/etc/nginx/conf.d/tomcat-basic.conf" "Vivo DataPassport Consumption Notification IF7" "NGINX CDR (177,1)";;


        *)legasyparseCDR;;

esac
}

#### Main()

# Flags and Mode
while getopts m:t:f:h option;
do
        case $option in
                m) msisdn=$OPTARG;;
                f) file=$OPTARG;;
                t) tail=$OPTARG;;
                h) hcHits=$(cat $DIR/.cdrParseHits);echo "
        Usage: cdrParse


        Filename:    cdrPasres
        Revision:    0.1.0
        Visits:      `tput setaf 2`$hcHits`tput sgr0`
        Author:      Hector Barriga

        Jiras:
        CO Scripts:  COSC-xx
        CO Internal: COIT-xxxx

        This sh script is to parse DRE CDRs such as Activity Meter, USSD SI, SPCM, PCRF
        GTP, SOM, OCI, DND and HRG CDRs

        This sh script is mainly used for Tango  CO internal  monitoring
        Copyright (c) Tango Telecom 2018

        All rights reserved.
        This document contains confidential and proprietary information of
        Tango Telecom and any reproduction, disclosure, or use in whole or
        in part is expressly prohibited, except as may be specifically
        authorized by prior written agreement or permission of Tango Telecom.


               Options:

               -h <help>                Show help

               -f <file>                To parse all CDRs present in a file

               -m <msisdn>              To filter all CDRs present in the file
                                        Note: It can also be sused to filter a particular string/field

               -t <tail>                To parse active CDRs from an active file in real time

               Examples:

               e.g. ./cdrParse.sh
                    It will promt \"Enter CDR > \" to enter CDR that will be parsed

               e.g. ./cdrParse.sh '<cdr>'
                    Same as above but promt will be not needed. Note, if there are spaces, use quotes '

               e.g. ./cdrParse.sh -f /tango/data/cdr/active_SI.cdr -m 5050101090402030803070904
                    Parse all CDRs where 5511942383794 is present from active_SI.cdr.
                    Note: USSD SI msisdn is always separated by 0, so you must insert the 0 in -m flag

               e.g. ./cdrParse.sh -t /tango/data/cdr/active_SI.cdr -m "17,41"
                    Parse CDRs that contain string \"17,41\" in real time from active file active_SI.cdr

               "; h="true";;
        esac
done

if [ "$h" != "true" ];then
################## Count cdrParse visits ###########
        if [ ! -f $DIR/.cdrParseHits ];then
                echo 0 > $DIR/.cdrParseHits
        fi
        hcHits=$(cat $DIR/.cdrParseHits)
        hcHits=$(($hcHits+1))
        echo "$hcHits" > $DIR/.cdrParseHits
        echo ""
        echo "                                      `tput setaf 2`Visits: $hcHits`tput sgr0`      "
        echo

###################### Start Script ###########
        if [ ! -z "$tail" ];then
                while(true)
                do
                        cp $tail $DIR/.tempFile
                        sleep 1
                        fileDiff=$(grep -v -f $DIR/.tempFile $tail | grep "$msisdn")
                        if  [ ! -z "$fileDiff" ];then
                                while read fileline
                                do
                                        getCDR "$fileline"
                                        sleep 1
                                done <<<"$fileDiff"
                        fi
                done


        elif [ ! -z "$file" ] && [ -z "$tail" ];then
                while read fileline
                do
                        getCDR "$fileline"
                done < <(cat $file | grep "$msisdn")
        else
                if [ -z "$1" ];then
                        echo -n "Enter CDR [Note, if there empty spaces, use quotes '] > "
                        read cdr
                else
                        if [ ! -z "$2" ];then
                                echo -e "\n\n`tput setaf 1`Only one argument permited. If CDR has spaces, make sure quotes ' are used. Press Enter to continue`tput sgr0`\n"
                                exit
                        fi
                        cdr="$1"
                fi
                getCDR "$cdr"
        fi
fi