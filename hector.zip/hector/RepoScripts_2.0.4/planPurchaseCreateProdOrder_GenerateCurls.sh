#!/bin/bash
SCRIPT=$(realpath "$0")
defaultMsisdn="13455163528"
defaultSVEnv="HRD"
TMF620Level="L4"
echo "`tput setaf 2`
TEST MSISDNS:

18764034045     Nejila Jamaica
18764071398     Nejila Jamaica
18764034049     Nejila Jamaica
13455163528     Karan Main test MSISDN
13455012316
13455163626
18764034045
13451003216     Supriya Demo 5
13451003228     Supriya Demo 5
13454879318     PrePaid for Plan Purchase
13455163645     PrePaid for Plan Purchase and PlanPurchase Karan
13453421244     PlanPurchase Nitish
13458009140     PlanPurchase Test for Hector
13458009138     PlanPurchase Test for Hector
13455163626     Karan
13457845201     Karan FnF
13455483091     SV UAT Alessandro
13453233464     Jadan SIT USSSD
12468339211     BARBADOS USSD SIT and SV SIT
13455483136     Cayman SIT cassandrea
13453233530     Mogany Cay UAT
12468421291     UAT Pardeep
13453233387     SIT Jadan Jones
13453233509     SIT Paul Gordon
13453233385     SIT Jadan Jones
13455483079     UAT
13453233462     UAT
13457013031     Carlos Vallejo HRD
18697601014     PROD CSG
18697605797     PROD Real Subscriber
18697674807     PROD Cassandrea
13453237167     PROD Real Subscriber
13453001550     HRD Supriya
18697678606     UAT St Kitts
13451005036     HRD
18697600509     UAT Cassandrea
13453005438     HRD Santosh Digiloan
18697606536     HRD Plan Purchase Bruno Villa
18697638961     UAT Abigail PlanPurchase
13456024233     HRD Cayman Supriya
18697648981     PROD Cassandrea Plan Purchase
18697607057     PROD Alessandro Plan Purchase
18697679071     UAT St Kitts Prime
`tput sgr0`";
echo -n "Enter MSISDN [Default = $defaultMsisdn] > "
read msisdn
if [ -z "$msisdn" ] ;then msisdn=$defaultMsisdn;fi
echo -n "Enter SV Environment [Default = $defaultSVEnv] > "
read SVEnv
if [ -z "$SVEnv" ] ;then SVEnv=$defaultSVEnv;fi

if [ $SVEnv == "SIT" ];then
        SubKey="a2dc29ac86bb49528ec4ca90ab38cd2f"
        APIMDomain="sit-apim.digicelgroup.com"
elif [ $SVEnv == "UAT" ];then
        SubKey="44fd6e018469407ea6be0bdddb36ed3d"
        APIMDomain="uat-apim.digicelgroup.com"
elif [ $SVEnv == "HRD" ];then
        SubKey="c4a7619bc8644636a1f899405a8974d3"
        APIMDomain="stg-apim.digicelgroup.com"
elif [ $SVEnv == "PROD" ];then
        SubKey="38c691706ce24907be81bf04534427b7"
        APIMDomain="apim.digicelgroup.com"
else
        echo -e "\nWrong Environment, bye\n";exit
fi
echo -e "\n`tput setaf 2`=====================================================\nPARENT FAMILY MENU\n"
echo "1. BestSeller Plans
2. Stay Connected
3. Prime
4. Data Only Prime
5. Prime Digiloan
6. FnF
7. Voice Roaming
8. International Voice
9. Local Voice"
echo "===================================================== `tput sgr0`"
echo -n "Enter Option > "
read parentFamilyOpt
if [ -z "$parentFamilyOpt" ]; then
        echo -e "\nWhat? "
        echo -n -e "\n\nEnter Option > "
        read parentFamilyOpt
fi
optionChildOfferTag="IMP_PACK"
if [ $parentFamilyOpt == "2" ];then
        parentFamilyKey="stay%20connected"
        familyKey="stay%20connected"
        optionParentFamily=$parentFamilyKey
elif [ $parentFamilyOpt == "3" ];then
        parentFamilyKey="prime"
        optionParentFamily=$parentFamilyKey
        familyKey="prime"
elif [ $parentFamilyOpt == "4" ];then
        parentFamilyKey="data%20only"
        optionParentFamily=$parentFamilyKey
        familyKey="data%20only"
elif [ $parentFamilyOpt == "5" ];then
        parentFamilyKey="anyproduct"
        optionParentFamily="digiloanplan"
        familyKey="anyproduct"
        optionChildOfferTag="VAS_DIGILOAN_PLAN"
elif [ $parentFamilyOpt == "6" ];then
        familyKey="fnf"
        TMF620Level="L3"
elif [ $parentFamilyOpt == "7" ] && [ $SVEnv == "HRD" ];then
        familyKey="roam"
        TMF620Level="L3"
elif [ $parentFamilyOpt == "7" ] && [ $SVEnv == "UAT" ];then
        parentFamilyKey="roam"
        optionParentFamily=$parentFamilyKey
        familyKey="roam"
        TMF620Level="L4"
elif [ $parentFamilyOpt == "8" ];then
        parentFamilyKey="int"
        familyKey="int"
        optionParentFamily=$parentFamilyKey
elif [ $parentFamilyOpt == "9" ];then
        parentFamilyKey="local"
        familyKey="local"
        optionParentFamily=$parentFamilyKey
elif [ $parentFamilyOpt == "1" ];then
        parentFamilyKey="prime"
        optionParentFamily="bestseller"
        familyKey="prime"
        optionChildOfferTag="BEST_SELLER"
fi

getTMF632=$(curl -X GET -H "tenant: production" -H "" "http://localhost:8286/serviceRequest?context=APIM_$SVEnv""_TMF632_PartyManagement&APIMSubscriptionKey=$SubKey&tenant=production&msisdn=$msisdn")
isTMF632=$(echo "$getTMF632" | sed 's/><[^/]/>\n</g' | grep TangoResponseCode | cut -d">" -f2 | cut -d"<" -f1)
prodCat=$(curl -X GET -H "tenant: production" -H "" "http://localhost:8286/serviceRequest?context=APIM_$SVEnv""_TMF637_ProductInventoryManagement&APIMSubscriptionKey=$SubKey&tenant=production&msisdn=$msisdn" )
isTMF637=$(echo "$prodCat" | grep TangoResponseCode | cut -d">" -f4 | cut -d"<" -f1)
prodCatId=$(echo "$prodCat" | sed 's/><[^/]/>\n</g' | grep rodCatalogID | cut -d">" -f2 | cut -d"<" -f1 | jq '.prodCatalogId[0]')
prodCatName=$(echo "$prodCat" | sed 's/><[^/]/>\n</g' | grep rodCatalogName | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.prodCatalogName[0]')
currentPlanPurchaseLength=$(echo "$prodCat" | grep currentPlanPurchaseJson | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.currentPlanPurchase' | jq length)

for (( clo=0;clo < $currentPlanPurchaseLength;clo++)); do
        if [ $clo == "0" ];then
                currentPlanPurchaseID0=$(echo "$prodCat" | grep currentPlanPurchaseJson | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.currentPlanPurchase['$clo'].currentCLOPlanPurchaseId')
                currentPlanPurchaseName0=$(echo "$prodCat" | grep currentPlanPurchaseJson | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.currentPlanPurchase['$clo'].currentCLOPlanPurchaseName')
                currentPlanPurchaseStr0="$currentPlanPurchaseName0 [$currentPlanPurchaseID0]"
                currentFamilyId0=$(echo "$prodCat" | grep currentPlanPurchaseJson | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.currentPlanPurchase['$clo'].currentParentBundles.currentFamilyIdPlanPurchase')
                currentFamilyName0=$(echo "$prodCat" | grep currentPlanPurchaseJson | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.currentPlanPurchase['$clo'].currentParentBundles.currentFamilyNamePlanPurchase')
                currentFamilyPlanPurchaseStr0="$currentFamilyName0 [$currentFamilyId0]"
        elif [ $clo == "1" ];then
                currentPlanPurchaseID1=$(echo "$prodCat" | grep currentPlanPurchaseJson | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.currentPlanPurchase['$clo'].currentCLOPlanPurchaseId')
                currentPlanPurchaseName1=$(echo "$prodCat" | grep currentPlanPurchaseJson | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.currentPlanPurchase['$clo'].currentCLOPlanPurchaseName')
                currentPlanPurchaseStr1="`tput setaf 5`$currentPlanPurchaseName1 [$currentPlanPurchaseID1]"
                currentFamilyId1=$(echo "$prodCat" | grep currentPlanPurchaseJson | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.currentPlanPurchase['$clo'].currentParentBundles.currentFamilyIdPlanPurchase')
                currentFamilyName1=$(echo "$prodCat" | grep currentPlanPurchaseJson | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.currentPlanPurchase['$clo'].currentParentBundles.currentFamilyNamePlanPurchase')
                currentFamilyPlanPurchaseStr1="`tput setaf 5`$currentFamilyName1 [$currentFamilyId1]"
        elif [ $clo == "2" ];then
                currentPlanPurchaseID2=$(echo "$prodCat" | grep currentPlanPurchaseJson | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.currentPlanPurchase['$clo'].currentCLOPlanPurchaseId')
                currentPlanPurchaseName2=$(echo "$prodCat" | grep currentPlanPurchaseJson | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.currentPlanPurchase['$clo'].currentCLOPlanPurchaseName')
                currentPlanPurchaseStr2="`tput setaf 6`$currentPlanPurchaseName2 [$currentPlanPurchaseID2]"
                currentFamilyId2=$(echo "$prodCat" | grep currentPlanPurchaseJson | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.currentPlanPurchase['$clo'].currentParentBundles.currentFamilyIdPlanPurchase')
                currentFamilyName2=$(echo "$prodCat" | grep currentPlanPurchaseJson | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.currentPlanPurchase['$clo'].currentParentBundles.currentFamilyNamePlanPurchase')
                currentFamilyPlanPurchaseStr2="`tput setaf 6`$currentFamilyName2 [$currentFamilyId2]"
        elif [ $clo == "3" ];then
                currentPlanPurchaseID3=$(echo "$prodCat" | grep currentPlanPurchaseJson | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.currentPlanPurchase['$clo'].currentCLOPlanPurchaseId')
                currentPlanPurchaseName3=$(echo "$prodCat" | grep currentPlanPurchaseJson | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.currentPlanPurchase['$clo'].currentCLOPlanPurchaseName')
                currentPlanPurchaseStr3="`tput setaf 3`$currentPlanPurchaseName3 [$currentPlanPurchaseID3]"
                currentFamilyId3=$(echo "$prodCat" | grep currentPlanPurchaseJson | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.currentPlanPurchase['$clo'].currentParentBundles.currentFamilyIdPlanPurchase')
                currentFamilyName3=$(echo "$prodCat" | grep currentPlanPurchaseJson | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.currentPlanPurchase['$clo'].currentParentBundles.currentFamilyNamePlanPurchase')
                currentFamilyPlanPurchaseStr3="`tput setaf 3`$currentFamilyName3 [$currentFamilyId3]"
        elif [ $clo == "4" ];then
                currentPlanPurchaseID4=$(echo "$prodCat" | grep currentPlanPurchaseJson | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.currentPlanPurchase['$clo'].currentCLOPlanPurchaseId')
                currentPlanPurchaseName4=$(echo "$prodCat" | grep currentPlanPurchaseJson | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.currentPlanPurchase['$clo'].currentCLOPlanPurchaseName')
                currentPlanPurchaseStr4="`tput setaf 4`$currentPlanPurchaseName4 [$currentPlanPurchaseID4]"
                currentFamilyId4=$(echo "$prodCat" | grep currentPlanPurchaseJson | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.currentPlanPurchase['$clo'].currentParentBundles.currentFamilyIdPlanPurchase')
                currentFamilyName4=$(echo "$prodCat" | grep currentPlanPurchaseJson | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.currentPlanPurchase['$clo'].currentParentBundles.currentFamilyNamePlanPurchase')
                currentFamilyPlanPurchaseStr4="`tput setaf 4`$currentFamilyName4 [$currentFamilyId4]"
        elif [ $clo == "5" ];then
                currentPlanPurchaseID5=$(echo "$prodCat" | grep currentPlanPurchaseJson | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.currentPlanPurchase['$clo'].currentCLOPlanPurchaseId')
                currentPlanPurchaseName5=$(echo "$prodCat" | grep currentPlanPurchaseJson | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.currentPlanPurchase['$clo'].currentCLOPlanPurchaseName')
                currentPlanPurchaseStr5="`tput setaf 5`$currentPlanPurchaseName5 [$currentPlanPurchaseID5]"
                currentFamilyId5=$(echo "$prodCat" | grep currentPlanPurchaseJson | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.currentPlanPurchase['$clo'].currentParentBundles.currentFamilyIdPlanPurchase')
                currentFamilyName5=$(echo "$prodCat" | grep currentPlanPurchaseJson | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.currentPlanPurchase['$clo'].currentParentBundles.currentFamilyNamePlanPurchase')
                currentFamilyPlanPurchaseStr5="`tput setaf 5`$currentFamilyName5 [$currentFamilyId5]"
        elif [ $clo == "6" ];then
                currentPlanPurchaseID6=$(echo "$prodCat" | grep currentPlanPurchaseJson | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.currentPlanPurchase['$clo'].currentCLOPlanPurchaseId')
                currentPlanPurchaseName6=$(echo "$prodCat" | grep currentPlanPurchaseJson | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.currentPlanPurchase['$clo'].currentCLOPlanPurchaseName')
                currentPlanPurchaseStr6="`tput setaf 6`$currentPlanPurchaseName6 [$currentPlanPurchaseID6]"
                currentFamilyId6=$(echo "$prodCat" | grep currentPlanPurchaseJson | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.currentPlanPurchase['$clo'].currentParentBundles.currentFamilyIdPlanPurchase')
                currentFamilyName6=$(echo "$prodCat" | grep currentPlanPurchaseJson | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.currentPlanPurchase['$clo'].currentParentBundles.currentFamilyNamePlanPurchase')
                currentFamilyPlanPurchaseStr6="`tput setaf 6`$currentFamilyName6 [$currentFamilyId6]"
        fi
done
currentPlanPurchaseID="$currentPlanPurchaseID0"
currentPlanPurchaseName="$currentPlanPurchaseName0"
currentFamilyPlanPurchaseID=$(echo "$prodCat" | grep currentPlanPurchaseJson | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.currentPlanPurchase[0].currentParentBundles.currentFamilyIdPlanPurchase')
currentFamilyPlanPurchaseName=$(echo "$prodCat" | grep currentPlanPurchaseJson | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.currentPlanPurchase[0].currentParentBundles.currentFamilyNamePlanPurchase')
currentParentFamilyPlanPurchaseID=$(echo "$prodCat" | grep currentPlanPurchaseJson | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.currentPlanPurchase[0].currentParentBundles.currentParentFamilyIdPlanPurchase')
baseProdInsId=$(curl -X GET -H "tenant: production" -H "" "http://localhost:8286/serviceRequest?context=APIM_$SVEnv""_TMF637_ProductInventoryManagement&APIMSubscriptionKey=$SubKey&tenant=production&msisdn=$msisdn" | sed 's/><[^/]/>\n</g' | grep aseProdInstanceId| cut -d">" -f2 | cut -d"<" -f1 | jq '.baseProdInstanceID[0]')
customerId=$(curl -X GET -H "tenant: production" -H "" "http://localhost:8286/serviceRequest?msisdn=$msisdn&context=APIM_$SVEnv""_TMF629_getCustomerID&tenant=production&APIMSubscriptionKey=$SubKey&msisdnIn=$msisdn"| sed 's/><[^/]/>\n</g' | grep ustomerID| cut -d">" -f2 | cut -d"<" -f1)
curl -X GET -H "Accept: application/json" -H "Ocp-Apim-Subscription-Key: $SubKey" "https://$APIMDomain/product-catalog-management/productOffering?channel=USSD&customerId=$customerId&retrievalType=3&objKeys=$prodCatId&offerEligibility=Available&baseProductInstanceId=$baseProdInsId&serviceName=$msisdn&fields=bundledProductOffering"
echo -e "\n------------------------------------------------------------------------------------------------------------------------------------------------------\n                          ^\n                          |"
echo -e "\nTMF620 via APIM get Families L4 PlanPurchase\n\n`tput setaf 3`curl -X GET -H \"Accept: application/json\" -H \"Ocp-Apim-Subscription-Key: $SubKey\" \"https://$APIMDomain/product-catalog-management/productOffering?channel=USSD&customerId=$customerId&retrievalType=3&objKeys=$prodCatId&offerEligibility=Available&baseProductInstanceId=$baseProdInsId&serviceName=$msisdn&fields=bundledProductOffering\"`tput sgr0`"
echo "------------------------------------------------------------------------------------------------------------------------------------------------------"
echo "$getTMF632"
echo -e "\n------------------------------------------------------------------------------------------------------------------------------------------------------\n                          ^\n                          |"
echo -e "\nTMF632 via HRG get Subscriber preffered Language \n\n`tput setaf 2`curl -X GET -H \"tenant: production\" -H \"\" \"http://localhost:8286/serviceRequest?context=APIM_$SVEnv""_TMF632_PartyManagement&APIMSubscriptionKey=$SubKey&tenant=production&msisdn=$msisdn\"`tput sgr0`"
if [ "$isTMF632" == "200" ];then
        echo -e "\033[97;42;1m TMF632 = 200 OK \033[m\n\n"
else
        echo -e "\033[97;41;1m TMF632 = 200 NOT OK \033[m\n\n"
fi
echo "------------------------------------------------------------------------------------------------------------------------------------------------------"
echo "$prodCat"
echo -e "\n------------------------------------------------------------------------------------------------------------------------------------------------------\n                          ^\n                          |"
echo -e "\nTMF637 via HRG get Prod Catalog PlanPurchase\n\n`tput setaf 2`curl -X GET -H \"tenant: production\" -H \"\" \"http://localhost:8286/serviceRequest?context=APIM_$SVEnv""_TMF637_ProductInventoryManagement&APIMSubscriptionKey=$SubKey&tenant=production&msisdn=$msisdn\"`tput sgr0`"
if [ "$isTMF637" == "200" ];then
        echo -e "\033[97;42;1m TMF637 = 200 OK \033[m\n\n"
else
        echo -e "\033[97;41;1m TMF632 = 200 NOT OK \033[m\n\n"
fi
echo "------------------------------------------------------------------------------------------------------------------------------------------------------"
if [ "$TMF620Level" == "L4" ];then
        getFamiliesPlanPurchase=$(curl -X GET -H "tenant: production" -H "" "http://localhost:8286/serviceRequest?msisdn=$msisdn&context=APIM_$SVEnv""_TMF620_GetFamilies""_$TMF620Level""&tenant=production&APIMSubscriptionKey=$SubKey&customerID=$customerId&productCatalogID=$prodCatId&baseProductInstanceId=$baseProdInsId&parentFamilyKey=$parentFamilyKey&familyKey=$familyKey&msisdnIn=$msisdn&optionParentFamily=$optionParentFamily&optionChildOfferTag=$optionChildOfferTag")
elif [ "$TMF620Level" == "L3" ];then
        getFamiliesPlanPurchase=$(curl -X GET -H "tenant: production" -H "" "http://localhost:8286/serviceRequest?msisdn=$msisdn&context=APIM_$SVEnv""_TMF620_GetFamilies""_$TMF620Level""&tenant=production&APIMSubscriptionKey=$SubKey&customerID=$customerId&productCatalogID=$prodCatId&baseProductInstanceId=$baseProdInsId&familyKey=$familyKey&msisdnIn=$msisdn")
fi
isTMF620=$(echo "$getFamiliesPlanPurchase" | sed 's/><[^/]/>\n</g' | grep TangoResponseCode | cut -d">" -f2 | cut -d"<" -f1)
echo $getFamiliesPlanPurchase
echo -e "\n------------------------------------------------------------------------------------------------------------------------------------------------------\n                          ^\n                          |"
if [ "$TMF620Level" == "L4" ];then
        echo -e "\nTMF620 via HRG get Families PlanPurchase for Plans in L4\n\n`tput setaf 2`curl -X GET -H \"tenant: production\" -H \"\" \"http://localhost:8286/serviceRequest?msisdn=$msisdn&msisdnIn=$msisdn&context=APIM_$SVEnv""_TMF620_GetFamilies""_$TMF620Level""&tenant=production&APIMSubscriptionKey=$SubKey&customerID=$customerId&productCatalogID=$prodCatId&baseProductInstanceId=$baseProdInsId&parentFamilyKey=$parentFamilyKey&familyKey=$familyKey&optionParentFamily=$optionParentFamily&optionChildOfferTag=$optionChildOfferTag\"`tput sgr0`"
elif [ "$TMF620Level" == "L3" ];then
                echo -e "\nTMF620 via HRG get Families PlanPurchase for Plans in L3\n\n`tput setaf 2`curl -X GET -H \"tenant: production\" -H \"\" \"http://localhost:8286/serviceRequest?msisdn=$msisdn&context=APIM_$SVEnv""_TMF620_GetFamilies""_$TMF620Level""&tenant=production&APIMSubscriptionKey=$SubKey&customerID=$customerId&productCatalogID=$prodCatId&baseProductInstanceId=$baseProdInsId&familyKey=$familyKey&msisdnIn=$msisdn\"`tput sgr0`"
fi
if [ "$isTMF620" == "200" ];then
        echo -e "\033[97;42;1m TMF620 = 200 OK \033[m\n\n"
else
        echo -e "\033[97;41;1m TMF632 = 200 NOT OK \033[m\n\n"
fi
echo "------------------------------------------------------------------------------------------------------------------------------------------------------"
echo -e "\n`tput setaf 2`=====================================================\nFAMILY MENU\n\n`tput setaf 3`currentFamilyPlanPurchaseName =  \e\033[0;93m$currentFamilyPlanPurchaseName [$currentFamilyPlanPurchaseID\e\033[0m`tput setaf 3`] $currentFamilyPlanPurchaseStr1 $currentFamilyPlanPurchaseStr2 $currentFamilyPlanPurchaseStr3 $currentFamilyPlanPurchaseStr4 $currentFamilyPlanPurchaseStr5 $currentFamilyPlanPurchaseStr6\n`tput setaf 2`"
getFamiliesArrayLength=$(echo "$getFamiliesPlanPurchase" | grep familyBundles | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.familyBundles' | jq length)
for (( f=0;f<$getFamiliesArrayLength;f++)); do
        familyNameMenu=$(echo "$getFamiliesPlanPurchase" | grep familyBundles | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.familyBundles['$f'] | .name' | sed -r 's/"//g')
        familyIdMenu=$(echo "$getFamiliesPlanPurchase" | grep familyBundles | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.familyBundles['$f'] | .id' | sed -r 's/"//g')
        g=$((f+1))
        if [ $g -lt 10 ];then space=" ";else space="";fi
        echo -e "$g$space - [FamilyID = \033[1;32m$familyIdMenu\e\033[0m`tput setaf 2`]`tput setaf 2` $familyNameMenu"
done
echo "===================================================== `tput sgr0`"
echo -n -e "\n\nEnter Family ID [If you want to, clean Scrollback on putty] > "
read familyID
if [ -z "$familyID" ]; then
        echo -e "\nWhat? "
        echo -n -e "\n\nEnter Family ID [If you want to, clean Scrollback on putty] > "
        read familyID
fi

areThereDuplicatedChildOffers=$(echo "$getFamiliesPlanPurchase" | grep familyBundles | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.familyBundles[] | select(.id == "'"$familyID"'") | .childOffers' | jq length | wc -l)
if [ $areThereDuplicatedChildOffers -gt 1 ];then
        echo -e "\n`tput setaf 1`$familyID Family ID is\033[1m duplicated`tput sgr0``tput setaf 1`. Ask SV administrator to amend the catalog\n`tput sgr0`"
        exit
fi

echo -e "\n`tput setaf 2`=====================================================\n PLANPURCHASE MENU`tput setaf 3`\ncurrentPlanPurchaseName =  \e\033[0;93m$currentPlanPurchaseName [$currentPlanPurchaseID\e\033[0m`tput setaf 3`] $currentPlanPurchaseStr1 $currentPlanPurchaseStr2 $currentPlanPurchaseStr3 $currentPlanPurchaseStr4 $currentPlanPurchaseStr5 $currentPlanPurchaseStr6\n`tput setaf 2`"
getChildOffersArrayLength=$(echo "$getFamiliesPlanPurchase" | grep familyBundles | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.familyBundles[] | select(.id == "'"$familyID"'") | .childOffers' | jq length)
for (( i=0;i<$getChildOffersArrayLength;i++)); do
        planNameOrig=$(echo "$getFamiliesPlanPurchase" | grep familyBundles | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.familyBundles[] | select(.id == "'"$familyID"'") | .childOffers['$i'] | .planNameOrig' | sed -r 's/"//g')
        planId=$(echo "$getFamiliesPlanPurchase" | grep familyBundles | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.familyBundles[] | select(.id == "'"$familyID"'") | .childOffers['$i'] | .planId' | sed -r 's/"//g')
        planPrice=$(echo "$getFamiliesPlanPurchase" | grep familyBundles | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.familyBundles[] | select(.id == "'"$familyID"'") | .childOffers['$i'] | .planPrice' | sed -r 's/"//g')
        planCurrency=$(echo "$getFamiliesPlanPurchase" | grep familyBundles | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.familyBundles[] | select(.id == "'"$familyID"'") | .childOffers['$i'] | .planCurrency' | sed -r 's/"//g')
        planAvailability=$(echo "$getFamiliesPlanPurchase" | grep familyBundles | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.familyBundles[] | select(.id == "'"$familyID"'") | .childOffers['$i'] | .planAvailability' | sed -r 's/"//g')
        j=$((i+1))
        if [ "$planAvailability" == "Unavailable" ];then
                echo -e "$j - $planNameOrig [ProductID = \033[1;32m$planId\e\033[0m`tput setaf 2`] ($""$planPrice $planCurrency] \033[97;41;1m$planAvailability\033[m`tput setaf 2`"
        else
                echo -e "$j - $planNameOrig [ProductID = \033[1;32m$planId\e\033[0m`tput setaf 2`] ($""$planPrice $planCurrency] \033[97;42;1m$planAvailability\033[m`tput setaf 2`"
        fi
done

echo "===================================================== `tput sgr0`"
echo -n -e "\n\nEnter product ID [Raw TMF620 APIM response is above on top] > "
read prodID
if [ -z "$prodID" ]; then
        echo -e "\nWhat?"
        echo -n -e "\n\nEnter product ID [Raw TMF620 APIM response is above on top] > "
        read prodID
fi
if [ "$TMF620Level" == "L4" ];then
        productNameTitle=$(echo "$getFamiliesPlanPurchase" | grep familyBundles | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.familyBundles[] | select(.id == "'"$familyID"'") | .childOffers[] | .planNameOrig' | cut -d'"' -f2)
        discountPrice=$(echo "$getFamiliesPlanPurchase" | grep familyBundles | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.familyBundles[] | select(.id == "'"$familyID"'") | .childOffers[] | .discountPrice' | cut -d'"' -f2)
        discountTerm=$(echo "$getFamiliesPlanPurchase" | grep familyBundles | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.familyBundles[] | select(.id == "'"$familyID"'") | .childOffers[] | .discountTerm' | cut -d'"' -f2)
        planCurrency=$(echo "$getFamiliesPlanPurchase" | grep familyBundles | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.familyBundles[] | select(.id == "'"$familyID"'") | .childOffers[] | .planCurrency' | cut -d'"' -f2)
        planPrice=$(echo "$getFamiliesPlanPurchase" | grep familyBundles | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.familyBundles[] | select(.id == "'"$familyID"'") | .childOffers[] | .planPrice' | cut -d'"' -f2)
        productName=$(echo "$productNameTitle" |sed -e 's/ /%20/g' )
        prodOfferItems=$(curl -X GET -H "tenant: production" -H "" "http://localhost:8286/serviceRequest?msisdn=$msisdn&context=APIM_$SVEnv""_TMF620_GetProdOfferItems""_$TMF620Level""&tenant=production&APIMSubscriptionKey=$SubKey&customerID=$customerId&productCatalogID=$prodCatId&baseProductInstanceId=$baseProdInsId&productID=$prodID&productName=$productName&parentFamilyKey=$parentFamilyKey")
elif [ "$TMF620Level" == "L3" ];then
        productNameTitle=$(echo "$getFamiliesPlanPurchase" | grep familyBundles | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.familyBundles[] | select(.id == "'"$familyID"'") | .childOffers[] |  select(.planId == "'"$prodID"'") | .planNameOrig' | cut -d'"' -f2)
        discountPrice=$(echo "$getFamiliesPlanPurchase" | grep familyBundles | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.familyBundles[] | select(.id == "'"$familyID"'") | .childOffers[] |  select(.planId == "'"$prodID"'") | .discountPrice' | cut -d'"' -f2)
        discountTerm=$(echo "$getFamiliesPlanPurchase" | grep familyBundles | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.familyBundles[] | select(.id == "'"$familyID"'") | .childOffers[] |  select(.planId == "'"$prodID"'") | .discountTerm' | cut -d'"' -f2)
        planCurrency=$(echo "$getFamiliesPlanPurchase" | grep familyBundles | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.familyBundles[] | select(.id == "'"$familyID"'") | .childOffers[] |  select(.planId == "'"$prodID"'") | .planCurrency' | cut -d'"' -f2)
        planPrice=$(echo "$getFamiliesPlanPurchase" | grep familyBundles | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.familyBundles[] | select(.id == "'"$familyID"'") | .childOffers[] |  select(.planId == "'"$prodID"'") | .planPrice' | cut -d'"' -f2)
        productName=$(echo "$productNameTitle" |sed -e 's/ /%20/g' )
        prodOfferItems=$(curl -X GET -H "tenant: production" -H "" "http://localhost:8286/serviceRequest?msisdn=$msisdn&context=APIM_$SVEnv""_TMF620_GetProdOfferItems""_$TMF620Level""&tenant=production&APIMSubscriptionKey=$SubKey&customerID=$customerId&productCatalogID=$prodCatId&baseProductInstanceId=$baseProdInsId&productID=$prodID&productName=$productName&familyKey=$familyKey")
fi
echo $prodOfferItems
echo -e "\n------------------------------------------------------------------------------------------------------------------------------------------------------\n                          ^\n                          |"
if [ "$TMF620Level" == "L4" ];then
        echo -e "\nTMF620 via HRG get ProdOffer Items PlanPurchase\n\n`tput setaf 2`curl -X GET -H \"tenant: production\" -H \"\" \"http://localhost:8286/serviceRequest?msisdn=$msisdn&context=APIM_$SVEnv""_TMF620_GetProdOfferItems""_$TMF620Level""&tenant=production&APIMSubscriptionKey=$SubKey&customerID=$customerId&productCatalogID=$prodCatId&baseProductInstanceId=$baseProdInsId&productID=$prodID&productName=$productName&parentFamilyKey=$parentFamilyKey&familyKey=$familyKey\"`tput sgr0`"
elif [ "$TMF620Level" == "L3" ];then
        echo -e "\nTMF620 via HRG get ProdOffer Items PlanPurchase\n\n`tput setaf 2`curl -X GET -H \"tenant: production\" -H \"\" \"http://localhost:8286/serviceRequest?msisdn=$msisdn&context=APIM_$SVEnv""_TMF620_GetProdOfferItems""_$TMF620Level""&tenant=production&APIMSubscriptionKey=$SubKey&customerID=$customerId&productCatalogID=$prodCatId&baseProductInstanceId=$baseProdInsId&productID=$prodID&productName=$productName&familyKey=$familyKey\"`tput sgr0`"
fi

# GET ITEMS TO CREATE PROD ORDER
familyName=$(echo "$getFamiliesPlanPurchase" | grep familyBundles | cut -d">" -f2 | cut -d"<" -f1 | jq '.familyBundles[] | .id,.name' | grep $familyID -A1 | tail -1 | cut -d'"' -f2)
if [ "$parentFamilyKey" == "prime" ];then
        tagVasDigiloanPlan=$(echo "$getFamiliesPlanPurchase" | grep familyBundles | cut -d">" -f2 | cut -d"<" -f1 | jq -r '.familyBundles[] | select(.id == "'"$familyID"'") | .childOffers[] | .tagVasDigiloanPlan' | cut -d'"' -f2)
fi
rootProdSpecID=$(echo "$prodOfferItems" | grep ootProdSpecID | cut -d">" -f2 | cut -d"<" -f1)
rootProdSpecName=$(echo "$prodOfferItems" | grep ootProdSpecName | cut -d">" -f2 | cut -d"<" -f1)
rootBundleID=$(echo "$prodOfferItems" |  grep rootBundleID | cut -d">" -f2 | cut -d"<" -f1)
rootBundleName=$(echo "$prodOfferItems" |  grep rootBundleName | cut -d">" -f2 | cut -d"<" -f1)
parentFamilyID=$(echo "$prodOfferItems" |  grep parentFamilyBundleID | cut -d">" -f2 | cut -d"<" -f1)
parentFamilyName=$(echo "$prodOfferItems" |  grep parentFamilyBundleName | cut -d">" -f2 | cut -d"<" -f1)
autoRenewalID=$(echo "$prodOfferItems" | grep utoRenewalID | cut -d">" -f2 | cut -d"<" -f1)
digiloanProdSpecFound=$(echo "$prodOfferItems" | grep digiloanProdSpecFound | cut -d">" -f2 | cut -d"<" -f1)
realtimeDiscountFound=$(echo "$prodOfferItems" | grep realtimeDiscountFound | cut -d">" -f2 | cut -d"<" -f1)
productOfferingPriceFound=$(echo "$prodOfferItems" | grep productOfferingPriceFound | cut -d">" -f2 | cut -d"<" -f1)



if [ ! -z "$currentPlanPurchaseID" ];then
        removeJson=$(echo ",
                                                                {
                                                                    \"product\": {
                                                                        \"op\": \"remove\",
                                                                        \"productOffering\": {
                                                                            \"id\": \"$currentParentFamilyPlanPurchaseID\"
                                                                        },
                                                                        \"productRelationship\": [{
                                                                            \"product\": {
                                                                                \"op\": \"remove\",
                                                                                \"productOffering\": {
                                                                                    \"id\": \"$currentFamilyPlanPurchaseID\"
                                                                                },
                                                                                \"productRelationship\": [{
                                                                                    \"product\": {
                                                                                        \"op\": \"remove\",
                                                                                        \"productOffering\": {
                                                                                            \"id\": \"$currentPlanPurchaseID\"
                                                                                        }
                                                                                    }
                                                                                }]
                                                                            }
                                                                        }]
                                                                    }
                                                            }")
fi
if [ -z "$currentPlanPurchaseID" ];then
        currentPlanPurchaseID="''"
fi


if [ "$parentFamilyKey" == "prime" ] && [ "$digiloanProdSpecFound" == "present" ];then
        withPriceJson="                                                                                                        },
                                                                                                        {
                                                                                                            \"id\": \"${prodID}-2000217\",
                                                                                                            \"name\": \"${productNameTitle}-Realtime Discount Feature\",
                                                                                                            \"productSpecCharacteristic\": [
                                                                                                                {
                                                                                                                    \"name\": \"Offer Reference\",
                                                                                                                    \"productSpecCharacteristicValue\": {
                                                                                                                        \"value\": \"$prodID\"
                                                                                                                    }
                                                                                                                },
                                                                                                                {
                                                                                                                    \"name\": \"Periodic Discount\",
                                                                                                                    \"productSpecCharacteristicValue\": {
                                                                                                                        \"value\": \"$discountPrice\"
                                                                                                                    }
                                                                                                                },
                                                                                                                {
                                                                                                                    \"name\": \"Periodic Discount Type\",
                                                                                                                    \"productSpecCharacteristicValue\": {
                                                                                                                        \"value\": \"Fixed\"
                                                                                                                    }
                                                                                                                },
                                                                                                                {
                                                                                                                    \"name\": \"Discount Term\",
                                                                                                                    \"productSpecCharacteristicValue\": {
                                                                                                                        \"value\": \"$discountTerm\"
                                                                                                                    }
                                                                                                                }
                                                                                                         ]
                                                                                                    },
                                                                                                    {
                                                                                                        \"id\": \"$prodID-2000126\",
                                                                                                        \"name\": \"$productName-IMP.DigiLoan\",
                                                                                                        \"productSpecCharacteristic\": [
                                                                                                            {
                                                                                                                \"name\": \"Loan Opted?\",
                                                                                                                \"productSpecCharacteristicValue\":
                                                                                                                {
                                                                                                                    \"value\": \"$tagVasDigiloanPlan\"
                                                                                                                }
                                                                                                            }
                                                                                                        ]
                                                                                                }"
elif [ "$digiloanProdSpecFound" == "absent" ];then
        noDigiloanPlan="--- No Digiloan Plan ---"
elif [ "$parentFamilyKey" == "prime" ] && [ "$realtimeDiscountFound" == "present" ];then
        withPriceJson="                                                                                                        },
                                                                                                        {
                                                                                                            \"id\": \"${prodID}-2000217\",
                                                                                                            \"name\": \"${productNameTitle}-Realtime Discount Feature\",
                                                                                                            \"productSpecCharacteristic\": [
                                                                                                                {
                                                                                                                    \"name\": \"Offer Reference\",
                                                                                                                    \"productSpecCharacteristicValue\": {
                                                                                                                        \"value\": \"$prodID\"
                                                                                                                    }
                                                                                                                },
                                                                                                                {
                                                                                                                    \"name\": \"Periodic Discount\",
                                                                                                                    \"productSpecCharacteristicValue\": {
                                                                                                                        \"value\": \"$discountPrice\"
                                                                                                                    }
                                                                                                                },
                                                                                                                {
                                                                                                                    \"name\": \"Periodic Discount Type\",
                                                                                                                    \"productSpecCharacteristicValue\": {
                                                                                                                        \"value\": \"Fixed\"
                                                                                                                    }
                                                                                                                },
                                                                                                                {
                                                                                                                    \"name\": \"Discount Term\",
                                                                                                                    \"productSpecCharacteristicValue\": {
                                                                                                                        \"value\": \"$discountTerm\"
                                                                                                                    }
                                                                                                                }
                                                                                                         ]
                                                                                                   }"
elif [ "$realtimeDiscountFound" == "absent" ];then
        noPriceTitle="--- No Price ---"
else
        withPriceJson="}"
fi

if [ "$productOfferingPriceFound" == "present" ];then
        productOfferingPriceJson="
        \"orderCharacteristic\": [
            {
                \"name\": \"OrderUpfrontPrice\",
                \"value\": \"$planCurrency|$planPrice\"
            }
        ],"
else
        withOrderUpfrontPrice="---- No OrderUpfrontPrice --"
fi

echo -e "\n`tput setaf 3`############################################
aNumber=$msisdn
customerId=$customerId
productCatalogID=$prodCatId
productCatalogName=$prodCatName
familyID=$familyID
familyName=$familyName
productID=$prodID
productName=$productNameTitle
rootBundleID=$rootBundleID
rootBundleName=$rootBundleName"
if [ "$TMF620Level" == "L4" ];then
        echo -e "parentFamilyID=$parentFamilyID
parentFamilyName=$parentFamilyName
rootProdSpecID=$rootProdSpecID
rootProdSpecName=$rootProdSpecName"
fi
echo -e "currentParentFamilyPlanPurchaseID=$currentParentFamilyPlanPurchaseID
currentFamilyPlanPurchaseID=$currentFamilyPlanPurchaseID
currentPlanPurchaseID=$currentPlanPurchaseID
autoRenewalID=$autoRenewalID
realtimeDiscountFound=$realtimeDiscountFound
digiloanProdSpecFound=$digiloanProdSpecFound
productOfferingPriceFound=$productOfferingPriceFound"

if [ "$parentFamilyKey" == "prime" ];then
        echo -e "discountPrice=$discountPrice
discountTerm=$discountTerm"
        if [ $tagVasDigiloanPlan == "No" ] && [ $optionParentFamily == "digiloanplan" ];then
                echo -e "tagVasDigiloanPlan=\033[97;41;1m$tagVasDigiloanPlan\033[m"
        else
                if [ $optionParentFamily != "digiloanplan" ];then
                        echo -e "tagVasDigiloanPlan=$tagVasDigiloanPlan\033[97;45;1m Note: \033[mVAS_DIGILOAN_PLAN\033[97;45;1m might be in the catalog but you didnt select Digiloan Plan from menu\033[m"
                else
                        echo -e "tagVasDigiloanPlan=$tagVasDigiloanPlan"
                fi
        fi
fi
echo -e "`tput setaf 3`planPrice=$planPrice
planCurrency=$planCurrency"
echo -e "`tput setaf 3`############################################ `tput sgr0`\n"
if [ "$tagVasDigiloanPlan" == "No" ] && [ "$optionParentFamily" == "digiloanplan" ];then
        echo -e "\n\n\033[97;41;1m There is an oustanding Digi Loan debt pending. You can get Digiloan Plans until 100% of repayment is complete \033[m\n\n"
        exit
fi

if [ "$familyKey" == "fnf" ];then
        if [ -z "$removeJson" ];then
                echo -e "\n\n\033[97;44;1m TMF622 Create Product Order PlanPurchase L3 POST BODY \033[m\n\n"
        else
                echo -e "\n\n\033[97;44;1m TMF622 Remove L4 And Create L3 Product Order PlanPurchase  POST BODY \033[m\n\n"
        fi

        echo "
{
        \"reason\": \"Upgrade\",
        \"@type\": \"Alter Product Options\",
        \"channel\": [{
                        \"name\": \"USSD\",
                        \"id\": \"17\"
        }],
        \"relatedParty\": [{
                        \"id\": \"$customerId\",
                        \"@referredType\": \"customer\"
        }],$productOfferingPriceJson
        \"productOrderItem\": [{
                        \"action\": \"replace\",
                        \"product\": {
                                        \"id\": \"AAAAAA11111\",
                                        \"op\": \"replace\",
                                        \"productOffering\": {
                                                        \"id\": \"$prodCatId\",
                                                        \"name\": \"$prodCatName\"
                                        },
                                        \"realizingService\": [{
                                                        \"@type\": \"Wireless Service\",
                                                        \"name\": \"$msisdn\"
                                        }],
                                        \"productSpecification\": [{
                                                        \"id\": \"$rootProdSpecID\",
                                                        \"productSpecCharacteristic\": [{
                                                                        \"name\": \"SubscriptionType\",
                                                                        \"productSpecCharacteristicValue\": {
                                                                                        \"value\": \"PREPAID\"
                                                                        }
                                                        }]
                                        }],
                                        \"productRelationship\": [{
                                                \"product\": {
                                                                \"op\": \"replace\",
                                                                \"productOffering\": {
                                                                                \"id\": \"$rootBundleID\"
                                                                },
                                                                \"productRelationship\": [{
                                                                        \"product\": {
                                                                                \"op\": \"add\",
                                                                                \"productOffering\": {
                                                                                                \"id\": \"$familyID\",
                                                                                                \"name\": \"$familyName\"
                                                                                },
                                                                                \"productRelationship\": [{
                                                                                                \"product\": {
                                                                                                        \"op\": \"add\",
                                                                                                        \"productOffering\": {
                                                                                                                        \"id\": \"$prodID\",
                                                                                                                        \"name\": \"$productNameTitle\"
                                                                                                        },
                                                                                                        \"productSpecification\": [{
                                                                                                                        \"id\": \"$autoRenewalID\",
                                                                                                                        \"name\": \"$productNameTitle-Auto Renewal\",
                                                                                                                        \"productSpecCharacteristic\": [{
                                                                                                                                \"name\": \"Opt Out Window ( in hrs )\",
                                                                                                                                \"productSpecCharacteristicValue\": {
                                                                                                                                        \"value\": \"24\"
                                                                                                                                }
                                                                                                                                },
                                                                                                                                {
                                                                                                                                        \"name\": \"Enabled\",
                                                                                                                                        \"productSpecCharacteristicValue\": {
                                                                                                                                                        \"value\": \"Yes\"
                                                                                                                                         }
                                                                                                                                }
                                                                                                                        ]
                                                                                                                }
                                                                                                        ]
                                                                                                }
                                                                                        }
                                                                                ]
                                                                        }
                                                                }
                                                        ]
                                                }
                                        }
                                ]
                        }
                }
        ]
}
"

elif [ "$parentFamilyKey" == "prime" ] || [ "$parentFamilyKey" == "stay" ];then

        if [ -z "$removeJson" ];then
                echo -e "\n\n\033[97;44;1m TMF622 Create Product Order PlanPurchase $noPriceTitle $withOrderUpfrontPrice $noDigiloanPlan POST BODY \033[m\n\n"
        else
                echo -e "\n\n\033[97;44;1m TMF622 Remove And Create Product Order PlanPurchase $noPriceTitle $withOrderUpfrontPrice $noDigiloanPlan POST BODY \033[m\n\n"
        fi


        echo "
{
        \"reason\": \"Upgrade\",
        \"@type\": \"Alter Product Options\",
        \"channel\": [{
                \"name\": \"USSD\",
                \"id\": \"17\"
        }],
        \"relatedParty\": [{
                \"id\": \"$customerId\",
                \"@referredType\": \"customer\"
        }],$productOfferingPriceJson
        \"productOrderItem\": [{
                \"action\": \"replace\",
                \"product\": {
                        \"id\": \"AAAAAA11111\",
                        \"op\": \"replace\",
                        \"productOffering\": {
                                \"id\": \"$prodCatId\",
                                \"name\": \"$prodCatName\"
                        },
                        \"realizingService\": [{
                                \"@type\": \"Wireless Service\",
                                \"name\": \"$msisdn\"
                        }],
                        \"productSpecification\": [{
                                \"id\": \"$rootProdSpecID\",
                                \"productSpecCharacteristic\": [{
                                        \"name\": \"SubscriptionType\",
                                        \"productSpecCharacteristicValue\": {
                                                \"value\": \"PREPAID\"
                                        }
                                }]
                        }],
                        \"productRelationship\": [{
                                \"product\": {
                                        \"op\": \"replace\",
                                        \"productOffering\": {
                                                \"id\": \"$rootBundleID\"
                                        },
                                        \"productRelationship\": [{
                                                \"product\": {
                                                        \"op\": \"add\",
                                                        \"productOffering\": {
                                                                \"id\": \"$parentFamilyID\",
                                                                \"name\": \"$parentFamilyName\"
                                                        },
                                                        \"productRelationship\": [{
                                                                        \"product\": {
                                                                                \"op\": \"add\",
                                                                                \"productOffering\": {
                                                                                        \"id\": \"$familyID\",
                                                                                        \"name\": \"$familyName\"
                                                                                },
                                                                                \"productRelationship\": [{
                                                                                        \"product\": {
                                                                                                \"op\": \"add\",
                                                                                                \"productOffering\": {
                                                                                                        \"id\": \"$prodID\",
                                                                                                        \"name\": \"$productNameTitle\"
                                                                                                },
                                                                                                \"productSpecification\": [{
                                                                                                        \"id\": \"$autoRenewalID\",
                                                                                                        \"name\": \"$productNameTitle-Auto Renewal\",
                                                                                                        \"productSpecCharacteristic\": [{
                                                                                                                        \"name\": \"Opt Out Window ( in hrs )\",
                                                                                                                        \"productSpecCharacteristicValue\": {
                                                                                                                                \"value\": \"24\"
                                                                                                                        }
                                                                                                                },
                                                                                                                {
                                                                                                                        \"name\": \"Enabled\",
                                                                                                                        \"productSpecCharacteristicValue\": {
                                                                                                                                \"value\": \"Yes\"
                                                                                                                         }
                                                                                                                }
                                                                                                            ]
                                                                                $withPriceJson
                                                ]
                                        }}]
                                    }
                                }]
                            }
                        }$removeJson
                    ]
                }
            }]
        }
    }]
}
"
fi

echo -e "\n------------------------------------------------------------------------------------------------------------------------------------------------------\n                          ^\n                          |"
prodCatNameCurl=$(echo "$prodCatName" | sed -e 's/ /%20/g')
productCatalogNameCurl=$(echo "$productCatalogName" | sed -e 's/ /%20/g')
rootBundleNameCurl=$(echo "$rootBundleName" | sed -e 's/ /%20/g')
parentFamilyNameCurl=$(echo "$parentFamilyName" | sed -e 's/ /%20/g')
familyNameCurl=$(echo "$familyName" | sed -e 's/ /%20/g')
if [ "$parentFamilyKey" == "prime" ];then
        if [ -z "$removeJson" ];then
                echo -e "\n\n\033[97;44;1m TMF622 Create Product Order PlanPurchase $noDigiloanPlan VIA HRG \033[m\n\n"
        else
                echo -e "\n\n\033[97;44;1m TMF622 Remove And Create Product Order PlanPurchase $noDigiloanPlan VIA HRG \033[m\n\n"
        fi
        if [ "$digiloanProdSpecFound" == "present" ];then
                if [ "$currentPlanPurchaseID" != "null" ];then
                        echo "`tput setaf 2`curl -X GET -H \"tenant: production\"  \"http://localhost:8286/serviceRequest?aNumber=$msisdn&context=APIM_$SVEnv""_TMF622_ReplaceProductOrder""_$TMF620Level""&tenant=production&APIMSubscriptionKey=$SubKey&currentPlanPurchaseID=$currentPlanPurchaseID&customerID=$customerId&callReference=1111AAA&productCatalogID=$prodCatId&productCatalogName=$prodCatNameCurl&rootProdSpecID=$rootProdSpecID&rootBundleID=$rootBundleID&parentFamilyID=$parentFamilyID&parentFamilyName=$parentFamilyNameCurl&familyID=$familyID&familyName=$familyNameCurl&productID=$prodID&productName=$productName&autoRenewalID=$autoRenewalID&currentFamilyPlanPurchaseID=$currentFamilyPlanPurchaseID&currentParentFamilyPlanPurchaseID=$currentParentFamilyPlanPurchaseID&discountTerm=$discountTerm&discountPrice=$discountPricetag&VasDigiloanPlan=$tagVasDigiloanPlan\"`tput sgr0`"
                else
                        echo "`tput setaf 2`curl -X GET -H \"tenant: production\"  \"http://localhost:8286/serviceRequest?aNumber=$msisdn&context=APIM_$SVEnv""_TMF622_CreateProductOrder""_$TMF620Level""&tenant=production&APIMSubscriptionKey=$SubKey&customerID=$customerId&callReference=1111AAA&productCatalogID=$prodCatId&productCatalogName=$prodCatNameCurl&rootProdSpecID=$rootProdSpecID&rootProdSpecName=$rootProdSpecID&rootBundleID=$rootBundleID&parentFamilyID=$parentFamilyID&parentFamilyName=$parentFamilyNameCurl&familyID=$familyID&familyName=$familyNameCurl&productID=$prodID&productName=$productName&autoRenewalID=$autoRenewalID&discountTerm=$discountTerm&discountPrice=$discountPrice&tagVasDigiloanPlan=$tagVasDigiloanPlan\"`tput sgr0`"
                fi
        elif [ "$digiloanProdSpecFound" == "absent" ];then
                if [ "$currentPlanPurchaseID" != "null" ];then
                        echo "`tput setaf 2`curl -X GET -H \"tenant: production\"  \"http://localhost:8286/serviceRequest?aNumber=$msisdn&context=APIM_$SVEnv""_TMF622_ReplaceProductOrder_NoDigiloanPlan""_$TMF620Level""&tenant=production&APIMSubscriptionKey=$SubKey&currentPlanPurchaseID=$currentPlanPurchaseID&customerID=$customerId&callReference=1111AAA&productCatalogID=$prodCatId&productCatalogName=$prodCatNameCurl&rootProdSpecID=$rootProdSpecID&rootBundleID=$rootBundleID&parentFamilyID=$parentFamilyID&parentFamilyName=$parentFamilyNameCurl&familyID=$familyID&familyName=$familyNameCurl&productID=$prodID&productName=$productName&autoRenewalID=$autoRenewalID&currentFamilyPlanPurchaseID=$currentFamilyPlanPurchaseID&currentParentFamilyPlanPurchaseID=$currentParentFamilyPlanPurchaseID&discountTerm=$discountTerm&discountPrice=$discountPrice\"`tput sgr0`"
                else
                        echo "`tput setaf 2`curl -X GET -H \"tenant: production\"  \"http://localhost:8286/serviceRequest?aNumber=$msisdn&context=APIM_$SVEnv""_TMF622_CreateProductOrder_NoDigiloanPlan""_$TMF620Level""&tenant=production&APIMSubscriptionKey=$SubKey&customerID=$customerId&callReference=1111AAA&productCatalogID=$prodCatId&productCatalogName=$prodCatNameCurl&rootProdSpecID=$rootProdSpecID&rootProdSpecName=$rootProdSpecID&rootBundleID=$rootBundleID&parentFamilyID=$parentFamilyID&parentFamilyName=$parentFamilyNameCurl&familyID=$familyID&familyName=$familyNameCurl&productID=$prodID&productName=$productName&autoRenewalID=$autoRenewalID&discountTerm=$discountTerm&discountPrice=$discountPrice\"`tput sgr0`"
                fi
        fi
elif [ "$parentFamilyKey" == "stay" ];then
        if [ -z "$removeJson" ];then
                echo -e "\n\n\033[97;44;1m TMF622 Create Product Order PlanPurchase $noPriceTitle VIA HRG \033[m\n\n"
        else
                echo -e "\n\n\033[97;44;1m TMF622 Remove And Create Product Order PlanPurchase $noPriceTitle VIA HRG \033[m\n\n"
        fi
        if [ "$currentPlanPurchaseID" != "null" ];then
                echo "`tput setaf 2`curl -X GET -H \"tenant: production\"  \"http://localhost:8286/serviceRequest?aNumber=$msisdn&context=APIM_$SVEnv""_TMF622_ReplaceProductOrder_NoPrice""_$TMF620Level""&tenant=production&APIMSubscriptionKey=$SubKey&currentPlanPurchaseID=$currentPlanPurchaseID&customerID=$customerId&callReference=1111AAA&productCatalogID=$prodCatId&productCatalogName=$prodCatNameCurl&rootProdSpecID=$rootProdSpecID&rootBundleID=$rootBundleID&parentFamilyID=$parentFamilyID&parentFamilyName=$parentFamilyNameCurl&familyID=$familyID&familyName=$familyNameCurl&productID=$prodID&productName=$productName&autoRenewalID=$autoRenewalID&currentFamilyPlanPurchaseID=$currentFamilyPlanPurchaseID&currentParentFamilyPlanPurchaseID=$currentParentFamilyPlanPurchaseID\"`tput sgr0`"
        else
                echo "`tput setaf 2`curl -X GET -H \"tenant: production\"  \"http://localhost:8286/serviceRequest?aNumber=$msisdn&context=APIM_$SVEnv""_TMF622_CreateProductOrder_NoPrice""_$TMF620Level""&tenant=production&APIMSubscriptionKey=$SubKey&customerID=$customerId&callReference=1111AAA&productCatalogID=$prodCatId&productCatalogName=$prodCatNameCurl&rootProdSpecID=$rootProdSpecID&rootProdSpecName=$rootProdSpecID&rootBundleID=$rootBundleID&parentFamilyID=$parentFamilyID&parentFamilyName=$parentFamilyNameCurl&familyID=$familyID&familyName=$familyNameCurl&productID=$prodID&productName=$productName&autoRenewalID=$autoRenewalID\"`tput sgr0`"
        fi
elif [ "$familyKey" == "fnf" ];then
        if [ -z "$removeJson" ];then
                echo -e "\n\n\033[97;44;1m TMF622 Create Product Order PlanPurchase L3 VIA HRG \033[m\n\n"
        else
                echo -e "\n\n\033[97;44;1m TMF622 Remove L4 And Create L3 Product Order PlanPurchase VIA HRG \033[m\n\n"
        fi
        if [ "$currentPlanPurchaseID" != "null" ];then
                echo "`tput setaf 2`curl -X GET -H \"tenant: production\"  \"http://localhost:8286/serviceRequest?aNumber=$msisdn&context=APIM_$SVEnv""_TMF622_ReplaceL4ToL3ProductOrder_""_$TMF620Level""&tenant=production&APIMSubscriptionKey=$SubKey&currentPlanPurchaseID=$currentPlanPurchaseID&customerID=$customerId&callReference=1111AAA&productCatalogID=$prodCatId&productCatalogName=$prodCatNameCurl&rootProdSpecID=$rootProdSpecID&rootBundleID=$rootBundleID&parentFamilyID=$parentFamilyID&familyID=$familyID&familyName=$familyNameCurl&productID=$prodID&productName=$productName&autoRenewalID=$autoRenewalID&currentFamilyPlanPurchaseID=$currentFamilyPlanPurchaseID\"`tput sgr0`"
        else
                echo "`tput setaf 2`curl -X GET -H \"tenant: production\"  \"http://localhost:8286/serviceRequest?aNumber=$msisdn&context=APIM_$SVEnv""_TMF622_CreateProductOrder_NoPrice""_$TMF620Level""&tenant=production&APIMSubscriptionKey=$SubKey&customerID=$customerId&callReference=1111AAA&productCatalogID=$prodCatId&productCatalogName=$prodCatNameCurl&rootProdSpecID=$rootProdSpecID&rootProdSpecName=$rootProdSpecID&rootBundleID=$rootBundleIDfamilyID=$familyID&familyName=$familyNameCurl&productID=$prodID&productName=$productName&autoRenewalID=$autoRenewalID\"`tput sgr0`"
        fi
fi