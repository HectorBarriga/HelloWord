#!/bin/bash
#############################################################################
# Filename:    feedfile.sh
#
# This sh script is to run End-To-End tests for Silent Roamer Telefonica
#
# Copyright (c) Tango Telecom 2017
# Author: Hector Barriga
#
# All rights reserved.
# This document contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or
# in part is expressly prohibited, except as may be specifically
# authorized by prior written agreement or permission of Tango Telecom.
##############################################################################
# version 0.1.0 - First version
# version 0.1.2 - Add multitenancy
# version 0.1.3 - Add Offer Acceptance
version=0.1.3
#
##############################################################################

#---------------------------------------------------------------
# Configurations
#---------------------------------------------------------------
scriptDir=$1
mysqlmasterhost1="IPXMIATCDB1"
mysqlmasterhost2="IPXMIATCDB2"
mysqluser="root"
mysqlpw="t3il3achum"
logstashMachine=IPXMIATCRTE_flfeed
spcmMachine=IPXMIATCSPCMext
askToEnterNewEpochTime=no

if [ -z "$1" ];then scriptDir="/tango/logs/COSTAFF/hector/sh_scripts/Autoprovisioning";fi
ncat -w 1 $mysqlmasterhost1 3306 </dev/null > $scriptDir/.tmp
if [ ! -s $scriptDir/.tmp ];then
        mysqlmasterhost=$mysqlmasterhost2
else
        mysqlmasterhost=$mysqlmasterhost1
fi
mv $scriptDir/.tmp /tango/logs/COSTAFF/trash
#subroutines

showfeedfile()
{
columnnames=$(echo "Start_Date_and_time,End_Date_and_time,DATA_RECORD_TYPE,VIOLATION,TIMEOUT,LABEL_OPC,LABEL_DPC,GTCALLING_NO,GTCALLED_NO,MS_ISDN,MSC,BACKCLG_NO,MS_RN,IMSI,SUBSCRIBER_OPERATOR_NAME,SUBSCRIBER_OPERATOR_COUNTRY,IMEI,TAC,SS_CODE,SERVICE_KEY,SUPPORT_CAMEL_PH,ER_CODE,TCAP_ABORT_CAUSE,SCCP_RETCAUSE,SERVCENT_ADDR,USRERR_REASON,NUMOF_SCCPMSG,SCCP_MSGLEN,TP_MTI,DCH,LINKSET_NAME,NUMOF_MO_SMSMSG,NUMOF_MT_SMSMSG,TP_OA_ALPHANUM,CAMEL_CAPABILITY_HANDLING,TP_OA,TP_DA,TRANS_TIME,OP_CODE,DIRECTION,DESTIN_OPERATOR_NAME,DESTIN_OPERATOR_COUNTRY,ORIG_OPERATOR_NAME,ORIG_OPERATOR_COUNTRY,VLR_NUMBER,SGSN_NUMBER,SGSN_ADDRESS,Call_Trace_Jump")
file=$(cat $1 | grep $msisdnorig)
ofile=$(cat $1 | grep $msisdnorig | paste -sd' ')
echo ""
echo "`tput setaf 5`CDR:"
echo "`tput setaf 3`$file"
echo "`tput sgr0`"
echo "`tput setaf 5`List of Fields:`tput sgr0`"
c=0
IFS=","
for i in $ofile
do
        if [ "$c" == "48" ];then
                c=0
                echo ""
        fi
        d=$((c+1))
        getColumnname=$(echo "$columnnames" | cut -d, -f"$d")
        if [ "$c" == "0" ] || [ "$c" == "1" ];then
                getEpochTime=$(echo "base=10; $i" | bc)
                getEpochTime=$(echo $((0x${i})))
                getNormalTime=$(date -d @$((getEpochTime/1000)))
                outputprintf=$(printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-1s \033[32m %-3s\n' $c. $getColumnname "=" $i "=> ")
                echo -en "$outputprintf $getNormalTime\033[1m"
                echo ""
        else
                printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-1s \033[0;39m\n' $c. $getColumnname "=" $i
        fi
        let ++c
done
echo ""
}

showfeedfileLTE()
{
columnnamesLTE=$(echo "Start_Date_and_time,End_Date_and_time,REQUEST_TYPE,IMSI,MSISDN,DIAMETER_RESULT_CODE,DIAMETER_PLMN_ID(vplmn),DIAM_ORIGIN_REALM(vplmn),DIAM_DESTINATION_REALM(hplmn)")
file=$(cat $1 | grep $msisdnorig)
ofile=$(cat $1 | grep $msisdnorig | paste -sd' ')
echo ""
echo "`tput setaf 5`LTE TDR:"
echo "`tput setaf 3`$file"
echo "`tput sgr0`"
echo "`tput setaf 5`List of Fields:`tput sgr0`"
c=0
IFS=","
for i in $ofile
do
        if [ "$c" == "48" ];then
                c=0
                echo ""
        fi
        d=$((c+1))
        getColumnname=$(echo "$columnnamesLTE" | cut -d, -f"$d")
        if [ "$c" == "0" ] || [ "$c" == "1" ];then
                getEpochTime=$(echo "base=10; $i")
                getEpochTime=$(echo $((0x${i})))
                getNormalTime=$(date -d @$((getEpochTime/1000)))
                outputprintf=$(printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-1s \033[32m %-3s\n' $c. $getColumnname "=" $i "=> ")
                echo -en "$outputprintf $getNormalTime\033[1m"
                echo ""
        else
                printf '\033[35m %-5s \033[0;39m %-30s  %-3s \033[33m %-1s \033[0;39m\n' $c. $getColumnname "=" $i
        fi
        let ++c
done
echo ""
}


showSIcdrs()
{
if [ ! -d "$scriptDir/temp" ];then
        mkdir $scriptDir/temp
fi
echo "------------------------------------------------------------------------------------------------------------------"
echo "`tput setaf 3`cp /tango/data/cdr/active_SI.cdr $scriptDir/temp/active_SI_tangoC.cdr`tput sgr0`"
echo "`tput setaf 3`scp tangoD:/tango/data/cdr/active_SI.cdr $scriptDir/temp/active_SI_tangoD.cdr`tput sgr0`"
cp /tango/data/cdr/active_SI.cdr $scriptDir/temp/active_SI_tangoC.cdr
scp tangoD:/tango/data/cdr/active_SI.cdr $scriptDir/temp/active_SI_tangoD.cdr
ls -altr $scriptDir/temp/active_SI*
sessionIdSiCdrs=$(cat  $scriptDir/temp/active_SI* | grep "$msisdnin" | tail -1 | cut -d, -f6)
timeSiCdrs=$(cat  $scriptDir/temp/active_SI* | grep "$sessionIdSiCdrs" | tail -1 | cut -d, -f5)
echo "`tput setaf 3`cat  $scriptDir/temp/active_SI* | grep $msisdnin | egrep $sessionIdSiCdrs`tput sgr0`"
sicdrs=$(cat  $scriptDir/temp/active_SI* | grep $msisdnin | egrep "$sessionIdSiCdrs")
if [ -z "$sicdrs" ];then
        echo ""
        echo "`tput setaf 1`No SI CDRs!!!`tput setaf 5` It seems CDR didnt pass the filters as per trigger_generator.cfg.
Very likely \"`tput setaf 1`Current EPOCH time in Hex\"`tput setaf 5` is too old"
        echo "HOWEVER!!! check:
    1. offset time is not OK. It means Start_Date_and_time and End_Date_and_time are TOO old (See feedfile CDRs first 2 fields)
    2 SI SD is available for VPLMN=$fvisitplmn
    3. active_SI.cdr may have rolled over, check /tango/data/cdr/ussd_si/
    4. trigger_generator.cfg is not configured properly`tput sgr0`"
        echo ""
else
        echo "$sicdrs"
fi
mv $scriptDir/temp/active_SI_tangoC.cdr $scriptDir/temp/old
mv $scriptDir/temp/active_SI_tangoD.cdr $scriptDir/temp/old
}

showUNScdrs()
{
echo "------------------------------------------------------------------------------------------------------------------"
echo "`tput setaf 3`cp /tango/data/cdr/active_UNS_SMS.cdr $scriptDir/temp/active_UNS_SMS_tangoC.cdr`tput sgr0`"
echo "`tput setaf 3`scp tangoD:/tango/data/cdr/active_UNS_SMS.cdr $scriptDir/temp/active_UNS_SMS_tangoD.cdr`tput sgr0`"
cp /tango/data/cdr/active_UNS_SMS.cdr $scriptDir/temp/active_UNS_SMS_tangoC.cdr
scp tangoD:/tango/data/cdr/active_UNS_SMS.cdr $scriptDir/temp/active_UNS_SMS_tangoD.cdr
ls -altr $scriptDir/temp/active_UNS_SMS*
echo "`tput setaf 3`cat $scriptDir/temp/active_UNS_SMS* | grep $msisdnorig | egrep \"$timeSiCdrs\"`tput sgr0`"
IsThereunsCDRs=$(cat $scriptDir/temp/active_UNS_SMS* | grep "$msisdnorig" | egrep "$timeSiCdrs" | tail -2)
unsCDRs=$(cat $scriptDir/temp/active_UNS_SMS* | grep "$msisdnorig" | egrep "$timeSiCdrs" | tail -2)
if [ -z "$IsThereunsCDRs" ];then
        echo ""
        echo -e "`tput setaf 1`No CDRs!!!`tput setaf 5` It seems NO SMS was sent to subscriber. Either:\n   1. Subscriber must have received it already\n   2. There is not Campaign configured in PMUI for VPLMN=$fvisitplmn \n   3. active_UNS_SMS.cdr file rolled over\n   4. UNS is not running or something`tput sgr0`"
        echo ""
else
        echo "$unsCDRs"
fi
}

showSOMcdrs()
{
echo "------------------------------------------------------------------------------------------------------------------"
echo "`tput setaf 3`cp /tango/data/cdr/active_SOM.cdr $scriptDir/temp/active_SOM_tangoC.cdr`tput sgr0`"
echo "`tput setaf 3`scp tangoD:/tango/data/cdr/active_SOM.cdr $scriptDir/temp/active_SOM_tangoD.cdr`tput sgr0`"
cp /tango/data/cdr/active_SOM.cdr $scriptDir/temp/active_SOM_tangoC.cdr
scp tangoD:/tango/data/cdr/active_SOM.cdr $scriptDir/temp/active_SOM_tangoD.cdr
ls -altr $scriptDir/temp/active_SOM*
echo "`tput setaf 3`cat $scriptDir/temp/active_SOM* | grep $msisdnorig | egrep \"$sessionIdSiCdrs\"`tput sgr0`"
somcdrs=$(cat $scriptDir/temp/active_SOM* | grep "$msisdnorig" | egrep "$sessionIdSiCdrs")
IsTheresomcdrs=$(cat $scriptDir/temp/active_SOM* | grep "$msisdnorig" | egrep "$sessionIdSiCdrs" | cut -d, -f1)
if [ -z $IsTheresomcdrs ];then
        echo ""
        echo "`tput setaf 1`No CDRs!!!`tput setaf 5` It seems cdr file rolled over or CDRH (SOM) process is not running or something`tput sgr0`"
        echo ""
else
        echo "$somcdrs"
fi
}

getOfferStatus()
{
namehost=$(hostname)
if [ "$mysqlmasterhost" == "$namehost" ];then
        whichmysql=$(which mysql)
        isPWinMyCnf=$(cat /etc/my.cnf | grep $mysqlpw | egrep -v grep)
        if [ ! -z "$isPWinMyCnf" ];then
                gomysql=$(echo "$whichmysql -u$mysqluser")
        else
                gomysql=$(echo "$whichmysql -u$mysqluser -p$mysqlpw")
        fi
        getOfferStatus=$(echo "select status from Offer where msisdn = '$msisdnorig';" | $gomysql promotion_$tenant | egrep -v status)
        Offer=$(echo "select * from Offer where msisdn = '$msisdnorig'\G;" | $gomysql promotion_$tenant)
else
        whichmysql=$(ssh tango@$mysqlmasterhost 'which mysql')
        getOfferStatus=$(ssh tango@$mysqlmasterhost "$whichmysql -u '$mysqluser' -p'$mysqlpw' promotion_$tenant -e 'select status from Offer where msisdn = '$msisdnorig';' | egrep -v status" 2>/dev/null)
        Offer=$(ssh tango@$mysqlmasterhost "$whichmysql -u '$mysqluser' -p'$mysqlpw' promotion_$tenant -e 'select * from Offer where msisdn = '$msisdnorig'\G;'" 2>/dev/null)
fi
}

getOfferUuidAndTenantID()
{
namehost=$(hostname)
if [ "$mysqlmasterhost" == "$namehost" ];then
        whichmysql=$(which mysql)
        isPWinMyCnf=$(cat /etc/my.cnf | grep $mysqlpw | egrep -v grep)
        if [ ! -z "$isPWinMyCnf" ];then
                gomysql=$(echo "$whichmysql -u$mysqluser")
        else
                gomysql=$(echo "$whichmysql -u$mysqluser -p$mysqlpw")
        fi
        Offer=$(echo "select * from Offer where msisdn = '$msisdnorig'\G;" | $gomysql promotion_$tenant)
        getOfferUuid=$(echo "select uuid from Offer where msisdn = '$msisdnorig';" | $gomysql promotion_$tenant | egrep -v uuid)
        getOfferTenant=$(echo "select tenantId from Offer where msisdn = '$msisdnorig';" | $gomysql promotion_$tenant | egrep -v tenantId)
else
        whichmysql=$(ssh tango@$mysqlmasterhost 'which mysql')
        Offer=$(ssh tango@$mysqlmasterhost "$whichmysql -u '$mysqluser' -p'$mysqlpw' promotion_$tenant -e 'select * from Offer where msisdn = '$msisdnorig'\G;'" 2>/dev/null)
        getOfferUuid=$(ssh tango@$mysqlmasterhost "$whichmysql -u '$mysqluser' -p'$mysqlpw' promotion_$tenant -e 'select uuid from Offer where msisdn = '$msisdnorig';' | egrep -v uuid" 2>/dev/null)
        getOfferTenant=$(ssh tango@$mysqlmasterhost "$whichmysql -u '$mysqluser' -p'$mysqlpw' promotion_$tenant -e 'select tenantId from Offer where msisdn = '$msisdnorig';' | egrep -v tenantId" 2>/dev/null)
fi
}

checkAMDB()
{
namehost=$(hostname)
if [ "$mysqlmasterhost" == "$namehost" ];then
        whichmysql=$(which mysql)
        isPWinMyCnf=$(cat /etc/my.cnf | grep $mysqlpw | egrep -v grep)
        if [ ! -z "$isPWinMyCnf" ];then
                gomysql=$(echo "$whichmysql -u$mysqluser")
        else
                gomysql=$(echo "$whichmysql -u$mysqluser -p$mysqlpw")
        fi
        echo "------------------------------------------------------------------------------------------------------------------"
        echo "`tput setaf 3`echo \"select * from activity where msisdn = '$msisdnorig'\G;\" | $gomysql activity_meter`tput sgr0`"
        subType=$(echo "select * from activity where msisdn = '$msisdnorig'\G;" | $gomysql activity_meter)
else
        whichmysql=$(ssh tango@$mysqlmasterhost 'which mysql')
        echo "`tput setaf 3`ssh tango@$mysqlmasterhost '$whichmysql -u$mysqluser -p$mysqlpw activity_meter -e \"select * from activity where msisdn = '$msisdnorig'\G;\"'`tput sgr0`"
        subType=$(ssh tango@$mysqlmasterhost "$whichmysql -u '$mysqluser' -p'$mysqlpw' activity_meter -e 'select * from activity where msisdn = '$msisdnorig'\G;'" 2>/dev/null)
fi
echo "$subType"
echo "------------------------------------------------------------------------------------------------------------------"
}


checkOfferPromotionDB()
{
namehost=$(hostname)
if [ "$mysqlmasterhost" == "$namehost" ];then
        whichmysql=$(which mysql)
        isPWinMyCnf=$(cat /etc/my.cnf | grep $mysqlpw | egrep -v grep)
        if [ ! -z "$isPWinMyCnf" ];then
                gomysql=$(echo "$whichmysql -u$mysqluser")
        else
                gomysql=$(echo "$whichmysql -u$mysqluser -p$mysqlpw")
        fi
        echo "------------------------------------------------------------------------------------------------------------------"
        getOfferStatus=$(echo "select status from Offer where msisdn = '$msisdnorig';" | $gomysql promotion_$tenant | egrep -v status)
        echo "`tput setaf 3`echo \"select * from Offer where msisdn = '$msisdnorig'\G;\" | $gomysql promotion_$tenant`tput sgr0`"
        Offer=$(echo "select * from Offer where msisdn = '$msisdnorig'\G;" | $gomysql promotion_$tenant)
else
        whichmysql=$(ssh tango@$mysqlmasterhost 'which mysql')
        getOfferStatus=$(ssh tango@$mysqlmasterhost "$whichmysql -u '$mysqluser' -p'$mysqlpw' promotion_$tenant -e 'select status from Offer where msisdn = '$msisdnorig';' | egrep -v status" 2>/dev/null)
        echo "`tput setaf 3`ssh tango@$mysqlmasterhost '$whichmysql -u$mysqluser -p$mysqlpw promotion_$tenant -e \"select * from Offer where msisdn = '$msisdnorig'\G;\"'`tput sgr0`"
        Offer=$(ssh tango@$mysqlmasterhost "$whichmysql -u '$mysqluser' -p'$mysqlpw' promotion_$tenant -e 'select * from Offer where msisdn = '$msisdnorig'\G;'" 2>/dev/null)
fi
echo "$Offer"
echo "------------------------------------------------------------------------------------------------------------------"
}

# main ()
echo "------------------------------------------------------------------------------------------------------------------"
echo "`tput setaf 2`                               Welcome to \"feedfile.sh\" simulator for Telefonica
                                                version: $version             `tput sgr0`"
echo "------------------------------------------------------------------------------------------------------------------"
cd $scriptDir
echo "`tput setaf 3`Going to $scriptDir/`tput sgr0`"
echo "------------------------------------------------------------------------------------------------------------------"
ls -alrt | egrep -v feedfile
echo "------------------------------------------------------------------------------------------------------------------"
defaultfeedfile=$(ls -altr $scriptDir/ | egrep -v feedfile | egrep -v total | egrep -v "drwxr" | tail -1 | awk "{print \$9}")
echo -n "`tput setaf 3`Enter feed file [Default = $defaultfeedfile] > `tput sgr0`"
read feedfile
if [ -z $feedfile ];then
        feedfile=$defaultfeedfile
fi
if [ ! -f ./$feedfile ];then
        echo ""
        echo "`tput setaf 1`File doesnt exist!!!`tput sgr0` Nothing done, Bye"
        echo ""
else
tenant=brav1
DIAMETER_DESTINATION_REALM="724010"

iSItLTEFeedfile=$(echo "$feedfile" |  cut -c1-5 | grep eoNGN)
echo "------------------------------------------------------------------------------------------------------------------"
echo -n "`tput setaf 3`Do you wanna edit the file? [y/n] (Default n) > `tput sgr0`"
read confirm
if [ -z "$confirm" ]; then
        sleep 0
else
        if [ "$confirm" == "y" ];then
                vi $feedfile
        fi
fi
echo "------------------------------------------------------------------------------------------------------------------"
echo "`tput setaf 3`List of Silent Roamers:`tput sgr0`"
gettadigMappings=$(ssh $logstashMachine 'cat /etc/logstash/tadigMappings.csv')
cat $feedfile | while read in
do
if [ -z "$iSItLTEFeedfile" ];then
        getmsisdn=$(echo $in | cut -d"," -f10)
        getopcode=$(echo $in | cut -d"," -f39)
        if [ -z $getmsisdn ] || [ "$getmsisdn" == "_" ]; then
                part1=$(echo "MSISDN= <empty>\t\t")
        else
                part1=$(echo "MSISDN= $getmsisdn\t")
        fi
        visitcountry=$(echo $in | cut -d"," -f15)
        srcountry=$(echo "$gettadigMappings" | grep "$visitcountry" | tail -1 | rev | cut -d',' -f1 | rev)
        color=2
        if [ "$visitcountry" != "VIVO (BR)" ] && [ "$visitcountry" != "VIVO BRATC (BR)" ];then
                if [ -z "$getmsisdn" ] || [ "$getmsisdn" == "_" ];then
                        color=1
                        srcountry='[NO GOOD CDR for VIVO, SI wont be triggered]'
                fi
        fi
        if [ "$getopcode" != 2 ];then
                color=1
                srcountry='[NO GOOD OP_CODE. It is not 2, SI wont be triggered]'

        fi
        if [ -z "$srcountry" ];then
                color=1
                srcountry='[NO GOOD CDR, VISITOR COUNTRY OPERATOR is not in $logstashMachine:/etc/logstash/tadigMappings.csv. SI might be triggered but CMCG wont find an OFFER]'
        fi
        echo -e "$part1""\tSUBSCRIBER_OPERATOR_NAME=$visitcountry""\tVPLMN=`tput setaf $color`$srcountry`tput sgr0`"
else
        getmsisdn=$(echo $in | cut -d"," -f5)
        echo $in | cut -d, -f9 | awk -F'.' '{print substr($3,4,3) substr($2,4,3)}' > $scriptDir/.tmp
        getHplmn=$(cat $scriptDir/.tmp)
        if [ -z $getmsisdn ] || [ "$getmsisdn" == "_" ]; then
                part1=$(echo "MSISDN= <empty>\t\t")
        else
                part1=$(echo "MSISDN= $getmsisdn\t")
        fi
        color=2
        TDRdisplay="GOOD"
        compareHplmn1=$(cat /etc/logstash/hplmnToTenant.csv | grep "$getHplmn")
        compareHplmn2=$(cat /etc/logstash/hplmnToTenant.csv | grep "$DIAMETER_DESTINATION_REALM")
        if [ -z "$compareHplmn1" ];then
                color=1
                TDRdisplay="[NO GOOD TDR, 9th field $getHplmn is not configured in /etc/logstash/hplmnToTenant.csv. SIBB $tenant wont be triggered]"
        fi
        if [ -z "$compareHplmn2" ];then
                color=1
                TDRdisplay="[NO GOOD TDR, Your HPLMN in TDR 9th field DIAMETER_DESTINATION_REALM $DIAMETER_DESTINATION_REALM is not configured in /etc/logstash/hplmnToTenant.csv. SIBB $tenant wont be triggered]"
        fi

        if [ -z "$getmsisdn" ] || [ "$getmsisdn" == "_" ] || [ "$getHplmn" != "$DIAMETER_DESTINATION_REALM" ];then
                color=1
                TDRdisplay="[GOOD TDR but your HPLMN in DIAMETER_DESTINATION_REALM $DIAMETER_DESTINATION_REALM that you want to monitor does not match with TDR's VPLMN in 9th field $getHplmnSIBB]"
        fi
        echo -e "$part1""\tHPLMN (TDR 9th field) = $DIAMETER_DESTINATION_REALM""\t\tTENANT = $tenant""\t\tTDR = `tput setaf $color`$TDRdisplay`tput sgr0`"
fi
done

echo "------------------------------------------------------------------------------------------------------------------"
if [ -z "$iSItLTEFeedfile" ];then
        lastmsisdnin=$(cat $feedfile | head -1 | cut -d"," -f10)
else
        lastmsisdnin=$(cat $feedfile | head -1 | cut -d"," -f5)
fi

echo -n "`tput setaf 3`Enter msisdn you would like to monitor [Default = First on the list $lastmsisdnin]  = > `tput sgr0`"
read selectedmsisdn
if [ -z "$iSItLTEFeedfile" ];then
        if [ -z "$selectedmsisdn" ];then
                msisdnin=$(cat $feedfile | grep $lastmsisdnin | cut -d"," -f10 | sed 's/./&0/g' | cut -d= -f2 | sed 's/0 020403/20403/' | sed 's/.$//' | head -1)
                msisdnorig=$lastmsisdnin
        else
                msisdnin=$(cat $feedfile | grep $selectedmsisdn | cut -d"," -f10 | sed 's/./&0/g' | cut -d= -f2 | sed 's/0 020403/20403/' | sed 's/.$//' | head -1)
                msisdnorig=$selectedmsisdn
        fi
else
        if [ -z "$selectedmsisdn" ];then
                msisdnin=$(cat $feedfile | grep $lastmsisdnin | cut -d"," -f5 | sed 's/./&0/g' | cut -d= -f2 | sed 's/0 020403/20403/' | sed 's/.$//' | head -1)
                msisdnorig=$lastmsisdnin
        else
                msisdnin=$(cat $feedfile | grep $selectedmsisdn | cut -d"," -f5 | sed 's/./&0/g' | cut -d= -f2 | sed 's/0 020403/20403/' | sed 's/.$//' | head -1)
                msisdnorig=$selectedmsisdn
        fi
fi

if [ -z "$iSItLTEFeedfile" ];then
        fvisitcountry=$(cat $feedfile | grep $msisdnorig | cut -d"," -f15)
        fvisitplmnNum=$(ssh $logstashMachine 'cat /etc/logstash/tadigMappings.csv' | grep "$fvisitcountry" | wc -l)
        if [ $fvisitplmnNum -eq 1 ];then
                fvisitplmn=$(ssh $logstashMachine 'cat /etc/logstash/tadigMappings.csv' | grep "$fvisitcountry" | rev | cut -d',' -f1 | rev)
        else
                defaultfvisitplmn=$(ssh $logstashMachine 'cat /etc/logstash/tadigMappings.csv' | grep "$fvisitcountry" | tail -1 | rev | cut -d',' -f1 | rev)
                echo "----------------------"
                ssh $logstashMachine 'cat /etc/logstash/tadigMappings.csv' | grep "$fvisitcountry" | rev | cut -d',' -f1 | rev
                echo "----------------------"
                echo -n "`tput setaf 3`As seen, there are 3 tagids in $logstashMachine:/etc/logstash/tadigMappings.csv!! Please select one of them [Default = $defaultfvisitplmn]  = > `tput sgr0`"
                read fvisitplmn
        fi
else
        getHplmn=$(cat $scriptDir/.tmp)
        fvisitplmn=$(cat /etc/logstash/hplmnToTenant.csv | grep "$getHplmn" | cut -d, -f2)
fi

tenant=$(echo "$fvisitplmn" | tr '[:upper:]' '[:lower:]')
if [ "$tenant" == "bratc" ];then
        echo -e "`tput setaf 6`\n----------------------"
        echo "Logstash will convert BRATC to BRAV1. So will I convert it for monitoring purposes only. Note: I wont modify the TDR though."
        echo "----------------------"
        tenant=brav1
fi
echo ""
echo "`tput setaf 5`############################### NOTE: ####################################
# You selected `tput sgr0`$msisdnorig`tput setaf 5` to be monitored.
# You will see results only for that subscriber in particular (below).   #
# However, all GOOD CDRs from input feedfile will ALSO be processed      #
##########################################################################
`tput sgr0`"
if [ -z "$iSItLTEFeedfile" ];then
        date1=$(echo "$feedfile" | cut -d"-" -f5)
        sec1=$(echo "$date1" | rev | cut -c1-2 | rev)
        date2=$(echo "$feedfile" | cut -d"-" -f6)
        sec2=$(echo "$date2" | rev | cut -c1-2 | rev)
else
        date1=$(echo "$feedfile" | cut -d"-" -f4)
        sec1=$(echo "$date1" | rev | cut -c1-2 | rev)
        date2=$(echo "$feedfile" | cut -d"-" -f5)
        sec2=$(echo "$date2" | rev | cut -c1-2 | rev)
fi

if [[ $sec1 -eq 59 ]];then
        newdate1=$(($date1 + 41))
else
        newdate1=$(($date1 + 1))
fi
if [[ $sec2 -eq 59 ]];then
        newdate2=$(($date2 + 41))
else
        newdate2=$(($date2 + 1))
fi
anothernewdate=$(($date + 2))
prefixnewfile=$(echo "$feedfile" | rev | cut -c30- | rev)
newfeedfile=$(echo "$prefixnewfile""$newdate1""-""$newdate2")
echo "------------------------------------------------------------------------------------------------------------------"
mv $feedfile $newfeedfile
feedfile=$(echo "$newfeedfile")
echo "`tput setaf 3`Feed file is now: `tput sgr0`$feedfile"
echo ""
currentEpoch=$(date +"%s")
currentEpochmillisec=$((currentEpoch*1000))
hexCuerrentEpoch=$(echo "obase=16; $currentEpochmillisec" | bc)
if [ $askToEnterNewEpochTime = "yes" ] || [ $askToEnterNewEpochTime = "true" ]; then
        if [ -z "$iSItLTEFeedfile" ];then
                showfeedfile "$feedfile"
        else
                showfeedfileLTE "$feedfile"
        fi
        echo "--------------------------------------------------------------------------------------------------------------------------------"
        echo "`tput setaf 2`FYI : Current EPOCH time is (in Hex) = `tput sgr0` $hexCuerrentEpoch"
        echo "--------------------------------------------------------------------------------------------------------------------------------"
        echo -n "`tput setaf 3`Do you wanna re-edit it? [y/n] (Default n) > `tput sgr0`"
        read confirm
        if [ -z "$confirm" ]; then
                sleep 0
        else
                if [ "$confirm" == "y" ];then
                        vi $feedfile
                        if [ -z "$iSItLTEFeedfile" ];then
                                showfeedfile "$feedfile"
                        else
                                showfeedfileLTE "$feedfile"
                        fi
                        echo "--------------------------------------------------------------------------------------------------------------------------------"
                fi
        fi
else
        getFirstFieldEpochTime=$(cat $feedfile | grep "$msisdnorig" | grep "$homeSubCountry" | grep "$srcountry" | cut -d"," -f1)
        sed "s/$getFirstFieldEpochTime/$hexCuerrentEpoch/g" $feedfile > $scriptDir/.tmp
        mv $scriptDir/.tmp $feedfile
        echo "--------------------------------------------------------------------------------------------------------------------------------"
        echo "`tput setaf 2`FYI : Old EPOCH time was (in HEX) = `tput sgr0` $getFirstFieldEpochTime"
        echo "`tput setaf 2`FYI : New EPOCH time is (in HEX)  = `tput sgr0` $hexCuerrentEpoch"
        echo "--------------------------------------------------------------------------------------------------------------------------------"
fi
if [ -z "$iSItLTEFeedfile" ];then
        showfeedfile "$feedfile"
else
        showfeedfileLTE "$feedfile"
fi
echo "--------------------------------------------------------------------------------------------------------------------------------"

echo -n "`tput setaf 3`Do you wanna drop it in /tango/data/ingest/autoprovision/ [y/n] > `tput sgr0`"
read confirm
if [ "$confirm" == "y" ] || [ -z "$confirm" ];then
        echo "------------------------------------------------------------------------------------------------------------------"
        echo "`tput setaf 2`curl -i -X GET -H \"tenant: $tenant\" -H \"Content-Type: application/json\" -H \"Accept: application/json\"  http://$spcmMachine:8091/spcm-rest-ws/pcc/spcm/subscribers/$msisdnorig/plans`tput sgr0`"
        curl -i -X GET -H "tenant: $tenant" -H "Content-Type: application/json" -H "Accept: application/json"  http://$spcmMachine:8091/spcm-rest-ws/pcc/spcm/subscribers/$msisdnorig/plans
        getSubPlans=$(curl -i -X GET -H "tenant: $tenant" -H "Content-Type: application/json" -H "Accept: application/json" http://$spcmMachine:8091/spcm-rest-ws/pcc/spcm/subscribers/$msisdnorig/plans 2>/dev/null)
        doesSubExist=$(echo "$getSubPlans" | grep "HTTP/1.1 200" | egrep -v grep)
        if [ ! -z "$doesSubExist" ];then
                echo "------------------------------------------------------------------------------------------------------------------"
                echo -en "`tput setaf 3`\nDo you want to DELETE subscriber from SPCM manually (Via curl)? Note: ONLY If deleted, he will be provissioned. (default = y) [y/n] > `tput sgr0`"
                read rmSubSPCM
                if [ "$rmSubSPCM" == "y" ] || [ -z "$rmSubSPCM" ];then
                echo "------------------------------------------------------------------------------------------------------------------"
                        echo "`tput setaf 2`curl -i -X DELETE -H \"Content-Type: application/json\" -H \"Accept: application/json\" -H \"tenant: $tenant\" \"http://$spcmMachine:8091/spcm-rest-ws/pcc/spcm/subscribers/$msisdnorig\"`tput sgr0`"
                        curl -i -X DELETE -H "Content-Type: application/json" -H "Accept: application/json" -H "tenant: $tenant" "http://$spcmMachine:8091/spcm-rest-ws/pcc/spcm/subscribers/$msisdnorig"
                        echo -e "\n------------------------------------------------------------------------------------------------------------------"
                        echo "`tput setaf 2`curl -i -X GET -H \"tenant: $tenant\" -H \"Content-Type: application/json\" -H \"Accept: application/json\"  http://$spcmMachine:8091/spcm-rest-ws/pcc/spcm/subscribers/$msisdnorig/plans`tput sgr0`"
                        curl -i -X GET -H "tenant: $tenant" -H "Content-Type: application/json" -H "Accept: application/json"  http://$spcmMachine:8091/spcm-rest-ws/pcc/spcm/subscribers/$msisdnorig/plans
                fi
        else
                echo -e "\n------------------------------------------------------------------------------------------------------------------"
                echo -en "`tput setaf 3`\nDo you want to ADD subscriber to SPCM manually (Via curl)? Note: If added, plan will be NOT provisioned [y/n] > `tput sgr0`"
                read addSubSPCM
                if [ "$addSubSPCM" == "y" ];then
                        echo "------------------------------------------------------------------------------------------------------------------"
                        echo "`tput setaf 2`curl -i -X POST -H \"tenant: $tenant\" -H \"Content-Type: application/json\" -H \"Accept: application/json\" \"http://66.119.82.200:8091/spcm-rest-ws/pcc/spcm/subscribers/\" -d '{\"msisdn\":\"$msisdnorig\",\"imsi\":\"740000119139692\",\"alternateNotificationMsisdn\":\"\",\"paymentType\":\"postpaid\",\"class\":\"Standard\",\"locale\":\"en\",\"status\":\"active\",\"dpsEnabled\":true,\"dpsNotification\":false,\"eosNotification\":true,\"paygNotification\":true,\"imei\":\"294032949812345\",\"qosCategoryName\":\"NULL\",\"renewalDayOfMonth\":0}'`tput sgr0`"
                        curl -i -X POST -H "tenant: $tenant" -H "Content-Type: application/json" -H "Accept: application/json" "http://66.119.82.200:8091/spcm-rest-ws/pcc/spcm/subscribers/" -d '{"msisdn":"'$msisdnorig'","imsi":"740000119139692","alternateNotificationMsisdn":"","paymentType":"postpaid","class":"Standard","locale":"en","status":"active","dpsEnabled":true,"dpsNotification":false,"eosNotification":true,"paygNotification":true,"imei":"294032949812345","qosCategoryName":"NULL","renewalDayOfMonth":0}'
                        echo -e "\n------------------------------------------------------------------------------------------------------------------"
                        echo "`tput setaf 2`curl -i -X GET -H \"tenant: $tenant\" -H \"Content-Type: application/json\" -H \"Accept: application/json\"  http://$spcmMachine:8091/spcm-rest-ws/pcc/spcm/subscribers/$msisdnorig/plans`tput sgr0`"
                        curl -i -X GET -H "tenant: $tenant" -H "Content-Type: application/json" -H "Accept: application/json"  http://$spcmMachine:8091/spcm-rest-ws/pcc/spcm/subscribers/$msisdnorig/plans
                fi
        fi

        echo -e "\n------------------------------------------------------------------------------------------------------------------"
        cp $feedfile /tango/data/ingest/autoprovision/
        chmod 777 /tango/data/ingest/autoprovision/$feedfile
        echo -en "\n`tput setaf 3`Wait until LOGSTASH processes $feedfile and triggers SI API * "
        finishedprocessed="false"
        a=0
        isSICDRsReady=0;
        while [ "$isSICDRsReady" == "0" ]
        do
                if [ $a -gt 31 ];then
                        isSICDRsReady=$(grep $msisdnorig /tango/data/cdr/active_SI.cdr | wc -l)
                fi
                sleep 1
                echo -n "* "
                if [ $a -eq 30 -o $a -eq 60 -o $a -eq 120 -o $a -eq 180 -o $a -eq 240 ];then
                        echo -n "No CDRs in /tango/data/cdr/active_SI.cdr yet "
                fi
                let a++
        done
        echo -n " Done. `tput sgr0`Time = $a secs."
        echo ""
        echo "------------------------------------------------------------------------------------------------------------------`tput setaf 2`"
        echo "`tput setaf 3`ls -atlr /tango/data/ingest/autoprovision/ | grep $newfeedfile `tput sgr0`"
        ls -atlr /tango/data/ingest/autoprovision/ | grep "$newfeedfile"
        showSIcdrs
        checkAMDB
        checkOfferPromotionDB
else
        echo "Nothing done, Bye"
fi

fi