#!/bin/bash
##############################################################################
# Filename:    stop_sendmail.sh
# Revision:    $Revision: 0.1.0 $
# Author:      Hector Barriga
#
# This sh script stops enabled sendmail deamon and/or cleans up /var/spool/clientmqueue/
# Both stopping sendmail and clientmqueue clean-up can be enabled from flags options
# In order to prevent eventual CPU deterioration, it is recommended to call this script from
# a crontab job and enable:
# 1. stop enabled sendmail deamon
# 2. clientmqueue clean-up to get rid of queued system mails
#
# This sh script is mainly used for housekeeping.
# Copyright (c) Tango Telecom 2015
#
# All rights reserved.
# This document contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or
# in part is expressly prohibited, except as may be specifically
# authorized by prior written agreement or permission of Tango Telecom.
##############################################################################
# version 0.1.0 - First version
#
##############################################################################

# Flags
while getopts m:d:h option;
do
        case $option in
                m) mode=$OPTARG;;
                d) days=$OPTARG;;
                h) echo "        Usage: stop_sendmail.sh

        This sh script stops enabled sendmail deamon and/or cleans up /var/spool/clientmqueue/

        Both stopping sendmail and clientmqueue clean-up can be enabled from flags options

        Notes:  1. This script should be used as root user
                2. Use it only for Solaris Unix !!!
                3. /tango/bin/HK_purgeFiles must be deployed

        In order to prevent eventual CPU deterioration, it is recommended to call this script from
        a crontab job and enable:
                1. stop enabled sendmail deamon
                2. clientmqueue clean-up to get rid of queued system mails

        This sh script is mainly used for housekeeping.
        Copyright (c) Tango Telecom 2015

               Options:
               -m <mode>                How the script will oparate:
                                        stopsendmail      = Checks if sendmail deamon is enabled and stops it only if enabled.
                                                            It also ignores flag -d and removes all files under /var/spool/clientmqueue/
                                        cleanclientmqueue = Only cleans up /var/spool/clientmqueue/
                                                            It never stops sendmail deamon
                                                            [Define flag -d. If not, all files will be removed by default]
                                        stopcleansendmail = It both stops sendmail and clean up files under /var/spool/clientmqueue/
                                                            [Define flag -d. If not, all files will be removed by default]

               -d <days>                To keep files x days ago under /var/spool/clientmqueue/
                                       -1 = Removes all files [Default - Flag is missing]
                                        0 = Keeps files from today
                                        x = Keep files x days ago

               -h <help>                Show help

               e.g. crontab job line: 59 * * * * /tango/scripts/Generic/HouseKeeping/stop_sendmail.sh -m stopsendmail
                    It will check if sendmail deamon is enabled and stops it only if enabled.
                    It does not remove any file under /var/spool/clientmqueue/

               e.g. crontab job line: 59 * * * * /tango/scripts/Generic/HouseKeeping/stop_sendmail.sh -m cleanclientmqueue -d 7
                    It will only remove files older than 7 days under /var/spool/clientmqueue/.
                    It will never stop sendmail deamon

               e.g. crontab job line: 59 * * * * /tango/scripts/Generic/HouseKeeping/stop_sendmail.sh -m stopcleansendmail
                    It will check if sendmail deamon is enabled and stops it only if enabled
                    Since -d flag missing, it will assign -d -1 which will remove all files
               "; h="true";;
        esac
done


# Check if Solaris, running this script as root or clientmqueue exits
if ! [[ -d "/var/spool/clientmqueue/" ]] && [[ -d "/tango/bin/HK_purgeFiles" ]]&& [ "$(uname)" == "SunOS" ] && [ "$(whoami)" == "root" ];then
echo "Script can't be run due to either:
1. Server is not Solaris
2. Script is not run as root user
3. Directory /var/spool/clientmqueue/ doesn't exist
4. Purge script /tango/bin/HK_purgeFiles is not deployed
Bye"


else

# Config Parameters
LOGS="TRUE";


# Initial Arguments
timenow=$(perl -e '@d=localtime time(); printf "%4d%02d%02d %02d:%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1]')
lognow=$(perl -e '@d=localtime time(); printf "%4d-%02d-%02d\n", $d[5]+1900,$d[4]+1,$d[3]')

# Check if /tango/logs/sendmail/ directory exists. If not, create it
if ! [[ -d "/tango/logs/sendmail/" ]];then
        /bin/mkdir /tango/logs/sendmail/
fi

# SubRoutines

stop_sendmail()
{
CallCheckSendmail
if [ ! -z "$checkSendmail" ];then
        /etc/init.d/sendmail stop
        printLog "Running: /etc/init.d/sendmail stop"
        printLog "Running: pkill sendmail"
        sleep 15
        CallCheckSendmail
fi
}

CallCheckSendmail()
{
checkSendmail=$(/bin/svcs -a | grep -i mail | egrep -i online)
printLog "Running: /bin/svcs -a | grep -i mail | egrep -i online"
if [ -z "$checkSendmail" ];then
        printLog "Result :  sendmail deamon seems disabled"
else
        printLog "Result :\n$checkSendmail"
fi
}

clean_clientmqueue()
{
countfiles_clientmqueue "There are"
if [ ! -z "$1" ];then
        purgedays=$1
else
        purgedays="-1"
        printLog "Warning: Flag -d is missing. However, script is assigning -d -1. Hence, all files will be removed"
fi
printLog "Running: /tango/bin/HK_purgeFiles /var/spool/clientmqueue/ $purgedays"
/tango/bin/HK_purgeFiles /var/spool/clientmqueue/ $purgedays
countfiles=$(ls -altr /var/spool/clientmqueue/ | wc -l)
countfiles_clientmqueue "After HK_purgeFiles, there are"
}


countfiles_clientmqueue()
{
countfiles=$(ls /var/spool/clientmqueue/ | wc -l | tr -s " ")
printLog "$1$countfiles files in /var/spool/clientmqueue/"
}

printLog()
{
if [ "$LOGS" == "TRUE" ];then
echo -e [ $timenow ] "$1" >> /tango/logs/sendmail/sendmail_$lognow.log
fi
}

# Script
printLog "----------- START -----------"
case $mode in
        stopsendmail) stop_sendmail;;
        cleanclientmqueue) clean_clientmqueue "$days";;
        stopcleansendmail) stop_sendmail;clean_clientmqueue "$days";;
esac


fi