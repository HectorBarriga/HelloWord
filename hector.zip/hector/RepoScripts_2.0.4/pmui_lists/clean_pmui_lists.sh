#!/bin/bash

#---------------------------------------------------------------
# Configurations
#---------------------------------------------------------------
mysqlmasterhost="IPXMIATCDB1"
mysqluser="root"
mysqlpw="t3il3achum"
ESdataHostsPort="IPXMIATCDB2_es"
ESuser="elastic"
ESpw="t3il3achum"
tenant="brav1"

#---------------------------------------------------------------
# Set Initial variables
#---------------------------------------------------------------
localhost=$(hostname)
DIR=`dirname $0`
whichmysql=$(ssh tangoI 'which mysql')
gomysqlmaster=$(echo "$whichmysql -u$mysqluser -p$mysqlpw -h $mysqlmasterhost")

#---------------------------------------------------------------
# Flags
#---------------------------------------------------------------

while getopts sh option;
do
        case $option in
                s) show="true";;
                h) echo -e "
        Usage: clean_pmui_lists.sh

        This sh housekeeping script shows curl commands to run to remove PMUI Lists that are not in PMUI anymore
        Note: This script will not run any curl command. It only displays and suggests the commands to run
        Copyright (c) Tango Telecom 2015

               Options:

               -s <show Lists to clean> It only shows the lists to clean (Optional)

               -h <help>                Show help

               ";help="true";;
        esac
done

if [ "$help" ==  "true" ];then
        echo ""
else

if [ "$show" != "true" ];then
        getCurrentPMUILists=$(ssh tangoI 'echo "select tag,name  from FieldMapping;" | mysql -u root -pt3il3achum promotion_brav1' | grep Lists)
        showgetCurrentPMUILists=$(echo $getCurrentPMUILists | sed 's/ /\n/g' | egrep -v Lists)
        i=0
        while read showgetCurrentPMUIListsLoop0
        do
                if [ "$i" == "0" ];then
                        curl -s -u $ESuser:$ESpw -XGET "$ESdataHostsPort:9201/campaign_lists/_search?q=list_name:$showgetCurrentPMUIListsLoop0&pretty" | grep list_name | cut -d'"' -f4 > $DIR/.tempfile
                else
                        curl -s -u $ESuser:$ESpw -XGET "$ESdataHostsPort:9201/campaign_lists/_search?q=list_name:$showgetCurrentPMUIListsLoop0&pretty" | grep list_name | cut -d'"' -f4 >> $DIR/.tempfile
                fi
                i=$((i+1))
        done <<< "$showgetCurrentPMUILists"
        j=0
        for listInES in $(echo $getCurrentPMUILists | sed 's/ /\n/g' | egrep -v Lists)
        do
                getCurrentPMUIListsArray[$j]="$listInES"
                let "j= $j + 1"
        done

        for getESList in "${getCurrentPMUIListsArray[@]}"
        do
                cat $DIR/.tempfile | egrep -w -v "$getESList" | tee  $DIR/.tempfile > /dev/null 2>&1
        done


        echo "`tput setaf 3`------------ PMUI Imported Lists ------------`tput sgr0`"
        echo "$showgetCurrentPMUILists" | while read in;do echo $in "   `tput setaf 2` <<< Do not touch it`tput sgr0`";done
        echo "`tput setaf 3`------------If you need to remove a list manually on MySQL, run this query: --------"
        echo "Note: It is in case it is not in PMUI but it remains in MySQL promotion_brav1.FieldMapping`tput setaf 2`"
        echo "$showgetCurrentPMUILists" | while read in;do echo "delete from promotion_brav1.FieldMapping where name='$in';";done
        echo "`tput setaf 3`------------ ES stored Lists (I wont show duplicates) ------------`tput sgr0`"
        while read showgetCurrentPMUIListsLoop
        do
                ESstoredListCurl=$(curl -s -u $ESuser:$ESpw -XGET "$ESdataHostsPort:9201/campaign_lists/_search?q=list_name:$showgetCurrentPMUIListsLoop&pretty" | grep list_name | cut -d'"' -f4 | sort -u )
                if [ ! -z "$ESstoredListCurl" ];then
                        echo "$ESstoredListCurl"
                else
                        echo "`tput setaf 1`$showgetCurrentPMUIListsLoop seems to be missing in ES`tput sgr0`"
                fi
        done <<< "$showgetCurrentPMUILists"
        echo "`tput setaf 3`------------- ES stored Lists to Remove ------------`tput setaf 1`"
        ESstoredListstoRemove=$(cat -n $DIR/.tempfile | sort -k2 | uniq -f1 | sort -k1 | cut -f2-)
        if [ ! -z "$ESstoredListstoRemove" ];then
                echo "$ESstoredListstoRemove"
        else
                echo "`tput sgr0`None"
        fi
        echo "`tput setaf 3`----------- Curl commands to remove them (This script will not run them, you need to run them manually and CAREFULLY -----------`tput sgr0`"
        if [ ! -z "$ESstoredListstoRemove" ];then
                cat -n $DIR/.tempfile | sort -k2 | uniq -f1 | sort -k1 | cut -f2- | while read in;do echo "curl -u $ESuser:$ESpw -X POST -H \"Content-Type: application/json\" http://$ESdataHostsPort:9201/campaign_lists/_delete_by_query -d '{\"query\": {\"match\": {\"list_name\": \"$in\"}}}';";echo "sleep 60;";done
        else
                echo "`tput sgr0`None"
        fi
        echo "`tput setaf 3`-------------------------------------- Run this command to check ES stored Lists ------------------------------------------------"
        echo "`tput setaf 2`curl -s -u $ESuser:$ESpw -XGET \"$ESdataHostsPort:9201/campaign_lists/_search?q=list_name:*&pretty\" | grep list_name | cut -d'\"' -f4;`tput sgr0`"
        echo "`tput setaf 3`-------------------------------------- Run this command to check an MSISDN stored in an ES Lists  ------------------------------------------------"
        echo "`tput setaf 2`echo -n \"Enter msisdn > \";read msisdn;while (true);do curl -u elastic:t3il3achum -X POST -H 'Content-Type: application/json' 'IPXMIATCDB2_es:9201/campaign_lists/_search' -d '{\"query\" : {\"term\" : { \"list_values\" : \"'\$msisdn'\" }}}';echo -e \"\\n==================================================================================\";echo \"\`tput setaf 2\`curl -u elastic:t3il3achum -X POST -H 'Content-Type: application/json' 'IPXMIATCDB2_es:9201/campaign_lists/_search' -d '{\\\"query\\\" : {\\\"term\\\" : { \\\"list_values\\\" : \\\"\$msisdn\\\" }}}'\`tput sgr0\`\";sleep 2;done`tput sgr0`"
        echo -e "\nFinished, bye\n"


else
        i=0
        curl -s -u $ESuser:$ESpw -XGET "$ESdataHostsPort:9201/campaign_lists/_search?q=list_name:*&pretty" | grep list_name | cut -d'"' -f4 > $DIR/.tempfile
        getCurrentPMUILists=$(ssh tangoI 'echo "select tag,name  from FieldMapping;" | mysql -u root -pt3il3achum promotion_brav1' | grep Lists)
        showgetCurrentPMUILists=$(echo $getCurrentPMUILists | sed 's/ /\n/g' | egrep -v Lists)
        j=0
        for listInES in $(echo $getCurrentPMUILists | sed 's/ /\n/g' | egrep -v Lists)
        do
                getCurrentPMUIListsArray[$j]="$listInES"
                let "j= $j + 1"
        done

        for getESList in "${getCurrentPMUIListsArray[@]}"
        do
                cat $DIR/.tempfile | egrep -w -v "$getESList" | tee  $DIR/.tempfile > /dev/null 2>&1
        done
        cat -n $DIR/.tempfile | sort -k2 | uniq -f1 | sort -k1 | cut -f2-

fi
fi