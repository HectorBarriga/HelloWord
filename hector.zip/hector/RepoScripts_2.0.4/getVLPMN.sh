#!/bin/bash
database=IPXMIATCDB1
Zone=$1
if [ -z "$Zone" ];then
        echo -n "Country or Zone ? [Default = Zone] > "
        read countryOrZone
        if [ -z "$countryOrZone" ] || [ "$countryOrZone" == "zone" ] || [ "$countryOrZone" == "Zone" ];then
                echo -n "Enter Location Profile (Zone or Region) > "
                read Zone
        else
                echo -n "Enter Country Name > "
                read getCountryName
        fi
fi

if [ -z "$getCountryName" ];then
        getZoneId=$(ssh tango@$database "mysql -u root -e \"select id from pcrfdb_wsms_brav1.pcrf_location_profile where name='$Zone';\"" | egrep -v id)
        getCountriesIds=$(ssh tango@$database "mysql -u root -e \"select location_oid from pcrfdb_wsms_brav1.pcrf_location_profile_location_mapping where location_profile_oid=$getZoneId;\"" | egrep -v location_oid)

        echo -e "`tput setaf 3`\n===================== Locations (Countries) for Location Profile (Zone or Region) `tput setaf 2`$Zone `tput setaf 3`======================`tput sgr0`"
        for countryId in $getCountriesIds
        do
               ssh tango@$database "mysql -u root -e \"select name from pcrfdb_wsms_brav1.pcrf_location where id=$countryId;\"" | egrep -v name
        done

        echo "`tput setaf 3`====================================== Network Locations (Network Operators) ======================================`tput sgr0`"
        for countryId in $getCountriesIds
        do
                getCountryName=$(ssh tango@$database "mysql -u root -e \"select name from pcrfdb_wsms_brav1.pcrf_location where id=$countryId;\"" | egrep -v name)
                echo "`tput setaf 2`------ $getCountryName ------`tput sgr0`"
                ssh tango@$database "mysql -u root -e \"select name,location_info from pcrfdb_wsms_brav1.pcrf_location_info where location_oid=$countryId;\"" | egrep -v name
        done

        echo "`tput setaf 3`===============================================       VPLMNs      =================================================`tput sgr0`"
        for countryId in $getCountriesIds
        do

                ssh tango@$database "mysql -u root -e \"select location_info from pcrfdb_wsms_brav1.pcrf_location_info where location_oid=$countryId;\"" | egrep -v location_info
        done
else
        countryId=$(ssh tango@$database "mysql -u root -e \"select id from pcrfdb_wsms_brav1.pcrf_location where name='$getCountryName';\"" | egrep -v id)
        echo "`tput setaf 3`===============================================       VPLMNs      =================================================`tput sgr0`"
        ssh tango@$database "mysql -u root -e \"select location_info from pcrfdb_wsms_brav1.pcrf_location_info where location_oid=$countryId;\"" | egrep -v location_info
fi