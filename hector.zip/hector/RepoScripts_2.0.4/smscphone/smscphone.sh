#!/bin/bash

sub_m2p()
{
echo -n "Do you want to use CURRENT msg.txt & esme.cfg ? [y/n] > "
read current

if [[ "$current" != "y" ]] && [[ ! -z "$current" ]]; then

        echo -n "Do you want to modify message? [y/n] > "
        read message
        if [[ "$message" == "y" ]]; then
                        vi /tango/logs/COSTAFF/hector/sh_scripts/smscphone/esme_M2P_GSM.msg
                        echo "1" > /tango/logs/COSTAFF/hector/sh_scripts/smscphone/counter.txt
                        origMsg=$(cat /tango/logs/COSTAFF/hector/sh_scripts/smscphone/esme_M2P_GSM.msg)
                        echo "$origMsg [1]" > /tango/logs/COSTAFF/hector/sh_scripts/smscphone/esme_M2P_GSM.msg
        else
                counter=$(cat /tango/logs/COSTAFF/hector/sh_scripts/smscphone/counter.txt)
                origMsg=$(cat /tango/logs/COSTAFF/hector/sh_scripts/smscphone/esme_M2P_GSM.msg | cut -d"[" -f1)
                counter=$((counter+1))
                echo "$counter" > /tango/logs/COSTAFF/hector/sh_scripts/smscphone/counter.txt
                echo "$origMsg [$counter]" > /tango/logs/COSTAFF/hector/sh_scripts/smscphone/esme_M2P_GSM.msg
        fi

        echo -n "Do you want to modify esme.cfg? [y/n] > "
        read config
        if [[ "$config" == "y" ]]; then
                        vi /tango/logs/COSTAFF/hector/sh_scripts/smscphone/esme.cfg
        fi
else
        counter=$(cat /tango/logs/COSTAFF/hector/sh_scripts/smscphone/counter.txt)
        origMsg=$(cat /tango/logs/COSTAFF/hector/sh_scripts/smscphone/esme_M2P_GSM.msg | cut -d"[" -f1)
        counter=$((counter+1))
        echo "$counter" > /tango/logs/COSTAFF/hector/sh_scripts/smscphone/counter.txt
        echo "$origMsg [$counter]" > /tango/logs/COSTAFF/hector/sh_scripts/smscphone/esme_M2P_GSM.msg
fi

echo ""
tput setaf 3
echo "========================================================="
echo "/tango/logs/COSTAFF/hector/sh_scripts/smscphone/esme.cfg"
echo "========================================================="
tput sgr0
cat /tango/logs/COSTAFF/hector/sh_scripts/smscphone/esme.cfg
tput setaf 3
echo "========================================================="
echo ""
echo "========================================================="
echo "/tango/logs/COSTAFF/hector/sh_scripts/smscphone/esme_M2P_GSM.msg"
tput sgr0
cat /tango/logs/COSTAFF/hector/sh_scripts/smscphone/esme_M2P_GSM.msg
tput setaf 3
echo "========================================================="
tput sgr0
echo ""

echo -n "Trigger esme to send M2P message [y/n] ? > "
read confirm
if [[ "$confirm" == "y" ]] || [[ -z "$confirm" ]]; then
        /tango/logs/COSTAFF/hector/sh_scripts/smscphone/esme.pl -c /tango/logs/COSTAFF/hector/sh_scripts/smscphone/esme.cfg -l /tango/logs/COSTAFF/hector/sh_scripts/smscphone/esme.pl_temp.log -v
        echo ""
else
        tput setaf 1;echo "Nothing done, Bye.";tput sgr0;
        echo ""
fi
}

sub_p2m()
{
anin=$(cat /tango/logs/COSTAFF/hector/sh_scripts/smscphone/mo_SCCProute_P2M_GSM.msg | grep "62 81 A9 48 04 08 00" |  head -c 212 | tail -c 12 | tr -d " ")
anin1=$(echo $anin | head -c 1 | tail -c 1)
anin2=$(echo $anin | head -c 2 | tail -c 1)
anin3=$(echo $anin | head -c 3 | tail -c 1)
anin4=$(echo $anin | head -c 4 | tail -c 1)
anin5=$(echo $anin | head -c 5 | tail -c 1)
anin6=$(echo $anin | head -c 6 | tail -c 1)
anin7=$(echo $anin | head -c 7 | tail -c 1)
anin8=$(echo $anin | head -c 8 | tail -c 1)
tput setaf 5
echo "Note: 501 was added on puporpse in aNumber"
tput sgr0
echo -n "Current aNumber = "
tput setaf 3
echo "501$anin1$anin4$anin3$anin6$anin5$anin8$anin7"
tput sgr0
bnin=$(cat /tango/logs/COSTAFF/hector/sh_scripts/smscphone/mo_SCCProute_P2M_GSM.msg | grep "62 81 A9 48 04 08 00" |  head -c 241 | tail -c 11 | tr -d " ")
bnin1=$(echo $bnin | head -c 1 | tail -c 1)
bnin2=$(echo $bnin | head -c 2 | tail -c 1)
bnin3=$(echo $bnin | head -c 3 | tail -c 1)
bnin4=$(echo $bnin | head -c 4 | tail -c 1)
echo -n "Current ShortCode = "
tput setaf 3
echo "$bnin2$bnin1$bnin4$bnin3"
tput sgr0

echo -n "Do you want to Edit mo_SCCProute_P2M_GSM.msg [Default = n] n/y > "
read answer
if [ ! -z "$answer" ] && [ "$answer"  == "y" ];then
echo -n "Enter aNumber [Dont include country code] [Enter to leave old one] > "
read aNumber
anuml=${#aNumber}
if [ ! -z "$aNumber" ];then
                if [ "$anuml" != 7 ];then
                        tput setaf 1
                        echo "Sorry, msisdn is not 7 diggits"
                        tput sgr0
                        exit
                else
                        a1=$(echo $aNumber | head -c 1 | tail -c 1)
                        a2=$(echo $aNumber | head -c 2 | tail -c 1)
                        a3=$(echo $aNumber | head -c 3 | tail -c 1)
                        a4=$(echo $aNumber | head -c 4 | tail -c 1)
                        a5=$(echo $aNumber | head -c 5 | tail -c 1)
                        a6=$(echo $aNumber | head -c 6 | tail -c 1)
                        a7=$(echo $aNumber | head -c 7 | tail -c 1)
                        anum=$(echo "05 $a1""1 $a3$a2 $a5$a4 $a7$a6")
                fi
else
                anum=$(cat /tango/logs/COSTAFF/hector/sh_scripts/smscphone/mo_SCCProute_P2M_GSM.msg | grep "62 81 A9 48 04 08 00" | head -c 212 | tail -c 14)
fi

echo -n "Enter ShortCode [4 diggits only] [Enter to leave old one] > "
read bNumber
bnuml=${#bNumber}
if [ ! -z "$bNumber" ];then
                if [ "$bnuml" != 4 ];then
                        tput setaf 1
                        echo "Sorry, msisdn is not 4 diggits"
                        tput sgr0
                        exit
                else
                        b1=$(echo $bNumber | head -c 1 | tail -c 1)
                        b2=$(echo $bNumber | head -c 2 | tail -c 1)
                        b3=$(echo $bNumber | head -c 3 | tail -c 1)
                        b4=$(echo $bNumber | head -c 4 | tail -c 1)
                        bnum=$(echo "$b2$b1 $b4$b3")
                fi
else
                bnum=$(cat /tango/logs/COSTAFF/hector/sh_scripts/smscphone/mo_SCCProute_P2M_GSM.msg | grep "62 81 A9 48 04 08 00" | head -c 241 | tail -c 11)
fi
tput setaf 3
echo "This is the message that should be used:"
echo "
  62 81 A9 48 04 08 00 F8 A9 6B 1E 28 1C 06 07 00 11 86 05 01 01 01 A0 11 60 0F 80 02 07 80 A1 09 06 07 04 00 00 01 00 15 03 6C 81 80 A1 7E 02 01 01 02 01 2E 30 76 84 06 91 05 61 17 00 90 82 06 91 $anum 04 5A 11 ED 04 81 $bnum 00 00 05 5B D2 E2 B1 25 2D 46 7F F6 DE 6C 47 EF 15 8B 36 98 71 96 1B DE 72 C1 9B B0 88 CB 0D 8D B2 9C 50 28 2C 12 6B 37 E3 8D 66 AB E5 64 C2 DC 10 47 A4 15 61 32 59 CE 76 8B 0D 63 31 61 91 16 CC 09 89 B8 58 AD 16 23 EE E4 BD 18 2E 66 AB CD 64 36 DC 0C 04 08 07 62 59 10 70 60 03 F9"
echo ""
tput sgr0

vi /tango/logs/COSTAFF/hector/sh_scripts/smscphone/mo_SCCProute_P2M_GSM.msg
fi
echo -n "Are you sure you want to poke mo_SCCProute_P2M_GSM.msg? [Default = y] y/n > "
read confirm
if [ -z "$confirm" ] || [ "$confirm"  == "y" ];then
        tput setaf 2
        echo ""
        echo "/tango/logs/COSTAFF/hector/sh_scripts/smscphone/poke /tango/logs/COSTAFF/hector/sh_scripts/smscphone/mo_SCCProute_P2M_GSM.msg"
        echo ""
        tput sgr0
        /tango/logs/COSTAFF/hector/sh_scripts/smscphone/poke /tango/logs/COSTAFF/hector/sh_scripts/smscphone/mo_SCCProute_P2M_GSM.msg
else
        tput setaf 1;echo "Nothing done, Bye.";tput sgr0;
        echo""
fi

}

sub_miussd()
{
tput setaf 2
echo ""
echo "/tango/logs/COSTAFF/hector/sh_scripts/smscphone/poke /tango/logs/COSTAFF/hector/sh_scripts/smscphone/mo_SCCProute_MI_USSD_GSM.msg"
echo ""
tput sgr0
/tango/logs/COSTAFF/hector/sh_scripts/smscphone/poke /tango/logs/COSTAFF/hector/sh_scripts/smscphone/mo_SCCProute_MI_USSD_GSM.msg
}

sub_p2p()
{
anin=$(cat /tango/logs/COSTAFF/hector/sh_scripts/smscphone/mo_SCCProute_P2P_GSM.msg | grep "62 5F 48 04 08 00 3A 9C" |  head -c 205 | tail -c 11 | tr -d " ")
anin1=$(echo $anin | head -c 1 | tail -c 1)
anin2=$(echo $anin | head -c 2 | tail -c 1)
anin3=$(echo $anin | head -c 3 | tail -c 1)
anin4=$(echo $anin | head -c 4 | tail -c 1)
anin5=$(echo $anin | head -c 5 | tail -c 1)
anin6=$(echo $anin | head -c 6 | tail -c 1)
anin7=$(echo $anin | head -c 7 | tail -c 1)
anin8=$(echo $anin | head -c 8 | tail -c 1)
tput setaf 5
echo "Note: 501 was added on puporpse in aNumber and bNumber"
tput sgr0
echo -n "Current aNumber = "
tput setaf 3
echo "501$anin1$anin4$anin3$anin6$anin5$anin8$anin7"
tput sgr0
bnin=$(cat /tango/logs/COSTAFF/hector/sh_scripts/smscphone/mo_SCCProute_P2P_GSM.msg | grep "62 5F 48 04 08 00 3A 9C" |  head -c 238 | tail -c 11 | tr -d " ")
bnin1=$(echo $bnin | head -c 1 | tail -c 1)
bnin2=$(echo $bnin | head -c 2 | tail -c 1)
bnin3=$(echo $bnin | head -c 3 | tail -c 1)
bnin4=$(echo $bnin | head -c 4 | tail -c 1)
bnin5=$(echo $bnin | head -c 5 | tail -c 1)
bnin6=$(echo $bnin | head -c 6 | tail -c 1)
bnin7=$(echo $bnin | head -c 7 | tail -c 1)
bnin8=$(echo $bnin | head -c 8 | tail -c 1)
echo -n "Current bNumber = "
tput setaf 3
echo "501$bnin1$bnin4$bnin3$bnin6$bnin5$bnin8$bnin7"
tput sgr0

echo -n "Do you want to Edit mo_SCCProute_P2P_GSM.msg [Default = n] n/y > "
read answer
if [ ! -z "$answer" ] && [ "$answer"  == "y" ];then
echo -n "Enter aNumber [Dont include country code] [Enter to leave old one] > "
read aNumber
anuml=${#aNumber}
if [ ! -z "$aNumber" ];then
                if [ "$anuml" != 7 ];then
                        tput setaf 1
                        echo "Sorry, msisdn is not 7 diggits"
                        tput sgr0
                        exit
                else
                        a1=$(echo $aNumber | head -c 1 | tail -c 1)
                        a2=$(echo $aNumber | head -c 2 | tail -c 1)
                        a3=$(echo $aNumber | head -c 3 | tail -c 1)
                        a4=$(echo $aNumber | head -c 4 | tail -c 1)
                        a5=$(echo $aNumber | head -c 5 | tail -c 1)
                        a6=$(echo $aNumber | head -c 6 | tail -c 1)
                        a7=$(echo $aNumber | head -c 7 | tail -c 1)
                        anum=$(echo "05 $a1""1 $a3$a2 $a5$a4 $a7$a6")
                fi
else
                anum=$(cat /tango/logs/COSTAFF/hector/sh_scripts/smscphone/mo_SCCProute_P2P_GSM.msg | grep "62 5F 48 04 08 00 3A 9C" | head -c 205 | tail -c 14)
fi

echo -n "Enter bNumber [Dont include country code] [Enter to leave old one] > "
read bNumber
bnuml=${#bNumber}
if [ ! -z "$bNumber" ];then
                if [ "$bnuml" != 7 ];then
                        tput setaf 1
                        echo "Sorry, msisdn is not 7 diggits"
                        tput sgr0
                        exit
                else
                        b1=$(echo $bNumber | head -c 1 | tail -c 1)
                        b2=$(echo $bNumber | head -c 2 | tail -c 1)
                        b3=$(echo $bNumber | head -c 3 | tail -c 1)
                        b4=$(echo $bNumber | head -c 4 | tail -c 1)
                        b5=$(echo $bNumber | head -c 5 | tail -c 1)
                        b6=$(echo $bNumber | head -c 6 | tail -c 1)
                        b7=$(echo $bNumber | head -c 7 | tail -c 1)
                        bnum=$(echo "05 $b1""1 $b3$b2 $b5$b4 $b7$b6")
                fi
else
                bnum=$(cat /tango/logs/COSTAFF/hector/sh_scripts/smscphone/mo_SCCProute_P2P_GSM.msg | grep "62 5F 48 04 08 00 3A 9C" | head -c 238 | tail -c 14)
fi
tput setaf 3
echo "This is the message that should be used:"
echo "
  62 5F 48 04 08 00 3A 9C 6B 1E 28 1C 06 07 00 11 86 05 01 01 01 A0 11 60 0F 80 02 07 80 A1 09 06 07 04 00 00 01 00 15 03 6C 37 A1 35 02 01 01 02 01 2E 30 2D 84 06 91 05 61 17 00 90 82 06 91 $anum 04 11 31 78 0A 81 $bnum 00 00 FF 04 D4 F2 9C 0E 04 08 07 62 59 10 70 60 03 F9"
echo ""
tput sgr0

vi /tango/logs/COSTAFF/hector/sh_scripts/smscphone/mo_SCCProute_P2P_GSM.msg
fi
echo -n "Are you sure you want to poke mo_SCCProute_P2P_GSM.msg? [Default = y] y/n > "
read confirm
if [ -z "$confirm" ] || [ "$confirm"  == "y" ];then
        tput setaf 2
        echo ""
        echo "/tango/logs/COSTAFF/hector/sh_scripts/smscphone/poke /tango/logs/COSTAFF/hector/sh_scripts/smscphone/mo_SCCProute_P2P_GSM.msg"
        echo ""
        tput sgr0
        /tango/logs/COSTAFF/hector/sh_scripts/smscphone/poke /tango/logs/COSTAFF/hector/sh_scripts/smscphone/mo_SCCProute_P2P_GSM.msg
else
        tput setaf 1;echo "Nothing done, Bye.";tput sgr0;
        echo""
fi

}

default()
{
if [ -z "$option" ]; then
        sub_m2p
else
        tput setaf 1;echo "Nothing done, Bye.";tput sgr0;
        echo ""
fi
}

tput setaf 1
echo "==========================
|          GSM           |
|  SMSC Phone Simulator  |
=========================="

tput setaf 3
echo "| 0) M2P [Default]       |
| 1) P2M                 |
| 2) P2P                 |
| 3) MI USSD             |
--------------------------
"
tput sgr0
echo -n "Phone> "
tput sgr0
read option

case $option in

0) sub_m2p;;
1) sub_p2m;;
2) sub_p2p;;
3) sub_miussd;;
*) default;;

esac