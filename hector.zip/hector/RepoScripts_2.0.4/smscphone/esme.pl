#!/usr/bin/perl
# Copyright (c) 2005 Tango Telecom

# Filename: esme.pl
# Revision: $Revision: 1.1.2.5 $
# Author  : Niall Murray

use Getopt::Std;
use POSIX;
use Net::SMPP;
use Data::Dumper;
use Carp;
use Time::Local;

$multi_esme = 0;
$sentOnce = 0;

@scriptPath = split '/', $0;
$scriptName = $scriptPath[$#scriptPath];

my $revision = q/$Revision: 1.1.2.5 $/;
$revision =~ s/^.*(\d+\.\d+).*$/$1/;
$fileRoot = "./";

if ( 0 == getopts( "c:vdhl:s:" ) )
{
    usage();
    exit 0;
}

if ( defined( $opt_h ) )
{
    help();
    exit 0;
}

if ( defined( $opt_c ) )
{
    $cfgFile = $opt_c;
}
$logFile = $scriptName."_temp.log";
if ( defined( $opt_l ) )
{
    $logFile = $opt_l;
}
open( LOG, ">$logFile" );
close LOG;
$seconds2run = 10;
if ( defined( $opt_s ) )
{
    $seconds2run = $opt_s;
}
$startTime = timelocal(localtime(time));

getTime();
printLog( "$timeStr $scriptName starting\n" );
printLog( "Perl version: $]\n" );
loadConfig();

#
# Configuration items
#
$traceTxt = "trace";
$enabledTxt = "disabled";
$dumpTxt = "dump";

$connTxt = "connection";
$hostTxt = "host";
$portTxt = "port";

$bindTxt = "bind";
$typeTxt = "type";
$sysidTxt = "system_id";
$pwdTxt = "password";
$systypeTxt = "system_type";

$enquireTxt = "enquire";

$submitTxt = "submit";
$rateTxt = "rate";
$srctonTxt = "source_addr_ton";
$srcnpiTxt = "source_addr_npi";
$srcTxt = "source_addr";
$dsttonTxt = "dest_addr_ton";
$dstnpiTxt = "dest_addr_npi";
$dstprefixTxt = "dest_addr_prefix";
$dstpaddingTxt = "dest_addr_padding";
$dstmaxTxt = "dest_addr_max";
$serviceTxt = "service_type";
$replaceTxt = "replace_if_present_flag";
$receiptTxt = "registered_delivery";

$shortMessageTxt = "short_message";
$formatTxt = "file_format";
$nameTxt = "file_name";
$segTxt = "segmentation";

#
# Script variables from configuration
#

# connection
$host = setFromConfig( $connTxt, $hostTxt, "localhost" );
$port = setFromConfig( $connTxt, $portTxt, 8010 );

# bind
$bindType = setFromConfig( $bindTxt, $typeTxt, "transmitter" );
$systemId = setFromConfig( $bindTxt, $sysidTxt, "esme" );
$password = setFromConfig( $bindTxt, $pwdTxt, "esme" );
$systemType = setFromConfig( $bindTxt, $systypeTxt, "" );

# enquire
$enquireEnabled = setFromConfig( $enquireTxt, $enabledTxt, 1 );

# submit
$rate = setFromConfig( $submitTxt, $rateTxt, 1 );

@source_addr = ( setFromConfig( $submitTxt, $srctonTxt, '1' ),
                 setFromConfig( $submitTxt, $srcnpiTxt, '1' ),
                 setFromConfig( $submitTxt, $srcTxt, '0002' ) );

@dest_addr = ( setFromConfig( $submitTxt, $dsttonTxt, '1' ),
               setFromConfig( $submitTxt, $dstnpiTxt, '1' ) );

# Setup the dest_addr range of numbers to use
$dest_addr_prefix = setFromConfig( $submitTxt, $dstprefixTxt, 1 );
$dest_addr_padding = setFromConfig( $submitTxt, $dstpaddingTxt, 1 );
$dest_addr_max = setFromConfig( $submitTxt, $dstmaxTxt, 1 );
$dest_addr_index = 0;
@dest_addr_range = ();
if ($multi_esme)
{
   for ($i=0; $i<$dest_addr_max; $i++)
   {
      push( @dest_addr_range, sprintf '%s%0*s', $dest_addr_prefix, $dest_addr_padding, $i );
      #print "This is added B number: $dest_addr_range[$i]\n";
   }
}
else
{
   push( @dest_addr_range, $dest_addr_prefix );
   print "This a B number: $dest_addr_range[0]\n";
}
$service_type = setFromConfig( $submitTxt, $serviceTxt, '' );
$replace_if_present_flag = setFromConfig( $submitTxt, $replaceTxt, '0' );
$registered_delivery = setFromConfig( $submitTxt, $receiptTxt, '0' );

# short_message
@short_message_array = ();
$fileFormat = setFromConfig( $shortMessageTxt, $formatTxt, '' );
$fileName = setFromConfig( $shortMessageTxt, $nameTxt, '' );
$segmentation = setFromConfig( $shortMessageTxt, $segTxt, 'udh' );

#
# Hard coded script variables
#

#$cfgFile = $fileRoot . $systemId . "_" . $bindType . ".cfg";
#$logFile = $fileRoot . $systemId . "_" . $bindType . ".log";
$debugFile = $fileRoot . $systemId . "_" . $bindType . ".dbg";


$version = 0x34;
$if_version = 0x34;

$maxChars = 160;
$udhChars = 7;
$maxBytes = 140;
$udhBytes = 6;

$partReference = 1;

#
# Table defining handlers for different SMPP command ids
#
use constant reply_tab => {
    0x80000000 => { cmd => 'generic_nack',                      reply => doNothing, },
    0x80000001 => { cmd => 'bind_receiver_resp',                reply => doNothing, },
    0x80000002 => { cmd => 'bind_transmitter_resp',             reply => doNothing, },
    0x80000004 => { cmd => 'submit_sm_resp',                    reply => handleSubmitSmResponse, },
    0x00000005 => { cmd => 'deliver_sm',                        reply => handleDeliverSm, },
    0x80000005 => { cmd => 'deliver_sm_resp',                   reply => doNothing, },
    0x00000006 => { cmd => 'unbind',                            reply => handleUnbind, },
    0x80000006 => { cmd => 'unbind_resp',
                    reply => sub { warn "$$: Remote replied to unbind. Dropping connection.";
                                   exit;
                               }, },
    0x80000009 => { cmd => 'bind_transceiver_resp',             reply => doNothing, },
    0x0000000b => { cmd => 'outbind',                           reply => doNothing, },
    0x00000015 => { cmd => 'enquire_link',                      reply => handleEnquireLink },
    0x80000015 => { cmd => 'enquire_link_resp',                 reply => doNothing, },
};

# SMPP trace
$Net::SMPP::trace = setFromConfig( $traceTxt, $enabledTxt, 0 );
$dump = setFromConfig( $traceTxt, $dumpTxt, 0 );

#
# Connect to the host
#

my $smpp;
my $bound = 0;

#
# Binding loop..
#
while ( !$bound ) {
  sleep 1;
  print "Connecting to $host:$port\n";
  $smpp = Net::SMPP->new_connect( $host,
                                  port => $port,
                                  smpp_version => $version,
                                  async => 1 );
  if ( defined( $smpp ) ) {
    #
    # Send the appropriate bind PDU and block for the response
    #
    if ( $bindType eq "transmitter" ) {
      $bound = bindTransmitter();
    } elsif ( $bindType eq "receiver" ) {
      $bound = bindReceiver();
    } elsif ( $bindType eq "transceiver" ) {
      $bound = bindTransceiver();
    } else {
      die "Invalid configuration";
    }
    print "Bound is $bound\n";
  }
}


#
# Print startup message
#
print "$systemId bound as $bindType to $host:$port\n";

#
# Processing loop..
#
$sendingMsgs = 1;
while ($sendingMsgs)
{
  $pduSent = 0;

  # Send submit-sm PDUs at the configured rate
  $pduSent = sendPdu();

  # Process incoming request/response PDUs
  readPdu();
  $timeNow = timelocal(localtime(time));
  $sendingMsgs = 0 if ($timeNow > ($startTime + $seconds2run));

#  if (! $multi_esme) { $sendingMsgs = 0;}
}

################################################################
# sendPdu
#
# Send outgoing requests
################################################################

sub sendPdu {
  $pduSent = 0;
  $esm_class = Net::SMPP::ESM_feature_none;
  $data_coding = 0x00;

  return if ($rate <= 0);

  # printLog( "Sending PDUs at $rate/s" . "\n" );

  #
  # Send enquire-link PDU
  #
  if ( $enquireEnabled ) {
    enquireLink();
  }

  return if ( $bindType eq "receiver" );
  return if ($sentOnce  && ($bindType eq "transceiver"));
  #
  # Send submit-sm PDU
  #

  if ( $fileFormat eq "binary" ) {
    $data_coding = 0x00;
  }

  $timeout = ( 1 / $rate );
  for ($i=0; $i<$rate; $i++) {

    # Initialise the destination
    # subscriber & the message contents
    setDestAddr();
        print "$dest_addr[0], $dest_addr[1], $dest_addr[2] \n";
    ( $large, $udhi, $sar, $reference ) = setupShortMessage();
    $totalParts = scalar @short_message_array;
    $partId = 1;

    foreach $short_message_part (@short_message_array) {

      $sentOnce = 1;
      # time delay between sending each PDU
      select( undef, undef, undef, $timeout);

      if ( $fileFormat eq "binary" ) {
        $data_coding = 0x00;
        $short_message_part = pack 'a*', $short_message_part;
      }

      if ( $udhi ) {
        $esm_class |= Net::SMPP::ESM_feature_UDHI;
        $smpp->submit_sm( source_addr_ton => $source_addr[0],
                          source_addr_npi => $source_addr[1],
                          source_addr => $source_addr[2],
                          dest_addr_ton => $dest_addr[0],
                          dest_addr_npi => $dest_addr[1],
                          destination_addr => $dest_addr[2],
                          service_type => $service_type,
                          replace_if_present_flag => $replace_if_present_flag,
                          registered_delivery => $registered_delivery,
                          esm_class => $esm_class,
                          data_coding => $data_coding,
                          short_message => $short_message_part,
                        );
      } elsif ( $sar ) {
        $sar_msg_ref_num = pack 'n', $reference; # 2 byte
        $sar_total_segments = pack 'C', $totalParts; # 1 byte
        $sar_segment_seqnum = pack 'C', $partId++; # 1 byte
        $smpp->submit_sm( source_addr_ton => $source_addr[0],
                          source_addr_npi => $source_addr[1],
                          source_addr => $source_addr[2],
                          dest_addr_ton => $dest_addr[0],
                          dest_addr_npi => $dest_addr[1],
                          destination_addr => $dest_addr[2],
                          service_type => $service_type,
                          replace_if_present_flag => $replace_if_present_flag,
                          registered_delivery => $registered_delivery,
                          data_coding => $data_coding,
                          short_message => $short_message_part,
                          sar_msg_ref_num => $sar_msg_ref_num,
                          sar_total_segments => $sar_total_segments,
                          sar_segment_seqnum => $sar_segment_seqnum
                        );
      } elsif ( $large ) {
        $smpp->submit_sm( source_addr_ton => $source_addr[0],
                          source_addr_npi => $source_addr[1],
                          source_addr => $source_addr[2],
                          dest_addr_ton => $dest_addr[0],
                          dest_addr_npi => $dest_addr[1],
                          destination_addr => $dest_addr[2],
                          service_type => $service_type,
                          replace_if_present_flag => $replace_if_present_flag,
                          registered_delivery => $registered_delivery,
                          data_coding => $data_coding,
                          short_message => '',
                          message_payload => $short_message_part
                        );
      } else {
        $smpp->submit_sm( source_addr_ton => $source_addr[0],
                          source_addr_npi => $source_addr[1],
                          source_addr => $source_addr[2],
                          dest_addr_ton => $dest_addr[0],
                          dest_addr_npi => $dest_addr[1],
                          destination_addr => $dest_addr[2],
                          service_type => $service_type,
                          replace_if_present_flag => $replace_if_present_flag,
                          registered_delivery => $registered_delivery,
                          data_coding => $data_coding,
                          short_message => $short_message_part
                        );
      }
    }

    $pduSent++;
  }
  return $pduSent;
}

################################################################
# setupShortMessage
#
# Read the next short_message to send
################################################################

sub setupShortMessage
{
  @short_message_array = ();
  my $udhi = 0;
  my $sar = 0;
  my $ref = 0;
  my $large = 0;
  my $lsm = 0;

  if ( $fileFormat eq "binary" ) {
    $fileData = readFile( $fileName, binmode => 1 );
    $maxPart = $maxBytes - $udhBytes;
    $fileDataLength = length $fileData;
    if ( $fileDataLength > $maxBytes ) {
      $lsm = 1;
    }
  }
  else {
    $fileData = readFile( $fileName );
    $maxPart = $maxChars - $udhChars;
    $fileDataLength = length $fileData;
    if ( $fileDataLength > $maxChars ) {
      $lsm = 1;
    }
  }

  if ( $lsm ) {
    if ( $segmentation eq "large" ) {
      $large = 1;
      # Long short message in single large piece
      push( @short_message_array, $fileData );

    } else {
      # Long short message
      $charOffset = 0;
      $totalParts = floor( $fileDataLength / $maxPart );
      $totalParts++ if ($fileDataLength % $maxPart);

      $ref = $partReference++;
      if ( $partReference == 256 ) {
        $partReference = 1;
      }

      if ( $segmentation eq "udh" ) {
        $udhi = 1;
      } elsif ( $segmentation eq "sar" ) {
        $sar = 1;
      }

      for( $i=1; $i<=$totalParts && $i<256; $i++ ) {
        $userData = "";
        if ( $segmentation eq "udh" ) {
          $userData = pack 'CCCCCC', 6, 0, 3, $ref, $totalParts, $i;
        }
        $userData .= substr( $fileData, $charOffset, $maxPart );
        $userDataLength = length $userData;
        $charOffset += $maxPart;
        printLog( "[$ref:$i/$totalParts/$userDataLength]");
        push( @short_message_array, $userData );
      }
    }
  }
  else
  {
    # Single part short message
    push( @short_message_array, $fileData );
  }

  return ($large, $udhi, $sar, $ref);
}

################################################################
# setDestAddr
#
# Allocate a dest_addr from the available range
################################################################

sub setDestAddr
{
  $dest_addr[2] = $dest_addr_range[$dest_addr_index++];
  $dest_addr[2] = $dest_addr_range[0]  if (! $multi_esme);
  if ( $dest_addr_index == $dest_addr_max ) {
    $dest_addr_index = 0;
  }

  return;
}

################################################################
# readPdu
#
# Block for incoming requests/responses
################################################################

sub readPdu
{
  # figure out the best rate to use
  if ( $pduSent == 0 ) {
    $readRate = 1;
  } elsif ( $bindType eq "transceiver" ) {
    $readRate = $pduSent * 2;
  } else {
    $readRate = $pduSent;
  }

 # printLog( "Read rate is $readRate" . "\n" );

  for ($i=0; $i<$readRate; $i++) {

 #   printLog( "Waiting for PDU" . "\n" );

    $pdu = $smpp->read_pdu() or die "$$: PDU not read. Closing connection";

    printLog( "$i Received #$pdu->{seq} $pdu->{cmd}:". Net::SMPP::pdu_tab->{$pdu->{cmd}}{cmd} ."\n" ) if ($pdu->{cmd} != 2147483669);
    printLog( Dumper($pdu) . "\n" ) if ($dump && ($pdu->{cmd} != 2147483669));

    if (defined reply_tab->{$pdu->{cmd}}) {
      &{reply_tab->{$pdu->{cmd}}{reply}}($smpp, $pdu);
  #    printLog( "Replied" . "\n" );
    } else {
      printLog( "Don't know to reply to $pdu->{cmd}" . "\n" );
    }
  }

  return;
}

################################################################
# doNothing
#
# dummy PDU handler
################################################################

sub doNothing
{
  return;
}

################################################################
# handleSubmitSmResponse
#
# submit-sm-resp PDU handler
################################################################

sub handleSubmitSmResponse
{
  my ($me, $pdu) = @_;

  getTime();

  if (${$pdu}{status} != 0x0) {
    printLog( "submit-sm rejected: ${$pdu}{status}\n" );
    printLog( "$timeStr,${$pdu}{message_id},SUBMIT-REJECTED,${$pdu}{status}\n", Debug );

  } else {
    printLog( "submit-sm ok: id = ${$pdu}{message_id}\n" );
    printLog( "$timeStr,${$pdu}{message_id},SUBMIT-OK,${$pdu}{status}\n", Debug );

  }

  return;
}

################################################################
# handleDeliverSm
#
# Respond to the deliver-sm  PDU
################################################################

sub handleDeliverSm
{
  my ($me, $pdu) = @_;

  $me->deliver_sm_resp(seq => $pdu->{seq},
                       message_id => "" );

  $messageState = "UNKNOWN";
  $messageId = ${$pdu}{receipted_message_id};
  chop $messageId;
  getTime();
  if ( ${$pdu}{short_message} =~ /.*stat:([\w\S]+).*/ ) {
    $messageState = $1;
  }
  if ( ${$pdu}{short_message} =~ /.*err:([\d\S]+).*/ ) {
    $networkError = $1;
  }
  printLog( "$timeStr,$messageId,$messageState,$networkError\n", Debug );
}

################################################################
# handleUnbind
#
# Respond to the unbind PDU and close down the connection
################################################################

sub handleUnbind
{
  my ($me, $pdu) = @_;
  $me->unbind_resp(seq => $pdu->{seq});
  sleep 1; # allow the unbind response to be received
  printLog( "$$: Remote sent unbind. Dropping connection.\n" );
  exit;
}

################################################################
# handleEnquireLink
#
# Respond to the enquire-link PDU
################################################################

sub handleEnquireLink
{
  my ($me, $pdu) = @_;
  $me->enquire_link_resp(seq => $pdu->{seq});
}

################################################################
# enquireLink
#
# Send an enquire-link PDU and wait for the response
################################################################

sub enquireLink
{
  $seq = $smpp->enquire_link()
    or die "Can't contact server: $!";
}

################################################################
# bindReceiver
#
# Bind as a receiver
################################################################

sub bindReceiver
{
  $seq = $smpp->bind_receiver( system_id => $systemId,
                               password => $password,
                               system_type => $systemType )
    or die "Can't contact server: $!";

  $pdu = $smpp->wait_pdu(Net::SMPP::CMD_bind_receiver_resp, $seq) or die;

  if (${$pdu}{status} == 0x0) {
    return 1;
  } else {
    return 0;
  }
}

################################################################
# bindTransmitter
#
# Bind as a transmitter
################################################################

sub bindTransmitter
{
  $seq = $smpp->bind_transmitter( system_id => $systemId,
                                  password => $password,
                                  system_type => $systemType )
    or die "Can't contact server: $!";

  $pdu = $smpp->wait_pdu(Net::SMPP::CMD_bind_transmitter_resp, $seq) or die;

  if (${$pdu}{status} == 0x0) {
    return 1;
  } else {
    return 0;
  }
}

################################################################
# bindTransceiver
#
# Bind as a transceiver
################################################################

sub bindTransceiver
{
  $seq = $smpp->bind_transceiver( system_id => $systemId,
                                  password => $password,
                                  system_type => $systemType )
    or die "Can't contact server: $!";

  $pdu = $smpp->wait_pdu(Net::SMPP::CMD_bind_transceiver_resp, $seq) or die;

  if (${$pdu}{status} == 0x0) {
    return 1;
  } else {
    return 0;
  }
}

################################################################
# usage
#
# Print the script command line usage
################################################################

sub usage
{
    print <<EO_USAGE;

Usage: $scriptName
    options:
            -h                  help
            -c <file>           use <file> as config file
            -v                  verbose mode
            -l <file>           use <file> as log file

EO_USAGE
}

################################################################
# help
#
# Print a help message
################################################################

sub help
{
    print <<EO_HELP;

Help for script $scriptName v$revision (c) Tango Telecom 2005

EO_HELP

    usage();
}

################################################################
# setFromConfig
#
# Return the value from configuration or else use the default
################################################################

sub setFromConfig
{
  my ( $section, $item, $default ) = @_;

  if ( defined $cfg{$section}{$item} )
  {
    $value = $cfg{$section}{$item};
  }
  else
  {
    $value = $default;
  }

  return $value;
}

################################################################
# loadConfig
#
# Load the configuration file
################################################################

sub loadConfig
{
  open( CFG, $cfgFile ) || logDie( "Unable to open $cfgFile\n" );
  printLog( "Reading config from $cfgFile\n" );
  while ( <CFG> )
  {
    chop;
    if ( /^#/ )
    {
      next;
    }
    if ( /\[[\w\s]+\]/ )
    {
      $section = $_;
      $section =~ s/\[([\w\s]+)\]/$1/;
    }

    if ( /=/ )
    {
      ( $var, @values ) = split( "=", $_ );
      $val = join( "=", @values );
      $var =~ s/^\s*//;
      $var =~ s/\s*$//;
      $val =~ s/^\s*//;
      $val =~ s/\s*$//;
      $cfg{$section}{$var} = $val;
      #printLog( "<$section><$var><$val>\n" );
      #print "<$section><$var><$val>\n";
    }
  }
  close( CFG );
}

################################################################
# printLog
#
# Print a message to the log file
################################################################

sub printLog
{
   if ( ! defined( $_[1] ) )
   {
       open( LOG, ">>$logFile" );
       print LOG "$_[0]";
       close LOG;
   }

   if (
       ( $_[1] =~ /^[Dd]ebug$/ ) &&
       ( defined( $opt_d ) )
      )
   {
     open( DBG, ">>$debugFile" );
     print DBG "$_[0]";
     close DBG;
   }

   if ( defined( $opt_v ) )
   {
       print "$_[0]";
   }
}

################################################################
# logDie
#
# Print a message to the log file then exit
################################################################

sub logDie
{
   open( LOG, ">>$logFile" );
   print LOG "$_[0]";
   close LOG;

   die "$_[0]";
}

################################################################
# getTime
#
# Get the current time as a formatted string
################################################################

sub getTime
{
   ( my $sec,
     my $min,
     my $hour,
     my $mday,
     my $mon,
     my $year,
        $ignore,
        $ignore,
        $ignore) = localtime;

   $year += 1900;
   $mon++;

   my $padMin = sprintf( "%2.2d", $min );
   my $padSec = sprintf( "%2.2d", $sec );
   my $padMon = sprintf( "%2.2d", $mon );
   my $padDay = sprintf( "%2.2d", $mday );

   $dateStr = "$year$padMon$padDay";
   $timeStr = "$year$padMon$padDay$hour$padMin$padSec";
}

################################################################
# readFile
#
# Read entire file into memory
################################################################
sub readFile {

    my( $file_name, %args ) = @_ ;

    my $buf ;
    my $buf_ref = $args{'buf_ref'} || \$buf ;

    my $mode = O_RDONLY ;
    $mode |= O_BINARY if $args{'binmode'} ;

    local( *FH ) ;
    sysopen( FH, $file_name, $mode ) or
        carp "Can't open $file_name: $!" ;

    my $size_left = -s FH ;

    printLog( "Reading $file_name of size $size_left bytes\n" );

    while( $size_left > 0 ) {

        my $read_cnt = sysread( FH, ${$buf_ref},
            $size_left, length ${$buf_ref} ) ;

        unless( $read_cnt ) {

            carp "read error in file $file_name: $!" ;
            last ;
        }

            $size_left -= $read_cnt ;
    }

# handle void context (return scalar by buffer reference)
    return unless defined wantarray ;

# handle list context
    return split m|?<$/|g, ${$buf_ref} if wantarray ;

# handle scalar context
    return ${$buf_ref} ;
}
 
