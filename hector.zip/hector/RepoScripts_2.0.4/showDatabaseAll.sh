#!/bin/bash
echo -n "Enter Database [Default=ALL] > "
read databases
if [ -z "$databases" ] || [ "$databases" == "All" ] || [ "$databases" == "all" ] || [ "$databases" == "ALL" ];then
        echo -n "Enter Pattern > "
        read pattern
        if [ -z "$pattern" ] || [ "$pattern" == "All" ] || [ "$pattern" == "ALL" ] || [ "$pattern" == "all" ]  || [ "$pattern" == "*" ];then
                echo -e "\n`tput setaf 1`Sorry, pattern cannot be All or empty or *. You must use a pattern to search with throughout all databases, else that search will be endless, sorry, use some other tool, Bye`tput sgr0`\n"
                exit
        fi
        while read databases
        do
                echo "`tput setaf 6`======================= Database $databases ===========================`tput sgr0`"
                while read table
                do
                        echo "`tput setaf 3`======================= Table $table ===========================`tput sgr0`"
                        mysql -u root $databases -e "select * from $table;" -vvv | egrep -i "$pattern"
                done < <(echo "show tables;" | mysql -u root $databases | egrep -v Tables)
        done < <(mysql -u root -e "show databases" -s | egrep -v Database | egrep -v sys | egrep -v information_schema | egrep -v performance_schema)
else
        echo -n "Enter Pattern [Default='*'] > "
        read pattern
        echo "`tput setaf 6`======================= Database $databases ===========================`tput sgr0`"
        while read table
        do
                echo "`tput setaf 3`======================= Table $table ===========================`tput sgr0`"
                mysql -u root $databases -e "select * from $table;" -vvv | grep -i "$pattern"
        done < <(mysql -u root $databases -e "show tables;" | egrep -v Tables)
fi