#!/bin/bash
##############################################################################
# Filename:    subscriberMessagesHistoryReport.sh
# Revision:    $Revision: 0.1.0 $
# Author:      Hector Barriga
#
# This sh script displays report outlining the number of messages submitted to
# a given subscriber (MSISDN) in a given time frame
#
# Copyright (c) Tango Telecom 2015
#
# All rights reserved.
# This document contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or
# in part is expressly prohibited, except as may be specifically
# authorized by prior written agreement or permission of Tango Telecom.
##############################################################################
# version 0.1.0 - First version
#
##############################################################################

# Initial Arguments
from_mail="bcm.tango@claro.com.pe"
to_mails="hector.barriga@tangotelecom.com"
display_mail="bcm.tango@claro.com.pe"
smtp_server="172.19.3.102"
today=$(perl -e '@d=localtime time(); printf "__%4d-%02d-%02d\n", $d[5]+1900,$d[4]+1')
todate=$(perl -e '@d=localtime time(); printf "%4d-%02d-%02d\n", $d[5]+1900,$d[4]+1,$d[3]')
dateReport=$(perl -e '@d=localtime time(); printf "%4d/%02d/%02d %02d:%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1]')
lognow=$(perl -e '@d=localtime time(); printf "%4d-%02d-%02d\n", $d[5]+1900,$d[4]+1,$d[3]')
bold=$(tput bold)
normal=$(tput sgr0)

# Subroutines

printLog()
{
echo "[ $timenow ] $1" >> /tango/logs/bcs/subscriberMessagesHistoryReport_$lognow.log
}

headermail()
{
echo "========================================================================================
Report Date: $dateReport
Site                 : Claro Peru
Platform       : BCM
Report           : Subscriber Messages History
msisdn           : $1
From              : $2
To                    : $3
========================================================================================
" >> /tango/logs/stats/bcs/subscriberMessagesHistoryReport_$lognow.txt
}

printReport()
{
echo "$1" >> /tango/logs/stats/bcs/subscriberMessagesHistoryReport_$lognow.txt
}

footermail()
{
echo "

Tango Telecom Ltd.
Customer Operations
+353 872958622 Ireland


#### Tango Telecom Ltd. ####
Registered in Ireland - Number 307010
Registered Office - Walton House, Lonsdale Road, National Technology Park, Limerick, Ireland.
T: +353 61 501900, F: +353 61 501901, W: www.tangotelecom.com, E info@tangotelecom.com

Private, Confidential and Privileged. This e-mail and any files and attachments transmitted with it are confidential and/or privileged. They are intended solely for the use of the intended recipient. The content of this e-mail and any file or attachment transmitted with it may have been changed or altered without the consent of the author. If you are not the intended recipient, please note that any review, dissemination, disclosure, alteration, printing, circulation or transmission of this e-mail and/or any file or attachment transmitted with it, is prohibited and may be unlawful. If you have received this e-mail or any file or attachment transmitted with it in error please notify the sender.  Any views expressed in this message are those of the individual sender and do not necessarily reflect the views of Tango Telecom

" >> /tango/logs/stats/bcs/subscriberMessagesHistoryReport_$lognow.txt
}

sendemail()
{
/usr/bin/perl /tango/scripts/sendMail.pl -f "$from_mail" -t "$to_mails" -n "$display_mail" -s "[ClaroPeru:BCM] Subscriber Messages History for $1 From $2 To $3" -x $smtp_server -a "/bin/cat /tango/logs/stats/bcs/subscriberMessagesHistoryReport_$lognow.txt" -v
}

# Start Script
rm /tango/logs/stats/bcs/subscriberMessagesHistoryReport_*
headermail $1 $2 $3
printLog "---------------------- Start --------------------"
printLog "msisdn = $1 | startdate = $2  |  enddate = $3"

isfoundjobtmp=$(find /tango/scripts/Generic/Others/reports/ -name jobfound.tmp)
if [ ! -z "$isfoundjobtmp" ]; then
        rm /tango/scripts/Generic/Others/reports/jobfound.tmp
        printLog "For some reason /tango/scripts/Generic/Others/reports/jobfound.tmp was there. I just removed it"
fi
countfoundjobsdb=$(ls -altr /tango/scripts/Generic/Others/reports/tmp/ | wc -l)
if [ "$countfoundjobsdb" != "3" ]; then
        rm /tango/scripts/Generic/Others/reports/tmp/*
        printLog "For some reason  /tango/scripts/Generic/Others/reports/tmp/ had files. I just removed them"
fi


#----------------------------------- Exports ----------------------------------------------
i=0
extdate=2000-01-01
while(true); do
        if [[ "$extdate" != $3 ]]; then
                printLog "extdate=$extdate is not $3 . I will get data from backup partition or database "
                extdate=$(date +%Y-%m-%d -d "$2 + $i day")
                getJobfile=$(find /backup/bcs_housekeeping/exports/messages*$extdate.txt -type f | xargs grep -l "$1" | egrep -v "No such file or directory")
                if [ ! -z "$getJobfile" ]; then
                        printLog "$1 was found in /backup/bcs_housekeeping/exports/messages*$extdate.txt"
                        touch /tango/scripts/Generic/Others/reports/jobfound.tmp
                        echo "$getJobfile" >> /tango/scripts/Generic/Others/reports/jobfound.tmp
                        printLog "Adding $getJobfile in /tango/scripts/Generic/Others/reports/jobfound.tmp"
                else
                        printLog "$1 was NOT found in /backup/bcs_housekeeping/exports/messages*$extdate.txt"
                        printLog "I will try to find it in broadcast database"
                        printLog "Selecting id,start_date from jobs where start_date = '$extdate';"
                        getJobIds=$(echo "select id,start_date from jobs where start_date = '$extdate';" | /opt/mysql/bin/mysql -u root -pclaro123 broadcast | egrep -v id)
                        if [ ! -z "$getJobIds" ]; then
                                printLog "The following jobs were found in broadcast database:"
                                printLog "$getJobIds"
                                printLog "Starting a while loop to export messages_xxx and jobs tables where msisdn = $1"

                                echo "$getJobIds" | while read inid; do
                                printLog "While loop > Jobid and start_date = $inid"
                                ext=$(echo $inid | awk '{print $1"_"$2}')
                                jobiddb=$(echo $inid | awk '{print $1}')
                                isitintable=$(echo "select * FROM messages_$jobiddb where destination = '$1';"| /opt/mysql/bin/mysql -u root -pclaro123 broadcast)
                                if [ ! -z "$isitintable" ]; then
                                        printLog "While loop > $1 was found in messages_$jobiddb"
                                        echo "select * into outfile '/tango/scripts/Generic/Others/reports/tmp/messages_$ext.tmp' FIELDS TERMINATED BY '|' LINES TERMINATED BY '\n' FROM messages_$jobiddb where destination = '$1';"| /opt/mysql/bin/mysql -u root -pclaro123 broadcast
                                        printLog "While loop > Exporting messages_$jobiddb where destination = '$1' into /tango/scripts/Generic/Others/reports/tmp/messages_$ext.tmp"
                                        echo "select * into outfile '/tango/scripts/Generic/Others/reports/tmp/jobs_$ext.tmp' FIELDS TERMINATED BY '|' LINES TERMINATED BY '\n' FROM jobs where id = '$jobiddb';"| /opt/mysql/bin/mysql -u root -pclaro123 broadcast
                                        printLog "While loop > Exporting jobs where id = '$jobiddb' into /tango/scripts/Generic/Others/reports/tmp/jobs_$ext.tmp"
                                        getJobfileInDB=$(find /tango/scripts/Generic/Others/reports/tmp/messages_$ext.tmp -type f | xargs grep -l "$1")
                                        printLog "While loop > $1 can now be found in /tango/scripts/Generic/Others/reports/tmp/messages_$ext.tmp"
                                        touch /tango/scripts/Generic/Others/reports/jobfound.tmp
                                        echo "$getJobfileInDB" >> /tango/scripts/Generic/Others/reports/jobfound.tmp
                                        printLog "While loop > Adding $getJobfileInDB in /tango/scripts/Generic/Others/reports/jobfound.tmp"
                                else
                                        printLog "While loop > $1 was NOT found in databases. Next please!"

                                fi
                                done
                                printLog "Finished while loop to export messages_xxx and jobs tables where msisdn = $1"
                        else
                                printLog "No Jobs found in database on $extdate"
                        fi
                fi
                let i=i+1
                printLog "Increment start_date $extdate by 1 day to continue getting data from backup partition or database "

        else
                printLog "Finished getting data from backup partition or database. extdate $extdate is equal to $3 . It is time to display the report "
                countfoundjobs=$(find /tango/scripts/Generic/Others/reports/ -name jobfound.tmp)
                        printLog "I am going to see if any jobs were found in /tango/scripts/Generic/Others/reports/jobfound.tmp"
                if [ ! -z "$countfoundjobs" ]; then
                        printLog "Wow, there are Jobs in $countfoundjobs. I am going to start a while loop to get all data from each job which will be displayed on the final report"
                        catjobfound=$(echo "/bin/cat /tango/scripts/Generic/Others/reports/jobfound.tmp")
                        /bin/cat /tango/scripts/Generic/Others/reports/jobfound.tmp >> /tango/logs/bcs/subscriberMessagesHistoryReport_$lognow.log
                        /bin/cat /tango/scripts/Generic/Others/reports/jobfound.tmp | while read in; do
                                printLog "While loop > Getting message string"
                                if [ ! -z "$getJobfile" ]; then
                                        getJobId=$(ls $in | cut -d_ -f3)
                                        printLog "While loop > Since $1 was found in /backup/bcs_housekeeping/exports/messages_$getJobId, I am going to get the message string"
                                        getMessage=$(/bin/cat /backup/bcs_housekeeping/exports/jobs_$getJobId* |  cut -d'|' -f21)
                                else
                                        getJobId=$(ls $in | cut -d_ -f2)
                                        printLog "While loop > Since $1 was NOT found in /backup/bcs_housekeeping/exports/messages_$getJobId, it must be in /tango/scripts/Generic/Others/reports/tmp/jobs_$getJobId*. Now, I am going to get the message string"
                                        getMessage=$(/bin/cat /tango/scripts/Generic/Others/reports/tmp/jobs_$getJobId* |  cut -d'|' -f21)
                                fi
                                printLog "While loop > Getting Start Date and time, Job status and smpplink"
                                getJobStartDate=$(/bin/cat $in | sed 's/N/NULL/g' | grep $1| cut -d'|' -f8)
                                getJobStartTime=$(/bin/cat $in | sed 's/N/NULL/g' | grep $1| cut -d'|' -f9)
                                getJobstatus=$(/bin/cat $in | grep $1| cut -d'|' -f4)
                                smpplink=$(/bin/cat $in | sed 's/N/NULL/g' | grep $1| cut -d'|' -f6)
                                printReport "-------------------------------------------------------------------------"
                                printReport "| Job Id : $getJobId "
                                printReport "| Start Date and Time : $getJobStartDate $getJobStartTime "
                                printReport "|* Message Status : $getJobstatus "
                                printReport "| SMPP Link : $smpplink "
                                printReport "|  Message : $getMessage"
                                printReport "-------------------------------------------------------------------------"
                                printLog "While loop > -------------------------------------------------------------------------"
                                printLog "While loop > | Job Id : $getJobId"
                                printLog "While loop > | Start Date and Time : $getJobStartDate $getJobStartTime"
                                printLog "While loop > | Message Status : $getJobstatus"
                                printLog "While loop > | SMPP Link : $smpplink"
                                printLog "While loop > | Message : $getMessage"
                                printLog "While loop > -------------------------------------------------------------------------"
                        done
                        rm /tango/scripts/Generic/Others/reports/jobfound.tmp
                        printLog "Removing /tango/scripts/Generic/Others/reports/jobfound.tmp"
                        countfoundjobsdb=$(ls -altr /tango/scripts/Generic/Others/reports/tmp/ | wc -l)
                        if [ "$countfoundjobsdb" != "3" ]; then
                                rm /tango/scripts/Generic/Others/reports/tmp/*
                                printLog "Removing /tango/scripts/Generic/Others/reports/tmp/* "
                        fi
                else
                        printReport "--------------------------------------------------"
                        printReport "| $1 was not found in any Job |"
                        printReport "--------------------------------------------------"
                        printLog "---------------------------------------"
                        printLog "| $1 was not found in any Job |"
                        printLog "---------------------------------------"
                fi
                break
        fi
done

footermail
sendemail $1 $2 $3
printLog "Removing /tango/logs/stats/bcs/subscriberMessagesHistoryReport_$lognow.txt"
printLog "----------------------Finished-----------------------------"