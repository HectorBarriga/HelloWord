#!/usr/bin/perl
##############################################################################
# Filename:    encodeSS7toCAP.pl
# Created by:  mario
# $Revision: 33570 $
# $Author: mario $
#
# This script converts the SCCP_route trace files and SS8 log files into CAP
# files readable by wireshark.
#
# Copyright (c) Tango Telecom 2007
# All rights reserved.
# This file contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or in
# part is expressly prohibited, except as may be specifically authorized
# by prior written agreement or permission of Tango Telecom.
# History:
# 19/10/2007 Creation
# 26/10/2007 Improvement for timestamps
# 10/04/2008 v1.2 Change the datetime for the SS8 stack trace
# 22/07/2008 adding hexdump format option
# 22/04/2009 adding option for changing text2pcap file location
##############################################################################
use Getopt::Std;
use Time::Local;


$WinVer = `ver`;
if ($WinVer =~ /Windows/i)
{
   $path2text2pcap = "text2pcap.exe";
   $catFileCmd     = "type";
   $timefmt        = "\"\%Y\/\%m\/\%d \%H:\%M:\%S.\"";
}
else
{
   $path2text2pcap = "./text2pcap";
   $catFileCmd     = "/bin/cat";
   $timefmt        = "\"\%Y/\%m/\%d \%H:\%M:\%S.\"";
}

%MSG;
$msgNr = 0;
$verbose = 0;
$NI = 3;
$NIhex = "C";

@scriptPath = split '/', $0;
$scriptName = $scriptPath[$#scriptPath];


if ( 0 == getopts( "uhnf:i:t:v" ) )
{
    usage();
    exit 0;
}

if ( defined($opt_i))
{
   $NI = int($opt_i);
}

if ( defined($opt_t))
{
   $path2text2pcap = $opt_t;
}

if ( defined($opt_v))
{
   $verbose = 1;
}

if ( defined($opt_f))
{
   $filePassed = $opt_f;
   ($filename,$fileext) = split /\./, $filePassed;
   if ($fileext eq "cap"){  $filename .= "_enc";}
   @traces = `$catFileCmd $filePassed`;
   $protocol = &EncodeTraces($NI);
   print "===============================================\n";
   print "Output from text2pcap:\n";
   print "----------------------\n";
   $tempStr = "$path2text2pcap -l $protocol -t $timefmt temp.hex $filename.cap\n";
   print $tempStr;
   `$path2text2pcap -l $protocol -t \"\%Y\/\%m\/\%d \%H:\%M:\%S.\" temp.hex $filename.cap`;
   print "===============================================\n";
}

if ( defined($opt_u) )
{
    usage();
    exit 0;
}

if (defined($opt_h) )
{
    usage();
    exit 0;
}


sub usage
{
$tempStr = "$path2text2pcap -l protocol -t \"\%Y\/\%m\/\%d \%H:\%M:\%S.\" temp.hex $filename.cap\n";
    print <<EO_USAGE;

    Help for script encodeSS7toCAP.pl (c) Tango Telecom 2005

    Usage: encodeSS7toCAP.pl

    -f <filename> (SCCP trace of SS7 stack trace to encode)
    -i <network indicator>  (NI for SCCP trace, default is 3. )
    -t path to text2pcap 
    -v     ( for verbose mode)

    Small help for text2pcap
    text2pcap [-l protocol] [-t timestampformat] sourcefile destfile
    -l protocol  (use: man text2pcap on Linux for more info)

EO_USAGE
}

sub EncodeTraces
{
   my $tempNI = shift;
   my $dayseconds = 0;
   my ($Second, $Minute, $Hour, $Day, $Month, $Year) = getTime();
   my $timestampNow = "$Year/$Month/$Day $Hour:$Minute:$Second";
   $prevtimestamp = "";
   if ($tempNI<4)
   {
      $tempNI = &FillLeadingZeros(2,dec2bin($tempNI));
      $NIhex = &bin2hex($tempNI."00");
   }
   my $ss7_log_trace = 0;
   my $sccp_trace = 0;
   @CloseStr  = ( "- - - - - - - - - - - - - - - - - - - - - - -",
                  "---------------------------------------------" );
   my $inDestGT = 0;
   my $inOrigGT = 0;
   my $process = 0;
   my $startUserData = 0;

   my $lastEncoded = 0;
   my $lineNr = 0;
   $chr10 = chr(10);
   $chr13 = chr(13);
   
   foreach $str (@traces)
   {
      $lineNr++;
      $str =~ s/$chr10//g;
      $str =~ s/$chr13//g;
      next if ($str eq "");
      
      if ($str =~ /TangoTimeStamp/)
      #TangoTimeStamp,43599.57,2007/12/07 12:06:39.57
      {
         ($ignore,$dayseconds,$timestamp) = split /\,/ , $str;
         $timestamp =~ s/\n//g;
         next;
      }
      if ($str =~ /^Date:(\s+)(\w+)(\s+)(\w+)(\s+)(\d+)(\s+)(\d+):(\d+):(\d+)(\s+)(\d+)/)
      #Date: Thu May 17 16:22:28 2007
      {
         $startUserData = 0;
         $TSmonthStr = $4;
         $TSmonth = MonthNumber($TSmonthStr);
         $TSday = $6;
         $TShour = $8;
         $TSmin  = $9;
         $TSsec  = $10;
         $TSyear = $12;
         $dayseconds = (int($TShour) * 3600) + (int($TSmin) * 60 )+ $TSsec;
         $timestamp  = "$TSyear/$TSmonth/" . sprintf("%02d", $TSday);
         $timestamp  .= " ". sprintf("%02d", $TShour) .":". sprintf("%02d", $TSmin) .":".sprintf("%02d", $TSsec);
         next;
      }
      if ($str =~ /^\|(\d+):(\d+):(\d+)(\s+)([AP])M/)
      #  |5:21:05 AM,
      {

         $TShour = $1;
         $TShour += 12 if ($5 eq "P");
         $TSmin  = $2;
         $TSsec  = $3;

         $dayseconds = (int($TShour) * 3600) + (int($TSmin) * 60 )+ $TSsec;
         $timestamp  = "$Year/$Month/$Day ";
         $timestamp  .= sprintf("%02d", $TShour) .":". sprintf("%02d", $TSmin) .":".sprintf("%02d", $TSsec);
         next;
      }
      foreach $cstr (@CloseStr)
      {
         if ($str =~ /^$cstr(.*)/)
         {
            $process = 0;
            $sccp_trace = 1;
            $startUserData = 0;
            if (($msgNr > $lastEncoded) && ($MSG{$msgNr}{TCAPdata} ne ""))
            {
               &EncodeSS7message($msgNr);
               $lastEncoded = $msgNr;
            }
         }
      }
      if (($str =~ /SCCP_mtpServer/) && ($pstr =~ /SCCP_route/))
      {
         $process = 1;
         $msgNr++;
         $sccp_trace = 1;
         $MSG{$msgNr}{callingRouteOnGT} = 1;   # route on SSN
         $MSG{$msgNr}{calledRouteOnGT} = 1;    # route on SSN
         if (defined $timestamp)
         {
           $MSG{$msgNr}{dayseconds} = "$dayseconds". sprintf("%06d", $msgNr);
           $MSG{$msgNr}{timestamp} = $timestamp;
         }
         else
         {
           $MSG{$msgNr}{dayseconds} = sprintf("%06d", $msgNr);
           $MSG{$msgNr}{timestamp} = $timestampNow."." . sprintf("%06d", $msgNr);
         }
         printLog ("found: outgoing msg on line:$lineNr");
      }
      if (($str =~ /SCCP_route/) && ($pstr =~ /SCCP_mtpPoll/))
      {
         $process = 1;
         $msgNr++;
         $sccp_trace = 1;
         $MSG{$msgNr}{callingRouteOnGT} = 1;   # route on SSN
         $MSG{$msgNr}{calledRouteOnGT} = 1;    # route on SSN
         if (defined $timestamp)
         {
           $MSG{$msgNr}{dayseconds} = "$dayseconds". sprintf("%06d", $msgNr);
           $MSG{$msgNr}{timestamp} = $timestamp;
         }
         else
         {
           $MSG{$msgNr}{dayseconds} = sprintf("%06d", $msgNr);
           $MSG{$msgNr}{timestamp} = $timestampNow."." . sprintf("%06d", $msgNr);
         }
         printLog ("found: incoming msg on line:$lineNr");
      }
      if ($str =~ /Message-Category:(\s+)SS7 Message/)
      {
        $process = 1;
        $ss7_log_trace = 1;
        $msgNr++;
        if (defined $timestamp)
        {
          if ($timestamp ne $prevtimestamp) {$PacketsInSec = 0;}
          else {$PacketsInSec++;}
          $MSG{$msgNr}{dayseconds} = "$dayseconds". sprintf("%06d", $PacketsInSec);
          $MSG{$msgNr}{timestamp} = $timestamp. ".".sprintf("%06d", $PacketsInSec);
          $prevtimestamp = $timestamp;
        }
        else
        {
          $MSG{$msgNr}{dayseconds} = sprintf("%06d", $msgNr);
          $MSG{$msgNr}{timestamp} = $timestampNow."." . sprintf("%06d", $msgNr);
        }

      }
      if ($str =~ /^\|0(\s+)\|/)
      {
         $hexdump_trace = 1;
         $process = 1;
         $msgNr++;
        if (defined $timestamp)
        {
          if ($timestamp ne $prevtimestamp) {$PacketsInSec = 0;}
          else {$PacketsInSec++;}
          $MSG{$msgNr}{dayseconds} = "$dayseconds". sprintf("%06d", $PacketsInSec);
          $MSG{$msgNr}{timestamp} = $timestamp. ".".sprintf("%06d", $PacketsInSec);
          $prevtimestamp = $timestamp;
        }
        else
        {
          $MSG{$msgNr}{dayseconds} = sprintf("%06d", $msgNr);
          $MSG{$msgNr}{timestamp} = $timestampNow."." . sprintf("%06d", $msgNr);
        }
         printLog ("found hexdump message on the line nr.:$lineNr");         
      }

      $pstr = $str;
      if (! $process)
      {
         next;
      }
      if ($ss7_log_trace)
      {
         if ($startUserData)
         {
            if ($str =~ /(\s+)([(0x\w\w\s)]+)/)
            {
               $tempstr = $2;
               $tempstr =~ s/0x//g;
               $tempstr =~ s/\s//g;
            #   print "adding $msgNr hexdump;";
               $MSG{$msgNr}{SS7msg} .= $tempstr;
            }
            else
            {
               $startUserData = 0;
               $process = 0;

            }
         }
         if ($str =~ /Message-Contents:/)
         {
            $startUserData = 1;
         }
      }
      if ($hexdump_trace)
      {
      
         if ($str =~ /^\|(\w+)(\s*)([(\|\w\w)]+)/)
         {
            $tempstr = $3;
            $tempstr =~ s/\|//g;
            $MSG{$msgNr}{SS7msg} .= $tempstr;   
            #printLog ("for $str  \n <br> it is $tempstr \n<br>"); 
         }
         else
         {
            $process = 0;
         }
      
      }
      
      if ($sccp_trace)
      {
         if (($inDestGT) && ($str =~ /^\s+/))
         {
            $tempstr = $str;
            $tempstr =~ s/\D+//g;
            $MSG{$msgNr}{destGT} .= $tempstr;
            $inDestGT = 0;
         }
         if (($inOrigGT) && ($str =~ /^\s+/))
         {
            $tempstr = $str;
            $tempstr =~ s/\D+//g;
            $MSG{$msgNr}{origGT} .= $tempstr;
            $inOrigGT = 0;
         }
         if ($str =~ /destPointCode(\s+)(\d+)/)
         {
           $MSG{$msgNr}{DPC} = $2;
         }
         if ($str =~ /destSSN(\s+)(\d+)/)
         {
           $MSG{$msgNr}{dSSN} = $2;
         }
         if ($str =~ /destGT(\s+)(.*)/)
         {
            $tempstr = $2;
            $tempstr =~ s/$chr10//;
            $tempstr =~ s/$chr13//;
            $tempstr =~ s/\.//g;
            $tempstr =~ s/\s//g;
            $MSG{$msgNr}{destGT} = $tempstr;
            $inDestGT = 1;
         }
         if ($str =~ /calledRouteOnGT(\s+)(\w+)/)
         {
            $tempstr = $2;
            $MSG{$msgNr}{calledRouteOnGT} = 0 if (uc($tempstr) eq "TRUE");   # route on GT
         }
         if ($str =~ /origPointCode(\s+)(\d+)/)
         {
           $MSG{$msgNr}{OPC} = $2;
         }
         if ($str =~ /origSSN(\s+)(\d+)/)
         {
           $MSG{$msgNr}{oSSN} = $2;
         }

         if ($str =~ /origGT(\s+)(.*)/)
         {
            $tempstr = $2;
            $tempstr =~ s/$chr10//;
            $tempstr =~ s/$chr13//;
            $tempstr =~ s/\.//g;
            $tempstr =~ s/\s//g;
            $MSG{$msgNr}{origGT} = $tempstr;
            $inOrigGT = 1;
         }
         if ($str =~ /callingRouteOnGT(\s+)(\w+)/)
         {
            $tempstr = $2;
            $MSG{$msgNr}{callingRouteOnGT} = 0 if (uc($tempstr) eq "TRUE");   # route on GT
         }
         if ($str =~ /sequenceControl(\s+)(\d+)/)
         {
            $MSG{$msgNr}{SLS} = $2;
         }
         if ($startUserData)
         {
            if ($str =~ /(\s+)([(\w\w\s)]+)\s\s(.*)/)
            {
               $tempstr = $2;
               $tempstr =~ s/\s//g;
               $MSG{$msgNr}{TCAPdata} .= $tempstr;
            }
            else
            {
               $startUserData = 0;
            }
         }
         if ($str =~ /userData(\s+)([(\w\w\s)]+)\s\s(.*)/)
         {
            $tempstr = $2;
            $tempstr =~ s/\s//g;
            $MSG{$msgNr}{TCAPdata} = $tempstr;
            $startUserData = 1;
         }
      }

   }
   if ($sccp_trace && ($msgNr > $lastEncoded) && ($MSG{$msgNr}{TCAPdata} ne ""))
   {
      &EncodeSS7message($msgNr);
   }
   WriteMessages();
   if (($ss7_log_trace) || ($hexdump_trace))
   {
     return 140;
   }
   if ($sccp_trace)
   {
      return 141;
   }
   else
   {
      return 0;
   }
}

sub WriteMessages
{
   open(HEXDUMP,">temp.hex");
   my $write2HexFile = "";
   my $NrCompleteMsgs = 0;
   my $hexValues = "";
   my $destMsg = "";
   my $lastNr = -16;
#   for ($i = 1;$i<=$msgNr; $i++)

   foreach $i (sort { $MSG{$a}{dayseconds} cmp $MSG{$b}{dayseconds}} (keys %MSG)  )
   {
      $msgLen = length ($MSG{$i}{SS7msg});
      if ($msgLen <10) {next;}

      $firstsix = substr ($MSG{$i}{SS7msg},0,6);
      if ($firstsix eq "000000")
      {
         $tempLen = int (($msgLen - 6) / 2);
         if ($tempLen > 255)
         {
            $tempLen = "FF";
         }
         else
         {
            $tempLen = &FillLeadingZeros(2,dec2hex($tempLen));
         }
         $MSG{$i}{SS7msg} = "1213".$tempLen.substr ($MSG{$i}{SS7msg},6,$msgLen-6)  ;
      }
      $tempTimeStamp = $MSG{$i}{timestamp}."\n";
      @tempMsg = split //,$MSG{$i}{SS7msg};
      $hexNr = 0;
      $hexValues = ""; $destMsg = "";
      for ($j=0 ; $j<= $msgLen; $j = $j+2)
      {
        if ((($hexNr % 16) == 0) && ($hexNr > 0) )
        {
           $destMsg .= &FillLeadingZeros(5,dec2hex($hexNr - 16)) .
                       "  " . $hexValues . "   .......__.......\n";
           $hexValues = "";
           $lastNr = $hexNr - 16;
        }
        $hexValues .= $tempMsg[$j].$tempMsg[$j+1]." ";
        $hexNr++;
      }
      if ($hexValues ne "")
      {
         $destMsg .= &FillLeadingZeros(5,dec2hex($lastNr + 16)) .
                  "  " . $hexValues . "   .......__.......\n";
      }
      $write2HexFile .= $tempTimeStamp.$destMsg ."\n\n";
      $NrCompleteMsgs++;
   }
   printLog("Number of complete messages written: $NrCompleteMsgs");
   print HEXDUMP $write2HexFile;
   close (HEXDUMP);
}


sub EncodeSS7message
{
   my $tempNr = shift;
   my $tempval = "";
   my $OPC = $MSG{$tempNr}{OPC};
   my $DPC = $MSG{$tempNr}{DPC};
   my $oSSN = $MSG{$tempNr}{oSSN};
   my $dSSN = $MSG{$tempNr}{dSSN};
   my $SLS = $MSG{$tempNr}{SLS};

   my $origGT = $MSG{$tempNr}{origGT};
   my $destGT = $MSG{$tempNr}{destGT};
   my $callingRouteOnGT = $MSG{$tempNr}{callingRouteOnGT};
   my $calledRouteOnGT = $MSG{$tempNr}{calledRouteOnGT};
   my $TCAPdata = $MSG{$tempNr}{TCAPdata};

   my $opc_bin = dec2bin($OPC);
   my $dpc_bin = dec2bin($DPC);
   my $sls_bin = dec2bin($SLS);

   $opc_bin = &FillLeadingZeros(14,$opc_bin);
   $dpc_bin = &FillLeadingZeros(14,$dpc_bin);
   $sls_bin = &FillLeadingZeros(4,$sls_bin);

   my $mtp3 = $NIhex."3";
   $mtp3 .= bin2hex(substr($dpc_bin,6,4)).bin2hex(substr($dpc_bin,10,4));
   $mtp3 .= bin2hex(substr($opc_bin,12,2).substr($dpc_bin,0,2)).bin2hex(substr($dpc_bin,2,4));
   $mtp3 .= bin2hex(substr($opc_bin,4,4)).bin2hex(substr($opc_bin,8,4));
   $mtp3 .= bin2hex($sls_bin).bin2hex(substr($opc_bin,0,4));
   my $sccp = "090003";

   $tempval = "0".$calledRouteOnGT.  "01";
   my $calledAI = bin2hex($tempval). "2";
   my $calledNAI = "00";
   my $calledNPI = "0";
   $tempval =  substr($destGT,3,1);
   if ($tempval ne "")
   {
      $calledNAI = "0". int($tempval);
   }
   $tempval =  substr($destGT,4,1);
   if ($tempval ne "")
   {
      $calledNPI = int($tempval);
   }

   my $calledGT = substr($destGT,6,length($destGT) - 6);
   ($calledGT,$temp_odd) = &ByteReverse($calledGT);
   my $calledES = $temp_odd;
   my $CalledPartyAddress = "";
   $CalledPartyAddress .= $calledAI;
   $CalledPartyAddress .= FillLeadingZeros(2,dec2hex($dSSN));
   $CalledPartyAddress .= "00"; # Translation Type: 0x00
   $CalledPartyAddress .= $calledNPI;
   $CalledPartyAddress .= $calledES;
   $CalledPartyAddress .= $calledNAI;
   $CalledPartyAddress .= $calledGT;
   $LenCalledPartyAddress = int(length($CalledPartyAddress)/2);

   $tempval = "0".$callingRouteOnGT."01";
   my $callingAI = bin2hex($tempval). "2";
   my $callingNAI = "00";
   my $callingNPI = "0";
   $tempval =  substr($destGT,3,1);
   if ($tempval ne "")
   {
      $callingNAI = "0". int($tempval);
   }
   $tempval =  substr($destGT,4,1);
   if ($tempval ne "")
   {
      $callingNPI = int($tempval);
   }
   my $callingGT = substr($origGT,6,length($origGT) - 6);
   ($callingGT,$temp_odd) = &ByteReverse($callingGT);
   my $callingES = $temp_odd;
   my $CallingPartyAddress = "";
   $CallingPartyAddress .= $callingAI;
   $CallingPartyAddress .= FillLeadingZeros(2,dec2hex($oSSN));
   $CallingPartyAddress .= "00"; # Translation Type: 0x00
   $CallingPartyAddress .= $callingNPI;
   $CallingPartyAddress .= $callingES;
   $CallingPartyAddress .= $callingNAI;
   $CallingPartyAddress .= $callingGT;
   $LenCallingPartyAddress = int(length($CallingPartyAddress)/2);

   $sccp .= &FillLeadingZeros(2,dec2hex($LenCalledPartyAddress + 3));
   $sccp .= &FillLeadingZeros(2,dec2hex($LenCalledPartyAddress + $LenCallingPartyAddress + 3));
   $sccp .= &FillLeadingZeros(2,dec2hex($LenCalledPartyAddress));
   $sccp .= $CalledPartyAddress;
   $sccp .= &FillLeadingZeros(2,dec2hex($LenCallingPartyAddress));
   $sccp .= $CallingPartyAddress;

   $LenTCAPdata = int(length($TCAPdata)/2);
   if ($LenTCAPdata >255)
   {
      #  This case should not happen, only in some bad tracing e.g. GAP in LOG
      $sccp .= "FF";
      $sccp .= substr($TCAPdata,0,255);
   }
   else
   {
      $sccp .= &FillLeadingZeros(2,dec2hex($LenTCAPdata));
      $sccp .= $TCAPdata;
   }
   $MSG{$tempNr}{SS7msg} = $mtp3. $sccp;
}

sub ByteReverse
{
   my $inputstr = shift;
   my @inpArr = split //, $inputstr;
   my $tempGT = "";my $retGT = "";
   my $is_odd = 2;
   for (my $i = 1; $i <= length ($inputstr); $i = $i + 2)
   {
      $tempGT .= $inpArr[$i];
   }
   if ((length ($tempGT) % 2) != 0)
   {
      $tempGT .= "0";   # adding spare 0
      $is_odd = 1;
   }
   @inpArr = split //, $tempGT;
   for ($i = 1; $i <= length ($tempGT); $i = $i + 2)
   {
      $retGT .= $inpArr[$i].$inpArr[$i-1];
   }
   return ($retGT,$is_odd);
}

sub dec2bin {
    my $str = unpack("B32", pack("N", shift));
    $str =~ s/^0+(?=\d)//;   # otherwise you'll get leading zeros
    return $str;
}

sub bin2dec {
    return unpack("N", pack("B32", substr("0" x 32 . shift, -32)));
}

sub dec2hex
{
    my $decnum = shift;
    my $hexnum;
    my $tempval;
    if ($decnum == 0)
    {
       return "0";
    }
    while ($decnum != 0)
    {
       $tempval = $decnum % 16;
       if ($tempval > 9)
       {
          $tempval = chr($tempval + 55);
       }
       $hexnum = $tempval . $hexnum ;
       $decnum = int($decnum / 16);
       if ($decnum < 16)
       {
          if ($decnum > 9)
          {
             $decnum = chr($decnum + 55);
          }
       $hexnum = $decnum . $hexnum;
       $decnum = 0
       }
    }
    if ($hexnum ne "0")
    {
       $hexnum =~ s/^0+//;   # otherwise you'll get leading zeros
    }
    return $hexnum;
}

sub bin2hex
{
  my $binnum = shift;
  my $decnum = (8 * int (substr($binnum,0,1))) +
               (4 * int (substr($binnum,1,1)) ) +
               (2 * int (substr($binnum,2,1)) ) +
               int (substr($binnum,3,1));
  my $hexnum =  dec2hex($decnum);
  return $hexnum;
}

sub FillLeadingZeros
{
   my $DestStrLen = shift;
   my $InputStr = shift;
   my $InputLen = length($InputStr);
   my $ReturnStr = $InputStr;
   for (my $i=1; $i<= $DestStrLen - $InputLen; $i++)
   {
      $ReturnStr = "0" . $ReturnStr;
   }
   return $ReturnStr;
}
sub formatFile
{
   my $fileFormated = shift;
   ($Second, $Minute, $Hour, $Day, $Month, $Year) = getTime();
   $cutYear = substr($Year,2,2);
   $fileFormated =~ s/\%YYYY/$Year/g;
   $fileFormated =~ s/\%YY/$cutYear/g;
   $fileFormated =~ s/\%MM/$Month/g;
   $fileFormated =~ s/\%DD/$Day/g;
   $fileFormated =~ s/\%hh/$Hour/g;
   $fileFormated =~ s/\%mm/$Minute/g;
   $fileFormated =~ s/\%ss/$Second/g;

   $fileFormated =~ s/[\n\|\!\"\£\$\%\^\#\~\[\]\{\}\(\)\&\*\<\>\`]/_/g;
   return  $fileFormated;
}

sub printLog
{
   my $text = shift;
   if (! $verbose) {return 0;}
   $text .= "\n";
   if ($html)
   {
     $text .= "<BR>";
   }
   print "$text";
}
##############################################################################
# getTime()
# will return the curent date and time
##############################################################################
sub getTime
{
   ($Second, $Minute, $Hour, $Day, $Month, $Year, $ignore, $ignore, $ignore) = localtime(time);

   if($Hour < 10)   {  $Hour = "0" . $Hour ; }
   if($Minute < 10) {  $Minute = "0" . $Minute ; }
   if($Second < 10) {  $Second = "0" . $Second ; }
   my $Month = $Month + 1 ;
   if($Month < 10)
   {
      $Month = "0" .
      $Month ;
   }
   if($Day < 10)
   {
      $Day = "0" . $Day ;
   }
   if($Year >= 100)
   {
      $Year = $Year - 100 ;
      $Year = $Year + 2000;
   }
   return  ($Second, $Minute, $Hour, $Day, $Month, $Year);
}
sub MonthNumber
{
   $inpMon = shift;
   $retStr = "00";
   if ($inpMon eq "Jan") {$retStr =  "01";}
   if ($inpMon eq "Feb") {$retStr =  "02";}
   if ($inpMon eq "Mar") {$retStr =  "03";}
   if ($inpMon eq "Apr") {$retStr =  "04";}
   if ($inpMon eq "May") {$retStr =  "05";}
   if ($inpMon eq "Jun") {$retStr =  "06";}
   if ($inpMon eq "Jul") {$retStr =  "07";}
   if ($inpMon eq "Aug") {$retStr =  "08";}
   if ($inpMon eq "Sep") {$retStr =  "09";}
   if ($inpMon eq "Oct") {$retStr =  "10";}
   if ($inpMon eq "Nov") {$retStr =  "11";}
   if ($inpMon eq "Dec") {$retStr =  "12";}
   return $retStr;
}
1;
