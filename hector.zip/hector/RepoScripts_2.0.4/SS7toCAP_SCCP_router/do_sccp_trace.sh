echo "Copy next line into your clipboard, then paste it when staring SCCP trace: "
echo "add SCCP_route"
echo "When finished type: quit [Enter]"
echo "                                           Now press Enter ..."
read a
/tango/scripts/add_times.pl &
telnet 0 14070
kill %-
echo "Now you have to copy the trace and paste it into SS7toCAP encoder."
echo "You can copy and paste the traces from more machines, they will be sorted by time." 
