#!/usr/bin/perl
##############################################################################
# Filename:    add_times.pl
# Created by:  mario
# $Revision: 0 $
# $Author: mario $
# $LastChangedDate: 2007-10-03 01:11:06 +0100 (Wed, 03 Oct 2007) $
#
# This script is used to put timestamps into the SCCP_route trace
# The trace is then prepared for encodeSS7toCAP.pl for encoding it into the CAP file 
# readable by Wireshark
#
# Copyright (c) Tango Telecom 2007
# All rights reserved.
# This file contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or in
# part is expressly prohibited, except as may be specifically authorized
# by prior written agreement or permission of Tango Telecom.
# History:
# 06/12/2007 Creation
##############################################################################
use Time::HiRes qw(sleep gettimeofday);
use Time::Local;
$i=0;
$diff = 0.2;
$ddiff = $diff - 0.01;
while (1)
{
   ($Second, $Minute, $Hour, $Day, $Month, $Year) = getTime();
   $timesec = (int($Hour) * 3600) + (int($Minute) * 60 )+ $Second;
   if ($timesec == $prevtimesec)
   {
      $mili_sec = $mili_sec + $ddiff;
   }
   else
   {
      $output_sec = $timesec;
      $mili_sec = 0;
   }
   $secIncMili = sprintf ("%.2f", $Second + $mili_sec);
   $output_secStr = sprintf ("%.2f", $output_sec + $mili_sec);
   
   print "\n\#TangoTimeStamp,$output_secStr,$Year/$Month/$Day $Hour:$Minute:$secIncMili\n";
   $prevtimesec = $timesec;
   sleep($diff);
}



##############################################################################
# getTime()
# will return the curent date and time
##############################################################################
sub getTime
{
   ($Second, $Minute, $Hour, $Day, $Month, $Year, $ignore, $ignore, $ignore) = localtime(time);

   if($Hour < 10)   {  $Hour = "0" . $Hour ; }
   if($Minute < 10) {  $Minute = "0" . $Minute ; }
   if($Second < 10) {  $Second = "0" . $Second ; }
   my $Month = $Month + 1 ;
   if($Month < 10)
   {
      $Month = "0" . $Month ;
   }
   if($Day < 10)
   {
      $Day = "0" . $Day ;
   }
   if($Year >= 100)
   {
      $Year = $Year - 100 ;
      $Year = $Year + 2000;
   }
   return  ($Second, $Minute, $Hour, $Day, $Month, $Year);
}
