#!/bin/bash

##############################################################################
# Filename:    PMUI_ManageLists_scp_blackwhitelists.sh
# Revision:    0.1.0
# Author:      Hector Barriga
#
# Jiras:
# CO Internal: COIT-18947
#
# This sh script will gather blackwhitelists from machines where CMGR/PMUI run and compare to spot missing or obsoleted lists
# It transfers missing files to or from remote machine
# It checks CMGR logs and if it spots file has been deleted, it will not transfer from machine where it still remains but instead
# will move it to /tango/data/campaignmanager/deleted/ (scripts creates that directory if it is not there)
#
# This sh script is mainly used for Tango  CO internal  monitoring
# Copyright (c) Tango Telecom 2018
#
# All rights reserved.
# This document contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or
# in part is expressly prohibited, except as may be specifically
# authorized by prior written agreement or permission of Tango Telecom.
##############################################################################
# version 0.1.0 - First version
version="0.1.0"
#
##############################################################################


# Get Remote IP
NginxPMUI_IPs=$(cat /etc/nginx/conf.d/tomcat-basic.conf  | grep 8200 | egrep -v "#" | cut -d":" -f1 | cut -d":" -f1 | awk '{print $2}')
while read IP
do
        isIPonLocalMachine=$(/usr/sbin/ip addr | grep "$IP")
        if [ -z "$isIPonLocalMachine" ];then
                remoteIP=$IP
                break
        fi
done <<< "$NginxPMUI_IPs"

# To avoid local and remote machines to get missing files simulatenouslly (if crontab jobs are schedule at the same time), delay if local hostid grater than remote hostid
LocalHostId=$(hostid)
RemHostId=$(ssh tango@$remoteIP "hostid")
if [ "$LocalHostId" \> "$RemHostId" ];then
        echo "Delay of 10 secs ..."
        sleep 10
fi

# Compare to detect missing files
LocalBlackwhitelistsDir=$(cat /tango/config/bulk_import/biiManageLists.cfg | grep "listFilePath" | cut -d"=" -f2 | tr -d " ")
cd $LocalBlackwhitelistsDir
cd ..
LocalDeletedBlackwhitelistsDir=$(pwd)
if [ ! -d "$LocalDeletedBlackwhitelistsDir/deleted" ];then
        mkdir $LocalDeletedBlackwhitelistsDir/deleted
fi
LocalBlackwhitelists=$(ls -altr $LocalBlackwhitelistsDir | grep "_read" | awk '{print $9}')
RemBlackwhitelistsDir=$(ssh tango@$remoteIP 'cat /tango/config/bulk_import/biiManageLists.cfg | grep "listFilePath" | cut -d"=" -f2 | tr -d " "')
RemBlackwhitelists=$(ssh tango@$remoteIP "ls -altr $RemBlackwhitelistsDir | grep '_read' | awk '{print \$9}'")
FilesToSend=$(diff <( echo "$LocalBlackwhitelists" ) <( echo "$RemBlackwhitelists" ) | grep "<" | cut -d"<" -f2 | tr -d " ")
FilesToGet=$(diff <( echo "$LocalBlackwhitelists" ) <( echo "$RemBlackwhitelists" ) | grep ">" | cut -d">" -f2 | tr -d " ")

# Transfer if needed and if it hasnt been deleted via PMUI
if [ ! -z "$FilesToSend" ];then
        while read scpFileToSend
        do
                hasListBeenDeletedLocal=$(cat /tango/logs/cmgr/campaign-manager-controller.log | grep "Deleting list file" | grep "$scpFileToSend")
                hasListBeenDeletedRem=$(ssh tango@$remoteIP "cat /tango/logs/cmgr/campaign-manager-controller.log | grep 'Deleting list file' | grep '$scpFileToSend'" < /dev/null)
                if [ -z "$hasListBeenDeletedLocal" ] && [ -z "$hasListBeenDeletedRem" ];then
                        scp $LocalBlackwhitelistsDir/$scpFileToSend tango@$remoteIP:$RemBlackwhitelistsDir/
                fi
                if [ ! -z "$hasListBeenDeletedRem" ];then
                        mv $LocalBlackwhitelistsDir/$scpFileToSend $LocalDeletedBlackwhitelistsDir/deleted/
                fi
        done <<< "$FilesToSend"
fi
if [ ! -z "$FilesToGet" ];then
        while read scpFileToGet
        do
                hasListBeenDeletedLocal=$(cat /tango/logs/cmgr/campaign-manager-controller.log | grep "Deleting list file" | grep "$scpFileToGet")
                hasListBeenDeletedRem=$(cat /tango/logs/cmgr/campaign-manager-controller.log | grep "Deleting list file" | grep "$scpFileToGet" | ssh tango@$remoteIP 2> /dev/null)
                if [ -z "$hasListBeenDeletedLocal" ] && [ -z "$hasListBeenDeletedRem" ];then
                        scp tango@$remoteIP:$RemBlackwhitelistsDir/$scpFileToGet $LocalBlackwhitelistsDir/.
                fi
        done <<< "$FilesToGet"
fi