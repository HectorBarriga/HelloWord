#!/bin/bash

help()
{
echo "
        Usage: restartLogstashFilebeat.sh

        This sh script is to start, shutdown or check status for Logstash 6.2.3 and Filebeat 6.2.3

        Version:     0.1.0
        Author:      Hector Barriga
        Copyright (c) Tango Telecom 2020

               Flags:
               Notes: These are flags, so not need to add arguments

               -h <help>           Show help

               -s <Shutdown>       Shutdown all ELK services

               -r <Restart>        Restart all ELK services

               -c <Check Status>   Check status of all ELK services

               -m <move logs>      Move all ELK logs under /tango/logs/COSTAFF/trash/


               Examples:

               e.g. restartLogstashFilebeat.sh -s
                    It shuts down Logstash and Filebeat
"
}

delay()
{
for (( i=0;i<=$1;i++ ))
do
        echo -n "* "
        sleep 1
done
echo -e "Done\n"
}

if [ "$1" == "-s" ];then
        echo -e "`tput setaf 6`\n====================================== Shutting Down Filebeat ======================================"
        echo -e "`tput setaf 3`---------------------- NH1 --------------------\n`tput setaf 2`ssh IPXMIATCNH1 \"sudo systemctl stop filebeat\""
        ssh IPXMIATCNH1 "sudo systemctl stop filebeat"
        echo -e "`tput setaf 3`---------------------- NH2 --------------------\n`tput setaf 2`ssh IPXMIATCNH2 \"sudo systemctl stop filebeat\""
        ssh IPXMIATCNH2 "sudo systemctl stop filebeat"
        echo -e "`tput setaf 3`---------------------- RTE1 --------------------\n`tput setaf 2`ssh IPXMIATCRTE1 \"sudo systemctl stop filebeat\""
        ssh IPXMIATCRTE1 "sudo systemctl stop filebeat"
        echo -e "`tput setaf 3`---------------------- RTE2 --------------------\n`tput setaf 2`ssh IPXMIATCRTE2 \"sudo systemctl stop filebeat\""
        ssh IPXMIATCRTE2 "sudo systemctl stop filebeat"
        echo -e "`tput setaf 3`---------------------- SPCM1 --------------------\n`tput setaf 2`ssh IPXMIATCSPCM1 \"sudo systemctl stop filebeat\""
        ssh IPXMIATCSPCM1 "sudo systemctl stop filebeat"
        echo -e "`tput setaf 3`---------------------- SPCM2 --------------------\n`tput setaf 2`ssh IPXMIATCSPCM2 \"sudo systemctl stop filebeat\""
        ssh IPXMIATCSPCM2 "sudo systemctl stop filebeat"
        echo -e "`tput setaf 3`---------------------- GTP1 --------------------\n`tput setaf 2`ssh IPXMIATCGTP1 \"sudo systemctl stop filebeat\""
        ssh IPXMIATCGTP1 "sudo systemctl stop filebeat"
        echo -e "`tput setaf 3`---------------------- GTP2 --------------------\n`tput setaf 2`ssh IPXMIATCGTP2 \"sudo systemctl stop filebeat\""
        ssh IPXMIATCGTP2 "sudo systemctl stop filebeat"
        echo -e "`tput setaf 3`---------------------- GTP3 --------------------\n`tput setaf 2`ssh IPXMIATCGTP3 \"sudo systemctl stop filebeat\""
        ssh IPXMIATCGTP3 "sudo systemctl stop filebeat"
        echo -e "`tput setaf 3`---------------------- GTP4 --------------------\n`tput setaf 2`ssh IPXMIATCGTP4 \"sudo systemctl stop filebeat\""
        ssh IPXMIATCGTP4 "sudo systemctl stop filebeat"
        echo -e "`tput setaf 3`---------------------- GTP5 --------------------\n`tput setaf 2`ssh IPXMIATCGTP5 \"sudo systemctl stop filebeat\""
        ssh IPXMIATCGTP5 "sudo systemctl stop filebeat"
        echo -e "`tput setaf 3`---------------------- GTP6 --------------------\n`tput setaf 2`ssh IPXMIATCGTP6 \"sudo systemctl stop filebeat\""
        ssh IPXMIATCGTP6 "sudo systemctl stop filebeat"
        echo -e "`tput setaf 6`\n====================================== Shutting Down Logstash ======================================"
        echo -e "`tput setaf 3`---------------------- RTE1 --------------------\n`tput setaf 2`sudo systemctl stop logstash"
        sudo systemctl stop logstash
        echo -e "`tput setaf 3`---------------------- RTE2 --------------------\n`tput setaf 2`ssh IPXMIATCRTE2 \"sudo systemctl stop logstash\""
        ssh IPXMIATCRTE2 "sudo systemctl stop logstash"
        echo "`tput sgr0`"
elif [ "$1" == "-r" ];then
        echo -e "`tput setaf 6`\n=================================== Restarting Logstash =================================="
        echo -e "`tput setaf 3`---------------------- RTE1 --------------------\n`tput setaf 2`sudo systemctl start logstash"
        sudo systemctl start logstash
        RTE1LogstashPort5044=$(netstat -an | grep ":5044 " | egrep -v 172.19.1.57 | egrep -v 172.19.1.58 | wc -l)
        while [ $RTE1LogstashPort5044 -eq 0 ]
        do
                echo -n "* "
                RTE1LogstashPort5044=$(netstat -an | grep ":5044 " | egrep -v 172.19.1.57 | egrep -v 172.19.1.58 | wc -l)
                sleep 1
        done
        echo -e "Done\n"
        echo -e "`tput setaf 3`---------------------- RTE2 --------------------\n`tput setaf 2`ssh IPXMIATCRTE2 \"sudo systemctl start logstash\""
        ssh IPXMIATCRTE2 "sudo systemctl start logstash"
        RTE2LogstashPort5044=$(ssh IPXMIATCRTE2 'netstat -an | grep ":5044 "' | egrep -v 172.19.1.57 | egrep -v 172.19.1.58 | wc -l)
        while [ $RTE2LogstashPort5044 -eq 0 ]
        do
                echo -n "* "
                RTE2LogstashPort5044=$(ssh IPXMIATCRTE2 'netstat -an | grep ":5044 "' | egrep -v 172.19.1.57 | egrep -v 172.19.1.58 | wc -l)
                sleep 1
        done
        echo -e "Done\n"
        delay 10
        echo "`tput setaf 6`=================================== Restarting Filebeat =================================="
        echo -e "`tput setaf 3`---------------------- NH1 --------------------\n`tput setaf 2`ssh IPXMIATCNH1 \"sudo systemctl start filebeat\""
        ssh IPXMIATCNH1 "sudo systemctl start filebeat"
        delay 1
        echo -e "`tput setaf 3`---------------------- NH2 --------------------\n`tput setaf 2`ssh IPXMIATCNH2 \"sudo systemctl start filebeat\""
        ssh IPXMIATCNH2 "sudo systemctl start filebeat"
        delay 1
        echo -e "`tput setaf 3`---------------------- RTE1 --------------------\n`tput setaf 2`ssh IPXMIATCRTE1 \"sudo systemctl start filebeat\""
        ssh IPXMIATCRTE1 "sudo systemctl start filebeat"
        delay 1
        echo -e "`tput setaf 3`---------------------- RTE2 --------------------\n`tput setaf 2`ssh IPXMIATCRTE2 \"sudo systemctl start filebeat\""
        ssh IPXMIATCRTE2 "sudo systemctl start filebeat"
        delay 1
        echo -e "`tput setaf 3`---------------------- SPCM1 --------------------\n`tput setaf 2`ssh IPXMIATCSPCM1 \"sudo systemctl start filebeat\""
        ssh IPXMIATCSPCM1 "sudo systemctl start filebeat"
        delay 1
        echo -e "`tput setaf 3`---------------------- SPCM2 --------------------\n`tput setaf 2`ssh IPXMIATCSPCM2 \"sudo systemctl start filebeat\""
        ssh IPXMIATCSPCM2 "sudo systemctl start filebeat"
        delay 1
        echo -e "`tput setaf 3`---------------------- GTP1 --------------------\n`tput setaf 2`ssh IPXMIATCGTP1 \"sudo systemctl start filebeat\""
        ssh IPXMIATCGTP1 "sudo systemctl start filebeat"
        delay 1
        echo -e "`tput setaf 3`---------------------- GTP2 --------------------\n`tput setaf 2`ssh IPXMIATCGTP2 \"sudo systemctl start filebeat\""
        ssh IPXMIATCGTP2 "sudo systemctl start filebeat"
        delay 1
        echo -e "`tput setaf 3`---------------------- GTP3 --------------------\n`tput setaf 2`ssh IPXMIATCGTP3 \"sudo systemctl start filebeat\""
        ssh IPXMIATCGTP3 "sudo systemctl start filebeat"
        delay 1
        echo -e "`tput setaf 3`---------------------- GTP4 --------------------\n`tput setaf 2`ssh IPXMIATCGTP4 \"sudo systemctl start filebeat\""
        ssh IPXMIATCGTP4 "sudo systemctl start filebeat"
        delay 1
        echo -e "`tput setaf 3`---------------------- GTP5 --------------------\n`tput setaf 2`ssh IPXMIATCGTP5 \"sudo systemctl start filebeat\""
        ssh IPXMIATCGTP5 "sudo systemctl start filebeat"
        delay 1
        echo -e "`tput setaf 3`---------------------- GTP6 --------------------\n`tput setaf 2`ssh IPXMIATCGTP6 \"sudo systemctl start filebeat\""
        ssh IPXMIATCGTP6 "sudo systemctl start filebeat"
        delay 10
        echo "`tput sgr0`"
elif [ "$1" == "-c" ];then
        echo "`tput setaf 6`====================================== Check Logstash ======================================"
        RTE1LogstashStatus=$(sudo systemctl status logstash | grep Active | grep running)
        RTE1LogstashPort5044=$(netstat -an | grep ":5044 ")
        if [ -z "$RTE1LogstashStatus" ] || [ -z "$RTE1LogstashPort5044" ];then echo "`tput setaf 3`---- RTE1-Logstash `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- RTE1-Logstash `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";LAcc1=yes;fi
        sudo systemctl status logstash
        RTE2LogstashPort5044=$(ssh IPXMIATCRTE2 'netstat -an | grep ":5044 "')
        RTE2LogstashStatus=$(ssh IPXMIATCRTE2 "sudo systemctl status logstash" | grep Active | grep running)
        if [ -z "$RTE2LogstashStatus" ] || [ -z "$RTE2LogstashPort5044" ];then echo "`tput setaf 3`---- RTE2-Logstash `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- RTE2-Logstash `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";LAcc2=yes;fi
        ssh IPXMIATCRTE2 "sudo systemctl status logstash"
        echo "`tput setaf 6`====================================== Check Filebeat ======================================"
        NH1FilebeatStatus=$(ssh IPXMIATCNH1 "sudo systemctl status filebeat" | grep Active | grep running)
        if [ -z "$NH1FilebeatStatus" ];then echo "`tput setaf 3`---- NH1-Filebeat `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- NH1-Filebeat `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";FAcc1=yes;fi
        ssh IPXMIATCNH1 "sudo systemctl status filebeat"
        NH2FilebeatStatus=$(ssh IPXMIATCNH2 "sudo systemctl status filebeat" | grep Active | grep running)
        if [ -z "$NH2FilebeatStatus" ];then echo "`tput setaf 3`---- NH2-Filebeat `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- NH2-Filebeat `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";FAcc2=yes;fi
        ssh IPXMIATCNH2 "sudo systemctl status filebeat"
        RTE1FilebeatStatus=$(ssh IPXMIATCRTE1 "sudo systemctl status filebeat" | grep Active | grep running)
        if [ -z "$RTE1FilebeatStatus" ];then echo "`tput setaf 3`---- RTE1-Filebeat `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- RTE1-Filebeat `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";FAcc3=yes;fi
        ssh IPXMIATCRTE1 "sudo systemctl status filebeat"
        RTE2FilebeatStatus=$(ssh IPXMIATCRTE2 "sudo systemctl status filebeat" | grep Active | grep running)
        if [ -z "$RTE2FilebeatStatus" ];then echo "`tput setaf 3`---- RTE2-Filebeat `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- RTE2-Filebeat `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";FAcc4=yes;fi
        ssh IPXMIATCRTE2 "sudo systemctl status filebeat"
        SPCM1FilebeatStatus=$(ssh IPXMIATCSPCM1 "sudo systemctl status filebeat" | grep Active | grep running)
        if [ -z "$SPCM1FilebeatStatus" ];then echo "`tput setaf 3`---- SPCM1-Filebeat `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- SPCM1-Filebeat `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";FAcc7=yes;fi
        ssh IPXMIATCSPCM1 "sudo systemctl status filebeat"
        SPCM2FilebeatStatus=$(ssh IPXMIATCSPCM2 "sudo systemctl status filebeat" | grep Active | grep running)
        if [ -z "$SPCM2FilebeatStatus" ];then echo "`tput setaf 3`---- SPCM2-Filebeat `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- SPCM2-Filebeat `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";FAcc8=yes;fi
        ssh IPXMIATCSPCM2 "sudo systemctl status filebeat"
        GTP1FilebeatStatus=$(ssh IPXMIATCGTP1 "sudo systemctl status filebeat" | grep Active | grep running)
        if [ -z "$GTP1FilebeatStatus" ];then echo "`tput setaf 3`---- GTP1-Filebeat `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- GTP1-Filebeat `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";FAcc9=yes;fi
        ssh IPXMIATCGTP1 "sudo systemctl status filebeat"
        GTP2FilebeatStatus=$(ssh IPXMIATCGTP2 "sudo systemctl status filebeat" | grep Active | grep running)
        if [ -z "$GTP2FilebeatStatus" ];then echo "`tput setaf 3`---- GTP2-Filebeat `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- GTP2-Filebeat `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";FAcc10=yes;fi
        ssh IPXMIATCGTP2 "sudo systemctl status filebeat"
        GTP3FilebeatStatus=$(ssh IPXMIATCGTP3 "sudo systemctl status filebeat" | grep Active | grep running)
        if [ -z "$GTP3FilebeatStatus" ];then echo "`tput setaf 3`---- GTP3-Filebeat `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- GTP3-Filebeat `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";FAcc11=yes;fi
        ssh IPXMIATCGTP3 "sudo systemctl status filebeat"
        GTP4FilebeatStatus=$(ssh IPXMIATCGTP4 "sudo systemctl status filebeat" | grep Active | grep running)
        if [ -z "$GTP4FilebeatStatus" ];then echo "`tput setaf 3`---- GTP4-Filebeat `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- GTP4-Filebeat `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";FAcc12=yes;fi
        ssh IPXMIATCGTP4 "sudo systemctl status filebeat"
        GTP5FilebeatStatus=$(ssh IPXMIATCGTP5 "sudo systemctl status filebeat" | grep Active | grep running)
        if [ -z "$GTP5FilebeatStatus" ];then echo "`tput setaf 3`---- GTP5-Filebeat `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- GTP5-Filebeat `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";FAcc13=yes;fi
        ssh IPXMIATCGTP5 "sudo systemctl status filebeat"
        GTP6FilebeatStatus=$(ssh IPXMIATCGTP6 "sudo systemctl status filebeat" | grep Active | grep running)
        if [ -z "$GTP6FilebeatStatus" ];then echo "`tput setaf 3`---- GTP6-Filebeat `tput setaf 1` DEAD `tput setaf 3`----`tput sgr0`";else echo "`tput setaf 3`---- GTP6-Filebeat `tput setaf 2` ACTIVE RUNNING `tput setaf 3`----`tput sgr0`";FAcc14=yes;fi
        ssh IPXMIATCGTP6 "sudo systemctl status filebeat"

        echo -e "`tput setaf 6`\n====================================== FINISHED ======================================"
        if [ "$LAcc1" == "yes" ] && [ "$LAcc2" == "yes" ] && [ "$FAcc1" == "yes" ] &&  [ "$FAcc2" == "yes" ] && [ "$FAcc3" == "yes" ] && [ "$FAcc4" == "yes" ] && [ "$FAcc7" == "yes" ] && [ "$FAcc8" == "yes" ] && [ "$FAcc9" == "yes" ] && [ "$FAcc10" == "yes" ] && [ "$FAcc11" == "yes" ] && [ "$FAcc12" == "yes" ] && [ "$FAcc13" == "yes" ] && [ "$FAcc14" == "yes" ];then
                echo "`tput sgr0`[`tput setaf 2`OK`tput sgr0`] ALL Logstash ARE `tput setaf 2`ACTIVE AND RUNNING"
                echo "[`tput setaf 2`OK`tput sgr0`] ALL Filebeats ARE `tput setaf 2`ACTIVE AND RUNNING"
        else
                echo "`tput setaf 1`SOME OR ALL SERVICESts AND Logstash ARE INACTIVE AND DEAD"
        fi
        echo "`tput setaf 6`======================================================================================"
        echo "`tput sgr0`"
elif [ "$1" == "-m" ];then
        amiroot=$(whoami)
        if [ "$amiroot" != "root" ];then
                echo -e "\n`tput setaf 1`Sorry, restartELK7.4.0.sh -m must be run as root user, bye.`tput sgr0`\n"
        fi
        todayExt=$(perl -e '@d=localtime time(); printf "%4d%02d%02d_%02d%02d%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1],$d[0]')
        echo "`tput setaf 6`====================================== Check Logstash ======================================"
        RTE1LogstashStatus=$(systemctl status logstash | grep Active | grep running)
        RTE1LogstashPort5044=$(netstat -an | grep ":5044 ")
        if [ -z "$RTE1LogstashStatus" ] || [ -z "$RTE1LogstashPort5044" ];then echo "`tput setaf 3`---- RTE1-Logstash `tput setaf 2` mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/logstash/;mv /var/log/logstash/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/logstash/ `tput setaf 3`----`tput sgr0`";mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/logstash/;mv /var/log/logstash/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/logstash/;else echo "`tput setaf 3`---- RTE1-Logstash `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";LAcc1=yes;fi

        RTE2LogstashPort5044=$(ssh IPXMIATCRTE2 'netstat -an | grep ":5044 "')
        RTE2LogstashStatus=$(ssh IPXMIATCRTE2 "systemctl status logstash" | grep Active | grep running)
        if [ -z "$RTE2LogstashStatus" ] || [ -z "$RTE2LogstashPort5044" ];then echo "`tput setaf 3`---- RTE2-Logstash `tput setaf 2` ssh IPXMIATCRTE2 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/logstash/;mv /var/log/logstash/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/logstash/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCRTE2 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/logstash/;mv /var/log/logstash/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/logstash/";else echo "`tput setaf 3`---- RTE2-Logstash `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";LAcc2=yes;fi


        echo "`tput setaf 6`====================================== Check Filebeat ======================================"
        NH1FilebeatStatus=$(ssh IPXMIATCNH1 "systemctl status filebeat" | grep Active | grep running)
        if [ -z "$NH1FilebeatStatus" ];then echo "`tput setaf 3`---- NH1-Filebeat `tput setaf 2` ssh IPXMIATCNH1 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/;mv /var/log/filebeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCNH1 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/;mv /var/log/filebeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/";else echo "`tput setaf 3`---- NH1-Filebeat `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";FAcc1=yes;fi

        NH2FilebeatStatus=$(ssh IPXMIATCNH2 "systemctl status filebeat" | grep Active | grep running)
        if [ -z "$NH2FilebeatStatus" ];then echo "`tput setaf 3`---- NH2-Filebeat `tput setaf 2` ssh IPXMIATCNH2 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/;mv /var/log/filebeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCNH2 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/;mv /var/log/filebeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/";else echo "`tput setaf 3`---- NH2-Filebeat `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";FAcc2=yes;fi

        RTE1FilebeatStatus=$(ssh IPXMIATCRTE1 "systemctl status filebeat" | grep Active | grep running)
        if [ -z "$RTE1FilebeatStatus" ];then echo "`tput setaf 3`---- RTE1-Filebeat `tput setaf 2` ssh IPXMIATCRTE1 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/;mv /var/log/filebeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCRTE1 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/;mv /var/log/filebeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/";else echo "`tput setaf 3`---- RTE1-Filebeat `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";FAcc3=yes;fi

        RTE2FilebeatStatus=$(ssh IPXMIATCRTE2 "systemctl status filebeat" | grep Active | grep running)
        if [ -z "$RTE2FilebeatStatus" ];then echo "`tput setaf 3`---- RTE2-Filebeat `tput setaf 2` ssh IPXMIATCRTE2 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/;mv /var/log/filebeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCRTE2 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/;mv /var/log/filebeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/";else echo "`tput setaf 3`---- RTE2-Filebeat `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";FAcc4=yes;fi

        SPCM1FilebeatStatus=$(ssh IPXMIATCSPCM1 "systemctl status filebeat" | grep Active | grep running)
        if [ -z "$SPCM1FilebeatStatus" ];then echo "`tput setaf 3`---- SPCM1-Filebeat `tput setaf 2` ssh IPXMIATCSPCM1 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/;mv /var/log/filebeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCSPCM1 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/;mv /var/log/filebeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/";else echo "`tput setaf 3`---- SPCM1-Filebeat `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";FAcc7=yes;fi

        SPCM2FilebeatStatus=$(ssh IPXMIATCSPCM2 "systemctl status filebeat" | grep Active | grep running)
        if [ -z "$SPCM2FilebeatStatus" ];then echo "`tput setaf 3`---- SPCM2-Filebeat `tput setaf 2` ssh IPXMIATCSPCM2 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/;mv /var/log/filebeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCSPCM2 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/;mv /var/log/filebeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/";else echo "`tput setaf 3`---- SPCM2-Filebeat `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";FAcc8=yes;fi

        GTP1FilebeatStatus=$(ssh IPXMIATCGTP1 "systemctl status filebeat" | grep Active | grep running)
        if [ -z "$GTP1FilebeatStatus" ];then echo "`tput setaf 3`---- GTP1-Filebeat `tput setaf 2` ssh IPXMIATCGTP1 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/;mv /var/log/filebeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCGTP1 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/;mv /var/log/filebeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/";else echo "`tput setaf 3`---- GTP1-Filebeat `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";FAcc9=yes;fi

        GTP2FilebeatStatus=$(ssh IPXMIATCGTP2 "systemctl status filebeat" | grep Active | grep running)
        if [ -z "$GTP2FilebeatStatus" ];then echo "`tput setaf 3`---- GTP2-Filebeat `tput setaf 2` ssh IPXMIATCGTP2 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/;mv /var/log/filebeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCGTP2 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/;mv /var/log/filebeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/";else echo "`tput setaf 3`---- GTP2-Filebeat `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";FAcc10=yes;fi

        GTP3FilebeatStatus=$(ssh IPXMIATCGTP3 "systemctl status filebeat" | grep Active | grep running)
        if [ -z "$GTP3FilebeatStatus" ];then echo "`tput setaf 3`---- GTP3-Filebeat `tput setaf 2` ssh IPXMIATCGTP3 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/;mv /var/log/filebeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCGTP3 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/;mv /var/log/filebeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/";else echo "`tput setaf 3`---- GTP3-Filebeat `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";FAcc11=yes;fi

        GTP4FilebeatStatus=$(ssh IPXMIATCGTP4 "systemctl status filebeat" | grep Active | grep running)
        if [ -z "$GTP4FilebeatStatus" ];then echo "`tput setaf 3`---- GTP4-Filebeat `tput setaf 2` ssh IPXMIATCGTP4 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/;mv /var/log/filebeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCGTP4 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/;mv /var/log/filebeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/";else echo "`tput setaf 3`---- GTP4-Filebeat `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";FAcc12=yes;fi

        GTP5FilebeatStatus=$(ssh IPXMIATCGTP5 "systemctl status filebeat" | grep Active | grep running)
        if [ -z "$GTP5FilebeatStatus" ];then echo "`tput setaf 3`---- GTP5-Filebeat `tput setaf 2` ssh IPXMIATCGTP5 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/;mv /var/log/filebeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCGTP5 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/;mv /var/log/filebeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/";else echo "`tput setaf 3`---- GTP5-Filebeat `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";FAcc13=yes;fi

        GTP6FilebeatStatus=$(ssh IPXMIATCGTP6 "systemctl status filebeat" | grep Active | grep running)
        if [ -z "$GTP6FilebeatStatus" ];then echo "`tput setaf 3`---- GTP6-Filebeat `tput setaf 2` ssh IPXMIATCGTP6 \"mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/;mv /var/log/filebeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/\" `tput setaf 3`----`tput sgr0`";ssh IPXMIATCGTP6 "mkdir -p /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/;mv /var/log/filebeat/* /tango/logs/COSTAFF/trash/ELK_Logs_Backup_$todayExt/filebeat/";else echo "`tput setaf 3`---- GTP6-Filebeat `tput setaf 1` ACTIVE RUNNING. Therefore, I did not move the logs. Check again ! `tput setaf 3`----`tput sgr0`";FAcc14=yes;fi


        echo -e "`tput setaf 6`\n====================================== FINISHED ======================================"
        if [ "$LAcc1" == "yes" ] && [ "$LAcc2" == "yes" ] && [ "$FAcc1" == "yes" ] &&  [ "$FAcc2" == "yes" ] && [ "$FAcc3" == "yes" ] && [ "$FAcc4" == "yes" ] && [ "$FAcc7" == "yes" ] && [ "$FAcc8" == "yes" ] && [ "$FAcc9" == "yes" ] && [ "$FAcc10" == "yes" ] && [ "$FAcc11" == "yes" ] && [ "$FAcc12" == "yes" ] && [ "$FAcc13" == "yes" ] && [ "$FAcc14" == "yes" ];then
                echo "`tput setaf 2`ALL LOGS WERE MOVED OK"
        else
                echo "`tput setaf 1`SOME OR ALL Filebeats AND Logstash ARE ACTIVE AND RUNNING, so some logs didnt get moved. Check again"
        fi
        echo "`tput setaf 6`======================================================================================"
        echo "`tput sgr0`"
else
        help
        exit
fi