#!/usr/bin/perl
##############################################################################
# Filename:    sendMail.pl
# Revision:    $Revision: 1.0
# Author:      Victor Reus
#              Modified By CK for VFiji
#
# This perl does what is says... sends mail.
#
# Copyright (c) Tango Telecom 2005
#
# All rights reserved.
# This document contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or
# in part is expressly prohibited, except as may be specifically
# authorized by prior written agreement or permission of Tango Telecom.
##############################################################################

use Socket;
use Getopt::Std;

my @scriptPath = split '/', $0;
my $scriptName = $scriptPath[$#scriptPath];

my $subVersion = "\nSend Mail Script version 0.1.0 \n";
$subVersion .= "Copyright by Tango Telecom 2005 (c)\n";
$subVersion .= "All rights reserved.\n\n\n";

my $mailFrom    = 'tango.ismsc.stats@barkie';
my $mailTo      = 'victor.reus@tango.ie';
my $realName    = "report";
my $subject     = 'Stats';
my $body        = "\n";
my $mailServer  = 'localhost';
my $domainSvr   = "vodafone.com";
my $vebose = 0;

if ( 0 == getopts( "uh:f:t:n:s:b:a:x:d:v" ) )
{
    usage();
    exit 0;
}

if ( defined($opt_f) && defined($opt_t) && defined($opt_n) &&
      defined($opt_s) && defined($opt_x))
{

 $mailFrom    = $opt_f;
 $mailTo      = $opt_t;
 $realName    = $opt_n;
 $subject     = $opt_s;
 $mailServer  = $opt_x;
 $domainSvr   = $opt_d;
 $verbose     = 1 if ($opt_v);

 if (defined($opt_b))
 {
  $body =  $opt_b;
 }
 else
 {
   die "No body specified" if (!defined($opt_a));

   # send output commands.
   my @commands = split /;/,$opt_a;

   my @allOutPut;
   foreach(@commands)
   {
    my $cmd = $_;
    print "Command $cmd \n" if ($verbose);
    my @output = `$cmd`;
    push (@allOutPut,@output);
   }

   foreach(@allOutPut)
   {
     chomp;
     $body .= $_."\n";
   }

#   $body = join("",@allOutPut);

 }

 main();
 exit(0);
}

usage();
exit(0);

sub usage
{
    print <<EO_USAGE;

$subVersion

Usage: $scriptName

    -f <from>
    -t <to@server.com>
    -n <Display Name>
    -s <subject>
    -x <smtp server IP>

     OPTIONS
     -b <body> or -a <command list>

     With -b option script will send a simple text

     With -a option you can specify multiple commands.
     The output of this commands will be send on the mail.
     i.e: cat pm.log;rsh tangoB cat pm.log

    Most common options:
    -v Displays verbose


EO_USAGE
}

sub help
{
    print <<EO_HELP;

Help for script $scriptName (c) Tango Telecom 2005


    -f <from>
    -t <to@server.com>
    -n <Display Name>
    -s <subject>
    -x <smtp server IP>

     OPTIONS
     -b <body> or -a <command list>

     With -b option script will send a simple text

     With -a option you can specify multiple commands.
     The output of this commands will be send on the mail.
     i.e: cat pm.log;rsh tangoB cat pm.log

    Most common options:
    -v Displays verbose



EO_HELP

    usage();
}



sub main()
{
 sendMail();
}

sub sendMail()
{

        $main::SIG{'INT'} = 'closeSocket';

        my($proto)      = getprotobyname("tcp")        || 6;
        my($port)       = getservbyname("SMTP", "tcp") || 25;


        my($name,$aliases,$addrtype,$length,$serverAddr) = gethostbyname($mailServer);


        if (! defined($length))
        {
         die('gethostbyname failed.');
        }

        print "Name: $name\n" if ($verbose);
        print "Alias: $aliases\n" if ($verbose);
        print "Type: $addrtype\n" if ($verbose);
        print "Length: $length\n" if ($verbose);
        print "Address: $serverAddr\n" if ($verbose);

        socket(SMTP, AF_INET(), SOCK_STREAM(), $proto)  or die("socket: $!");


        my $packFormat = 'S n a4 x8';   # Windows 95, SunOs 4.1+, Fedora

        connect(SMTP, pack($packFormat, AF_INET(), $port, $serverAddr)) or die("connect: $!");
        print "Connected\n" if ($verbose);

        sleep(1);

        print "Sending SMTP protocol...\n" if ($verbose);
#        sendSMTP(1, "HELO\r\n");
        sendSMTP(1, "HELO $domainSvr\r\n");
        sleep(6);
        sendSMTP(1, "MAIL From: <$mailFrom>\r\n");
        sleep(1);
#       sendSMTP(1, "RCPT To: <$mailTo>\r\n");
        @allRcpt = split /,/,$mailTo;
        foreach(@allRcpt)
        {
         my $mailRcpt = $_;
         sendSMTP(1, "RCPT To: <$mailRcpt>\r\n");
         sleep(1);
        }
        sendSMTP(1, "DATA\r\n");
        sleep(1);
        send(SMTP, "From: $realName\r\n", 0);
        sleep(1);
#       send(SMTP, "To: $mailTo\r\n", 0); # Disabled the to, to get undisclosed recipients.
        send(SMTP, "Subject: $subject\r\n\r\n", 0);
        sleep(1);
        send(SMTP, $body, 0);
        sleep(2);
        sendSMTP(1, "\r\n.\r\n");
        sendSMTP(1, "QUIT\r\n");
        sleep(1);

        close(SMTP);
}

sub closeSocket
{
    close(SMTP);
    die("SMTP socket closed [SIGINT]\n");
}


sub sendSMTP
{
    my($debug)  = shift;
    my($buffer) = @_;


    print STDERR ("> $buffer") if $verbose;
    send(SMTP, $buffer, 0);


    recv(SMTP, $buffer, 200, 0);
    print STDERR ("< $buffer") if $verbose;


    return( (split(/ /, $buffer))[0] );
}
