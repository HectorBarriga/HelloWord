#!/usr/bin/expect -f

send_user "\n\n\n############################################### CDMA 0 M3UA display TANGOA #############################################################################\n\n\n"

spawn telnet tangoA 2000
expect "assistance."
send "\r"
expect "mon>"
send "a M3UA_OM_oamIf;s display;"
send "\r"
expect "mon>"
send "quit"
send "\r"

send_user "\n\n\n############################################### CDMA 0 M3UA display TANGOB #############################################################################\n\n\n"

spawn telnet tangoB 2000
expect "assistance."
send "\r"
expect "mon>"
send "a M3UA_OM_oamIf;s display;"
send "\r"
expect "mon>"
send "quit"
send "\r"

send_user "\n\n\n############################################### CDMA 1 M3UA display TANGOA #############################################################################\n\n\n"

spawn telnet tangoA 2001
expect "assistance."
send "\r"
expect "mon>"
send "a M3UA_OM_oamIf;s display;"
send "\r"
expect "mon>"
send "quit"
send "\r"

send_user "\n\n\n############################################### CDMA 1 M3UA display TANGOB #############################################################################\n\n\n"

spawn telnet tangoB 2001
expect "assistance."
send "\r"
expect "mon>"
send "a M3UA_OM_oamIf;s display;"
send "\r"
expect "mon>"
send "quit"
send "\r"

send_user "\n\n\n############################################### GSM M3UA display TANGOA #############################################################################\n\n\n"

spawn telnet tangoA 2002
expect "assistance."
send "\r"
expect "mon>"
send "a M3UA_OM_oamIf;s display;"
send "\r"
expect "mon>"
send "quit"
send "\r"

send_user "\n\n\n############################################### GSM M3UA display TANGOB #############################################################################\n\n\n"

spawn telnet tangoB 2002
expect "assistance."
send "\r"
expect "mon>"
send "a M3UA_OM_oamIf;s display;"
send "\r"
expect "mon>"
send "quit"
send "\r"

send_user "\n\n\n############################################### CDMA M2P SMPP_router TANGOA #############################################################################\n\n\n"

spawn telnet tangoA 13030
expect "assistance."
send "\r"
expect "mon>"
send "a SMPP_router;s display;"
send "\r"
expect "mon>"
send "quit"
send "\r"


send_user "\n\n\n############################################### CDMA M2P SMPP_router TANGOB #############################################################################\n\n\n"

spawn telnet tangoB 13030
expect "assistance."
send "\r"
expect "mon>"
send "a SMPP_router;s display;"
send "\r"
expect "mon>"
send "quit"
send "\r"

send_user "\n\n\n############################################### OFFLINE SMPP_router TANGOA #############################################################################\n\n\n"
 
spawn telnet tangoA 13031
expect "assistance."
send "\r"
expect "mon>"
send "a SMPP_router;s display\r"
expect "nothing"

send_user "\n\n\n############################################### OFFLINE SMPP_router TANGOB #############################################################################\n\n\n"

spawn telnet tangoB 13031
expect "assistance."
send "\r"
expect "mon>"
send "a SMPP_router;s display;"
send "\r"
expect "mon>"
send "quit"
send "\r"

send_user "\n\n\n############################################### SMSC Interface SMPP_router TANGOA #############################################################################\n\n\n"

spawn telnet tangoA 13033
expect "assistance."
send "\r"
expect "mon>"
send "a SMPP_router;s display;"
send "\r"
expect "mon>"
send "quit"
send "\r"

send_user "\n\n\n############################################### SMSC Interface SMPP_router TANGOB #############################################################################\n\n\n"

spawn telnet tangoB 13033
expect "assistance."
send "\r"
expect "mon>"
send "a SMPP_router;s display;"
send "\r"
expect "mon>"
send "quit"
send "\r"

send_user "\n\n\n############################################### GSM M2P SMPP_router TANGOA #############################################################################\n\n\n"

spawn telnet tangoA 13034
expect "assistance."
send "\r"
expect "mon>"
send "a SMPP_router;s display;"
send "\r"
expect "mon>"
send "quit"
send "\r"

send_user "\n\n\n############################################### GSM M2P SMPP_router TANGOB #############################################################################\n\n\n"

spawn telnet tangoB 13034
expect "assistance."
send "\r"
expect "mon>"
send "a SMPP_router;s display;"
send "\r"
expect "mon>"
send "quit"
send "\r"

send_user "\n\n\n############################################### M2P STORE TANGOA #############################################################################\n\n\n"

spawn telnet tangoA 11100
expect "assistance."
send "\r"
expect "mon>"
send "a oam;s stateDisplay;"
send "\r"
expect "mon>"
send "quit"
send "\r"

send_user "\n\n\n############################################### OFFLINE STORE TANGOA #############################################################################\n\n\n"

spawn telnet tangoA 11101
expect "assistance."
send "\r"
expect "mon>"
send "a oam;s stateDisplay;"
send "\r"
expect "mon>"
send "quit"
send "\r"

send_user "\n\n\n############################################### M2P STORE TANGOB #############################################################################\n\n\n"

spawn telnet tangoB 11100
expect "assistance."
send "\r"
expect "mon>"
send "a oam;s stateDisplay;"
send "\r"
expect "mon>"
send "quit"
send "\r"

send_user "\n\n\n############################################### OFFLINE STORE TANGOB #############################################################################\n\n\n"

spawn telnet tangoB 11101
expect "assistance."
send "\r"
expect "mon>"
send "a oam;s stateDisplay;"
send "\r"
expect "mon>"
send "quit"
send "\r"

send_user "\n\n\n############################################### P2P STORE TANGOC #############################################################################\n\n\n"

spawn telnet tangoC 11100
expect "assistance."
send "\r"
expect "mon>"
send "a oam;s stateDisplay;"
send "\r"
expect "mon>"
send "quit"
send "\r"

send_user "\n\n\n############################################### P2P STORE TANGOD #############################################################################\n\n\n"

spawn telnet tangoD 11100
expect "assistance."
send "\r"
expect "mon>"
send "a oam;s stateDisplay;"
send "\r"
expect "mon>"
send "quit"
send "\r"

send_user "\n\n\n############################################### P2P Receipts STORE TANGOC #############################################################################\n\n\n"

spawn telnet tangoC 11101
expect "assistance."
send "\r"
expect "mon>"
send "a oam;s stateDisplay;"
send "\r"
expect "mon>"
send "quit"
send "\r"

send_user "\n\n\n############################################### P2P STORE TANGOD #############################################################################\n\n\n"

spawn telnet tangoD 11101
expect "assistance."
send "\r"
expect "mon>"
send "a oam;s stateDisplay;"
send "\r"
expect "mon>"
send "quit"
send "\r"

exit
