#!/bin/bash

############################################
# EMAIL Emergency Alert (SEA)
#
# SMSC Claro Puerto Rico
############################################

################### getStatus ##############################################################

/usr/bin/nice /tango/scripts/Generic/Others/sshBanner/dynmotd | tee /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus_tangoA.txt
/bin/scp tangoB:/tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus_tangoB.txt /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/.
/bin/scp tangoC:/tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus_tangoC.txt /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/.
/bin/scp tangoD:/tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus_tangoD.txt /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/.

/usr/bin/nice /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/Spawn_Processes_Status.sh | tee /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt



#################### get alrms and trigger MO SMS if there are alarms #######################

# mps
IsProcessesFailedtangoA=$(cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus_tangoA.txt | awk '/Failed/ || /Shutdown/ {print $0}')
if [ ! -z "$IsProcessesFailedtangoA" ]; then
/usr/bin/nice /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/sendMail.pl -f "tango.status@tangotelecom.com" -t "caradeyoujuliabarriga@gmail.com" -n "ALARM@claropr.com" -s "[ TangoA ] Proccess Failed" -x 10.50.0.150 -d claropr.com -b "$IsProcessesFailedtangoA" -v
sleep 10
fi
IsProcessesFailedtangoB=$(cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus_tangoB.txt | awk '/Failed/ || /Shutdown/ {print $0}')
if [ ! -z "$IsProcessesFailedtangoB" ]; then
/usr/bin/nice /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/sendMail.pl -f "tango.status@tangotelecom.com" -t "caradeyoujuliabarriga@gmail.com" -n "ALARM@claropr.com" -s "[ TangoB ] Proccess Failed" -x 10.50.0.150 -d claropr.com -b "$IsProcessesFailedtangoB" -v
sleep 10
fi
IsProcessesFailedtangoC=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus_tangoC.txt | awk '/Failed/ || /Shutdown/ {print $0}')
if [ ! -z "$IsProcessesFailedtangoC" ]; then
/usr/bin/nice /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/sendMail.pl -f "tango.status@tangotelecom.com" -t "caradeyoujuliabarriga@gmail.com" -n "ALARM@claropr.com" -s "[ TangoC ] Proccess Failed" -x 10.50.0.150 -d claropr.com -b "$IsProcessesFailedtangoC" -v
sleep 10
fi
IsProcessesFailedtangoD=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus_tangoD.txt | awk '/Failed/ || /Shutdown/ {print $0}')
if [ ! -z "$IsProcessesFailedtangoD" ]; then
/usr/bin/nice /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/sendMail.pl -f "tango.status@tangotelecom.com" -t "caradeyoujuliabarriga@gmail.com" -n "ALARM@claropr.com" -s "[ TangoD ] Proccess Failed" -x 10.50.0.150 -d claropr.com -b "$IsProcessesFailedtangoD" -v
sleep 10
fi
# VirtualIPs
IsSmppVIP=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt | grep "10.50.37.79")
if [ -z "$IsSmppVIP" ]; then
/usr/bin/nice /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/sendMail.pl -f "tango.status@tangotelecom.com" -t "caradeyoujuliabarriga@gmail.com" -n "ALARM@claropr.com" -s "[ TangoAB ] SMPP VirtualIP Down" -x 10.50.0.150 -d claropr.com -b "SMPP Virtual IP 10.50.37.79 is down on tangoA and tangoB" -v
sleep 10
fi
IsIntVIP=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt | grep "172.90.1.3")
if [ -z "$IsIntVIP" ]; then
/usr/bin/nice /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/sendMail.pl -f "tango.status@tangotelecom.com" -t "caradeyoujuliabarriga@gmail.com" -n "ALARM@claropr.com" -s "[ TangoAB ] Internal IP Down" -x 10.50.0.150 -d claropr.com -b "Iternal Virtual IP 172.90.1.3 is down on tangoA and tangoB" -v
sleep 10
fi

# Mysql
IsMysql=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt | grep "MYSQL IS DOWN")
if [ ! -z "$IsMysql" ]; then
/usr/bin/nice /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/sendMail.pl -f "tango.status@tangotelecom.com" -t "caradeyoujuliabarriga@gmail.com" -n "ALARM@claropr.com" -s "[ TangoABCD ] MYSQL is Down" -x 10.50.0.150 -d claropr.com -b "$IsMysql on either tangoA, tangoB, tangoC or tangoD" -v
sleep 10
fi
IsReplicationOk=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt | awk '/Slave_IO_Running/ || /Slave_SQL_Running/' | awk '/Yes/' | wc -l | tr -s " ")
if [ $IsReplicationOk -ne 4 ]; then
/usr/bin/nice /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/sendMail.pl -f "tango.status@tangotelecom.com" -t "caradeyoujuliabarriga@gmail.com" -n "ALARM@claropr.com" -s "[ TangoABCD ] REPLICATION is Broken" -x 10.50.0.150 -d claropr.com -b "REPLICATION is broken or MYSQL is down on either tangoA, tangoB, tangoC or tangoD"- v
sleep 10
fi

#Tomcat
IsTomcat=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt | grep "Tomcat is DOWN")
if [ ! -z "$IsTomcat" ]; then
/usr/bin/nice /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/sendMail.pl -f "tango.status@tangotelecom.com" -t "caradeyoujuliabarriga@gmail.com" -n "ALARM@claropr.com" -s "[ TangoABCD ] TOMCAT is Down" -x 10.50.0.150 -d claropr.com -b "TOMCAT is down on either tangoA, tangoB, tangoC or tangoD" -v
sleep 10
fi

#Sigtran Associations
IsAssociationDown=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | awk '/ESTABLISHED/' | wc -l | tr -s " ")
if [ $IsAssociationDown -ne 4 ]; then
/usr/bin/nice /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/sendMail.pl -f "tango.status@tangotelecom.com" -t "caradeyoujuliabarriga@gmail.com" -n "ALARM@claropr.com" -s "[ SIGTRAN ] Association is Down" -x 10.50.0.150 -d claropr.com -b "An ASSOCIATION is down on either tangoA or tangoB" -v
sleep 10
fi

#Disk Partition Space > 85%
IsDiskFullA=$(df -h | grep "%" | nawk '{print $5}' | cut -d% -f1 | awk '$(NF)>85 { print }')
if [ ! -z "$IsDiskFullA" ]; then
/usr/bin/nice /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/sendMail.pl -f "tango.status@tangotelecom.com" -t "caradeyoujuliabarriga@gmail.com" -n "ALARM@claropr.com" -s "[ TangoA ] Partition > 85%" -x 10.50.0.150 -d claropr.com -b "One of the partitions on tangoA is bigger than 85%" -v
sleep 10
fi
IsDiskFullB=$(ssh tangoB 'df -h' | grep "%" | nawk '{print $5}' | cut -d% -f1 | awk '$(NF)>85 { print }')
if [ ! -z "$IsDiskFullB" ]; then
/usr/bin/nice /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/sendMail.pl -f "tango.status@tangotelecom.com" -t "caradeyoujuliabarriga@gmail.com" -n "ALARM@claropr.com" -s "[ TangoB ] Partition > 85%" -x 10.50.0.150 -d claropr.com -b "One of the partitions on tangoB is bigger than 85%" -v
sleep 10
fi
IsDiskFullC=$(ssh tangoC 'df -h' | grep "%" | nawk '{print $5}' | cut -d% -f1 | awk '$(NF)>85 { print }')
if [ ! -z "$IsDiskFullC" ]; then
/usr/bin/nice /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/sendMail.pl -f "tango.status@tangotelecom.com" -t "caradeyoujuliabarriga@gmail.com" -n "ALARM@claropr.com" -s "[ TangoC ] Partition > 85%" -x 10.50.0.150 -d claropr.com -b "One of the partitions on tangoC is bigger than 85%" -v
sleep 10
fi

IsDiskFullD=$(ssh tangoD 'df -h' | grep "%" | nawk '{print $5}' | cut -d% -f1 | awk '$(NF)>85 { print }')
if [ ! -z "$IsDiskFullD" ]; then
/usr/bin/nice /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/sendMail.pl -f "tango.status@tangotelecom.com" -t "caradeyoujuliabarriga@gmail.com" -n "ALARM@claropr.com" -s "[ TangoD ] Partition > 85%" -x 10.50.0.150 -d claropr.com -b "One of the partitions on tangoC is bigger than 85%" -v
sleep 10
fi

#Apache
IsApacheDown=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt | grep "Apache is DOWN")
if [ ! -z "$IsApacheDown" ]; then
/usr/bin/nice /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/sendMail.pl -f "tango.status@tangotelecom.com" -t "caradeyoujuliabarriga@gmail.com" -n "ALARM@claropr.com" -s "[ TangoABCD ] Apache is Down" -x 10.50.0.150 -d claropr.com -b "$IsApacheDown on either tangoA, tangoB, tangoC or tangoD" -v
sleep 10
fi

#Stores
IsStoreDown=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | awk '/FAILED/ || /OFFLINE/ {print $0}' | egrep -v bind | egrep -v SystemID | egrep -v "OFFLINE S")
if [ ! -z "$IsStoreDown" ]; then
/usr/bin/nice /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/sendMail.pl -f "tango.status@tangotelecom.com" -t "caradeyoujuliabarriga@gmail.com" -n "ALARM@claropr.com" -s "[ TangoABCD ] STORE is Down" -x 10.50.0.150 -d claropr.com -b "One of the STORES is DOWN or OFFLINE on either tangoA, tangoB, tangoC or tangoD" -v
sleep 10
fi

#Binds SMPP_routers
IsSyniverseUp=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | awk '/sybase01/ || /tracf3ci/ || /synive01/ {print $0}' | wc -l | tr -s " ")
#if [ "$IsSyniverseUp" -lt 6 ]; then
if [ "$IsSyniverseUp" -lt 5 ]; then
/usr/bin/nice /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/sendMail.pl -f "tango.status@tangotelecom.com" -t "caradeyoujuliabarriga@gmail.com" -n "ALARM@claropr.com" -s "[ TangoAB ] Syniverse or sybase01 or tracf3ci are Down" -x 10.50.0.150 -d claropr.com -b "SYNIVERSE or TRACFONE traffic is affected. Bind synive01,tracf3ci or synive01 is Down on both tangoA and tangoB" -v
sleep 10
fi
IsSmppws=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | grep smppws)
if [ -z "$IsSmppws" ]; then
/usr/bin/nice /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/sendMail.pl -f "tango.status@tangotelecom.com" -t "caradeyoujuliabarriga@gmail.com" -n "ALARM@claropr.com" -s "[ TangoAB ] SMS_Forwarder is Down" -x 10.50.0.150 -d claropr.com -b "SMS_Forwerder traffic is affected. Bind smppws is Down on both tangoA and tangoB" -v
sleep 10
fi
Isp2m911=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | grep p2m911)
if [ -z "$Isp2m911" ]; then
/usr/bin/nice /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/sendMail.pl -f "tango.status@tangotelecom.com" -t "caradeyoujuliabarriga@gmail.com" -n "ALARM@claropr.com" -s "[ TangoAB ] SMS_Chat & 911 are Down" -x 10.50.0.150 -d claropr.com -b "SMS_Chat and 911 Service MO traffic are affected. Bind p2m911 is Down on both tangoA and tangoB" -v
sleep 10
fi
Isssrv911=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | grep ssrv911)
if [ -z "$Isssrv911" ]; then
/usr/bin/nice /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/sendMail.pl -f "tango.status@tangotelecom.com" -t "caradeyoujuliabarriga@gmail.com" -n "ALARM@claropr.com" -s "[ TangoAB ] SMS_Chat & 911 are Down" -x 10.50.0.150 -d claropr.com -b "SMS_Chat and 911 Service M2P traffic are affected. SSRV-SMPP might not be working. Bind ssrv911 is Down on both tangoA and tangoB" -v
sleep 10
fi

#Memmory TOP
IsMemoryLow=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt | grep "Memmory is very low")
if [ ! -z "$IsMemoryLow" ]; then
/usr/bin/nice /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/sendMail.pl -f "tango.status@tangotelecom.com" -t "caradeyoujuliabarriga@gmail.com" -n "ALARM@claropr.com" -s "[ TangoABCD ] Memory is Low" -x 10.50.0.150 -d claropr.com -b "$IsMemoryLow. It is lower than 1G on either tangoA, tangoB, tangoC or tangoD" -v
sleep 10
fi

#Syniverse CDRs OK
SyniDeliver=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt | awk '/Delivered/ && /synive01/' | wc -l | tr -s " ")
if [ $IsAssociationDown -eq 0 ]; then
/usr/bin/nice /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/sendMail.pl -f "tango.status@tangotelecom.com" -t "caradeyoujuliabarriga@gmail.com" -n "ALARM@claropr.com" -s "[ TangoAB ] Syniverse MO Traffic failing" -x 10.50.0.150 -d claropr.com -b "cdrmon2 on tangoA or tnagoB show that there are not any Delivered MO CDRs for synive01." -v
sleep 10
fi











exit
