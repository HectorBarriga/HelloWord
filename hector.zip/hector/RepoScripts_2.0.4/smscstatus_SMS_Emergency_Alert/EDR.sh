#!/bin/bash

############################################
# Email Daily Report (EDR)
#
# SMSC Claro Puerto Rico
############################################


# mps
AreProcessesFailed=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt | awk '/Failed/ || /Shutdown/')

# VirtualIPs
IsSmppVIP=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt | grep "10.50.37.79")
IsIntVIP=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt | grep "172.90.1.3")

# Mysql
IsMysql=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt | grep "MYSQL IS DOWN")
IsReplicationOk=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt | awk '/Slave_IO_Running/ || /Slave_SQL_Running/' | awk '/Yes/' | wc -l | tr -s " ")

#Tomcat
IsTomcat=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt | grep "Tomcat is DOWN")

#Sigtran Associations
IsAssociationDown=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | awk '/ESTABLISHED/' | wc -l | tr -s " ")

#Disk Partition Space > 85%
IsDiskFullA=$(df -h | grep "%" | nawk '{print $5}' | cut -d% -f1 | awk '$(NF)>85 { print }')
IsDiskFullB=$(ssh tangoB 'df -h' | grep "%" | nawk '{print $5}' | cut -d% -f1 | awk '$(NF)>85 { print }')
IsDiskFullC=$(ssh tangoC 'df -h' | grep "%" | nawk '{print $5}' | cut -d% -f1 | awk '$(NF)>85 { print }')
IsDiskFullD=$(ssh tangoD 'df -h' | grep "%" | nawk '{print $5}' | cut -d% -f1 | awk '$(NF)>85 { print }')

#Apache
IsApacheDown=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt | grep "Apache is DOWN")

#Stores
IsStoreDown=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | awk '/FAILED/ || /OFFLINE/ {print $0}' | egrep -v bind | egrep -v SystemID | egrep -v "OFFLINE S")

#Binds SMPP_routers
IsSyniverseUp=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | awk '/sybase01/ || /tracf3ci/ || /synive01/ {print $0}' | wc -l | tr -s " ")
IsSmppws=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | grep smppws)
Isp2m911=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | grep p2m911)
Isssrv911=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | grep ssrv911)

#Memmory TOP
IsMemoryLow=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt | grep "Memmory is very low")

#Syniverse CDRs OK
SyniDeliver=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt |   awk '/Delivered/ && /synive01/' | wc -l | tr -s " ") 

# Clean EDR.msg
echo > /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/EDR.msg

# Send Everything is OK message if OK

if [ -z "$AreProcessesFailed" ] && [ ! -z "$IsSmppVIP" ] &&  [ ! -z "$IsIntVIP" ] && [ -z "$IsMysql" ] && [ $IsReplicationOk -eq 4 ] && [ -z "$IsTomcat" ] && [ $IsAssociationDown -eq 4 ] && [ -z "$IsDiskFullA" ]&& [ -z "$IsDiskFullB" ] && [ -z "$IsDiskFullC" ]&& [ -z "$IsDiskFullD" ]&& [ -z "$IsApacheDown" ] && [ -z "$IsStoreDown" ] && [ "$IsSyniverseUp" -ge 4 ] && [ ! -z "$IsSmppws" ] && [ ! -z "$Isp2m911" ] && [ ! -z "$Isssrv911" ] && [ -z "$IsMemoryLow" ]  && [ "$SyniDeliver" -gt 0 ]; then

echo "" > /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/EDR.msg
echo "Everthing is OK" >> /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/EDR.msg
echo "---------------" >> /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/EDR.msg
echo "AreProcessesFailed= [ $AreProcessesFailed ] It must be empty" >> /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/EDR.msg
echo "IsSmppVIP= [ $IsSmppVIP It cannot be empty ]" >> /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/EDR.msg
echo "IsIntVIP= [ $IsIntVIP It cannot be empty ]" >> /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/EDR.msg
echo "isMysql= [ $isMysql ] It must be empty" >> /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/EDR.msg
echo "IsReplicationOk= [ $IsReplicationOk ]  It must be 4" >> /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/EDR.msg
echo "IsTomcat= [ $IsTomcat ] It must be empty" >> /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/EDR.msg
echo "IsAssociationDown= [ $IsAssociationDown ]  It must be 4" >> /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/EDR.msg
echo "IsDiskFullA [ $IsDiskFullA ] It must be empty" >> /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/EDR.msg
echo "IsDiskFullB [ $IsDiskFullB ] It must be empty" >> /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/EDR.msg
echo "IsDiskFullC [ $IsDiskFullC ] It must be empty" >> /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/EDR.msg
echo "IsDiskFullD [ $IsDiskFullD ] It must be empty" >> /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/EDR.msg
echo "IsApacheDown= [$IsApacheDown ] It must be empty" >> /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/EDR.msg
echo "IsStoreDown= [ $IsStoreDown ] It must be empty" >> /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/EDR.msg
echo "IsSyniverseUp= [$IsSyniverseUp] It must be equal or greater than 4" >> /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/EDR.msg
echo "IsSmppws= $IsSmppws" >> /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/EDR.msg
echo "Isp2m911= $Isp2m911" >> /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/EDR.msg
echo "Isssrv911= $Isssrv911" >> /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/EDR.msg
echo "IsMemoryLow= [ $IsMemoryLow ] It must be empty" >> /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/EDR.msg
echo "Synive01 CDRs= [ $SyniDeliver ] It cant be 0" >> /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/EDR.msg
echo ""
echo "Everthing is OK"
echo "---------------"
echo ""
echo "AreProcessesFailed= [ $AreProcessesFailed ] It must be empty"
echo "IsSmppVIP= [ $IsSmppVIP ] It cannot be empty"
echo "IsIntVIP= [ $IsIntVIP ] It cannot be empty"
echo "isMysql= [ $isMysql ] It must be empty"
echo "IsReplicationOk= [ $IsReplicationOk ]  It must be 4"
echo "IsTomcat= [ $IsTomcat ] It must be empty"
echo "IsAssociationDown= [ $IsAssociationDown ]  It must be 4"
echo "IsDiskFullA [ $IsDiskFullA ] It must be empty"
echo "IsDiskFullB [ $IsDiskFullB ] It must be empty"
echo "IsDiskFullC [ $IsDiskFullC ] It must be empty"
echo "IsDiskFullD [ $IsDiskFullD ] It must be empty"
echo "IsApacheDown= [$IsApacheDown ] It must be empty"
echo "IsStoreDown= [ $IsStoreDown ] It must be empty"
echo "IsSyniverseUp= [$IsSyniverseUp] It must be equal or greater than 4"
echo "IsSmppws= $IsSmppws"
echo "Isp2m911= $Isp2m911"
echo "Isssrv911= $Isssrv911"
echo "IsMemoryLow= [ $IsMemoryLow ] It must be empty"
echo "Synive01 CDRs= [ $SyniDeliver ] It cant be 0"

#/usr/bin/nice /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/sendMail.pl -f "tango.status@tangotelecom.com" -t "caradeyoujuliabarriga@gmail.com" -n "EVERYTHING_OK@claropr.com" -s "[ TangoABCD ] Everythin is OK" -x 10.205.2.9 -d claropr.com -a "/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/EDR.msg" -v
/usr/bin/nice /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/sendMail.pl -f "tango.status@tangotelecom.com" -t "caradeyoujuliabarriga@gmail.com" -n "EVERYTHING_OK@claropr.com" -s "[ TangoABCD ] Everythin is OK" -x 10.50.0.150 -d claropr.com -a "/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/EDR.msg" -v

else
echo ""
echo "PROBLEM"
echo "---------------"
echo ""
echo "AreProcessesFailed= [ $AreProcessesFailed ] It must be empty"
echo "IsSmppVIP= $IsSmppVIP It cannot be empty"
echo "IsIntVIP= $IsIntVIP It cannot be empty"
echo "isMysql= [ $isMysql ] It must be empty"
echo "IsReplicationOk= [ $IsReplicationOk ]  It must be 4"
echo "IsTomcat= [ $IsTomcat ] It must be empty"
echo "IsAssociationDown= [ $IsAssociationDown ]  It must be 4"
echo "IsDiskFullA [ $IsDiskFullA ] It must be empty"
echo "IsDiskFullB [ $IsDiskFullB ] It must be empty"
echo "IsDiskFullC [ $IsDiskFullC ] It must be empty"
echo "IsDiskFullD [ $IsDiskFullD ] It must be empty"
echo "IsApacheDown= [$IsApacheDown ] It must be empty"
echo "IsStoreDown= [ $IsStoreDown ] It must be empty"
echo "IsSyniverseUp= [$IsSyniverseUp] It must be equal or greater than 4"
echo "IsSmppws= $IsSmppws"
echo "Isp2m911= $Isp2m911"
echo "Isssrv911= $Isssrv911"
echo "IsMemoryLow= [ $IsMemoryLow ] It must be empty"
echo "Synive01 CDRs= [ $SyniDeliver ] It cant be 0"
fi









exit
