#!/bin/bash
now=`date +%c`

#### Email Head

echo "Dear BOSVA, Rafael, Ivellisse" | tee /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/ClusterFullstatus.txt
echo "

Please find below the babysitting report at $now

" >> /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/ClusterFullstatus.txt

#### Scan all systems and include everything is OK

# mps
AreProcessesFailed=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | grep "Failed")

# VirtualIPs
IsSmppVIP=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | grep "10.50.37.79")
IsIntVIP=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | grep "172.90.1.3")

# Mysql
IsMysql=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt | grep "MYSQL IS DOWN")
IsReplicationOk=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt | awk '/Slave_IO_Running/ || /Slave_SQL_Running/' | awk '/Yes/' | wc -l | tr -s " ")

#Tomcat
IsTomcat=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt | grep "Tomcat is DOWN")

#Sigtran Associations
IsAssociationDown=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | awk '/ESTABLISHED/' | wc -l | tr -s " ")

#Disk Partition Space > 85%
IsDiskFull=$(df -h | grep "%" | nawk '{print $5}' | cut -d% -f1 | awk '$(NF)>85 { print }')

#Apache
IsApacheDown=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt | grep "Apache is DOWN")

#Stores
IsStoreDown=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | grep -i "FAILED" | egrep -v bind | egrep -v SystemID)

#Binds SMPP_routers
IsSyniverseUp=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | awk '/sybase01/ || /tracf3ci/ || /synive01/ {print $0}' | wc -l | tr -s " ")
IsSmppws=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | grep smppws)
Isp2m911=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | grep p2m911)
Isssrv911=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | grep ssrv911)

#Memmory TOP
IsMemoryLow=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt | grep "Memmory is very low")

#Syniverse CDRs OK
SyniDeliver=$(/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt |   awk '/Delivered/ && /synive01/' | wc -l | tr -s " ")

if [ -z "$AreProcessesFailed" ] && [ ! -z "$IsSmppVIP" ] &&  [ ! -z "$IsIntVIP" ] && [ -z "$IsMysql" ] && [ $IsReplicationOk -eq 4 ] && [ -z "$IsTomcat" ] && [ $IsAssociationDown -eq 4 ] && [ -z "$IsDiskFull" ] && [ -z "$IsApacheDown" ] && [ -z "$IsStoreDown" ] && [ "$IsSyniverseUp" -ge 4 ] && [ ! -z "$IsSmppws" ] && [ ! -z "$Isp2m911" ] && [ ! -z "$Isssrv911" ] && [ -z "$IsMemoryLow" ] && [ "$SyniDeliver" -gt 0 ]; then

echo "As can be seen below, everything is working correctly

	-	Processes status 		OK
	-	Stores status     		OK
	-	Binds status      		OK
	-	Disk status       		OK
	-	CPU usage and Memory status   	OK
	-	Tomcat, apache servers status 	OK
	-	Mysql Database status		OK
	-	Sigtran associations status	OK



" >> /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/ClusterFullstatus.txt
MailSubject_OK="Everything is OK "
else
MailSubject_OK="PROBLEM !!!!!! "
fi








##### Get Cluster Quick Scan Report and ClusterFullstatus

/tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/QuickScanReport.sh >> /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/ClusterFullstatus.txt
/usr/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus_tango* >> /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/ClusterFullstatus.txt

##### Add tail of email
echo "


Hector Barriga
Tango Telecom Ltd.
Customer Operations
+353 872958622 Ireland       


#### Tango Telecom Ltd. ####
Registered in Ireland - Number 307010
Registered Office - Walton House, Lonsdale Road, National Technology Park, Limerick, Ireland.
T: +353 61 501900, F: +353 61 501901, W: www.tangotelecom.com, E info@tangotelecom.com

Private, Confidential and Privileged. This e-mail and any files and attachments transmitted with it are confidential and/or privileged. They are intended solely for the use of the intended recipient. The content of this e-mail and any file or attachment transmitted with it may have been changed or altered without the consent of the author. If you are not the intended recipient, please note that any review, dissemination, disclosure, alteration, printing, circulation or transmission of this e-mail and/or any file or attachment transmitted with it, is prohibited and may be unlawful. If you have received this e-mail or any file or attachment transmitted with it in error please notify the sender.  Any views expressed in this message are those of the individual sender and do not necessarily reflect the views of Tango Telecom

" >> /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/ClusterFullstatus.txt







#### Send email

#/usr/bin/nice /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/sendMail.pl -f "tango.status@tangotelecom.com" -t "hector.barriga@tangotelecom.com,co-latam@tangotelecom.com,bosva@claropr.com,rafael.colon1@claropr.com,iquinones@claropr.com,nelson.torres1@claropr.com,daniel.paulino@tangotelecom.com" -n "tango.status@claropr.com" -s "[Claro PRT SMSC COIT-10051] Babysitting Report at $now" -x 10.205.2.9 -d claropr.com -a "/usr/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/ClusterFullstatus.txt" -v

/usr/bin/nice /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/sendMail.pl -f "tango.status@tangotelecom.com" -t "hector.barriga@tangotelecom.com" -n "tango.status@claropr.com" -s "[Claro PRT $MailSubject_OK] Report at $now" -x 10.50.0.150 -d claropr.com -a "/usr/bin/cat /tango/data/user_data/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/ClusterFullstatus.txt" -v

