

############################################
# SMS Emergency Alert (SEA)
#
# SMSC Belize Speednet
############################################

################### getStatus ##############################################################

/usr/bin/scp tangoA:/tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus_tangoA.txt /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/.
/usr/bin/scp tangoC:/tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus_tangoC.txt /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/.
/usr/bin/scp tangoD:/tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus_tangoD.txt /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/.

cp -rfp /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/oldSPS.txt
/bin/nice /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/Spawn_Processes_Status.sh | tee /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt

#################### get alrms and trigger MO SMS if there are alarms #######################
# check process telnet
tangoA11100=$(nc -v -z -w2 tangoA 11100 &> /dev/null; echo $?)
tangoB11100=$(nc -v -z -w2 tangoB 11100 &> /dev/null; echo $?)
tangoC11100=$(nc -v -z -w2 tangoC 11100 &> /dev/null; echo $?)
tangoD11100=$(nc -v -z -w2 tangoD 11100 &> /dev/null; echo $?)
tangoA11101=$(nc -v -z -w2 tangoA 11101 &> /dev/null; echo $?)
tangoB11101=$(nc -v -z -w2 tangoB 11101 &> /dev/null; echo $?)
tangoC11101=$(nc -v -z -w2 tangoC 11101 &> /dev/null; echo $?)
tangoD11101=$(nc -v -z -w2 tangoD 11101 &> /dev/null; echo $?)
tangoA13030=$(nc -v -z -w2 tangoA 13030 &> /dev/null; echo $?)
tangoB13030=$(nc -v -z -w2 tangoB 13030 &> /dev/null; echo $?)
tangoA13031=$(nc -v -z -w2 tangoA 13031 &> /dev/null; echo $?)
tangoB13031=$(nc -v -z -w2 tangoB 13031 &> /dev/null; echo $?)
tangoA13034=$(nc -v -z -w2 tangoA 13034 &> /dev/null; echo $?)
tangoB13034=$(nc -v -z -w2 tangoB 13034 &> /dev/null; echo $?)
tangoA2000=$(nc -v -z -w2 tangoA 2000 &> /dev/null; echo $?)
tangoB2000=$(nc -v -z -w2 tangoB 2000 &> /dev/null; echo $?)
tangoA2001=$(nc -v -z -w2 tangoA 2001 &> /dev/null; echo $?)
tangoB2001=$(nc -v -z -w2 tangoB 2001 &> /dev/null; echo $?)
tangoA2002=$(nc -v -z -w2 tangoA 2002 &> /dev/null; echo $?)
tangoB2002=$(nc -v -z -w2 tangoB 2002 &> /dev/null; echo $?)
if [ "$tangoA11100" -eq "1" ] || [ "$tangoB11100" -eq "1" ] || [ "$tangoC11100" -eq "1" ] || [ "$tangoD11100" -eq "1" ] || [ "$tangoA11101" -eq "1" ] || [ "$tangoB11101" -eq "1" ] || [ "$tangoC11101" -eq "1" ] || [ "$tangoD11101" -eq "1" ] || [ "$tangoA13030" -eq "1" ] || [ "$tangoB13030" -eq "1" ] || [ "$tangoA13031" -eq "1" ] || [ "$tangoB13031" -eq "1" ] || [ "$tangoA13034" -eq "1" ] || [ "$tangoB13034" -eq "1" ] || [ "$tangoA2000" -eq "1" ] || [ "$tangoB2000" -eq "1" ] || [ "$tangoA2001" -eq "1" ] || [ "$tangoB2001" -eq "1" ]|| [ "$tangoA2002" -eq "1" ] || [ "$tangoB2002" -eq "1" ];then
/tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/poke /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/ProcessesNoTelnet.msg
fi

# mps
IsProcessesFailedtangoA=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus_tangoA.txt /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | grep "Failed" | egrep -v "incrementRemPcStats"  | egrep -v IMS)
if [ ! -z "$IsProcessesFailedtangoA" ]; then
/tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/poke /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/ProcessesFailed_tangoA.msg
sleep 10
fi
IsProcessesFailedtangoB=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus_tangoB.txt /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | grep "Failed" | egrep -v "incrementRemPcStats"  | egrep -v IMS)
if [ ! -z "$IsProcessesFailedtangoB" ]; then
/tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/poke /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/ProcessesFailed_tangoB.msg
sleep 10
fi
IsProcessesFailedtangoC=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus_tangoC.txt /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | grep "Failed" | egrep -v "incrementRemPcStats" )
if [ ! -z "$IsProcessesFailedtangoC" ]; then
/tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/poke /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/ProcessesFailed_tangoC.msg
sleep 10
fi
IsProcessesFailedtangoD=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus_tangoD.txt /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | grep "Failed" | egrep -v "incrementRemPcStats" )
if [ ! -z "$IsProcessesFailedtangoD" ]; then
/tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/poke /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/ProcessesFailed_tangoD.msg
sleep 10
fi
# VirtualIPs
IsSmppVIP=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | grep "10.23.2.233")
if [ -z "$IsSmppVIP" ]; then
/tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/poke /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/NoSmppVIP.msg
sleep 10
fi
IsGSMSmppVIP=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | grep "10.23.2.234")
if [ -z "$IsGSMSmppVIP" ]; then
/tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/poke /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/NoGSMSmppVIP.msg
sleep 10
fi
IsIntVIP=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | grep "172.20.2.254")
if [ -z "$IsIntVIP" ]; then
/tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/poke /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/NoIntVIP.msg
sleep 10
fi

# Mysql
IsMysql=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt | grep "MYSQL IS DOWN")
if [ ! -z "$IsMysql" ]; then
/tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/poke /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/MysqlDown.msg
sleep 10
fi
IsReplicationOk=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt | awk '/Slave_IO_Running/ || /Slave_SQL_Running/' | awk '/Yes/' | wc -l | tr -s " ")
if [ $IsReplicationOk -ne 2 ]; then
/tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/poke /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/ReplicationBroken.msg
sleep 10
fi

#Tomcat
IsTomcat=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt | grep "Tomcat is DOWN")
if [ ! -z "$IsTomcat" ]; then
/tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/poke /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/TomcatDown.msg
sleep 10
fi

#Sigtran Associations
IsAssociationDown=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt | awk '/ESTABLISHED/' | wc -l | tr -s " ")
if [ $IsAssociationDown -ne 10 ]; then
/tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/poke /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/AssociationDown.msg
sleep 10
fi

#Sigtran Associations M3UA Active
IsAssociationActive=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | awk '/Current state  : ACTIVE/' | wc -l | tr -s " ")
if [ $IsAssociationActive -ne 10 ]; then
/tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/poke /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/AssociationActive.msg
sleep 10
fi

#Disk Partition Space > 90%
IsDiskFull=$(df -h | grep "%" | egrep -v Filesystem | awk '{print $5}' | cut -d% -f1 | awk '$(NF)>90 { print }')
if [ ! -z "$IsDiskFull" ]; then
/tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/poke /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/DiskFull.msg
sleep 10
fi

#Apache
IsApacheDown=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt | grep "Apache is DOWN")
if [ ! -z "$IsApacheDown" ]; then
/tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/poke /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/ApacheDown.msg
sleep 10
fi

#Stores
IsStoreDown=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | awk '/FAILED/ || /OFFLINE/ {print $0}' | egrep -v bind | egrep -v SystemID | egrep -v "OFFLINE S")
if [ ! -z "$IsStoreDown" ]; then
/tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/poke /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/StoreDown.msg
sleep 10
fi

#Binds SMPP_routers
IsSyniverseUp=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | grep Syni)
	if [ -z "$IsSyniverseUp" ]; then
	/tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/poke /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/BindDown.msg
	sleep 10
	fi
Iswebservice=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | grep webservice)
	if [ -z "$Iswebservice" ]; then
	/tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/poke /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/BindDown.msg
	sleep 10
	fi
Isspeednet=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | grep speednet)
	if [ -z "$Isspeednet" ]; then
	/tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/poke /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/BindDown.msg
	sleep 10
	fi
Isapple1=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | grep apple1)
	if [ -z "$Isapple1" ]; then
	/tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/poke /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/BindDown.msg
	sleep 10
	fi

#Memmory TOP
	IsMemoryLow=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt | grep "Memmory is very low")
	if [ ! -z "$IsMemoryLow" ]; then
	/tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/poke /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/MemmoryLow.msg
	sleep 10
	fi






	exit
