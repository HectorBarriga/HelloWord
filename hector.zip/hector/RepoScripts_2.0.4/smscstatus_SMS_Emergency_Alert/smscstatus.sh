#!/bin/bash

currentminute=$(perl -e '@d=localtime time(); printf "%02d\n", $d[1]')
if [[ "$currentminute" -le "03" && "$currentminute" -ge "00" ]] || [[ "$currentminute" -le "23" && "$currentminute" -ge "20" ]] || [[ "$currentminute" -le "43" && "$currentminute" -ge "40" ]]; then
SPS_file="oldSPS"
else
SPS_file="SPS"
fi


echo "`tput setaf 3`--------------- Stores -----------------`tput sgr0`"
StangoB=$(awk '/spawn telnet tangoB 11100/ {for(e=1; e<=70; e++) {getline; print}}' /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/$SPS_file.txt | awk '/FAILED/ || /OFFLINE/ {print $0}')
if [ ! -z "$StangoB" ]; then
echo "`tput setaf 1`M2P    STORE tangoB is FAILED or OFFLINE!!!!`tput sgr0`"
else
StatustangoB=$(awk '/spawn telnet tangoB 11100/ {for(f =1; f<=70; f++) {getline; print}}' /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/$SPS_file.txt | grep summary | awk '{print $3;}')
echo "`tput setaf 2`M2P    STORE tangoB is OK        :`tput sgr0` $StatustangoB"
fi
StangoA=$(awk '/spawn telnet tangoA 11100/ {for(a=1; a<=70; a++) {getline; print}}' /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/$SPS_file.txt |  awk '/FAILED/ || /OFFLINE/ {print $0}')
if [ ! -z "$StangoA" ]; then
echo "`tput setaf 1`M2P    STORE tangoA is FAILED or OFFLINE!!!!`tput sgr0`"
else
StatustangoA=$(awk '/spawn telnet tangoA 11100/ {for(b=1; b<=70; b++) {getline; print}}' /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/$SPS_file.txt | grep summary | awk '{print $3;}')
echo "`tput setaf 2`M2P    STORE tangoA is OK        :`tput sgr0` $StatustangoA"
fi
echo ""
StangoB2=$(awk '/spawn telnet tangoB 11101/ {for(g=1; g<=70; g++) {getline; print}}' /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/$SPS_file.txt |  awk '/FAILED/ || /OFFLINE/ {print $0}')
if [ ! -z "$StangoB2" ]; then
echo "`tput setaf 1`OFFNET STORE tangoB is FAILED or OFFLINE!!!!`tput sgr0`"
else
StatustangoB2=$(awk '/spawn telnet tangoB 11101/ {for(h =1; h<=70; h++) {getline; print}}' /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/$SPS_file.txt | grep summary | awk '{print $3;}')
echo "`tput setaf 2`OFFNET STORE tangoB is OK        :`tput sgr0` $StatustangoB2"
fi
StangoA2=$(awk '/spawn telnet tangoA 11101/ {for(c=1; c<=70; c++) {getline; print}}' /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/$SPS_file.txt |  awk '/FAILED/ || /OFFLINE/ {print $0}')
if [ ! -z "$StangoA2" ]; then
echo "`tput setaf 1`OFFNET STORE tangoA is FAILED or OFFLINE!!!!`tput sgr0`"
else
StatustangoA2=$(awk '/spawn telnet tangoA 11101/ {for(d=1; d<=70; d++) {getline; print}}' /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/$SPS_file.txt | grep summary | awk '{print $3;}')
echo "`tput setaf 2`OFFNET STORE tangoA is OK        :`tput sgr0` $StatustangoA2"
fi
StangoC=$(awk '/spawn telnet tangoC 11100/ {for(i=1; i<=70; i++) {getline; print}}' /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/$SPS_file.txt |  awk '/FAILED/ || /OFFLINE/ {print $0}')
echo ""
if [ ! -z "$StangoC" ]; then
echo "`tput setaf 1`P2P    STORE tangoC is FAILED or OFFLINE!!!!`tput sgr0`"
else
StatustangoC=$(awk '/spawn telnet tangoC 11100/ {for(j=1; j<=70; j++) {getline; print}}' /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/$SPS_file.txt | grep summary | awk '{print $3;}')
echo "`tput setaf 2`P2P    STORE tangoC is OK        :`tput sgr0` $StatustangoC"
fi
StangoD=$(awk '/spawn telnet tangoD 11100/ {for(j=1; j<=70; j++) {getline; print}}' /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/$SPS_file.txt |  awk '/FAILED/ || /OFFLINE/ {print $0}')
if [ ! -z "$StangoD" ]; then
echo "`tput setaf 1`P2P    STORE tangoD is FAILED or OFFLINE!!!!`tput sgr0`"
else
StatustangoD=$(awk '/spawn telnet tangoD 11100/ {for(j=1; j<=70; j++) {getline; print}}' /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/$SPS_file.txt | grep summary | awk '{print $3;}')
echo "`tput setaf 2`P2P    STORE tangoD is OK        :`tput sgr0` $StatustangoD"
fi
StangoC1=$(awk '/spawn telnet tangoC 11101/ {for(i=1; i<=70; i++) {getline; print}}' /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/$SPS_file.txt |  awk '/FAILED/ || /OFFLINE/ {print $0}')
echo ""
if [ ! -z "$StangoC1" ]; then
echo "`tput setaf 1`M2P Rt STORE tangoC is FAILED or OFFLINE!!!!`tput sgr0`"
else
StatustangoC1=$(awk '/spawn telnet tangoC 11101/ {for(j=1; j<=70; j++) {getline; print}}' /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/$SPS_file.txt | grep summary | awk '{print $3;}')
echo "`tput setaf 2`M2P Rt STORE tangoC is OK        :`tput sgr0` $StatustangoC1"
fi
StangoD1=$(awk '/spawn telnet tangoD 11100/ {for(j=1; j<=70; j++) {getline; print}}' /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/$SPS_file.txt |  awk '/FAILED/ || /OFFLINE/ {print $0}')
if [ ! -z "$StangoD1" ]; then
echo "`tput setaf 1`M2P Rt STORE tangoD is FAILED or OFFLINE!!!!`tput sgr0`"
else
StatustangoD1=$(awk '/spawn telnet tangoD 11101/ {for(j=1; j<=70; j++) {getline; print}}' /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/$SPS_file.txt | grep summary | awk '{print $3;}')
echo "`tput setaf 2`M2P Rt STORE tangoD is OK        :`tput sgr0` $StatustangoD1"
fi


echo ""
echo "`tput setaf 3`--------CDMA M2P SMPP_router Binds tangoA -----------`tput sgr0`"
cdmam2ptangoa=$(sed -e '1,/CDMA M2P SMPP_router TANGOA/d' -e '/CDMA M2P SMPP_router TANGOB/,$d' /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/$SPS_file.txt | grep "|" | grep -v ReconnTime)
cdmam2ptangob=$(sed -e '1,/CDMA M2P SMPP_router TANGOB/d' -e '/OFFLINE SMPP_router TANGOA/,$d' /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/$SPS_file.txt | grep "|" | grep -v ReconnTime)
if [ ! -z "$cdmam2ptangoa" ]; then
echo "$cdmam2ptangoa"
elif [ ! -z "$cdmam2ptangob" ]; then
echo "`tput setaf 2`Binds should be on tangoB. See below`tput sgr0`"
else 
echo "`tput setaf 1`ALERT !!! CDMA M2P SMPP Traffic is down. Binds are not on tangoA or tangoB`tput sgr0`"
fi
echo ""
echo "`tput setaf 3`--------CDMA M2P SMPP_router Binds tangoB -----------`tput sgr0`"
if [ ! -z "$cdmam2ptangob" ]; then
echo "$cdmam2ptangob"
elif [ ! -z "$cdmam2ptangoa" ]; then
echo "`tput setaf 1`ALERT !!! binds are not established. They should be. `tput setaf 2`However, GSM M2P SMPP Traffic is NOT down becouse they are or tangoA. See above`tput sgr0`"
else 
echo "`tput setaf 1`ALERT !!! CDMA M2P SMPP Traffic is down. Binds are not on tangoA or tangoB`tput sgr0`"
fi
echo ""

gsmm2pbinda=$(sed -e '1,/GSM M2P SMPP_router TANGOA/d' -e '/GSM M2P SMPP_router TANGOB/,$d' /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/$SPS_file.txt | grep "|" | grep -v ReconnTime)
gsmm2pbindb=$(sed -e '1,/GSM M2P SMPP_router TANGOB/d' -e '/M2P STORE TANGOA/,$d' /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/$SPS_file.txt | grep "|" | grep -v ReconnTime)
echo "`tput setaf 3`--------GSM M2P SMPP_router Binds tangoA -----------`tput sgr0`"
if [ ! -z "$gsmm2pbinda" ]; then
echo "$gsmm2pbinda"
elif [ ! -z "$gsmm2pbindb" ]; then
        echo "`tput setaf 2`Binds are on tangoB. See below`tput sgr0`"
else
        echo "`tput setaf 1`ALERT !!! GSM M2P SMPP Traffic is down. Binds are not on tangoA or tangoB`tput sgr0`"
fi
echo ""
echo "`tput setaf 3`--------GSM M2P SMPP_router Binds tangoB -----------`tput sgr0`"
if [ ! -z "$gsmm2pbindb" ]; then
echo "$gsmm2pbindb"
elif [ ! -z "$gsmm2pbinda" ]; then
        echo "`tput setaf 2`Binds are on tangoA. See above`tput sgr0`"
else
        echo "`tput setaf 1`ALERT !!! GSM M2P SMPP Traffic is down. Binds are not on tangoA or tangoB`tput sgr0`"
fi
echo ""

offnetbindA=$(sed -e '1,/OFFLINE SMPP_router TANGOA/d' -e '/OFFLINE SMPP_router TANGOB/,$d' /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/$SPS_file.txt | grep "|" | grep -v ReconnTime)
offnetbindB=$(sed -e '1,/OFFLINE SMPP_router TANGOB/d' -e '/SMSC Interface SMPP_router TANGOA/,$d' /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/$SPS_file.txt | grep "|" | grep -v ReconnTime)
echo "`tput setaf 3`-------OFFNET SMPP_router Binds tangoA ---------`tput sgr0`"
if [ ! -z "$offnetbindA" ]; then
echo "$offnetbindA"
elif [ ! -z "$offnetbindB" ]; then
	echo "`tput setaf 2`Binds are on tangoB. See below`tput sgr0`"
else
	echo "`tput setaf 1`ALERT !!! Syniverse Traffic is down. Binds are not on tangoA or tangoB`tput sgr0`"
fi
echo ""
echo "`tput setaf 3`-------OFFNET SMPP_router Binds tangoB ---------`tput sgr0`"
if [ ! -z "$offnetbindB" ]; then
echo "$offnetbindB"
elif [ ! -z "$offnetbindA" ]; then
        echo "`tput setaf 2`Binds are on tangoA. See above`tput sgr0`"
else
        echo "`tput setaf 1`ALERT !!! Syniverse Traffic is down. Binds are not on tangoA or tangoB`tput sgr0`"
fi
echo ""

esmebindA=$( awk '/spawn telnet tangoA 13033/ {for(x=1; x<=70; x++) {getline; print}}' /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/$SPS_file.txt | grep "|" | grep -v ReconnTime)
esmebindB=$(awk '/spawn telnet tangoB 13033/ {for(y=1; y<=70; y++) {getline; print}}' /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/$SPS_file.txt | grep "|" | grep -v ReconnTime)
echo "`tput setaf 3`-------(SMSC Interface - BLT) - ESME SMPP_router Binds tangoA ---------`tput sgr0`"
if [ ! -z "$esmebindA" ]; then
echo "$esmebindA"
elif [ ! -z "$esmebindB" ]; then
echo "`tput setaf 1`ALERT !!! binds are not established. They should be. `tput setaf 2`However, SMSC Interface - BLT M2P SMPP Traffic is NOT down becouse they are or tangoB. See below`tput sgr0`"
else
echo "`tput setaf 1`ALERT !!! CDMA M2P SMPP Traffic is down. Binds are not on tangoA or tangoB`tput sgr0`"
fi
echo ""
echo "`tput setaf 3`-------(SMSC Interface - BLT) - ESME SMPP_router Binds tangoB ---------`tput sgr0`"
if [ ! -z "$esmebindB" ]; then
echo "$esmebindB"
elif [ ! -z "$esmebindA" ]; then
echo "`tput setaf 1`ALERT !!! binds are not established. They should be. `tput setaf 2`However, SMSC Interface - BLT M2P SMPP Traffic is NOT down becouse they are or tangoA. See above`tput sgr0`"
else
echo "`tput setaf 1`ALERT !!! SMSC Interface - BLT M2P SMPP Traffic is down. Binds are not on tangoA or tangoB`tput sgr0`"
fi
echo ""
