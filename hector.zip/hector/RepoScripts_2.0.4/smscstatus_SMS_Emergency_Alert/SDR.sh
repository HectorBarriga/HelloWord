#!/bin/bash

############################################
# SMS Daily Report (SDR)
#
# SMSC Belize Speednet
############################################


# mps
AreProcessesFailed=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | grep "Failed" | egrep -v IMS)

# VirtualIPs
IsSmppVIP=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | grep "10.23.2.233")
IsGSMSmppVIP=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | grep "10.23.2.234")
IsIntVIP=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | grep "172.20.2.254")

# Mysql
IsMysql=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt | grep "MYSQL IS DOWN")
IsReplicationOk=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt | awk '/Slave_IO_Running/ || /Slave_SQL_Running/' | awk '/Yes/' | wc -l | tr -s " ")

#Tomcat
IsTomcat=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt | grep "Tomcat is DOWN")

#Sigtran Associations
IsAssociationDown=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt | awk '/ESTABLISHED/' | wc -l | tr -s " ")
IsAssociationActive=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | awk '/Current state  : ACTIVE/' | wc -l | tr -s " ")

#Disk Partition Space > 90%
IsDiskFull=$(df -h | grep "%" | egrep -v Use | awk '{print $5}' | cut -d% -f1 | awk '$(NF)>90 { print }')

#Apache
IsApacheDown=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt | grep "Apache is DOWN")

#Stores
IsStoreDown=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | awk '/FAILED/ || /OFFLINE/ {print $0}' | egrep -v bind | egrep -v SystemID | egrep -v "OFFLINE S")

#Binds SMPP_routers
IsSyniverseUp=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | grep Syni)
Iswebservice=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | grep webservice)
Isspeednet=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | grep speednet)
Isapple1=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SPS.txt | grep apple1)

#Memmory TOP
IsMemoryLow=$(/bin/cat /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/fullstatus*.txt | grep "Memmory is very low")

if [ -z "$AreProcessesFailed" ] && [ ! -z "$IsSmppVIP" ] &&  [ ! -z "$IsGSMSmppVIP" ] &&  [ ! -z "$IsIntVIP" ] && [ -z "$IsMysql" ] && [ $IsReplicationOk -eq 2 ] && [ -z "$IsTomcat" ] && [ $IsAssociationDown -eq 10 ] && [ $IsAssociationActive -eq 10 ] && [ -z "$IsDiskFull" ] && [ -z "$IsApacheDown" ] && [ -z "$IsStoreDown" ] && [ ! -z "$IsSyniverseUp" ] && [ ! -z "$Iswebservice" ] && [ ! -z "$Isspeednet" ] && [ ! -z "$Isapple1" ] && [ -z "$IsMemoryLow" ]; then
/tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/poke /tango/logs/COStaff/hector/sh_scripts/SMS_Emergency_Alert/templates/SDR_EverthingOK.msg
echo ""
echo "Everthing is OK"
echo "---------------"
fi
echo "AreProcessesFailed= [ $AreProcessesFailed ] It must be empty"
echo "IsSmppVIP= [ $IsSmppVIP ] It must not be empty"
echo "IsSmppVIP= [ $IsGSMSmppVIP ] It must not be empty"
echo "IsIntVIP= [ $IsIntVIP ] It must not be empty"
echo "isMysql= [ $isMysql ] It must be empty"
echo "IsReplicationOk= [ $IsReplicationOk ] It must be 2"
echo "IsTomcat= [ $IsTomcat ] It must be empty"
echo "IsAssociationDown= [ $IsAssociationDown ] It must be 10"
echo "IsAssociationActive= [ $IsAssociationActive ] It must be 10"
echo "IsDiskFull [ $IsDiskFull ] It must be empty"
echo "IsApacheDown= [$IsApacheDown ] It must be empty"
echo "IsStoreDown= [ $IsStoreDown ] It must be empty"
echo "IsSyniverseUp= 
[ $IsSyniverseUp ] 
It must not be empty"
echo ""
echo "Iswebservice= 
[ $Iswebservice ] 
It must not be empty"
echo ""
echo "Isspeednet= 
[ $Isspeednet ] 
It must not be empty"
echo ""
echo "Isapple1= 
[ $Isapple1 ] 
It must not be empty"
echo ""
echo "IsMemoryLow= [ $IsMemoryLow ] It must be empty"



exit

