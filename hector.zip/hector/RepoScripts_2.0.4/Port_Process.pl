#!/bin/bash
echo -n "Enter port > "
read port
whoami=$(whoami)
echo "`tput setaf 2`"
if [ "$whoami" == "tango" ];then
        sudo netstat -nltp | egrep -w "$port" | awk '{print $7}' | cut -d'/' -f1 | while read in; do ps -ef | grep "$in" | egrep -v color | egrep -v grep;done
else
        netstat -nltp | egrep -w "$port" | awk '{print $7}' | cut -d'/' -f1 | while read in; do ps -ef | grep "$in" | egrep -v color | egrep -v grep;done
fi
echo "`tput sgr0`"