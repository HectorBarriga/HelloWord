#!/bin/bash

# Initial Settings
site=TELEFONICA #MOBILYOCSTRIAL #TELEFONICA #GITElSalvador
whiteliststring=none
blackliststring=none
convertRemoteEtcHostAliasFrom=
convertRemoteEtcHostAliasTo=
convertRemoteEtcHostAliasFrom_2=
convertRemoteEtcHostAliasTo_2=
convertRemoteEtcHostAliasFrom_3=
convertRemoteEtcHostAliasTo_3=
etcHosts=/etc/hosts

if [ -z "$whiteliststring" ] || [ "$whiteliststring" == "none" ];then
        whiteliststring=''
fi
if [ -z "$blackliststring" ];then
        blackliststring='none'
fi

convertRemoteHost()
{
if [ "$in" == "$convertRemoteEtcHostAliasFrom" ];then
        in=$convertRemoteEtcHostAliasTo
elif [ "$in" == "$convertRemoteEtcHostAliasFrom_2" ];then
        in=$convertRemoteEtcHostAliasTo_2
elif [ "$in" == "$convertRemoteEtcHostAliasFrom_3" ];then
        in=$convertRemoteEtcHostAliasTo_3
fi
}

DIR=$(echo "`dirname $0`")
while getopts c:u:p:m:h option;
do
        case $option in
                c) cmd=$OPTARG;;
                u) user=$OPTARG;;
                p) pattern=$OPTARG;;
                m) etcHosts=$OPTARG;;
                h) echo "
        Usage: sshCommandCluster.sh

        This sh script is to ssh commands accross all remote machines especified in $etcHosts or in particular clusters

        Version:     0.1.0
        Author:      Hector Barriga
        Copyright (c) Tango Telecom 2018

               Options:

               -h <help>        Show help

               -c <command>     Destination directory

               -u <Dest user>   Remote server's user. You will need to enter password for each transfer

               -p <Dest host>   Destination hosts. Note, you can use a pattern from $etcHosts. It is
                                useful do you want to run commans on all machines that belong to a cluster.
                                You can add multiple paterns or hostnames separated by commas

               -m <etc hosts>   Use another etc hosts in case $etcHosts is not compatible

               Examples:

               e.g. sshCommandCluster.sh -c \"ls -altr /tango/\" -m /tango/logs/COSTAFF/hector/sh_scripts/hosts
                    It runs \"ls -altr /tango/\" on all machines especified in /tango/logs/COSTAFF/hector/sh_scripts/hosts

               e.g. sshCommandCluster.sh -c \"ls -altr /tango/\" -p NAC,DMZ
                    It runs \"ls -altr /tango/\" on all NAC machines

               "; h="true";;
        esac
done

if [ "$h" != "true" ];then



printResult()
{
getEqual=""
foundItAgain=""
foundIt=""
while read in
do
        if [ "$in" == "==================================================================================" ];then
                getEqual="yes"
                if [ "$foundIt" == "yes" ] && [ "$in" == "==================================================================================" ];then
                        getEqual="no"
                        foundItAgain="yes"
                fi
        fi
        if [ "$getEqual" == "yes" ];then
                foundIt="yes"
        else
                if [ "$foundItAgain" == "yes" ];then
                        foundItAgain="no"
                else
                        echo "$in"
                fi
        fi
done < <(cat $DIR/.tempFile)
}

if [ -z "$cmd" ];then
        echo -e "`tput setaf 1`\nWhat's the command, please try again sshCommandCluster.sh -c \"<command>\", bye`tput sgr0`\n"
        exit
fi
getRm=$( echo "$cmd" | grep "rm ")
getRm2=$( echo "$cmd" | grep " rm ")
getRm3=$( echo "$cmd" | grep "rm -")
if [ ! -z "$getRm" ] || [ ! -z "$getRm2" ] || [ ! -z "$getRm3" ];then
        echo -e "`tput setaf 1`\nSorry, \"rm\" command is not permited, bye`tput sgr0`\n"
        exit
fi
hostname=$(hostname)
if [ ! -z "$pattern" ];then
        listOfPatternsArray=(`echo ${pattern} | sed 's/,/ /g'`)
        listOfPatternsArrayLengh=${#listOfPatternsArray[@]}
else
        listOfPatternsArray="#"
        listOfPatternsArrayLengh=1
fi


if [ -z "$user" ];then
        user="tango"
fi

for (( j=0;j<$listOfPatternsArrayLengh;j++))
do
if [ "$site" == "ZainSudan" ];then
        if [ "$user" == "root" ];then
                echo -n "`tput setaf 2`root Password = bernabeuT0ur`tput sgr0`"
                cat $etcHosts | grep tango | egrep "#" | egrep -v NAC | egrep -v DMZ | egrep "${listOfPatternsArray[$j]}" | egrep -v $hostname | awk '{print $4}' | while read in;do echo -e "\n`tput setaf 3`ssh root@$in -o ConnectTimeout=5 \"$cmd\"`tput sgr0`";echo "$cmd" | ssh root@$in -o ConnectTimeout=5 > $DIR/.tempFile 2> /dev/null;printResult;done
        else
                cat $etcHosts | grep tango | egrep "#" | egrep -v NAC | egrep -v DMZ | egrep "${listOfPatternsArray[$j]}" | egrep -v $hostname | awk '{print $4}' | while read in;do echo -e "\n`tput setaf 3`ssh $user@$in -T -o ConnectTimeout=5 \"$cmd\"`tput sgr0`";echo "$cmd" | ssh $user@$in -T -o ConnectTimeout=5 /bin/bash --noprofile > $DIR/.tempFile 2> /dev/null;printResult;done
        fi
elif [ "$site" == "MOBILYOCSTRIAL" ];then
        if [ "$user" == "root" ];then
                echo -n "`tput setaf 1`root Password = UNKOWN`tput sgr0`"
                cat $etcHosts | grep tango | egrep "#" | egrep "${listOfPatternsArray[$j]}" | egrep -v $hostname | awk '{print $5}' | while read in;do echo -e "\n`tput setaf 3`ssh root@$in -o ConnectTimeout=5 \"$cmd\"`tput sgr0`";echo "$cmd" | ssh root@$in -o ConnectTimeout=5 > $DIR/.tempFile 2> /dev/null;printResult;done
        else
                cat $etcHosts | grep tango | egrep "#" | egrep "${listOfPatternsArray[$j]}" | egrep -v $hostname | awk '{print $5}' | while read in;do echo -e "\n`tput setaf 3`ssh $user@$in -o ConnectTimeout=5 \"$cmd\"`tput sgr0`";echo "$cmd" | ssh $user@$in -o ConnectTimeout=5 -T /bin/bash --noprofile > $DIR/.tempFile 2> /dev/null;printResult;done
        fi

elif [ "$site" == "GITElSalvador" ] || [ "$site" == "Telcel" ]|| [ "$site" == "DIGICEL" ] || [ "$site" == "TELEFONICA" ];then

        if [ "$user" == "root" ];then
                if [ "$site" == "TELEFONICA" ];then
                        echo -n "`tput setaf 1`root Password = bernabeuT0ur`tput sgr0`"
                else
                        echo -n "`tput setaf 1`root Password = UNKOWN`tput sgr0`"
                fi
                cat $etcHosts | grep "$whiteliststring" | egrep "#" | egrep -v "=" | egrep "${listOfPatternsArray[$j]}" | egrep -v $hostname | egrep -v $blackliststring | awk '{print $5}' | while read in;do convertRemoteHost;echo -e "\n`tput setaf 3`ssh root@$in -o ConnectTimeout=5 \"$cmd\"`tput sgr0`";echo "$cmd" | ssh root@$in -o ConnectTimeout=5 > $DIR/.tempFile 2> /dev/null;printResult;done
        else
                cat $etcHosts | grep "$whiteliststring" | egrep "#" | egrep -v "=" | egrep "${listOfPatternsArray[$j]}" | egrep -v $hostname | egrep -v $blackliststring | awk '{print $5}' | while read in;do convertRemoteHost;echo -e "\n`tput setaf 3`ssh $user@$in -o ConnectTimeout=5 \"$cmd\"`tput sgr0`";echo "$cmd" | ssh $user@$in -o ConnectTimeout=5 -T /bin/bash --noprofile > $DIR/.tempFile 2> /dev/null;printResult;done
        fi
fi
done
fi