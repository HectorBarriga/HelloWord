#!/bin/bash

printecho()
{
echo "[ `date +20%y%m%d" "%H:%M:%S` ] $1= cat /tango/scripts/Generic/Others/MRS_Reports/258_DOL_CDRs/* | egrep $3 | egrep ',5' | egrep '$HH$v|$HH$w|$HH$x|$HH$y|$HH$z' | nawk -F',' '{print \$21}' | wc -l | tr -d ' '" >> /tango/scripts/Generic/Others/MRS_Reports/logs_MRS_upload_SRT_WebService_258_DOL.log
echo "[ `date +20%y%m%d" "%H:%M:%S` ] $2= cat /tango/scripts/Generic/Others/MRS_Reports/258_DOL_CDRs/* | egrep $3 | egrep -v ',5' | egrep '$HH$v|$HH$w|$HH$x|$HH$y|$HH$z' | nawk -F',' '{print \$21}' | wc -l | tr -d ' '" >> /tango/scripts/Generic/Others/MRS_Reports/logs_MRS_upload_SRT_WebService_258_DOL.log
}

#debug=true
debug=false
timenow=$(perl -e '@d=localtime time(); printf "%02d%02d\n", $d[2],$d[1]')
filterMMnow=$(perl -e '@d=localtime time(); printf "%02d\n", $d[1]' | sed 's/^.//')

if [ "$timenow" == "0004" ]; then
        todate=$(perl -e '@d=localtime time()-86400; printf "%4d-%02d-%02d \n", $d[5]+1900,$d[4]+1,$d[3]')
else
        todate=$(perl -e '@d=localtime time(); printf "%4d-%02d-%02d \n", $d[5]+1900,$d[4]+1,$d[3]')
fi

rm /tango/scripts/Generic/Others/MRS_Reports/258_DOL_CDRs/*
if [ "$filterMMnow" -gt "5" ]; then
        cdrhour=$(perl -e '@d=localtime time()-300; printf "%4d%02d%02d_%02d%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1]' | sed 's/.$//')
        HH=$(perl -e '@d=localtime time(); printf ",%02d:%02d\n", $d[2],$d[1]' | sed 's/.$//')
        mysqlHH=$(perl -e '@d=localtime time(); printf "%02d:%02d\n", $d[2],$d[1]' | sed 's/.$//')
        v=0
        w=1
        x=2
        y=3
        z=4
else
        cdrhourold=$(perl -e '@d=localtime time()-300; printf "%4d%02d%02d_%02d%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1]' | sed 's/.$//')
        cdrhour=$(perl -e '@d=localtime time(); printf "%4d%02d%02d_%02d%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1]' | sed 's/.$//')
        HH=$(perl -e '@d=localtime time()-300; printf ",%02d:%02d\n", $d[2],$d[1]' | sed 's/.$//')
        mysqlHH=$(perl -e '@d=localtime time()-300; printf "%02d:%02d\n", $d[2],$d[1]' | sed 's/.$//')
        v=5
        w=6
        x=7
        y=8
        z=9
        scp tangoA:/tango/data/cdr/ussd_si_production/PROD_USSD_SI_tangoA.$cdrhourold* /tango/scripts/Generic/Others/MRS_Reports/258_DOL_CDRs/
        cp /tango/data/cdr/ussd_si_production/PROD_USSD_SI_tangoB.$cdrhourold* /tango/scripts/Generic/Others/MRS_Reports/258_DOL_CDRs/
fi

mysqltoday=$todate$mysqlHH$v

scp tangoA:/tango/data/cdr/ussd_si_production/PROD_USSD_SI_tangoA.$cdrhour* /tango/scripts/Generic/Others/MRS_Reports/258_DOL_CDRs/
scp tangoA:/tango/data/cdr/active_PROD_USSD_SI.cdr /tango/scripts/Generic/Others/MRS_Reports/258_DOL_CDRs/active_PROD_USSD_SI_tangoA.cdr
cp /tango/data/cdr/ussd_si_production/PROD_USSD_SI_tangoB.$cdrhour* /tango/scripts/Generic/Others/MRS_Reports/258_DOL_CDRs/
cp /tango/data/cdr/active_PROD_USSD_SI.cdr /tango/scripts/Generic/Others/MRS_Reports/258_DOL_CDRs/active_PROD_USSD_SI_tangoB.cdr

if [ "$debug" == "true" ]; then
echo ""  >> /tango/scripts/Generic/Others/MRS_Reports/logs_MRS_upload_SRT_WebService_258_DOL.log
echo ""  >> /tango/scripts/Generic/Others/MRS_Reports/logs_MRS_upload_SRT_WebService_258_DOL.log
echo ""  >> /tango/scripts/Generic/Others/MRS_Reports/logs_MRS_upload_SRT_WebService_258_DOL.log
echo "[ `date +20%y%m%d" "%H:%M:%S` ] ###################################### START [`date +20%y%m%d" "%H:%M:%S`] ###########################################"  >> /tango/scripts/Generic/Others/MRS_Reports/logs_MRS_upload_SRT_WebService_258_DOL.log
echo "[ `date +20%y%m%d" "%H:%M:%S` ] todate=$todate Its the date that will be used for sql insert query in mysql DB. timenow=$timenow" >> /tango/scripts/Generic/Others/MRS_Reports/logs_MRS_upload_SRT_WebService_258_DOL.log
echo "[ `date +20%y%m%d" "%H:%M:%S` ] Removing 258_DOL_CDRs ... rm /tango/scripts/Generic/Others/MRS_Reports/258_DOL_CDRs/*" >> /tango/scripts/Generic/Others/MRS_Reports/logs_MRS_upload_SRT_WebService_258_DOL.log
echo "[ `date +20%y%m%d" "%H:%M:%S` ] -------------- Get 258_DOL_CDRs under /tango/scripts/Generic/Others/MRS_Reports/258_DOL_CDRs/ -----------------"  >> /tango/scripts/Generic/Others/MRS_Reports/logs_MRS_upload_SRT_WebService_258_DOL.log
echo "[ `date +20%y%m%d" "%H:%M:%S` ] Copying.... scp tangoA:/tango/data/cdr/ussd_si_production/PROD_USSD_SI_tangoA.$cdrhour* /tango/scripts/Generic/Others/MRS_Reports/258_DOL_CDRs/"  >> /tango/scripts/Generic/Others/MRS_Reports/logs_MRS_upload_SRT_WebService_258_DOL.log
echo "[ `date +20%y%m%d" "%H:%M:%S` ] cp /tango/data/cdr/ussd_si_production/PROD_USSD_SI_tangoB.$cdrhour* /tango/scripts/Generic/Others/MRS_Reports/258_DOL_CDRs/" >> /tango/scripts/Generic/Others/MRS_Reports/logs_MRS_upload_SRT_WebService_258_DOL.log
ls -altr /tango/scripts/Generic/Others/MRS_Reports/258_DOL_CDRs/  >> /tango/scripts/Generic/Others/MRS_Reports/logs_MRS_upload_SRT_WebService_258_DOL.log
fi


validarClaveGVPDV=$(cat /tango/scripts/Generic/Others/MRS_Reports/258_DOL_CDRs/* | egrep VAS_SI_PE_258_SR_DOL_GestionaVendedorPDVWS_validarClave | egrep ",5" | egrep "$HH$v|$HH$w|$HH$x|$HH$y|$HH$z" | nawk -F',' '{print $21}' | wc -l | tr -d ' ')
validarClaveGVPDV_Errors=$(cat /tango/scripts/Generic/Others/MRS_Reports/258_DOL_CDRs/* | egrep VAS_SI_PE_258_SR_DOL_GestionaVendedorPDVWS_validarClave | egrep -v ",5" | egrep "$HH$v|$HH$w|$HH$x|$HH$y|$HH$z" | nawk -F',' '{print $21}' | wc -l | tr -d ' ')

obtPregCliente=$(cat /tango/scripts/Generic/Others/MRS_Reports/258_DOL_CDRs/* | egrep VAS_SI_PE_258_SR_DOL_IdentificacionClienteWS_obtenerPreguntas | egrep ",5" | egrep "$HH$v|$HH$w|$HH$x|$HH$y|$HH$z" | nawk -F',' '{print $21}' | wc -l | tr -d ' ')
obtPregCliente_Errors=$(cat /tango/scripts/Generic/Others/MRS_Reports/258_DOL_CDRs/* | egrep VAS_SI_PE_258_SR_DOL_IdentificacionClienteWS_obtenerPreguntas | egrep -v ",5" | egrep "$HH$v|$HH$w|$HH$x|$HH$y|$HH$z" |  nawk -F',' '{print $21}' | wc -l | tr -d ' ')

respPregCliente=$(cat /tango/scripts/Generic/Others/MRS_Reports/258_DOL_CDRs/* | egrep VAS_SI_PE_258_SR_DOL_IdentificacionClienteWS_responderPreguntas | egrep ",5" | egrep "$HH$v|$HH$w|$HH$x|$HH$y|$HH$z" | nawk -F',' '{print $21}' | wc -l | tr -d ' ')
respPregCliente_Errors=$(cat /tango/scripts/Generic/Others/MRS_Reports/258_DOL_CDRs/* | egrep VAS_SI_PE_258_SR_DOL_IdentificacionClienteWS_responderPreguntas | egrep -v ",5" | egrep "$HH$v|$HH$w|$HH$x|$HH$y|$HH$z" | nawk -F',' '{print $21}' | wc -l | tr -d ' ')

confUsoInformacion=$(cat /tango/scripts/Generic/Others/MRS_Reports/258_DOL_CDRs/* | egrep VAS_SI_PE_258_SR_DOL_IdentificacionClienteWS_confirmarUsoInformacion | egrep ",5" | egrep "$HH$v|$HH$w|$HH$x|$HH$y|$HH$z" | nawk -F',' '{print $21}' | wc -l | tr -d ' ')
confUsoInformacion_Errors=$(cat /tango/scripts/Generic/Others/MRS_Reports/258_DOL_CDRs/* | egrep VAS_SI_PE_258_SR_DOL_IdentificacionClienteWS_confirmarUsoInformacion | egrep -v ",5" | egrep "$HH$v|$HH$w|$HH$x|$HH$y|$HH$z" | nawk -F',' '{print $21}' | wc -l | tr -d ' ')


echo "insert into SRT_WebService_258_DOL_Report (Date_Time,validarClaveGVPDV_Errors,obtPregCliente,validarClaveGVPDV,respPregCliente,confUsoInformacion,obtPregCliente_Errors,respPregCliente_Errors,confUsoInformacion_Errors) values ('$mysqltoday','$validarClaveGVPDV_Errors','$obtPregCliente','$validarClaveGVPDV','$respPregCliente','$confUsoInformacion','$obtPregCliente_Errors','$respPregCliente_Errors','$confUsoInformacion_Errors');" | /usr/share/mysql/bin/mysql -u root -pclaro123 mrs_combined_reports_db





if [ "$debug" == "true" ]; then
printecho validarClaveGVPDV validarClaveGVPDV_Errors VAS_SI_PE_258_SRT_DOL_GestionaVendedorPDVWS_validarClave
printecho obtPregCliente obtPregCliente_Errors VAS_SI_PE_258_SRT_DOL_IdentificacionClienteWS_obtenerPreguntas
printecho respPregCliente respPregCliente_Errors VAS_SI_PE_258_SRT_DOL_IdentificacionClienteWS_responderPreguntas
printecho confUsoInformacion confUsoInformacion_Errors VAS_SI_PE_258_SRT_DOL_IdentificacionClienteWS_confirmarUsoInformacion

echo "[ `date +20%y%m%d" "%H:%M:%S` ] validarClaveGVPDV=$validarClaveGVPDV" >> /tango/scripts/Generic/Others/MRS_Reports/logs_MRS_upload_SRT_WebService_258_DOL.log
echo "[ `date +20%y%m%d" "%H:%M:%S` ] validarClaveGVPDV_Errors=$validarClaveGVPDV_Errors" >> /tango/scripts/Generic/Others/MRS_Reports/logs_MRS_upload_SRT_WebService_258_DOL.log
echo "[ `date +20%y%m%d" "%H:%M:%S` ] obtPregCliente=$obtPregCliente" >> /tango/scripts/Generic/Others/MRS_Reports/logs_MRS_upload_SRT_WebService_258_DOL.log
echo "[ `date +20%y%m%d" "%H:%M:%S` ] obtPregCliente_Errors=$obtPregCliente_Errors" >> /tango/scripts/Generic/Others/MRS_Reports/logs_MRS_upload_SRT_WebService_258_DOL.log
echo "[ `date +20%y%m%d" "%H:%M:%S` ] respPregCliente=$respPregCliente" >> /tango/scripts/Generic/Others/MRS_Reports/logs_MRS_upload_SRT_WebService_258_DOL.log
echo "[ `date +20%y%m%d" "%H:%M:%S` ] respPregCliente_Errors=$respPregCliente_Errors" >> /tango/scripts/Generic/Others/MRS_Reports/logs_MRS_upload_SRT_WebService_258_DOL.log
echo "[ `date +20%y%m%d" "%H:%M:%S` ] confUsoInformacion=$confUsoInformacion" >> /tango/scripts/Generic/Others/MRS_Reports/logs_MRS_upload_SRT_WebService_258_DOL.log
echo "[ `date +20%y%m%d" "%H:%M:%S` ] confUsoInformacion_Errors=$confUsoInformacion_Errors" >> /tango/scripts/Generic/Others/MRS_Reports/logs_MRS_upload_SRT_WebService_258_DOL.log

echo "insert into SRT_WebService_258_DOL_Report (Date_Time,validarClaveGVPDV_Errors,obtPregCliente,validarClaveGVPDV,respPregCliente,confUsoInformacion,obtPregCliente_Errors,respPregCliente_Errors,confUsoInformacion_Errors) values ('$mysqltoday','$validarClaveGVPDV_Errors','$obtPregCliente','$validarClaveGVPDV','$respPregCliente','$confUsoInformacion','$obtPregCliente_Errors','$respPregCliente_Errors','$confUsoInformacion_Errors'); | /usr/share/mysql/bin/mysql -u root
-pclaro123 mrs_combined_reports_db" >> /tango/scripts/Generic/Others/MRS_Reports/logs_MRS_upload_SRT_WebService_258_DOL.log
fi