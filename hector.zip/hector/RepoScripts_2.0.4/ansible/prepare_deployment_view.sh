#!/bin/bash

######################################
# REPORTING PLATFORM RELEASE
VERSION=3.0.0
DEPS_VERSION=4.0.0
VIA_ATLAS=yes
######################################
REPORTING_PLATFORM_VERSION=3.0.0
TANGO_METRICBEAT_VERSION=3.0.0
TANGO_ELASTIC_VERSION=3.0.0
TANGO_FILEBEAT_VERSION=3.0.0
TANGO_KIBANA_VERSION=3.0.0
TANGO_LOGSTASH_VERSION=3.0.0
#####################################



getopt --test > /dev/null
if [[ $? -ne 4 ]]; then
    echo "I'm sorry, `getopt --test` failed in this environment."
    exit 1
fi

OPTIONS=d
LONGOPTIONS=download

# -temporarily store output to be able to check for errors
# -e.g. use "--options" parameter by name to activate quoting/enhanced mode
# -pass arguments only via   -- "$@" to separate them correctly
PARSED=$(getopt --options=$OPTIONS --longoptions=$LONGOPTIONS --name "$0" -- "$@")
if [[ $? -ne 0 ]]; then
    # e.g. $? == 1
    # then getopt has complained about wrong arguments to stdout
    exit 2
fi
# read getopt's output this way to handle the quoting right:
eval set -- "$PARSED"

function download_from_tangier() {
    # if the tangier directory does not exist the wget shall create it
    wget -P tangier http://tangier/releases/Products/Tarballs/reporting-platform/$DEPS_VERSION/reporting-platform-dependencies.tar.gz;
    wget -P tangier http://tangier/releases/Products/Tarballs/reporting-platform/$VERSION/tango-metricbeat-$TANGO_METRICBEAT_VERSION.tar.gz
    wget -P tangier http://tangier/releases/Products/Tarballs/reporting-platform/$VERSION/tango-elasticsearch-$TANGO_ELASTIC_VERSION.tar.gz
    wget -P tangier http://tangier/releases/Products/Tarballs/reporting-platform/$VERSION/tango-filebeat-$TANGO_FILEBEAT_VERSION.tar.gz
    wget -P tangier http://tangier/releases/Products/Tarballs/reporting-platform/$VERSION/tango-kibana-$TANGO_KIBANA_VERSION.tar.gz
    wget -P tangier http://tangier/releases/Products/Tarballs/reporting-platform/$VERSION/tango-logstash-$TANGO_LOGSTASH_VERSION.tar.gz
    wget -P tangier http://tangier/releases/Products/Tarballs/reporting-platform/$VERSION/reporting-ansible-$REPORTING_PLATFORM_VERSION.tar.gz
}
function download_from_tangier_via_atlas() {
    # if the tangier directory does not exist create_directory_if_not_exist shall create it
    TANGIER=/tango/install/tangier;
    create_directory_if_not_exist $TANGIER
    cd $TANGIER
    ssh tangier "wget -P /export/home/hector/ansible/Telefonica/ELK_installation/ http://tangier/releases/Products/Tarballs/reporting-platform/$DEPS_VERSION/reporting-platform-dependencies.tar.gz;"
    ssh tangier "wget -P /export/home/hector/ansible/Telefonica/ELK_installation/ http://tangier/releases/Products/Tarballs/reporting-platform/$VERSION/tango-metricbeat-$TANGO_METRICBEAT_VERSION.tar.gz"
    ssh tangier "wget -P /export/home/hector/ansible/Telefonica/ELK_installation/ http://tangier/releases/Products/Tarballs/reporting-platform/$VERSION/tango-elasticsearch-$TANGO_ELASTIC_VERSION.tar.gz"
    ssh tangier "wget -P /export/home/hector/ansible/Telefonica/ELK_installation/ http://tangier/releases/Products/Tarballs/reporting-platform/$VERSION/tango-filebeat-$TANGO_FILEBEAT_VERSION.tar.gz"
    ssh tangier "wget -P /export/home/hector/ansible/Telefonica/ELK_installation/ http://tangier/releases/Products/Tarballs/reporting-platform/$VERSION/tango-kibana-$TANGO_KIBANA_VERSION.tar.gz"
    ssh tangier "wget -P /export/home/hector/ansible/Telefonica/ELK_installation/ http://tangier/releases/Products/Tarballs/reporting-platform/$VERSION/tango-logstash-$TANGO_LOGSTASH_VERSION.tar.gz"
    ssh tangier "wget -P /export/home/hector/ansible/Telefonica/ELK_installation/ http://tangier/releases/Products/Tarballs/reporting-platform/$VERSION/reporting-ansible-$REPORTING_PLATFORM_VERSION.tar.gz"
    scp tangier:/export/home/hector/ansible/Telefonica/ELK_installation/*tar.gz .
    ssh tangier "rm /export/home/hector/ansible/Telefonica/ELK_installation/*tar.gz*"
}

function create_directory_if_not_exist() {
    if [ ! -d "$1" ]; then
       mkdir -p "$1";
    fi
}

function deployment_view() {
    TANGIER=/tango/install/tangier;
    PACKAGES=/tango/install/packages;
    REPORTING_PLATFORM_DEPENDENCIES=/tango/install/packages/reporting-platform-dependencies;
    REPORTING_PLATFORM_DATA=/tango/install/packages/reporting-platform-data;
    REPORTING_PLATFORM_SERVICE=/tango/install/packages/reporting-platform-service;
    REPORTING_PLATFORM_SHIPPER=/tango/install/packages/reporting-platform-shipper;

    create_directory_if_not_exist $PACKAGES
    create_directory_if_not_exist $REPORTING_PLATFORM_DEPENDENCIES
    create_directory_if_not_exist $REPORTING_PLATFORM_DATA
    create_directory_if_not_exist $REPORTING_PLATFORM_SERVICE
    create_directory_if_not_exist $REPORTING_PLATFORM_SHIPPER

    # Handle reporting-platform dependencies
    mv $TANGIER/reporting-platform-dependencies.tar.gz $REPORTING_PLATFORM_DEPENDENCIES;

    # Handle reporting-platform-data
    echo "Handle reporting-platform-data";
    gunzip $TANGIER/tango-elasticsearch-$TANGO_ELASTIC_VERSION.tar.gz $TANGIER/tango-metricbeat-$TANGO_METRICBEAT_VERSION.tar.gz
    cat $TANGIER/tango-elasticsearch-$TANGO_ELASTIC_VERSION.tar $TANGIER/tango-metricbeat-$TANGO_METRICBEAT_VERSION.tar >> $REPORTING_PLATFORM_DATA/reporting-platform-data.tar;
    gzip $REPORTING_PLATFORM_DATA/reporting-platform-data.tar;

    # Handle reporting-platform-service
    echo "Handle reporting-platform-service";
    echo "going gunzip"
    #gunzip $TANGIER/tango-elasticsearch-$TANGO_ELASTIC_VERSION.tar.gz $TANGIER/reporting-platform-$REPORTING_PLATFORM_VERSION.tar.gz $TANGIER/tango-kibana-$TANGO_KIBANA_VERSION.tar.gz $TANGIER/tango-logstash-$TANGO_LOGSTASH_VERSION.tar.gz $TANGIER/tango-metricbeat-$TANGO_METRICBEAT_VERSION.tar.gz
    gunzip $TANGIER/reporting-ansible-$REPORTING_PLATFORM_VERSION.tar.gz $TANGIER/tango-kibana-$TANGO_KIBANA_VERSION.tar.gz $TANGIER/tango-logstash-$TANGO_LOGSTASH_VERSION.tar.gz
    echo "doing cat"
    cat $TANGIER/tango-elasticsearch-$TANGO_ELASTIC_VERSION.tar $TANGIER/reporting-ansible-$REPORTING_PLATFORM_VERSION.tar $TANGIER/tango-kibana-$TANGO_KIBANA_VERSION.tar $TANGIER/tango-logstash-$TANGO_LOGSTASH_VERSION.tar $TANGIER/tango-metricbeat-$TANGO_METRICBEAT_VERSION.tar >> $REPORTING_PLATFORM_SERVICE/reporting-platform-service.tar;
    gzip $REPORTING_PLATFORM_SERVICE/reporting-platform-service.tar;

    # Handle reporting-platform-shipper

    echo "Handle reporting-platform-shipper";
    #gunzip $TANGIER/tango-filebeat-$TANGO_FILEBEAT_VERSION.tar.gz $TANGIER/tango-metricbeat-$TANGO_METRICBEAT_VERSION.tar.gz
    gunzip $TANGIER/tango-filebeat-$TANGO_FILEBEAT_VERSION.tar.gz
    cat $TANGIER/tango-filebeat-$TANGO_FILEBEAT_VERSION.tar $TANGIER/tango-metricbeat-$TANGO_METRICBEAT_VERSION.tar >> $REPORTING_PLATFORM_SHIPPER/reporting-platform-shipper.tar;
    gzip $REPORTING_PLATFORM_SHIPPER/reporting-platform-shipper.tar;
}

# now enjoy the options in order and nicely split until we see --
while true; do
    case "$1" in
        -d|--download)
            if [ "$VIA_ATLAS" == "yes" ] || [ "$VIA_ATLAS" == "Yes" ] || [ "$VIA_ATLAS" == "true" ] || [ "$VIA_ATLAS" == "True" ] || [ "$VIA_ATLAS" == "YES" ];then
                    download_from_tangier_via_atlas
            else
                    download_from_tangier
            fi
            shift
            ;;
        --)
            shift
            break
            ;;
        *)
            echo "Programming error"
            exit 3
            ;;
    esac
done
deployment_view

# do this do revert changes to files so the script can be re-run again without error
cd $TANGIER
gzip tango-elasticsearch-$TANGO_ELASTIC_VERSION.tar tango-filebeat-$TANGO_FILEBEAT_VERSION.tar tango-kibana-$TANGO_KIBANA_VERSION.tar tango-logstash-$TANGO_LOGSTASH_VERSION.tar tango-metricbeat-$TANGO_METRICBEAT_VERSION.tar
#    cp $TANGIER/reporting-platform-dependencies.tar.gz $REPORTING_PLATFORM_DEPENDENCIES;