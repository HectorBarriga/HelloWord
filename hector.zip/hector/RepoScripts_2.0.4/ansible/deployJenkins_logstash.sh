VERSION=4.0.0
TARGET_VM=rte3ViaAtlas
TENANT=brav1
NEW_ES_PASSWORD=t3il3achum
INSTALL_JAVA=no
INSTALL_LOGSTASH=yes
INSTALL_METRICBEAT=yes
INSTALL_FILEBEAT=yes
PLAYBOOKS=/etc/ansible/playbooks
JDK=jdk-13.3


hasTargetVMViaAtlas=$(echo "$TARGET_VM" | grep ViaAtlas | egrep -v grep | wc -l)
checkHosts=$(cat /etc/hosts | cut -d'#' -f1 | grep "$TARGET_VM" | egrep -v grep | wc -l)

if [ "$hasTargetVMViaAtlas" -eq 0 ] && [ "$checkHosts" -eq 0 ];then
        echo -e "\n`tput setaf 1`----------------------------------------------------------------------------------------------------\nI didnt find `tput setaf 3`$TARGET_VM`tput setaf 1` in /etc/hosts on ansible-mster ser. Please add it now ...\n----------------------------------------------------------------------------------------------------\n`tput sgr0`"
        echo -n "Press Enter to continue > "
        read continueWithThatHosts
fi



echo "`tput setaf 3` << EOF
# Install docker / docker compose on jump server
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh

/usr/sbin/usermod -aG docker tango

echo 'usermod call'

mkdir -p /etc/docker
echo '{ \"insecure-registries\" : [\"zion:5000\"] }' > /etc/docker/daemon.json
curl -L \"https://github.com/docker/compose/releases/download/1.24.0/docker-compose-$(uname -s)-$(uname -m)\" -o /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose
systemctl restart docker
EOF
docker --version
docker-compose --version

newgrp docker`tput sgr0`"

while getopts d:h option;
do
        case $option in
                d) downloadArtifacts=$OPTARG;;
        esac
done

if [ "$downloadArtifacts" == "yes" ] || [ "$downloadArtifacts" == "true" ] || [ -z "$downloadArtifacts" ];then
        echo -n "`tput setaf 1`
----------------------------------------------------------------------------------------------------------------------------------------------------
Are you sure you want to run deployJankins without flag `tput setaf 2`-d no`tput setaf 1` ? It will download all airticrafts
----------------------------------------------------------------------------------------------------------------------------------------------------
`tput sgr0`[Send Ctr+C now] or [Press Enter to continue] >"
        read continuenow


# Download /tango/install  packages
        chmod u+x  /tango/data/user_data/Telefonica/ELK_installation/trunk/scripts/prepare_deployment_view.sh

# Prepare deployment view - downloads artifacts from tanger
        if [ ! -d /tango/install ];then
                mkdir -p /tango/install
        fi

        cp /tango/data/user_data/Telefonica/ELK_installation/trunk/scripts/prepare_deployment_view.sh /tango/install/
        cd /tango/install/
        ./prepare_deployment_view.sh -dd

        cp /tango/data/user_data/Telefonica/ELK_installation/security/policydemo_com.cert /etc/ansible/playbooks/

# Transfer artifacts to target machine

        tar -cvf artifacts_packages.tar packages -C /tango/install
        tar -cvf artifacts_tangier.tar tangier -C /tango/install
        scp /tango/install/artifacts*.tar $TARGET_VM:/tango/install
        rm /tango/install/artifacts*.tar
        ssh $TARGET_VM "tar -xvmf /tango/install/artifacts_packages.tar -C /tango/install/"
        ssh $TARGET_VM "tar -xvmf /tango/install/artifacts_tangier.tar -C /tango/install/"
        ssh $TARGET_VM "rm /tango/install/artifacts*.tar"
fi

# Prepare ansible environment
## Prepare hosts file
cd $PLAYBOOKS
echo -e "[reporting-platform-data]\n$TARGET_VM" > $PLAYBOOKS/host-data
echo -e "[reporting-platform-service]\n$TARGET_VM" > $PLAYBOOKS/host-service
echo -e "[reporting-platform-shipper]\n$TARGET_VM" > $PLAYBOOKS/host-shipper
## Add deprecation_warnings = False in ansible.cfg
getDeprecationWarningParamter=$(cat /etc/ansible/playbooks/ansible.cfg | grep deprecation_warnings | wc -l)
if [ "$getDeprecationWarningParamter" -eq 0 ];then
        echo "deprecation_warnings = False" >> /etc/ansible/playbooks/ansible.cfg
fi

## Update Ansible configuration ansible.cfg (as root user)
#echo -e "[defaults]\nroles_path = ${PWD}/../roles:${PWD}/../../co_roles:${PWD}/../../automation_roles" > /etc/ansible/ansible.cfg.ELK

# Run ansible scripts

cd $PLAYBOOKS

## Install Java
if [ "$INSTALL_JAVA" == "yes" ] || [ "$INSTALL_JAVA" == "Yes" ] || [ "$INSTALL_JAVA" == "True" ] || [ "$INSTALL_JAVA" == "true" ];then
        echo -e "`tput setaf 2`\n========================================================================== Install Java ==========================================================================\ncd $PLAYBOOKS\nansible-playbook reporting-platform-data_01_base.yml --extra-vars=\"delegate_to_host=$TARGET_VM hostname=$TARGET_VM\" -i host-data\n===================================================================================================================================================================`tput sgr0`\n"
        if [ ! -d "/etc/ansible/roles/java" ];then
                echo -e -n "`tput setaf 3`ATENTION: \"java\" role is not present. reporting-base role needs to import java role to install jdk-13.3. Just copy java role directory from iAX-Platform roles. Please enter java role directory from iAX-Platform roles [Default=/etc/ansible/roles_iAX_Platform/java/] > "
                read javaroleDir
                if [ -z $javaroleDir ];then
                        javaroleDir="/etc/ansible/roles_iAX_Platform/java/"
                fi
                cp -rfp $javaroleDir /etc/ansible/roles
        fi
        ansible-playbook reporting-platform-data_01_base.yml --extra-vars="delegate_to_host=$TARGET_VM hostname=$TARGET_VM" -i host-data
fi


echo "`tput setaf 3`Open another putty and Update all files that need to be edited before ansible continues deploying correctly on the target machine $TARGET_VM such as group_vars, defaults, airtcrafts, etc

----------------------------------------------------------------------------------------------------
Although deployJenkins.sh only downloaded /tango/install packages and artcrafts. It will not download playbooks, roles, or even this script from SVN. However, modify group_vars and roles/*/default/main.yml
-----
vi /etc/ansible/roles/elastic/tasks/main.yml
Run this:
:%s/inventory_hostname/ansible_hostname/g
-----
Change from { hostname } (which is the target VM's hostname. Not anyother alias (like db5labViaAtlas which is necesary if ANSIBLE-MASTER node is not at HQ. It cannot be \"iel-co-elk-vm1\" because when ANSIBLE is in HQ, well, a different alias would be needed. AT HQ the alias would be db5lab which would be different and .ssh/config would not clash with similar aliases)

perl -pi.orig -e 's/{ hostname }/{ ansible_hostname }/g' /etc/ansible/roles/xpack/tasks/* /etc/ansible/roles/elastic/tasks/create_directories.yml
rm /etc/ansible/roles/xpack/tasks/*.orig /etc/ansible/roles/elastic/tasks/create_directories.yml.orig
----------------------------------------------------------------------------------------------------`tput sgr0`
"
echo -n "Press Enter to continue > "
read continue

## Install logstash
# logstash needs to be up prior to filebeat
# PC 25-09-2019 install_logstash_tenant=false as otherwise logstash will try to connect to database, and if not configured
# correctly will stop logstash from starting up.  Set install_logstash_tenant=true to deploy database logstash config
if [ "$INSTALL_LOGSTASH" == "yes" ] || [ "$INSTALL_LOGSTASH" == "Yes" ] || [ "$INSTALL_LOGSTASH" == "True" ] || [ "$INSTALL_LOGSTASH" == "true" ];then
        echo -e "`tput setaf 2`\n======================================================================= Install logstash  =======================================================================\ncd $PLAYBOOKS\nansible-playbook reporting-platform-service_02_logstash.yml --extra-vars=\"delegate_to_host=$TARGET_VM es_original_password=$NEW_ES_PASSWORD hostname=$TARGET_VM tenant=$TENANT install_logstash_tenant=false\" -i host-service\n=============================================================================================================================================================`tput sgr0`\n"
        ansible-playbook reporting-platform-service_02_logstash.yml --extra-vars="delegate_to_host=$TARGET_VM es_original_password=$NEW_ES_PASSWORD hostname=$TARGET_VM tenant=$TENANT install_logstash_tenant=false" -i host-service
fi


## Install metricbeat
if [ "$INSTALL_METRICBEAT" == "yes" ] || [ "$INSTALL_METRICBEAT" == "Yes" ] || [ "$INSTALL_METRICBEAT" == "True" ] || [ "$INSTALL_METRICBEAT" == "true" ];then
        echo -e "`tput setaf 2`\n======================================================================= Install metricbeat  =======================================================================\ncd $PLAYBOOKS\nansible-playbook reporting-platform-shipper_01_metricbeat.yml --extra-vars=\"delegate_to_host=$TARGET_VM hostname=$TARGET_VM\ install_jdk=false push_and_explode_packages=false" -i host-shipper\n=============================================================================================================================================================`tput sgr0`\n"
        ansible-playbook reporting-platform-shipper_01_metricbeat.yml --extra-vars="delegate_to_host=$TARGET_VM hostname=$TARGET_VM install_jdk=false push_and_explode_packages=false" -i host-shipper
fi


## Install filebeat
if [ "$INSTALL_FILEBEAT" == "yes" ] || [ "$INSTALL_FILEBEAT" == "Yes" ] || [ "$INSTALL_FILEBEAT" == "True" ] || [ "$INSTALL_FILEBEAT" == "true" ];then
        echo -e "`tput setaf 2`\n======================================================================= Install filebeat  =======================================================================\ncd $PLAYBOOKS\nansible-playbook reporting-platform-shipper_02_filebeat.yml --extra-vars=\"delegate_to_host=$TARGET_VM hostname=$TARGET_VM filebeat_logstash_wait_timeout=10 install_jdk=false push_and_explode_packages=false\" -i host-shipper\n=============================================================================================================================================================`tput sgr0`\n"
        ansible-playbook reporting-platform-shipper_02_filebeat.yml --extra-vars="delegate_to_host=$TARGET_VM hostname=$TARGET_VM filebeat_logstash_wait_timeout=10 install_jdk=false push_and_explode_packages=false" -i host-shipper
fi