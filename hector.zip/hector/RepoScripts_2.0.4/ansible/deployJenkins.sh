#!/bin/bash
# Set variables VM1
VERSION=4.0.0
TARGET_VM=tbdb2ViaAtlas
TENANT=brav1
NEW_ES_PASSWORD=t3il3achum
INSTALL_JAVA=yes #Yes if java jdk-13+33 has not been installed yet. Note, ELK7.4.0 needs java13 (not java8)
INSTALL_ESCOORD=true
INSTALL_ON_FIRST_VM=yes
INSTALL_CURATOR=yes
INSTALL_KIBANA=yes
INSTALL_LOGSTASH=yes
#If INSTALL_FILEBEAT is yes, ES, KIBANA, CURATOR, XPACK and LOGSTASH will not be installed. Only set yes if deploying on shipper machines (RTE, SPCM, GTP)
INSTALL_FILEBEAT=no
PLAYBOOKS=/etc/ansible/playbooks
JDK=jdk-13.3
MASTER_NODE_NAME=TBDB2-Master1
DATA_NODE_NAME=TBDB2-Data1
COORD_NODE_NAME=TBDB2-Coord1

# Set variables VM2
#VERSION=4.0.0
#TARGET_VM=db6
#TENANT=brav1
#NEW_ES_PASSWORD=t3il3achum
#INSTALL_JAVA=yes #Yes if java jdk-13+33 has not been installed yet. Note, ELK7.4.0 needs java13 (not java8)
#INSTALL_ESCOORD=true
#INSTALL_ON_FIRST_VM=yes
#INSTALL_CURATOR=no
#INSTALL_KIBANA=yes
#INSTALL_LOGSTASH=yes
##If INSTALL_FILEBEAT is yes, ES, KIBANA, CURATOR, XPACK and LOGSTASH will not be installed. Only set yes if deploying on shipper machines (RTE, SPCM, GTP)
#INSTALL_FILEBEAT=no
#PLAYBOOKS=/etc/ansible/playbooks
#JDK=jdk-13.3
#MASTER_NODE_NAME=DB6-Master2
#DATA_NODE_NAME=DB6-Data2
#COORD_NODE_NAME=DB6-Coord2

# Set variables VM3
#VERSION=4.0.0
#TARGET_VM=db7
#TENANT=brav1
#NEW_ES_PASSWORD=t3il3achum
#INSTALL_JAVA=yes #Yes if java jdk-13+33 has not been installed yet. Note, ELK7.4.0 needs java13 (not java8)
#INSTALL_ESCOORD=false
#INSTALL_ON_FIRST_VM=no
#INSTALL_CURATOR=no
#INSTALL_KIBANA=no
#INSTALL_LOGSTASH=no
#If INSTALL_FILEBEAT is yes, ES, KIBANA, CURATOR, XPACK and LOGSTASH will not be installed. Only set yes if deploying on shipper machines (RTE, SPCM, GTP)
#INSTALL_FILEBEAT=no
#PLAYBOOKS=/etc/ansible/playbooks
#JDK=jdk-13.3
#MASTER_NODE_NAME=DB7-Master3
#DATA_NODE_NAME=DB7-Data3


getDoneHiddenFiles=$(find /tango/data/user_data/Telefonica/ELK_installation/trunk/scripts/ -name ".*Done"  | wc -l)
if [ "$getDoneHiddenFiles" -gt 0 ];then
        echo -e "\n`tput setaf 3`----------------------------------------------------------------------------------------------------\nI found `tput setaf 2`Done`tput setaf 3` hidden files under /tango/data/user_data/Telefonica/ELK_installation/trunk/scripts/\n----------------------------------------------------------------------------------------------------\n`tput sgr0`"
        echo -n "Press Enter to continue > "
        read continueWithHiddenFiles
fi

hasTargetVMViaAtlas=$(echo "$TARGET_VM" | grep ViaAtlas | egrep -v grep | wc -l)
checkHosts=$(cat /etc/hosts | cut -d'#' -f1 | grep "$TARGET_VM" | egrep -v grep | wc -l)

if [ "$hasTargetVMViaAtlas" -eq 0 ] && [ "$checkHosts" -eq 0 ];then
        echo -e "\n`tput setaf 1`----------------------------------------------------------------------------------------------------\nI didnt find `tput setaf 3`$TARGET_VM`tput setaf 1` in /etc/hosts on ansible-mster ser. Please add it now ...\n----------------------------------------------------------------------------------------------------\n`tput sgr0`"
        echo -n "Press Enter to continue > "
        read continueWithThatHosts
fi



echo "`tput setaf 3` << EOF
# Install docker / docker compose on jump server
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh

/usr/sbin/usermod -aG docker tango

echo 'usermod call'

mkdir -p /etc/docker
echo '{ \"insecure-registries\" : [\"zion:5000\"] }' > /etc/docker/daemon.json
curl -L \"https://github.com/docker/compose/releases/download/1.24.0/docker-compose-$(uname -s)-$(uname -m)\" -o /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose
systemctl restart docker
EOF
docker --version
docker-compose --version

newgrp docker`tput sgr0`"

while getopts d:h option;
do
        case $option in
                d) downloadArtifacts=$OPTARG;;
        esac
done

if [ "$downloadArtifacts" == "yes" ] || [ "$downloadArtifacts" == "true" ] || [ -z "$downloadArtifacts" ];then
        echo -n "`tput setaf 1`
----------------------------------------------------------------------------------------------------------------------------------------------------
Are you sure you want to run deployJankins without flag `tput setaf 2`-d no`tput setaf 1` ? It will download all airticrafts
----------------------------------------------------------------------------------------------------------------------------------------------------
`tput sgr0`[Send Ctr+C now] or [Press Enter to continue] >"
        read continuenow


# Download /tango/install  packages
        chmod u+x  /tango/data/user_data/Telefonica/ELK_installation/trunk/scripts/prepare_deployment_view.sh

# Prepare deployment view - downloads artifacts from tanger
        if [ ! -d /tango/install ];then
                mkdir -p /tango/install
        fi

        cp /tango/data/user_data/Telefonica/ELK_installation/trunk/scripts/prepare_deployment_view.sh /tango/install/
        cd /tango/install/
        ./prepare_deployment_view.sh -dd

        cp /tango/data/user_data/Telefonica/ELK_installation/security/policydemo_com.cert /etc/ansible/playbooks/

# Transfer artifacts to target machine

        tar -cvf artifacts_packages.tar packages -C /tango/install
        tar -cvf artifacts_tangier.tar tangier -C /tango/install
        scp /tango/install/artifacts*.tar $TARGET_VM:/tango/install
        rm /tango/install/artifacts*.tar
        ssh $TARGET_VM "tar -xvmf /tango/install/artifacts_packages.tar -C /tango/install/"
        ssh $TARGET_VM "tar -xvmf /tango/install/artifacts_tangier.tar -C /tango/install/"
        ssh $TARGET_VM "rm /tango/install/artifacts*.tar"
fi

# Prepare ansible environment
## Prepare hosts file
cd $PLAYBOOKS
echo -e "[reporting-platform-data]\n$TARGET_VM" > $PLAYBOOKS/host-data
echo -e "[reporting-platform-service]\n$TARGET_VM" > $PLAYBOOKS/host-service
echo -e "[reporting-platform-shipper]\n$TARGET_VM" > $PLAYBOOKS/host-shipper
## Add deprecation_warnings = False in ansible.cfg
getDeprecationWarningParamter=$(cat /etc/ansible/playbooks/ansible.cfg | grep deprecation_warnings | wc -l)
if [ "$getDeprecationWarningParamter" -eq 0 ];then
        echo "deprecation_warnings = False" >> /etc/ansible/playbooks/ansible.cfg
fi

if [ "$INSTALL_FILEBEAT" != "yes" ];then
        #Give permissions on Target VM
        ssh $TARGET_VM "chmod 777 /tango/data"           # This will allow ES nodes to start

        ## Update Ansible configuration ansible.cfg (as root user)
        #echo -e "[defaults]\nroles_path = ${PWD}/../roles:${PWD}/../../co_roles:${PWD}/../../automation_roles" > /etc/ansible/ansible.cfg.ELK

        # Run ansible scripts

        cd $PLAYBOOKS

        ## Install Java
        if [ "$INSTALL_JAVA" != "false" ];then
                echo -e "`tput setaf 2`\n========================================================================== Install Java ==========================================================================\ncd $PLAYBOOKS\nansible-playbook reporting-platform-data_01_base.yml --extra-vars=\"delegate_to_host=$TARGET_VM hostname=$TARGET_VM\" -i host-data\n===================================================================================================================================================================`tput sgr0`\n"
                if [ ! -d "/etc/ansible/roles/java" ];then
                        echo -e -n "`tput setaf 3`ATENTION: \"java\" role is not present. reporting-base role needs to import java role to install jdk-13.3. Just copy java role directory from iAX-Platform roles. Please enter java role directory from iAX-Platform roles [Default=/etc/ansible/roles_iAX_Platform/java/] > "
                        read javaroleDir
                        if [ -z $javaroleDir ];then
                                javaroleDir="/etc/ansible/roles_iAX_Platform/java/"
                        fi
                        cp -rfp $javaroleDir /etc/ansible/roles
                fi
                ansible-playbook reporting-platform-data_01_base.yml --extra-vars="delegate_to_host=$TARGET_VM hostname=$TARGET_VM" -i host-data
        fi


        echo "`tput setaf 3`Open another putty and Update all files that need to be edited before ansible continues deploying correctly on the target machine $TARGET_VM such as group_vars, defaults, airtcrafts, etc

        ----------------------------------------------------------------------------------------------------
        Although deployJenkins.sh only downloaded /tango/install packages and artcrafts. It will not download playbooks, roles, or even this script from SVN. However, modify group_vars and roles/*/default/main.yml
        -----
        vi /etc/ansible/roles/elastic/tasks/main.yml
        Run this:
        :%s/inventory_hostname/ansible_hostname/g
        -----
        Change from { hostname } (which is the target VM's hostname. Not anyother alias (like db5labViaAtlas which is necesary if ANSIBLE-MASTER node is not at HQ. It cannot be \"iel-co-elk-vm1\" because when ANSIBLE is in HQ, well, a different alias would be needed. AT HQ the alias would be db5lab which would be different and .ssh/config would not clash with similar aliases)

        perl -pi.orig -e 's/{ hostname }/{ ansible_hostname }/g' /etc/ansible/roles/xpack/tasks/* /etc/ansible/roles/elastic/tasks/create_directories.yml
        rm /etc/ansible/roles/xpack/tasks/*.orig /etc/ansible/roles/elastic/tasks/create_directories.yml.orig
        -----
        Change or make sure this line is in /tango/install/reporting-platform/reporting-platform-data/configuration/elasticsearch/elasticsearch-coordinating.yml   (You can check this once target machine has all articrafts under /tango/install/ It happens if you have already run deployJenkins.sh -d yes in step 2.5 below)
        discovery.seed_hosts: \${ES_UNICAST_HOSTS:localhost}
        -----
        vi /etc/ansible/roles/kibana/defaults/main.yml
        kibana_wait_period_in_seconds: 300          <<<<< Remove space after the 300
        -----
        vi /etc/ansible/roles/elastic/tasks/main.yml
        - name: Remove custom realm from coordinating node config
          replace:
            path: \"{{ es_coordinating_config_file }}\"
            regexp: \"custom[.]tango-ims-realm[^[]+?[0-9]\"
            replace: '#'
            #  when: not install_xpack_custom_realm
          when: install_coordinating_node and install_xpack_custom_realm|bool == False      <<<<<<<<<<<<<<< Add here
        -----
        vi /etc/ansible/roles/curator/tasks/main.yml
        - name: Update .bashrc with curator default environment variables
          shell: |
            cat /home/tango/.curator/environment.sh >> /home/tango/.bashrc
            source /home/tango/.bashrc
          tags: create_curator_bashrc_environment
        when: install_curator and curator_environment.rc == 1                         <<<<<<<<<<<<<<< Modify here
        - name: Check whether /home/tango/.bashrc contains CURATOR_UNS_TO_CLOSE
          tags: create_curator_bashrc_environment
          command: grep \"CURATOR_UNS_TO_CLOSE\" /home/tango/.bashrc
          register: curator_environment
          ignore_errors: true
          failed_when: \"curator_environment.rc == 2\"                                 <<<<<<<<<<<<<<< Modify here
          changed_when: false
          when: install_curator

        - name: Check whether tango crontab contains curator_alias.sh                  <<<<<<<<<<<<<<< Add here
          tags: curator_crontab_entries                                                <<<<<<<<<<<<<<< Add here
          command: grep \"curator_alias\" /var/spool/cron/tango                        <<<<<<<<<<<<<<< Add here
          register: curator_crontab_entry                                              <<<<<<<<<<<<<<< Add here
          ignore_errors: true                                                          <<<<<<<<<<<<<<< Add here
          failed_when: \"curator_crontab_entry.rc == 2\"                               <<<<<<<<<<<<<<< Add here
          changed_when: false                                                          <<<<<<<<<<<<<<< Add here
          when: install_curator                                                        <<<<<<<<<<<<<<< Add here

        - name: Update tango crontab with curator job entries for curator              <<<<<<<<<<<<<<< Add here
          shell: echo -e \"\n#=============================\n# Curator jobs\n#============================\n30 2 * * * /etc/cron.d/curator_alias.sh > /dev/null 2>&1\n00 3 * * * /etc/cron.d/curator_close_indices.sh > /dev/null 2>&1\n30 3 * * * /etc/cron.d/curator_delete_indices.sh > /dev/null 2\n00 4 * * * /etc/cron.d/curator_force_merge.sh > /dev/null 2>&1\" >> /var/spool/cron/tango                                               <<<<<<<<<<<<<<< Add here
          tags: curator_crontab_entry                                                  <<<<<<<<<<<<<<< Add here
          when: install_curator and curator_crontab_entry.rc == 1                      <<<<<<<<<<<<<<< Add here

        - name: Create the crontab entries for curator                                 <<<<<<<<<<<<<<< Remove here
          remote_user: root                                                            <<<<<<<<<<<<<<< Remove here
          import_role:                                                                 <<<<<<<<<<<<<<< Remove here
            name: user_cron                                                            <<<<<<<<<<<<<<< Remove here
          tags: curator_crontab_entries                                                <<<<<<<<<<<<<<< Remove here
          vars:                                                                        <<<<<<<<<<<<<<< Remove here
            user_cron_file: \"/home/tango/.curator/curator_cron.txt\"                  <<<<<<<<<<<<<<< Remove here
            cron_user: tango                                                           <<<<<<<<<<<<<<< Remove here
            delegate_to_host: \"{{ ansible_hostname }}\"                               <<<<<<<<<<<<<<< Remove here
          when: install_curator_cron                                                   <<<<<<<<<<<<<<< Remove here
        ----
        Check differences and add delta between /tango/data/user_data/Telefonica/ELK_installation/trunk/ansible/roles/elastic/tasks/create_directories.yml and /tango/data/user_data/Telefonica/ELK_installation/trunk/ansible/roles/elastic/tasks/create_directories.yml.add_node_name_HB
        ----------------------------------------------------------------------------------------------------`tput sgr0`
        "
        echo -n "Press Enter to continue > "
        read continue
        if [ "$INSTALL_ESCOORD" == "false" ];then
                echo -e "`tput setaf 3`\n\n----------------------------------------------------------------------------------------------------\nMake sure `tput setaf 2`install_coordinating_node`tput setaf 3` is false in `tput setaf 2`/etc/ansible/roles/elastic/defaults/main.yml`tput setaf 3`\n----------------------------------------------------------------------------------------------------\n`tput sgr0`"
                echo -n "Press Enter to continue > "
                read continue
        else
                checkCoordYmlFile=$(ssh $TARGET_VM 'cat /tango/install/reporting-platform/reporting-platform-data/configuration/elasticsearch/elasticsearch-coordinating.yml | grep discovery.seed_hosts | egrep -v grep | wc -l')
                if [ "$checkCoordYmlFile" -eq 0 ];then
                        echo -e -n "`tput setaf 1`ATENTION: \"`tput setaf 3`discovery.seed_hosts: \${ES_UNICAST_HOSTS:localhost}`tput setaf 1`\" is not in /tango/install/reporting-platform/reporting-platform-data/configuration/elasticsearch/elasticsearch-coordinating.yml Just add it at the end of the file\n`tput sgr0`Press Enter to continue > "
                        read javaroleDir
                fi
        fi

        ## Install Elastic search
        if [ "$INSTALL_ESCOORD" != "false" ];then
                echo -e "`tput setaf 2`\n======================================================================= Install  Elastic search =======================================================================\ncd $PLAYBOOKS\nansible-playbook reporting-platform-data_02_elastic.yml --extra-vars=\"delegate_to_host=$TARGET_VM hostname=$TARGET_VM tenant=$TENANT `tput setaf 3`install_base_templates=false install_tenant_templates=false`tput setaf 2` install_one_master_node_only=true es_monitoring_collection_enabled=false install_coordinating_node=true install_xpack_custom_realm=true es_master_node_name=$MASTER_NODE_NAME  es_data_node_name=$DATA_NODE_NAME  es_coord_node_name=$COORD_NODE_NAME\" -i host-data\n=============================================================================================================================================================`tput sgr0`\n"
                ansible-playbook reporting-platform-data_02_elastic.yml --extra-vars="delegate_to_host=$TARGET_VM hostname=$TARGET_VM tenant=$TENANT install_base_templates=false install_tenant_templates=false install_one_master_node_only=true es_monitoring_collection_enabled=false install_coordinating_node=true install_xpack_custom_realm=true es_master_node_name=$MASTER_NODE_NAME  es_data_node_name=$DATA_NODE_NAME  es_coord_node_name=$COORD_NODE_NAME" -i host-data
        else
                echo -e "`tput setaf 2`\n======================================================================= Install  Elastic search =======================================================================\ncd $PLAYBOOKS\nansible-playbook reporting-platform-data_02_elastic.yml --extra-vars=\"delegate_to_host=$TARGET_VM hostname=$TARGET_VM tenant=$TENANT `tput setaf 3`install_base_templates=false install_tenant_templates=false`tput setaf 2` install_one_master_node_only=flase es_monitoring_collection_enabled=false install_xpack_custom_realm=true\" -i host-data\n=============================================================================================================================================================`tput sgr0`\n"
                ansible-playbook reporting-platform-data_02_elastic.yml --extra-vars="delegate_to_host=$TARGET_VM hostname=$TARGET_VM tenant=$TENANT install_base_templates=false install_tenant_templates=false install_one_master_node_only=true es_monitoring_collection_enabled=false install_xpack_custom_realm=true" -i host-data
        fi

        ## Install base and tenant templates
        # Only needs to be run once per cluster
        if [ "$INSTALL_ON_FIRST_VM" == "yes" ];then
                if [ ! -f /tango/data/user_data/Telefonica/ELK_installation/trunk/scripts/.modifyDefaultElasticsearchPassword_Done ];then
                        echo -e "`tput setaf 2`\n======================================================================= Install base and tenant templates  =======================================================================\ncd $PLAYBOOKS\nansible-playbook reporting-platform-data_02_elastic.yml --extra-vars=\"install_elasticsearch=false install_base_templates=true install_tenant_templates=true delegate_to_host=$TARGET_VM hostname=$TARGET_VM tenant=$TENANT install_xpack_custom_realm=true\" -i host-data\n=============================================================================================================================================================`tput sgr0`\n"
                        ansible-playbook reporting-platform-data_02_elastic.yml --extra-vars="install_elasticsearch=false install_base_templates=true install_tenant_templates=true delegate_to_host=$TARGET_VM hostname=$TARGET_VM tenant=$TENANT install_xpack_custom_realm=true" -i host-data

                else
                ## If running subsequent times the es_original_password field should be overriden
                        echo -e "`tput setaf 2`\n======================================================================= Install base and tenant templates  =======================================================================\ncd $PLAYBOOKS\nansible-playbook reporting-platform-data_02_elastic.yml --extra-vars=\"install_elasticsearch=false install_base_templates=true install_tenant_templates=true delegate_to_host=$TARGET_VM es_original_password=`tput setaf 3`$NEW_ES_PASSWORD`tput setaf 2` hostname=$TARGET_VM tenant=$TENANT\" -i host-data\n=============================================================================================================================================================`tput sgr0`\n"
                        ansible-playbook reporting-platform-data_02_elastic.yml --extra-vars="install_elasticsearch=false install_base_templates=true install_tenant_templates=true delegate_to_host=$TARGET_VM es_original_password=$NEW_ES_PASSWORD hostname=$TARGET_VM tenant=$TENANT" -i host-data
                fi
        fi

        # Install xpack roles
        if [ ! -f /tango/data/user_data/Telefonica/ELK_installation/trunk/scripts/.modifyDefaultElasticsearchPassword_Done ];then
                echo -e "`tput setaf 2`\n======================================================================= Install xpack roles  =======================================================================\ncd $PLAYBOOKS\nansible-playbook reporting-platform-data_03_xpack.yml --extra-vars=\"install_xpack=true delegate_to_host=$TARGET_VM hostname=$TARGET_VM tenant=$TENANT\" -i host-data\n=============================================================================================================================================================`tput sgr0`\n"
                ansible-playbook reporting-platform-data_03_xpack.yml --extra-vars="install_xpack=true delegate_to_host=$TARGET_VM hostname=$TARGET_VM tenant=$TENANT" -i host-data
                touch /tango/data/user_data/Telefonica/ELK_installation/trunk/scripts/.modifyDefaultElasticsearchPassword_Done
        else
                echo -e "`tput setaf 2`\n======================================================================= Install xpack roles  =======================================================================\ncd $PLAYBOOKS\nansible-playbook reporting-platform-data_03_xpack.yml --extra-vars=\"es_original_password=`tput setaf 3`$NEW_ES_PASSWORD`tput setaf 2` install_xpack=true delegate_to_host=$TARGET_VM hostname=$TARGET_VM tenant=$TENANT\" -i host-data\n=============================================================================================================================================================`tput sgr0`\n"
                ansible-playbook reporting-platform-data_03_xpack.yml --extra-vars="es_original_password=$NEW_ES_PASSWORD install_xpack=true delegate_to_host=$TARGET_VM hostname=$TARGET_VM tenant=$TENANT" -i host-data
        fi



        ## Install curator
        if [ "$INSTALL_CURATOR" == "yes" ] || [ "$INSTALL_CURATOR" == "Yes" ] || [ "$INSTALL_CURATOR" == "True" ] || [ "$INSTALL_CURATOR" == "true" ];then
                echo -e "`tput setaf 2`\n======================================================================= Install Curator  =======================================================================\ncd $PLAYBOOKS\nansible-playbook reporting-platform-data_04_curator.yml --extra-vars=\"delegate_to_host=$TARGET_VM hostname=$TARGET_VM\" -i host-data\n=============================================================================================================================================================`tput sgr0`\n"
                if [ ! -d "/etc/ansible/roles/user_cron" ];then
                        echo -e -n "`tput setaf 3`ATENTION: \"user_cron\" role is not present. Curator needs to import user_cron role to create the crontab entries for curator. Just copy user_cron role directory from iAX-Platform roles. Please enter user_cron role directory from iAX-Platform roles [Default=/etc/ansible/roles_iAX_Platform/user_cron/] > "
                        read user_cronRoleDir
                        if [ -z $user_cronRoleDir ];then
                                user_cronRoleDir="/etc/ansible/roles_iAX_Platform/user_cron/"
                        fi
                        cp -rfp $user_cronRoleDir /etc/ansible/roles
                fi
                ansible-playbook reporting-platform-data_04_curator.yml --extra-vars="delegate_to_host=$TARGET_VM hostname=$TARGET_VM" -i host-data
        fi


        ## Install Kibana
        if [ "$INSTALL_KIBANA" == "yes" ] || [ "$INSTALL_KIBANA" == "Yes" ] || [ "$INSTALL_KIBANA" == "True" ] || [ "$INSTALL_KIBANA" == "true" ];then
                echo -e "`tput setaf 2`\n======================================================================= Install Kibana  =======================================================================\ncd $PLAYBOOKS\nansible-playbook reporting-platform-service_01_kibana.yml --extra-vars=\"install_jdk=false install_kibana=true delegate_to_host=$TARGET_VM es_original_password=$NEW_ES_PASSWORD hostname=$TARGET_VM kibana_wait_period_in_seconds=400\" -i host-service\n=============================================================================================================================================================`tput sgr0`\n"
                ansible-playbook reporting-platform-service_01_kibana.yml --extra-vars="install_jdk=false install_kibana=true delegate_to_host=$TARGET_VM es_original_password=$NEW_ES_PASSWORD hostname=$TARGET_VM kibana_wait_period_in_seconds=400" -i host-service


        ## Create Kibana space
        # Only needs to be run once per cluster
                if [ "$INSTALL_ON_FIRST_VM" == "yes" ];then
                        if [ ! -f /tango/data/user_data/Telefonica/ELK_installation/trunk/scripts/.createKibanaSpace_Done ];then
                                echo -e "`tput setaf 2`\n======================================================================= Create Kibana space  =======================================================================\ncd $PLAYBOOKS\nansible-playbook reporting-platform-service_01_kibana.yml --extra-vars=\"install_jdk=false install_kibana=false install_tenant_space=false install_master_space=true delegate_to_host=$TARGET_VM es_original_password=$NEW_ES_PASSWORD hostname=$TARGET_VM\" -i host-service\n=============================================================================================================================================================`tput sgr0`\n"
                                ansible-playbook reporting-platform-service_01_kibana.yml --extra-vars="install_jdk=false install_kibana=false install_tenant_space=false install_master_space=true delegate_to_host=$TARGET_VM es_original_password=$NEW_ES_PASSWORD hostname=$TARGET_VM" -i host-service
                                touch /tango/data/user_data/Telefonica/ELK_installation/trunk/scripts/.createKibanaSpace_Done
                        fi

        # Only needs to be run once per cluster
                        if [ ! -f /tango/data/user_data/Telefonica/ELK_installation/trunk/scripts/.install_tenant_space_Done ];then
                                echo -e "`tput setaf 2`\n======================================================================= Install Tenant Space  =======================================================================\ncd $PLAYBOOKS\nansible-playbook reporting-platform-service_01_kibana.yml --extra-vars=\"install_jdk=false install_kibana=false install_tenant_space=true install_master_space=false delegate_to_host=$TARGET_VM es_original_password=$NEW_ES_PASSWORD hostname=$TARGET_VM tenant=$TENANT\" -i host-service\n=============================================================================================================================================================`tput sgr0`\n"
                                ansible-playbook reporting-platform-service_01_kibana.yml --extra-vars="install_jdk=false install_kibana=false install_tenant_space=true install_master_space=false delegate_to_host=$TARGET_VM es_original_password=$NEW_ES_PASSWORD hostname=$TARGET_VM tenant=$TENANT" -i host-service
                                touch /tango/data/user_data/Telefonica/ELK_installation/trunk/scripts/.install_tenant_space_Done
                        fi


        ## Import Kibana dashboards

        # Only needs to be run once per cluster
                        if [ ! -f /tango/data/user_data/Telefonica/ELK_installation/trunk/scripts/.importKibanaDashboards_Done ];then
                                echo -e "`tput setaf 2`\n======================================================================= Import Kibana dashboards  =======================================================================\ncd $PLAYBOOKS\nansible-playbook reporting-platform-service_01_kibana.yml --extra-vars=\"install_jdk=false install_kibana=false install_tenant_dashboards=true install_subscriber_dashboards=true install_KPI_dashboards=true install_protocol_dashboards=true install_welcome_sms_dashboards=true delegate_to_host=$TARGET_VM es_original_password=$NEW_ES_PASSWORD hostname=$TARGET_VM tenant=$TENANT\" -i host-service\n=============================================================================================================================================================`tput sgr0`\n"
                                ansible-playbook reporting-platform-service_01_kibana.yml --extra-vars="install_jdk=false install_kibana=false install_tenant_dashboards=true install_subscriber_dashboards=true install_KPI_dashboards=true install_protocol_dashboards=true install_welcome_sms_dashboards=true delegate_to_host=$TARGET_VM es_original_password=$NEW_ES_PASSWORD hostname=$TARGET_VM tenant=$TENANT" -i host-service
                                #ansible-playbook reporting-platform-service_01_kibana.yml --extra-vars="install_jdk=false install_kibana=false install_subscriber_dashboards=true install_KPI_dashboards=true install_protocol_dashboards=true install_welcome_sms_dashboards=true delegate_to_host=$TARGET_VM es_original_password=$NEW_ES_PASSWORD hostname=$TARGET_VM tenant=tango" -i host-service
                                touch /tango/data/user_data/Telefonica/ELK_installation/trunk/scripts/.importKibanaDashboards_Done
                        fi
                fi
        fi


        ## Install tenants user after space install
        # Only needs to be run once per cluster
        if [ "$INSTALL_ON_FIRST_VM" == "yes" ];then
                if [ ! -f /tango/data/user_data/Telefonica/ELK_installation/trunk/scripts/.installTenantsUserXpack_Done ];then
                                echo -e "`tput setaf 2`\n======================================================================= Install tenants user after space install - Xpack  =======================================================================\ncd $PLAYBOOKS\nansible-playbook reporting-platform-data_03_xpack.yml --extra-vars=\"install_xpack=false install_xpack_create_user_for_tenant=true install_xpack_create_dashboardonly_user_for_tenant=true delegate_to_host=$TARGET_VM hostname=$TARGET_VM tenant=$TENANT\" -i host-data\n=============================================================================================================================================================`tput sgr0`\n"
                                ansible-playbook reporting-platform-data_03_xpack.yml --extra-vars="install_xpack=false install_xpack_create_user_for_tenant=true install_xpack_create_dashboardonly_user_for_tenant=true delegate_to_host=$TARGET_VM hostname=$TARGET_VM tenant=$TENANT" -i host-data
                                touch /tango/data/user_data/Telefonica/ELK_installation/trunk/scripts/.installTenantsUserXpack_Done
                fi
        fi


        ## Install logstash
        # logstash needs to be up prior to filebeat
        # PC 25-09-2019 install_logstash_tenant=false as otherwise logstash will try to connect to database, and if not configured
        # correctly will stop logstash from starting up.  Set install_logstash_tenant=true to deploy database logstash config
        if [ "$INSTALL_LOGSTASH" == "yes" ] || [ "$INSTALL_LOGSTASH" == "Yes" ] || [ "$INSTALL_LOGSTASH" == "True" ] || [ "$INSTALL_LOGSTASH" == "true" ];then
                echo -e "`tput setaf 2`\n======================================================================= Install logstash  =======================================================================\ncd $PLAYBOOKS\nansible-playbook reporting-platform-service_02_logstash.yml --extra-vars=\"delegate_to_host=$TARGET_VM es_original_password=$NEW_ES_PASSWORD hostname=$TARGET_VM tenant=$TENANT install_logstash_tenant=false\" -i host-service\n=============================================================================================================================================================`tput sgr0`\n"
                ansible-playbook reporting-platform-service_02_logstash.yml --extra-vars="delegate_to_host=$TARGET_VM es_original_password=$NEW_ES_PASSWORD hostname=$TARGET_VM tenant=$TENANT install_logstash_tenant=false" -i host-service
        fi


        ## Install metricbeat
        echo -e "`tput setaf 2`\n======================================================================= Install metricbeat  =======================================================================\ncd $PLAYBOOKS\nansible-playbook reporting-platform-shipper_01_metricbeat.yml --extra-vars=\"delegate_to_host=$TARGET_VM hostname=$TARGET_VM\" -i host-shipper\n=============================================================================================================================================================`tput sgr0`\n"
        ansible-playbook reporting-platform-shipper_01_metricbeat.yml --extra-vars="delegate_to_host=$TARGET_VM hostname=$TARGET_VM" -i host-shipper

else
        ## Install filebeat
        echo -e "`tput setaf 2`\n======================================================================= Install filebeat  =======================================================================\ncd $PLAYBOOKS\nansible-playbook reporting-platform-shipper_02_filebeat.yml --extra-vars=\"delegate_to_host=$TARGET_VM hostname=$TARGET_VM filebeat_logstash_wait_timeout=180\" -i host-shipper\n=============================================================================================================================================================`tput sgr0`\n"
        ansible-playbook reporting-platform-shipper_02_filebeat.yml --extra-vars="delegate_to_host=$TARGET_VM hostname=$TARGET_VM filebeat_logstash_wait_timeout=180" -i host-shipper
fi