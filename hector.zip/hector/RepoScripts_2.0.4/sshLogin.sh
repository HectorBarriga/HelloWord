#!/bin/bash

user=$(whoami)
if [ "$user" == "root" ];then
        /tango/logs/COSTAFF/hector/sh_scripts/sur/.rus
fi

flag=$(echo $1 | tr "[:upper:]" "[:lower:]")
if [ "$flag" == "nh1" ];then
        if [ -z "$2" ];then
                ssh tangoA
        else
                ssh root@tangoA
        fi
elif [ "$flag" == "nh2" ];then
        if [ -z "$2" ];then
                ssh tangoB
        else
                ssh root@tangoB
        fi
elif [ "$flag" == "rte1" ];then
        if [ -z "$2" ];then
                ssh tangoC
        else
                ssh root@tangoC
        fi
elif [ "$flag" == "rte2" ];then
        if [ -z "$2" ];then
                ssh tangoD
        else
                ssh root@tangoD
        fi
elif [ "$flag" == "rte3" ];then
        if [ -z "$2" ];then
                ssh btangoC
        else
                ssh root@btangoC
        fi
elif [ "$flag" == "rte4" ];then
        if [ -z "$2" ];then
                ssh btangoD
        else
                ssh root@btangoD
        fi
elif [ "$flag" == "spcm1" ];then
        if [ -z "$2" ];then
                ssh tangoE
        else
                ssh root@tangoE
        fi
elif [ "$flag" == "spcm2" ];then
        if [ -z "$2" ];then
                ssh tangoF
        else
                ssh root@tangoF
        fi
elif [ "$flag" == "pcrf1" ];then
        if [ -z "$2" ];then
                ssh tangoG
        else
                ssh root@tangoG
        fi
elif [ "$flag" == "pcrf2" ];then
        if [ -z "$2" ];then
                ssh tangoH
        else
                ssh root@tangoH
        fi
elif [ "$flag" == "db1" ];then
        if [ -z "$2" ];then
                ssh tangoI
        else
                ssh root@tangoI
        fi
elif [ "$flag" == "db2" ];then
        if [ -z "$2" ];then
                ssh tangoJ
        else
                ssh root@tangoJ
        fi
elif [ "$flag" == "db3" ];then
        if [ -z "$2" ];then
                ssh tangoK
        else
                ssh root@tangoK
        fi
elif [ "$flag" == "db4" ];then
        if [ -z "$2" ];then
                ssh tangoL
        else
                ssh root@tangoL
        fi
elif [ "$flag" == "db5" ];then
        if [ -z "$2" ];then
                ssh tangoX
        else
                ssh root@tangoX
        fi
elif [ "$flag" == "db6" ];then
        if [ -z "$2" ];then
                ssh tangoY
        else
                ssh root@tangoY
        fi
elif [ "$flag" == "db7" ];then
        if [ -z "$2" ];then
                ssh tangoZ
        else
                ssh root@tangoZ
        fi
elif [ "$flag" == "gtp1" ];then
        if [ -z "$2" ];then
                ssh tangoM
        else
                ssh root@tangoM
        fi
elif [ "$flag" == "gtp2" ];then
        if [ -z "$2" ];then
                ssh tangoN
        else
                ssh root@tangoN
        fi
elif [ "$flag" == "gtp3" ];then
        if [ -z "$2" ];then
                ssh tangoO
        else
                ssh root@tangoO
        fi
elif [ "$flag" == "gtp4" ];then
        if [ -z "$2" ];then
                ssh tangoP
        else
                ssh root@tangoP
        fi
elif [ "$flag" == "gtp5" ];then
        if [ -z "$2" ];then
                ssh tangoQ
        else
                ssh root@tangoQ
        fi
elif [ "$flag" == "gtp6" ];then
        if [ -z "$2" ];then
                ssh tangoR
        else
                ssh root@tangoR
        fi
elif [ "$flag" == "nac1" ];then
        if [ -z "$2" ];then
                ssh tangoS
        else
                ssh root@tangoS
        fi
elif [ "$flag" == "nac2" ];then
        if [ -z "$2" ];then
                ssh tangoT
        else
                ssh root@tangoT
        fi
else
        echo "`tput setaf 1`Node does not exist`tput sgr0`"
fi