#!/bin/bash
cd /home/tango/.curator;
source environment.sh;
curator --config /home/tango/.curator/curator.yml actions/close_indices.yml