curl -uelastic:t3l3com -XPUT 'localhost:9200/_xpack/security/role/logstash_writer?pretty' -H 'Content-Type: application/json' -d'
{
  "cluster": [
    "manage_index_templates",
    "monitor"
  ],
  "indices": [
    {
      "names": [
          "/[^.].*/"
      ],
      "privileges": [
          "write",
          "delete",
          "create_index"
      ]
  }
  ]
'