-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.45-community-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

--
-- Definition of table `blacklist`
--

DROP TABLE IF EXISTS `blacklist`;
CREATE TABLE `blacklist` (
  `id` bigint(20) NOT NULL auto_increment,
  `timezone_refreshed` varchar(255) default NULL,
  `time_refreshed` bigint(20) default NULL,
  `msisdn` varchar(100) NOT NULL,
  `timezone_blocked` varchar(255) NOT NULL,
  `time_blocked` bigint(20) NOT NULL,
  `expiry_timezone` varchar(255) default NULL,
  `expiry_time` bigint(20) default NULL,
  `timezone_unblocked` varchar(255) default NULL,
  `time_unblocked` bigint(20) default NULL,
  `cause` varchar(100) NOT NULL,
  `source_id` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK4F74291DEE689932` (`source_id`),
  CONSTRAINT `FK4F74291DEE689932` FOREIGN KEY (`source_id`) REFERENCES `se_address` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;


--
-- Definition of table `blacklist_event_log`
--

DROP TABLE IF EXISTS `blacklist_event_log`;
CREATE TABLE `blacklist_event_log` (
  `id` bigint(20) NOT NULL auto_increment,
  `msisdn` varchar(100) NOT NULL,
  `expiry_timezone` varchar(255) default NULL,
  `expiry_time` bigint(20) default NULL,
  `event` varchar(100) NOT NULL,
  `timezone_logged` varchar(255) NOT NULL,
  `time_logged` bigint(20) NOT NULL,
  `cause` varchar(100) default NULL,
  `source_id` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FKB6228B7DEE689932` (`source_id`),
  CONSTRAINT `FKB6228B7DEE689932` FOREIGN KEY (`source_id`) REFERENCES `se_address` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;


/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;

--
-- Insert into scripts_run
--
CREATE TABLE IF NOT EXISTS `scripts_run` (
	`id` BIGINT(20) NOT NULL AUTO_INCREMENT,
	`script_name` VARCHAR(100) NULL DEFAULT NULL,
	`date_updated` DATETIME NULL DEFAULT NULL,
	PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
INSERT INTO `scripts_run` (`script_name`, `date_updated`) VALUES ('mo_blacklist.sql', now());

-- End of script.
