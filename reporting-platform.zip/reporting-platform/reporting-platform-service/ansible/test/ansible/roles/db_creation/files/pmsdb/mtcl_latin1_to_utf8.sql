set global character_set_server=utf8;

ALTER SCHEMA ${jdbc.schema.name} DEFAULT CHARACTER SET utf8;


ALTER TABLE application_config_file CONVERT TO CHARACTER SET utf8;
ALTER TABLE configuration_file CONVERT TO CHARACTER SET utf8;
ALTER TABLE msac_config_parameter CONVERT TO CHARACTER SET utf8;
ALTER TABLE msac_subscriber_msisdn CONVERT TO CHARACTER SET utf8;
ALTER TABLE msac_subscriber_profile CONVERT TO CHARACTER SET utf8;
ALTER TABLE msac_white_list_config CONVERT TO CHARACTER SET utf8;
ALTER TABLE se_address CONVERT TO CHARACTER SET utf8;
ALTER TABLE tango_application CONVERT TO CHARACTER SET utf8;
ALTER TABLE tango_application_host CONVERT TO CHARACTER SET utf8;
ALTER TABLE tango_host CONVERT TO CHARACTER SET utf8;

--
-- Insert into scripts_run
--
CREATE TABLE IF NOT EXISTS `scripts_run` (
	`id` BIGINT(20) NOT NULL AUTO_INCREMENT,
	`script_name` VARCHAR(100) NULL DEFAULT NULL,
	`date_updated` DATETIME NULL DEFAULT NULL,
	PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
INSERT INTO `scripts_run` (`script_name`, `date_updated`) VALUES ('mtcl_latin1_to_utf8.sql', now());

-- End of script.