-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.45-community-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

--
-- Definition of table `antispam_configuration`
--

DROP TABLE IF EXISTS `antispam_configuration`;
CREATE TABLE `antispam_configuration` (
  `id` bigint(20) NOT NULL auto_increment,
  `digits_for_spoofing` int(11) NOT NULL,
  `enable_content_cdr` bit(1) NOT NULL,
  `log_only_when_blocked` bit(1) NOT NULL,
  `mo_basic_validation_enabled` bit(1) NOT NULL,
  `mo_basic_validation_fail_action` varchar(255) NOT NULL,
  `mo_content_analysis_enabled` bit(1) NOT NULL,
  `mo_location_verification_enabled` bit(1) NOT NULL,
  `mo_rate_control_enabled` bit(1) NOT NULL,
  `mo_source_system_screening_enabled` bit(1) NOT NULL,
  `mo_subscriber_access_control_enabled` bit(1) NOT NULL,
  `mo_subscriber_blacklisting_enabled` bit(1) NOT NULL,
  `mt_basic_validation_enabled` bit(1) NOT NULL,
  `mt_basic_validation_fail_action` varchar(255) NOT NULL,
  `mt_content_analysis_enabled` bit(1) NOT NULL,
  `mt_rate_control_enabled` bit(1) NOT NULL,
  `mt_source_system_screening_enabled` bit(1) NOT NULL,
  `mt_subscriber_blacklisting_enabled` bit(1) NOT NULL,
  `no_matching_sri_action` varchar(255) NOT NULL,
  `prefix_length_for_mo_bv` int(11) NOT NULL,
  `prefix_length_for_mt_bv` int(11) NOT NULL,
  `rate_control_enabled` bit(1) NOT NULL,
  `sri_basic_validation_fail_action` varchar(255) NOT NULL,
  `print_16_bit` bit(1) NOT NULL,
  `print_8_bit` bit(1) NOT NULL,
  `sixteen_bit_string` varchar(255) default NULL,
  `eight_bit_string` varchar(255) default NULL,
  `mt_basic_validation_whitelist_id` bigint(20) DEFAULT NULL,
  `sri_basic_validation_whitelist_id` bigint(20) DEFAULT NULL,
  `enable_mt_basic_validation_country_code_check` bit(1) NOT NULL,
  `enable_sri_basic_validation_country_code_check` bit(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- data for table `antispam_configuration`
--


/*!40000 ALTER TABLE `antispam_configuration` DISABLE KEYS */;
INSERT INTO `antispam_configuration` (`id`,`digits_for_spoofing`,`enable_content_cdr`,`log_only_when_blocked`,`mo_basic_validation_enabled`,`mo_basic_validation_fail_action`,`mo_content_analysis_enabled`,`mo_location_verification_enabled`,`mo_rate_control_enabled`,`mo_source_system_screening_enabled`,`mo_subscriber_access_control_enabled`,`mo_subscriber_blacklisting_enabled`,`mt_basic_validation_enabled`,`mt_basic_validation_fail_action`,`mt_content_analysis_enabled`,`mt_rate_control_enabled`,`mt_source_system_screening_enabled`,`mt_subscriber_blacklisting_enabled`,`no_matching_sri_action`,`prefix_length_for_mo_bv`,`prefix_length_for_mt_bv`,`rate_control_enabled`,`sri_basic_validation_fail_action`,`print_16_bit`,`print_8_bit`,`sixteen_bit_string`,`eight_bit_string`,`mt_basic_validation_whitelist_id`,`sri_basic_validation_whitelist_id` ) VALUES
 (1,3,0x00,0x00,0x00,'ALLOW',0x00,0x00,0x00,0x00,0x00,0x00,0x00,'ALLOW',0x00,0x00,0x00,0x00,'BLOCK_REPLY_OK',3,3,0x00,'ALLOW',0x01,0x01,'','',NULL,NULL);
/*!40000 ALTER TABLE `antispam_configuration` ENABLE KEYS */;


--
-- Definition of table `antispam_content_analysis_configuration`
--

DROP TABLE IF EXISTS `antispam_content_analysis_configuration`;
CREATE TABLE `antispam_content_analysis_configuration` (
  `id` bigint(20) NOT NULL auto_increment,
  `global_case_sensitive` bit(1) NOT NULL,
  `global_count_multiple_occurrences_enabled` bit(1) NOT NULL,
  `global_default_action` varchar(255) NOT NULL,
  `global_default_sfg_action` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `antispam_content_analysis_configuration`
--

/*!40000 ALTER TABLE `antispam_content_analysis_configuration` DISABLE KEYS */;
INSERT INTO `antispam_content_analysis_configuration` (`id`,`global_case_sensitive`,`global_count_multiple_occurrences_enabled`,`global_default_action`,`global_default_sfg_action`) VALUES
 (1,0x01,0x01,'NO_SPAM_DETECTED','ALLOW');
/*!40000 ALTER TABLE `antispam_content_analysis_configuration` ENABLE KEYS */;


--
-- Definition of table `antispam_content_analysis_table`
--

DROP TABLE IF EXISTS `antispam_content_analysis_table`;
CREATE TABLE `antispam_content_analysis_table` (
  `id` bigint(20) NOT NULL auto_increment,
  `case_sensitive` bit(1) NOT NULL,
  `count_multiple_occurrences_enabled` bit(1) NOT NULL,
  `default_action` varchar(255) NOT NULL,
  `default_sfg_action` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content_configuration_id` bigint(20) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `FK6AA286475534545` (`content_configuration_id`),
  CONSTRAINT `FK6AA286475534545` FOREIGN KEY (`content_configuration_id`) REFERENCES `antispam_content_analysis_configuration` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `antispam_content_analysis_table`
--

/*!40000 ALTER TABLE `antispam_content_analysis_table` DISABLE KEYS */;
/*!40000 ALTER TABLE `antispam_content_analysis_table` ENABLE KEYS */;


--
-- Definition of table `antispam_generated_configuration_file`
--

DROP TABLE IF EXISTS `antispam_generated_configuration_file`;
CREATE TABLE `antispam_generated_configuration_file` (
  `id` bigint(20) NOT NULL auto_increment,
  `contents` longtext NOT NULL,
  `file_type` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `fileset_id` bigint(20) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `FKEEADB86BB296865B` (`fileset_id`),
  CONSTRAINT `FKEEADB86BB296865B` FOREIGN KEY (`fileset_id`) REFERENCES `antispam_generated_configuration_fileset` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `antispam_generated_configuration_file`
--

/*!40000 ALTER TABLE `antispam_generated_configuration_file` DISABLE KEYS */;
/*!40000 ALTER TABLE `antispam_generated_configuration_file` ENABLE KEYS */;


--
-- Definition of table `antispam_generated_configuration_fileset`
--

DROP TABLE IF EXISTS `antispam_generated_configuration_fileset`;
CREATE TABLE `antispam_generated_configuration_fileset` (
  `id` bigint(20) NOT NULL auto_increment,
  `create_timestamp` datetime NOT NULL,
  `description` varchar(1024) default NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `antispam_generated_configuration_fileset`
--

/*!40000 ALTER TABLE `antispam_generated_configuration_fileset` DISABLE KEYS */;
/*!40000 ALTER TABLE `antispam_generated_configuration_fileset` ENABLE KEYS */;


--
-- Definition of table `antispam_global_threshold_map`
--

DROP TABLE IF EXISTS `antispam_global_threshold_map`;
CREATE TABLE `antispam_global_threshold_map` (
  `content_configuration_id` bigint(20) NOT NULL,
  `action` varchar(255) NOT NULL,
  `threshold` int(11) NOT NULL default '0',
  PRIMARY KEY  (`content_configuration_id`,`threshold`),
  KEY `FK5BCFC6825534545` (`content_configuration_id`),
  CONSTRAINT `FK5BCFC6825534545` FOREIGN KEY (`content_configuration_id`) REFERENCES `antispam_content_analysis_configuration` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `antispam_global_threshold_map`
--

/*!40000 ALTER TABLE `antispam_global_threshold_map` DISABLE KEYS */;
INSERT INTO `antispam_global_threshold_map` (`content_configuration_id`,`action`,`threshold`) VALUES 
 (1,'SPAM_DETECTED',10);
/*!40000 ALTER TABLE `antispam_global_threshold_map` ENABLE KEYS */;


--
-- Table structure for table `antispam_global_sfg_threshold_map`
--

DROP TABLE IF EXISTS `antispam_global_sfg_threshold_map`;
CREATE TABLE `antispam_global_sfg_threshold_map` (
  `content_configuration_id` bigint(20) NOT NULL,
  `sfg_action` varchar(255) NOT NULL,
  `threshold` int(11) NOT NULL default '0',
  PRIMARY KEY  (`content_configuration_id`,`threshold`),
  KEY `FK331AA9753BBAE4CF` (`content_configuration_id`),
  CONSTRAINT `FK331AA9753BBAE4CF` FOREIGN KEY (`content_configuration_id`) REFERENCES `antispam_content_analysis_configuration` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `antispam_global_sfg_threshold_map`
--

LOCK TABLES `antispam_global_sfg_threshold_map` WRITE;
/*!40000 ALTER TABLE `antispam_global_sfg_threshold_map` DISABLE KEYS */;
INSERT INTO `antispam_global_sfg_threshold_map` VALUES (1,'ALLOW',10);
/*!40000 ALTER TABLE `antispam_global_sfg_threshold_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Definition of table `antispam_location_verification_profile`
--

DROP TABLE IF EXISTS `antispam_location_verification_profile`;
CREATE TABLE `antispam_location_verification_profile` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `default_action` varchar(255) NOT NULL,
  `num_spoofing_digits` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `spoofer_action` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `antispam_location_verification_profile` DISABLE KEYS */;
INSERT INTO `antispam_location_verification_profile` (`id`,`default_action`,`num_spoofing_digits`,`name`,`spoofer_action`) VALUES
 (1,'ALLOW',1, 'VerProf1','ALLOW');
/*!40000 ALTER TABLE `antispam_location_verification_profile` ENABLE KEYS */;

--
-- Definition of table `antispam_error_code_action_map`
--

DROP TABLE IF EXISTS `antispam_error_code_action_map`;
CREATE TABLE `antispam_error_code_action_map` (
  `sri_sm_error_code_to_action_map_id` bigint(20) NOT NULL,
  `action` varchar(255) NOT NULL,
  `error_code` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`sri_sm_error_code_to_action_map_id`,`error_code`),
  KEY `FK6EAF199A87EE6C43` (`sri_sm_error_code_to_action_map_id`),
  CONSTRAINT `FK6EAF199A87EE6C43` FOREIGN KEY (`sri_sm_error_code_to_action_map_id`) REFERENCES `antispam_location_verification_profile` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `antispam_error_code_action_map` DISABLE KEYS */;
INSERT INTO `antispam_error_code_action_map` (`sri_sm_error_code_to_action_map_id`,`action`,`error_code`) VALUES
 (1,'ALLOW',1),
 (1,'BLOCK_SEND_ABORT',13);
/*!40000 ALTER TABLE `antispam_error_code_action_map` ENABLE KEYS */;

--
-- Definition of table `antispam_network_profile`
--

DROP TABLE IF EXISTS `antispam_network_profile`;
CREATE TABLE `antispam_network_profile` (
  `id` bigint(20) NOT NULL auto_increment,
  `content_analysis_action` varchar(255) NOT NULL,
  `content_analysis_enabled` bit(1) NOT NULL,
  `mo_location_verification_action` varchar(255) NOT NULL,
  `mo_location_verification_enabled` bit(1) NOT NULL,
  `mo_check_loc_ver_prof_list_enabled` bit(1) NOT NULL,
  `logging_enabled` bit(1) NOT NULL,
  `mo_basic_validation_action` varchar(255) NOT NULL,
  `mo_basic_validation_enabled` bit(1) NOT NULL,
  `mo_fwd_sm_handling_action` varchar(255) NOT NULL,
  `mo_msisdn_blacklist_action` varchar(255) NOT NULL,
  `mo_msisdn_blacklist_enabled` bit(1) NOT NULL,
  `mo_msisdn_whitelist_action` varchar(255) NOT NULL,
  `mo_msisdn_whitelist_enabled` bit(1) NOT NULL,
  `mo_pid_blacklist_action` varchar(255) NOT NULL,
  `mo_pid_blacklist_enabled` bit(1) NOT NULL,
  `mo_rating_action` varchar(255) NOT NULL,
  `mo_rating_enabled` bit(1) NOT NULL,
  `mt_alphanumeric_whitelist_action` varchar(255) NOT NULL,
  `mt_alphanumeric_blacklist_action` varchar(255) NOT NULL,
  `mt_alphanumeric_whitelist_enabled` bit(1) NOT NULL,
  `mt_alphanumeric_blacklist_enabled` bit(1) NOT NULL,
  `mt_basic_validation_action` varchar(255) NOT NULL,
  `mt_basic_validation_enabled` bit(1) NOT NULL,
  `mt_fwd_sm_handling_action` varchar(255) NOT NULL,
  `mt_msisdn_blacklist_action` varchar(255) NOT NULL,
  `mt_msisdn_blacklist_enabled` bit(1) NOT NULL,
  `mt_pid_blacklist_action` varchar(255) NOT NULL,
  `mt_pid_blacklist_enabled` bit(1) NOT NULL,
  `mt_rating_action` varchar(255) NOT NULL,
  `mt_rating_enabled` bit(1) NOT NULL,
  `name` varchar(255) NOT NULL,
  `verbose` bit(1) NOT NULL,
  `message_type` varchar(255) NOT NULL default 'MAP',
  `mt_msisdn_blacklist_id` bigint(20) default NULL,
  `mt_pid_blacklist_id` bigint(20) DEFAULT NULL,
  `mo_rating_profile_id` bigint(20) default NULL,
  `mt_rating_profile_id` bigint(20) default NULL,
  `mo_msisdn_blacklist_id` bigint(20) default NULL,
  `mo_msisdn_whitelist_id` bigint(20) default NULL,
  `mo_pid_blacklist_id` bigint(20) DEFAULT NULL,
  `mt_alphanumeric_whitelist_id` bigint(20) default NULL,
  `mt_alphanumeric_blacklist_id` bigint(20) default NULL,
  `content_analysis_id` bigint(20) default NULL,
  `loc_ver_profile_id` bigint(20) default NULL,
  `sri_sm_b_msisdn_list_action` varchar(255) NOT NULL,
  `sri_sm_handling` varchar(255) NOT NULL,
  `sri_sm_b_msisdn_white_list` bigint(20) default NULL,
  `sri_sm_white_list_enabled` bit(1) NOT NULL,
  `mo_duplicate_content_profile_enabled` bit(1) NOT NULL DEFAULT 0x00,
  `mo_duplicate_content_profile_action` VARCHAR(255) NOT NULL DEFAULT 'ALLOW',
  `mo_duplicate_content_profile_id` bigint(20) DEFAULT NULL,
  `mt_duplicate_content_profile_enabled` bit(1) NOT NULL DEFAULT 0x00,
  `mt_duplicate_content_profile_action` VARCHAR(255) NOT NULL DEFAULT 'ALLOW',
  `mt_duplicate_content_profile_id` bigint(20) DEFAULT NULL,
  `mt_msisdn_whitelist_id` bigint(20) DEFAULT NULL,
  `mt_msisdn_whitelist_action` VARCHAR(255) NOT NULL DEFAULT 'ALLOW',
  `mt_msisdn_whitelist_enabled` BIT(1) NOT NULL DEFAULT 0x00,
  `mt_ton_blacklist_enabled` BIT(1) NOT NULL DEFAULT 0x00,
  `mt_ton_blacklist_action` VARCHAR(255) NOT NULL DEFAULT 'ALLOW',
  `mt_ton_blacklist_name` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `FKC3013842BA78E7AB` (`content_analysis_id`),
  KEY `FKC3013842F59408B4` (`mt_msisdn_blacklist_id`),
  KEY `FKC3013842G40276H5` (`mt_msisdn_whitelist_id`),
  KEY `FKC3013842B6973D2F` (`mo_msisdn_blacklist_id`),
  KEY `FKC30138421026DDC5` (`mo_msisdn_whitelist_id`),
  KEY `FKC30138422F2AB9C8` (`mo_rating_profile_id`),
  KEY `FKC3013842B2B278BE` (`mt_alphanumeric_blacklist_id`),
  KEY `FKC3013842337EA28D` (`mt_rating_profile_id`),
  KEY `FK38875604E3653400` (`sri_sm_b_msisdn_white_list`),
  KEY `FK388756044E4D44C1` (`loc_ver_profile_id`),
  KEY `FK388756044BEC93B9` (`mo_pid_blacklist_id`),
  KEY `FK3887560422C5FE54` (`mt_pid_blacklist_id`),
  CONSTRAINT `FKC3013842337EA28D` FOREIGN KEY (`mt_rating_profile_id`) REFERENCES `antispam_rating_profile` (`id`),
  CONSTRAINT `FKC30138421026DDC5` FOREIGN KEY (`mo_msisdn_whitelist_id`) REFERENCES `antispam_prefix_list` (`id`),
  CONSTRAINT `FKC30138422F2AB9C8` FOREIGN KEY (`mo_rating_profile_id`) REFERENCES `antispam_rating_profile` (`id`),
  CONSTRAINT `FKC3013842B2B278BE` FOREIGN KEY (`mt_alphanumeric_blacklist_id`) REFERENCES `antispam_string_list` (`id`),
  CONSTRAINT `FKC3013842B6973D2F` FOREIGN KEY (`mo_msisdn_blacklist_id`) REFERENCES `antispam_prefix_list` (`id`),
  CONSTRAINT `FKC3013842BA78E7AB` FOREIGN KEY (`content_analysis_id`) REFERENCES `antispam_content_analysis_table` (`id`),
  CONSTRAINT `FKC3013842F59408B4` FOREIGN KEY (`mt_msisdn_blacklist_id`) REFERENCES `antispam_prefix_list` (`id`),
  CONSTRAINT `FKC3013842G40276H5` FOREIGN KEY (`mt_msisdn_whitelist_id`) REFERENCES `antispam_prefix_list` (`id`),
  CONSTRAINT `FK38875604E3653400` FOREIGN KEY (`sri_sm_b_msisdn_white_list`) REFERENCES `antispam_prefix_list` (`id`),
  CONSTRAINT `FK388756044E4D44C1` FOREIGN KEY (`loc_ver_profile_id`) REFERENCES `antispam_location_verification_profile` (`id`),
  CONSTRAINT `FK388756044BEC93B9` FOREIGN KEY (`mo_pid_blacklist_id`) REFERENCES `antispam_protocol_identifier_list` (`id`),
  CONSTRAINT `FK3887560422C5FE54` FOREIGN KEY (`mt_pid_blacklist_id`) REFERENCES `antispam_protocol_identifier_list` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `antispam_network_profile`
--

/*!40000 ALTER TABLE `antispam_network_profile` DISABLE KEYS */;
INSERT INTO `antispam_network_profile` (`id`,`content_analysis_action`,`content_analysis_enabled`,`mo_location_verification_action`,`mo_location_verification_enabled`,`loc_ver_profile_id`, `mo_check_loc_ver_prof_list_enabled`, `logging_enabled`,`mo_basic_validation_action`,`mo_basic_validation_enabled`,`mo_fwd_sm_handling_action`,`mo_msisdn_blacklist_action`,`mo_msisdn_blacklist_enabled`,`mo_msisdn_whitelist_action`,`mo_msisdn_whitelist_enabled`,`mo_rating_action`,`mo_rating_enabled`,`mt_alphanumeric_whitelist_action`,`mt_alphanumeric_blacklist_action`,`mt_alphanumeric_whitelist_enabled`,`mt_alphanumeric_blacklist_enabled`,`mt_basic_validation_action`,`mt_basic_validation_enabled`,`mt_fwd_sm_handling_action`,`mt_msisdn_blacklist_action`,`mt_msisdn_blacklist_enabled`,`mt_rating_action`,`mt_rating_enabled`,`name`,`verbose`,`mt_msisdn_blacklist_id`,`mo_rating_profile_id`,`mt_rating_profile_id`,`mo_msisdn_blacklist_id`,`mo_msisdn_whitelist_id`,`mt_alphanumeric_whitelist_id`,`mt_alphanumeric_blacklist_id`,`content_analysis_id`,`sri_sm_b_msisdn_list_action`,`sri_sm_handling`,`sri_sm_b_msisdn_white_list`,`sri_sm_white_list_enabled`,`mo_pid_blacklist_enabled`,`mo_pid_blacklist_action`,`mo_pid_blacklist_id`,`mt_pid_blacklist_enabled`,`mt_pid_blacklist_action`,`mt_pid_blacklist_id`,`mo_duplicate_content_profile_enabled`,`mo_duplicate_content_profile_action`, mo_duplicate_content_profile_id,`mt_duplicate_content_profile_enabled`,`mt_duplicate_content_profile_action`,mt_duplicate_content_profile_id,`mt_ton_blacklist_enabled`,`mt_ton_blacklist_action`,`mt_ton_blacklist_name`,`mt_msisdn_whitelist_id`,`mt_msisdn_whitelist_action`,`mt_msisdn_whitelist_enabled`) VALUES
 (1,'ALLOW',0x00,'ALLOW',0x00,1,1,0x00,'ALLOW',0x00,'ALLOW','ALLOW',0x00,'ALLOW',0x00,'ALLOW',0x00,'ALLOW','ALLOW',0x00,0x00,'ALLOW',0x00,'ALLOW','ALLOW',0x00,'ALLOW',0x00,'default_profile',0x00,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ALLOW','ALLOW',NULL,0x00,0x00,'ALLOW',NULL,0x00,'ALLOW',NULL,0,'ALLOW',NULL,0,'ALLOW',NULL,0,'ALLOW',NULL,NULL,'ALLOW',0);
/*!40000 ALTER TABLE `antispam_network_profile` ENABLE KEYS */;


--
-- Definition of table `antispam_network_profile_configuration`
--

DROP TABLE IF EXISTS `antispam_network_profile_configuration`;
CREATE TABLE `antispam_network_profile_configuration` (
  `id` bigint(20) NOT NULL auto_increment,
  `default_network_profile_id` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK5B91E3B93B0C4EB5` (`default_network_profile_id`),
  CONSTRAINT `FK5B91E3B93B0C4EB5` FOREIGN KEY (`default_network_profile_id`) REFERENCES `antispam_network_profile` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `antispam_network_profile_configuration`
--

/*!40000 ALTER TABLE `antispam_network_profile_configuration` DISABLE KEYS */;
INSERT INTO `antispam_network_profile_configuration` (`id`,`default_network_profile_id`) VALUES 
 (1,1);
/*!40000 ALTER TABLE `antispam_network_profile_configuration` ENABLE KEYS */;


--
-- Definition of table `antispam_prefix`
--

DROP TABLE IF EXISTS `antispam_prefix`;
CREATE TABLE `antispam_prefix` (
  `prefix_list_id` bigint(20) NOT NULL,
  `msisdn` varchar(255) NOT NULL,
  PRIMARY KEY  (`prefix_list_id`,`msisdn`),
  KEY `FK35954FA89FD1B139` (`prefix_list_id`),
  CONSTRAINT `FK35954FA89FD1B139` FOREIGN KEY (`prefix_list_id`) REFERENCES `antispam_prefix_list` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `antispam_prefix`
--

/*!40000 ALTER TABLE `antispam_prefix` DISABLE KEYS */;
/*!40000 ALTER TABLE `antispam_prefix` ENABLE KEYS */;


--
-- Definition of table `antispam_prefix_list`
--

DROP TABLE IF EXISTS `antispam_prefix_list`;
CREATE TABLE `antispam_prefix_list` (
  `id` bigint(20) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `antispam_prefix_list`
--

/*!40000 ALTER TABLE `antispam_prefix_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `antispam_prefix_list` ENABLE KEYS */;


--
-- Definition of table `antispam_protocol_identifier`
--

DROP TABLE IF EXISTS `antispam_protocol_identifier`;
CREATE TABLE `antispam_protocol_identifier` (
  `protocol_identifier_list_id` bigint(20) NOT NULL,
  `protocol_identifier` int(11) NOT NULL,
  PRIMARY KEY (`protocol_identifier_list_id`,`protocol_identifier`),
  KEY `FK6FE5281C4DE94CD8` (`protocol_identifier_list_id`),
  CONSTRAINT `FK6FE5281C4DE94CD8` FOREIGN KEY (`protocol_identifier_list_id`) REFERENCES `antispam_protocol_identifier_list` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `antispam_protocol_identifier`
--

/*!40000 ALTER TABLE `antispam_protocol_identifier` DISABLE KEYS */;
/*!40000 ALTER TABLE `antispam_protocol_identifier` ENABLE KEYS */;


--
-- Definition of table `antispam_protocol_identifier_list`
--

DROP TABLE IF EXISTS `antispam_protocol_identifier_list`;
CREATE TABLE `antispam_protocol_identifier_list` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `antispam_protocol_identifier_list`
--

/*!40000 ALTER TABLE `antispam_protocol_identifier_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `antispam_protocol_identifier_list` ENABLE KEYS */;


--
-- Definition of table `antispam_rating_definition`
--

DROP TABLE IF EXISTS `antispam_rating_definition`;
CREATE TABLE `antispam_rating_definition` (
  `id` bigint(20) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `number_of_windows` int(11) NOT NULL,
  `threshold_per_window` int(11) NOT NULL,
  `window_length` int(11) NOT NULL,
  `windows_over_threshold_Max` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `antispam_rating_definition`
--

/*!40000 ALTER TABLE `antispam_rating_definition` DISABLE KEYS */;
/*!40000 ALTER TABLE `antispam_rating_definition` ENABLE KEYS */;


--
-- Definition of table `antispam_rating_profile`
--

DROP TABLE IF EXISTS `antispam_rating_profile`;
CREATE TABLE `antispam_rating_profile` (
  `id` bigint(20) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `antispam_rating_profile`
--

/*!40000 ALTER TABLE `antispam_rating_profile` DISABLE KEYS */;
/*!40000 ALTER TABLE `antispam_rating_profile` ENABLE KEYS */;


--
-- Definition of table `antispam_rating_profile_map`
--

DROP TABLE IF EXISTS `antispam_rating_profile_map`;
CREATE TABLE `antispam_rating_profile_map` (
  `rating_profile_id` bigint(20) NOT NULL,
  `rating_def_id` bigint(20) NOT NULL,
  `rating_rule_id` bigint(20) NOT NULL,
  PRIMARY KEY  (`rating_profile_id`,`rating_rule_id`),
  KEY `FK5E379A3AC9D1F20F` (`rating_rule_id`),
  KEY `FK5E379A3AF230EB01` (`rating_def_id`),
  KEY `FK5E379A3A703F2725` (`rating_profile_id`),
  CONSTRAINT `FK5E379A3A703F2725` FOREIGN KEY (`rating_profile_id`) REFERENCES `antispam_rating_profile` (`id`),
  CONSTRAINT `FK5E379A3AC9D1F20F` FOREIGN KEY (`rating_rule_id`) REFERENCES `antispam_rating_rule` (`id`),
  CONSTRAINT `FK5E379A3AF230EB01` FOREIGN KEY (`rating_def_id`) REFERENCES `antispam_rating_definition` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `antispam_rating_profile_map`
--

/*!40000 ALTER TABLE `antispam_rating_profile_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `antispam_rating_profile_map` ENABLE KEYS */;


--
-- Definition of table `antispam_rating_rule`
--

DROP TABLE IF EXISTS `antispam_rating_rule`;
CREATE TABLE `antispam_rating_rule` (
  `id` bigint(20) NOT NULL auto_increment,
  `apply_if_true` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `param_type` varchar(255) NOT NULL,
  `param_value` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `antispam_rating_rule`
--

/*!40000 ALTER TABLE `antispam_rating_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `antispam_rating_rule` ENABLE KEYS */;


--
-- Table structure for table `antispam_sfg_threshold_map`
--

DROP TABLE IF EXISTS `antispam_sfg_threshold_map`;
CREATE TABLE `antispam_sfg_threshold_map` (
  `content_table_id` bigint(20) NOT NULL,
  `sfg_action` varchar(255) NOT NULL,
  `threshold` int(11) NOT NULL default '0',
  PRIMARY KEY  (`content_table_id`,`threshold`),
  KEY `FKCB886D69FB21FACF` (`content_table_id`),
  CONSTRAINT `FKCB886D69FB21FACF` FOREIGN KEY (`content_table_id`) REFERENCES `antispam_content_analysis_table` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `antispam_sfg_threshold_map`
--

LOCK TABLES `antispam_sfg_threshold_map` WRITE;
/*!40000 ALTER TABLE `antispam_sfg_threshold_map` DISABLE KEYS */;
INSERT INTO `antispam_sfg_threshold_map` VALUES (1,'ALLOW',10),(1,'ALLOW',20),(2,'ALLOW',12),(2,'ALLOW',24);
/*!40000 ALTER TABLE `antispam_sfg_threshold_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Definition of table `antispam_source_global_title_map`
--

DROP TABLE IF EXISTS `antispam_source_global_title_map`;
CREATE TABLE `antispam_source_global_title_map` (
  `network_profile_configuration_id` bigint(20) NOT NULL,
  `network_profile_id` bigint(20) NOT NULL,
  `prefix` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`network_profile_configuration_id`,`prefix`),
  KEY `FK4C475EA7C27A2FF7` (`network_profile_id`),
  KEY `FK4C475EA77E395EEC` (`network_profile_configuration_id`),
  CONSTRAINT `FK4C475EA77E395EEC` FOREIGN KEY (`network_profile_configuration_id`) REFERENCES `antispam_network_profile_configuration` (`id`),
  CONSTRAINT `FK4C475EA7C27A2FF7` FOREIGN KEY (`network_profile_id`) REFERENCES `antispam_network_profile` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `antispam_source_global_title_map`
--

/*!40000 ALTER TABLE `antispam_source_global_title_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `antispam_source_global_title_map` ENABLE KEYS */;


--
-- Definition of table `antispam_string`
--

DROP TABLE IF EXISTS `antispam_string`;
CREATE TABLE `antispam_string` (
  `string_list_id` bigint(20) NOT NULL,
  `string` varchar(255) NOT NULL,
  PRIMARY KEY  (`string_list_id`,`string`),
  KEY `FK3AD5FD27242845B7` (`string_list_id`),
  CONSTRAINT `FK3AD5FD27242845B7` FOREIGN KEY (`string_list_id`) REFERENCES `antispam_string_list` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `antispam_string`
--

/*!40000 ALTER TABLE `antispam_string` DISABLE KEYS */;
/*!40000 ALTER TABLE `antispam_string` ENABLE KEYS */;


--
-- Definition of table `antispam_string_list`
--

DROP TABLE IF EXISTS `antispam_string_list`;
CREATE TABLE `antispam_string_list` (
  `id` bigint(20) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `antispam_string_list`
--

/*!40000 ALTER TABLE `antispam_string_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `antispam_string_list` ENABLE KEYS */;


--
-- Definition of table `antispam_threshold_map`
--

DROP TABLE IF EXISTS `antispam_threshold_map`;
CREATE TABLE `antispam_threshold_map` (
  `content_table_id` bigint(20) NOT NULL,
  `action` varchar(255) NOT NULL,
  `threshold` int(11) NOT NULL default '0',
  PRIMARY KEY  (`content_table_id`,`threshold`),
  KEY `FKF43F29B250C53145` (`content_table_id`),
  CONSTRAINT `FKF43F29B250C53145` FOREIGN KEY (`content_table_id`) REFERENCES `antispam_content_analysis_table` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `antispam_threshold_map`
--

/*!40000 ALTER TABLE `antispam_threshold_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `antispam_threshold_map` ENABLE KEYS */;


--
-- Definition of table `antispam_token_map`
--

DROP TABLE IF EXISTS `antispam_token_map`;
CREATE TABLE `antispam_token_map` (
  `content_table_id` bigint(20) NOT NULL,
  `weighting` int(11) NOT NULL,
  `token` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`content_table_id`,`token`),
  KEY `FKDFDC2D4050C53145` (`content_table_id`),
  CONSTRAINT `FKDFDC2D4050C53145` FOREIGN KEY (`content_table_id`) REFERENCES `antispam_content_analysis_table` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `antispam_token_map`
--

/*!40000 ALTER TABLE `antispam_token_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `antispam_token_map` ENABLE KEYS */;


--
-- Add "antispam" Feature data
--
/*!40000 ALTER TABLE `tango_application` DISABLE KEYS */;
INSERT INTO `tango_application` (`id`,`name`) VALUES
 (1,'SFP_antispam'),
 (2,'SFG_antispam');
/*!40000 ALTER TABLE `tango_application` ENABLE KEYS */;

/*!40000 ALTER TABLE `application_se_process` DISABLE KEYS */;
INSERT INTO `application_se_process` (`tango_application_id`,`se_process_address`) VALUES
 (1,'SFP_smsMoProxy/0'),
 (1,'SFP_smsMtProxy/0'),
 (2,'SFG_smsMoProxy/0'),
 (2,'SFG_smsMtProxy/0');
/*!40000 ALTER TABLE `application_se_process` ENABLE KEYS */;

/*!40000 ALTER TABLE `application_config_file` DISABLE KEYS */;
INSERT INTO `application_config_file` (`tango_application_id`,`file_name`) VALUES
 (1,'SFP_accessControlLists.cfg'),
 (1,'SFP_alphanumericLists.cfg'),
 (1,'SFP_antispam.cfg'),
 (1,'SFP_contentAnalysis.cfg'),
 (1,'SFP_locationVerification.cfg'),
 (1,'SFP_networkProfiles.cfg'),
 (1,'SFP_rateControl.cfg'),
 (2,'SFG_accessControlLists.cfg'),
 (2,'SFG_alphanumericLists.cfg'),
 (2,'SFG_antispam.cfg'),
 (2,'SFG_contentAnalysis.cfg'),
 (2,'SFG_locationVerification.cfg'),
 (2,'SFG_networkProfiles.cfg'),
 (2,'SFG_rateControl.cfg');

--
-- Table structure for table `antispam_dc_landc_profile`
--

DROP TABLE IF EXISTS `antispam_dc_landc_profile`;
CREATE TABLE `antispam_dc_landc_profile` (
  `id` bigint(20) NOT NULL,
  `long_duplicate_content_rule_oid` bigint(20) DEFAULT NULL,
  `short_duplicate_content_rule_oid` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK27C86C96F01CBC0F` (`id`),
  KEY `FK27C86C969140DEF7` (`short_duplicate_content_rule_oid`),
  KEY `FK27C86C96D75A5CF7` (`long_duplicate_content_rule_oid`),
  CONSTRAINT `FK27C86C96D75A5CF7` FOREIGN KEY (`long_duplicate_content_rule_oid`) REFERENCES `antispam_dc_rule` (`id`),
  CONSTRAINT `FK27C86C969140DEF7` FOREIGN KEY (`short_duplicate_content_rule_oid`) REFERENCES `antispam_dc_rule` (`id`),
  CONSTRAINT `FK27C86C96F01CBC0F` FOREIGN KEY (`id`) REFERENCES `antispam_dc_test_type_profile` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Table structure for table `antispam_dc_landc_settings`
--

DROP TABLE IF EXISTS `antispam_dc_landc_settings`;
CREATE TABLE `antispam_dc_landc_settings` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `minimum_time_to_prune_sms` int(11) DEFAULT NULL,
  `table_prune_period` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


--
-- Table structure for table `antispam_dc_normalisation_profile`
--

DROP TABLE IF EXISTS `antispam_dc_normalisation_profile`;
CREATE TABLE `antispam_dc_normalisation_profile` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


--
-- Table structure for table `antispam_dc_normalisation_rule`
--

DROP TABLE IF EXISTS `antispam_dc_normalisation_rule`;
CREATE TABLE `antispam_dc_normalisation_rule` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `input` varchar(255) NOT NULL,
  `output` varchar(255) NOT NULL,
  `normalisation_profile_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK8D2B8D43DE1EE99A` (`normalisation_profile_id`),
  CONSTRAINT `FK8D2B8D43DE1EE99A` FOREIGN KEY (`normalisation_profile_id`) REFERENCES `antispam_dc_normalisation_profile` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


--
-- Table structure for table `antispam_dc_profile`
--

DROP TABLE IF EXISTS `antispam_dc_profile`;
CREATE TABLE `antispam_dc_profile` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `enable_cdr` bit(1) DEFAULT NULL,
  `min_no_chars` int(11) DEFAULT NULL,
  `min_no_chars_test_enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `normalisation_enabled` bit(1) DEFAULT NULL,
  `whitelist_enabled` bit(1) DEFAULT NULL,
  `normalisation_profile_id` bigint(20) DEFAULT NULL,
  `test_type_profile_id` bigint(20) DEFAULT NULL,
  `whitelist_profile_id` bigint(20) DEFAULT NULL,
  `originating_gt_length` int(11) NOT NULL DEFAULT '10',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `FKC91040FDDE1EE99A` (`normalisation_profile_id`),
  KEY `FKC91040FD741BDEDD` (`test_type_profile_id`),
  KEY `FKC91040FD808A7ED4` (`whitelist_profile_id`),
  CONSTRAINT `FKC91040FD808A7ED4` FOREIGN KEY (`whitelist_profile_id`) REFERENCES `antispam_dc_whitelist_profile` (`id`),
  CONSTRAINT `FKC91040FD741BDEDD` FOREIGN KEY (`test_type_profile_id`) REFERENCES `antispam_dc_test_type_profile` (`id`),
  CONSTRAINT `FKC91040FDDE1EE99A` FOREIGN KEY (`normalisation_profile_id`) REFERENCES `antispam_dc_normalisation_profile` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `antispam_dc_rule`
--

DROP TABLE IF EXISTS `antispam_dc_rule`;
CREATE TABLE `antispam_dc_rule` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blocking_window_length` int(11) NOT NULL,
  `detection_window_length` int(11) NOT NULL,
  `detection_window_max_sms` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `rule_type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `antispam_dc_test_type_profile`
--

DROP TABLE IF EXISTS `antispam_dc_test_type_profile`;
CREATE TABLE `antispam_dc_test_type_profile` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `test_type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `antispam_dc_whitelist_profile`
--

DROP TABLE IF EXISTS `antispam_dc_whitelist_profile`;
CREATE TABLE `antispam_dc_whitelist_profile` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


--
-- Table structure for table `antispam_dc_whitelist_rule`
--

DROP TABLE IF EXISTS `antispam_dc_whitelist_rule`;
CREATE TABLE `antispam_dc_whitelist_rule` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `whitelist` varchar(255) NOT NULL,
  `whitelist_profile_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK9294620808A7ED4` (`whitelist_profile_id`),
  CONSTRAINT `FK9294620808A7ED4` FOREIGN KEY (`whitelist_profile_id`) REFERENCES `antispam_dc_whitelist_profile` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


--
-- Table structure for table `antispam_ton_types`
--

DROP TABLE IF EXISTS `antispam_ton_types`;
CREATE TABLE `antispam_ton_types` (
	`network_profile_id` BIGINT(20) NOT NULL,
	`ton_type` VARCHAR(255) NOT NULL,
	PRIMARY KEY (`network_profile_id`, `ton_type`),
	INDEX `FK998A4CF976C4E929` (`network_profile_id`),
	CONSTRAINT `FK998A4CF976C4E929` FOREIGN KEY (`network_profile_id`) REFERENCES `antispam_network_profile` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;

--
-- Insert into scripts_run
--
CREATE TABLE IF NOT EXISTS `scripts_run` (
	`id` BIGINT(20) NOT NULL AUTO_INCREMENT,
	`script_name` VARCHAR(100) NULL DEFAULT NULL,
	`date_updated` DATETIME NULL DEFAULT NULL,
	PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `scripts_run` (`script_name`, `date_updated`) VALUES ('antispam.sql', now());

-- End of script.