db_creation
===========
This role is responsible for creation of databases for test purposes. 

To run this role, it is assumed that you have a msql server or a docker mysql container running which will be populated
with databases, database schema (DDL) and/or database data (DML).

The roles performs the following:

- The role reads a 'databases' variable which contains meta data concerning the databases to create. The variable is intended to be overridden, passed as a command line argument as a property - see the way in which the file containing the variable can be passed as 
 ansible-playbook command below: 
 
   ````
       0. databases:
       1.   pmsdb: 
       2.      name: pmsdb
       3.      user: pmsjdbc
       4.      userhost: "{{targetdb}}"
       5.      password: "{{pms_pass}}"
       6.      logfile: "{{ pcc_logs_dir }}/pmi/pmi.log"
       7.      schema:
       8.        - file: "/home/tango/end-to-end/other/ansible/roles/db_creation/files/pmsdb/pms_base_schema.sql"
       9.        - file: "/home/tango/end-to-end/other/ansible/roles/db_creation/files/pmsdb/antispam.sql"
       10.       - file: "/home/tango/end-to-end/other/ansible/roles/db_creation/files/pmsdb/common_config.sql"
       11.       - file: "/home/tango/end-to-end/other/ansible/roles/db_creation/files/pmsdb/ismsc.sql"
       12.     datafile:
       13        - file: "/home/tango/end-to-end/other/ansible/roles/db_creation/files/empty.sql"
       14   cpsdb: 
       15.     name: cpsdb
       16.     user: cpsjdbc
       17.     userhost: "{{targetdb}}"
       18      password: "{{cps_pass}}"
       19.     logfile: "{{ pcc_logs_dir }}/cps/cps.log"
       20      schema:
       21.       - file: /home/tango/end-to-end/other/ansible/roles/db_creation/files/empty.sql      
        
   ````
The following describes each line above
0. The 'databases' variable declaration. It contains one or more entries (e.g. pmsdb (line1), cpsdb (line 12) )
1. Each database entry contains a number of properties (name,user, userhost, password, logfile, schema, datafile (optional))
2. name: the name of the 1st database to create ( database schema name)
3. user: the mysql user associated with the database 
4. userhost: the ip address (or docker container name of the host where mysql is running)
5. password: the mysql database password associated with the role. Can contain a specific password or an ansible variable. If
an ansible variable is used the variable is declared elsewhere in the file.
6. logfile: a location where the output logs will be written to.
7. schema: a list containing one or more database (DDL) schema files containing e.g. CREATE TABLE, CREATE INDEX statements..
8.  schema file 1 - absolute path to the schema file 1
9.  schema file 2 - absolute path to the schema file 2
10. schema file 3 - absolute path to the schema file 3
11. schema file 4 - absolute path to the schema file 4
12. datafile: a list of files containing database (DML) scripts (e.g. containing e.g. INSERT INTO TABLE statements)
13. data file 1 - absolute path the data file. Can be empty datafile. 
14. name of the 2nd database (database schema name)
15. user: the mysql user associated with the 2nd database
16. userhost: the mysql host user associated with the 2nd database
 
The role reads the 
- Creates databases instances for the specified databases 
- Executes a schema DDL script (if one is provided)  
- Executes a DML script to populate the database with data (if one is provided) 

Requirements
------------
It is required to ensure the mysql dependencies are installed prior to running this role 

Role Variables
--------------

Available variables are listed below, along with default values (see `defaults/main.yml`):

    ## default for db_creation
    greenfield_deploy: true
    insert_data: true
    docker_containers_used: true

    ## The mysql root user name    
    mysql_root: <obfuscated>
    
    ## The mysql root user password
    mysql_root_pass: <obfuscated>
    
    ## The port number to connect to the mysql host
    mysql_root_port: 3306 
  
The pcc.yml file containing ansible variables used by the role
        
    ## default tenant
    tenant: tango
    
    targetdb: "{{pccdb_tango}}"
    cpsdb_pass: cpss3cret
    ds_pass: dss3cret
    hrg_pass: hrgs3cret
    pcrfdb_pass: pcrfs3cret
    pmcsdb_pass: pmcss3cret
    pms_pass: pmss3cret
    ppsdb_pass: ppss3cret
    smd_pass: smds3cret
    spcm_pass: spcms3cret
    smpp_pass: smpps3cret
    pcc_logs_dir: /home/tango/containers/pcc/6.1.2/logs/
    host: "%"
    
    databases:
      cpsdb:
        name: cpsdb
        user: cpsjdbc
        userhost: "{{targetdb}}"
        password: "{{ cpsdb_pass }}"
        logfile: "{{ pcc_logs_dir }}"
        schema:
          - file: /home/tango/end-to-end/other/ansible/roles/db_creation/files/empty.sql
    
      dsdb:
        name: dsdb
        user: dsjdbc
        userhost: "{{targetdb}}"
        password: "{{ ds_pass }}"
        logfile: "{{ pcc_logs_dir }}"
        schema:
          - file: /home/tango/end-to-end/other/ansible/roles/db_creation/files/empty.sql
      hrgdb:
        name: hrgdb
        user: hrgjdbc
        userhost: "{{targetdb}}"
        password: "{{ hrg_pass }}"
        logfile: "{{ pcc_logs_dir }}/hrg/hrg.log"
        schema:
          - file: /home/tango/end-to-end/other/ansible/roles/db_creation/files/empty.sql
      
      pcrfdb:
        name: pcrfdb
        user: pcrfjdbc
        userhost: "{{targetdb}}"
        password: "{{ pcrfdb_pass }}"
        logfile: "{{ pcc_logs_dir }}"
        schema:
          - file: /home/tango/end-to-end/other/ansible/roles/db_creation/files/empty.sql
      pmscsdb:
        name: pcrfdb
        user: pmcsjdbc
        userhost: "{{targetdb}}"
        password: "{{ pmcsdb_pass }}"
        logfile: "{{ pcc_logs_dir }}"
        schema:
          - file: /home/tango/end-to-end/other/ansible/roles/db_creation/files/empty.sql
      
      pmsdb:
        name: pmsdb
        user: pmsjdbc
        userhost: "{{targetdb}}"
        password: "{{pms_pass}}"
        logfile: "{{ pcc_logs_dir }}/pmi/pmi.log"
        schema:
          - file: "/home/tango/end-to-end/other/ansible/roles/db_creation/files/pmsdb/pms_base_schema.sql"
          - file: "/home/tango/end-to-end/other/ansible/roles/db_creation/files/pmsdb/antispam.sql"
          - file: "/home/tango/end-to-end/other/ansible/roles/db_creation/files/pmsdb/common_config.sql"
          - file: "/home/tango/end-to-end/other/ansible/roles/db_creation/files/pmsdb/ismsc.sql"
          - file: "/home/tango/end-to-end/other/ansible/roles/db_creation/files/pmsdb/mo_blacklist.sql"
          - file: "/home/tango/end-to-end/other/ansible/roles/db_creation/files/pmsdb/sccp.sql"
          - file: "/home/tango/end-to-end/other/ansible/roles/db_creation/files/pmsdb/sms_blackout.sql"
          - file: "/home/tango/end-to-end/other/ansible/roles/db_creation/files/pmsdb/trace.sql"
          - file: "/home/tango/end-to-end/other/ansible/roles/db_creation/files/pmsdb/ussd.sql"
      ppsdb:
        name: ppsdb
        user: ppsjdbc
        userhost: "{{targetdb}}"
        password: "{{ ppsdb_pass }}"
        logfile: "{{ pcc_logs_dir }}"
        schema:
          - file: /home/tango/end-to-end/other/ansible/roles/db_creation/files/empty.sql
        
      smd:
        name: smd
        user: smdjdbc
        userhost: "{{targetdb}}"
        password: "{{ smd_pass }}"
        logfile: "{{ pcc_logs_dir }}"
        schema:
          - file: /home/tango/end-to-end/other/ansible/roles/db_creation/files/empty.sql
     
      smpp:
        name: smpp
        user: smppjdbc
        userhost: "{{targetdb}}"
        password: "{{ smpp_pass }}"
        logfile: "{{ pcc_logs_dir }}"
        schema:
          - file: /home/tango/end-to-end/other/ansible/roles/db_creation/files/smpp/create_tables.sql
      
      spcmdb:
        name: spcmdb
        user: spcmjdbc
        userhost: "{{targetdb}}"
        password: "{{ spcm_pass }}"
        logfile: "{{ pcc_logs_dir }}"
        schema:
          - file: /home/tango/end-to-end/other/ansible/roles/db_creation/files/empty.sql
                        
Dependencies
------------

- mysql client dependencies
- ansible mysql client 

Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - name: Create databases playbook
      hosts: localhost
      roles:
        - db_creation   
        
             
````

ansible-playbook db_creation.yml -vvv --extra-vars="pccdb_tango=192.168.192.3" --extra-vars '@pcc.yml' -K


````
    
In this case the *--extra-vars* variables shall over-ride the default *tenant* (see `defaults/main.yml`) and any 
variables defined on site in the *host_vars* or *group_vars* directories.        


Getting the ip address of the docker mysql container:

````

dbip=`docker inspect testdb | grep IPAddress | tail -n 1 | grep -oE '((1?[0-9][0-9]?|2[0-4][0-9]|25[0-5])\.){3}(1?[0-9][0-9]?|2[0-4][0-9]|25[0-5])'`
echo $dbip

````



License
-------
Tango Telecom Ltd.
