-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.45-community-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Table structure for table `ussd_application`
--

DROP TABLE IF EXISTS `ussd_application`;
CREATE TABLE `ussd_application` (
  `id` bigint(20) NOT NULL auto_increment,
  `canvas_coordinate_left` int(11) default NULL,
  `canvas_coordinate_top` int(11) default NULL,
  `canvas_termination_coordinate_left` int(11) default NULL,
  `canvas_termination_coordinate_top` int(11) default NULL,
  `charging_enabled` bit(1) NOT NULL,
  `charging_method` varchar(255) default NULL,
  `charging_rate` bigint(20) default NULL,
  `created_date_time` datetime NOT NULL,
  `default_display` varchar(255) default NULL,
  `description` varchar(255) default NULL,
  `date_time` datetime NOT NULL,
  `message_content_type` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `persistant_sessions_flag` bit(1) NOT NULL,
  `proceed_if_insufficient_funds` bit(1) NOT NULL,
  `proceed_if_postpaid` bit(1) NOT NULL,
  `proceed_on_charging_error` bit(1) NOT NULL,
  `server_resource` varchar(255) default NULL,
  `root_menu_command_id` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK4E9BA280DE8EBAB3` (`root_menu_command_id`),
  CONSTRAINT `FK4E9BA280DE8EBAB3` FOREIGN KEY (`root_menu_command_id`) REFERENCES `ussd_menu_command` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;



--
-- Table structure for table `ussd_event`
--

DROP TABLE IF EXISTS `ussd_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ussd_event` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event` varchar(255) NOT NULL,
  `date_time` datetime NOT NULL,
  `operator` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ussd_event`
--

LOCK TABLES `ussd_event` WRITE;
/*!40000 ALTER TABLE `ussd_event` DISABLE KEYS */;
INSERT INTO `ussd_event` VALUES (1,'PROCESS_DISCOVERED','2010-10-04 13:01:31','denis'),(2,'PROCESS_GROUP_CREATED','2011-02-28 18:22:11','martin'),(3,'SERVICE_SET_EDITED','2012-12-22 04:19:23','frank'),(4,'SERVICE_SET_DEPLOYED','1944-08-31 11:01:24','alex'),(5,'SERVICE_EDITED','2073-05-12 23:18:37','brendan');
/*!40000 ALTER TABLE `ussd_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ussd_handover_request`
--

DROP TABLE IF EXISTS `ussd_handover_request`;
CREATE TABLE `ussd_handover_request` (
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKFFCE74E33F3C2BBC` (`id`),
  CONSTRAINT `FKFFCE74E33F3C2BBC` FOREIGN KEY (`id`) REFERENCES `ussd_menu_command` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Table structure for table `ussd_menu_command`
--

DROP TABLE IF EXISTS `ussd_menu_command`;
CREATE TABLE `ussd_menu_command` (
  `id` bigint(20) NOT NULL,
  `canvas_coordinate_left` int(11) default NULL,
  `canvas_coordinate_top` int(11) default NULL,
  `command_type` varchar(255) default NULL,
  `display_string` varchar(500) default NULL,
  `date_time` datetime NOT NULL,
  `message_content_type` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `response_map_value` varchar(255) DEFAULT NULL,
  `command_ok_id` bigint(20) default NULL,
  `command_operation_error_id` bigint(20) default NULL,
  `command_system_error_id` bigint(20) default NULL,
  `post_execution_delay` bigint(20) NOT NULL default -1,
  `custom_cdr_enabled` bit(1) NOT NULL DEFAULT b'0',
  `custom_cdr_identifier` bigint(20) default NULL,
  `custom_cdr_data` varchar(255) DEFAULT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `FKD1E4D53BB805246F` (`command_system_error_id`),
  KEY `FKD1E4D53B5D9CC30B` (`command_ok_id`),
  KEY `FKD1E4D53B9245769F` (`command_operation_error_id`),
  CONSTRAINT `FKD1E4D53B9245769F` FOREIGN KEY (`command_operation_error_id`) REFERENCES `ussd_menu_command` (`id`),
  CONSTRAINT `FKD1E4D53B5D9CC30B` FOREIGN KEY (`command_ok_id`) REFERENCES `ussd_menu_command` (`id`),
  CONSTRAINT `FKD1E4D53BB805246F` FOREIGN KEY (`command_system_error_id`) REFERENCES `ussd_menu_command` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Table structure for table `ussd_header`
--

DROP TABLE IF EXISTS `ussd_header`;
CREATE TABLE `ussd_header` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `value` varchar(255) DEFAULT NULL,
  `server_request_tag_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK50DBC75D9BE321B4` (`server_request_tag_id`),
  CONSTRAINT `FK50DBC75D9BE321B4` FOREIGN KEY (`server_request_tag_id`) REFERENCES `ussd_server_request_tag` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Definition of table `ussd_request`
--

DROP TABLE IF EXISTS `ussd_request`;
CREATE TABLE `ussd_request` (
  `id` bigint(20) NOT NULL,
  `alternative_subscriber` varchar(255) DEFAULT NULL,
  `storage_tag` varchar(255) DEFAULT NULL,
  `storage_type` varchar(255) DEFAULT NULL, 
  PRIMARY KEY (`id`),
  KEY `FKDC84A7BF3F3C2BBC` (`id`),
  CONSTRAINT `FKDC84A7BF3F3C2BBC` FOREIGN KEY (`id`) REFERENCES `ussd_menu_command` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Table structure for table `ussd_request_option`
--

DROP TABLE IF EXISTS `ussd_request_option`;
CREATE TABLE `ussd_request_option` (
  `id` bigint(20) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `command_id` bigint(20) default NULL,
  `ussd_request_id` bigint(20) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `FK917C78F52F617421` (`ussd_request_id`),
  KEY `FK917C78F56DF96930` (`command_id`),
  CONSTRAINT `FK917C78F56DF96930` FOREIGN KEY (`command_id`) REFERENCES `ussd_menu_command` (`id`),
  CONSTRAINT `FK917C78F52F617421` FOREIGN KEY (`ussd_request_id`) REFERENCES `ussd_request` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


--
-- Definition of table `ussd_notify`
--

DROP TABLE IF EXISTS `ussd_notify`;
CREATE TABLE `ussd_notify` (
  `id` bigint(20) NOT NULL,
  `alternative_subscriber` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK5BAE7C193F3C2BBC` (`id`),
  CONSTRAINT `FK5BAE7C193F3C2BBC` FOREIGN KEY (`id`) REFERENCES `ussd_menu_command` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Definition of table `ussd_server_request`
--

DROP TABLE IF EXISTS `ussd_server_request`;
CREATE TABLE `ussd_server_request` (
  `id` bigint(20) NOT NULL,
  `command_tag_id` bigint(20) NOT NULL,
  `server_response_map_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKD247EA633F3C2BBC` (`id`),
  KEY `FKD247EA63DB7438FC` (`command_tag_id`),
  KEY `FKD247EA63646E097E` (`server_response_map_id`),
  CONSTRAINT `FKD247EA63646E097E` FOREIGN KEY (`server_response_map_id`) REFERENCES `ussd_server_response_map` (`id`),
  CONSTRAINT `FKD247EA633F3C2BBC` FOREIGN KEY (`id`) REFERENCES `ussd_menu_command` (`id`),
  CONSTRAINT `FKD247EA63DB7438FC` FOREIGN KEY (`command_tag_id`) REFERENCES `ussd_server_request_tag` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Table structure for table `ussd_server_request_tag`
--

DROP TABLE IF EXISTS `ussd_server_request_tag`;
CREATE TABLE `ussd_server_request_tag` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `http_request_type` varchar(255) DEFAULT NULL,
  `http_status_code` varchar(255) DEFAULT NULL,
  `date_time` datetime NOT NULL,
  `name` varchar(255) NOT NULL,
  `request_data` longtext DEFAULT NULL,
  `server_request_type` varchar(255) NOT NULL,
  `response_code_storage_tag` varchar(255) DEFAULT NULL,
  `response_data_handling` varchar(255) DEFAULT 'PARSE',
  `response_data_storage_tag` varchar(255) DEFAULT NULL,
  `response_string_storage_tag` varchar(255) DEFAULT NULL,
  `timeout` bigint(20) NOT NULL,
  `url` varchar(500) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Definition of table `ussd_parameter`
--

DROP TABLE IF EXISTS `ussd_parameter`;
CREATE TABLE `ussd_parameter` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `server_request_tag_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK191BDCD99BE321B4` (`server_request_tag_id`),
  CONSTRAINT `FK191BDCD99BE321B4` FOREIGN KEY (`server_request_tag_id`) REFERENCES `ussd_server_request_tag` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


--
-- Table structure for table `ussd_server_response_map`
--

DROP TABLE IF EXISTS `ussd_server_response_map`;
CREATE TABLE `ussd_server_response_map` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `canvas_coordinate_left` int(11) DEFAULT NULL,
  `canvas_coordinate_top` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `date_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


--
-- Table structure for table `ussd_server_response_option`
--

DROP TABLE IF EXISTS `ussd_server_response_option`;
CREATE TABLE `ussd_server_response_option` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT, 
  `command` bigint(20) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `server_response_map_id` bigint(20) NOT NULL,
  `date_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKE0F3A0777E1FDEC` (`command`),
  KEY `FKE0F3A07646E097E` (`server_response_map_id`),
  CONSTRAINT `FKE0F3A07646E097E` FOREIGN KEY (`server_response_map_id`) REFERENCES `ussd_server_response_map` (`id`),
  CONSTRAINT `FKE0F3A0777E1FDEC` FOREIGN KEY (`command`) REFERENCES `ussd_menu_command` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


--
-- Table structure for table `ussd_process_group`
--

DROP TABLE IF EXISTS `ussd_process_group`;
CREATE TABLE `ussd_process_group` (
  `id` bigint(20) NOT NULL auto_increment,
  `created_date_time` datetime NOT NULL,
  `description` varchar(255) default NULL,
  `date_time` datetime NOT NULL,
  `name` varchar(255) NOT NULL,
  `process_group_type` varchar(255) NOT NULL,
  `application_name` varchar(255) default 'USSD_SI_SD',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `ussd_process`
--

DROP TABLE IF EXISTS `ussd_process`;
CREATE TABLE `ussd_process` (
  `id` bigint(20) NOT NULL auto_increment,
  `created_date_time` datetime NOT NULL,
  `host_name` varchar(255) NOT NULL,
  `last_report_date_time` datetime default NULL,
  `last_report_version` varchar(255) default NULL,
  `date_time` datetime NOT NULL,
  `sd_file_name` varchar(255) default NULL,
  `se_address` varchar(255) NOT NULL,
  `state` varchar(255) default NULL,
  `user` varchar(255) default NULL,
  `process_group_id` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK88C2D39F3188A64` (`process_group_id`),
  CONSTRAINT `FK88C2D39F3188A64` FOREIGN KEY (`process_group_id`) REFERENCES `ussd_process_group` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `ussd_script_expression`
--

DROP TABLE IF EXISTS `ussd_script_expression`;
CREATE TABLE `ussd_script_expression` (
  `id` bigint(20) NOT NULL auto_increment,
  `functionEnd` varchar(255) default NULL,
  `functionPrototype` varchar(255) default NULL,
  `date_time` datetime NOT NULL,
  `lockdown_enabled` bit(1) NOT NULL,
  `name` varchar(255) NOT NULL,
  `number_of_response_paras` int(11) NOT NULL,
  `script_type` varchar(255) NOT NULL,
  `text` longtext,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `ussd_script_expression_parameter`
--

DROP TABLE IF EXISTS `ussd_script_expression_parameter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ussd_script_expression_parameter` (
  `script_expression_id` bigint(20) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `parameter_index` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FKFCC97BA21C22F0EB` (`script_expression_id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ussd_event`
--

DROP TABLE IF EXISTS `ussd_event`;
CREATE TABLE `ussd_event` (
  `id` bigint(20) NOT NULL auto_increment,
  `event` varchar(255) NOT NULL,
  `firing_object` varchar(255) NOT NULL,
  `date_time` datetime NOT NULL,
  `operator` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `ussd_generated_app_set`
--

DROP TABLE IF EXISTS `ussd_generated_app_set`;
CREATE TABLE `ussd_generated_app_set` (
  `id` bigint(20) NOT NULL auto_increment,
  `app_set_name` varchar(255) default NULL,
  `app_set_version` varchar(255) default NULL,
  `contents` longtext NOT NULL,
  `create_timestamp` datetime NOT NULL,
  `deployed` bit(1) NOT NULL,
  `java_script_contents` longtext,
  `date_time` datetime NOT NULL,
  `xml_contents` longtext NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


--
-- Table structure for table `ussd_script_request`
--

DROP TABLE IF EXISTS `ussd_script_request`;
CREATE TABLE `ussd_script_request` (
  `id` bigint(20) NOT NULL,
  `server_response_map_id` bigint(20) NOT NULL,
  `script_expression_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKD5583EB3F3C2BBC` (`id`),
  KEY `FKD5583EB1C22F0EB` (`script_expression_id`),
  KEY `FKD5583EB646E097E` (`server_response_map_id`),
  CONSTRAINT `FKD5583EB1C22F0EB` FOREIGN KEY (`script_expression_id`) REFERENCES `ussd_script_expression` (`id`),
  CONSTRAINT `FKD5583EB3F3C2BBC` FOREIGN KEY (`id`) REFERENCES `ussd_menu_command` (`id`),
  CONSTRAINT `FKD5583EB646E097E` FOREIGN KEY (`server_response_map_id`) REFERENCES `ussd_server_response_map` (`id`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Table structure for table `ussd_script_parameter`
--

DROP TABLE IF EXISTS `ussd_script_parameter`;
CREATE TABLE `ussd_script_parameter` (
  `id` bigint(20) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `parameter_type` varchar(255) default NULL,
  `value` varchar(255) default NULL,
  `script_request_id` bigint(20) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `FK59265E05C4CA66BA` (`script_request_id`),
  CONSTRAINT `FK59265E05C4CA66BA` FOREIGN KEY (`script_request_id`) REFERENCES `ussd_script_request` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


--
-- Table structure for table `ussd_upload`
--

DROP TABLE IF EXISTS `ussd_upload`;
CREATE TABLE `ussd_upload` (
  `id` bigint(20) NOT NULL auto_increment,
  `date_time` datetime NOT NULL,
  `operator` varchar(255) NOT NULL,
  `generated_app_set_id` bigint(20) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `FK67AAF2D1245D3CFE` (`generated_app_set_id`),
  CONSTRAINT `FK67AAF2D1245D3CFE` FOREIGN KEY (`generated_app_set_id`) REFERENCES `ussd_generated_app_set` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


--
-- Table structure for table `ussd_upload_result`
--

DROP TABLE IF EXISTS `ussd_upload_result`;
CREATE TABLE `ussd_upload_result` (
  `id` bigint(20) NOT NULL auto_increment,
  `date_time` datetime NOT NULL,
  `upload_result` varchar(255) default NULL,
  `ussd_process_id` bigint(20) NOT NULL,
  `ussd_upload_id` bigint(20) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `FK9A14354BF2936821` (`ussd_process_id`),
  KEY `FK9A14354BC4A43073` (`ussd_upload_id`),
  CONSTRAINT `FK9A14354BC4A43073` FOREIGN KEY (`ussd_upload_id`) REFERENCES `ussd_upload` (`id`),
  CONSTRAINT `FK9A14354BF2936821` FOREIGN KEY (`ussd_process_id`) REFERENCES `ussd_process` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


--
-- Table structure for table `ussd_application_set`
--

DROP TABLE IF EXISTS `ussd_application_set`;
CREATE TABLE `ussd_application_set` (
  `id` bigint(20) NOT NULL auto_increment,
  `created_date_time` datetime NOT NULL,
  `description` varchar(255) default NULL,
  `date_time` datetime NOT NULL,
  `name` varchar(255) default NULL,
  `version` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;




--
-- Table structure for table `ussd_application_set`
--

DROP TABLE IF EXISTS `ussd_application_set`;
CREATE TABLE `ussd_application_set` (
  `id` bigint(20) NOT NULL auto_increment,
  `created_date_time` datetime NOT NULL,
  `description` varchar(255) default NULL,
  `date_time` datetime NOT NULL,
  `name` varchar(255) default NULL,
  `version` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `ussd_application_set_application`
--

DROP TABLE IF EXISTS `ussd_application_set_application`;
CREATE TABLE `ussd_application_set_application` (
  `id` bigint(20) NOT NULL auto_increment,
  `short_code` varchar(255) default NULL,
  `application_id` bigint(20) NOT NULL,
  `application_set_id` bigint(20) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `FK6289534407F2031` (`application_id`),
  KEY `FK6289534B3814502` (`application_set_id`),
  CONSTRAINT `FK6289534B3814502` FOREIGN KEY (`application_set_id`) REFERENCES `ussd_application_set` (`id`),
  CONSTRAINT `FK6289534407F2031` FOREIGN KEY (`application_id`) REFERENCES `ussd_application` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


--
-- For Canvas SCE to enable draft / work in progress services to be saved and retrieved.
--

DROP TABLE IF EXISTS `ussd_draft_canvas_service`;
CREATE TABLE `ussd_draft_canvas_service` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `draft_service_desc` varchar(255) DEFAULT NULL,
  `draft_service_name` varchar(255) DEFAULT NULL,
  `date_time` datetime NOT NULL,
  `xml_contents` longtext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `draft_service_name` (`draft_service_name`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;

--
-- Insert into scripts_run
--
CREATE TABLE IF NOT EXISTS `scripts_run` (
	`id` BIGINT(20) NOT NULL AUTO_INCREMENT,
	`script_name` VARCHAR(100) NULL DEFAULT NULL,
	`date_updated` DATETIME NULL DEFAULT NULL,
	PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
INSERT INTO `scripts_run` (`script_name`, `date_updated`) VALUES ('ussd.sql', now());

-- End of script.
