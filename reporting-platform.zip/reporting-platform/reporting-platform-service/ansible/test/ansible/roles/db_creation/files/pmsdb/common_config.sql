
--
-- Definition of table `common_configuration`
--



DROP TABLE IF EXISTS `common_configuration`;
CREATE TABLE `common_configuration` (
  `id` bigint(20) NOT NULL auto_increment,
  `create_timestamp` datetime NOT NULL,
  `updated_time` datetime DEFAULT NULL,
  `created_time` datetime DEFAULT NULL,
  `entity_name` varchar(255) NOT NULL,
  `description` varchar(1024) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `entity_name` (`entity_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;



--
-- Definition of table `generated_configuration`
--

DROP TABLE IF EXISTS `generated_configuration`;
CREATE TABLE `generated_configuration` (
  `id` bigint(20) NOT NULL auto_increment,
  `create_timestamp` datetime NOT NULL,
  `config_file_type` varchar(255) default NULL,
  `name` varchar(255) NOT NULL,
  `contents` longtext NOT NULL,
  `description` varchar(1024) default NULL,
  `common_configuration_id` bigint(20) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `FKB42C7A4648ED702B` (`common_configuration_id`),
  CONSTRAINT `FKB42C7A4648ED702B` FOREIGN KEY (`common_configuration_id`) REFERENCES `common_configuration` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;

--
-- Insert into scripts_run
--
CREATE TABLE IF NOT EXISTS `scripts_run` (
	`id` BIGINT(20) NOT NULL AUTO_INCREMENT,
	`script_name` VARCHAR(100) NULL DEFAULT NULL,
	`date_updated` DATETIME NULL DEFAULT NULL,
	PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
INSERT INTO `scripts_run` (`script_name`, `date_updated`) VALUES ('common_config.sql', now());

-- End of script.