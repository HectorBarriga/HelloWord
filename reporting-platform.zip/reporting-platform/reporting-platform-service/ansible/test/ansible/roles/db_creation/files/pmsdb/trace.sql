-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.45-community-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

--
-- Definition of table `trace`
--

DROP TABLE IF EXISTS `trace`;
CREATE TABLE `trace` (
  `id` bigint(20) NOT NULL auto_increment,
  `timezone_modified` varchar(255) NOT NULL,
  `time_modified` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `trace_type_id` bigint(20) NOT NULL,
  `trace_point_id` bigint(20) NOT NULL,
  `trace_setting_id` bigint(20) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `FK697F1455AAB196` (`trace_type_id`),
  KEY `FK697F145F381C91E` (`trace_point_id`),
  KEY `FK697F1455CC3481E` (`trace_setting_id`),
  CONSTRAINT `FK697F1455CC3481E` FOREIGN KEY (`trace_setting_id`) REFERENCES `trace_setting` (`id`),
  CONSTRAINT `FK697F1455AAB196` FOREIGN KEY (`trace_type_id`) REFERENCES `trace_type` (`id`),
  CONSTRAINT `FK697F145F381C91E` FOREIGN KEY (`trace_point_id`) REFERENCES `trace_point` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;


--
-- Definition of table `trace_event`
--

DROP TABLE IF EXISTS `trace_event`;
CREATE TABLE `trace_event` (
  `id` bigint(20) NOT NULL auto_increment,
  `trace_point` varchar(255) NOT NULL,
  `matched_key` varchar(255) NOT NULL,
  `text` varchar(255) NOT NULL,
  `timezone_time` varchar(255) NOT NULL,
  `time_time` bigint(20) NOT NULL,
  `trace_source_id` bigint(20) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `FK210FFF20BF59E2F6` (`trace_source_id`),
  CONSTRAINT `FK210FFF20BF59E2F6` FOREIGN KEY (`trace_source_id`) REFERENCES `trace_source` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;


--
-- Definition of table `trace_key`
--

DROP TABLE IF EXISTS `trace_key`;
CREATE TABLE `trace_key` (
  `id` bigint(20) NOT NULL auto_increment,
  `value` varchar(255) NOT NULL,
  `trace_key_type_id` bigint(20) NOT NULL,
  `trace_id` bigint(20) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `FK2B309465C4A121C9` (`trace_key_type_id`),
  KEY `FK2B309465C212744B` (`trace_id`),
  CONSTRAINT `FK2B309465C212744B` FOREIGN KEY (`trace_id`) REFERENCES `trace` (`id`),
  CONSTRAINT `FK2B309465C4A121C9` FOREIGN KEY (`trace_key_type_id`) REFERENCES `trace_key_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;


--
-- Definition of table `trace_key_type`
--

DROP TABLE IF EXISTS `trace_key_type`;
CREATE TABLE `trace_key_type` (
  `id` bigint(20) NOT NULL auto_increment,
  `value` varchar(100) NOT NULL,
  `description` varchar(1024) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `value` (`value`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `trace_key_type`
--

/*!40000 ALTER TABLE `trace_key_type` DISABLE KEYS */;
INSERT INTO `trace_key_type` (`id`,`value`,`description`) VALUES 
 (1,'exact','exact key number'),
 (2,'partial','partial key number');
/*!40000 ALTER TABLE `trace_key_type` ENABLE KEYS */;


--
-- Definition of table `trace_point`
--

DROP TABLE IF EXISTS `trace_point`;
CREATE TABLE `trace_point` (
  `id` bigint(20) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL,
  `description` varchar(1024) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `trace_point`
--

/*!40000 ALTER TABLE `trace_point` DISABLE KEYS */;
INSERT INTO `trace_point` (`id`,`name`,`description`) VALUES 
 (1,'MO SMS A-Number','moniter from number'),
 (2,'MO SMS B-Number','moniter to number'),
 (3,'P2P MT SMS A-Number','monitor P2P MT A number'),
 (4,'P2P MT SMS B-Number','monitor P2P MT B number'),
 (5,'P2P MT SMS Text','monitor P2P MT Text'),
 (6,'M2P MT SMS A-Number','monitor M2P MT A number'),
 (7,'M2P MT SMS B-Number','monitor M2P MT B number'),
 (8,'M2P MT SMS Text','monitor M2P MT Text'),
 (9,'Receipt A-Number','monitor A number Receipt'),
 (10,'MO SMS Text','monitor MO Text'),
 (11,'MT SMS A-Number','monitor MT A number'),
 (12,'MT SMS B-Number','monitor MT B number'),
 (13,'MT SMS Text','monitor MT Text');
/*!40000 ALTER TABLE `trace_point` ENABLE KEYS */;


--
-- Definition of table `trace_setting`
--

DROP TABLE IF EXISTS `trace_setting`;
CREATE TABLE `trace_setting` (
  `id` bigint(20) NOT NULL auto_increment,
  `sequence_id` bigint(20) NOT NULL,
  `global_enabled` bit(1) NOT NULL,
  `description` varchar(1024) default NULL,
  `password` varchar(255) NOT NULL,
  `password_enabled` bit(1) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `sequence_id` (`sequence_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `trace_setting`
--

/*!40000 ALTER TABLE `trace_setting` DISABLE KEYS */;
INSERT INTO `trace_setting` (`id`,`sequence_id`,`global_enabled`,`description`,`password`,`password_enabled`) VALUES 
 (1,1,0x01,'trace setting 1, feel free to change this description','password',0x01);
/*!40000 ALTER TABLE `trace_setting` ENABLE KEYS */;


--
-- Definition of table `trace_source`
--

DROP TABLE IF EXISTS `trace_source`;
CREATE TABLE `trace_source` (
  `id` bigint(20) NOT NULL auto_increment,
  `system` varchar(255) NOT NULL,
  `cluster` varchar(255) NOT NULL,
  `process` varchar(255) NOT NULL,
  `process_instance` int(11) NOT NULL,
  `state_machine` varchar(255) NOT NULL,
  `state_machine_instance` int(11) NOT NULL,
  `host` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;


--
-- Definition of table `trace_type`
--

DROP TABLE IF EXISTS `trace_type`;
CREATE TABLE `trace_type` (
  `id` bigint(20) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL,
  `description` varchar(1024) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `trace_type`
--

/*!40000 ALTER TABLE `trace_type` DISABLE KEYS */;
INSERT INTO `trace_type` (`id`,`name`,`description`) VALUES 
 (1,'basic','basic'),
 (2,'intercept','intercept');
/*!40000 ALTER TABLE `trace_type` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;

--
-- Insert into scripts_run
--
CREATE TABLE IF NOT EXISTS `scripts_run` (
	`id` BIGINT(20) NOT NULL AUTO_INCREMENT,
	`script_name` VARCHAR(100) NULL DEFAULT NULL,
	`date_updated` DATETIME NULL DEFAULT NULL,
	PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
INSERT INTO `scripts_run` (`script_name`, `date_updated`) VALUES ('trace.sql', now());

-- End of script.