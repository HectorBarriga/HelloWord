#!/bin/sh
for NAME in $(docker ps --format {{.Names}})
do
  echo -n "$NAME: "
  docker inspect $NAME | grep "IP.*[12]*\.[0-9]*" | \
         sed -e 's/^  *//g' -e 's/[",]//g' -e 's/[a-zA-Z: ]//g' -e 's/^d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b//g' | head -n 1 
done

