-- MySQL dump 10.13  Distrib 5.1.37, for debian-linux-gnu (i486)
--
-- Host: localhost    Database: pmidb
-- ------------------------------------------------------
-- Server version       5.1.37-1ubuntu5.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `longest_prefix_match_config`
--

DROP TABLE IF EXISTS `longest_prefix_match_config`;
CREATE TABLE `longest_prefix_match_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `useReverseGtt` bit(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `longest_prefix_match_config`
--


DROP TABLE IF EXISTS `longest_prefix_match_incoming_map`;

CREATE TABLE `longest_prefix_match_incoming_map` (
  `longest_prefix_match_id` bigint(20) NOT NULL,
  `gtt_definition_id` bigint(20) NOT NULL,
  UNIQUE KEY `gtt_definition_id` (`gtt_definition_id`),
  KEY `FK95F23A55BE06B7BC` (`longest_prefix_match_id`),
  KEY `FK95F23A559F64D95D` (`gtt_definition_id`),
  CONSTRAINT `FK95F23A559F64D95D` FOREIGN KEY (`gtt_definition_id`) REFERENCES `gtt_definition` (`id`),
  CONSTRAINT `FK95F23A55BE06B7BC` FOREIGN KEY (`longest_prefix_match_id`) REFERENCES `longest_prefix_match_config` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Dumping data for table `longest_prefix_match_incoming_map`
--

--
-- Table structure for table `longest_prefix_match_outgoing_map`
--

DROP TABLE IF EXISTS `longest_prefix_match_outgoing_map`;

CREATE TABLE `longest_prefix_match_outgoing_map` (
  `longest_prefix_match_id` bigint(20) NOT NULL,
  `gtt_definition_id` bigint(20) NOT NULL,
  UNIQUE KEY `gtt_definition_id` (`gtt_definition_id`),
  KEY `FK3CDC629BBE06B7BC` (`longest_prefix_match_id`),
  KEY `FK3CDC629B9F64D95D` (`gtt_definition_id`),
  CONSTRAINT `FK3CDC629B9F64D95D` FOREIGN KEY (`gtt_definition_id`) REFERENCES `gtt_definition` (`id`),
  CONSTRAINT `FK3CDC629BBE06B7BC` FOREIGN KEY (`longest_prefix_match_id`) REFERENCES `longest_prefix_match_config` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `longest_prefix_match_outgoing_map`
--




--
-- Table structure for table `longest_prefix_match_calling_map`
--

DROP TABLE IF EXISTS `longest_prefix_match_calling_map`;

CREATE TABLE `longest_prefix_match_calling_map` (
  `longest_prefix_match_id` bigint(20) NOT NULL,
  `gtt_definition_id` bigint(20) NOT NULL,
  UNIQUE KEY `gtt_definition_id` (`gtt_definition_id`),
  KEY `FK6BD3208FBE06B7BC` (`longest_prefix_match_id`),
  KEY `FK6BD3208F9F64D95D` (`gtt_definition_id`),
  CONSTRAINT `FK6BD3208F9F64D95D` FOREIGN KEY (`gtt_definition_id`) REFERENCES `gtt_definition` (`id`),
  CONSTRAINT `FK6BD3208FBE06B7BC` FOREIGN KEY (`longest_prefix_match_id`) REFERENCES `longest_prefix_match_config` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `longest_prefix_match_calling_map`
--

--
-- Table structure for table `network_entity`
--

DROP TABLE IF EXISTS `network_entity`;

CREATE TABLE `network_entity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `mode` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;


--
-- Dumping data for table `network_entity`
--

--
-- Table structure for table `gtt_definition`
--

DROP TABLE IF EXISTS `gtt_definition`;

CREATE TABLE `gtt_definition` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `globalTitle` varchar(255) DEFAULT NULL,
  `gttLength` int(11) DEFAULT NULL,
  `nature_of_address` varchar(255) DEFAULT NULL,
  `translation_type` varchar(255) DEFAULT NULL,
  `network_entity_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK74818B6B25F6B2EB` (`network_entity_id`),
  CONSTRAINT `FK74818B6B25F6B2EB` FOREIGN KEY (`network_entity_id`) REFERENCES `network_entity` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9133 DEFAULT CHARSET=utf8;


--
-- Dumping data for table `gtt_definition`
--


--
-- Table structure for table `ss7_detail`
--

DROP TABLE IF EXISTS `ss7_detail`;

CREATE TABLE `ss7_detail` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `digit_string` varchar(255) DEFAULT NULL,
  `gt_translation_type` int(11) DEFAULT NULL,
  `nature_of_address` int(11) DEFAULT NULL,
  `point_code` varchar(255) DEFAULT NULL,
  `route_on` varchar(255) DEFAULT NULL,
  `sub_system_number` varchar(255) DEFAULT NULL,
  `translation_type` int(11) DEFAULT NULL,
  `network_entity_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKFAF667B925F6B2EB` (`network_entity_id`),
  CONSTRAINT `FKFAF667B925F6B2EB` FOREIGN KEY (`network_entity_id`) REFERENCES `network_entity` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8;


--
-- Dumping data for table `ss7_detail`
--




/*!40000 ALTER TABLE `longest_prefix_match_config` DISABLE KEYS */;
INSERT INTO `longest_prefix_match_config` VALUES (1,'^A');
/*!40000 ALTER TABLE `longest_prefix_match_config` ENABLE KEYS */;





/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2010-08-24 10:39:59

--
-- Insert into scripts_run
--
CREATE TABLE IF NOT EXISTS `scripts_run` (
	`id` BIGINT(20) NOT NULL AUTO_INCREMENT,
	`script_name` VARCHAR(100) NULL DEFAULT NULL,
	`date_updated` DATETIME NULL DEFAULT NULL,
	PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
INSERT INTO `scripts_run` (`script_name`, `date_updated`) VALUES ('sccp.sql', now());

-- End of script.