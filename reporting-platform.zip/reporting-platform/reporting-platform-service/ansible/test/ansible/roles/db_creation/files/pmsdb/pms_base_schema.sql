-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.45-community-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

--
-- Definition of table `configuration_file`
--

DROP TABLE IF EXISTS `configuration_file`;
CREATE TABLE `configuration_file` (
  `id` bigint(20) NOT NULL auto_increment,
  `created_by` varchar(255) NOT NULL,
  `last_updated_by` varchar(255) default NULL,
  `reloaded` bit(1) NOT NULL,
  `timezone_created` varchar(255) NOT NULL,
  `time_created` bigint(20) NOT NULL,
  `timezone_last_updated` varchar(255) default NULL,
  `time_last_updated` bigint(20) default NULL,
  `applicatioin` varchar(255) default NULL,
  `file_path` varchar(255) default NULL,
  `hcm_id` varchar(255) default NULL,
  `hcm_port` varchar(255) default NULL,
  `host_ip` varchar(255) default NULL,
  `process` varchar(255) default NULL,
  `file_name` varchar(255) default NULL,
  `content` LONGTEXT,
  `host_name` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Definition of table `se_address`
--

DROP TABLE IF EXISTS `se_address`;
CREATE TABLE `se_address` (
  `id` bigint(20) NOT NULL auto_increment,
  `application` varchar(100) default NULL,
  `cluster` varchar(50) default NULL,
  `service` varchar(100) default NULL,
  `node` varchar(50) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

--
-- Definition of table `application_config_file`
--

DROP TABLE IF EXISTS `application_config_file`;
CREATE TABLE `application_config_file` (
  `tango_application_id` bigint(20) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  PRIMARY KEY  (`tango_application_id`,`file_name`),
  KEY `FK7AA7CFEAAE50F516` (`tango_application_id`),
  CONSTRAINT `FK7AA7CFEAAE50F516` FOREIGN KEY (`tango_application_id`) REFERENCES `tango_application` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Definition of table `tango_application`
--

DROP TABLE IF EXISTS `tango_application`;
CREATE TABLE `tango_application` (
  `id` bigint(20) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Definition of table `application_se_process`
--

DROP TABLE IF EXISTS `application_se_process`;
CREATE TABLE `application_se_process` (
  `tango_application_id` bigint(20) NOT NULL,
  `se_process_address` varchar(100) NOT NULL,
  PRIMARY KEY  (`tango_application_id`,`se_process_address`),
  KEY `FKEB933FD1232361CD` (`tango_application_id`),
  CONSTRAINT `FKEB933FD1232361CD` FOREIGN KEY (`tango_application_id`) REFERENCES `tango_application` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Definition of table `tango_application_host`
--

DROP TABLE IF EXISTS `tango_application_host`;
CREATE TABLE `tango_application_host` (
  `tango_application_id` bigint(20) NOT NULL,
  `tango_host_id` bigint(20) NOT NULL,
  PRIMARY KEY  (`tango_application_id`,`tango_host_id`),
  KEY `FK2BF5F06DF3BB7ADE` (`tango_host_id`),
  KEY `FK2BF5F06DAE50F516` (`tango_application_id`),
  CONSTRAINT `FK2BF5F06DAE50F516` FOREIGN KEY (`tango_application_id`) REFERENCES `tango_application` (`id`),
  CONSTRAINT `FK2BF5F06DF3BB7ADE` FOREIGN KEY (`tango_host_id`) REFERENCES `tango_host` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Table structure for table `tango_http_endpoint`
--

DROP TABLE IF EXISTS `tango_http_endpoint`;
CREATE TABLE `tango_http_endpoint` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `url` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;



--
-- Definition of table `tango_host`
--

DROP TABLE IF EXISTS `tango_host`;
CREATE TABLE `tango_host` (
  `id` bigint(20) NOT NULL auto_increment,
  `host_name` varchar(80) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `host_name` (`host_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `menu_item`;

CREATE TABLE menu_item (
id BIGINT not null,
parent_name VARCHAR(30),
name VARCHAR(30),
title VARCHAR(255),
description VARCHAR(50),
location VARCHAR(255),
target VARCHAR(10),
onclick VARCHAR(100),
onmouseover VARCHAR(100),
onmouseout VARCHAR(100),
image VARCHAR(50),
altImage VARCHAR(30),
tooltip VARCHAR(100),
roles VARCHAR(100),
page VARCHAR(255),
width VARCHAR(5),
height VARCHAR(5),
forward VARCHAR(50),
action VARCHAR(50),
primary key (id)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;

--
-- Definition of table scripts_run
--

DROP TABLE IF EXISTS `scripts_run`;
CREATE TABLE `scripts_run` (
	`id` BIGINT(20) NOT NULL AUTO_INCREMENT,
	`script_name` VARCHAR(100) NULL DEFAULT NULL,
	`date_updated` DATETIME NULL DEFAULT NULL,
	PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Insert into scripts_run
--

INSERT INTO `scripts_run` (`script_name`, `date_updated`) VALUES ('pms_base_schema.sql', now());

-- End of script.
