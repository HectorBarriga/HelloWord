/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Script to build tables for pmcs

CREATE DATABASE IF NOT EXISTS `pmcsdb` DEFAULT CHARACTER SET utf8;
USE pmcsdb;

GRANT ALL PRIVILEGES ON pmcsdb.* TO 'pmcsjdbc'@'%' IDENTIFIED BY 'pmcss3cret';


--
-- Table structure for table `config_set`
--

DROP TABLE IF EXISTS `config_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config_set` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime DEFAULT NULL,
  `updated_time` datetime DEFAULT NULL,
  `currently_active` tinyint(1) DEFAULT NULL,
  `data_token` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `number_of_clones` int(11) DEFAULT NULL,
  `number_of_deployments` int(11) DEFAULT NULL,
  `service` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `tango_application_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_cobt30y0mcwolsv89rekosvkd` (`tango_application_id`),
  CONSTRAINT `FK_cobt30y0mcwolsv89rekosvkd` FOREIGN KEY (`tango_application_id`) REFERENCES `tango_application` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=870 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Create table `alarm_level`
--
DROP TABLE IF EXISTS `alarm_level`;
CREATE TABLE `alarm_level` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime NOT NULL,
  `updated_time` datetime NOT NULL,
  `level_code` INT(11) NOT NULL,
  `description` VARCHAR(1024) NULL DEFAULT NULL,
  `level_name` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `level_name` (`level_name`)
)
  COLLATE='utf8_general_ci'
  ENGINE=InnoDB
  AUTO_INCREMENT=4;
--
-- Dumping data for table `alarm_level`
--

LOCK TABLES `alarm_level` WRITE;
/*!40000 ALTER TABLE `alarm_level` DISABLE KEYS */;
INSERT INTO `alarm_level` VALUES (1,'2010-05-10 00:00:00','2010-05-10 00:00:00',0,'Critical Alarm','CRITICAL'),(2,'2010-05-10 00:00:00','2010-05-10 00:00:00',1,'Major Alarm','MAJOR'),(3,'2010-05-10 00:00:00','2010-05-10 00:00:00',2,'Minor Alarm','MINOR'),(4,'2010-05-10 00:00:00','2010-05-10 00:00:00',3,'Default Alarm','DEFAULT');
/*!40000 ALTER TABLE `alarm_level` ENABLE KEYS */;
UNLOCK TABLES;


--
-- Create table `alarm_type`
--
DROP TABLE IF EXISTS `alarm_type`;
CREATE TABLE `alarm_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime NOT NULL,
  `updated_time` datetime NOT NULL,
  `description` VARCHAR(1024) NULL DEFAULT NULL,
  `type_name` VARCHAR(100) NOT NULL,
  `alarm_level_id` BIGINT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `type_name` (`type_name`),
  INDEX `FKC6FC9868372FE29E` (`alarm_level_id`),
  CONSTRAINT `FKC6FC9868372FE29E` FOREIGN KEY (`alarm_level_id`) REFERENCES `alarm_level` (`id`)
)
  COLLATE='utf8_general_ci'
  ENGINE=InnoDB
  AUTO_INCREMENT=9;

LOCK TABLES `alarm_type` WRITE;
/*!40000 ALTER TABLE `alarm_type` DISABLE KEYS */;
INSERT INTO `alarm_type` VALUES (1,'2010-05-10 00:00:00','2010-05-10 00:00:00','Information alarm 1','INFO_ALARM_1',3),(2,'2010-05-10 00:00:00','2010-05-10 00:00:00','Information alarm 2','INFO_ALARM_2',3),(3,'2010-05-10 00:00:00','2010-05-10 00:00:00','Debug alarm 1','DEBUG_ALARM_1',3),(4,'2010-05-10 00:00:00','2010-05-10 00:00:00','Debug alarm 2','DEBUG_ALARM_2',3),(5,'2010-05-10 00:00:00','2010-05-10 00:00:00','Warning alarm 1','WARN_ALARM_1',2),(6,'2010-05-10 00:00:00','2010-05-10 00:00:00','Warning alarm 2','WARN_ALARM_2',2),(7,'2010-05-10 00:00:00','2010-05-10 00:00:00','Fatal error alarm 1','FATAL_ALARM_1',1),(8,'2010-05-10 00:00:00','2010-05-10 00:00:00','Fatal error alarm 2','FATAL_ALARM_2',1),(15,'2015-02-06 11:26:53','2015-02-06 11:26:53','New alarm type added on Fri Feb 06 11:26:53 WET 2015','PM_FAILED_PROCESS',1);
/*!40000 ALTER TABLE `alarm_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Create table `se_address`
--
DROP TABLE IF EXISTS `se_address`;
CREATE TABLE `se_address` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime NOT NULL,
  `updated_time` datetime NOT NULL,
  `application` VARCHAR(100) NULL DEFAULT NULL,
  `cluster` VARCHAR(50) NULL DEFAULT NULL,
  `node` VARCHAR(50) NULL DEFAULT NULL,
  `service` VARCHAR(100) NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
)
  COLLATE='utf8_general_ci'
  ENGINE=InnoDB
  AUTO_INCREMENT=10;

--
-- Create table `alarm_log`
--
DROP TABLE IF EXISTS `alarm_log`;
CREATE TABLE `alarm_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime NOT NULL,
  `updated_time` datetime NOT NULL,
  `acknowledged` BIT(1) NOT NULL,
  `acknowledged_by` VARCHAR(255) NULL DEFAULT NULL,
  `active` BIT(1) NOT NULL,
  `description` VARCHAR(1024) NULL DEFAULT NULL,
  `instance` BIGINT(20) NOT NULL,
  `time_acknowledged` BIGINT(20) NULL DEFAULT NULL,
  `timezone_acknowledged` VARCHAR(255) NULL DEFAULT NULL,
  `time_activated` BIGINT(20) NOT NULL,
  `timezone_activated` VARCHAR(255) NOT NULL,
  `time_cleared` BIGINT(20) NULL DEFAULT NULL,
  `timezone_cleared` VARCHAR(255) NULL DEFAULT NULL,
  `time_refreshed` BIGINT(20) NULL DEFAULT NULL,
  `timezone_refreshed` VARCHAR(255) NULL DEFAULT NULL,
  `alarm_source_id` BIGINT(20) NULL DEFAULT NULL,
  `alarm_type_id` BIGINT(20) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `FKD4DEBC56D1895763` (`alarm_source_id`),
  INDEX `FKD4DEBC56C287A396` (`alarm_type_id`),
  CONSTRAINT `FKD4DEBC56C287A396` FOREIGN KEY (`alarm_type_id`) REFERENCES `alarm_type` (`id`),
  CONSTRAINT `FKD4DEBC56D1895763` FOREIGN KEY (`alarm_source_id`) REFERENCES `se_address` (`id`)
)
  COLLATE='utf8_general_ci'
  ENGINE=InnoDB
  AUTO_INCREMENT=9;

--
-- Create table `event_level`
--
DROP TABLE IF EXISTS `event_level`;
CREATE TABLE `event_level` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime NOT NULL,
  `updated_time` datetime NOT NULL,
  `level_code` INT(11) NOT NULL,
  `description` VARCHAR(200) NULL DEFAULT NULL,
  `level_name` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `level_name` (`level_name`)
)
  COLLATE='utf8_general_ci'
  ENGINE=InnoDB
  AUTO_INCREMENT=4;

--
-- Dumping data for table `event_level`
--

LOCK TABLES `event_level` WRITE;
/*!40000 ALTER TABLE `event_level` DISABLE KEYS */;
INSERT INTO `event_level` VALUES (1,'2010-05-10 00:00:00','2010-05-10 00:00:00',0,'Critical Event','CRITICAL'),(2,'2010-05-10 00:00:00','2010-05-10 00:00:00',1,'Major Event','MAJOR'),(3,'2010-05-10 00:00:00','2010-05-10 00:00:00',2,'Minor Event','MINOR'),(4,'2010-05-10 00:00:00','2010-05-10 00:00:00',3,'Default Event','DEFAULT');
/*!40000 ALTER TABLE `event_level` ENABLE KEYS */;
UNLOCK TABLES;


--
-- Create table `event_type`
--
DROP TABLE IF EXISTS `event_type`;
CREATE TABLE `event_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime NOT NULL,
  `updated_time` datetime NOT NULL,
  `description` VARCHAR(200) NULL DEFAULT NULL,
  `type_name` VARCHAR(50) NOT NULL,
  `event_level_id` BIGINT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `type_name` (`type_name`),
  INDEX `FK3AAC65BF5C967CA3` (`event_level_id`),
  CONSTRAINT `FK3AAC65BF5C967CA3` FOREIGN KEY (`event_level_id`) REFERENCES `event_level` (`id`)
)
  COLLATE='utf8_general_ci'
  ENGINE=InnoDB
  AUTO_INCREMENT=7;

LOCK TABLES `event_type` WRITE;
/*!40000 ALTER TABLE `event_type` DISABLE KEYS */;
INSERT INTO `event_type` VALUES (1,'2010-05-10 00:00:00','2010-05-10 00:00:00','Critical event 1','CRITICAL_TYPE_1',1),(2,'2010-05-10 00:00:00','2010-05-10 00:00:00','Critical event 2','CRITICAL_TYPE_2',1),(3,'2010-05-10 00:00:00','2010-05-10 00:00:00','Major event 1','MAJOR_TYPE_1',2),(4,'2010-05-10 00:00:00','2010-05-10 00:00:00','Major event 2','MAJOR_TYPE_2',2),(5,'2010-05-10 00:00:00','2010-05-10 00:00:00','Minor event 1','MINOR_TYPE_1',3),(6,'2010-05-10 00:00:00','2010-05-10 00:00:00','Minor event 2','MINOR_TYPE_2',3);
/*!40000 ALTER TABLE `event_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Create table `event_log`
--
DROP TABLE IF EXISTS `event_log`;
CREATE TABLE `event_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime NOT NULL,
  `updated_time` datetime NOT NULL,
  `description` VARCHAR(1024) NULL DEFAULT NULL,
  `time_logged` BIGINT(20) NOT NULL,
  `timezone_logged` VARCHAR(255) NOT NULL,
  `event_source_id` BIGINT(20) NULL DEFAULT NULL,
  `event_type_id` BIGINT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `FK1E4681F1E9334F1` (`event_type_id`),
  INDEX `FK1E4681FB927486C` (`event_source_id`),
  CONSTRAINT `FK1E4681F1E9334F1` FOREIGN KEY (`event_type_id`) REFERENCES `event_type` (`id`),
  CONSTRAINT `FK1E4681FB927486C` FOREIGN KEY (`event_source_id`) REFERENCES `se_address` (`id`)
)
  COLLATE='utf8_general_ci'
  ENGINE=InnoDB
  AUTO_INCREMENT=15;


--
-- Create table `system_status`
--
DROP TABLE IF EXISTS `system_status`;
CREATE TABLE `system_status` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `updated_time` datetime,
  `alarm_status` BIGINT(20) NULL DEFAULT NULL,
  `alarm_status_str` VARCHAR(80) NULL DEFAULT NULL,
  `cpu_idle` BIGINT(20) NULL DEFAULT NULL,
  `cpu_sys` BIGINT(20) NULL DEFAULT NULL,
  `cpu_user` BIGINT(20) NULL DEFAULT NULL,
  `host_name` VARCHAR(80) NOT NULL,
  `up_time` VARCHAR(150) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `host_name` (`host_name`)
)
  COLLATE='utf8_general_ci'
  ENGINE=InnoDB;

--
-- Create table `system_status_client`
--
DROP TABLE IF EXISTS `system_status_client`;
CREATE TABLE `system_status_client` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `host_name` VARCHAR(80) NOT NULL,
  `port` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `host_name` (`host_name`)
)
  COLLATE='utf8_general_ci'
  ENGINE=InnoDB
  AUTO_INCREMENT=5;
  
--
-- Table structure for table `throttle_configuration`
--

DROP TABLE IF EXISTS `throttle_configuration`;
CREATE TABLE `throttle_configuration` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime DEFAULT NULL,
  `updated_time` datetime DEFAULT NULL,
  `contents` longtext NOT NULL,
  `data_token` varchar(255) NOT NULL,
  `entity_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1;

-- Table structure for table `throttle_point`
--
DROP TABLE IF EXISTS `throttle_point`;
CREATE TABLE `throttle_point` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime DEFAULT NULL,
  `updated_time` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `entity_name` varchar(1024) NOT NULL,
  `point_identifier` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1;

-- Table structure for table `throttle_rule`
--

DROP TABLE IF EXISTS `throttle_rule`;
CREATE TABLE `throttle_rule` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime DEFAULT NULL,
  `updated_time` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL,
  `entity_name` varchar(1024) NOT NULL,
  `throttle_point_tag` varchar(255) NOT NULL,
  `throttle_point_oid` bigint(20) NOT NULL,
  `throttling_profile_oid` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_jcir4g90yoalf8j3xrm1k6gbh` (`throttle_point_oid`),
  KEY `FK_d29ne7y6uwy1k4ud1yvi85kc2` (`throttling_profile_oid`),
  CONSTRAINT `FK_d29ne7y6uwy1k4ud1yvi85kc2` FOREIGN KEY (`throttling_profile_oid`) REFERENCES `throttling_profile` (`id`),
  CONSTRAINT `FK_jcir4g90yoalf8j3xrm1k6gbh` FOREIGN KEY (`throttle_point_oid`) REFERENCES `throttle_point` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1;


-- Table structure for table `throttling_profile`
--

DROP TABLE IF EXISTS `throttling_profile`;
CREATE TABLE `throttling_profile` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime DEFAULT NULL,
  `updated_time` datetime DEFAULT NULL,
  `active_dialogue_control_enabled` tinyint(1) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `dialogue_control_alarm_id` bigint(20) DEFAULT NULL,
  `dialogue_control_alarm_name` varchar(255) DEFAULT NULL,
  `dialogue_control_throttle_lower_threshold` bigint(20) DEFAULT NULL,
  `dialogue_control_throttle_upper_threshold` bigint(20) DEFAULT NULL,
  `entity_name` varchar(1024) NOT NULL,
  `rate_control_alarm_id` bigint(20) DEFAULT NULL,
  `rate_control_alarm_name` varchar(255) DEFAULT NULL,
  `rate_control_enabled` tinyint(1) NOT NULL,
  `rate_control_threshold_per_second` bigint(20) DEFAULT NULL,
  `resourse_based_scaling_enabled` tinyint(1) NOT NULL,
  `statistics_enabled` tinyint(1) NOT NULL,
  `throttle_action` int(11) NOT NULL,
  `throttle_limiting_on_threshold` bigint(20) DEFAULT NULL,
  `throttle_measurement_window_length` bigint(20) DEFAULT NULL,
  `throttle_period` bigint(20) DEFAULT NULL,
  `throttle_string` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1;

--
-- Table structure for table `config_upload`
--

DROP TABLE IF EXISTS `config_upload`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config_upload` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime DEFAULT NULL,
  `updated_time` datetime DEFAULT NULL,
  `configuration_set_id` bigint(20) DEFAULT NULL,
  `configuration_upload_id` bigint(20) DEFAULT NULL,
  `tango_process_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_anwwvigchxsv6ngbfwg0k4gvf` (`configuration_set_id`),
  KEY `FK_a1ea41r603k59xqywqblt6irt` (`configuration_upload_id`),
  KEY `FK_9a4qyegvk0eje6bturtqatfw6` (`tango_process_id`),
  CONSTRAINT `FK_9a4qyegvk0eje6bturtqatfw6` FOREIGN KEY (`tango_process_id`) REFERENCES `tango_process` (`id`),
  CONSTRAINT `FK_a1ea41r603k59xqywqblt6irt` FOREIGN KEY (`configuration_upload_id`) REFERENCES `configuration_upload` (`id`),
  CONSTRAINT `FK_anwwvigchxsv6ngbfwg0k4gvf` FOREIGN KEY (`configuration_set_id`) REFERENCES `config_set` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_upload`
--

--
-- Table structure for table `configuration_file_deployment_settings`
--

DROP TABLE IF EXISTS `configuration_file_deployment_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configuration_file_deployment_settings` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime DEFAULT NULL,
  `updated_time` datetime DEFAULT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `reload_application` varchar(255) NOT NULL,
  `tango_application_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_ip8bxqw9xn9l4e3grk23ty2s1` (`tango_application_id`),
  CONSTRAINT `FK_ip8bxqw9xn9l4e3grk23ty2s1` FOREIGN KEY (`tango_application_id`) REFERENCES `tango_application` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuration_file_deployment_settings`
--

LOCK TABLES `configuration_file_deployment_settings` WRITE;
/*!40000 ALTER TABLE `configuration_file_deployment_settings` DISABLE KEYS */;
INSERT INTO `configuration_file_deployment_settings` VALUES (1,'2010-05-10 00:00:00','2010-05-10 00:00:00','SAS_profiles.cfg','/tango/config/SAS_profiles/','SAS_profiles',1),(2,'2010-05-10 00:00:00','2010-05-10 00:00:00','SAS_rateMonitor.cfg','/tango/config/SAS_rateMonitor/','SAS_rateMonitor',1),(3,'2010-05-10 00:00:00','2010-05-10 00:00:00','SAS_moRules.cfg','/tango/config/SAS_moRules/','SAS_moRules',1),(4,'2010-05-10 00:00:00','2010-05-10 00:00:00','SAS_screening.cfg','/tango/config/SAS_screening/','SAS_screening',1),(5,'2010-05-10 00:00:00','2010-05-10 00:00:00','SAS_moAnalysisSequence.cfg','/tango/config/SAS_moAnalysisSequence/','SAS_moAnalysisSequence',1),(6,'2010-05-10 00:00:00','2010-05-10 00:00:00','SAS_scanContent.cfg','/tango/config/SAS_scanContent/','SAS_scanContent',1),(7,'2010-05-10 00:00:00','2010-05-10 00:00:00','SAS_digitDiff.cfg','/tango/config/SAS_digitDiff/','SAS_digitDiff',1),(8,'2010-05-10 00:00:00','2010-05-10 00:00:00','SAS_lengthChecksum.cfg','/tango/config/SAS_lengthChecksum/','SAS_lengthChecksum',1),(9,'2010-05-10 00:00:00','2010-05-10 00:00:00','SAS_smsVirus.cfg','/tango/config/SAS_smsVirus/','SAS_smsVirus',1),(10,'2010-05-10 00:00:00','2010-05-10 00:00:00','THROTTLE_rules.cfg','/tango/config/THROTTLE/','THROTTLE',2),(11,'2010-05-10 00:00:00','2010-05-10 00:00:00','M2P_blackoutProfiles.cfg','/tango/config/M2P_classify/','M2P_Classify',3),(12,'2010-05-10 00:00:00','2010-05-10 00:00:00','M2P_throttlingProfiles.cfg','/tango/config/M2P_classify/','M2P_Classify',3),(13,'2010-05-10 00:00:00','2010-05-10 00:00:00','M2P_screeningProfiles.cfg','/tango/config/M2P_classify/','M2P_Classify',3),(14,'2010-05-10 00:00:00','2010-05-10 00:00:00','M2P_listManager.cfg','/tango/config/M2P_classify/','M2P_Classify',3),(15,'2010-05-10 00:00:00','2010-05-10 00:00:00','M2P_scanContentAntispamProfiles.cfg','/tango/config/M2P_classify/','M2P_Classify',3);
/*!40000 ALTER TABLE `configuration_file_deployment_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuration_upload_result`
--

DROP TABLE IF EXISTS `configuration_upload_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configuration_upload_result` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime DEFAULT NULL,
  `updated_time` datetime DEFAULT NULL,
  `upload_result` varchar(255) DEFAULT NULL,
  `entry` varchar(255) DEFAULT NULL,
  `tango_process_id` bigint(20) NOT NULL,
  `configuration_upload_id` bigint(20) DEFAULT NULL,
  `configuration_upload_result_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_nx49yyynbbnnifsgn9p7dch84` (`tango_process_id`),
  KEY `FK_7gumqngysn10mc35wkji17uhp` (`configuration_upload_id`),
  CONSTRAINT `FK_7gumqngysn10mc35wkji17uhp` FOREIGN KEY (`configuration_upload_id`) REFERENCES `config_upload` (`id`),
  CONSTRAINT `FK_nx49yyynbbnnifsgn9p7dch84` FOREIGN KEY (`tango_process_id`) REFERENCES `tango_process` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=217 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tango_application`
--

DROP TABLE IF EXISTS `tango_application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tango_application` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime DEFAULT NULL,
  `updated_time` datetime DEFAULT NULL,
  `config_file_provider_path` varchar(255) NOT NULL,
  `config_file_provider_resource_name` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `config_file_generator_path` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tango_application`
--

LOCK TABLES `tango_application` WRITE;
/*!40000 ALTER TABLE `tango_application` DISABLE KEYS */;
INSERT INTO `tango_application` VALUES (1,'2010-05-10 00:00:00','2010-05-10 00:00:00','http://{host}:{port}/configurationFileSets/{dataToken}/contents','SMSWS_RES','P2P','http://{host}:{port}/configurationFileSets/create/p2p/{dataToken}/{name}'),(2,'2010-05-10 00:00:00','2010-05-10 00:00:00','http://{host}:{port}/pmcs/common/throttlingConfigurations/{dataToken}/contents','pmcs','THROTTLE','http://{host}:{port}/pmcs/common/throttlingConfigurations/create/{dataToken}/{name}'),(3,'2010-05-10 00:00:00','2010-05-10 00:00:00','http://{host}:{port}/configurationFileSets/{dataToken}/contents','SMSWS_RES','A2P','http://{host}:{port}/configurationFileSets/create/a2p/{dataToken}/{name}');
/*!40000 ALTER TABLE `tango_application` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tango_process`
--

DROP TABLE IF EXISTS `tango_process`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tango_process` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime DEFAULT NULL,
  `updated_time` datetime DEFAULT NULL,
  `host` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `port` int(11) DEFAULT NULL,
  `resource_name` varchar(255) DEFAULT NULL,
  `se_address` varchar(255) DEFAULT NULL,
  `tangoProcessState` varchar(255) DEFAULT NULL,
  `tangoProcessType` varchar(255) DEFAULT NULL,
  `tango_process_group_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_6wehxofhfshb9yrf8qxwf4ury` (`tango_process_group_id`),
  CONSTRAINT `FK_6wehxofhfshb9yrf8qxwf4ury` FOREIGN KEY (`tango_process_group_id`) REFERENCES `tango_process_group` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tango_process_group`
--

DROP TABLE IF EXISTS `tango_process_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tango_process_group` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime DEFAULT NULL,
  `updated_time` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `tango_application_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_8vwhr24qlwcg9mihxyxuoh879` (`name`),
  KEY `FK_ag55xnaeairjnr0ev5y5ce6jy` (`tango_application_id`),
  CONSTRAINT `FK_ag55xnaeairjnr0ev5y5ce6jy` FOREIGN KEY (`tango_application_id`) REFERENCES `tango_application` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;


/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;

