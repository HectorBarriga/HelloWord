CREATE DATABASE IF NOT EXISTS `smpp` DEFAULT CHARACTER SET utf8;
USE `smpp`;

DROP TABLE IF EXISTS `smsc`;
CREATE TABLE `smsc` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime DEFAULT NULL,
  `updated_time` datetime DEFAULT NULL,
  `address_range` varchar(255) DEFAULT NULL,
  `conn_accepts_system_error` bit(1) DEFAULT NULL,
  `conn_restart_throttle_ms` int(11) DEFAULT NULL,
  `esm_class` tinyint(4) DEFAULT NULL,
  `keepalive_period_ms` int(11) DEFAULT NULL,
  `keepalive_timeout_ms` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `max_msg_rate_per_sc` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `system_type` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `smpp_link`;
CREATE TABLE `smpp_link` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime DEFAULT NULL,
  `updated_time` datetime DEFAULT NULL,
  `bind_time` datetime DEFAULT NULL,
  `curr_retry_count` int(11) NOT NULL,
  `host` varchar(255) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `link_id` int(11) NOT NULL,
  `link_type` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `operator_blocked` bit(1) NOT NULL,
  `operator_reset` bit(1) NOT NULL,
  `password` varchar(45) NOT NULL,
  `port` int(11) NOT NULL,
  `rx_traffic_last_period` int(11) NOT NULL,
  `system_id` varchar(45) NOT NULL,
  `traffic_collect_period_mins` int(11) NOT NULL,
  `tx_traffic_last_period` int(11) NOT NULL,
  `smsc_oid` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKBEE4133F6C251747` (`smsc_oid`),
  CONSTRAINT `FKBEE4133F6C251747` FOREIGN KEY (`smsc_oid`) REFERENCES `smsc` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `smsc_err_map`;
CREATE TABLE `smsc_err_map` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime DEFAULT NULL,
  `updated_time` datetime DEFAULT NULL,
  `code` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `value` varchar(255) NOT NULL,
  `smsc_oid` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK2202EE6D6C251747` (`smsc_oid`),
  CONSTRAINT `FK2202EE6D6C251747` FOREIGN KEY (`smsc_oid`) REFERENCES `smsc` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `message_rate`;
CREATE TABLE `message_rate` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime DEFAULT NULL,
  `updated_time` datetime DEFAULT NULL,
  `day` int(11) DEFAULT NULL,
  `end_minute` int(11) DEFAULT NULL,
  `rate` int(11) DEFAULT NULL,
  `start_minute` int(11) DEFAULT NULL,
  `smpp_link_oid` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKB356F218AEFA9CA6` (`smpp_link_oid`),
  CONSTRAINT `FKB356F218AEFA9CA6` FOREIGN KEY (`smpp_link_oid`) REFERENCES `smpp_link` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `smpp_submit_cdr`;
CREATE TABLE `smpp_submit_cdr` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `a_number` varchar(255) NOT NULL,
  `b_number` varchar(255) NOT NULL,
  `short_message` varchar(255) NOT NULL,
  `time_stamp` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

