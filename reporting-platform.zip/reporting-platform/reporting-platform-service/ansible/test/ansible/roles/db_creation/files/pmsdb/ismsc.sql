-- MySQL dump 10.13  Distrib 5.1.37, for debian-linux-gnu (i486)
--
-- Host: localhost    Database: pmidb
-- ------------------------------------------------------
-- Server version       5.1.37-1ubuntu5.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Table structure for table `mo_routing_list_config`
--

DROP TABLE IF EXISTS `mo_routing_list_config`;


CREATE TABLE `mo_routing_list_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `match_rule` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


--
-- Dumping data for table `mo_routing_list_config`
--

/*!40000 ALTER TABLE `mo_routing_list_config` DISABLE KEYS */;
INSERT INTO `mo_routing_list_config`(`id`) VALUES (1);
/*!40000 ALTER TABLE `mo_routing_list_config` ENABLE KEYS */;

--
-- Table structure for table `generic_prefix_list`
--

DROP TABLE IF EXISTS `generic_prefix_list`;

    CREATE TABLE `generic_prefix_list` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `list_type` varchar(60) DEFAULT NULL,
  `prefix_list_tag` varchar(255) DEFAULT NULL,
  `prefix_list_tag2` varchar(255) DEFAULT NULL,
  `name` varchar(60) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;


--
-- Dumping data for table `generic_prefix_list`
--


--
-- Table structure for table `mo_routing_table`
--

DROP TABLE IF EXISTS `mo_routing_table`;

CREATE TABLE `mo_routing_table` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `default_phone_delivery` int(11) NOT NULL,
  `default_short_code` int(11) NOT NULL,
  `use_dest_address` tinyint(1) NOT NULL DEFAULT '0',
  `prefix_list_id` bigint(20) DEFAULT NULL,
  `routing_list_config_id` bigint(20) DEFAULT NULL,
  `routing_table_type` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK80DA2F38354A473C` (`routing_list_config_id`),
  KEY `FK80DA2F382578B19E` (`prefix_list_id`),
  CONSTRAINT `FK80DA2F382578B19E` FOREIGN KEY (`prefix_list_id`) REFERENCES `generic_prefix_list` (`id`),
  CONSTRAINT `FK80DA2F38354A473C` FOREIGN KEY (`routing_list_config_id`) REFERENCES `mo_routing_list_config` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;


--
-- Dumping data for table `mo_routing_table`
--




--
-- Table structure for table `strip_replace_config`
--

DROP TABLE IF EXISTS `strip_replace_config`;

CREATE TABLE `strip_replace_config` (
  `CONFIG_TYPE` varchar(31) NOT NULL,
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ao_strict_validation_mode` bit(1) NOT NULL,
  `ao_strip_replace_enabled` bit(1) NOT NULL,
  `mo_strict_validation_mode` bit(1) NOT NULL,
  `mo_strip_replace_enabled` bit(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;


--
-- Dumping data for table `strip_replace_config`
--

/*!40000 ALTER TABLE `strip_replace_config` DISABLE KEYS */;
INSERT INTO `strip_replace_config` (`CONFIG_TYPE`, `id`, `ao_strict_validation_mode`, `ao_strip_replace_enabled`, `mo_strict_validation_mode`, `mo_strip_replace_enabled`) VALUES ('A',1,'\0','\0','\0','\0'),('B',2,'\0','\0','\0','\0'),('AppHoA',3,'\0','\0','\0','\0'),('AppHoB',4,'\0','\0','\0','\0'),('CALLED',5,'\0','\0','\0','\0'),('CALLING',6,'\0','\0','\0','\0'),('MT_INTERFACE_CALLING_NA',7,'\0','\0','\0','\0');
/*!40000 ALTER TABLE `strip_replace_config` ENABLE KEYS */;




--
-- Table structure for table `strip_and_replace`
--

DROP TABLE IF EXISTS `strip_and_replace`;

CREATE TABLE `strip_and_replace` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `enabled` bit(1) NOT NULL,
  `max_digits` int(11) DEFAULT NULL,
  `min_digits` int(11) DEFAULT NULL,
  `replace_string` varchar(255) DEFAULT NULL,
  `strip` varchar(255) DEFAULT NULL,
  `strip_replace_config_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK691189A518004E25` (`strip_replace_config_id`),
  CONSTRAINT `FK691189A518004E25` FOREIGN KEY (`strip_replace_config_id`) REFERENCES `strip_replace_config` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


--
-- Dumping data for table `strip_and_replace`
--


--
-- Table structure for table `anti_spoofing_config`
--

DROP TABLE IF EXISTS `anti_spoofing_config`;
CREATE TABLE `anti_spoofing_config` (
  `id` bigint(20) NOT NULL auto_increment,
  `description` varchar(254) default NULL,
  `black_list_enabled` bit(1) default NULL,
  `msc_black_list_enabled` bit(1) default NULL,
  `white_list_enabled` bit(1) default NULL,
  `enabled` bit(1) default NULL,
  `minimum_a_number_digits` int(11) default NULL,
  `number_of_digits` int(11) default NULL,
  `positive_response_enabled` bit(1) default NULL,
  `blacklist_prefix_list_oid` bigint(20) default NULL,
  `msc_blacklist_prefix_list_oid` bigint(20) default NULL,
  `whitelist_prefix_list_oid` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK46CE6B2B65BD6C83` (`blacklist_prefix_list_oid`),
  KEY `FK46CE6B2B4A75A41` (`msc_blacklist_prefix_list_oid`),
  KEY `FK46CE6B2B4285EFAD` (`whitelist_prefix_list_oid`),
  CONSTRAINT `FK46CE6B2B4285EFAD` FOREIGN KEY (`whitelist_prefix_list_oid`) REFERENCES `generic_prefix_list` (`id`),
  CONSTRAINT `FK46CE6B2B4A75A41` FOREIGN KEY (`msc_blacklist_prefix_list_oid`) REFERENCES `generic_prefix_list` (`id`),
  CONSTRAINT `FK46CE6B2B65BD6C83` FOREIGN KEY (`blacklist_prefix_list_oid`) REFERENCES `generic_prefix_list` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `anti_spoofing_config`
--

LOCK TABLES `anti_spoofing_config` WRITE;
/*!40000 ALTER TABLE `anti_spoofing_config` DISABLE KEYS */;
INSERT INTO `anti_spoofing_config` VALUES (1,NULL,'\0','\0','\0','\0',3,9,'\0',NULL,NULL,NULL);
/*!40000 ALTER TABLE `anti_spoofing_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `a_number_analysis_config`
--

DROP TABLE IF EXISTS `a_number_analysis_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `a_number_analysis_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blacklist_prefix_list_id` bigint(20) DEFAULT NULL,
   `charging_overide_prefix_list_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKBDD91EADC1FFF900` (`blacklist_prefix_list_id`),
  CONSTRAINT `FKBDD91EADC1FFF900` FOREIGN KEY (`blacklist_prefix_list_id`) REFERENCES `generic_prefix_list` (`id`),
   CONSTRAINT `FKBDD91EADC1FFF901` FOREIGN KEY (`charging_overide_prefix_list_id`) REFERENCES `generic_prefix_list` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


--
-- Dumping data for table `a_number_analysis_config`
--

/*!40000 ALTER TABLE `a_number_analysis_config` DISABLE KEYS */;
INSERT INTO `a_number_analysis_config`(`id`) VALUES (1);
/*!40000 ALTER TABLE `a_number_analysis_config` ENABLE KEYS */;

--
-- Table structure for table `aNumberAnalysis_to_prefix_map`
--

DROP TABLE IF EXISTS `aNumberAnalysis_to_prefix_map`;

CREATE TABLE `aNumberAnalysis_to_prefix_map` (
  `whitelist_prefixlist_id` bigint(20) NOT NULL,
  `prefix_list_id` bigint(20) NOT NULL,
  UNIQUE KEY `prefix_list_id` (`prefix_list_id`),
  KEY `FK60F861FAAD4C88C2` (`whitelist_prefixlist_id`),
  KEY `FK60F861FA2578B19E` (`prefix_list_id`),
  CONSTRAINT `FK60F861FA2578B19E` FOREIGN KEY (`prefix_list_id`) REFERENCES `generic_prefix_list` (`id`),
  CONSTRAINT `FK60F861FAAD4C88C2` FOREIGN KEY (`whitelist_prefixlist_id`) REFERENCES `a_number_analysis_config` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Dumping data for table `aNumberAnalysis_to_prefix_map`
--



--
-- Table structure for table `b_number_analysis_config`
--

DROP TABLE IF EXISTS `b_number_analysis_config`;

CREATE TABLE `b_number_analysis_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blacklist_prefix_list_id` bigint(20) DEFAULT NULL,
  `whitelist_prefix_list_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKB9DAAD8CE1E56896` (`whitelist_prefix_list_id`),
  KEY `FKB9DAAD8CC1FFF900` (`blacklist_prefix_list_id`),
  CONSTRAINT `FKB9DAAD8CC1FFF900` FOREIGN KEY (`blacklist_prefix_list_id`) REFERENCES `generic_prefix_list` (`id`),
  CONSTRAINT `FKB9DAAD8CE1E56896` FOREIGN KEY (`whitelist_prefix_list_id`) REFERENCES `generic_prefix_list` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `b_number_analysis_config`
--

/*!40000 ALTER TABLE `b_number_analysis_config` DISABLE KEYS */;
INSERT INTO `b_number_analysis_config`(`id`) VALUES (1);
/*!40000 ALTER TABLE `b_number_analysis_config` ENABLE KEYS */;



--
-- Table structure for table `prepaid_list_config`
--

DROP TABLE IF EXISTS `prepaid_list_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prepaid_list_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `prepaidSubscribers_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKBC9D7DB3CEAA846D` (`prepaidSubscribers_id`),
  CONSTRAINT `FKBC9D7DB3CEAA846D` FOREIGN KEY (`prepaidSubscribers_id`) REFERENCES `generic_prefix_list` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--

/*!40000 ALTER TABLE `prepaid_list_config` DISABLE KEYS */;
INSERT INTO `prepaid_list_config` VALUES (1,NULL);
/*!40000 ALTER TABLE `prepaid_list_config` ENABLE KEYS */;



--
-- Table structure for table `cdr_number_analysis_config`
--

DROP TABLE IF EXISTS `cdr_number_analysis_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cdr_number_analysis_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `prefixList_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKD3DCD4DDDEA9AF79` (`prefixList_id`),
  CONSTRAINT `FKD3DCD4DDDEA9AF79` FOREIGN KEY (`prefixList_id`) REFERENCES `generic_prefix_list` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cdr_number_analysis_config`
--


/*!40000 ALTER TABLE `cdr_number_analysis_config` DISABLE KEYS */;
INSERT INTO `cdr_number_analysis_config`(`id`) VALUES (1);
/*!40000 ALTER TABLE `cdr_number_analysis_config` ENABLE KEYS */;



DROP TABLE IF EXISTS `iwf_whitelist_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `iwf_whitelist_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `hlr_reject` bit(1) DEFAULT NULL,
  `hlr_whitelist_active` bit(1) DEFAULT NULL,
  `mt_sms_reject` bit(1) DEFAULT NULL,
  `mt_sms_whitelist_active` bit(1) DEFAULT NULL,
  `whitelist_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKF92C8AA1F093EE02` (`whitelist_id`),
  CONSTRAINT `FKF92C8AA1F093EE02` FOREIGN KEY (`whitelist_id`) REFERENCES `generic_prefix_list` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iwf_whitelist_config`
--


/*!40000 ALTER TABLE `iwf_whitelist_config` DISABLE KEYS */;
INSERT INTO `iwf_whitelist_config` VALUES (1,'\0','\0','\0','\0',NULL);


--
-- Table structure for table `mt_antispam_config`
--

DROP TABLE IF EXISTS `mt_antispam_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mt_antispam_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `enabled` bit(1) NOT NULL,
  `sm_response_error` int(11) DEFAULT NULL,
  `sm_response_text` varchar(255) DEFAULT NULL,
  `srism_response_error` int(11) DEFAULT NULL,
  `srism_response_text` varchar(255) DEFAULT NULL,
  `gt_blacklist_id` bigint(20) DEFAULT NULL,
  `gt_whitelist_id` bigint(20) DEFAULT NULL,
  `msisdn_blacklist_id` bigint(20) DEFAULT NULL,
  `msisdn_whitelist_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKC53E55BE89ECC7B1` (`msisdn_blacklist_id`),
  KEY `FKC53E55BEE37C6847` (`msisdn_whitelist_id`),
  KEY `FKC53E55BEF2FA7414` (`gt_whitelist_id`),
  KEY `FKC53E55BE996AD37E` (`gt_blacklist_id`),
  CONSTRAINT `FKC53E55BE89ECC7B1` FOREIGN KEY (`msisdn_blacklist_id`) REFERENCES `generic_prefix_list` (`id`),
  CONSTRAINT `FKC53E55BE996AD37E` FOREIGN KEY (`gt_blacklist_id`) REFERENCES `generic_prefix_list` (`id`),
  CONSTRAINT `FKC53E55BEE37C6847` FOREIGN KEY (`msisdn_whitelist_id`) REFERENCES `generic_prefix_list` (`id`),
  CONSTRAINT `FKC53E55BEF2FA7414` FOREIGN KEY (`gt_whitelist_id`) REFERENCES `generic_prefix_list` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mt_antispam_config`
--


/*!40000 ALTER TABLE `mt_antispam_config` DISABLE KEYS */;
INSERT INTO `mt_antispam_config` VALUES (1,'\0',NULL,'',NULL,'',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `mt_antispam_config` ENABLE KEYS */;


--
-- Table structure for table `local_number_analysis_config`
--

DROP TABLE IF EXISTS `local_number_analysis_config`;

CREATE TABLE `local_number_analysis_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `leading_zero` bit(1) NOT NULL,
  `enabled` bit(1) NOT NULL,
  `int_prefix` bigint(20) DEFAULT NULL,
  `max_local_digits` bigint(20) DEFAULT NULL,
  `min_int_length` bigint(20) DEFAULT NULL,
  `prefix_list_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKD197F4632578B19E` (`prefix_list_id`),
  CONSTRAINT `FKD197F4632578B19E` FOREIGN KEY (`prefix_list_id`) REFERENCES `generic_prefix_list` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


--
-- Dumping data for table `local_number_analysis_config`
--

/*!40000 ALTER TABLE `local_number_analysis_config` DISABLE KEYS */;
INSERT INTO `local_number_analysis_config`(`id`,`leading_zero`,`enabled`) VALUES (1,'\0','\0');
/*!40000 ALTER TABLE `local_number_analysis_config` ENABLE KEYS */;


--
-- Table structure for table `mtif_olo_roaming_config`
--

DROP TABLE IF EXISTS `mtif_olo_roaming_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mtif_olo_roaming_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `intPrefix` varchar(255) DEFAULT NULL,
  `ololist_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKFD28EF06785FD9` (`ololist_id`),
  CONSTRAINT `FKFD28EF06785FD9` FOREIGN KEY (`ololist_id`) REFERENCES `generic_prefix_list` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mtif_olo_roaming_config`
--


/*!40000 ALTER TABLE `mtif_olo_roaming_config` DISABLE KEYS */;
INSERT INTO `mtif_olo_roaming_config` VALUES (1,'',NULL);
/*!40000 ALTER TABLE `mtif_olo_roaming_config` ENABLE KEYS */;



--
-- Table structure for table `generic_prefix_list_tag`
--

DROP TABLE IF EXISTS `generic_prefix_list_tag`;

CREATE TABLE `generic_prefix_list_tag` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `list_type` varchar(255) NOT NULL,
  `prefix` varchar(255) DEFAULT NULL,
  `length` int(11) DEFAULT NULL,
  `tag` varchar(30) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `generic_prefix_list_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKCEE7351E1BDA4D06` (`generic_prefix_list_id`),
  CONSTRAINT `FKCEE7351E1BDA4D06` FOREIGN KEY (`generic_prefix_list_id`) REFERENCES `generic_prefix_list` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `generic_prefix_list_tag`
--

--
-- Table structure for table `charge_config`
--

DROP TABLE IF EXISTS `charge_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charge_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `config_heading_hame` varchar(255) DEFAULT NULL,
  `match_rule` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charge_config`
--

--
-- Table structure for table `prepaid_platform`
--

DROP TABLE IF EXISTS `prepaid_platform`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prepaid_platform` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `gateway_resource_policy` varchar(255) DEFAULT NULL,
  `service_name` varchar(255) DEFAULT NULL,
  `charge_config_id` bigint(20) DEFAULT NULL,
  `prefix_list_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK7498AC32578B19E` (`prefix_list_id`),
  KEY `FK7498AC3F650C31B` (`charge_config_id`),
  CONSTRAINT `FK7498AC3F650C31B` FOREIGN KEY (`charge_config_id`) REFERENCES `charge_config` (`id`),
  CONSTRAINT `FK7498AC32578B19E` FOREIGN KEY (`prefix_list_id`) REFERENCES `generic_prefix_list` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prepaid_platform`
--



/*!40000 ALTER TABLE `charge_config` DISABLE KEYS */;
INSERT INTO `charge_config` VALUES (1,NULL,NULL);
/*!40000 ALTER TABLE `charge_config` ENABLE KEYS */;

DROP TABLE IF EXISTS `mo_routing_class_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mo_routing_class_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mo_routing_class_config`
--

LOCK TABLES `mo_routing_class_config` WRITE;
/*!40000 ALTER TABLE `mo_routing_class_config` DISABLE KEYS */;
INSERT INTO `mo_routing_class_config` VALUES (1);
/*!40000 ALTER TABLE `mo_routing_class_config` ENABLE KEYS */;
UNLOCK TABLES;

DROP TABLE IF EXISTS `config_policy`;

CREATE TABLE `config_policy` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `policy_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;


--
-- Table structure for table `retry_profile`
--

DROP TABLE IF EXISTS `retry_profile`;

CREATE TABLE `retry_profile` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `profile_description` varchar(255) DEFAULT NULL,
  `profile_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `profile_name` (`profile_name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `aux_service`;

CREATE TABLE `aux_service` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `enabled` bit(1) NOT NULL,
  `local_forwarding` bit(1) DEFAULT NULL,
  `response_timeout` bigint(20) DEFAULT NULL,
  `valid_config` bit(1) DEFAULT NULL,
  `config_policy_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK931FE43AE79F0237` (`config_policy_id`),
  CONSTRAINT `FK931FE43AE79F0237` FOREIGN KEY (`config_policy_id`) REFERENCES `config_policy` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `route`;

CREATE TABLE `route` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `enabled` bit(1) NOT NULL,
  `interface_type` varchar(255) DEFAULT NULL,
  `message_type` varchar(255) DEFAULT NULL,
  `priorty` int(11) DEFAULT NULL,
  `response_timeout` bigint(20) DEFAULT NULL,
  `routing_label` varchar(255) DEFAULT NULL,
  `send_cdr` bit(1) DEFAULT NULL,
  `valid_config` bit(1) DEFAULT NULL,
  `aux_service_id` bigint(20) DEFAULT NULL,
  `config_policy_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK67AB249C205CEE7` (`aux_service_id`),
  KEY `FK67AB249E79F0237` (`config_policy_id`),
  CONSTRAINT `FK67AB249C205CEE7` FOREIGN KEY (`aux_service_id`) REFERENCES `aux_service` (`id`),
  CONSTRAINT `FK67AB249E79F0237` FOREIGN KEY (`config_policy_id`) REFERENCES `config_policy` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Table structure for table `storage_profile`
--

DROP TABLE IF EXISTS `storage_profile`;

CREATE TABLE `storage_profile` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `config_policy_id` bigint(20) DEFAULT NULL,
  `interworking_storage_id` bigint(20) DEFAULT NULL,
  `retry_profile_id` bigint(20) DEFAULT NULL,
  `valid_config` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK3B4DC7E5E601F8B5` (`interworking_storage_id`),
  KEY `FK3B4DC7E5552B73E1` (`retry_profile_id`),
  KEY `FK3B4DC7E5E79F0237` (`config_policy_id`),
  CONSTRAINT `FK3B4DC7E5E79F0237` FOREIGN KEY (`config_policy_id`) REFERENCES `config_policy` (`id`),
  CONSTRAINT `FK3B4DC7E5552B73E1` FOREIGN KEY (`retry_profile_id`) REFERENCES `retry_profile` (`id`),
  CONSTRAINT `FK3B4DC7E5E601F8B5` FOREIGN KEY (`interworking_storage_id`) REFERENCES `config_policy` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;





DROP TABLE IF EXISTS `mo_routing_class`;
CREATE TABLE `mo_routing_class` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `category` varchar(255) DEFAULT NULL,
  `mt_protocol_id` varchar(255) DEFAULT NULL,
  `routing_class_config_id` bigint(20) NOT NULL,
  `storage_profile_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK7FEF9CE25C3778FB` (`storage_profile_id`),
  KEY `FK7FEF9CE277D8EFC6` (`routing_class_config_id`),
  CONSTRAINT `FK7FEF9CE277D8EFC6` FOREIGN KEY (`routing_class_config_id`) REFERENCES `mo_routing_class_config` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK7FEF9CE25C3778FB` FOREIGN KEY (`storage_profile_id`) REFERENCES `storage_profile` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;


--
-- Table structure for table `routingClass_routes`
--

DROP TABLE IF EXISTS `routingClass_routes`;

CREATE TABLE `routingClass_routes` (
  `time_added` datetime DEFAULT NULL,
  `route_id` bigint(20) NOT NULL DEFAULT '0',
  `mo_routing_class_id` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`mo_routing_class_id`,`route_id`),
  KEY `FKD6DC8FD776DF2F82` (`route_id`),
  KEY `FKD6DC8FD7F1BFDB44` (`mo_routing_class_id`),
  CONSTRAINT `FKD6DC8FD7F1BFDB44` FOREIGN KEY (`mo_routing_class_id`) REFERENCES `mo_routing_class` (`id`),
  CONSTRAINT `FKD6DC8FD776DF2F82` FOREIGN KEY (`route_id`) REFERENCES `route` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dump completed on 2010-08-24 10:39:59


--
-- Table structure for table `appProfile_retryProfile`
--

DROP TABLE IF EXISTS `appProfile_retryProfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appProfile_retryProfile` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `retry_profile_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK2B6B2078552B73E1` (`retry_profile_id`),
  CONSTRAINT `FK2B6B2078552B73E1` FOREIGN KEY (`retry_profile_id`) REFERENCES `retry_profile` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;








--
-- Table structure for table `application_list`
--

DROP TABLE IF EXISTS `application_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `application_list` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `fileName` varchar(255) DEFAULT NULL,
  `match_rule` varchar(255) DEFAULT NULL,
  `default_optinout_profile_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK8362D2F168AFF` (`default_optinout_profile_id`),
  CONSTRAINT `FK8362D2F168AFF` FOREIGN KEY (`default_optinout_profile_id`) REFERENCES `default_optinout_profile` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `application_list`
--


LOCK TABLES `application_list` WRITE;
/*!40000 ALTER TABLE `application_list` DISABLE KEYS */;
INSERT INTO `application_list` VALUES (1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `application_list` ENABLE KEYS */;
UNLOCK TABLES;


--
-- Table structure for table `aux_profile`
--

DROP TABLE IF EXISTS `aux_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aux_profile` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `aux_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `aux_resource_policy_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKA6AA72EA4615E` (`aux_resource_policy_id`),
  CONSTRAINT `FKA6AA72EA4615E` FOREIGN KEY (`aux_resource_policy_id`) REFERENCES `config_policy` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `barring_profile`
--

DROP TABLE IF EXISTS `barring_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `barring_profile` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `global_submit_barring` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `barring_profile`
--

--
-- Table structure for table `cdr_profile`
--

DROP TABLE IF EXISTS `cdr_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cdr_profile` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `m2p_aux_service_cdr_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `m2p_charging_cdr_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `m2p_final_cdr_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `m2p_receipt_cdr_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `m2p_retry_cdr_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `m2p_submit_cdr_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `charging_profile`
--

DROP TABLE IF EXISTS `charging_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charging_profile` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `charge_before_delivery` tinyint(1) NOT NULL DEFAULT '0',
  `charge_before_store` tinyint(1) NOT NULL DEFAULT '0',
  `charge_on_delivery` tinyint(1) NOT NULL DEFAULT '0',
  `charge_orig_subscriber` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `connection_profile`
--
SET foreign_key_checks = 0;
DROP TABLE IF EXISTS `connection_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `connection_profile` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `allowInternationalDest` tinyint(1) NOT NULL DEFAULT '0',
  `default_profile_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `default_source_address` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `domainWhitelist_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `enterprise_id` varchar(255) DEFAULT NULL,
  `max_binds` int(11) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `required_authentication` tinyint(1) NOT NULL DEFAULT '0',
  `required_interfaceValue` tinyint(1) NOT NULL DEFAULT '0',
  `response_emailorurladdress` varchar(255) DEFAULT NULL,
  `response_mode` varchar(255) DEFAULT 'MO+DR',
  `system_id` varchar(255) DEFAULT NULL,
  `whitelist_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `app_classifier_id` bigint(20) DEFAULT NULL,
  `domainWhitelist_id` bigint(20) DEFAULT NULL,
  `prefix_id` bigint(20) DEFAULT NULL,
  `connection_id` int(11) DEFAULT NULL,
  `connection_type` varchar(255) DEFAULT 'SMPP',
  PRIMARY KEY (`id`),
  KEY `FK89DCF148EABABCC6` (`domainWhitelist_id`),
  KEY `FK89DCF1486346C1CC` (`app_classifier_id`),
  KEY `FK89DCF1482B6053D7` (`prefix_id`),
  CONSTRAINT `FK89DCF1482B6053D7` FOREIGN KEY (`prefix_id`) REFERENCES `generic_prefix_list` (`id`),
  CONSTRAINT `FK89DCF1486346C1CC` FOREIGN KEY (`app_classifier_id`) REFERENCES `app_classifier` (`id`),
  CONSTRAINT `FK89DCF148EABABCC6` FOREIGN KEY (`domainWhitelist_id`) REFERENCES `generic_prefix_list` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
SET foreign_key_checks = 1;
--
-- Table structure for table `data_coding_profile`
--

DROP TABLE IF EXISTS `data_coding_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data_coding_profile` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `user_data_encoding` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deliver_encoding_profile`
--

DROP TABLE IF EXISTS `deliver_encoding_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deliver_encoding_profile` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `user_data_encoding` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `npi_replacement`
--

DROP TABLE IF EXISTS `npi_replacement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `npi_replacement` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `enable_npi_replacement` tinyint(1) NOT NULL DEFAULT '0',
  `incoming_npi_to_replace` varchar(255) DEFAULT NULL,
  `outgoing_value` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `priority_retry_profile`
--

DROP TABLE IF EXISTS `priority_retry_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priority_retry_profile` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `override_priorty` tinyint(1) NOT NULL DEFAULT '0',
  `default_priorty_id` bigint(20) DEFAULT NULL,
  `priorty0_id` bigint(20) DEFAULT NULL,
  `priorty1_id` bigint(20) DEFAULT NULL,
  `priorty2_id` bigint(20) DEFAULT NULL,
  `priorty3_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKD1D9C7B76061B66F` (`priorty3_id`),
  KEY `FKD1D9C7B760605952` (`priorty0_id`),
  KEY `FKD1D9C7B760614210` (`priorty2_id`),
  KEY `FKD1D9C7B76060CDB1` (`priorty1_id`),
  KEY `FKD1D9C7B797E22FC2` (`default_priorty_id`),
  CONSTRAINT `FKD1D9C7B797E22FC2` FOREIGN KEY (`default_priorty_id`) REFERENCES `retry_profile` (`id`),
  CONSTRAINT `FKD1D9C7B760605952` FOREIGN KEY (`priorty0_id`) REFERENCES `retry_profile` (`id`),
  CONSTRAINT `FKD1D9C7B76060CDB1` FOREIGN KEY (`priorty1_id`) REFERENCES `retry_profile` (`id`),
  CONSTRAINT `FKD1D9C7B760614210` FOREIGN KEY (`priorty2_id`) REFERENCES `retry_profile` (`id`),
  CONSTRAINT `FKD1D9C7B76061B66F` FOREIGN KEY (`priorty3_id`) REFERENCES `retry_profile` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `program_profile`
--

DROP TABLE IF EXISTS `program_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `program_profile` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `is_B2B` tinyint(1) NOT NULL DEFAULT '0',
  `b2bRoutingTable_id` int(11) DEFAULT NULL,
  `billing_id` int(11) DEFAULT NULL,
  `content_filtering` int(11) DEFAULT NULL,
  `is_F2EU` tinyint(1) NOT NULL DEFAULT '0',
  `network_address` varchar(255) DEFAULT NULL,
  `program_id` int(11) DEFAULT NULL,
  `use_dynamic_codes_enabled` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `default_optinout_profile`
--

DROP TABLE IF EXISTS `default_optinout_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `default_optinout_profile` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `default_help_cmds` varchar(255) DEFAULT NULL,
  `default_help_text` varchar(255) DEFAULT NULL,
  `default_invite_text` varchar(255) DEFAULT NULL,
  `default_optin_cmds` varchar(255) DEFAULT NULL,
  `default_optin_confirm_text` varchar(255) DEFAULT NULL,
  `default_optout_cmds` varchar(255) DEFAULT NULL,
  `default_optout_confirm_text` varchar(255) DEFAULT NULL,
  `send_optin_confirm` varchar(255) DEFAULT NULL,
  `send_optout_confirm` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `optinout_profile`
--

DROP TABLE IF EXISTS `optinout_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `optinout_profile` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cmd_handling` varchar(255) DEFAULT NULL,
  `enterprise_description` varchar(255) DEFAULT NULL,
  `help_cmds` varchar(255) DEFAULT NULL,
  `invite_mode` varchar(255) DEFAULT NULL,
  `list_handling` varchar(255) DEFAULT NULL,
  `list_type` varchar(255) DEFAULT NULL,
  `optin_cmds` varchar(255) DEFAULT NULL,
  `optout_cmds` varchar(255) DEFAULT NULL,
  `override_help_text` varchar(255) DEFAULT NULL,
  `override_invite_text` varchar(255) DEFAULT NULL,
  `override_optin_confirm_text` varchar(255) DEFAULT NULL,
  `override_optout_confirm_text` varchar(255) DEFAULT NULL,
  `program_description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `receipt_profile`
--

DROP TABLE IF EXISTS `receipt_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receipt_profile` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `receipt_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `sub_on_failure` tinyint(1) NOT NULL DEFAULT '0',
  `sub_on_success` tinyint(1) NOT NULL DEFAULT '0',
  `receipt_policy_id` bigint(20) DEFAULT NULL,
  `sub_resource_policy_id` bigint(20) DEFAULT NULL,
  `receipt_forced_flag` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK106EAA28E231462` (`sub_resource_policy_id`),
  KEY `FK106EAA25435AD` (`receipt_policy_id`),
  CONSTRAINT `FK106EAA25435AD` FOREIGN KEY (`receipt_policy_id`) REFERENCES `config_policy` (`id`),
  CONSTRAINT `FK106EAA28E231462` FOREIGN KEY (`sub_resource_policy_id`) REFERENCES `config_policy` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `store_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `store_profile` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `disable_message_reassembly` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `store_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `consumer_resource_policy_id` bigint(20) DEFAULT NULL,
  `store_resource_policy_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKF256B84BD8536C21` (`store_resource_policy_id`),
  KEY `FKF256B84BF94296EC` (`consumer_resource_policy_id`),
  CONSTRAINT `FKF256B84BF94296EC` FOREIGN KEY (`consumer_resource_policy_id`) REFERENCES `config_policy` (`id`),
  CONSTRAINT `FKF256B84BD8536C21` FOREIGN KEY (`store_resource_policy_id`) REFERENCES `config_policy` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `submit_profile`
--

DROP TABLE IF EXISTS `submit_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `submit_profile` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `apply_rate_control` tinyint(1) NOT NULL DEFAULT '0',
  `global_submit_barred` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `rate_control_analysis` int(11) DEFAULT NULL,
  `rate_control_desc` varchar(255) DEFAULT NULL,
  `rate_control_limiting` int(11) DEFAULT NULL,
  `rate_control_measurement` int(11) DEFAULT NULL,
  `rate_control_period` int(11) DEFAULT NULL,
  `replace_src_address` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `throttling_profile`
--

DROP TABLE IF EXISTS `throttling_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `throttling_profile` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `alarm_id` bigint(20) DEFAULT NULL,
  `alarm_name` varchar(255) DEFAULT NULL,
  `alarm_severity` bigint(20) DEFAULT NULL,
  `block_window_duration` int(11) DEFAULT NULL,
  `disconnect_alarm_id` bigint(20) DEFAULT NULL,
  `disconnect_alarm_name` varchar(255) DEFAULT NULL,
  `disconnect_alarm_severity` int(11) DEFAULT NULL,
  `disconnect_window_length` int(11) DEFAULT NULL,
  `forced_disconnect_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `limiting_threshold` bigint(20) DEFAULT NULL,
  `measurement_window_len` bigint(20) DEFAULT NULL,
  `period_attempt_threshold` bigint(20) DEFAULT NULL,
  `period_time` bigint(20) DEFAULT NULL,
  `profile_name` varchar(255) DEFAULT NULL,
  `throttling_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `variable_description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `app_profile`
--

DROP TABLE IF EXISTS `app_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_profile` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `default_profile` tinyint(1) NOT NULL DEFAULT '0',
  `force_alert_store` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `retry_profile_id` bigint(20) DEFAULT NULL,
  `aux_profile_id` bigint(20) DEFAULT NULL,
  `barring_profile_id` bigint(20) DEFAULT NULL,
  `bNumber_blacklist_id` bigint(20) DEFAULT NULL,
  `bNumber_whitelist_id` bigint(20) DEFAULT NULL,
  `cdr_profile_id` bigint(20) DEFAULT NULL,
  `charging_profile_id` bigint(20) DEFAULT NULL,
  `data_coding_profile_id` bigint(20) DEFAULT NULL,
  `deliver_encoding_profile_id` bigint(20) DEFAULT NULL,
  `routing_class_id` bigint(20) DEFAULT NULL,
  `priority_retry_profile_id` bigint(20) DEFAULT NULL,
  `receipt_profile_id` bigint(20) DEFAULT NULL,
  `receipt_retry_profile_id` bigint(20) DEFAULT NULL,
  `receipt_storage_profile_id` bigint(20) DEFAULT NULL,
  `storage_profile_id` bigint(20) DEFAULT NULL,
  `submit_profile_id` bigint(20) DEFAULT NULL,
  `vrl_blacklist_id` bigint(20) DEFAULT NULL,
  `vrl_whitelist_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKA2D7F98BB5F94B00` (`bNumber_blacklist_id`),
  KEY `FKA2D7F98BB9B5FCB1` (`vrl_whitelist_id`),
  KEY `FKA2D7F98B5046D842` (`retry_profile_id`),
  KEY `FKA2D7F98BC9A97F69` (`receipt_retry_profile_id`),
  KEY `FKA2D7F98B66735235` (`data_coding_profile_id`),
  KEY `FKA2D7F98B35E9CE47` (`routing_class_id`),
  KEY `FKA2D7F98B33467486` (`charging_profile_id`),
  KEY `FKA2D7F98BAA118D45` (`deliver_encoding_profile_id`),
  KEY `FKA2D7F98BF88EB96` (`bNumber_whitelist_id`),
  KEY `FKA2D7F98BD30ECD19` (`priority_retry_profile_id`),
  KEY `FKA2D7F98B7FC46022` (`aux_profile_id`),
  KEY `FKA2D7F98B60265C1B` (`vrl_blacklist_id`),
  KEY `FKA2D7F98B27D3F8B8` (`submit_profile_id`),
  KEY `FKA2D7F98B67856BF4` (`storage_profile_id`),
  KEY `FKA2D7F98BDF631A88` (`cdr_profile_id`),
  KEY `FKA2D7F98BD26005BA` (`receipt_profile_id`),
  KEY `FKA2D7F98B12DAE55B` (`receipt_storage_profile_id`),
  KEY `FKA2D7F98B89644964` (`barring_profile_id`),
  CONSTRAINT `FKA2D7F98B89644964` FOREIGN KEY (`barring_profile_id`) REFERENCES `barring_profile` (`id`),
  CONSTRAINT `FKA2D7F98B12DAE55B` FOREIGN KEY (`receipt_storage_profile_id`) REFERENCES `store_profile` (`id`),
  CONSTRAINT `FKA2D7F98B27D3F8B8` FOREIGN KEY (`submit_profile_id`) REFERENCES `submit_profile` (`id`),
  CONSTRAINT `FKA2D7F98B33467486` FOREIGN KEY (`charging_profile_id`) REFERENCES `charging_profile` (`id`),
  CONSTRAINT `FKA2D7F98B35E9CE47` FOREIGN KEY (`routing_class_id`) REFERENCES `mo_routing_class` (`id`),
  CONSTRAINT `FKA2D7F98B5046D842` FOREIGN KEY (`retry_profile_id`) REFERENCES `appProfile_retryProfile` (`id`),
  CONSTRAINT `FKA2D7F98B60265C1B` FOREIGN KEY (`vrl_blacklist_id`) REFERENCES `generic_prefix_list` (`id`),
  CONSTRAINT `FKA2D7F98B66735235` FOREIGN KEY (`data_coding_profile_id`) REFERENCES `data_coding_profile` (`id`),
  CONSTRAINT `FKA2D7F98B67856BF4` FOREIGN KEY (`storage_profile_id`) REFERENCES `store_profile` (`id`),
  CONSTRAINT `FKA2D7F98B7FC46022` FOREIGN KEY (`aux_profile_id`) REFERENCES `aux_profile` (`id`),
  CONSTRAINT `FKA2D7F98BAA118D45` FOREIGN KEY (`deliver_encoding_profile_id`) REFERENCES `deliver_encoding_profile` (`id`),
  CONSTRAINT `FKA2D7F98BB5F94B00` FOREIGN KEY (`bNumber_blacklist_id`) REFERENCES `generic_prefix_list` (`id`),
  CONSTRAINT `FKA2D7F98BB9B5FCB1` FOREIGN KEY (`vrl_whitelist_id`) REFERENCES `generic_prefix_list` (`id`),
  CONSTRAINT `FKA2D7F98BC9A97F69` FOREIGN KEY (`receipt_retry_profile_id`) REFERENCES `appProfile_retryProfile` (`id`),
  CONSTRAINT `FKA2D7F98BD26005BA` FOREIGN KEY (`receipt_profile_id`) REFERENCES `receipt_profile` (`id`),
  CONSTRAINT `FKA2D7F98BD30ECD19` FOREIGN KEY (`priority_retry_profile_id`) REFERENCES `priority_retry_profile` (`id`),
  CONSTRAINT `FKA2D7F98BDF631A88` FOREIGN KEY (`cdr_profile_id`) REFERENCES `cdr_profile` (`id`),
  CONSTRAINT `FKA2D7F98BF88EB96` FOREIGN KEY (`bNumber_whitelist_id`) REFERENCES `generic_prefix_list` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Table structure for table `app_classifier`
--


DROP TABLE IF EXISTS `app_classifier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_classifier` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `aob_snr_disabled` tinyint(1) NOT NULL DEFAULT '0',
  `app_classifier_id` varchar(255) DEFAULT NULL,
  `application_trace` tinyint(1) NOT NULL DEFAULT '0',
  `emf_supported` tinyint(1) NOT NULL DEFAULT '0',
  `force_del_sms_after_display` tinyint(1) NOT NULL DEFAULT '0',
  `force_display_sms` tinyint(1) NOT NULL DEFAULT '0',
  `include_validity_period` tinyint(1) NOT NULL DEFAULT '0',
  `m2p_routinglist_lookup_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `network_address` varchar(255) DEFAULT NULL,
  `network_address_len` int(11) DEFAULT NULL,
  `nonNANP_Routing_Table_Id` int(11) DEFAULT NULL,
  `offNet_Routing_Table_Id` int(11) DEFAULT NULL,
  `onNet_Routing_Table_Id` int(11) DEFAULT NULL,
  `p2a_store_push_alert_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `per_application_stats` tinyint(1) NOT NULL DEFAULT '0',
  `replacement_source_address` varchar(255) DEFAULT NULL,
  `service_id` varchar(255) DEFAULT NULL,
  `skip_aux_services` tinyint(1) NOT NULL DEFAULT '0',
  `smpp_errormapping_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `alias_app_profile_id` bigint(20) DEFAULT NULL,
  `application_list_id` bigint(20) NOT NULL,
  `app_profile_id` bigint(20) DEFAULT NULL,
  `connection_profile_id` bigint(20) DEFAULT NULL,
  `optinout_profile_id` bigint(20) DEFAULT NULL,
  `program_profile_id` bigint(20) DEFAULT NULL,
  `throttling_profile_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK7C2C06FFA3404B0A` (`application_list_id`),
  KEY `FK7C2C06FF85BC3399` (`app_profile_id`),
  KEY `FK7C2C06FFA13ED92C` (`connection_profile_id`),
  KEY `FK7C2C06FFEB15A168` (`alias_app_profile_id`),
  KEY `FK7C2C06FFC21CD05A` (`throttling_profile_id`),
  KEY `FK7C2C06FF58201822` (`program_profile_id`),
  KEY `FK7C2C06FF8B0FA7C` (`optinout_profile_id`),
  CONSTRAINT `FK7C2C06FF8B0FA7C` FOREIGN KEY (`optinout_profile_id`) REFERENCES `optinout_profile` (`id`),
  CONSTRAINT `FK7C2C06FF58201822` FOREIGN KEY (`program_profile_id`) REFERENCES `program_profile` (`id`),
  CONSTRAINT `FK7C2C06FF85BC3399` FOREIGN KEY (`app_profile_id`) REFERENCES `app_profile` (`id`),
  CONSTRAINT `FK7C2C06FFA13ED92C` FOREIGN KEY (`connection_profile_id`) REFERENCES `connection_profile` (`id`),
  CONSTRAINT `FK7C2C06FFA3404B0A` FOREIGN KEY (`application_list_id`) REFERENCES `application_list` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK7C2C06FFC21CD05A` FOREIGN KEY (`throttling_profile_id`) REFERENCES `throttling_profile` (`id`),
  CONSTRAINT `FK7C2C06FFEB15A168` FOREIGN KEY (`alias_app_profile_id`) REFERENCES `app_profile` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

--
-- Insert into scripts_run
--
CREATE TABLE IF NOT EXISTS `scripts_run` (
	`id` BIGINT(20) NOT NULL AUTO_INCREMENT,
	`script_name` VARCHAR(100) NULL DEFAULT NULL,
	`date_updated` DATETIME NULL DEFAULT NULL,
	PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
INSERT INTO `scripts_run` (`script_name`, `date_updated`) VALUES ('ismsc.sql', now());

-- End of script.