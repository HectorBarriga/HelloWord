#!/usr/bin/python

DOCUMENTATION = '''
---
module: cron_parser

short_description: This module is used to parse cron job into individual components.

version_added: "1.0"

description:
    - "This module is used to parse cron job defined in a file. The output of the module can be used to create cron job by using cron module."

options:
    file:
        description:
            - This is the file that contains cron job to be parsed.
        required: true
        type: str
        
        Example of job definition:
                           .---------------- minute (0 - 59)
                           |  .------------- hour (0 - 23)
                           |  |  .---------- day of month (1 - 31)
                           |  |  |  .------- month (1 - 12) OR jan,feb,mar,apr ...
                           |  |  |  |  .---- day of week (0 - 6) (Sunday=0 or 7) OR sun,mon,tue,wed,thu,fri,sat
                           |  |  |  |  |
        user-name comment  *  *  *  *  *  command to be executed

        user-name: The specific user whose crontab should be modified.
        comment  : Comment to the job. If no comment, quotes ("") must be used. For example:
                   tango "Purge olg logs" 01 5 * * * /tango/bin/HK_purgeFiles /tango/logs 30
                   tango "" 02 5 * * * /tango/bin/HK_purgeFiles /tango/data 30

    user:
        description:
            - A cron file can contains jobs for more than one user. This option is used to select the user job to be parsed.
        required: true
        type: str

author:
    - CK Lai
'''

EXAMPLES = '''
- name: Parse cron job
  cron_parser:
    file: /tmp/user_cron
    user: foo

'''

RETURN = '''
changed:
    description: defined if there is changes to the system
    returned: always
    type: boolean
    sample: true
meta:
    description: cron job of the user
    returned: always
    type: complex
    contains:
        exists:
            description: Status of cron job of the user existence
            returned: always
            type: boolean
            sample: true
        user:
            description: the user name
            returned: always
            type: str
            sample: foo
        cron:
            description: cron jobs of the user
            returned: always
            type: string
            contains:
                <counter>
                   description: counter for the number of job which starts from 0
                   returned: always
                   type: int
                   contains:
                      minute:
                          description: minute field in cron job
                          returned: always
                          type: str
                          sample: 59
                      hour:
                          description: hour field in the cron job
                          returned: always
                          type: str
                          sample: 2
                      dom:
                          description: day of month field in the cron job
                          returned: always
                          type: str
                          sample: 5
                      month:
                          description: month field in the cron job
                          returned: always
                          type: str
                          sample: 8
                      dow:
                          description: day of week in the cron job
                          returned: always
                          type: str
                          sample: 5
                      cmd:
                          description: command to be scheduled in cron job
                          returned: always
                          type: str
                          sample: /sbin/reboot
'''

import shlex
from ansible.module_utils.basic import *

def main():
  fields = {
    "file": {
      "required": True,
      "type": "str"
    },
    "user": {
      "required": True,
      "type": "str"
    },
  }

  module = AnsibleModule(argument_spec=fields)
  is_error, has_changed, result = cronmap(module.params)

  if not is_error:
    module.exit_json(changed=has_changed, meta=result)
  else:
    module.fail_json(msg="Error in parsing cron file.", meta=result)


def cronmap(data):
  is_error = False
  has_changed = False
  cfile = data['file']
  cuser = data['user']
  res = []

  ucronmap = []
  cronline = 0
  file_object = open(cfile, 'r')
  for line in file_object:
    if line.strip() and not line.startswith("#"):
      line = line.strip()
      fields = shlex.split(line)
      if fields[0] == cuser:
        cmdstr = ' '.join(fields[7:])
        ucronmap.append({'name':fields[1],'minute':fields[2],'hour':fields[3],'dom':fields[4],'month':fields[5],'dow':fields[6],'cmd':cmdstr})
        cronline = cronline + 1
  file_object.close()

  if cronline > 0:
    res = {"exists": True, "user": cuser, "cron": ucronmap}
  else:
    res = {"exists": False, "user": cuser, "cron": ucronmap}

  return is_error, has_changed, res


if __name__ == '__main__':
    main()

