#!/usr/bin/python

DOCUMENTATION = '''
---
module: match_user_group

short_description: This module is used to check the existence of user or group.

version_added: "1.0"

description:
    - "This module is used to check the existence of user or group in /etc/passwd and /etc/group. If the user or group exists, the uid/gid will be checked against the provided user/group. A response containing user/group existence and uid/gid matching status."

options:
    name:
        description:
            - This is the user or group name to be checked.
        required: true
        type: str
    id:
        description:
            - User ID (UID) or Goup ID (GID) to be matched.
        required: true
        type: int
    type:
        description:
            - The type of checking, either user or group.
        default: user
        type: str
        choices:
            - user
            - group

author:
    - CK Lai
'''

EXAMPLES = '''
- name: Check User Name and UID
  match_uid_gid:
    name: tango
    id: 500

- name: Check Group Name and GID
  match_uid_gid:
    name: tango
    id: 1000
    type: group
'''

RETURN = '''
changed:
    description: defined if there is changes to the system
    returned: always
    type: boolean
    sample: true
meta:
    description: user or group existence status
    returned: always
    type: complex
    contains:
        exists:
            description: Status of user or group existence
            returned: always
            type: boolean
            sample: true
        matched:
            description: Status of uid or gid matching
            returned: always
            type: boolean
            sample: true
        ugname:
            description: user or group name that is found in /etc/passwd or /etc/group
            returned: always
            type: string
            sample: tango
        id:
            description: user or group id
            returned: success
            type: int
            sample: 500

'''

from ansible.module_utils.basic import *

def main():
  fields = {
    "name": {
      "required": True,
      "type": "str"
    },
    "id": {
      "default": 1500,
      "type": "int"
    },
    "type": {
      "default": "user",
      "choices": ['user', 'group'],
      "type": "str"
    },
  }

  module = AnsibleModule(argument_spec=fields)
  is_error, has_changed, result = ugnmap(module.params)

  if not is_error:
    module.exit_json(changed=has_changed, meta=result)
  else:
    module.fail_json(msg="Error in getting user/group", meta=result)


def ugnmap(data):
  is_error = False
  has_changed = False
  ugn = data['name']
  ugid = data['id']
  ugtype = data['type']
  res = []

  if ugtype == "user":
    file = "/etc/passwd"
  elif ugtype == "group":
    file = "/etc/group"
  else:
    is_error = True

  ugmap = {}
  file_object = open(file, 'r')
  for line in file_object:
    line = line.strip()
    fields = line.split(":")
    ugmap[fields[0]] = int(fields[2])
  file_object.close()

  if ugmap.get(ugn) == None:
    res = {"exists": False, "matched": False, "ugname": ugn}
  elif ugmap[ugn] == ugid:
    res = {"exists": True, "matched": True, "ugname": ugn, "id": ugmap[ugn]}
  else:
    res = {"exists": True, "matched": False, "ugname": ugn, "id": ugmap[ugn]}

  return is_error, has_changed, res


if __name__ == '__main__':
    main()

