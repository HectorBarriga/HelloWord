elastic
=======
This role is responsible for deploying the tango-elasticsearch component.

Details of manual deployment is documented:
[Tango elasticsearch ](http://confluence:8090/display/DEV/Tango+Elasticsearch)

It installs elastic-search, applies the Tango standard configuration and deployment model preferences (i.e. master,
data and coordinating nodes). Using variables one can determine which of master, data and coordinating nodes to deploy,
and whether x-pack should be used or not.
 
It has tight integration with centos 7 and systemd service life-cycle management. All configuration parameterization 
is conducted through systemd environment files.

For x-pack and security, the public certificate and private keys associated with Kibana shall vary per site : sometimes 
self-signed, sometimes CA approved. It is envisaged that the public key of Kibana shall be created on or copied to the 
Ansible  server and copied into the files directory of this role prior to launching any playbook using this role. This 
is a necessary pre-requisite to creating the watcher trust-store used by elastic. This is used in the monitoring 
feature, when elastic-search sends alerts to Kibana to notify of node failures and licence expiry. 

It does the following:

- Local Install elastic-search (--tags=run_install_elastic)
- Create directory structure based on the selected deployment model of master, data and coordinating nodes. This 
includes handling for logs, pids, data and configuration -- including settings, jvm and log4j2 configuration 
(--tags=create_directories)
- Create systemd service and tmpfiles (--tags=create_systemd_service_plus_tmpfiles)
- Create systemd environment files (--tags=create_systemd_environment_files)
- Create cluster security resources (--tags=create_cluster_security_resources)
- Install x-pack IMS custom realm extension (--tags=run_install_xpack_ims_plugin)
- Change to the default bootstrap password (--tags=change_default_elastic_bootstrap_password)
- Create the watcher trust-store (--tags=create_watcher_truststore)
- Create custom elastic-search start-up scripts so Systemd environment files can be leveraged 
(--tags=create_elasticsearch_scripts)
- Reloads the Systemd daemon and starts up the required elastic-search nodes per host (--tags=start_elasticsearch)
- Installs the currently Tango supported base elastic-search index templates (--tags=install_base_index_templates)
- Installs the currently Tango supported per tenant elastic-search index templates (--tags=install_per_tenant_index_templates)


Requirements
------------
It is required to run the reporting-base role to generate the deployment view of resources prior to running this role.

For x-pack and security, the public certificate and private keys associated with Kibana shall vary per site : sometimes 
self-signed, sometimes CA approved. It is envisaged that the public key of Kibana shall be created on or copied to the 
Ansible  server and copied into the files directory of this role prior to launching any playbook using this role. This 
is a necessary pre-requisite to creating the watcher trust-store used by elastic. This is used in the monitoring 
feature, when elastic-search sends alerts to Kibana to notify of node failures and licence expiry.

For example: 

    - % sudo openssl req -x509 -nodes -days 14600 -newkey rsa:2048 -keyout tango.mtn.com.pem -out tango.mtn.com.cert.pem
    
See 
[Creating self-signed certificates](http://confluence:8090/display/DEV/PM-UI+Deploying+into+multi-tenant+environment#PM-UIDeployingintomulti-tenantenvironment-Creatingself-signedcertificatesandprivatekeys)
    

Role Variables
--------------
Available variables are listed below, along with default values (see `defaults/main.yml`):

    # install elastic-search
    local_package_install: true
    local_packages_directory: /tango/install/reporting-platform/reporting-platform-dependencies/7.3.0
    elastic_package_file: elasticsearch-7.3.0-x86_64.rpm
    
    # deployment view
    install_master_node: true
    install_data_node: true
    install_coordinating_node: false
    install_xpack: true
    
    # systemd environment - general
    es_cluster_name: "mtn-cluster"
    es_bootstrap_memory_lock: "true"
    es_minimum_master_nodes: "1"
    es_tango_ims_realm_primary_service_url: "http://localhost:8225"
    es_tango_ims_realm_secondary_service_url: "http://localhost:8225"
    es_tango_ims_realm_use_ldap_no_roles: "false"
    es_unicast_hosts: "localhost"
    
    # systemd environment - master
    es_master_java_opts: "-Xms512m -Xmx512m"
    master_path_data: "/tango/data/elasticsearch/master"
    master_path_logs: "/var/log/elasticsearch.master"
    es_master_xpack_http_ssl_truststore_path: "/etc/elasticsearch-master/policydemo-truststore.jks"
    es_master_cert_path: "/etc/elasticsearch-master/elastic-certificates.p12"
    
    # systemd environment - data
    es_data_java_opts: "-Xms1g -Xmx1g"
    data_path_data: "/tango/data/elasticsearch/data"
    data_path_logs: "/var/log/elasticsearch.data"
    es_data_xpack_http_ssl_truststore_path: "/etc/elasticsearch-data/policydemo-truststore.jks"
    es_data_cert_path: "/etc/elasticsearch-data/elastic-certificates.p12"
    
    # systemd environment - coordinating
    es_coordinating_java_opts: "-Xms1g -Xmx1g"
    coordinating_path_data: "/tango/data/elasticsearch/coordinating"
    coordinating_path_logs: "/var/log/elasticsearch.coordinating"
    es_coordinating_xpack_http_ssl_truststore_path: "/etc/elasticsearch-coordinating/policydemo-truststore.jks"
    es_coordinating_cert_path: "/etc/elasticsearch-coordinating/elastic-certificates.p12"
    es_transport_host: "localhost"
    
    # creating watcher trust-store
    input_cert: policydemo_com.crt
    keystore_password: t3l3com
    output_truststore: watcher-truststore.jks
    
    # shard allocation
    campaign_manager_num_shards: 1
    campaign_manager_stats_num_shards: 1
    gtp_proxy_num_shards: 1
    gtp_proxy_stats_num_shards: 1
    gtp_proxy_data_usage_stats_num_shards: 1
    nginx_access_num_shards: 1
    notification_hdlr_num_shards: 1
    pcc_data_usage_num_shards: 1
    pcc_spcm_plan_num_shards: 1
    pcc_spcm_sub_lifecycle_num_shards: 1
    pcc_stats_num_shards: 1
    pcc_rules_counters_num_shards: 1
    referral_manager_num_shards: 1
    uns_num_shards: 1
    hrg_num_shards: 1
    wsms_num_shards: 1
    
    # replica allocation
    campaign_manager_num_replicas: 1
    campaign_manager_stats_num_replicas: 1
    gtp_proxy_num_replicas: 1
    gtp_proxy_stats_num_replicas: 1
    gtp_proxy_data_usage_stats_num_replicas: 1
    nginx_num_replicas: 1
    notification_hdlr_num_replicas: 1
    pcc_data_usage_num_replicas: 1
    pcc_spcm_plan_num_replicas: 1
    pcc_spcm_plan_num_replicas: 1
    pcc_spcm_sub_lifecycle_num_replicas: 1
    pcc_stats_num_replicas: 1
    pcc_rules_counters_num_replicas: 1
    referral_manager_num_replicas: 1
    uns_num_replicas: 1
    hrg_num_replicas: 1
    wsms_num_replicas: 1
    
    # elastic-search base templates
    index_templates:
      campaign_manager_base_template:
        filename: campaign_manager_base_template.json.j2
      campaign_manager_stats_base_template:
        filename: campaign_manager_stats_base_template.json.j2
      nginx_base_template:
        filename: nginx_base_template.json.j2  
      pcc_spcm_plan_template_base:
        filename: pcc_spcm_plan_template_base.json.j2
      pcc_spcm_sub_lifecycle_base_template:
        filename: pcc_spcm_sub_lifecycle_base_template.json.j2  
      pcc_data_usage_template_base:
        filename: pcc_data_usage_template_base.json.j2
      pcc_stats_template_base:
        filename: pcc_stats_template_base.json.j2
      pcc_rules_counters_template_base:
        filename: pcc_rules_counters_template_base.json.j2
      gtp_proxy_base_template:
        filename: gtp_proxy_base_template.json.j2
      gtp_proxy_stats_base_template:
        filename: gtp_proxy_stats_base_template.json.j2
      gtp_proxy_data_usage_stats_base_template:
        filename: gtp_proxy_datausage_stats_base_template.json.j2
      notification_hdlr_base_template:
        filename: notification_hdlr_base_template.json.j2
      uns_base_template:
        filename: uns_base_template.json.j2
      hrg_base_template:
        filename: hrg_template_base.json.j2
      location_update_base_template:
        filename: location_update_base_template.json.j2
      welcomenotifications_base_template:
        filename: welcomenotifications_base_template.json.j2
    
    # elastic-search templates per tenant
    tenant_index_templates:
      campaign_manager:
        filename: campaign_manager_tenant_template.json.j2
      campaign_manager_stats:
        filename: campaign_manager_stats_tenant_template.json.j2
      nginx_template:
        filename: nginx_tenant_template.json.j2        
      pcc_spcm_plan_template:
        filename: pcc_spcm_plan_tenant_template.json.j2
      pcc_spcm_sub_lifecycle_template:
        filename: pcc_spcm_sub_lifecycle_tenant_template.json.j2        
      pcc_data_usage_template:
        filename: pcc_data_usage_tenant_template.json.j2
      pcc_stats_template:
        filename: pcc_stats_tenant_template.json.j2
      pcc_rules_counters_template:
        filename: pcc_rules_counters_tenant_template.json.j2
      gtp_proxy:
        filename: gtp_proxy_tenant_template.json.j2
      gtp_proxy_stats:
        filename: gtp_proxy_stats_tenant_template.json.j2
      gtp_proxy_data_usage_stats:
        filename: gtp_proxy_datausage_stats_tenant_template.json.j2
      uns:
        filename: uns_tenant_template.json.j2
      hrg:
        filename: hrg_tenant_template.json.j2
      lists:
        filename: lists_index_template.json.j2
      location_update_tenant_template:
        filename: location_update_tenant_template.json.j2
      welcomenotifications_tenant_template:
        filename: welcomenotifications_tenant_template.json.j2



Dependencies
------------
reporting-base

Example Playbook
----------------
Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - name: reporting-platform-data playbook
      hosts: reporting-platform-data
      roles:
        - reporting-base
        - elastic
        
There are certain tasks that are useful to run when running an *Add a Tenant* use-case in production:

    % ansible-playbook reporting-platform-data.yml --tags=install_per_tenant_index_templates --extra-vars="tenant=coltm" -i hosts
    
In this case the *--extra-vars* variables shall over-ride the default *tenant* (see `defaults/main.yml`) and any 
*tenant* defined on site in the *host_vars* or *group_vars* directories.        

License
-------
Tango Telecom Ltd.