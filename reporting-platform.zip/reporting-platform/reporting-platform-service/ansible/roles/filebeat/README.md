filebeat
========
This role is responsible reading CDR or log files, record at a time and sending events to logstash for ingestion into
elastic-search indices.

It is expected that filebeat shall run on any VM type that generates CDRs (e.g. PCC VM, GTP_Proxy VM, NH VM, UNS VM, 
RTE VM &c.). It is expected that this can be managed with an overall group (e.g. reporting-platform-shipper).  It is
expected that each VM type would have different filebeat variables configured so may make sense to have an ansible 
group for the various VM types above when using filebeat role, and it is possible to pass ansible variables into the 
filebeat role at host level granularity if necessary. 

If the *install_filebeat* variable is set to false then all tasks in this role shall be ignored.

It does the following:

- Local install of filebeat
- Creates Systemd files including filebeat.service and a templated filebeat environment file
- Creates the Tango customized filebeat.yml configuration settings
- Perform a configuration test and connection test with the configured logstash instances


Requirements
------------
It is required to run the reporting-base and logstash role prior to running this role.

Note the logstash role is only required to be run, if you need to install logstash and test the file-beat connection
to logstash.

Role Variables
--------------
Available variables are listed below, along with default values (see `defaults/main.yml`):

    # install file-beat
    install_filebeat: true
    local_package_install: true
    local_packages_directory: /tango/install/reporting-platform/reporting-platform-dependencies/7.3.0
    filebeat_package_file: filebeat-7.3.0-x86_64.rpm
    
    # file-beat configuration
    filebeat_kibana_hosts: "localhost:5602"
    filebeat_kibana_username: "elastic"
    filebeat_kibana_password: "t3l3com"
    filebeat_logstash_hosts: "localhost:5044"
    filebeat_logstash_wait_timeout: 30

    
    # Prospector Paths and activation
    filebeat_pcc_enabled: "true"
    filebeat_uns_enabled: "true"
    filebeat_nh_enabled: "true"
    filebeat_gtp_proxy_enabled: "true"
    filebeat_campaign_stats_enabled: "true"
    filebeat_campaign_manager_enabled: "true"
    filebeat_referrals_enabled: "true"
    filebeat_triggering_enabled: "false"
    filebeat_hrg_enabled: "true"
    filebeat_wsms_enabled: "true"
    filebeat_generic_trigger_wsms_enabled: "false"
    filebeat_3g_trigger_wsms_enabled: "true"
    filebeat_lte_trigger_wsms_enabled: "true"

    
    filebeat_pcc_path: "/tango/data/ingest/*SPCM*.csv"
    filebeat_uns_path: "/tango/data/ingest/*UNS*"
    filebeat_nh_path: "/tango/data/ingest/SMS*"
    filebeat_gtp_proxy_path: "/tango/data/ingest/gtp*.txt"
    filebeat_campaign_stats_path: "/tango/data/ingest/*campaign*.json"
    filebeat_campaign_manager_path: "/tango/data/ingest/som_*.csv"
    filebeat_referrals_path: "/tango/data/ingest/rom_*.csv"

    filebeat_triggering_path: "/tango/data/ingest/eo-MAP-TIWS-IRMS-*"
    filebeat_hrg_path: "/tango/data/ingest/*hrg*"
    filebeat_wsms_path: "/tango/data/ingest/sibbWelcomeSms*"

    filebeat_trigger_wsms_path_generic: "/tango/data/ingest/wsms/eo-MAP-TIWS-IRMS-*"
    filebeat_trigger_wsms_path_3g: "/tango/data/ingest/wsms/3G/eo-MAP-TIWS-IRMS-*"
    filebeat_trigger_wsms_path_lte: "/tango/data/ingest/wsms/LTE/eo-MAP-TIWS-IRMS-*"

Dependencies
------------
Dependent on the follow Tango roles:

- reporting-base
- logstash

Note the logstash role is only required to be run, if you need to install logstash and test the file-beat connection
to logstash.

Example Playbook
----------------
Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - name: reporting-platform-shipper playbook
      hosts: reporting-platform-shipper
      roles:
        - reporting-base
        - metricbeat
        - filebeat
        
Note that particular care should be taken with regard to the hosts property here, as it is expected to be common for 
different VM types (e.g. PCC VM, GTP_Proxy VM, NH VM, UNS VM, RTE VM &c.) to be generating different CDR types with
different structure and so the directory path, and the enabled / disabled file-beat harvesters and prospectors is likely
to vary per VM type. Therefore, it would make sense to have a different ansible group per VM type in this case.        

License
-------
Tango Telecom Ltd.
