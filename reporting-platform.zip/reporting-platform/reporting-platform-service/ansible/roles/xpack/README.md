xpack
=====
This role is responsible for orchestrating some xpack related tasks a top of the tango-elasticsearch component.

To run this role it is required that you have an xpack license, and you place the license in the files directory for 
this role. The name of the license file also needs to be provided as an ansible variable below.

Some caution and care is necessary when orchestrating this role as this role is responsible for creating a number of 
users and you need to be careful when allocating passwords to users. Don't rely on the default password variables for 
all users as this would be a *big* security leak on site, allowing certain users to use accounts they are not meant
to have access to.

If the *install_xpack* variable is set to false then all tasks in this role shall be ignored.

It does the following:

- Modifies the default passwords of the build-in users: elastic, kibana and logstash_system 
(--tags=modify_default_passwords)
- Installs the xpack license on site (--tags=install_xpack_license) 
- Creates the logstash_writer role for logstash to use (--tags=create_logstash_writer_role)
- Creates the kibana_readonly role for kibana public users to use (--tags=create_kibana_readonly_role)
- Creates the master user role for kibana public users to use. The master tenant provides aggregated view
 across all tenants in a multi-tenant system (--tags=create_master_user_role)
- Creates the master admin user role and user for kibana private use. The master tenant provides aggregated view
 across all tenants in a multi-tenant system (--tags=create_master_admin_user_role) 
- Creates a monitoring user for accessing the kibana monitoring screens for monitoring elastic-search, kibana
 and logstash (--tags=create_monitoring_user)
- Creates a readonly role for a particular tenant. Some examples are given below in the 
 section below on triggering these tasks when adding a new tenant to a system for example. This is for a kibana 
 public user to view dashboards for a particular tenant (--tags=create_role_for_tenant) 
- Creates an admin role and user for a particular tenant. Some examples are given below in the *Example Playbook*  
 *Example Playbook*  section below on triggering these tasks when adding a new tenant to a system for example.
 This is for a kibana private user to create /edit new dashboards for a particular tenant  
 (--tags=create_admin_user_and_role_for_tenant)
 

Requirements
------------
It is required to run the reporting-base and the elastic role to generate the deployment view of resources 
and to set-up elastic-search prior to running this role.

To run this role it is required that you have an xpack license, and you place the license in the files directory for 
this role. The name of the license file also needs to be provided as an ansible variable below.

The license file should just be a json file.

See [Tango x-pack licensing ](http://confluence:8090/display/CO/%27Elastic%27+licensing)

Role Variables
--------------

Available variables are listed below, along with default values (see `defaults/main.yml`):

    ## defaults file for xpack
    install_xpack: true
    
    ## elastic-search
    es_port: 9201
    es_user: elastic
    es_original_password: "top-secret"
    es_password: t3l3com
    
    ## license
    xpack_license: "xpack-license.json"
    
    ## default tenant
    tenant: tango
    
    ###############
    ## user details
    ###############
    # master admin user is likely to be Tango staff -- with current strategy of public / private Kibana
    master_admin_user_password: t3l3com
    master_admin_user_full_name: "John Lee"
    master_admin_user_email: "john.lee@tangotelecom.com"
    
    # monitoring user is likely to be customer / operator staff
    monitoring_user_password: t3l3com
    monitoring_user_full_name: "John Lee"
    monitoring_user_email: "john.lee@tangotelecom.com"
    
    # per tenant admin user is likely to be Tango staff -- with current strategy of public / private Kibana
    per_tenant_admin_user_password: t3l3com
    per_tenant_admin_user_full_name: "John Lee"
    per_tenant_admin_user_email: "john.lee@tangotelecom.com"

Dependencies
------------
Dependent on the follow Tango roles:

reporting-base
elastic

Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - name: reporting-platform-data playbook
      hosts: reporting-platform-data
      roles:
        - reporting-base
        - elastic
        - xpack
        
There are certain tasks that are useful to run when running an *Add a Tenant* use-case in production:

    % ansible-playbook reporting-platform-data.yml --tags=create_role_for_tenant --extra-vars="tenant=coltm" -i hosts
    % ansible-playbook reporting-platform-data.yml --tags=create_admin_user_and_role_for_tenant --extra-vars="tenant=coltm" -i hosts
    
In this case the *--extra-vars* variables shall over-ride the default *tenant* (see `defaults/main.yml`) and any 
*tenant* defined on site in the *host_vars* or *group_vars* directories.        

License
-------
Tango Telecom Ltd.
