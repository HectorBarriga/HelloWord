logstash
========
This role is responsible for deploying the tango-logstash component.

It is expected that logstash shall run on RTE VMs. It is expected that this can be managed with an overall group 
(e.g. reporting-platform-service).

If the *install_logstash* variable is set to false then all tasks in this role shall be ignored.

It does the following:
- Local Install elastic-search (--tags=run_install_logstash)
- Deploy Systemd logstash environment file to parameterize the logstash configuration from environment 
(--tags=create_logstash_systemd_files)
- Deploy the logstash.yml configuration settings file (--tags=create_logstash_configuration_settings)
- Deploy the customized Tango logstash configuration templates (--tags=create_logstash_configuration)
- Deploy the customized Tango logstash configuration per tenant. This can be used as part of an *Add Tenant* 
procedure (--tags=create_logstash_configuration_per_tenant)
- Verify the deployed syntax of the logstash configuration (--tags=verify_logstash_configuration)
- Optionally install x-pack plugin into logstash. Logstash can be monitored through Kibana dashboard. This is
activated by the *install_xpack* ansible variable, which is defaulted to true. X-pack requires a licence to be
purchased in production (--tags=run_install_xpack)
- Install the Tango logstash plugins (--tags=install_logstash_plugins)
- Enable the logstash.service and start logstash


Requirements
------------
It is required to run the *reporting-base* role to generate the deployment view of resources prior to running this role.

This role is also dependent on *elastic* role if you want to test the connection.

This role can optionally use *xpack* role to avail of the monitoring feature. The monitoring feature allows
you to monitor logstash operational and diagnostic information from the Kibana dashboard.

Role Variables
--------------
Available variables are listed below, along with default values (see `defaults/main.yml`):

    # install logstash
    install_logstash: true
    install_logstash_tenant: true
    install_xpack: true
    local_package_install: true
    local_packages_directory: /tango/install/reporting-platform/reporting-platform-dependencies/7.3.0
    logstash_package_file: logstash-7.3.0.rpm
    
    # logstash configuration
    logstash_path_data: "/var/lib/logstash"
    logstash_path_config: "/etc/logstash/conf.d"
    logstash_path_logs: "/var/log/logstash"
    logstash_monitoring_es_url: "http://localhost:9200"
    logstash_es_hosts: "http://localhost:9200"
    
    # logstash configuration for PCC DB
    logstash_pcc_tenant_db_schema: pmsdb
    logstash_pcc_tenant_db_ip_address: 127.0.0.1
    logstash_pcc_tenant_db_port: 3306
    logstash_pcc_tenant_db_user: spcmjdbc
    logstash_pcc_tenant_db_password: spcms3cr3t

Dependencies
------------
reporting-base

There is an optional dependency on xpack, if you want to leverage monitoring of logstash.

Example Playbook
----------------
Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - name: reporting-platform-service playbook
      remote_user: root
      hosts: reporting-platform-service
      roles:
        - reporting-base
        - elastic
        - xpack
        - metricbeat
        - logstash
        - kibana
        
There are certain tasks that are useful to run when running an *Add a Tenant* use-case in production:

    % ansible-playbook reporting-platform-service.yml --tags=create_logstash_configuration_per_tenant --extra-vars="tenant=coltm" -i hosts
    
In this case the *--extra-vars* variables shall over-ride the default *tenant* (see `defaults/main.yml`) and any 
*tenant* defined on site in the *host_vars* or *group_vars* directories.             

License
-------
Tango Telecom Ltd.