reporting-base
==============
This role is responsible for distributing the Tango reporting-platform dependencies of third-party software and also
distributing a deployment-view of the Tango reporting-platform resources. It also installs Java 8 JDK.

The Tango reporting-platform is released as a suite of discrete components, but these are combined according to 
deployment view of standard node type (whereby each node type is represented with an ansible playbook group):

- reporting-platform-data (contains tango-elasticsearch, tango-metricbeat)
- reporting-platform-service (contains tango-elasticsearch, tango-metricbeat, tango-kibana, tango-logstash, reporting-platform)
- reporting-platform-shipper (contains tango-filebeat, tango-metricbeat)


Requirements
------------
To map from reporting-platform component view to deployment view requires executing a shell script on the ansible jump 
server, with an option to download dependencies and the release from tangier.

    - % ./prepare_deployment_view.sh --download
For offline mode then omit the --download switch, and put all the tarballs in a directory called 'tangier' on the 
ansible jump server, whereby the 'tangier' is in the same directory as the script.

The 'prepare_deployment_view.sh' script is distributed inside the reporting platform component, along with all the
other production ansible resources.

Role Variables
--------------
Available variables are listed below, along with default values (see `defaults/main.yml`):

    # defaults file for reporting-base
    push_and_explode_packages: true    
    
    # reporting-platform-dependencies for unarchive and decompression
    reporting_platform_dependencies_src: /tango/install/packages/reporting-platform-dependencies/reporting-platform-dependencies.tar.gz
    reporting_platform_dependencies_dest: /tango/install/reporting-platform/reporting-platform-dependencies
    
    # reporting-platform for unarchive and decompression
    reporting_platform_src: /tango/install/packages/reporting-platform-data/reporting-platform-data.tar.gz
    reporting_platform_dest: /tango/install/reporting-platform/reporting-platform-data
    
It is expected that the reporting-platform directory on the target shall have different content depending on 
whether the target is a reporting-platform-data, reporting-platform-service or reporting-platform-shipper type. It is
expected that these types shall map to ansible roles in the enclosing playbook, and that the group_vars for the group
would over-write the `reporting_platform_src` and `reporting_platform_dest` as required for the group.

On any given host, the expectation is that there is only one elastic-search instance per group type. So 
a reporting-data-node could have a master elastic-search instance, a data elastic-search instance and a co-ordinating
elastic-search instance, but that it would not contain two master elastic-search instances for example.
    
    # reporting-platform jdk to use
    install_jdk: true
    jdk_64bit_package_file: /tango/install/reporting-platform/reporting-platform-dependencies/jdk-8u162-linux-x64.tar.gz
    jdk_extracted_directory: jdk1.8.0_162
    
This is expected to be a Java 8 bundle.    

Dependencies
------------
This role has a dependency on the java role produced by CO, for the installation of java.
Refer to [Sites Automation](http://tangier/repo/cust_op/sites_automation) subversion project for details.

Example Playbook
----------------
    - name: reporting-platform-data playbook
      hosts: reporting-platform-data
      roles:
        - { role: reporting-base }

License
-------
Tango Telecom Ltd.
