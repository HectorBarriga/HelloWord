kibana
======
This role is responsible for deploying the tango-kibana component.

It installs kibana, applies the Tango standard configuration and deployment model preferences (i.e. a kibana-private 
software instance for Tango users, and a kibana-public software instance for customer access, which is read-only and
provides a per-tenant view). 
Using variables one can determine which of kibana-private and kibana-public to deploy.

For x-pack and security, the public certificate and private keys associated with Kibana shall vary per site : sometimes 
self-signed, sometimes CA approved. It is envisaged that the public key of Kibana shall be created on or copied to the 
Ansible  server and copied into the files directory of this role prior to launching any playbook using this role. The 
ansible variables in the playbook then need to be updated with the names of the public cert and private key.

If the *install_kibana* variable is set to false then all tasks in this role shall be ignored.
 
One can decide whether to deploy a kibana-public and/or kibana-private instance to the target using the 
*install_public_kibana* and *install_private_kibana* variables respectively.

It does the following:

- Local installation of Kibana version 7.3(--tags=run_install_kibana)
- Create directory structure for systemd for kibana-private and / or kibana-public (--tags=create_kibana_systemd_files)
- Distribute Kibana public certificate and private key to target systems for kibana-private and / or kibana-public 
(--tags=create_kibana_security_resources)
- Create a Kibana space per tenant and a master space
- Optionally deploy x-pack plugin into Kibana (--tags=run_install_xpack)
- Create customized Kibana code-base for kibana-public (--tags=create_kibana_code_bases)
- Starts all kibana instances. Note that this can take several minutes to complete as kibana shall trigger an 
optimization of coding bundles based on customized code and/or installed plugins (--tags=start_kibana)
- Create customized Kibana styles for kibana-public (--tags=overwrite_kibana_public_styles and overwrite_commons_public_styles)
- Import the Tango master dashboards into Kibana (--tags=import_master_customized_dashboards)
- Import the Tango per tenant dashboards into Kibana (--tags=import_per_tenant_customized_dashboards)
- Optionally, import the Tango per tenant subscriber dashboards into Kibana (--tags=import_per_tenant_subscriber_dashboards)
- Optionally, import the Tango per tenant KPI into Kibana (--tags=import_per_tenant_KPI_dashboards)
- Optionally, import the Tango protocol dashboards into Kibana (--tags=import_protocol_dashboards)
- Optionally, import the Tango Welcome SMS dashboards into Kibana  (--tags=import_welcome_sms_dashboards)
- Optionally, import the (TF) Subscriber specific dashboards into Kibana  (--tags=install_tf_vivo_dashboards)



Requirements
------------
It is required to run the reporting-base role to generate the deployment view of resources prior to running this role.

The elastic and xpack role is required to be run, if you want to login to Kibana

For x-pack and security, the public certificate and private keys associated with Kibana shall vary per site : sometimes 
self-signed, sometimes CA approved. It is envisaged that the public key of Kibana shall be created on or copied to the 
Ansible  server and copied into the files directory of this role prior to launching any playbook using this role.

For example: 

    - % sudo openssl req -x509 -nodes -days 14600 -newkey rsa:2048 -keyout tango.mtn.com.pem -out tango.mtn.com.cert.pem
    
See 
[Creating self-signed certificates](http://confluence:8090/display/DEV/PM-UI+Deploying+into+multi-tenant+environment#PM-UIDeployingintomulti-tenantenvironment-Creatingself-signedcertificatesandprivatekeys)

Role Variables
--------------
Available variables are listed below, along with default values (see `defaults/main.yml`):

    # install kibana
    install_kibana: true
    local_package_install: true
    local_packages_directory: /tango/install/reporting-platform/reporting-platform-dependencies/6.2.3
    kibana_package_file: kibana-6.2.3-x86_64.rpm
    
    # deployment view
    install_private_kibana: true
    install_tenant_space: true
    install_master_space: true
    install_tenant_role: true
    master_space: master
    install_public_kibana: true
    install_xpack: true
    
    # security resources
    input_cert: policydemo_com.crt
    input_key: policydemo.com.pem
    
    # kibana configuration
    es_url: http://localhost:9200
    es_user: elastic
    es_password: t3l3com
    kibana_private_ssl_cert: /etc/kibana-private/ssl/policydemo_com.crt
    kibana_private_ssl_key: /etc/kibana-private/ssl/policydemo.com.pem
    kibana_public_ssl_cert: /etc/kibana-public/ssl/policydemo_com.crt
    kibana_public_ssl_key: /etc/kibana-public/ssl/policydemo.com.pem
    
    # kibana rest configuration
    kibana_private_port: 5602
    
    http_or_https: https
    tenant: tango
    kibana_wait_period_in_seconds: 300 
    
    # Install Subscriber dashboards
    install_subscriber_dashboards: false
    
    # Install KPI dashboards
    install_KPI_dashboards: false
    
    # Install protocol dashboards
    install_protocol_dashboards: false    
    
    # Install welcome SMS dashboards
    install_welcome_sms_dashboards: false  
    
    # Install TF VIVO dashbaords
    install_tf_vivo_dashboards: false  

Dependencies
------------
Dependent on the follow Tango roles:
- reporting-base
- elastic
- xpack

Example Playbook
----------------
Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - name: reporting-platform-service playbook
      remote_user: root
      hosts: reporting-platform-service
      roles:
        - reporting-base
        - elastic
        - xpack
        - metricbeat
        - logstash
        - kibana
        
There are certain tasks that are useful to run when running an *Add a Tenant* use-case in production:

    % ansible-playbook reporting-platform-service.yml --tags=import_per_tenant_customized_dashboards --extra-vars="tenant=coltm" -i hosts
    
In this case the *--extra-vars* variables shall over-ride the default *tenant* (see `defaults/main.yml`) and any 
*tenant* defined on site in the *host_vars* or *group_vars* directories.            

License
-------
Tango Telecom Ltd.