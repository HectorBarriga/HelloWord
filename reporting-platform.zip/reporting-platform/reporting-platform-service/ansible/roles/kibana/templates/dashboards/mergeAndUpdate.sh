
# Merge individual dashboard json file to a group dashboards file
# utility uses jq to merge json files

cd 01_master-dashboards
jq -s '.' *.json > ../../tango-master-dashboards.json.j2

cd ../02_master-protocols
jq -s '.' *.json > ../../tango-master-dashboards.json.j2

cd ../03_tango-tenant-dashboards

jq -s '.' *.json > ../../tango-tenant-dashboards.json.j2

cd ../04_tenant-kpi-dashboards

jq -s '.' *.json > ../../tango-tenant-KPI-dashboards.json.j2

cd ../05_tenant-protocols

jq -s '.' *.json > ../../tango-tenant-protocols.tmpl.json.j2

cd ../06_tenant-subscriber-dashboards

jq -s '.' *.json > ../../tango-tenant-subscriber-dashboards.json.j2

cd ../07_tenant-welcomesms-dashboards

jq -s '.' *.json > ../../tango-tenant-welcomesms-dashboards.json.j2

cd ../09_customer_specific

jq -s '.' *.json > ../../tf-vivo-tenant-dashboards.json.j2