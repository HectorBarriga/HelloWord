# Exporting kibana dashboards from site

In addition to the page [Managing Kibana Dashboards](http://confluence:8090/display/DEV/Managing+Kibana+Dashboards), 
this adds more detailed informaiton about the process 

## Kibana dashboards allocation to logical groups

```$xslt
iain:~/devroot/reporting_platform/ansible/roles/kibana/templates/dashboards$ tree
.
├── 01_master-dashboards
│   ├── master-Campaign_Dashboard.json
│   ├── master-Captive_Portal_Remove_Throttling_Offers_Dashboard.json
│   ├── master-Channel_Dashboard.json
│   ├── master-Licences_Dashboard.json
│   ├── master-Notifications_Dashboard.json
│   ├── master-Offers_Dashboard.json
│   ├── master-Plan_Dashboard.json
│   ├── master-Segment_Dashboard.json
│   ├── master-Subscriber_Dashboard.json
│   ├── master-Summary_Dashboard.json
│   ├── master-Traffic_Analysis_Dashboard.json
│   └── master-Trigger_Dashboard.json
├── 02_master-protocols
│   └── master-Protocols_Dashboard.json
├── 03_tango-tenant-dashboards
│   ├── tenantId-Campaign_Dashboard.json
│   ├── tenantId-Channel_Dashboard.json
│   ├── tenantId-dbffce70-e286-11e8-a15a-57aec69ac0d0.json
│   ├── tenantId-Offers_Dashboard.json
│   ├── tenantId-Plan_Dashboard.json
│   ├── tenantId-Segment_Dashboard.json
│   ├── tenantId-Subscriber_Dashboard.json
│   ├── tenantId-Summary_Dashboard.json
│   └── tenantId-Trigger_Dashboard.json
├── 04_tenant-kpi-dashboards
│   ├── tenantId--VIVO_Aggregate_Data_Used_Dashboard.json
│   ├── tenantId--VIVO_General_KPIs_Dashboard.json
│   ├── tenantId--HTTP_API_Access_Dashboard.json
│   ├── tenantId--VIVO_Plan_Purchases_Dashboard.json
│   └── tenantId--VIVO_Rule_Violation_Counts_Dashboard.json
├── 05_tenant-protocols
│   └── tenantId--VIVO_Protocols_Dashboard.json
├── 06_tenant-subscriber-dashboards
│   ├── tenantId--VIVO_Subscriber_Daily_Plan_Dashboard.json
│   ├── tenantId--VIVO_Subscriber_Data_Used_MB_Per_Country_Dashboard.json
│   ├── tenant_id-Subscriber_Daily_Plan_Usage_Dashboard.json
│   ├── tenant_id-Subscriber_Lifecycle_Dashboard.json
│   ├── tenant_id_Subscriber_Billing_Cycle_Plan_Usage_Dashboard.json
│   ├── tenant_id_Subscriber_SMS_Notification_Dashboard.json
│   └── tenantId--VIVO_Subscriber_Throttling_Dashboard.json
├── 07_tenant-welcomesms-dashboards
│   ├── tenantId-LocationUpdate.json
│   └── tenantId-WelcomeSms_Notification.json
├── 08_internal
│   ├── Internal-Data-Analysis1.json
│   ├── Internal-Data-Analysis2.json
│   ├── Internal-DataUsedPerCountryMap.json
│   ├── Internal-Plan-Transaction-GTP-Error.json
│   ├── Internal-RuleViolations.json
│   ├── Internal-SDP-Transaction-Analysis.json
│   ├── Internal-WSMS-Notification-Region-Map.json
│   └── Internal-WSMS-Region-Map.json
├── 09_customer_specific
│   └── brav1--VIVO_Subscriber_SDP_Operations.json
├── dashboards.json
└── README.md


```

## Exporting Kibana dashboards from site


* Follow the procedure [Managing Kibana Dashboards](http://confluence:8090/display/DEV/Managing+Kibana+Dashboards)
* Export dashbords name and ids
```$xslt
curl -XGET -u elastic:t3il3achum 'IPXMIATCDB2_es:9201/.kibana/_search?q=type:dashboard&size=100&pretty' > dashboards.json

curl -XGET -u elastic:t3il3achum 'localhost:9201/.kibana/_search?q=type:dashboard&size=100&pretty' > dashboards.json

```
* Export dashboards according to each logical grouping indivudally
* Each dashboard must be exported by dashboard id

* The following shows which dashboard logical group breakdown


#### Master Dashboards

```bash

curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=master-Licences_Dashboard" >> master-Licences_Dashboard.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=master-Notifications_Dashboard" >> master-Notifications_Dashboard.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=master-Plan_Dashboard" >> master-Plan_Dashboard.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=master-Subscriber_Dashboard" >> master-Subscriber_Dashboard.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=master-Campaign_Dashboard" >> master-Campaign_Dashboard.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=master-Channel_Dashboard" >> master-Channel_Dashboard.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=master-Offers_Dashboard" >> master-Offers_Dashboard.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=master-Segment_Dashboard" >> master-Segment_Dashboard.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=master-Summary_Dashboard" >> master-Summary_Dashboard.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=master-Trigger_Dashboard" >> master-Trigger_Dashboard.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=master-Traffic_Analysis_Dashboard" >> master-Traffic_Analysis_Dashboard.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=d647b010-e673-11e8-a15a-57aec69ac0d0" >> master-Captive_Portal_Remove_Throttling_Offers_Dashboard.json

```
#### Master Protocols

```bash
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=master-115fdbe0-9bde-11e8-8653-4f4d231eec8f" >> master-Protocols_Dashboard.json
```

#### Tenant Dashboards

```$xslt
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=brav1-Plan_Dashboard" >> brav1-Plan_Dashboard.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=brav1-Subscriber_Dashboard" >> brav1-Subscriber_Dashboard.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=brav1-Campaign_Dashboard" >> brav1-Campaign_Dashboard.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=brav1-Channel_Dashboard" >> brav1-Channel_Dashboard.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=brav1-Offers_Dashboard" >> brav1-Offers_Dashboard.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=brav1-Segment_Dashboard" >> brav1-Segment_Dashboard.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=brav1-Summary_Dashboard" >> brav1-Summary_Dashboard.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=brav1-Trigger_Dashboard" >> brav1-Trigger_Dashboard.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=dbffce70-e286-11e8-a15a-57aec69ac0d0" >> brav1-dbffce70-e286-11e8-a15a-57aec69ac0d0.json

```

#### Tenant KPI

```$xslt
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=brav1-e1bcc9b0-971a-11e8-8653-4f4d231eec8f" >> brav1--VIVO_Plan_Purchases_Dashboard.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=36eb65f0-e283-11e8-a15a-57aec69ac0d0" >> brav1--VIVO_Aggregate_Data_Used_Dashboard.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=brav1-8c077710-96fa-11e8-8653-4f4d231eec8f" >> brav1--VIVO_General_KPIs_Dashboard.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=brav1-a8e28140-9704-11e8-8653-4f4d231eec8f" >> brav1--VIVO_Rule_Violation_Counts_Dashboard.json

```


#### Tenant Protocols

```$xslt
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=brav1-115fdbe0-9bde-11e8-8653-4f4d231eec8f" >> brav1--VIVO_Protocols_Dashboard.json

```

#### Tenant Subscriber Dashboards


```$xslt

curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=brav1-35a28830-9595-11e8-8653-4f4d231eec8f" >> brav1--VIVO_Subscriber_Data_Used_MB_Per_Country_Dashboard.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=brav1-8e1b2710-9595-11e8-8653-4f4d231eec8f" >> brav1--VIVO_Subscriber_Data_Used_MB_Per_Plan_Per_Country.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=brav1-9364b7f0-9594-11e8-8653-4f4d231eec8f" >> brav1--VIVO_Subscriber_Daily_Plan_Dashboard.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=brav1-7f489c00-9599-11e8-8653-4f4d231eec8f" >> brav1--VIVO_Subscriber_Throttling_Dashboard.json


curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=b1ef4dc0-7c57-11e9-b900-b754a6308b5b" >> tenant_id-HTTP_API_Access_Dashboard.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=48cf2f00-7c56-11e9-b900-b754a6308b5b" >> tenant_id_Subscriber_Daily_Plan_Usage_Dashboard.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=05775890-7c56-11e9-b900-b754a6308b5b" >> tenant_id_Subscriber_Lifecycle_Dashboard.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=2b14b5c0-7c56-11e9-b900-b754a6308b5b" >> tenant_id_Subscriber_Billing_Cycle_Plan_Usage_Dashboard.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=65cfce20-7c56-11e9-b900-b754a6308b5b" >> tenant_id_Subscriber_SMS_Notification_Dashboard.json

```

#### Tenant WelcomeSMS

```$xslt

curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=brav1-1785f320-edb8-11e8-aa9e-293cab12a94a" >> brav1-LocationUpdate.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=brav1-2bc09580-ee61-11e8-aa9e-293cab12a94a" >> brav1-WelcomeSms_Notification.json

```

#### Internal dashboards

``` bash 

curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=60aaad10-d833-11e8-b024-75caca05def3" >> Internal-Data-Analysis1.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=76d5d3b0-f7bb-11e8-a15a-57aec69ac0d0" >> Internal-Data-Analysis2.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=82437400-f4a5-11e8-a15a-57aec69ac0d0" >> Internal-SDP-Transaction-Analysis.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=76d5d3b0-f7bb-11e8-a15a-57aec69ac0d0" >> Internal-Plan-Transaction-GTP-Error.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=1cd08ae0-14c6-11e9-a59e-27d0bab3c74f" >> Internal-RuleViolations.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=8ae978a0-1a3b-11e9-82ab-c3dbfbae4204" >> Internal-WSMS-Region-Map.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=59d496b0-1a49-11e9-82ab-c3dbfbae4204" >> Internal-WSMS-Notification-Region-Map.json
curl -uelastic:$pss --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=bfcf51a0-2613-11e9-82ab-c3dbfbae4204" >> Internal-DataUsedPerCountryMap.json

```

#### Customer specific

```$xslt
curl -uelastic:$pwd --insecure -XGET "https://localhost:5602/api/kibana/dashboards/export?dashboard=8469d500-feee-11e8-a15a-57aec69ac0d0" >> brav1--VIVO_Subscriber_SDP_Operations.json

```

## Useful utilities

* Replace all occurences of a specific tenantID (e.g. brav1) with ${tenant} in all json files in the current directory

```
 find . -type f -name "*.json" -print0 | xargs -0 sed -i "s/brav1/\$\{\{ tenant\}\}/g"
 
 
  find . -type f -name "*.json" -print0 | xargs -0 sed -i "s/tenant_id/\$\{\{ tenant\}\}/g"

 
```

* Merge indivual JSON docs into an array 
```
jq -s '.' brav1-*.json > jsMerged.json
```

#### Notes

* Two new logical groupings (internal , customer specific) were made as part of the Reporting-Platform 1.5.0 release [DEVIT-1647](http://jira:8080/DEVIT-1647)

#### Suggestions for backlog
* Kibana Dashboard export automation:  It should be straightforward to create a (ansible script) which would automate the export of dashboards