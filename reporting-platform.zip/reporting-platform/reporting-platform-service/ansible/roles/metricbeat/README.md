metricbeat
==========
This role is responsible for generating metrics on system resources and writing them into elastic-search indices
indirectly through logstash.

It is expected that metricbeat shall run on any VM type where you want to measure system resources (e.g. PCC VM, 
GTP_Proxy VM, NH VM, UNS VM, RTE VM &c.). It is expected that this can be managed with an overall group 
(e.g. such as reporting-platform-shipper, reporting-platform-data, reporting-platform-service). 

Certain tasks need only be performed once, such as loading of metric-beat index-templates and importing of supported
metric-beat dashboards. This is controlled via the ansible variable, *metricbeat_once_only_tasks*.

If the *install_metricbeat* variable is set to false then all tasks in this role shall be ignored.

It does the following:

- Local install of metricbeat
- Creates Systemd files including metricbeat.service and a templated metricbeat environment file. In particular, this
environment file is used to tell metricbeat how to find logstash and how to find kibana for importing of its dashboards.
- Creates the Tango customized metricbeat.yml configuration settings
- Import the metric-beat index template allocating the number of shards appropriate for the deployment.
- Import the metric-beat dashboards into Kibana. Presently, only the System dashboards are supported.
- Perform a configuration test and connection test with the configured logstash instances

Requirements
------------
It is required to run the reporting-base, elastic, xpack, kibana and logstash role prior to running this role.

Note: the logstash role is only required to be run if you need to test the metric-beat connection to logstash.

Note: the Kibana role is only required to be run if you need to import the metric-beat dashboards into Kibana. Remember,
this only has to be done once per system, and should not be necessary for every simple metric-beat agent deployment.

Role Variables
--------------
Available variables are listed below, along with default values (see `defaults/main.yml`):

    # install metric-beat
    install_metricbeat: true
    local_package_install: true
    local_packages_directory: /tango/install/reporting-platform/reporting-platform-dependencies/7.3.0
    metricbeat_package_file: metricbeat-7.3.0-x86_64.rpm
    
    # metric-beat once only tasks
    metricbeat_once_only_tasks: false
    
    # elastic-search
    es_host: localhost
    es_port: 9200
    es_user: elastic
    es_password: t3l3com
    
    # metric-beat configuration
    metricbeat_kibana_hosts: "localhost:5602"
    metricbeat_kibana_username: "elastic"
    metricbeat_kibana_password: "t3l3com"
    metricbeat_logstash_hosts: "localhost:5044"
    metricbeat_version: "6.2.3"
    metricbeat_num_shards: 1

Dependencies
------------
Dependent on the follow Tango roles:
- reporting-base
- elastic
- xpack
- logstash
- Kibana

Note: the logstash role is only required to be run if you need to test the metric-beat connection to logstash.

Note: the Kibana role is only required to be run if you need to import the metric-beat dashboards into Kibana. Remember,
this only has to be done once per system, and should not be necessary for every simple metric-beat agent deployment.

Example Playbook
----------------
Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - name: reporting-platform-data playbook
      hosts: reporting-platform-data
      roles:
        - reporting-base
        - elastic
        - xpack
        - metricbeat


License
-------
Tango Telecom Ltd.