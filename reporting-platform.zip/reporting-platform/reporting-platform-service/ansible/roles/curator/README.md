curator
=======
This role is responsible for managing / curating elastic-search indices and aliases.

It is expected that curator shall run on only one data VM co-located with elastic-search. For this reason it is 
recommended that it has a dedicated inventory hosts file or be associated with a dedicated ansible group. 

If the *install_curator* variable is set to false then all tasks in this role shall be ignored.

It does the following:

- Local Installation of curator (--tags=run_install_curator)
- Creates the directory structure necessary for curator (--tags=create_curator_files)
- Tests the curator connection to elastic-search (--tags=check_curator_connection_to_elastic)
- Sets up curator environment (--tags=create_curator_environment)
- Sets up curator cron jobs (--tags=create_curator_cron_jobs)

Requirements
------------
It is required to run the reporting-base, elastic and xpack role prior to running this role.

Role Variables
--------------

Available variables are listed below, along with default values (see `defaults/main.yml`):

    # install curator
    install_curator: true
    local_package_install: true
    local_packages_directory: /tango/install/reporting-platform/reporting-platform-dependencies/6.2.3
    curator_package_file: elasticsearch-curator-5.7.6-1.x86_64.rpm
    
    # elastic-search
    es_port: 9200
    es_user: elastic
    es_password: t3l3com
    
    # Alias Action - Remove Indices from alias
    # Close Indices Action
    curator_uns_to_close: 30
    curator_pcc_to_close: 30
    curator_nginx_access_to_close: 30
    curator_notification_to_close: 30
    curator_license_to_close: 60
    curator_gtp_proxy_to_close: 30
    curator_campaign_manager_to_close: 7
    curator_campaign_manager_stats_to_close: 60
    
    # Delete Indices Action
    curator_monitoring_index_expiry: 14
    curator_metricbeat_index_expiry: 14
    curator_uns_index_expiry: 90
    curator_pcc_index_expiry: 90
    curator_nginx_access_index_expiry: 90
    curator_notification_handler_index_expiry: 90    
    curator_license_index_expiry: 90
    curator_gtp_proxy_index_expiry: 90
    curator_campaign_manager_index_expiry: 14
    curator_campaign_manager_stats_index_expiry: 90

Dependencies
------------
Dependent on the follow Tango roles:

- reporting-base
- elastic
- xpack

Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - name: curator playbook
      hosts: curators
      roles:
        - curator        

License
-------
Tango Telecom Ltd.
