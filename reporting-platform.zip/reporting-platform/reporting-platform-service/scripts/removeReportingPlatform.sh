#!/bin/bash

## Remove traces of ELK from machine - useful for testing on VMs that don't support reversion to SNAPSHOT/baseline stater

cd /etc/systemd/system
sudo systemctl stop logstash
sudo systemctl stop filebeat
sudo systemctl stop kibana.private
sudo systemctl stop kibana.public
sudo systemctl stop elasticsearch.master
sudo systemctl stop elasticsearch.data

# remove packages

#remove /etc/logstash
#remove /etc/filebeat
yum list installed | grep kibana

yum -y remove kibana
yum -y remove logstash
yum -y remove filebeat
yum -y remove elasticsearch

## Remove directories

rm -rf /etc/filebeat
rm -rf /etc/logstash
rm -rf /etc/elasticsearch-master
rm -rf /etc/elasticsearch-data
rm -rf /etc/elasticsearch/
rm -rf /etc/metricbeat


rm -f /etc/sysconfig/filebeat
rm -f /etc/sysconfig/elasticsearch.data
rm -f /etc/sysconfig/elasticsearch.master


rm -rf /var/log/elasticsearch.data
rm -rf /var/log/elasticsearch.master
rm -rf /var/log/filebeat
rm -rf /var/log/kibana.private
rm -rf /var/log/kibana.public
rm -rf /var/log/metricbeat


rm -rf /var/run/elasticsearch.data
rm -rf /var/run/elasticsearch.master
rm -rf /var/run/filebeat
rm -rf /var/run/kibana.private
rm -rf /var/run/kibana.public
rm -rf /var/run/metricbeat


rm -f /usr/share/elasticsearch/bin/elasticsearch-start-env
rm -rf /usr/share/elasticsearch
rm -rf /usr/share/logstash/
rm -rf /usr/share/kibana
rm -rf /usr/share/kibana-private
rm -rf /usr/share/kibana-public
rm -rf /usr/share/filebeat

rm -rf /tango/install
rm -rf /tango/data/elasticsearch
