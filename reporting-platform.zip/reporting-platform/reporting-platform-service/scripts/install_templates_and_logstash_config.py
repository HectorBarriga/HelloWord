#!/usr/bin/env python

import argparse
import collections
import json
import os

from elasticsearch import Elasticsearch
from elasticsearch import RequestError
from subprocess import Popen
from subprocess import PIPE

Template = collections.namedtuple('Template', 'template_file template_name')

es = None
elasticsearch_templates_source_dir = '../templates/elasticsearch/'
logstash_config_source_dir = '../configuration/logstash/conf.d/'
logstash_config_dest_dir = '/etc/logstash/conf.d/'

elasticsearch_template_map = {
        'PCC': [ 
            Template('pcc_spcm_plan_template_base.json', 'pcc_spcm_plan_template_base'),
            Template('pcc_spcm_sub_lifecycle_base_template.json', 'pcc_spcm_sub_lifecycle_base_template'),
            Template('pcc_data_usage_template_base.json', 'pcc_data_usage_template_base'),
            Template('pcc_rules_counters_template_base.json', 'pcc_rules_counters_template_base')
            ],
        'PCC_DB': [ 
            Template('pcc_stats_template_base.json', 'pcc_stats_template_base') 
            ],
        'RTPE': [
            Template('campaign_manager_base_template.json','campaign_manager_base_template'),
            Template('campaign_manager_stats_base_template.json', 'campaign_manager_stats_base_template')
            ],
       'SUB_LC': [
            Template('pcc_spcm_sub_lifecycle_base_template.json','pcc_spcm_sub_lifecycle_base_template'),
         ],
        'GTP': [
            Template('gtp_proxy_base_template.json','gtp_proxy_base_template'),
            Template('gtp_proxy_stats_base_template.json','gtp_proxy_stats_base_template'),
            Template('gtp_proxy_datausage_stats_base_template.json', 'gtp_proxy_datausage_stats_base_template')
        ],
        'NGINX': [
            Template('nginx_base_template.json','nginx_base_template')
        ],
        'NH': [
            Template('notification_hdlr_base_template.json','notification_hdlr_base_template')
            ],
        'LIC': [
            Template('licence_template_base.json','licence_template_base')
            ],
        'UNS': [
            Template('uns_base_template.json','uns_base_template')
            ],
        'HRG': [
            Template('hrg_template_base.json','hrg_base_template')
            ],
        'WSMS': [
            Template('location_update_base_template.json','location_update_base_template'),
            Template('welcomenotifications_base_template.json','welcomenotifications_base_template')
        ]
        }

logstash_config_map = {
        'PCC': [
            'logstash-pcc.conf'
            ],
        'RTPE': [
            'logstash-rtpe.conf'
            ],
        'GTP': [
            'logstash-gtp-proxy.conf',
            'logstash-gtp-proxy-stats.conf'
            ],
        'NGINX': [
            'logstash-nginx.conf'
            ],
        'NH': [
            'logstash-nh.conf'
            ],
        'UNS': [
            'logstash-uns.conf'
            ],
        'HRG': [
            'logstash-hrg.conf'
            ],
        'WSMS': [
            'logstash-wsms.conf'
            ]
        }

def install_elasticsearch_pcc_db_template():
    global es
    global elasticsearch_templates_source_dir

    template = elasticsearch_template_map['PCC_DB'][0]
    with open(elasticsearch_templates_source_dir + template.template_file) as f:
        template_body = f.read()
    es.indices.put_template(body=template_body, name=template.template_name)

def install_elasticsearch_template(template_key):
    global es
    global elasticsearch_templates_source_dir

    templates = elasticsearch_template_map[template_key]
    for template in templates:
        with open(elasticsearch_templates_source_dir + template.template_file) as f:
            template_body = f.read()
        es.indices.put_template(body=template_body, name=template.template_name)

def install_logstash_config(config_key, install_pcc_db):
    global logstash_config_source_dir
    global logstash_config_dest_dir

    if not os.path.isdir(logstash_config_dest_dir):
         raise Exception("Installation error, logstash configuration directory does not exist") 

    if config_key not in logstash_config_map:
        return

    config_files = logstash_config_map[config_key]
    for config_file in config_files:
        if config_file == 'logstash-pcc-db.conf' and not install_pcc_db:
            continue
        cmd = ['cp', logstash_config_source_dir + '/' + config_file, logstash_config_dest_dir + '/' + config_file]
        p = Popen(cmd, stdout=PIPE, stderr=PIPE)
        stdout, stderr = p.communicate()

        cmd = ['chmod', 'a+r', logstash_config_dest_dir + '/' + config_file]
        p = Popen(cmd, stdout=PIPE, stderr=PIPE)
        stdout, stderr = p.communicate()

def usage_msg():
    return '''install_templates_and_logstash_config.py [-h] [-a Elasticsearch IP Address]
                                          [-t [Space-delimited list of template names to install, Supported values PCC RTPE GTP NH LIC UNS HRG WSMS]]
                                          [-b Flag to denote if BI & Lists should be configured]

    '''

def main():
    global es
    global elasticsearch_templates_source_dir
    global logstash_config_source_dir
    parser = argparse.ArgumentParser(description='AnalyticsIngestion installation script', usage=usage_msg())
    parser.add_argument("-a", "--es-ip-address",default="127.0.0.1",metavar='Elasticsearch IP Address')
    parser.add_argument("-u", "--es-username",metavar='Elasticsearch Username')
    parser.add_argument("-p", "--es-password",metavar='Elasticsearch Password')
    parser.add_argument("-t", "--templates", nargs='*', default=[], metavar=("Space-delimited list of template names to install","..."), choices=['PCC', 'RTPE', 'GTP', 'NH', 'LIC', 'UNS', 'HRG','WSMS','NGINX','SUB_LC'])
    parser.add_argument("-b", action='store_true', help="Flag to denote if BI & Lists should be configured")
    parser.add_argument("-d", action='store_true', help="Flag to denote if PCC DB Ingestion should be configured")
    parser.add_argument("-c", "--templates_config_dir",metavar='Templates Configuration directory')
    parser.add_argument("-ls", "--logstash_config_dir",metavar='Logstash Configuration directory')

    try:
        args = parser.parse_args()

        if args.es_username and args.es_password:
            es = Elasticsearch(args.es_ip_address, http_auth=(args.es_username, args.es_password))
        else:
            es = Elasticsearch(args.es_ip_address)

        if args.templates_config_dir:
            elasticsearch_templates_source_dir = args.templates_config_dir
            if elasticsearch_templates_source_dir[:-1] != '/':
                elasticsearch_templates_source_dir += '/'

        if args.logstash_config_dir:
            logstash_config_source_dir = args.logstash_config_dir
            if logstash_config_source_dir[:-1] != '/':
                logstash_config_source_dir += '/'

        if args.d:
            install_elasticsearch_pcc_db_template()

        for template in args.templates:
            install_elasticsearch_template(template)
            install_logstash_config(template, args.d)

        cmd = ['cp', logstash_config_source_dir + '/logstash-beats-input.conf', '/etc/logstash/conf.d']
        p = Popen(cmd, stdout=PIPE, stderr=PIPE)
        stdout, stderr = p.communicate()

        if 'PCC' in args.templates:
            cmd = ['cp', logstash_config_source_dir + '/plmnIdToMccMnc.csv', '/etc/logstash']
            p = Popen(cmd, stdout=PIPE, stderr=PIPE)
            stdout, stderr = p.communicate()

            cmd = ['chmod', 'a+r', '/etc/logstash/plmnIdToMccMnc.csv']
            p = Popen(cmd, stdout=PIPE, stderr=PIPE)
            stdout, stderr = p.communicate()

            cmd = ['cp', logstash_config_source_dir + '/vplmnToPlmnId.csv', '/etc/logstash']
            p = Popen(cmd, stdout=PIPE, stderr=PIPE)
            stdout, stderr = p.communicate()

            cmd = ['chmod', 'a+r', '/etc/logstash/vplmnToPlmnId.csv']
            p = Popen(cmd, stdout=PIPE, stderr=PIPE)
            stdout, stderr = p.communicate()

        if 'GTP' in args.templates:
            cmd = ['cp', logstash_config_source_dir + '/traffic_class.yaml', '/etc/logstash']
            p = Popen(cmd, stdout=PIPE, stderr=PIPE)
            stdout, stderr = p.communicate()

            cmd = ['chmod', 'a+r', '/etc/logstash/traffic_class.yaml']
            p = Popen(cmd, stdout=PIPE, stderr=PIPE)
            stdout, stderr = p.communicate()

            cmd = ['cp', logstash_config_source_dir + '/mccmnc_vplmn.csv', '/etc/logstash']
            p = Popen(cmd, stdout=PIPE, stderr=PIPE)
            stdout, stderr = p.communicate()

            cmd = ['chmod', 'a+r', '/etc/logstash/mccmnc_vplmn.csv']
            p = Popen(cmd, stdout=PIPE, stderr=PIPE)
            stdout, stderr = p.communicate()

            cmd = ['cp', logstash_config_source_dir + '/ggsn_cause_code_mappings.csv', '/etc/logstash']
            p = Popen(cmd, stdout=PIPE, stderr=PIPE)
            stdout, stderr = p.communicate()

            cmd = ['chmod', 'a+r', '/etc/logstash/ggsn_cause_code_mappings.csv']
            p = Popen(cmd, stdout=PIPE, stderr=PIPE)
            stdout, stderr = p.communicate()

            cmd = ['cp', logstash_config_source_dir + '/ggsn_return_code_mappings.csv', '/etc/logstash']
            p = Popen(cmd, stdout=PIPE, stderr=PIPE)
            stdout, stderr = p.communicate()

            cmd = ['chmod', 'a+r', '/etc/logstash/ggsn_return_code_mappings.csv']
            p = Popen(cmd, stdout=PIPE, stderr=PIPE)
            stdout, stderr = p.communicate()

        if 'NH' in args.templates:
            cmd = ['cp', logstash_config_source_dir + '/nh_*.csv', '/etc/logstash']
            p = Popen(' '.join(cmd), shell=True) 

            cmd = ['chmod', 'a+r', '/etc/logstash/nh_*.csv']
            p = Popen(' '.join(cmd), shell=True)


        if args.b:
            print "install BI & lists"

    except AttributeError:
        parser.print_help()
        exit
    except Exception as e:
        print "Error " + str(e)
        exit

if __name__ == '__main__':
    main()




