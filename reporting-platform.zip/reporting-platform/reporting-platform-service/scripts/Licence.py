#!/usr/bin/env python

import argparse
from datetime import datetime
from elasticsearch import Elasticsearch
from elasticsearch.helpers import scan
import json
import logging

logger = logging.getLogger(__name__)

es = None
es_ingest = None

def __query_licence_usage(spcm_pcc_alias, date, max_plan_validity):
    '''
    Query the number of licences used against the specifed PCC SPCM Alias in Elasticsearch.

    Licences are calculated per-calendar month.

    Plans which span multiple months, between activation_date and expiry_date are also included in the licence 
    usage count. The maximum span of any plans is given by max_plan_validity. Any plans exceeding this
    interval will be ommitted from the licence count.

    A subscriber can only use, at most, a single licence "slot" i.e. if the subscriber has purchased/consumed
    multiple plans during the Licencing interval this will count as only 1 Licence "slot" being used.

    The varous criteria for assessing Licence usage are documented at http://confluence:8090/display/DEV/Licensing
    
    The lucene queria matching the scenarios described in the aforementioned link are as follows (assuming Licence
    usage is being queried for the current calendar month)

    Scenario 1 & 2: (txn_type: 2 AND activation_date:[now/M TO now/M+1M})
    Scenario 3: (txn_type: 5 AND expiry_date:[now/M TO now/M+1M})
    Scenario 4: (txn_type: 2 AND activation_date:[now/M-6M TO now/M} AND expiry_date:[now/M+1M TO now/M+6M})
    Scenario 5: (txn_type: 8 AND cdr_gen_date:[now/M TO now/M+1M})

    Args:
        spcm_pcc_alias (str): The name of the elasticsearch alias to query for licence usage
        date (str): The date (YYYY-MM-DD) of the month for which licence usage is to be calculated
        max_plan_validity (int): The maximium interval, between plan_activation and plan_expiry, when counting licence usage
            by multi-month plans.

    Returns:
        set(string): A set of strings representing the MSISDNs that consumed a licence slot during the given query interval

    '''
    if date != "now":
        date = date + "||"

    try:
        scan_result = scan(es, 
                query={
                    "query": 
                    {
                        "query_string": 
                        {
                            "query": 
                            "(\
                                    (txn_type: 0 AND purchase_date:[" + date + "/M TO " + date + "/M+1M}) OR\
                                    (txn_type: 2 AND activation_date:[" + date + "/M TO " + date + "/M+1M}) OR\
                                    (txn_type: 5 AND expiry_date:[" + date + "/M TO " + date + "/M+1M}) OR\
                                    (txn_type: 2 AND activation_date:[" + date + "/M-" + str(max_plan_validity/2) + "M TO " + date + "/M} AND expiry_date:[" + date + "/M+1M TO " + date + "/M+6M}) OR\
                                    (txn_type: 8 AND cdr_gen_date:[" + date + "/M TO " + date +"/M+1M}) \
                            )"
                        }
                    }
                },
                _source_include= [ "msisdn" ],
                index=spcm_pcc_alias,
                doc_type="doc")

        scan_set = { hit["_source"]["msisdn"] for hit in scan_result }
    except Exception as e:
        raise Exception("Licence Usage Query failed, Exception caught  " + str(e))

    return scan_set

def __generate_licence_usage_report(licence_usage_results, licence_usage_report, date, exclude_date):
    '''
    Write the Licence Usage report to a text file, in the specified location. The filename of the 
    Licence Usage report may be controlled via various parameters.
    
    Args:
        licence_usage_results (set(str)): A set containing each MSISDN using a Licence "slot"
        licence_usage_report (str): The absolite filename of the Licence Usage Report
        date (str): The date (YYYY-MM-DD) of the month for which the Licence Usage being generated. By default this will be included
            in the generated Licence Usage Report filename.
        exclude_date (bool): For test purposes only. Exclude all date information from the generated Licence Usage Report
            filename

    Returns:

    '''
    if not exclude_date:
        report_gen_date = datetime.now()
        report_date_suffix = '_' + datetime.strptime(date, "%Y-%m-%d").strftime("%B") + '_' + report_gen_date.strftime('%H%M%S_%d%m%Y')
        suffix_idx = licence_usage_report.rfind('.')
        if suffix_idx == -1:
            licence_usage_report = licence_usage_report + report_date_suffix 
        else:
            licence_usage_report = licence_usage_report[:suffix_idx] + report_date_suffix + licence_usage_report[suffix_idx:]

    with open(licence_usage_report, 'w') as f:
        f.write("Licences Used: " + str(len(licence_usage_results)) + "\n")
        f.write("\nSubscribers using licences:" + "\n") 
        f.write("\n".join(list(licence_usage_results)))


def __index_licence_usage_data(licence_usage_results):
    '''
    Ingests a JSON document detailing the current number of Licences used on the platform to the
    "licence-YYYY.MM.DD" Elasticsearch index. This index is used for the Kibana Licencing Visualization.
    
    Args:
        licence_usage_results (set(str)): A set containing each MSISDN using a Licence "slot"

    Returns:

    '''
    try:
        data = {}
        print(str(licence_usage_results))
        data['licences_used'] = len(licence_usage_results)
        data['cdr_timestamp'] = datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S') + 'Z'
        json_data = json.dumps(data)
        es_ingest.index(index="master-licence" + datetime.now().strftime('-%Y.%m.%d'), doc_type="doc", body=json_data)
    except Exception as e:
        raise Exception("Licence Usage Ingestion failed, Exception caught  " + str(e))


def main():
    global es
    global es_ingest

    parser = argparse.ArgumentParser(description='Licence Usage Reporting and Ingestion script')
    parser.add_argument("-e", "--es_ip_address",metavar='IP Address(es) and port of the Elasticsearch Co-ordinator node(s)',default="127.0.0.1:9200")
    parser.add_argument("-i", "--es_ingest_ip_address",metavar='IP Address(es) and port of the Elasticsearch Data node(s) for ingestion',default="127.0.0.1:9200")
    parser.add_argument("-d", "--date",metavar='Date to be used as the basis of the Licence Usage Report, YYYY-MM-DD, defaults to current month')
    parser.add_argument("-u", "--es_user",metavar='Elasticsearch Username')
    parser.add_argument("-s", "--es_password",metavar='Elasticsearch Password/Secret')
    parser.add_argument("-a", "--alias_name",metavar='The SPCM Plan Elasticsearch Alias Name',default="master-pcc")
    parser.add_argument("-r", "--report",metavar='Absolute filename of the generate Licence Usage Report')
    parser.add_argument("-x", "--exclude_date",action='store_true',default=False)
    parser.add_argument("-v", "--max_plan_validity",metavar='The maximum span between an activation date and expiry date, MUST be an even number', type=int, default=12)

    try:
        args = parser.parse_args()

        if args.max_plan_validity % 2:
            raise Exception("Invalid arg passed for max_plan_validity, MUST be an even number")

        date = "now"
        if args.date:
            try:
                datetime.strptime(args.date, '%Y-%m-%d')
                date = args.date
            except ValueError:
                raise ValueError("Incorrect data format, MUST be YYYY-MM-DD")

        es_url_prefix = 'http://'
        if args.es_user and args.es_password:
            es_url_prefix = 'http://' + args.es_user + ':' + args.es_password  + '@'

        es_node_addresses = args.es_ip_address.split(',')
        es = Elasticsearch(['{0}{1}'.format(es_url_prefix, node_addr) for node_addr in es_node_addresses])

        es_data_node_addresses = args.es_ingest_ip_address.split(',')
        es_ingest = Elasticsearch(['{0}{1}'.format(es_url_prefix, node_addr) for node_addr in es_data_node_addresses])

        licence_usage_results = __query_licence_usage(args.alias_name, date, args.max_plan_validity)
        if args.report:
            __generate_licence_usage_report(licence_usage_results, args.report, date, args.exclude_date)
        else:
            __index_licence_usage_data(licence_usage_results)

    except AttributeError as e:
        print "Error  " +str(e)
        parser.print_help()
        exit
    except Exception as e:
        print str(e)
        exit

if __name__ == '__main__':
    main()

