#!/bin/bash

# Script to run on jump server to reporting platform to test VM
# Script was run in stages (manually)
# Script will be used later to help form a fully automated deployment pipeline
# Not for production use - development use only..
# See http://confluence:8090/x/Pij6AQ for more information


## First add tango to sudo group - then logout

su << EOF
t3l3com
whoami
usermod -aG wheel tango
echo "Not a good idea to have a password encoded in plain text"
EOF
exit


# Set variables
JUMP_SERVER=iel-dev-ajs-vm1
VERSION=3.0.0
TARGET_VM=iel-dev-rep-vm3
TENANT=brav1
CO_ROLES_REPO=http://tangier/repo/cust_op/sites_automation/Robi/tags/1.0.3/roles
AUTOMATION_ROLES_REPO=http://tangier/repo/tango-automation/ansible/generic/trunk/roles
KIBANA_SECURITY_REPO=http://tangier/repo/docker/tango-kibana/trunk/security
# http://tangier/repo/docker/reporting-platform/tags/reporting-platform-$VERSION
REP_REPO=http://tangier/repo/docker/reporting-ansible/trunk
SVN_USER=jenkins
SVN_PWD=jenkins+100
PLAYBOOKS=/tango/end-to-end/ansible/playbooks
JDK=jdk-12.0.2

# Install required software on jump server if not already installed
sudo yum install -y wget
sudo yum install -y unzip
sudo yum install -y epel-release
sudo yum install -y ansible
sudo yum -y install -y subversion

# Install docker / docker compose on jump server
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
sudo usermod -aG docker tango
sudo echo '{ "insecure-registries" : ["zion:5000"] }' > /etc/docker/daemon.json
sudo curl -L "https://github.com/docker/compose/releases/download/1.24.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose
systemctl restart docker
docker --version
docker-compose --version


# Some work to do around this still TODO
ssh-keygen -f ~/.ssh/id_rsa -t rsa -N ''
sudo ssh-copy-id -i ~/.ssh/id_rsa.pub tango@$TARGET_VM
sudo ssh-copy-id -i ~/.ssh/id_rsa.pub root@$TARGET_VM

# Create directory where ansible scripts will be stored
sudo mkdir /tango
sudo chown -R tango:tango /tango
mkdir -p /tango/end-to-end/ansible

# Checkout repos
svn co --non-interactive --username $SVN_USER --password $SVN_PWD $REP_REPO/ansible /tango/end-to-end/ansible
svn co --non-interactive --username $SVN_USER --password $SVN_PWD $REP_REPO/scripts /tango/end-to-end/scripts
svn co --non-interactive --username $SVN_USER --password $SVN_PWD $CO_ROLES_REPO /tango/end-to-end/co_roles

svn co --non-interactive --username $SVN_USER --password $SVN_PWD $AUTOMATION_ROLES_REPO /tango/end-to-end/automation_roles
svn co --non-interactive --username $SVN_USER --password $SVN_PWD $KIBANA_SECURITY_REPO /tango/end-to-end/security

# Kibana needs .pem files
svn export --non-interactive --username $SVN_USER --password $SVN_PWD --force http://tangier/repo/docker/tango-kibana/trunk/security /tango/end-to-end/ansible/roles/kibana/files/


chmod u+x  /tango/end-to-end/scripts/prepare_deployment_view.sh

# Prepare deployment view - downloads artifacts from tanger
mkdir -p /tango/install
cp /tango/end-to-end/scripts/prepare_deployment_view.sh /tango/install
cd /tango/install
./prepare_deployment_view.sh -dd

## Only relevant for reporting platform 6.3.2 deployments
## keytool fix ( on target VM)
echo -e "# User specific aliases and functions
export PATH=$PATH:/usr/java/$JDK/bin
export JAVA_HOME=/usr/java/latest
" > ~/.bash_profile

## copy cert
cp /tango/end-to-end/security/policydemo_com.crt /tango/end-to-end/ansible/playbooks/

# Prepare ansible environment

## Prepare hosts file
cd $PLAYBOOKS
echo -e "[reporting-platform-data]\n$TARGET_VM" > $PLAYBOOKS/host-data
echo -e "[reporting-platform-service]\n$TARGET_VM" > $PLAYBOOKS/host-service
echo -e "[reporting-platform-shipper]\n$TARGET_VM" > $PLAYBOOKS/host-shipper

## Update Ansible configuration ansible.cfg (as root user)
echo -e '[defaults]\nroles_path = ${PWD}/../roles:${PWD}/../../co_roles:${PWD}/../../automation_roles' > /tango/end-to-end/ansible/playbooks/ansible.cfg

# Run ansible scripts

cd $PLAYBOOKS

## Install Java
ansible-playbook reporting-platform-data_01_base.yml --extra-vars="delegate_to_host=$TARGET_VM hostname=$TARGET_VM jdk_extracted_directory:=jdk-12.0.2" -i host-data

## Install Elastic search
ansible-playbook reporting-platform-data_02_elastic.yml --extra-vars="delegate_to_host=$TARGET_VM hostname=$TARGET_VM tenant=$TENANT" -i host-data

## Install base and tenant templates

## Install base and tenant templates
ansible-playbook reporting-platform-data_02_elastic.yml --extra-vars="install_elasticsearch=false install_base_templates=true install_tenant_templates=true delegate_to_host=$TARGET_VM hostname=$TARGET_VM tenant=brav1" -i host-data
ansible-playbook reporting-platform-data_02_elastic.yml --extra-vars="install_elasticsearch=false install_base_templates=false install_tenant_templates=true delegate_to_host=$TARGET_VM hostname=$TARGET_VM tenant=tango" -i host-data

# ansible-playbook reporting-platform-data_02_elastic.yml --extra-vars="install_elasticsearch=false install_base_templates=false install_tenant_templates=true delegate_to_host=$TARGET_VM hostname=$TARGET_VM tenant=brav3" -i host-data



## If running subsequent times the es_original_password field should be overriden
# ansible-playbook reporting-platform-data_02_elastic.yml --extra-vars="install_elasticsearch=false install_base_templates=true install_tenant_templates=true delegate_to_host=$TARGET_VM es_original_password=t3l3com hostname=$TARGET_VM tenant=brav1" -i host-data

## Install xpack roles
ansible-playbook reporting-platform-data_03_xpack.yml --extra-vars="install_xpack=true delegate_to_host=$TARGET_VM hostname=$TARGET_VM" -i host-data

## Install curator
ansible-playbook reporting-platform-data_04_curator.yml --extra-vars="delegate_to_host=$TARGET_VM hostname=$TARGET_VM" -i host-data

## Install Kibana
ansible-playbook reporting-platform-service_01_kibana.yml --extra-vars="install_jdk=false install_kibana=true delegate_to_host=$TARGET_VM es_original_password=t3l3com hostname=$TARGET_VM" -i host-service

## Create Kibana space
ansible-playbook reporting-platform-service_01_kibana.yml --extra-vars="install_jdk=false install_kibana=false install_tenant_space=false install_master_space=true delegate_to_host=$TARGET_VM es_original_password=t3l3com hostname=$TARGET_VM" -i host-service
ansible-playbook reporting-platform-service_01_kibana.yml --extra-vars="install_jdk=false install_kibana=false install_tenant_space=true install_master_space=false delegate_to_host=$TARGET_VM es_original_password=t3l3com hostname=$TARGET_VM tenant=brav1" -i host-service
ansible-playbook reporting-platform-service_01_kibana.yml --extra-vars="install_jdk=false install_kibana=false install_tenant_space=true install_master_space=false delegate_to_host=$TARGET_VM es_original_password=t3l3com hostname=$TARGET_VM tenant=tango" -i host-service


## Import Kibana dashboards
ansible-playbook reporting-platform-service_01_kibana.yml --extra-vars="install_jdk=false install_kibana=false install_tenant_dashboards=true install_subscriber_dashboards=true install_KPI_dashboards=true install_protocol_dashboards=true install_welcome_sms_dashboards=true install_tf_vivo_dashboards=true delegate_to_host=$TARGET_VM es_original_password=t3l3com hostname=$TARGET_VM tenant=brav1" -i host-service
ansible-playbook reporting-platform-service_01_kibana.yml --extra-vars="install_jdk=false install_kibana=false install_tenant_dashboards=true install_subscriber_dashboards=true install_KPI_dashboards=true install_protocol_dashboards=true install_welcome_sms_dashboards=true install_tf_vivo_dashboards=true delegate_to_host=$TARGET_VM es_original_password=t3l3com hostname=$TARGET_VM tenant=tango" -i host-service
ansible-playbook reporting-platform-service_01_kibana.yml --extra-vars="install_jdk=false install_kibana=false install_tenants_dashboards=true install_subscriber_dashboards=false install_KPI_dashboards=false install_protocol_dashboards=false install_welcome_sms_dashboards=false delegate_to_host=$TARGET_VM es_original_password=t3l3com hostname=$TARGET_VM tenant=brav1" -i host-service

## Install tenants role after space install
ansible-playbook reporting-platform-data_03_xpack.yml --extra-vars="install_xpack=false install_xpack_create_role_for_tenant=true delegate_to_host=$TARGET_VM hostname=$TARGET_VM tenant=brav1" -i host-data

## Install logstash
ansible-playbook reporting-platform-service_02_logstash.yml --extra-vars="delegate_to_host=$TARGET_VM es_original_password=t3l3com hostname=$TARGET_VM tenant=brav1" -i host-service

#ansible-playbook reporting-platform-data_05_metricbeat.yml --extra-vars="delegate_to_host=$TARGET_VM hostname=$TARGET_VM metricbeat_kibana_hosts=localhost:5602 metricbeat_logstash_hosts=localhost:5044" -i host-data

# Install docker
ansible-playbook reporting-platform-data_06_docker.yml --extra-vars="delegate_to_host=$TARGET_VM hostname=$TARGET_VM docker_users=tango" -i host-data

## Install metricebeat

ansible-playbook reporting-platform-shipper_01_metricbeat.yml --extra-vars="delegate_to_host=$TARGET_VM hostname=$TARGET_VM" -i host-shipper

## Install logstash
# logstash needs to be up prior to filebeat

## Install filebeat
ansible-playbook reporting-platform-shipper_02_filebeat.yml --extra-vars="delegate_to_host=$TARGET_VM hostname=$TARGET_VM" -i host-shipper

## Startup nginx container on jump server
cd /tango/end-to-end/ansible

TARGET_IP=`getent hosts $TARGET_VM | awk '{print $1}'`
echo "KIBANA_IP=$TARGET_IP" > .env
docker-compose up -d

