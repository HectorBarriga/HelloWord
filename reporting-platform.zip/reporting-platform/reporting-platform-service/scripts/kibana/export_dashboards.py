#!/usr/bin/env python

""" METL (Machine-learning ETL) CLI

This is the CLI (Command Line Interface for the Tango METL component)

The CLI MUST be invoked with both mandatory command-line arguments
Example:
    metl.py -c config/metl.yaml -l config/logging.conf

"""

import argparse
import copy
import json
import logging
import os
import re
import requests
import sys
import time

DEFAULT_KIBANA_URL = 'https://localhost:5601'
DEFAULT_KIBANA_TEMPLATE_DIR = '.'

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class QueryException(Exception):
    pass

def create_http_session(username, password):
    """create_http_session
    :param str username: The username to use for basic http authentication
    :param str password: The password to use for basic http authentication

    This method creates a pyhthon reqests session object using the provided parameters for http basic authentication
    """
    s = requests.session()
    s.auth = (username, password)
    return s


def retrieve_dashboard_id(session, kibana_url, dashboard):
    """retrieve_dashboard_id
    :param object session: The requests session object to use when submitting http requests
    :param str kibana_url: The requests session object to use when submitting http requests
    :param str dashboard: The 

    method retrieves the id of the dashboard to be exported via the (beta) Kibana saved_objects api 
    """

    try:
        r = session.get(kibana_url + '/api/saved_objects?type=dashboard&search_fields=title&search=' + dashboard, verify=False)        
        if not r:
            raise QueryException("Error querying dashboard id: {}".format())

        json_response = r.json()
        if logging.getLogger().getEffectiveLevel() == logging.DEBUG:
            for _object in json_response['saved_objects']:
                logging.debug("retrieve_dashboard_id: title {} id {}".format(_object['attributes']['title'], _object['id']))

        if json_response['total'] == 0:
            raise QueryException("Unexpected number of hits, {}, for dashboard id query".format(json_response['hits']['total']))

        return json_response['saved_objects'][0]['id']
    except requests.exceptions.ConnectionError as e:
        raise e


def export_dashboard(session, kibana_url, dashboard_id):
    """export_dashboard
    :param object session: The requests session object to use when submitting http requests
    :param str kibana_url: The requests session object to use when submitting http requests
    :param str dashboard_id: The id of the dashboard (inclusing all visualizations, index patterns, saved searches) 
    to be exported from Kibana via the export API

    Export the JSON document for the dashboard associated with the given id. All Saved Objects associated with the dashboard 
    will be exported
    """

    try:
        r = session.get(kibana_url + '/api/kibana/dashboards/export?dashboard=' + dashboard_id, verify=False)        
        if not r:
            raise QueryException("Error querying dashboard id: {}".format())

        return r.json()
    except requests.exceptions.ConnectionError as e:
        raise e


def generate_dashboard_template(dashboard_type="master", dashboard=""):
    """generate_dashboard_template
    :param str dashboard_type: The type [master|tenant] of the dashboard template to generate i.e. this param
    will dictate which prefix is used in all od the template ids
    :param object dashboard: The de-serialized JSON for the dashboard

    This method transforms the dashboard, provided in the dashboard parameter, for deployment in production.
    The transformation simply entails prefixing the id attribute of all Kibana SavedObjects in the dashboard with
    either "master" or ${tenantId}, depending on the specified dashboard_type
    """

    logging.debug("Initial dashboard {}".format(dashboard))
    if dashboard_type == "master":
        id_prefix = "master-"
    else:
        id_prefix = "${tenantId}-"

    template_dashboard = dashboard
    for dash_object in template_dashboard['objects']:
        if dash_object['id'] == None:
            raise QueryExcpetion("Unexpected dashboard JSON format {}".format(dash_object))

        dash_object['id'] = id_prefix + dash_object['id'][dash_object['id'].index('-') +1:]
        # use a closure here to get access to id_prefix
        def _replace_id(matchobj):
            return matchobj.group(1) + id_prefix + matchobj.group(2)[matchobj.group(2).index('-')+1:] + "\""

        def _replace_index_timelion(matchobj):
            return matchobj.group(1) + id_prefix + matchobj.group(2)[matchobj.group(2).index('-')+1:] + "\'"

        if dash_object['type'] == 'dashboard':
            panels_json = dash_object['attributes']['panelsJSON']
            dash_object['attributes']['panelsJSON'] = re.sub('(\"id\\\":\s?\\\")(?P<id>.*?)(\\\")', _replace_id, panels_json)
            dash_object['attributes']['title'] = id_prefix + dash_object['attributes']['title'][dash_object['attributes']['title'].find('-') +1:]
        if dash_object['type'] == 'visualization':
            query_string = dash_object['attributes']['kibanaSavedObjectMeta']['searchSourceJSON']
            dash_object['attributes']['kibanaSavedObjectMeta']['searchSourceJSON'] = re.sub('(\"index\\":\s?\\")(?P<index>.*?)(\\")', _replace_id, query_string)

            query_string = dash_object['attributes']['kibanaSavedObjectMeta']['searchSourceJSON']
            dash_object['attributes']['kibanaSavedObjectMeta']['searchSourceJSON'] = re.sub('(\"id\\":\s?\\")(?P<index>.*?)(\\")', _replace_id, query_string)

            query_string = dash_object['attributes']['visState']
            dash_object['attributes']['visState'] = re.sub('(index=\')(?P<index>.*?)(\')', _replace_index_timelion, query_string)

            dash_object['attributes']['title'] =  id_prefix + dash_object['attributes']['title']

            dash_object['attributes']['description'] ="${tenantId}"

            if 'savedSearchId' in dash_object['attributes']:
                dash_object['attributes']['savedSearchId'] = id_prefix + dash_object['attributes']['savedSearchId'][dash_object['attributes']['savedSearchId'].find('-') +1:]

        if dash_object['type'] == 'index-pattern':
            index_pattern = dash_object['attributes']['title']
            dash_object['attributes']['title'] = id_prefix + index_pattern[index_pattern.find('-') +1:]
            logger.info("Updated index pattern {}".format(dash_object['attributes']['title']))

    logging.debug("Updated dashboard {}".format(template_dashboard))
    return template_dashboard


def save_dash_template(template, template_dir, template_filename):
    """save_dash_template
    :param str template: The JSON of the newly templated dashboard
    :param str template_dir: The directory where the templated dashboard file will be written
    :param str template_filename: The filename for the dashbaord template

    This method is used to save the provided dashboard template to the specified filename
    If a dashboard template of the same name already exists in the given directory the new template will be appended
    otherwise a new dashboard template file will be created
    """

    template_file = "/".join([template_dir, template_filename])
    logging.info("Saving template to {}".format(template_file))

    data = []
    if os.path.isfile(template_file):
        with open(template_file, 'r') as f:
            data = json.load(f)

    data.append(template)
    with open(template_file, 'w') as f:
            json.dump(data, f, indent=4)


def main():
    parser = argparse.ArgumentParser(
        description='Exports the specified Kibana dashboard to a reporting-platform Kibana template file (master and|or tenant).\n\nExample:\n  ./export_dashboards --kibana-url https://localhost:5602 --dashboard GeneralKPIs --kibana-template-file tango-tenant-kpi-dashboards.tmpl.json')
    parser.add_argument("--username", metavar='Elasticsearch Super Admin Username', default='elastic')
    parser.add_argument("--password", metavar='Elasticsearch Super Admin Password', default='t3l3com')
    parser.add_argument("--dashboard", metavar='Dashboard name to export')
    parser.add_argument('--kibana-url', metavar=DEFAULT_KIBANA_URL, default=DEFAULT_KIBANA_URL, help='URL of the development Kibana instance (default ' + DEFAULT_KIBANA_URL + ')')
    parser.add_argument('--kibana-template-dir', default=DEFAULT_KIBANA_TEMPLATE_DIR, help='Directory to which Kibana templates will be written (default ' + DEFAULT_KIBANA_TEMPLATE_DIR + ')')
    parser.add_argument('--kibana-master-template-filename', help='The name of the Kibana template file to create or update')
    parser.add_argument('--kibana-tenant-template-filename', help='The name of the Kibana template file to create or update')
    parser.add_argument("--master", default=False, action='store_true', help='Export Dev Dashboard to Master Dashboard Template')
    parser.add_argument("--tenant", default=False, action='store_true', help='Export Dev Dashboard to Tenant Dashboard Template')
    parser.add_argument("--verbose", default=False, action='store_true', help='Enable DEBUG logging')
    args = parser.parse_args()

    try:
        if args.verbose:
            logging.getLogger().setLevel(logging.DEBUG)

        session = create_http_session(args.username, args.password)
        dashboard_id = retrieve_dashboard_id(session, args.kibana_url, args.dashboard)
        logging.info("Dashboard _id {}".format(dashboard_id))

        dashboard = export_dashboard(session, args.kibana_url, dashboard_id)
        if args.master:
            master_dash_template = generate_dashboard_template(
                    dashboard_type="master",
                    dashboard=copy.deepcopy(dashboard))
            if not args.kibana_master_template_filename:
                logging.warn("Required master template filename not provided")
                sys.exit()
            save_dash_template(master_dash_template, args.kibana_template_dir, args.kibana_master_template_filename)

        if args.tenant:
            tenant_dash_template =  generate_dashboard_template(
                    dashboard_type="tenant", 
                    dashboard=copy.deepcopy(dashboard))
            if not args.kibana_tenant_template_filename:
                logging.warn("Required tenant template filename not provided")
                sys.exit()
            save_dash_template(tenant_dash_template, args.kibana_template_dir, args.kibana_tenant_template_filename)
    except Exception as e:
        logging.error(e)


if __name__ == '__main__':
    main()
