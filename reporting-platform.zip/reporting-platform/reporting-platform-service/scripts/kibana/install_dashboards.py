#!/usr/bin/env python
import argparse
import json
import sys
import time
import requests

DEFAULT_KIBANA_BASE_URL = 'https://localhost:5602'

def wait_for_green_status(args):
    s = requests.session() # HTTP session for keep-alive
    s.auth = (args.username, args.password)
    while True:
        try:
            r = s.get(args.kibana_url + '/api/status', verify=False)
            r.raise_for_status()
            status = r.json()['status']['overall']['state']
            if status == 'green':
                break
            print 'Kibana status is not green (is: {}), retrying...'.format(status)
        except requests.exceptions.ConnectionError:
            print 'Kibana is not reachable, retrying...'
        time.sleep(0.1)


def upload_kibana_saved_json(args, dashboards):
    s = requests.session() # HTTP session for keep-alive
    s.auth = (args.username, args.password)

    for dashboard in dashboards:
        headers = {'kbn-xsrf': 'true', 'Content-type' : 'application/json'}
        s.post(args.kibana_url + '/api/kibana/dashboards/import', json=dashboard, headers=headers, verify=False)


def main():
    parser = argparse.ArgumentParser(
        description='Imports a Kibana dashboards JSON file into Kibana via its REST API.\n\nExample:\n  ./install_dashboards --json master_dashboards.json --kibana-url https://localhost:5602')
    parser.add_argument("--username", metavar='Elasticsearch Super Admin Username')
    parser.add_argument("--password", metavar='Elasticsearch Super Admin Password')
    parser.add_argument('--json', metavar='export.json', type=argparse.FileType('r'), default=sys.stdin, help='The Kibana JSON export file to import', required=True)
    parser.add_argument('--kibana-url', metavar=DEFAULT_KIBANA_BASE_URL, default=DEFAULT_KIBANA_BASE_URL, help='Kibana base URL (default ' + DEFAULT_KIBANA_BASE_URL + ')')
    parser.add_argument('--wait', action='store_true', help='Wait indefinitely for Kibana port to come up with status green')
    args = parser.parse_args()

    # Load JSON file; it contains an array of dashboard objects
    dashboards = json.load(args.json)
    if args.wait:
        wait_for_green_status(args)

    upload_kibana_saved_json(args, dashboards)


if __name__ == '__main__':
    main()