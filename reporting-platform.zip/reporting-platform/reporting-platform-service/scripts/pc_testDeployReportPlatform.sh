#!/bin/bash

# Script to run on jump server to reporting platform to test VM
# Script was run in stages (manually)
# Script will be used later to help form a fully automated deployment pipeline
# Not for production use - development use only..
# See http://confluence:8090/x/Pij6AQ for more information


## First add tango to sudo group - then logout



# Set variables
VERSION=3.0.0
TARGET_VM=<target_vm>
TENANT=<tenant>
CO_ROLES_REPO=http://tangier/repo/cust_op/sites_automation/Robi/tags/1.0.3/roles
AUTOMATION_ROLES_REPO=http://tangier/repo/tango-automation/ansible/generic/trunk/roles
KIBANA_SECURITY_REPO=http://tangier/repo/docker/tango-kibana/trunk/security
# http://tangier/repo/docker/reporting-platform/tags/reporting-platform-$VERSION
REP_REPO=http://tangier/repo/docker/reporting-ansible/trunk
SVN_USER=<svn_user>
SVN_PWD=<svn_password>
PLAYBOOKS=/tango/end-to-end/ansible/playbooks
JDK=jdk-12.0.2

# Some work to do around this still TODO
sudo ssh-copy-id -i ~/.ssh/id_rsa.pub tango@$TARGET_VM
sudo ssh-copy-id -i ~/.ssh/id_rsa.pub root@$TARGET_VM

svn co --non-interactive --username $SVN_USER --password $SVN_PWD $REP_REPO/ansible /tango/end-to-end/ansible
svn co --non-interactive --username $SVN_USER --password $SVN_PWD $REP_REPO/scripts /tango/end-to-end/scripts
svn co --non-interactive --username $SVN_USER --password $SVN_PWD $CO_ROLES_REPO /tango/end-to-end/co_roles

svn co --non-interactive --username $SVN_USER --password $SVN_PWD $AUTOMATION_ROLES_REPO /tango/end-to-end/automation_roles
svn co --non-interactive --username $SVN_USER --password $SVN_PWD $KIBANA_SECURITY_REPO /tango/end-to-end/security

# Kibana needs .pem files
svn export --non-interactive --username $SVN_USER --password $SVN_PWD --force http://tangier/repo/docker/tango-kibana/trunk/security /tango/end-to-end/ansible/roles/kibana/files/


chmod u+x  /tango/end-to-end/scripts/prepare_deployment_view.sh

# Prepare deployment view - downloads artifacts from tanger
mkdir -p /tango/install
cp /tango/end-to-end/scripts/prepare_deployment_view.sh /tango/install
cd /tango/install
./prepare_deployment_view.sh -dd

cp /tango/end-to-end/security/policydemo_com.crt /tango/end-to-end/ansible/playbooks/

# Prepare ansible environment
## Prepare hosts file
cd $PLAYBOOKS
echo -e "[reporting-platform-data]\n$TARGET_VM" > $PLAYBOOKS/host-data
echo -e "[reporting-platform-service]\n$TARGET_VM" > $PLAYBOOKS/host-service
echo -e "[reporting-platform-shipper]\n$TARGET_VM" > $PLAYBOOKS/host-shipper


## Update Ansible configuration ansible.cfg (as root user)
echo -e "[defaults]\nroles_path = ${PWD}/../roles:${PWD}/../../co_roles:${PWD}/../../automation_roles" > /tango/end-to-end/ansible/playbooks/ansible.cfg

# Run ansible scripts

cd $PLAYBOOKS

## Install Java
ansible-playbook reporting-platform-data_01_base.yml --extra-vars="delegate_to_host=$TARGET_VM hostname=$TARGET_VM jdk_extracted_directory:=jdk-12.0.2" -i host-data
## Install Elastic search
ansible-playbook reporting-platform-data_02_elastic.yml --extra-vars="delegate_to_host=$TARGET_VM hostname=$TARGET_VM tenant=$TENANT install_one_master_node_only=true" -i host-data

## Install base and tenant templates

## Install base and tenant templates
ansible-playbook reporting-platform-data_02_elastic.yml --extra-vars="install_elasticsearch=false install_base_templates=true install_tenant_templates=true delegate_to_host=$TARGET_VM hostname=$TARGET_VM tenant=$TENANT" -i host-data
#ansible-playbook reporting-platform-data_02_elastic.yml --extra-vars="install_elasticsearch=false install_base_templates=false install_tenant_templates=true delegate_to_host=$TARGET_VM hostname=$TARGET_VM tenant=tango" -i host-data

## If running subsequent times the es_original_password field should be overriden
# ansible-playbook reporting-platform-data_02_elastic.yml --extra-vars="install_elasticsearch=false install_base_templates=true install_tenant_templates=true delegate_to_host=$TARGET_VM es_original_password=t3l3com hostname=$TARGET_VM tenant=brav1" -i host-data

## Install xpack roles
ansible-playbook reporting-platform-data_03_xpack.yml --extra-vars="install_xpack=true delegate_to_host=$TARGET_VM hostname=$TARGET_VM tenant=$TENANT" -i host-data

## Install curator
ansible-playbook reporting-platform-data_04_curator.yml --extra-vars="delegate_to_host=$TARGET_VM hostname=$TARGET_VM" -i host-data

## Install Kibana
ansible-playbook reporting-platform-service_01_kibana.yml --extra-vars="install_jdk=false install_kibana=true delegate_to_host=$TARGET_VM es_original_password=t3l3com hostname=$TARGET_VM kibana_wait_period_in_seconds=700" -i host-service

## Create Kibana space
ansible-playbook reporting-platform-service_01_kibana.yml --extra-vars="install_jdk=false install_kibana=false install_tenant_space=false install_master_space=true delegate_to_host=$TARGET_VM es_original_password=t3l3com hostname=$TARGET_VM" -i host-service
ansible-playbook reporting-platform-service_01_kibana.yml --extra-vars="install_jdk=false install_kibana=false install_tenant_space=true install_master_space=false delegate_to_host=$TARGET_VM es_original_password=t3l3com hostname=$TARGET_VM tenant=$TENANT" -i host-service


## Import Kibana dashboards
ansible-playbook reporting-platform-service_01_kibana.yml --extra-vars="install_jdk=false install_kibana=false install_tenant_dashboards=true install_subscriber_dashboards=true install_KPI_dashboards=true install_protocol_dashboards=true install_welcome_sms_dashboards=true delegate_to_host=$TARGET_VM es_original_password=t3l3com hostname=$TARGET_VM tenant=$TENANT" -i host-service
#ansible-playbook reporting-platform-service_01_kibana.yml --extra-vars="install_jdk=false install_kibana=false install_subscriber_dashboards=true install_KPI_dashboards=true install_protocol_dashboards=true install_welcome_sms_dashboards=true delegate_to_host=$TARGET_VM es_original_password=t3l3com hostname=$TARGET_VM tenant=tango" -i host-service

## Install tenants role after space install
ansible-playbook reporting-platform-data_03_xpack.yml --extra-vars="install_xpack=false install_xpack_create_role_for_tenant=true delegate_to_host=$TARGET_VM hostname=$TARGET_VM tenant=$TENANT" -i host-data

## Install logstash
ansible-playbook reporting-platform-service_02_logstash.yml --extra-vars="delegate_to_host=$TARGET_VM es_original_password=t3l3com hostname=$TARGET_VM tenant=$TENANT install_logstash_tenant=false" -i host-service

#ansible-playbook reporting-platform-data_05_metricbeat.yml --extra-vars="delegate_to_host=$TARGET_VM hostname=$TARGET_VM metricbeat_kibana_hosts=localhost:5602 metricbeat_logstash_hosts=localhost:5044" -i host-data

## Install metricebeat

ansible-playbook reporting-platform-shipper_01_metricbeat.yml --extra-vars="delegate_to_host=$TARGET_VM hostname=$TARGET_VM" -i host-shipper

## Install logstash
# logstash needs to be up prior to filebeat

## Install filebeat
ansible-playbook reporting-platform-shipper_02_filebeat.yml --extra-vars="delegate_to_host=$TARGET_VM hostname=$TARGET_VM filebeat_logstash_wait_timeout=180" -i host-shipper


