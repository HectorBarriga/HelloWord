#!/usr/bin/env python

import argparse
import collections
import json
import os

from elasticsearch import Elasticsearch
from elasticsearch import RequestError
from subprocess import Popen
from subprocess import PIPE

Template = collections.namedtuple('Template', 'template_file template_name')
TenantDbCredentials = collections.namedtuple('TenantDbCredentials', 'tenant_id tenant_db_schema tenant_db_user tenant_db_password tenant_db_ip tenant_db_port')

es = None
elasticsearch_templates_source_dir = '../templates/elasticsearch/'
logstash_config_source_dir = '../configuration/logstash/conf.d/'
logstash_config_dest_dir = '/etc/logstash/conf.d/'

elasticsearch_template_map = {

        'NGINX': [
            Template('nginx_tenant_template.json', 'nginx')
            ],
        'PCC': [ 
            Template('pcc_stats_tenant_template.json', 'pcc_stats'), 
            Template('pcc_spcm_plan_tenant_template.json', 'pcc_spcm_plan'),
            Template('pcc_spcm_sub_lifecycle_tenant_template.json', 'pcc_spcm_sub_lifecycle'),
            Template('pcc_data_usage_tenant_template.json', 'pcc_data_usage'),
            Template('pcc_rules_counters_tenant_template.json', 'pcc_rules_counters')
            ],
        'RTPE': [
            Template('campaign_manager_tenant_template.json','campaign_manager'),
            Template('campaign_manager_stats_tenant_template.json', 'campaign_manager_stats')
            ],
        'SUB_LC': [
            Template('pcc_spcm_sub_lifecycle_tenant_template.json','pcc_spcm_sub_lifecycle_tenant_template'),
            ],
        'GTP': [
            Template('gtp_proxy_tenant_template.json', 'gtp_proxy'),
            Template('gtp_proxy_stats_tenant_template.json', 'gtp_proxy_stats'),
            Template('gtp_proxy_datausage_stats_tenant_template.json', 'gtp_proxy_datausage_stats')
            ],
        'UNS': [ 
            Template('uns_tenant_template.json', 'uns_proxy') 
            ],
        'HRG': [
            Template('hrg_tenant_template.json', 'hrg')
            ],
        'WSMS': [
            Template('welcomenotifications_tenant_template.json', 'welcomenotifications'),
            Template('location_update_tenant_template.json', 'locationupdate')
        ],
        }

def install_tenant(template_key, tenant_id):
    global es
    global elasticsearch_templates_source_dir

    templates = elasticsearch_template_map[template_key]
    for template in templates:
        with open(elasticsearch_templates_source_dir + template.template_file) as f:
            template_body = f.read()
            template_body = template_body.replace('@TENANT_ID@',tenant_id)

        print "Installing template [" + template.template_name + "], template body [" + template_body + "]"
        es.indices.put_template(body=template_body, name=template.template_name + "_" + tenant_id)

def install_tenant_db_ingestion(tenant_db_credentials):
    global logstash_config_source_dir
    global logstash_config_dest_dir

    if not os.path.isdir(logstash_config_dest_dir):
         raise Exception("Installation error, logstash configuration directory does not exist")

    with open(logstash_config_source_dir + 'logstash-pcc-db-tenant.conf', 'r') as f:
        template_body = f.read()
        template_body = template_body.replace('@TENANT_DB_SCHEMA@',tenant_db_credentials.tenant_db_schema) 
        template_body = template_body.replace('@TENANT_DB_IP_ADDRESS@',tenant_db_credentials.tenant_db_ip) 
        template_body = template_body.replace('@TENANT_DB_PORT@',tenant_db_credentials.tenant_db_port) 
        template_body = template_body.replace('@TENANT_DB_USER@',tenant_db_credentials.tenant_db_user) 
        template_body = template_body.replace('@TENANT_DB_PASSWORD@',tenant_db_credentials.tenant_db_password) 
        template_body = template_body.replace('@TENANT_ID@',tenant_db_credentials.tenant_id)

    logstash_tenant_db_cfg = "logstash-pcc-db-" + tenant_db_credentials.tenant_id + ".conf"
    with open(logstash_tenant_db_cfg, 'w') as f:
        f.write(template_body)


    cmd = ['cp', logstash_tenant_db_cfg, logstash_config_dest_dir + "/" + logstash_tenant_db_cfg,]

    p = Popen(cmd, stdout=PIPE, stderr=PIPE)

    stdout, stderr = p.communicate()
    os.remove(logstash_tenant_db_cfg)

def main():
    global es
    global elasticsearch_templates_source_dir
    global logstash_config_source_dir

    parser = argparse.ArgumentParser(description='AnalyticsIngestion Tenant installation script')
    parser.add_argument("-e", "--es-ip-address",metavar='IP Address of the Elasticsearch Server',default="127.0.0.1")
    parser.add_argument("-n", "--es-username",metavar='Elasticsearch Username')
    parser.add_argument("-l", "--es-password",metavar='Elasticsearch Password')
    parser.add_argument("-t", "--templates",nargs='*',choices=['PCC', 'RTPE', 'GTP', 'UNS', 'HRG', 'WSMS','NGINX','SUB_LC'],required=True)
    parser.add_argument("-i", "--tenant-id",metavar='Tenant ID',required=True)
    parser.add_argument("-c", "--templates-cfg-dir",metavar='Elastic-search templates configuration directory')
    parser.add_argument("-ls", "--logstash-cfg-dir",metavar='Logstash configuration directory')
    parser.add_argument("-d", "--tenant-db-schema",metavar='Tenant DB Schema',default='tenant-schema')
    parser.add_argument("-a", "--tenant-db-address",metavar='Tenant DB IP Address',default='127.0.0.1')
    parser.add_argument("-p", "--tenant-db-port",metavar='Tenant DB Port',default='3306')
    parser.add_argument("-u", "--tenant-db-user",metavar='Tenant DB Username',default='spcmjdbc')
    parser.add_argument("-s", "--tenant-db-password",metavar='Tenant DB Password/Secret',default='spcms3cr3t')


    try:
        args = parser.parse_args()

        if args.es_username and args.es_password:
            es = Elasticsearch(args.es_ip_address, http_auth=(args.es_username, args.es_password))
        else:
            es = Elasticsearch(args.es_ip_address)


        if args.templates_cfg_dir:
            elasticsearch_templates_source_dir = args.templates_cfg_dir
            if elasticsearch_templates_source_dir[:-1] != '/':
                elasticsearch_templates_source_dir += '/'

        if args.logstash_cfg_dir:
            logstash_config_source_dir = args.logstash_cfg_dir
            if logstash_config_source_dir[:-1] != '/':
                logstash_config_source_dir += '/'

        for template in args.templates:
            install_tenant(template, args.tenant_id)

        if "PCC" in args.templates:
            tenant_db_credentials = TenantDbCredentials(tenant_id=args.tenant_id, tenant_db_schema=args.tenant_db_schema, tenant_db_user=args.tenant_db_user, tenant_db_password=args.tenant_db_password, tenant_db_ip=args.tenant_db_address, tenant_db_port=args.tenant_db_port)
            install_tenant_db_ingestion(tenant_db_credentials)


    except AttributeError as e:
        print "Error  " +str(e)
        parser.print_help()
        exit
    except Exception as e:
        print "Exception caught  " + str(e)
        exit

if __name__ == '__main__':
    main()




