
## Logstash configuration files .conf have moved

* Previously logstash configuration files were located in this folder. However the files are now 
Ansible Jinja templates in the logstash under [reporting-ansible trunk](http://tangier/repo/docker/reporting-ansible/trunk/ansible/roles/logstash/templates)

### Example
For example - what once was a file in this directory logstash-nginx.conf

```text
filter {
  if "nginx_access" in [tags] {

    grok {
      patterns_dir => ["/etc/logstash/patterns"]
      match => { "message" => "%{NGINX_ACCESS}" }
      add_field => {
        "type" => "nginx_access"
      }
    }

    date {
      match => ["time_local", "dd/MMM/YYYY:HH:mm:ss Z"]
      target => "cdr_timestamp"
      remove_field => "time_local"
    }

    useragent {
      source => "user_agent"
      target => "useragent"
      remove_field => "user_agent"
    }

    mutate {
      add_field => { "[@metadata][tenant_id]" => "%{tenant_id}" }
    }

    mutate {
      lowercase => [ "[@metadata][tenant_id]" ]
    }

    ruby {
           code => "
                    event.set('[@metadata][index_date]', event.get('@timestamp').time.localtime.strftime('%Y.%m.%d'))
                   "
         }

  }
  else if "nginx_error" in [tags] {

    grok {
      patterns_dir => "/etc/logstash/patterns"
      match => { "message" => "%{NGINX_ERROR}" }
      add_field => {
        "type" => "nginx_error"
      }
    }

    date {
      match => ["time_local", "YYYY/MM/dd HH:mm:ss"]
      target => "@timestamp"
      remove_field => "time_local"
    }

    mutate {
            add_field => { "[@metadata][tenant_id]" => "%{tenant_id}" }
    }

    mutate {
        lowercase => [ "[@metadata][tenant_id]" ]
    }

    

  }
}

output {
    if "nginx_access" in [tags] {
        elasticsearch {
            hosts => [ "127.0.0.1:9200" ]
            index => "%{[@metadata][tenant_id]}-nginx_access-%{[@metadata][index_date]}"
            manage_template => false
        }
    }
    else if "nginx_error" in [tags] {
        elasticsearch {
            hosts => [ "127.0.0.1:9200" ]
            index => "%{[@metadata][tenant_id]}-nginx_error-%{[@metadata][index_date]}"
            manage_template => false
        }
    }
}

```

* This file has been relocated to 

```text
filter {
  if "nginx_access" in [tags] {

    grok {
      patterns_dir => ["/etc/logstash/patterns"]
      match => { "message" => "%{NGINX_ACCESS}" }
      add_field => {
        "type" => "nginx_access"
      }
    }

    date {
      match => ["time_local", "dd/MMM/YYYY:HH:mm:ss Z"]
      target => "cdr_timestamp"
      remove_field => "time_local"
    }

    useragent {
      source => "user_agent"
      target => "useragent"
      remove_field => "user_agent"
    }

    mutate {
      add_field => { "[@metadata][tenant_id]" => "%{tenant_id}" }
    }

    mutate {
      lowercase => [ "[@metadata][tenant_id]" ]
    }

    ruby {
           code => "
                    event.set('[@metadata][index_date]', event.get('@timestamp').time.localtime.strftime('%Y.%m.%d'))
                   "
         }

    {{ test_filter }}

  }
  else if "nginx_error" in [tags] {

    grok {
      patterns_dir => "/etc/logstash/patterns"
      match => { "message" => "%{NGINX_ERROR}" }
      add_field => {
        "type" => "nginx_error"
      }
    }

    date {
      match => ["time_local", "YYYY/MM/dd HH:mm:ss"]
      target => "@timestamp"
      remove_field => "time_local"
    }

    mutate {
            add_field => { "[@metadata][tenant_id]" => "%{tenant_id}" }
    }

    mutate {
        lowercase => [ "[@metadata][tenant_id]" ]
    }

    {{ test_filter }}

  }
}

output {
    if "nginx_access" in [tags] {
        {{ es_output_nginx_access }}
    }
    else if "nginx_error" in [tags] {
        {{ es_output_nginx_error }}
    }
}
```
* Note also that the output filter section of a logstash configuration template contains a placeholder - this makes it possible
to configure logstash to output to standard output (for reporting-anible-trunk unit testing) or ingest to a ES index (for integration testing)
* See [reporting-ansible testing README.md](http://tangier/repo/docker/reporting-ansible/trunk/rep-test/README.md) for more information on running tests.