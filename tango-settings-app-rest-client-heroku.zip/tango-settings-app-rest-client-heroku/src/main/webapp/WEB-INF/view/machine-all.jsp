<jsp:directive.include file="top-navbar.jsp" />

<div id="layoutSidenav">
	<jsp:directive.include file="sidenav.jsp" />



	<div id="layoutSidenav_content">

		<jsp:directive.include file="machine-content.jsp" />

		<jsp:directive.include file="footer.jsp" />
	</div>


</div>
<script
	src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
	crossorigin="anonymous"></script>
<script src="${pageContext.request.contextPath}/resources/js/scripts.js"></script>
<script
	src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js"
	crossorigin="anonymous"></script>
<script
	src="${pageContext.request.contextPath}resources/assets/demo/chart-area-demo.js"></script>
<script
	src="${pageContext.request.contextPath}resources/assets/demo/chart-bar-demo.js"></script>
<script
	src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"
	crossorigin="anonymous"></script>
<script
	src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"
	crossorigin="anonymous"></script>
<script
	src="${pageContext.request.contextPath}/resources/assets/demo/datatables-demo.js"></script>
</body>
</html>