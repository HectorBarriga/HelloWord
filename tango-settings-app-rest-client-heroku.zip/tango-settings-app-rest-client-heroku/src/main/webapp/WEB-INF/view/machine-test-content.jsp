<main style="background-color:#F7F9F9">
<meta http-equiv="refresh" content="120">
<div id="container-fluid" style="margin-left: 30px; margin-top: 5px;">
	<!-- pass in urls for javascript to use to access data from settings api for charts  -->
	<h1 id="settingUrl" style="display: none">${settingUrl}</h1>
	<h1 id="commandUrl" style="display: none">${commandUrl}</h1>

	<c:url var="machineLink" value="./showMachines">
		<c:param name="machine" value="${machine.id}" />
		<c:param name="cluster" value="${cluster.id}" />
	</c:url>

	<c:url var="clusterLink" value="./showClusters">
		<c:param name="machine" value="${machine.id}" />
		<c:param name="cluster" value="${cluster.id}" />
	</c:url>


	<div class="row">
		<div class="col-xl-8">
			<h2 class="mt-3" style="color: #404040; margin-bottom: 25px">Monitor:
				${machine.machineName}</h2>
		</div>
		<div class="col-xl-2.5">
			<div id="background" style="margin-left: 10px">
				<a id="pagelinkrev" class="text" href="${machineLink}">
					<h6 id="pagelinkrev2" id="myBtn">
						<span id="pageLinkrev3">&nbsp <i
							class="fas fa-arrow-circle-left"></i></i>&nbsp
						</span>&nbsp Back to ${cluster.clusterName}
					</h6>
				</a>
			</div>
		</div>
	</div>

	<!-- breadcrumbs -->
	<ol class="breadcrumb mb-4">
		<li class="breadcrumb-item active"><a href="${clusterLink}" style="text-decoration:none">
				&nbsp All Clusters &nbsp</a> /<a href="${machineLink}" style="text-decoration:none"> &nbsp
				${cluster.clusterName} &nbsp</a> / ${machine.machineName}</li>
		<h2 id="machineId" style="display: none">${machine.id}</h2>
	</ol>

	<!-- display donut chart 1 for api tests -->
	<div class="row">
		<div class="col-md-3 py-1">
			<div class="card" style="border: outset">
				<c:url var="monitorLink" value="/setting/showResults">
					<c:param name="cluster" value="${cluster.id}" />
					<c:param name="machine" value="${machine.id}" />
				</c:url>
				<a href="${monitorLink}" style="text-decoration:none">
				<div
					class="card-header  align-items-center d-flex justify-content-center">
					<!-- create link to mornitong that test -->
					
					<div class="text" style="font-size: 20px; color: #404040">
						<b> API</b>
					</div>
				</div>
				</a>
				<div class="card-body">
					<canvas id="chDonut1"></canvas>
				</div>
			</div>
		</div>

		<!-- display donut chart 2 for verbose tests -->
		<div class="col-sm-7 col-md-5 col-lg-3 py-1">
		
			<div class="card" style="border: outset">
				<c:url var="settingVerboseListLink"
					value="../commandSetting/showResults">
					<c:param name="machine" value="${machine.id}" />
					<c:param name="cluster" value="${cluster.id}" />
					<c:param name="test" value="Verbose" />
				</c:url>
				<a href="${settingVerboseListLink}" style="text-decoration:none">
				<div
					class="card-header  align-items-center d-flex justify-content-center">
					
					 <div class="text" style="font-size: 20px; color: #404040"> <b> Verbose</b></div>
				</div>
				<div class="card-body">
					<canvas id="chDonut2"></canvas>
				</div>
			</div>
			</a>
		</div>


		<!-- display donut chart 3 for database tests -->
		<div class="col-md-5 col-lg-3 py-1">
			<div class="card" style="border: outset">
				<c:url var="settingSQLListLink"
					value="../commandSetting/showResults">
					<c:param name="machine" value="${machine.id}" />
					<c:param name="cluster" value="${cluster.id}" />
					<c:param name="test" value="Databases" />
				</c:url>
				<a href="${settingSQLListLink}" style="text-decoration:none">
				<div
					class="card-header  align-items-center d-flex justify-content-center">
					
					<div class="text"
						style="font-size: 20px; color: #404040"><b>Databases</b></div>
				</div>
				</a>
				<div class="card-body">
					<canvas id="chDonut3"></canvas>
				</div>
			</div>
		</div>

		<!-- display donut chart 4 for 3rd party tests -->
		<div class="col-md-5 col-lg-3 py-1">
			<div class="card" style="border: outset">
				<c:url var="command3PTSettingListLink"
					value="../commandSetting/showResults">
					<c:param name="machine" value="${machine.id}" />
					<c:param name="cluster" value="${cluster.id}" />
					<c:param name="test" value="3rd Party SW" />
				</c:url>
				<a href="${command3PTSettingListLink}" style="text-decoration:none">
				<div
					class="card-header  align-items-center d-flex justify-content-center">
					
				<div	 class="text"
						style="font-size: 20px; color: #404040"><b>3rd Party SW</b></div>
				</div>
				</a>
				<div class="card-body">
					<canvas id="chDonut4"></canvas>
				</div>
			</div>
		</div>

		<!-- display donut chart 5 for Tango pm tests -->
		<div class="col-md-5 col-lg-3 py-1">
			<div class="card" style="border: outset">
				<c:url var="commandTMPSettingListLink"
					value="../commandSetting/showResults">
					<c:param name="machine" value="${machine.id}" />
					<c:param name="cluster" value="${cluster.id}" />
					<c:param name="test" value="Tango PM" />
				</c:url>
				<a href="${commandTMPSettingListLink}" style="text-decoration:none">
				<div
					class="card-header  align-items-center d-flex justify-content-center">
					
					<div class="text"
						style="font-size: 20px; color: #404040"><b>Tango PM</b></div>
				</div>
				</a>
				<div class="card-body">
					<canvas id="chDonut5"></canvas>
				</div>
			</div>
		</div>

		<!-- display donut chart 6 for Network tests -->
		<div class="col-md-5 col-lg-3 py-1">
			<div class="card" style="border: outset">
				<c:url var="commandNetSettingListLink"
					value="../commandSetting/showResults">
					<c:param name="machine" value="${machine.id}" />
					<c:param name="cluster" value="${cluster.id}" />
					<c:param name="test" value="Network" />
				</c:url>
				<a href="${commandNetSettingListLink}" style="text-decoration:none">
				<div
					class="card-header  align-items-center d-flex justify-content-center">
					
					<div class="text"
						style="font-size: 20px; color: #404040"><b>Network</b></div>
				</div>
				</a>
				<div class="card-body">
					<canvas id="chDonut6"></canvas>
				</div>
			</div>
		</div>
	</div>

<!-- get data for charts from apis -->
<script>

var machineId = document.getElementById("machineId").innerHTML;
var api_url_root = document.getElementById("settingUrl").innerHTML;
var health_url_root = document.getElementById("commandUrl").innerHTML;


const api_url = api_url_root + '/count/' + machineId;
const verbose_url = health_url_root + '/count/Verbose/' + machineId;
const databases_url = health_url_root+ '/count/Databases/' + machineId;
const pt_url = health_url_root+ '/count/3rd Party SW/' + machineId;
const pm_url= health_url_root+ '/count/Tango PM/' + machineId;
const net_url= health_url_root + '/count/Network/' + machineId;


</script>
<!-- get data for charts from apis -->
	<script>
		async function showChart() {

			<!-- fetch data from api url -->
			const response = await
			fetch(api_url);
			const data = await
			response.json();

			const totalOk = data.countOK;
			const totalWarning = data.countWarning;
			const totalAlert = data.countAlert;
			const totalInfo = data.info;
			const total1 = totalInfo + totalAlert + totalWarning + totalOk;

			<!-- fetch data from verbose url -->
			const response2 = await
			fetch(verbose_url);
			const data2 = await
			response2.json();

			const totalOk2 = data2.countOK;
			const totalWarning2 = data2.countWarning;
			const totalAlert2 = data2.countAlert;
			const totalInfo2 = data2.info;
			const total2 = totalInfo2 + totalAlert2 + totalWarning2 + totalOk2;

			<!-- fetch data from databases url -->
			const response3 = await
			fetch(databases_url);
			const data3 = await
			response3.json();
			console.log(data3);
			const totalOk3 = data3.countOK;
			const totalWarning3 = data3.countWarning;
			const totalAlert3 = data3.countAlert;
			const totalInfo3 = data3.info;
			const total3 = totalInfo3 + totalAlert3 + totalWarning3 + totalOk3;

			<!-- fetch data from 3rd party url -->
			const response4 = await
			fetch(pt_url);
			const data4 = await
			response4.json();

			const totalOk4 = data4.countOK;
			const totalWarning4 = data4.countWarning;
			const totalAlert4 = data4.countAlert;
			const totalInfo4 = data4.info;
			const total4 = totalInfo4 + totalAlert4 + totalWarning4 + totalOk4;

			<!-- fetch data from pm url -->
			const response5 = await
			fetch(pm_url);
			const data5 = await
			response5.json();

			const totalOk5 = data5.countOK;
			const totalWarning5 = data5.countWarning;
			const totalAlert5 = data5.countAlert;
			const totalInfo5 = data5.info;
			const total5 = totalInfo5 + totalAlert5 + totalWarning5 + totalOk5;

			<!-- fetch data from networks url -->
			const response6 = await
			fetch(net_url);
			const data6 = await
			response6.json();

			const totalOk6 = data6.countOK;
			const totalWarning6 = data6.countWarning;
			const totalAlert6 = data6.countAlert;
			const totalInfo6 = data6.info;
			const total6 = totalInfo6 + totalAlert6 + totalWarning6 + totalOk6;

			//add text for centre of pie charts
			Chart.pluginService
					.register({
						beforeDraw : function(chart) {
							var width = chart.chart.width, height = chart.chart.height, ctx = chart.chart.ctx;
							ctx.restore();
							var fontSize = (height / 105).toFixed(2);
							ctx.font = fontSize + "em sans-serif";
							ctx.textBaseline = "middle";

							var text = chart.config.options.elements.center.text, textX = Math
									.round((width - ctx.measureText(text).width) / 2), textY = height / 2.30;
							ctx.fillText(text, textX, textY);
							ctx.save();
						}
					});

			//text for chart 1-api
			var text2 = "";
			if (((totalOk / total1) * 100) == 100) {
				text2 = "OK";

			} else if (((totalOk / total1) * 100) != 100 && totalWarning > 0) {
				text2 = "Critical";
			} else if (((totalOk / total1) * 100) != 100 && totalAlert > 0) {
				text2 = "Alert";
			} else if (((totalOk / total1) * 100) != 100 && totalInfo > 0) {
				text2 = "OK";
			}

			//text for chart 2
			var text3 = "";
			if (((totalOk2 / total2) * 100) == 100) {
				text3 = "OK";

			} else if (((totalOk2 / total2) * 100) != 100 && totalWarning2 > 0) {
				text3 = "Critical";
			} else if (((totalOk2 / total2) * 100) != 100 && totalAlert2 > 0) {
				text3 = "Alert";
			} else if (((totalOk2 / total2) * 100) != 100 && totalInfo2 > 0) {
				text3 = "OK";
			}

			//text for chart 3
			var text4 = "";
			if (((totalOk3 / total3) * 100) == 100) {
				text4 = "OK";

			} else if (((totalOk3 / total3) * 100) != 100 && totalWarning3 > 0) {
				text4 = "Critical";
			} else if (((totalOk3 / total3) * 100) != 100 && totalAlert3 > 0) {
				text4 = "Alert";
			} else if (((totalOk3 / total3) * 100) != 100 && totalInfo3 > 0) {
				text4 = "OK";
			}

			//text for chart 4
			var text5 = "";
			if (((totalOk4 / total4) * 100) == 100) {
				text5 = "OK";

			} else if (((totalOk4 / total4) * 100) != 100 && totalWarning4 > 0) {
				text5 = "Critical";
			} else if (((totalOk4 / total4) * 100) != 100 && totalAlert4 > 0) {
				text5 = "Alert";
			} else if (((totalOk4 / total4) * 100) != 100 && totalInfo4 > 0) {
				text5 = "OK";
			}

			//text for chart 5
			var text6 = "";
			if (((totalOk5 / total5) * 100) == 100) {
				text6 = "OK";

			} else if (((totalOk5 / total5) * 100) != 100 && totalWarning5 > 0) {
				text6 = "Critical";
			} else if (((totalOk5 / total5) * 100) != 100 && totalAlert5 > 0) {
				text6 = "Alert";
			} else if (((totalOk5 / total5) * 100) != 100 && totalInfo5 > 0) {
				text6 = "OK";
			}

			//text for chart 6
			var text7 = "";
			if (((totalOk6 / total6) * 100) == 100) {
				text7 = "OK";

			} else if (((totalOk6 / total6) * 100) != 100 && totalWarning6 > 0) {
				text7 = "Critical";
			} else if (((totalOk6 / total6) * 100) != 100 && totalAlert6 > 0) {
				text7 = "Alert";
			} else if (((totalOk6 / total6) * 100) != 100 && totalInfo6 > 0) {
				text7 = "OK";
			}


			//set colors for charts
			var colors = [ 'red', '#F57C00', '#28B463 ', 'green', '#dc3545',
					'#6c757d' ];

			//options for chart 1
			var donutOptions1 = {
				elements : {
					center : {
						text : text2
					
					}
				},
				cutoutPercentage : 75,
				legend : {
					display : true,
					position : 'bottom',
					labels : {
						pointStyle : 'circle',
						usePointStyle : true
					}
				}
			};

			// donut 1
			var chDonutData1 = {
				labels : [ 'Critical', 'Alert', 'OK', 'Info' ],
				datasets : [ {
					backgroundColor : colors.slice(0, 4),
					borderWidth : 0,
					data : [ totalWarning, totalAlert, totalOk, totalInfo ]
				} ]
			};

			var chDonut1 = document.getElementById("chDonut1");
			if (chDonut1) {
				new Chart(chDonut1, {
					type : 'pie',
					data : chDonutData1,
					options : donutOptions1
				});

				//options for chart 2
				var donutOptions2 = {
					elements : {
						center : {
							text : text3
						//set as you wish
						}
					},
					
					cutoutPercentage : 75,
					legend : {
						display : true,
						position : 'bottom',
						labels : {
							pointStyle : 'circle',
							usePointStyle : true
						}
					}
				};

				var chDonutData2 = {
					labels : [ 'Critical', 'Alert', 'OK', 'Info' ],
					datasets : [ {
						backgroundColor : colors.slice(0, 4),
						borderWidth : 0,
						data : [ totalWarning2, totalAlert2, totalOk2,
								totalInfo2 ]
					} ]
				};

				var chDonut2 = document.getElementById("chDonut2");
				if (chDonut2) {
					new Chart(chDonut2, {
						type : 'pie',
						data : chDonutData2,
						options : donutOptions2
					});

					//options for chart 3
					var donutOptions3 = {
						elements : {
							center : {
								text : text4
						
							}
						},
						circumference: 2 * Math.PI,
						rotation: 0.5 * Math.PI,
						cutoutPercentage : 75,
						legend : {
							display : true,
							position : 'bottom',
							labels : {
								pointStyle : 'circle',
								usePointStyle : true
							}
						}
					};

					var chDonutData3 = {
						labels : [ 'Critical', 'Alert', 'OK', 'Info' ],
						datasets : [ {
							backgroundColor : colors.slice(0, 4),
							borderWidth : 0,
							data : [ totalWarning3, totalAlert3, totalOk3,
									totalInfo3 ]
						} ]
					};

					var chDonut3 = document.getElementById("chDonut3");
					if (chDonut3) {
						new Chart(chDonut3, {
							type : 'pie',
							data : chDonutData3,
							options : donutOptions3
						});


						//options for chart 4
						var donutOptions4 = {
							elements : {
								center : {
									text : text5
								//set as you wish
								}
							},
							circumference: 2 * Math.PI,
							rotation: 0.5 * Math.PI,
							cutoutPercentage : 75,
							legend : {
								display : true,
								position : 'bottom',
								labels : {
									pointStyle : 'circle',
									usePointStyle : true
								}
							}
						};

						var chDonutData4 = {
							labels : [ 'Critical', 'Alert', 'OK', 'Info' ],
							datasets : [ {
								backgroundColor : colors.slice(0, 4),
								borderWidth : 0,
								data : [ totalWarning4, totalAlert4, totalOk4,
										totalInfo4 ]
							} ]
						};

						var chDonut4 = document.getElementById("chDonut4");
						if (chDonut4) {
							new Chart(chDonut4, {
								type : 'pie',
								data : chDonutData4,
								options : donutOptions4
							});

							//options for chart 5
							var donutOptions5 = {
								elements : {
									center : {
										text : text6
								
									}
								},
								circumference: 2 * Math.PI,
								rotation: 0.5 * Math.PI,
								cutoutPercentage : 75,
								legend : {
									display : true,
									position : 'bottom',
									labels : {
										pointStyle : 'circle',
										usePointStyle : true
									}
								}
							};

							var chDonutData5 = {
								labels : [ 'Critical', 'Alert', 'OK', 'Info' ],
								datasets : [ {
									backgroundColor : colors.slice(0, 4),
									borderWidth : 0,
									data : [ totalWarning5, totalAlert5,
											totalOk5, totalInfo5 ]
								} ]
							};

							var chDonut5 = document.getElementById("chDonut5");
							if (chDonut5) {
								new Chart(chDonut5, {
									type : 'pie',
									data : chDonutData5,
									options : donutOptions5
								});

								//options for chart 6
								var donutOptions6 = {
									elements : {
										center : {
											text : text7
									
										}
									},
									cutoutPercentage : 75,
									legend : {
										display : true,
										position : 'bottom',
										labels : {
											pointStyle : 'circle',
											usePointStyle : true
										}
									}
								};

								var chDonutData6 = {
									labels : [ 'Critical', 'Alert', 'OK',
											'Info' ],
									datasets : [ {
										backgroundColor : colors.slice(0, 4),
										borderWidth : 0,
										data : [ totalWarning6, totalAlert6,
												totalOk6, totalInfo6 ]
									} ]
								};

								var chDonut6 = document
										.getElementById("chDonut6");
								if (chDonut6) {
									new Chart(chDonut6, {
										type : 'pie',
										data : chDonutData6,
										options : donutOptions6
									});
								}

							}
						}

					

					}
				}
			}
		}
		showChart();
	</script>

	<!-- display link to go back to machines -->
	<c:url var="machineLink" value="./showMachines">
		<c:param name="machine" value="${machine.id}" />
		<c:param name="cluster" value="${cluster.id}" />
	</c:url>
	<h5 style="margin-top: 25px; margin-bottom: 25px">
		<a href="${machineLink}"><u>Back to Machines</u> </a>
	</h5>

</div>

</main>

