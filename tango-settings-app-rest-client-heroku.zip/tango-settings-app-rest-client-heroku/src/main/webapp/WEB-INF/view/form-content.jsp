<main style="background-color:#F7F9F9">
<div id="container-fluid" style="margin-left: 30px; margin-top: 5px;">

	<!-- create links-->
	<c:url var="settingListLink" value="./list">
		<c:param name="machine" value="${machine.id}" />
		<c:param name="cluster" value="${cluster.id}" />
	</c:url>

	<c:url var="monitorLink" value="./showResults">
		<c:param name="cluster" value="${cluster.id}" />
		<c:param name="machine" value="${machine.id}" />
	</c:url>
	
	<c:url var="settingListLink" value="./list">
		<c:param name="machine" value="${machine.id}" />
		<c:param name="cluster" value="${cluster.id}" />
	</c:url>

<!-- create form for adding a setting-->	
<form:form action="saveSetting" modelAttribute="setting" method="POST">
	<div class="row" style="margin-bottom:10px">
		<div class="col-xl-4">
			<h2 class="mt-4" style="color: #404040"> Tests: ${cluster.clusterName} ${machine.machineName}</h2>
		</div>


			<!-- display save button at top of screen-->
			<div class="col-xl-2.5">
				<div id="background">
					<div id="pagelink">
						<button style="height: 46px; padding: 10px" id="pagelink2"
							"class="btn" type="submit" class="save">Save Setting</button>
					</div>
				</div>
			</div>
			<!-- display cancel button to go back to list of settings-->
			<div class="col-xl-2.5" style="margin-left: 10px"">
				<div id="background">
					<a id="pagelinkrev" class="text" href="${settingListLink}">
						<h6 id="pagelinkrev2" id="myBtn">
							<span id="pageLinkrev3"> </span>&nbsp Cancel&nbsp
						</h6>
					</a>
				</div>
			</div>
			
			<!-- display button to go to test list-->
			<div class="col-xl-2.5" style="margin-left: 10px">
				<div id="background">
					<a id="pagelinkrev" class="text" href="${settingListLink}">
						<h6 id="pagelinkrev2" id="myBtn">
							<span id="pageLinkrev3">&nbsp <i class="fas fa-list"></i>&nbsp
							</span>&nbsp API Tests
						</h6>
					</a>
				</div>
			</div>

			<!-- display button to go to monitoring-->
			<div class="col-xl-2.5">
				<div id="background" style="margin-left: 10px">

					<a id="pagelinkrev" class="text" href="${monitorLink}">
						<h6 id="pagelinkrev2" id="myBtn">
							<span id=pageLinkrev3">&nbsp <i class='fas fa-tv'></i>&nbsp
							</span>&nbsp API Monitoring
						</h6>
					</a>

				</div>
			</div>
			
		</div>
		
	<!-- display breadcrumbs-->
		<ol class="breadcrumb mb-4">
			<li class="breadcrumb-item active"><a href="${settingListLink}" style="text-decoration:none"
				class="text"> <b> &nbsp API Tests &nbsp </b></a> / Create New API
				Test</li>
		</ol>
		<h3>Create New API Test </h3>
	<br>

		<!-- need to associate this data with test id -->
		<form:hidden path="id" />

		<div class="form-group">
			<div class="form-group row">

				<!-- test name input-->
				<div class="col-md-5">
					<label>Test Name:</label>
					<form:input class="form-control form-control-md" path="testName"
						maxlength="18" required="true" />
				</div>

				<!-- api url input-->
				<div class="col-md-5">
					<label>API URL:</label>
					<form:input class="form-control form-control-md" path="apiUrl"
						style=" margin-left:15px" required="true" />
				</div>

			</div>

			<div class="form-group row">

				<div class="col-md-5">
					<div class="form-group row">

						<!-- search term input-->
						<div class="col-md-6">
							<label>Search Term:</label>
							<form:input class="form-control form-control-md"
								path="searchWord" required="true" />
						</div>

						<!-- expected input-->
						<div class="col-md-2">
							<label>Expected</label>
							<form:checkbox path="expected" class="checkBox" />
						</div>

						<!-- select options for severity-->
						<div class="col-md-4">
							<label>Severity</label>
							<form:select class="form-control" id="select" path="severity">
								<option value=3 style="color: red">Warning</option>
								<option value=2 style="color: orange">Alert</option>
								<option value=1 style="color: green">Info</option>
							</form:select>
						</div>
					</div>


					<div class="row">
						<!-- warning message input-->
						<div class="col-md-10">
							<label>Warning Message:</label>
							<form:input class="form-control form-control-md"
								path="warningMessage" />
						</div>
					</div>

					<!-- advice/info input-->
					<div class="row" style="margin-top: 10px; margin-left:4px">
						<label>Advice:</label>
						<form:textarea path="info" class="form-control" rows="7" />

					</div>

				</div>

				<!-- headers input table-->
				<div class="col-md-5 col-lg-5">
					<label>Headers (optional)</label> <br>

					<table class="table table-bordered"
						style="width: 100%; margin-left: 15px">
						<thead>
							<tr>
								<td scope="col">Key</td>
								<td scope="col">Value</td>
							</tr>
						</thead>
						<tbody>

							<tr>
								<td><form:input path="headers[0].headerKey"
										class="form-control form-control-md" /></td>
								<td><form:input path="headers[0].headerValue"
										class="form-control form-control-md" /></td>
							</tr>

							<tr>
								<td><form:input path="headers[1].headerKey"
										class="form-control form-control-md" /></td>
								<td><form:input path="headers[1].headerValue"
										class="form-control form-control-md" /></td>
							</tr>

							<tr>
								<td><form:input path="headers[2].headerKey"
										class="form-control form-control-md" /></td>
								<td><form:input path="headers[2].headerValue"
										class="form-control form-control-md" /></td>
							</tr>
						</tbody>
					</table>

					<!-- basic auth input-->
					<div class="row" style="margin-left: 5px;">
						<label>Basic Auth (optional)</label>
					</div>

					<div class="form-group row" style="margin-left: 20px;">

						<div class="col-md-6">
							<label>User</label>
							<form:input class="form-control form-control-md"
								path="basicAuth.username" />
						</div>

						<div class="col-md-6">
							<label>Password</label>
							<form:input class="form-control form-control-md"
								path="basicAuth.password" />
						</div>
					</div>

				</div>
			</div>
			<!-- pass in cluster and machine id-->
			<input type="hidden" id="cluster.id" name="cluster.id"
				value="${cluster.id}" /> <input type="hidden" id="machine.id"
				name="machine.id" value="${machine.id}" /> <br>

			<!-- button to save setting-->
			<div id="pagelink">
				<button style="height: 46px; padding: 10px" id="pagelink2"
					"class="btn" type="submit" class="save">Save Setting</button>
			</div>
		</div>
	</form:form>
	<div></div>

</div>
</main>
