<main style="background-color:#F7F9F9">
<div id="container-fluid"
	style="margin-left: 30px; margin-top: 5px; background-color: #F4F6F7">
	
	<div class="row">
		<!-- display page title -->
		<div class="col-xl-5">
			<h2 class="mt-1" style="color: #404040">${cluster.clusterName}
				Machines</h2>
		</div>
		
		<!-- display add machine button -->
		<div class="col-xl-2.5">
			<div id="background" style="padding: 5px">
				<p style="color: #ff6600; margin-top: 15px" id="myBtn">
					<b><span style="background-color: #ff6600; color: white">&nbsp
							<i class="fas fa-plus"></i>&nbsp
					</span>&nbsp ADD MACHINE</b>
				</p>
			</div>
		</div>
		
	</div>
	<hr>

	<div id="myModal" class="modal1">
		<!-- Modal content -->
		<div class="modal-content1">
			<span class="close">&times;</span>
			<form:form action="saveMachine" modelAttribute="machine"
				method="POST">

				<div class="form-group row">
					<div class="col-md-10 col-lg-10" style="padding: 10px">
						<label style="color: black">Machine Name:</label>
						<form:input class="form-control form-control-md"
							path="machineName" />
						<input type="hidden" id="cluster" name="cluster.id"
							value="${cluster.id}" />
					</div>
				</div>

				<div class="row">
					<div class="col-md-2">
						<button class="btn btn-primary" type="submit" class="save">
							Add</button>
					</div>
				</div>

			</form:form>
		</div>

	</div>



	<div class="row">

		<c:forEach var="tempMachine" items="${machines}" varStatus="count">

			<c:url var="deleteLink" value="/setting/deleteMachine">
				<c:param name="machineId" value="${tempMachine.id}" />
				<c:param name="clusterId" value="${cluster.id}" />
			</c:url>
			<h1 id="machineId_${count.index}" style="display: none">
				${tempMachine.id}</h1>


			<div class="col-md-4 col-lg-4">
				<div class="card" style="margin-bottom: 20px; border: outset">
					<div class="card-header align-items-center d-flex justify-content">

						<h5 style="text-color: #ff6600;" class="card-title">
							<c:url var="machineTestLink" value="showMachinesTests">
								<c:param name="machine" value="${tempMachine.id}" />
								<c:param name="cluster" value="${cluster.id}" />
							</c:url>

							<a href="${machineTestLink}" class="text" style="color: #33cc33">
								${tempMachine.machineName}</a>
						</h5>


					</div>
					<div class="card-body"></div>
					<canvas id="chart-line_${count.index}"></canvas>
				</div>
			</div>


			<script
				src='https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.1.4/Chart.bundle.min.js'></script>
			<script>

var machineId = document.getElementById('machineId_${count.index}').innerHTML;


var api_url='http://localhost:8080/tango-settings-rest/api/settings/count/' + machineId;

async function getData(){
	const response = await fetch(api_url);
	const data = await response.json();
	console.log(data);
	const totalOk = data.countOk;
	const totalWarning= data.Warning;
	console.log(data.countOK);
}

getData();
</script>

			<script>

async function showChart() {
	const response = await fetch(api_url);
	const data = await response.json();
	console.log(data);
	const totalOk = data.countOK;
	const totalWarning= data.countWarning;
	const totalAlert = data.countAlert;
	const totalInfo = data.info;
	console.log(data.countOK);
	console.log(totalWarning);
	console.log(totalAlert);

   
        var ctx = $("#chart-line_${count.index}");
        var myLineChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ["API", "FileSystem", "Memory", "CPU", "RAM"],
                datasets: [{
                    data: [totalWarning, 2, 6, 3, 1],
                    label: "Warning",
                    borderColor: "red",
                    backgroundColor: 'red',
                    fill: false
                }, {
                    data: [totalOk, 0, 3, 1, 1],
                    label: "OK",
                    borderColor: "#28B463 ",
                    fill: true,
                    backgroundColor: '#28B463 '
                }, {
                    data: [totalAlert, 1, 2, 3, 3],
                    label: "Alert",
                    borderColor: "#F57C00 ",
                    fill: false,
                    backgroundColor: '#F57C00'
                }]
            },
            options: {
                title: {
                    display: false,
                    text: ''
                }
            }
        });
    
}
showChart();
</script>



		</c:forEach>
	</div>



	<script>
		// Get the modal
		var modal = document.getElementById("myModal");

		// Get the button that opens the modal
		var btn = document.getElementById("myBtn");

		// Get the <span> element that closes the modal
		var span = document.getElementsByClassName("close")[0];

		// When the user clicks the button, open the modal 
		btn.onclick = function() {
			modal.style.display = "block";
		}

		// When the user clicks on <span> (x), close the modal
		span.onclick = function() {
			modal.style.display = "none";
		}

		// When the user clicks anywhere outside of the modal, close it
		window.onclick = function(event) {
			if (event.target == modal) {
				modal.style.display = "none";
			}
		}
	
		document.getElementById("background").onmouseover = function() {
			document.getElementById("background").style.backgroundColor =' #f2f2f2';
		}
		document.getElementById("background").onmouseout = function() {
			document.getElementById("background").style.backgroundColor = 'white';
		}
</script>




	<c:url var="clusterLink" value="/setting/showClusters">
		<c:param name="machine" value="${machine.id}" />
		<c:param name="cluster" value="${cluster.id}" />
	</c:url>
	<h5 style="margin-bottom: 20px">
		<a href="${clusterLink}"><u>Back to Clusters</u> </a>
	</h5>
</div>

</main>

