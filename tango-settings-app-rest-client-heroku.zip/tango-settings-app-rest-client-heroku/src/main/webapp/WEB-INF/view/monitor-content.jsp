<head>
<meta http-equiv="refresh" content="15">
</head>

<main style="background-color:#F7F9F9">

<div id="container-fluid" style="margin-left: 30px; margin-top: 5px;">

	<!-- create links -->
	<c:url var="createLink" value="./form">
		<c:param name="cluster" value="${cluster.id}" />
		<c:param name="machine" value="${machine.id}" />
	</c:url>


	<c:url var="machineTestLink" value="showMachinesTests">
		<c:param name="machine" value="${machine.id}" />
		<c:param name="cluster" value="${cluster.id}" />
	</c:url>
	
	<c:url var="machineLink" value="./showMachines">
		<c:param name="machine" value="${machine.id}" />
		<c:param name="cluster" value="${cluster.id}" />
	</c:url>
	
	<c:url var="clusterLink" value="./showClusters">
		<c:param name="machine" value="${machine.id}" />
		<c:param name="cluster" value="${cluster.id}" />
	</c:url>
	
	<c:url var="settingListLink" value="./list">
		<c:param name="machine" value="${machine.id}" />
		<c:param name="cluster" value="${cluster.id}" />
	</c:url>


	<!-- display page title -->
	<div class="row" style="margin-bottom:10px">
		<div class="col-xl-6">
			<h2 class="mt-3" style="color: #404040">Monitor: API</h2>
		</div>
	
	<!-- display button to add new test -->
		<div class="col-xl-2.5" style="display: none"">
			<div id="background">
				<a id="pagelink" class="text" href="${createLink}">
					<h6 id="pagelink2" id="myBtn">
						<span id="pageLink3">&nbsp <i class="fas fa-plus"></i>&nbsp
						</span>&nbsp Create New Test &nbsp
					</h6>
				</a>
			</div>
		</div>

		<!-- display button to go back to all tests -->
		<div class="col-xl-2.5" style="margin-left: 10px;">
			<div id="background">
				<a id="pagelinkrev" class="text" href="${settingListLink}">
					<h6 id="pagelinkrev2" id="myBtn">
						<span id="pageLinkrev3">&nbsp <i class="fas fa-list"></i>&nbsp
						</span>&nbsp API Tests
					</h6>
				</a>
			</div>
		</div>

		<!-- display button to go back to machine -->
		<div class="col-xl-2.5">
			<div id="background" style="margin-left: 10px">
				<a id="pagelinkrev" class="text" href="${machineTestLink}">
					<h6 id="pagelinkrev2" id="myBtn">
						<span id="pageLinkrev3">&nbsp <i
							class="fas fa-arrow-circle-left"></i></i>&nbsp
						</span>&nbsp Back to ${machine.machineName}
					</h6>
				</a>
			</div>
		</div>
		
	</div>
	
	
	
	<!-- breadcrumbs -->
	<ol class="breadcrumb mb-4">
		<li class="breadcrumb-item active"><a href="${clusterLink}" style="text-decoration:none"> &nbsp All Clusters &nbsp / </a>  <a href="${machineLink}" style="text-decoration:none">
		&nbsp ${cluster.clusterName}&nbsp</a> / <a href="${machineTestLink}" style="text-decoration:none" class="text" style= color:#404040" >
			&nbsp ${machine.machineName} &nbsp </a> / &nbsp API</li>
	</ol>


	<!-- display card to show results of each test -->
	<div class="row" style="margin-left:5px" >
	
		<c:forEach var="tempSetting" items="${settings}" varStatus="count">
			<!-- create link -->
			<c:url var="monitorLink" value="./showResult">
				<c:param name="settingId" value="${tempSetting.id}" />
				<c:param name="cluster" value="${cluster.id}" />
				<c:param name="machine" value="${machine.id}" />
			</c:url>
			
			<!-- create card -->
			<div >
				<div class="card text-dark bg-light" style=" width:200px; margin-right:15px; grid-column-gap:2px" >
				<a href="${monitorLink}" style="text-decoration:none">
					<div class="card-header align-items-center d-flex justify-content-center"  style="background-color:#28B463 ; color:white" id="color1_${count.index}"><div style="color:white; font-size:20px"> ${tempSetting.testName}</div></div></a>
					<div class="card-body  align-items-center d-flex justify-content-center text-white" style="background-color:#28B463" id="color2_${count.index}">
						
						<h6 id="result_${count.index}" style="background-color: #28B463 ; font-size:20px" class="card-title">${tempSetting.result.statusOk}</h6>		
						<h6 id="display_${count.index}" style="background-color:#28B463 ; display:none" class="card-title" >${tempSetting.severity}</h6>
									
					</div>
				</div>
				<script>
					var result = document
							.getElementById('result_${count.index}').innerHTML;
					var color1 = document
							.getElementById('color1_${count.index}');
					var color2 = document
							.getElementById('color1_${count.index}');

					// change color to green if status is ok 
					if (result == "true") {
						document.getElementById('result_${count.index}').innerHTML = "&nbsp OK &#10003 &nbsp";
						document.getElementById('result_${count.index}').style.color = 'white ';
						document.getElementById('result_${count.index}').style.padding = '10px';
					//change color of box if status not ok
					} else {

						var severity = document
								.getElementById('display_${count.index}').innerHTML;

						//red for critical
						if (severity == 3) {
							document.getElementById('result_${count.index}').innerHTML = "&nbspCritical! &nbsp";
							document.getElementById('result_${count.index}').style.color = 'white';
							document.getElementById('result_${count.index}').style.background = '#ff5050';
							document.getElementById('result_${count.index}').style.padding = '10px';
							document.getElementById('color1_${count.index}')
									.setAttribute("style",
											"background-color:   #ff5050");
							document.getElementById('color2_${count.index}')
									.setAttribute("style",
											"background-color:  #ff5050");
						}

						//orange for alert
						if (severity == 2) {
							document.getElementById('result_${count.index}').innerHTML = "&nbspAlert &nbsp";
							document.getElementById('result_${count.index}').style.color = 'white';
							document.getElementById('result_${count.index}').style.background = ' #ff9933';
							document.getElementById('result_${count.index}').style.padding = '10px';

							document.getElementById('color1_${count.index}')
									.setAttribute("style",
											"background-color:    #ff9933");
							document.getElementById('color2_${count.index}')
									.setAttribute("style",
											"background-color:   #ff9933");

						}
						//green for info
						if (severity == 1) {
							document.getElementById('result_${count.index}').innerHTML = "&nbspInfo &nbsp";
							document.getElementById('result_${count.index}').style.color = 'white';
							document.getElementById('result_${count.index}').style.background = 'green';	
							document.getElementById('result_${count.index}').style.padding = '10px';
							document.getElementById('color1_${count.index}')
									.setAttribute("style",
											"background-color:green");
							document.getElementById('color2_${count.index}')
									.setAttribute("style",
											"background-color:green");
						}
					}
				</script>
			</div>
		</c:forEach>
	</div>
	<br><br><br>
	
	<!-- display link back to machine -->
	<h5 style="text-color: #ff6600;" class="card-title">
		<c:url var="machineTestLink" value="showMachinesTests">
			<c:param name="machine" value="${machine.id}" />
			<c:param name="cluster" value="${cluster.id}" />
		</c:url>
		<a href="${machineTestLink}" class="text"><u> Back to Machine
				Monitoring</u></a>
	</h5>
</div>
</main>
