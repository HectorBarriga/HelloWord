
<div id="layoutSidenav_nav">

	<nav class="sb-sidenav accordion sb-sidenav-light"
		style="background-color: var(--tango-grey);" id="sidenavAccordion">
		<div class="sb-sidenav-menu">
			<div class="nav">
				<!-- create links -->
				<c:url var="mainDashboardLink" value="showClusters"></c:url>
				<c:url var="kibanaConfigureLink" value="showConfigureKibana"></c:url>

				<!-- create nav link for montoring dashboard -->
				<div class="sb-sidenav-menu-heading"
					style="color: black; font-size: 14px"> <i class="fas fa-tachometer-alt" style="color: var(--tango-orange); font-size: 18px"></i>&nbsp Monitoring</div>
				<a class="nav-link" href="${mainDashboardLink}">
					<div class="sb-nav-link-icon"
						style="color: var(--tango-orange); font-size: 18px">
						
					</div>Main Dashboard
				</a>
					
				<!-- toggle menu for monitoring each cluster -->	
				 <a class="nav-link" id="nav1" data-toggle="collapse"
					data-target="#collapsePagesBC" aria-expanded="false"
					aria-controls="collapsePages" style= "font-size: 16px"> 
					&nbsp Monitor Clusters
					<div class="sb-sidenav-collapse-arrow">
						<i class="fas fa-angle-down" ></i>
					</div>
				</a>
				<!--dropdown menu for clusters -->
				<div class="collapse" id="collapsePagesBC"
					aria-labelledby="heading" data-parent="#sidenavAccordion">

					<nav class="sb-sidenav-menu-nested nav accordion"
						id="sidenavAccordionPages">

						<c:forEach var="tempCluster" items="${clusters}" varStatus="count">
							<c:url var="showMachinesLink" value="./showMachines">
								<c:param name="cluster" value="${tempCluster.id}" />
							</c:url>
							<!-- root for each cluster -->
							<a class="nav-link" class="text" style="color: #404040"
								href="${showMachinesLink}"> &nbsp&nbsp${tempCluster.clusterName}
							</a>
						</c:forEach>
					</nav>
				</div>

				<!-- create accordion menu and links for all types of test on clusters and machines (dynamic) -->
				<div class="sb-sidenav-menu-heading "
					style="color: black; font-size: 14px"> <b><i class="fas fa-th-list"" style="color:var(--tango-orange); font-size: 18px"></i></b>&nbsp&nbspTest Settings</div>

				<c:forEach var="tempCluster" items="${clusters}" varStatus="count">

					<!-- root for each cluster -->
					<a class="nav-link" id="nav1_${count.index}" data-toggle="collapse"
						data-target="#collapsePagesBC_${count.index}"
						aria-expanded="false" aria-controls="collapsePages_${count.index}">

						<div class="sb-nav-link-icon"
							style="color: var(--tango-orange); font-size: 20px">
							
						</div> ${tempCluster.clusterName}
						<div class="sb-sidenav-collapse-arrow">
							<i class="fas fa-angle-down"></i>
						</div>
					</a>

					<!-- display each machine for the cluster in menu -->
					<div class="collapse" id="collapsePagesBC_${count.index}"
						aria-labelledby="headingOne" data-parent="#sidenavAccordion">

						<nav class="sb-sidenav-menu-nested nav accordion"
							id="sidenavAccordionPages_${count.index}">

							<c:forEach var="tempMachine" items="${tempCluster.machines}"
								varStatus="count1">

								<!-- loop through and display name of each machine -->
								<a class="nav-link collapsed" data-toggle="collapse"
									data-target="#pagesCollapseMachine1b_${count1.index}"
									aria-expanded="false"
									aria-controls="pagesCollapseAuth_${count1.index}">
									${tempMachine.machineName}
									<div class="sb-sidenav-collapse-arrow">
										<i class="fas fa-angle-down"></i>
									</div>
								</a>
								<div class="collapse"
									id="pagesCollapseMachine1b_${count1.index}"
									aria-labelledby="headingTwo"
									data-parent="#sidenavAccordionPages_${count.index}">
									<nav class="sb-sidenav-menu-nested nav">

										<!-- create links to go to each test type's test setting main page -->
										<c:url var="settingListLink" value="/setting/list">
											<c:param name="machine" value="${tempMachine.id}" />
											<c:param name="cluster" value="${tempCluster.id}" />
										</c:url>

										<c:url var="commandVerboseSettingListLink"
											value="../commandSetting/list">
											<c:param name="machine" value="${tempMachine.id}" />
											<c:param name="cluster" value="${tempCluster.id}" />
											<c:param name="test" value="Verbose" />
										</c:url>
										<c:url var="commandSQLSettingListLink"
											value="../commandSetting/list">
											<c:param name="machine" value="${tempMachine.id}" />
											<c:param name="cluster" value="${tempCluster.id}" />
											<c:param name="test" value="Databases" />
										</c:url>
										<c:url var="command3PTSettingListLink"
											value="../commandSetting/list">
											<c:param name="machine" value="${tempMachine.id}" />
											<c:param name="cluster" value="${tempCluster.id}" />
											<c:param name="test" value="3rd Party SW" />
										</c:url>
										<c:url var="commandTMPSettingListLink"
											value="../commandSetting/list">
											<c:param name="machine" value="${tempMachine.id}" />
											<c:param name="cluster" value="${tempCluster.id}" />
											<c:param name="test" value="Tango PM" />
										</c:url>
										<c:url var="commandNetSettingListLink"
											value="../commandSetting/list">
											<c:param name="machine" value="${tempMachine.id}" />
											<c:param name="cluster" value="${tempCluster.id}" />
											<c:param name="test" value="Network" />
										</c:url>

										<!-- display the links to each test types test setting main page -->
										<a class="nav-link" class="text" style="color: #404040"
											href="${settingListLink}"> <b> API </b></a> <a
											class="nav-link" class="text" style="color: #404040"
											href="${commandVerboseSettingListLink}"><b>Verbose</b></a> <a
											class="nav-link" class="text" style="color: #404040"
											href="${commandSQLSettingListLink}"><b>Databases</b></a> <a
											class="nav-link" class="text" style="color: #404040"
											href="${command3PTSettingListLink}"><b>3rd Party SW</b></a> <a
											class="nav-link" class="text" style="color: #404040"
											href="${commandTMPSettingListLink}"><b>Processes</b></a> <a
											class="nav-link" class="text" style="color: #404040"
											href="${commandNetSettingListLink}"><b>Network</b></a>
									</nav>
								</div>

							</c:forEach>
						</nav>
					</div>
				</c:forEach>

				<!-- nav to configuring clusters -->
				<div class="nav">
					<c:url var="mainDashboardLink" value="configureClusters"></c:url>
					<div class="sb-sidenav-menu-heading"
						style="color: black; font-size: 14px"> <i class="fas fa-cogs" style="font-size: 18px ; color:var(--tango-orange)"></i>&nbspConfigurations</div>
					<a class="nav-link" href="${mainDashboardLink}">
						<div class="sb-nav-link-icon">
							
						</div> Configure Clusters
					</a>
				</div>

				<!-- display link to kibana charts -->
				<div class="nav">
				
					
					<a class="nav-link" href="${kibanaConfigureLink}">
						<div class="sb-nav-link-icon"
							style="color: var(--tango-orange); font-size: 20px">
					
						</div>Add Kibana Reports
					</a>
				</div>
				
				<div class="sb-sidenav-menu-heading "
					style="color: black; font-size: 14px"> <i class="fas fa-chart-bar" style="color: var(--tango-orange); font-size: 18px"></i>&nbsp&nbspKibana Reports</div>
				
				<c:forEach var="tempDashboard" items="${dashboards}" varStatus="count">
				
				<!-- create link for kibana dashboard -->
				<c:url var="kibanaDashboardLink" value="showKibana">
				<c:param name="kibana" value="${tempDashboard.id}" />
				</c:url>

					<!-- display link for each dashboard -->
					 <a class="nav-link"  href="${kibanaDashboardLink}"  id="nav1_${count.index}" >

						<div class="sb-nav-link-icon"
							style="color: var(--tango-orange); font-size: 20px">
							
						</div> ${tempDashboard.dashboardName}
						
					</a>
					</c:forEach>
				
				
			</div>
		</div>
		
		<!-- display footer-->
		<div class="sb-sidenav-footer py-3 bg mt-3" style="background-color:#D6DBDF;">
			<div class="small">Health CHeck</div>
		</div>
	</nav>
</div>