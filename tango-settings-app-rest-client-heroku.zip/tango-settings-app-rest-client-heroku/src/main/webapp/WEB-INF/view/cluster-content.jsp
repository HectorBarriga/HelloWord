<main style="background-color:#F7F9F9">
<meta http-equiv="refresh" content="120">
<div id="container-fluid" style="margin-left: 30px; margin-right: 30px">


	<div class="row" style="margin-bottom: 10px">
		<div class="col-xl-8">
		
		<!-- Pass in the api and command setting api urls  for javascript to get data -->
			<h1 id="settingUrl" style="display: none">${settingUrl}</h1>
			<h1 id="commandUrl" style="display: none">${commandUrl}</h1>
			<h2 class="mt-3" style="color: #404040">Monitoring All Clusters</h2>
		</div>
		
		<!-- Button for adding a cluster -->
		<div class="col-xl-2.5" style="display: none">
			<div id="background" id="pageLink">
				<p
					style="color: #155484; background-color: white; box-shadow: 2px 2px 2px #d3e8f8; border: solid; border-width: thin; border-color: #d3e8f8; padding: 12px; margin-top: 15px;"
					id="myBtn">
					<b><span id="pageLink3">&nbsp <i class="fas fa-plus"></i>&nbsp
					</span>&nbsp Add Cluster</b>
				</p>
			</div>
		</div>
	</div>

	<ol class="breadcrumb mb-4">
		<li class="breadcrumb-item active">All Clusters</li>
	</ol>


	<div id="myModal" class="modal1">

		<!-- Modal content -->
		<div class="modal-content1">
			<span class="close">&times;</span>
			<form:form action="saveCluster2" modelAttribute="cluster"
				method="POST">
				
				<div class="form-group row">
					<div class="col-md-10 col-lg-10" style="padding: 10px">
						<label style="color: black">Cluster Name:</label>
						<form:input class="form-control form-control-md"
							path="clusterName" />
					</div>
				</div>

				<div class="row">
					<div class="col-md-2">
						<button class="btn btn-primary" type="submit" class="save">
							Add</button>
					</div>
				</div>

			</form:form>
		</div>

	</div>





	<script>
		// Get the <span> element that closes the modal
		var span = document.getElementsByClassName("close")[0];

		// When the user clicks the button, open the modal 
		document.getElementById("myBtn").onclick = function() {
			document.getElementById("myModal").style.display = "block";
		}

		// When the user clicks on <span> (x), close the modal
		document.getElementsByClassName("close")[0].onclick = function() {
			modal.style.display = "none";
		}

		// When the user clicks anywhere outside of the modal, close it
		window.onclick = function(event) {
			if (event.target == document.getElementById("myModal")) {
				document.getElementById("myModal").style.display = "none";
			}
		}
	</script>



	<script>
		document.getElementById("background").onmouseover = function() {
			document.getElementById("background").style.backgroundColor = ' #f2f2f2';
		}
		document.getElementById("background").onmouseout = function() {
			document.getElementById("background").style.backgroundColor = 'white';
		}
	</script>


<!-- Display the pie charts with the results of tests for cluster -->

	<div class="row" style="margin-top: 15px">

		<c:forEach var="tempCluster" items="${clusters}" varStatus="count">

			<c:url var="deleteLink" value="./deleteCluster">
				<c:param name="clusterId" value="${tempCluster.id}" />
			</c:url>
			<h1 id="clusterId_${count.index}" style="display: none">${tempCluster.id}</h1>
			<div class="col-md-3 py-1">
				<div class="card" style="border: outset">
					<c:url var="showMachinesLink" value="./showMachines">
						<c:param name="cluster" value="${tempCluster.id}" />
					</c:url>
					<a href="${showMachinesLink}" style="text-decoration:none">
					<div class="card-header  align-items-center d-flex">
						
						<div
							style="font-size: 25px; color: #404040; text-align:center"> <b>${tempCluster.clusterName}</b></div>
					</div></a>
					<div class="card-body">
						<canvas id="chDonut1_${count.index}"></canvas>
					</div>
				</div>
			</div>

<script>

var clusterId_${count.index} = document.getElementById("clusterId_${count.index}").innerHTML;
var api_url_root = document.getElementById("settingUrl").innerHTML;
var health_url_root = document.getElementById("commandUrl").innerHTML;

var api_url_${count.index }= api_url_root + '/count/cluster/' + clusterId_${count.index};
var health_url_${count.index} = health_url_root + '/count/cluster/' + clusterId_${count.index};



async function showChart() {
	const response_${count.index} = await fetch(api_url_${count.index});
	const data_${count.index} = await response_${count.index}.json();
	console.log(data_${count.index});
	const totalOk_${count.index} = data_${count.index}.countOK;
	const totalWarning_${count.index} = data_${count.index}.countWarning;
	const totalAlert_${count.index} = data_${count.index}.countAlert;
	const totalInfo_${count.index} = data_${count.index}.info;
	

	const response2_${count.index} = await fetch(health_url_${count.index});
	const data2_${count.index} = await response2_${count.index}.json();
	console.log(data2_${count.index});
	const totalOk2_${count.index} = data2_${count.index}.countOK + totalOk_${count.index};
	const totalWarning2_${count.index}= data2_${count.index}.countWarning + totalWarning_${count.index};
	const totalAlert2_${count.index} = data2_${count.index}.countAlert + totalAlert_${count.index};
	const totalInfo2_${count.index} = data2_${count.index}.info + totalInfo_${count.index};
	


	Chart.pluginService.register({
	    beforeDraw: function (chart) {
	        var width = chart.chart.width,
	            height = chart.chart.height,
	            ctx = chart.chart.ctx;
	        ctx.restore();
	        var fontSize = (height / 105).toFixed(2);
	        ctx.font = fontSize + "em sans-serif";
	        ctx.textBaseline = "middle";
	        
	        var text = chart.config.options.elements.center.text,
	            textX = Math.round((width - ctx.measureText(text).width) / 2),
	            textY = height / 2;
	        ctx.fillText(text, textX, textY);
	        ctx.save();
	    }
	});


	<!-- generate the text to enter into the centre of each pie chart based on api call results e.g. ok or warning -->

		 var text2="";
		
		 if((totalOk2_${count.index}/ (totalOk2_${count.index}+ totalWarning2_${count.index} + totalAlert2_${count.index} +totalInfo2_${count.index} ) * 100)== 100 ){
		    text2= "OK";
		 
		    

		    }
		    else if ((totalOk2_${count.index}/ (totalOk2_${count.index}+ totalWarning2_${count.index} + totalAlert2_${count.index} +totalInfo2_${count.index} ) * 100)!= 100 && totalWarning2_${count.index} > 0){
			    text2="Critical";
			   
			  
			    
			    }
		    else if(((totalOk2_${count.index}/ (totalOk2_${count.index}+ totalWarning2_${count.index} + totalAlert2_${count.index} +totalInfo2_${count.index} ) * 100)!= 100 && totalAlert2_${count.index} > 0)){
		    text2="Alert";
		    
		   
		     }
		    else{
		    	text2= "OK"; 
		    	 }
	
	var colors = ['red','#F57C00','#28B463 ','green ','#dc3545','#6c757d'];
	
	var donutOptions = {
			elements: {
	            center: {
	                text: text2
	            }
	        },
	       		
	circumference: 2 * Math.PI,
	rotation: 0.5 * Math.PI,
	  cutoutPercentage: 65, 
	  fontColor: 'green',
	  legend: {display:false, position:'bottom', labels: {pointStyle:'circle', usePointStyle:true}}
	};

	
	var chDonutData1 = {
	    labels: ['Critical', 'Alert', 'OK','Info'],
	    datasets: [
	      {
	        backgroundColor: colors.slice(0,4),
	        
	        borderWidth: 5,
	        data: [totalWarning2_${count.index}, totalAlert2_${count.index}, totalOk2_${count.index}, totalInfo2_${count.index}]
	      }
	    ]
	};

	var chDonut1 = document.getElementById("chDonut1_${count.index}");
	if (chDonut1) {
	  new Chart(chDonut1, {
	      type: 'pie',
	      data: chDonutData1,
	      options: donutOptions
 
	  });

	 
	}		    
	
}
showChart();

</script>
		</c:forEach>
	</div>
</div>

</main>

