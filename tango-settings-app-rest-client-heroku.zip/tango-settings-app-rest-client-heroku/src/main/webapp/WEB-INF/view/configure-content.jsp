<main style="background-color:#F7F9F9">
<div id="container-fluid" style="margin-left: 30px; margin-right: 30px"">

	<!-- display title-->
	<div class="row" style="margin-bottom:10px">
		<div class="col-xl-7">
			<h2 class="mt-3" style="color: #404040">Configure: Clusters</h2>
		</div>
		
		<!-- display add cluster button-->
		<div class="col-xl-2.5">
			<div id="background">
				<p
					style="color: white; background-color: #155484; box-shadow: 2px 2px 2px #e6e6e6; border: solid; border-width: thin; border-color: #e6e6e6; padding: 12px; margin-top: 15px;"
					id="myBtn">
					<b><span id="pageLink3">&nbsp <i class="fas fa-plus"></i>&nbsp
					</span>&nbsp Add Cluster</b>
				</p>
			</div>
		</div>
	</div>
	
<hr>

<!-- modal form for add cluster-->
	<div id="myModal" class="modal1">

		<!-- Modal content -->
		<div class="modal-content1">
			<span class="close">&times;</span>
			<form:form action="saveCluster" modelAttribute="cluster"
				method="POST">

				<div class="form-group row">
					<div class="col-md-10 col-lg-10" style="padding: 10px">
						<label style="color: black">Cluster Name:</label>
						<form:input class="form-control form-control-md"
							path="clusterName" />
					</div>
				</div>

				<div class="row">
					<div class="col-md-2">
						<button class="btn btn-primary" type="submit" class="save">
							Add</button>
					</div>
				</div>

			</form:form>
		</div>

	</div>





	<script>
		// Get the modal
		var modal = document.getElementById("myModal");

		// Get the button that opens the modal
		var btn = document.getElementById("myBtn");

		// Get the <span> element that closes the modal
		var span = document.getElementsByClassName("close")[0];

		// When the user clicks the button, open the modal 
		document.getElementById("myBtn").onclick = function() {
			document.getElementById("myModal").style.display = "block";
		}

		// When the user clicks on <span> (x), close the modal
		document.getElementsByClassName("close")[0].onclick = function() {
			modal.style.display = "none";
		}

		// When the user clicks anywhere outside of the modal, close it
		window.onclick = function(event) {
			if (event.target == document.getElementById("myModal")) {
				document.getElementById("myModal").style.display = "none";
			}
		}
	</script>



	<script>
		document.getElementById("background").onmouseover = function() {
			document.getElementById("background").style.backgroundColor = ' #f2f2f2';
		}
		document.getElementById("background").onmouseout = function() {
			document.getElementById("background").style.backgroundColor = 'white';
		}
	</script>

<!-- display table to show all clusters/machines and actions-->
	<div class="row">
		<div class="col-md-8 col-sm-12 col-lg-12">

			<div class="card mb-4">
				<div class="card-header">
					<i class="fas fa-cogs" style="color:#ff6600"></i> Clusters
				</div>
				<div class="card-body">
					<div class="table-responsive">
						<table class="table table-bordered" id="dataTable"
							style="width: 100%">
							<thead>
								<tr>
									<th>ID</th>
									<th>Name</th>
									<th>Actions</th>
									<th>Machines</th>
								</tr>
							</thead>

							<tbody>
								<c:forEach var="tempCluster" items="${clusters}"
									varStatus="count">

									<!-- construct links  -->
									<c:url var="deleteLink" value="./deleteCluster">
										<c:param name="clusterId" value="${tempCluster.id}" />
									</c:url>

									
									<c:url var="showMachinesLink" value="./showMachines">
										<c:param name="cluster" value="${tempCluster.id}" />
									</c:url>
									
									
									<c:url var="deleteMachineLink" value="./deleteMachineForm">
										<c:param name="machineId" value="${tempMachine.id}" />
										<c:param name="clusterId" value="${cluster.id}" />
									</c:url>

									<!-- display clusters-->
									<tr>
										<td id="clusterValueId_${count.index}">${tempCluster.id}</td>
										<td>${tempCluster.clusterName}</td>
										<td>
											<!-- display the update link -->
											<a href="#" id="myBtn2_${count.index}">Rename</a>  | <a
											href="${deleteLink}"
											onclick="if (!(confirm('WARNING. Are you sure you want to DELETE this cluster?'))) return false">Delete</a>
										</td>
										<td><a href="#" id="myBtn3_${count.index}">Add
												Machine</a> | <a href="#" id="myBtn4_${count.index}"> Delete
												Machine</a>| <a href="#" id="myBtn6_${count.index}">Rename
												Machine</a>  | <a href="#" id="myBtn5_${count.index}"> Show Machines
												</a>
											</td>

									</tr>
									
										<!-- display modal form for changing cluster name-->
										<div id="myModal2_${count.index}" class="modal1">
											<!-- Modal content -->
											<div class="modal-content1">
												<span id="close" class="close1_${count.index}">&times;</span>
												<h1>Cluster: ${tempCluster.clusterName}</h1>
												<form:form action="saveCluster" modelAttribute="cluster"
													method="POST">
													<!-- Associate cluster with ID for update -->
													<form:hidden path="id" id="idValue_${count.index}" value="" />

													<div class="form-group row">
														<div class="col-md-10 col-lg-10" style="padding: 10px">
															<label style="color: black">New cluster Name:</label>
															<form:input class="form-control form-control-md"
																path="clusterName" />
														</div>
													</div>

													<div class="row">
														<div class="col-md-2">
															<button class="btn btn-primary" type="submit"
																class="save">Update</button>
														</div>
													</div>

												</form:form>
											</div>

										</div>
			
										<!-- display modal form -->
										<script type="text/javascript">
											
											// Get the <span> element that closes the modal
											var span = document
													.getElementsByClassName("close1_${count.index}")[0];

											document
													.getElementById("idValue_${count.index}").value = document
													.getElementById("clusterValueId_${count.index}").innerHTML;
											;

											// When the user clicks the button, open the modal 
											document
													.getElementById("myBtn2_${count.index}").onclick = function() {
												document
														.getElementById("myModal2_${count.index}").style.display = "block";
											}

											// When the user clicks on <span> (x), close the modal
											document
													.getElementsByClassName("close1_${count.index}")[0].onclick = function() {
												document
														.getElementById("myModal2_${count.index}").style.display = "none";
											}

											// When the user clicks anywhere outside of the modal, close it
											window.onclick = function(event) {
												if (event.target == document.getElementById("myModal2_${count.index}")) {
													document
															.getElementById("myModal2_${count.index}").style.display = "none";
												}
											}
										</script>
										
										
										<!-- create modal form for adding a machine-->
										<div id="myModal3_${count.index}" class="modal1">

											<!-- Modal content -->
											<div class="modal-content1">
												<span id = "close" class="close2_${count.index}">&times;</span>
												
												<form:form action="saveMachine" modelAttribute="machine"
													method="POST">
													<!-- Associate cluster with ID for update -->
													<form:hidden path="cluster.id" id="idValue2_${count.index}" value="" />

													<div class="form-group row">
														<div class="col-md-10 col-lg-10" style="padding: 10px">
															<label style="color: black">Machine Name:</label>
															<form:input class="form-control form-control-md"
																path="machineName" />
														</div>
													</div>

													<div class="row">
														<div class="col-md-2">
															<button class="btn btn-primary" type="submit"
																class="save">Add</button>
														</div>
													</div>

												</form:form>
											</div>

										</div>
			
										<!-- display modal form for adding a machine-->
										<script type="text/javascript">
											// Get the <span> element that closes the modal
											var span = document
													.getElementsByClassName("close2_${count.index}")[0];

											document
													.getElementById("idValue2_${count.index}").value = document
													.getElementById("clusterValueId_${count.index}").innerHTML;
											;

											// When the user clicks the button, open the modal 
											document
													.getElementById("myBtn3_${count.index}").onclick = function() {
												document
														.getElementById("myModal3_${count.index}").style.display = "block";
											}

											// When the user clicks on <span> (x), close the modal
											document
													.getElementsByClassName("close2_${count.index}")[0].onclick = function() {
												document
														.getElementById("myModal3_${count.index}").style.display = "none";
											}

											// When the user clicks anywhere outside of the modal, close it
											window.onclick = function(event) {
												if (event.target == document.getElementById("myModal3_${count.index}")) {
													document
															.getElementById("myModal3_${count.index}").style.display = "none";
												}
											}
										</script>
										
										<!-- create modal form for deleting a machine by name-->
									<div id="myModal4_${count.index}" class="modal1">

										<!-- Modal content -->
										<div class="modal-content1">
											<span id="close" class="close3_${count.index}">&times;</span>

											<form:form action="deleteMachine" modelAttribute="machine"
												method="GET">
												<!-- Associate cluster with ID for update -->
												<input name="clusterId" type="hidden"
													id="idValue3_${count.index}" value="${tempCluster.id}" />


												<div class="form-group row">
													<div class="col-md-5 col-lg-5" style="padding: 10px">
														<label>Machine:</label> <select class="form-control"
															id="select" name="machineId">
															<c:forEach var="tempMachine"
																items="${tempCluster.machines}">
																<option value="${tempMachine.id}"
																	id="machineId_${count.index}">
															${tempMachine.machineName}</option>
															</c:forEach>
														</select>
													</div>
												</div>


												<div class="row">
													<div class="col-md-2">
														<button class="btn btn-primary" type="submit" onclick="if (!(confirm('WARNING. Are you sure you want to DELETE this machine?'))) return false"
															value="delete">Delete</button>
													</div>
												</div>
												
											</form:form>
										</div>

									</div>
									
									<!-- display form for deleting a machine-->
									<script type="text/javascript">
											// Get the modal
											// Get the <span> element that closes the modal
											var span = document
													.getElementsByClassName("close2_${count.index}")[0];
											//pass the cluster id
											document
													.getElementById("idValue3_${count.index}").value = document
													.getElementById("clusterValueId_${count.index}").innerHTML;
											
											// When the user clicks the button, open the modal 
											document
													.getElementById("myBtn4_${count.index}").onclick = function() {
												document
														.getElementById("myModal4_${count.index}").style.display = "block";
											}

											// When the user clicks on <span> (x), close the modal
											document
													.getElementsByClassName("close3_${count.index}")[0].onclick = function() {
												document
														.getElementById("myModal4_${count.index}").style.display = "none";
											}

											// When the user clicks anywhere outside of the modal, close it
											window.onclick = function(event) {
												if (event.target == document.getElementById("myModal4_${count.index}")) {
													document
															.getElementById("myModal4_${count.index}").style.display = "none";
												}
											}
										</script>
										
									<!-- create modal for displaying list of machines-->
									<div id="myModal5_${count.index}" class="modal1">

										<!-- Modal content -->
										<div class="modal-content1">
											<span id="close" class="close4_${count.index}">&times;</span>
											<h3>${tempCluster.clusterName}Machines:</h3>
											<br>
											<ol>
												<c:forEach var="tempMachine" items="${tempCluster.machines}">
													<h4>
														<li>${tempMachine.machineName}</li>
													</h4>
												</c:forEach>
											</ol>
										</div>
									</div>
									
									<!-- display list of machines modal-->
									<script type="text/javascript">
											// When the user clicks the button, open the modal 
											document
													.getElementById("myBtn5_${count.index}").onclick = function() {
												document
														.getElementById("myModal5_${count.index}").style.display = "block";
											}

											// When the user clicks on <span> (x), close the modal
											document
													.getElementsByClassName("close4_${count.index}")[0].onclick = function() {
												document
														.getElementById("myModal5_${count.index}").style.display = "none";
											}

											// When the user clicks anywhere outside of the modal, close it
											window.onclick = function(event) {
												if (event.target == document.getElementById("myModal5_${count.index}")) {
													document
															.getElementById("myModal5_${count.index}").style.display = "none";
												}
											}
										</script>
										
										<!-- create modal for renaming a machine from list-->
										<div id="myModal6_${count.index}" class="modal1">

										<!-- Modal content -->
										<div class="modal-content1">
											<span id="close" class="close5_${count.index}">&times;</span>
											<form:form action="saveMachine" modelAttribute="machine"
												method="POST">
												<!-- Associate cluster with ID for update -->
												<form:hidden path="cluster.id" value="${tempCluster.id}" />
												<div class="form-group row">
													<div class="col-md-5 col-lg-5" style="padding: 10px">


														<label>Machine:</label>
														<form:select class="form-control" id="select" path="id">

															<c:forEach var="tempMachine"
																items="${tempCluster.machines}">
																<option value="${tempMachine.id}"
																	id="machineId_${count.index}">
															${tempMachine.machineName} </option>
															</c:forEach>
														</form:select>


														<div class="form-group row">
															<div class="col-md-10 col-lg-12" style="padding: 10px">
																<label style="color: black">New Machine Name:</label>
																<form:input class="form-control form-control-md"
																	path="machineName" />
															</div>
														</div>
														
													</div>
												</div>


												<div class="row">
													<div class="col-md-2">
														<button class="btn btn-primary" type="submit" value="save">Update</button>
													</div>
												</div>
											</form:form>
										</div>

									</div>
									
									<!-- display form for changing a machine name-->
										<script type="text/javascript">
											// Get the <span> element that closes the modal
											var span = document
													.getElementsByClassName("close5_${count.index}")[0];

											// When the user clicks the button, open the modal 
											document
													.getElementById("myBtn6_${count.index}").onclick = function() {
												document
														.getElementById("myModal6_${count.index}").style.display = "block";
											}

											// When the user clicks on <span> (x), close the modal
											document
													.getElementsByClassName("close5_${count.index}")[0].onclick = function() {
												document
														.getElementById("myModal6_${count.index}").style.display = "none";
											}

											// When the user clicks anywhere outside of the modal, close it
											window.onclick = function(event) {
												if (event.target == document.getElementById("myModal6_${count.index}")) {
													document
															.getElementById("myModal6_${count.index}").style.display = "none";
												}
											}
										</script>
								</c:forEach>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>



</div>



</main>

