<main style="background-color:#F7F9F9">
<meta http-equiv="refresh" content="120">
<div id="container-fluid"
	style="margin-left: 30px; margin-right: 30px; background-color: #F4F6F7">

	<h1 id="settingUrl" style="display: none">${settingUrl}</h1>
	<h1 id="commandUrl" style="display: none">${commandUrl}</h1>

	<c:url var="clusterLink" value="./showClusters">
		<c:param name="machine" value="${machine.id}" />
		<c:param name="cluster" value="${cluster.id}" />
	</c:url>

	<div class="row" style="margin-bottom: 10px;">

		<div class="col-xl-8">
			<h2 class="mt-3" style="color: #404040">Monitor:
				${cluster.clusterName}</h2>
		</div>

		<!-- add machine button not displayed at moment -->
		<div class="col-xl-2.5" style="display: none">
			<div id="background" style="padding: 5px">
				<p
					style="color: #155484; background-color: white; box-shadow: 2px 2px 2px #d3e8f8; border: solid; border-width: thin; border-color: #d3e8f8; padding: 12px; margin-top: 15px;"
					id="myBtn">
					<b><span id="pageLink3">&nbsp <i class="fas fa-plus"></i>&nbsp
					</span>&nbsp Add Machine</b>
				</p>
			</div>
		</div>
		
		<!-- display back to clusters button -->
		<div class="col-xl-2.5">
			<div id="background" style="margin-left: 10px">
				<a id="pagelinkrev" class="text" href="${clusterLink}">
					<h6 id="pagelinkrev2" id="myBtn">
						<span id="pageLinkrev3">&nbsp <i
							class="fas fa-arrow-circle-left"></i></i>&nbsp
						</span>&nbsp Back to All Clusters
					</h6>
				</a>
			</div>
		</div>

	</div>
	
	<!-- display breadcrumbs -->
	<ol class="breadcrumb mb-4">
		<li class="breadcrumb-item active"><a href="${clusterLink}" style="text-decoration:none">
				&nbsp All Clusters &nbsp</a> / ${cluster.clusterName}</li>
	</ol>


	<!-- create modal for adding a machine -->
	<div id="myModal" class="modal1">
		<!-- Modal content -->
		<div class="modal-content1">
			<span class="close">&times;</span>
			<form:form action="saveMachine2" modelAttribute="machine"
				method="POST">

				<div class="form-group row">
					<div class="col-md-10 col-lg-10" style="padding: 10px">
						<label style="color: black">Machine Name:</label>
						<form:input class="form-control form-control-md"
							path="machineName" />
						<input type="hidden" id="cluster" name="cluster.id"
							value="${cluster.id}" />
					</div>
				</div>

				<div class="row">
					<div class="col-md-2">
						<button class="btn btn-primary" type="submit" class="save">
							Add</button>
					</div>
				</div>

			</form:form>
		</div>

	</div>
	
	<!-- display modal for adding a machine -->
	<script>
		// Get the modal
		var modal = document.getElementById("myModal");

		// Get the button that opens the modal
		var btn = document.getElementById("myBtn");

		// Get the <span> element that closes the modal
		var span = document.getElementsByClassName("close")[0];

		// When the user clicks the button, open the modal 
		btn.onclick = function() {
			modal.style.display = "block";
		}

		// When the user clicks on <span> (x), close the modal
		span.onclick = function() {
			modal.style.display = "none";
		}

		// When the user clicks anywhere outside of the modal, close it
		window.onclick = function(event) {
			if (event.target == modal) {
				modal.style.display = "none";
			}
		}
	
		document.getElementById("background").onmouseover = function() {
			document.getElementById("background").style.backgroundColor =' #f2f2f2';
		}
		document.getElementById("background").onmouseout = function() {
			document.getElementById("background").style.backgroundColor = 'white';
		}
</script>


<!-- create bar charts to display each machine test status -->
	<div class="row">

		<c:forEach var="tempMachine" items="${machines}" varStatus="count">

			<!-- add link to delete machine - not displayed at moment -->
			<c:url var="deleteLink" value="./deleteMachine">
				<c:param name="machineId" value="${tempMachine.id}" />
				<c:param name="clusterId" value="${cluster.id}" />
			</c:url>
			<h1 id="machineId_${count.index}" style="display: none">
				${tempMachine.id}</h1>

			
			<div class="col-md-10 col-lg-10 col-xl-4">
				<div class="card" style="margin-bottom: 20px; border: outset">
					<c:url var="machineTestLink" value="showMachinesTests">
						<c:param name="machine" value="${tempMachine.id}" />
						<c:param name="cluster" value="${cluster.id}" />
					</c:url>

					<a href="${machineTestLink}" style="text-decoration:none">
					<div class="card-header align-items-center d-flex justify-content">

						<h5 style="text-color: #ff6600;" class="card-title">
							

							<div class="text" style="color: #404040">
								${tempMachine.machineName}</div>
						</h5>
					</div>
					</a>
					<div class="card-body"></div>
					<canvas id="chart-line_${count.index}"></canvas>
				</div>
			</div>


<!-- dsiplay bar charts -->
<script src='https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.1.4/Chart.bundle.min.js'></script>
<script>

var machineId_${count.index} = document.getElementById('machineId_${count.index}').innerHTML;
var api_url_root${count.index} = document.getElementById("settingUrl").innerHTML;
var health_url_root${count.index} = document.getElementById("commandUrl").innerHTML;

var api_url_${count.index} = api_url_root${count.index} + '/count/' + machineId_${count.index};

var verbose_url_${count.index} = health_url_root${count.index} + '/count/Verbose/' + machineId_${count.index};
var databases_url_${count.index} = health_url_root${count.index}  + '/count/Databases/' + machineId_${count.index};
var pt_url_${count.index} = health_url_root${count.index} + '/count/3rd Party SW/' + machineId_${count.index};
var pm_url_${count.index} = health_url_root${count.index} + '/count/Tango PM/' + machineId_${count.index};
var net_url_${count.index} = health_url_root${count.index}  + '/count/Network/' + machineId_${count.index};


</script>

<script>

async function showChart() {
	const response_${count.index} = await fetch(api_url_${count.index});
	const data_${count.index} = await response_${count.index}.json();
	console.log(data_${count.index});
	const totalOk_${count.index} = data_${count.index}.countOK;
	const totalWarning_${count.index}= data_${count.index}.countWarning;
	const totalAlert_${count.index} = data_${count.index}.countAlert;
	const totalInfo_${count.index} = data_${count.index}.info;
	

	const response2_${count.index} = await fetch(verbose_url_${count.index});
	const data2_${count.index} = await response2_${count.index}.json();
	console.log(data2_${count.index});
	const totalOk2_${count.index} = data2_${count.index}.countOK;
	const totalWarning2_${count.index}= data2_${count.index}.countWarning;
	const totalAlert2_${count.index} = data2_${count.index}.countAlert;
	const totalInfo2_${count.index} = data2_${count.index}.info;


	const response3_${count.index} = await fetch(databases_url_${count.index});
	const data3_${count.index} = await response3_${count.index}.json();
	console.log(data3_${count.index});
	const totalOk3_${count.index} = data3_${count.index}.countOK;
	const totalWarning3_${count.index}= data3_${count.index}.countWarning;
	const totalAlert3_${count.index} = data3_${count.index}.countAlert;
	const totalInfo3_${count.index} = data3_${count.index}.info;

	const response4_${count.index} = await fetch(pt_url_${count.index});
	const data4_${count.index} = await response4_${count.index}.json();
	console.log(data4_${count.index});
	const totalOk4_${count.index} = data4_${count.index}.countOK;
	const totalWarning4_${count.index}= data4_${count.index}.countWarning;
	const totalAlert4_${count.index} = data4_${count.index}.countAlert;
	const totalInfo4_${count.index} = data4_${count.index}.info;

	const response5_${count.index} = await fetch(pm_url_${count.index});
	const data5_${count.index} = await response5_${count.index}.json();
	console.log(data5_${count.index});
	const totalOk5_${count.index} = data5_${count.index}.countOK;
	const totalWarning5_${count.index}= data5_${count.index}.countWarning;
	const totalAlert5_${count.index} = data5_${count.index}.countAlert;
	const totalInfo5_${count.index} = data5_${count.index}.info;

	const response6_${count.index} = await fetch(net_url_${count.index});
	const data6_${count.index} = await response6_${count.index}.json();
	console.log(data6_${count.index});
	const totalOk6_${count.index} = data6_${count.index}.countOK;
	const totalWarning6_${count.index}= data6_${count.index}.countWarning;
	const totalAlert6_${count.index} = data6_${count.index}.countAlert;
	const totalInfo6_${count.index} = data6_${count.index}.info;
	
	
   
        var ctx = $("#chart-line_${count.index}");
        var myLineChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ["API", "Verbose", "Databases", "3rd Party SW", "Tango PM", "Network"],
                datasets: [{
                    data: [totalWarning_${count.index}, totalWarning2_${count.index}, totalWarning3_${count.index}, totalWarning4_${count.index} ,totalWarning5_${count.index} ,totalWarning6_${count.index} ],
                    label: "Critical",
                    borderColor: "red",
                    backgroundColor: 'red',
                    fill: false
                }, {
                    data: [totalOk_${count.index}, totalOk2_${count.index}, totalOk3_${count.index}, totalOk4_${count.index} ,totalOk5_${count.index} ,totalOk6_${count.index} ],
                    label: "OK",
                    borderColor: "#28B463 ",
                    fill: true,
                    backgroundColor: '#28B463 '
                }, {
                    data: [totalAlert_${count.index}, totalAlert2_${count.index},totalAlert3_${count.index} ,totalAlert4_${count.index} ,totalAlert5_${count.index} ,totalAlert6_${count.index} ],
                    label: "Alert",
                    borderColor: "#F57C00 ",
                    fill: false,
                    backgroundColor: '#F57C00'
                }, {
                    data: [totalInfo_${count.index}, totalInfo2_${count.index}, totalInfo3_${count.index},totalInfo4_${count.index} ,totalInfo5_${count.index} , totalInfo6_${count.index}],
                    label: "Info",
                    borderColor: "green",
                    fill: true,
                    backgroundColor: 'green'
                }
                ]
            },
            options: {
                title: {
                    display: false,
                    text: ''
                }
            }
        });
    
}
showChart();
</script>

</c:forEach>
</div>

	<script>
		// Get the modal
		var modal = document.getElementById("myModal");

		// Get the button that opens the modal
		var btn = document.getElementById("myBtn");

		// Get the <span> element that closes the modal
		var span = document.getElementsByClassName("close")[0];

		// When the user clicks the button, open the modal 
		btn.onclick = function() {
			modal.style.display = "block";
		}

		// When the user clicks on <span> (x), close the modal
		span.onclick = function() {
			modal.style.display = "none";
		}

		// When the user clicks anywhere outside of the modal, close it
		window.onclick = function(event) {
			if (event.target == modal) {
				modal.style.display = "none";
			}
		}
	
		document.getElementById("background").onmouseover = function() {
			document.getElementById("background").style.backgroundColor =' #f2f2f2';
		}
		document.getElementById("background").onmouseout = function() {
			document.getElementById("background").style.backgroundColor = 'white';
		}
		
</script>



	<!-- siplay link to go back to clusters -->
	<c:url var="clusterLink" value="/setting/showClusters">
		<c:param name="machine" value="${machine.id}" />
		<c:param name="cluster" value="${cluster.id}" />
	</c:url>
	<h5 style="margin-bottom: 20px">
		<a href="${clusterLink}"><u>Back to Clusters</u> </a>
	</h5>
	
</div>
</main>

