   <footer class="py-3 bg mt-3" style="background-color:#D6DBDF;">
          <div class="container-fluid" >
                <div class="d-flex align-items-center justify-content-between small">
                      <div class="text-muted"></div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                        	</div>
                      </div>
                </div>
   </footer>