
<main>
<div class="container-fluid">

	<!-- create links -->
	
	<c:url var="createLink" value="./form">
		<c:param name="cluster" value="${cluster.id}" />
		<c:param name="machine" value="${machine.id}" />
		<c:param name="test" value="${test}" />
	</c:url>

	<c:url var="monitorLink" value="./showResults">
		<c:param name="cluster" value="${cluster.id}" />
		<c:param name="machine" value="${machine.id}" />
		<c:param name="test" value="${test}" />
	</c:url>

	<c:url var="deleteLink" value="./delete">
		<c:param name="settingId" value="${tempSetting.id}" />
		<c:param name="cluster" value="${cluster.id}" />
		<c:param name="machine" value="${machine.id}" />
		<c:param name="test" value="${test}" />
	</c:url>
	
	<!-- Add page title -->
	<div class="row" style="margin-bottom:10px">
		<div class="col-xl-6">
			<h2 class="mt-3" style="color: #404040">Test: ${cluster.clusterName} ${machine.machineName} ${test}</h2>
		</div>
		
		
		<!-- display the create button-->
		<div class="col-xl-2.5">
			<div id="background" style="margin-left:10px">
				<a  id= "pagelink" class="text"
						href="${createLink}"> <h6 id="pagelink2" id="myBtn" >
					<span id="pageLink3" >&nbsp
							<i class="fas fa-plus"></i>&nbsp
					</span>&nbsp Create New Test</h6></a>
			</div>
		</div>
		&nbsp&nbsp&nbsp&nbsp
		<!-- display the monitoring button -->
		<div class="col-xl-2.5">
			<div id="background" style="margin-left:10px">
				<a  id= "pagelinkrev" class="text"
						href="${monitorLink}"> <h6 id="pagelinkrev2" id="myBtn" >
					<span id="pageLinkrev3">&nbsp
							<i class='fas fa-tv'></i>&nbsp
					</span>&nbsp ${test} Monitoring</h6></a>
			
			</div>
		</div>
	</div>
	
	<!-- breadcrumbs -->
	<ol class="breadcrumb mb-4">
		<li class="breadcrumb-item active">  ${test} Tests </li>
	</ol>
	
	<!-- display the DATA TABLE of settings-->
	<div class="row">
	<div class="col-md-8 col-sm-12 col-lg-12">

		<div class="card mb-4">
			<div class="card-header">
				<i class="fas fa-table mr-1" style="color: #ff6600"></i> Test
				Settings
			</div>
			<div class="card-body">
				<div class="table-responsive">
					<table class="table table-bordered" id="dataTable"
						style="width: 100%">
						<thead>
							<tr>
								<th>ID</th>
								<th>Name</th>
								<th>Command</th>
								<th>Last Updated</th>
								<th>Actions</th>
							</tr>
						</thead>

						<!-- display the update link -->
						<tbody>
							<c:forEach var="tempSetting" items="${settings}">
								<!-- construct an "update" link -->
								<c:url var="updateLink" value="./showFormForUpdate">
									<c:param name="settingId" value="${tempSetting.id}" />
									<c:param name="cluster" value="${cluster.id}" />
									<c:param name="machine" value="${machine.id}" />
									<c:param name="test" value="${test}" />
								</c:url>

								<!-- construct an "delete" link  -->
								<c:url var="deleteLink" value="./delete">
									<c:param name="settingId" value="${tempSetting.id}" />
									<c:param name="cluster" value="${cluster.id}" />
									<c:param name="machine" value="${machine.id}" />
									<c:param name="test" value="${test}" />
								</c:url>
								
								<!-- construct an "update" link  -->
								<c:url var="monitorLink" value="./showResult">
									<c:param name="settingId" value="${tempSetting.id}" />
									<c:param name="cluster" value="${cluster.id}" />
									<c:param name="machine" value="${machine.id}" />
									<c:param name="test" value="${test}" />
								</c:url>

								<tr>
									<td>${tempSetting.id}</td>
									<td>${tempSetting.testName}</td>
									<td>${tempSetting.command.command}</td>
									<td>${tempSetting.modifyDate}</td>
									<td>
										<a href="${updateLink}">Update</a>
										| <a href="${monitorLink}">Monitor</a> | <a
										href="${deleteLink}"
										onclick="if (!(confirm('Are you sure you want to delete this test setting?'))) return false">Delete</a>
									</td>
								</tr>
							</c:forEach>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>

<!-- link to go back to machine page -->
		<div class="row">
			<c:url var="machineTestLink" value="./showMachinesTests">
				<c:param name="machine" value="${machine.id}" />
				<c:param name="cluster" value="${cluster.id}" />
			</c:url>
			<h5 style="margin: 20px">
				<a href="${machineTestLink}"><u>Back to
						${machine.machineName}</u> </a>
			</h5>
		</div>
		
	</div>
</div>


</main>
