<head>
<meta http-equiv="refresh" content="15">
</head>

<main style="background-color:#F7F9F9">

<div id="container-fluid" style="margin-left: 30px; margin-top: 5px;">

	<!-- create links -->
	
	<c:url var="createLink" value="./form">
		<c:param name="cluster" value="${cluster.id}" />
		<c:param name="machine" value="${machine.id}" />
		<c:param name="test" value="${test}" />
	</c:url>


	<c:url var="machineTestLink" value="showMachinesTests">
		<c:param name="machine" value="${machine.id}" />
		<c:param name="cluster" value="${cluster.id}" />
	</c:url>

	<c:url var="machineLink" value="./showMachines">
		<c:param name="machine" value="${machine.id}" />
		<c:param name="cluster" value="${cluster.id}" />
	</c:url>

	<c:url var="clusterLink" value="./showClusters">
		<c:param name="machine" value="${machine.id}" />
		<c:param name="cluster" value="${cluster.id}" />
	</c:url>

	<c:url var="settingListLink" value="./list">
		<c:param name="machine" value="${machine.id}" />
		<c:param name="cluster" value="${cluster.id}" />
		<c:param name="test" value="${test}" />
	</c:url>


	
	<div class="row" style="margin-bottom: 10px">
	
	<!-- display page title -->
		<div class="col-xl-6">
			<h2 class="mt-3" style="color: #404040">Monitor: ${test}</h2>
		</div>

	<!-- display the create test button -->
		<div class="col-xl-2.5" style="display: none"">
			<div id="background">
				<a id="pagelink" class="text" href="${createLink}">
					<h6 id="pagelink2" id="myBtn">
						<span id="pageLink3">&nbsp <i class="fas fa-plus"></i>&nbsp
						</span>&nbsp Create New Test &nbsp
					</h6>
				</a>
			</div>
		</div>

		<!-- display the back to tests button -->
		<div class="col-xl-2.5" style="margin-left: 10px;">
			<div id="background">
				<a id="pagelinkrev" class="text" href="${settingListLink}">
					<h6 id="pagelinkrev2" id="myBtn">
						<span id="pageLinkrev3">&nbsp <i class="fas fa-list"></i>&nbsp
						</span>&nbsp ${test} Tests
					</h6>
				</a>
			</div>
		</div>

		<!-- display the back to machine button -->
		<div class="col-xl-2.5">
			<div id="background" style="margin-left: 10px">
				<a id="pagelinkrev" class="text" href="${machineTestLink}">
					<h6 id="pagelinkrev2" id="myBtn">
						<span id="pageLinkrev3">&nbsp <i
							class="fas fa-arrow-circle-left"></i></i>&nbsp
						</span>&nbsp Back to ${machine.machineName}
					</h6>
				</a>
			</div>
		</div>
		
	</div>



	<!-- display breadcrumbs -->
	<ol class="breadcrumb mb-4">
		<li class="breadcrumb-item active"><a href="${clusterLink}" style="text-decoration:none">
				&nbsp All Clusters &nbsp / </a> <a href="${machineLink}" style="text-decoration:none"> &nbsp
				${cluster.clusterName} Machines &nbsp</a> / <a href="${machineTestLink}" style="text-decoration:none"
			class="text" > &nbsp
				${machine.machineName} &nbsp </a> / &nbsp ${test}</li>
	</ol>


	<!-- display card containing result of each test -->
	<div class="row">
		<c:forEach var="tempSetting" items="${settings}" varStatus="count">
		
			<c:url var="monitorLink" value="./showResult">
				<c:param name="settingId" value="${tempSetting.id}" />
				<c:param name="cluster" value="${cluster.id}" />
				<c:param name="machine" value="${machine.id}" />
				<c:param name="test" value="${test}" />
			</c:url>
			
			<div>
				<div class="card text-dark bg-light mb-3"
					style="margin-top: 20px; width: 200px; margin-right: 15px">
					<a href="${monitorLink}" style="text-decoration:none">
					<div
						class="card-header align-items-center d-flex justify-content-center"
						style="background-color: #28B463; color: white"
						id="color1_${count.index}">
						<div style="color: white; font-size: 20px">
							${tempSetting.testName}</div>
					</div>
					</a>
					
					<div
						class="card-body align-items-center d-flex justify-content-center text-white"
						style="background-color: white" id="color2_${count.index}">
						<h6 id="result_${count.index}"
							style="background-color: white; font-size: 20px"
							class="card-title">${tempSetting.result.statusOk}</h6>
						<h6 id="display_${count.index}"
							style="background-color: white; display: none"
							class="card-title">${tempSetting.severity}</h6>
					</div>
					
				</div>
				
				<!-- check the result status - if ok, diplay green message box else display red, orange if critical or alerts status -->
				<script>
					var result = document
							.getElementById('result_${count.index}').innerHTML;

					<!-- make message box green for OK -->
					if (result == "true") {
						
					document.getElementById('result_${count.index}').innerHTML = "&nbsp OK &#10003 &nbsp";
						document.getElementById('result_${count.index}').style.color = 'white ';
						document.getElementById('result_${count.index}').style.padding = '10px';
						document.getElementById('result_${count.index}').style.background = '#28B463';
						document.getElementById('color1_${count.index}')
								.setAttribute("style",
										"background-color:  #28B463 ");
						document.getElementById('color2_${count.index}')
								.setAttribute("style",
										"background-color:  #28B463");

					} else {

						<!-- make message box red for Critical -->
						var severity = document
								.getElementById('display_${count.index}').innerHTML;

						if (severity == 3) {
							document.getElementById('result_${count.index}').innerHTML = "&nbspCritical! &nbsp";
							document.getElementById('result_${count.index}').style.color = 'white';
							document.getElementById('result_${count.index}').style.background = 'red';
							document.getElementById('result_${count.index}').style.padding = '10px';
							document.getElementById('color1_${count.index}')
									.setAttribute("style",
											"background-color:   red");
							document.getElementById('color2_${count.index}')
									.setAttribute("style",
											"background-color:  red");
						}

						<!-- make message box orange for alert -->
						if (severity == 2) {
							document.getElementById('result_${count.index}').innerHTML = "&nbspAlert &nbsp";
							document.getElementById('result_${count.index}').style.color = 'white';
							document.getElementById('result_${count.index}').style.background = ' #ff9933';
							document.getElementById('result_${count.index}').style.padding = '10px';
							document.getElementById('color1_${count.index}')
									.setAttribute("style",
											"background-color:    #ff9933");
							document.getElementById('color2_${count.index}')
									.setAttribute("style",
											"background-color:   #ff9933");

						}

						<!-- make message box green for Info -->
						if (severity == 1) {
							document.getElementById('result_${count.index}').innerHTML = "&nbspInfo &nbsp";
							document.getElementById('result_${count.index}').style.color = 'whote';
							document.getElementById('result_${count.index}').style.background = 'green';
							document.getElementById('result_${count.index}').style.padding = '10px';
							document.getElementById('color1_${count.index}')
									.setAttribute("style",
											"background-color:green");
							document.getElementById('color2_${count.index}')
									.setAttribute("style",
											"background-color: green");

						}
					}
				</script>
			</div>

		</c:forEach>

	</div>
	<br>
	<br>
	<br>
	
	<!-- display back link -->
	<h5 style="text-color: #ff6600;" class="card-title">

		<c:url var="machineTestLink" value="showMachinesTests">
			<c:param name="machine" value="${machine.id}" />
			<c:param name="cluster" value="${cluster.id}" />
		</c:url>

		<a href="${machineTestLink}" class="text"> Back to Machine
			Monitoring</a>
	</h5>


</div>

</main>
