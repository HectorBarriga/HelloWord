
<head>
<!-- display alert box and change color based on result status -->
<script type="text/javascript">

         window.onload = function() {
			var result = document.getElementById("resultStatus").innerHTML;
			var alert =	document.getElementById("alert");
			var advice = document.getElementById("advice");
			var info= document.getElementById("info");
			var color = document.getElementById("color");
			var severity = document.getElementById("severity").innerHTML;

			if (result == "true") {
				document.getElementById("resultStatus").innerHTML = "&nbsp OK &nbsp<i class='fa fa-check-circle' style='font-size:20px; margin-top:10px'></i>";
				document.getElementById("resultStatus").style.color = '#00cc00';
				document.getElementById("resultStatus").style.padding = '10px';
			
						
			} else if ( result == "false" && severity == "3") {
				document.getElementById("resultStatus").innerHTML = "&nbspCRITICAL &nbsp<i class='fas fa-exclamation-triangle'  style='font-size:20px; margin-top:10px'></i>";
				document.getElementById("resultStatus").style.color = '#cc0000';
				document.getElementById("resultStatus").style.background= '#ffcccc';
				document.getElementById("resultStatus").style.padding = '10px';
				advice.style.display ="block";
				info.style.display="block";
				document.getElementById("alert").setAttribute("style", "background-color:  #ffcccc");
			}

			else if ( result == "false" && severity == "2") {
				document.getElementById("resultStatus").innerHTML = "&nbspALERT! &nbsp ";
				document.getElementById("resultStatus").style.color = ' #cc4400';
				document.getElementById("resultStatus").style.background=  '#ffe680';
				document.getElementById("resultStatus").style.padding = '10px';
				advice.style.display ="block";
				info.style.display="block";
				document.getElementById("alert").setAttribute("style", "background-color:   #ffe680");
			}

			else if ( result == "false" && severity == "1") {
				document.getElementById("resultStatus").innerHTML = "&nbspINFO &nbsp<i class='fa fa-info-circle'style='font-size:20px; margin-top:10px'></i>";
				document.getElementById("resultStatus").style.color = '#1f7a1f';
				document.getElementById("resultStatus").style.background=  '#c2f0c2';
				document.getElementById("resultStatus").style.padding = '10px';
				advice.style.display ="block";
				info.style.display="block";
				document.getElementById("alert").setAttribute("style", "background-color: #c2f0c2");
			}
       	 }
		</script>
</head>
<main>


<div id="container-fluid" style="margin-left: 30px; margin-top: 5px;">
		<!-- create links -->
	<c:url var="createLink" value="./form">
		<c:param name="cluster" value="${cluster.id}" />
		<c:param name="machine" value="${machine.id}" />
		<c:param name="test" value="${test}" />
	</c:url>

	<c:url var="machineTestLink" value="showMachinesTests">
		<c:param name="machine" value="${machine.id}" />
		<c:param name="cluster" value="${cluster.id}" />

	</c:url>

	<c:url var="machineLink" value="./showMachines">
		<c:param name="machine" value="${machine.id}" />
		<c:param name="cluster" value="${cluster.id}" />
	</c:url>

	<c:url var="clusterLink" value="./showClusters">
		<c:param name="machine" value="${machine.id}" />
		<c:param name="cluster" value="${cluster.id}" />
	</c:url>

	<c:url var="monitorLink" value="./showResults">
		<c:param name="cluster" value="${cluster.id}" />
		<c:param name="machine" value="${machine.id}" />
		<c:param name="test" value="${test}" />
	</c:url>

	<c:url var="settingListLink" value="./list">
		<c:param name="machine" value="${machine.id}" />
		<c:param name="cluster" value="${cluster.id}" />
		<c:param name="test" value="${test}" />
	</c:url>

		<!-- create heading -->
	<div class="row" style="margin-bottom: 10px">
		<div class="col-xl-5">
			<h2 class="mt-3" style="color: #404040">Monitor:
				${setting.testName}</h2>
		</div>

			<!-- make button to create new test -->
		<div class="col-xl-2.5">
			<div id="background">
				<a id="pagelink" class="text" href="${createLink}">
					<h6 id="pagelink2" id="myBtn">
						<span id="pageLink3">&nbsp <i class="fas fa-plus"></i>&nbsp
						</span>&nbsp Create New Test
					</h6>
				</a>

			</div>
		</div>


			<!-- button to go back to list of tests -->
		<div class="col-xl-2.5" style="margin-left: 10px">
			<div id="background">
				<a id="pagelinkrev" class="text" href="${settingListLink}">
					<h6 id="pagelinkrev2" id="myBtn">
						<span id="pageLinkrev3">&nbsp <i class="fas fa-list"></i>&nbsp
						</span>&nbsp ${test} Tests
					</h6>
				</a>

			</div>
		</div>

			<!-- create button to go to monitoring page-->
		<div class="col-xl-2.5">
			<div id="background" style="margin-left: 10px">
				<a id="pagelinkrev" class="text" href="${monitorLink}">
					<h6 id="pagelinkrev2" id="myBtn">
						<span id="pageLinkrev3">&nbsp <i class='fas fa-tv'></i>&nbsp
						</span>&nbsp ${test} Monitoring
					</h6>
				</a>
			</div>
		</div>

	</div>

		<!-- breadcrumbs -->
	<ol class="breadcrumb mb-4">
		<li class="breadcrumb-item active"><a href="${clusterLink}" style="text-decoration:none">
				&nbsp All Clusters &nbsp / </a> <a href="${machineLink}"> &nbsp
				${cluster.clusterName} &nbsp</a> / <a href="${machineTestLink}">
				&nbsp ${machine.machineName} &nbsp </a> / &nbsp <a href="${monitorLink}"
			class="text">${test} &nbsp </a> / ${setting.testName}</li>
	</ol>



		<!-- create alert box -->
	<div class="alert alert-light alert-dismissible fade show"
		style="margin-top: 20px; background-color: #d6f5d6" id="alert"
		role="alert">
		<p>
			<span id="severity" style="display: none">${setting.severity}</span>
			<span id="expected" style="display: none">${setting.expected}</span><strong
				id="resultStatus">${setting.result.statusOk}</strong> <span
				id="expected2" style="display: none">${setting.warningMessage}</span>
		</p>
		<button type="button" class="close" data-dismiss="alert"
			aria-label="Close">
			<span aria-hidden="true">&times;</span>
		</button>
	</div>

	<!-- create advice/extra info section -->
	<div class="row" id="advice">
		<h5 style="margin-left: 15px; font-color: green">Assistance</h5>
	</div>
	<div class="row" style="overflow: auto" id="info">
		<div class="col-6"
			style="margin-left: 25px; margin-top: 10px; background-color: #ecf2f9; height: 150px; padding: 15px">
			<h6>${setting.info}</h6>
		</div>
	</div>
	<hr>
	
	<!-- display request-->
	<div class="row" style="margin-left: 10px; margin-top: 25px;">
		<h5>Request</h5>
	</div>
	<div class="row" style="margin-left: 10px; margin-top: 25px;">
		<h6 style="font-family: 'Courier New', monospace">${setting.command.command}</h6>
	</div>
	<hr>
	
	<!-- display response in pretty print -->
	<div class="row" style="margin-left: 10px; margin-top: 25px">
		<h5>Response</h5>
	</div>
	<div class="overflow-auto">
		<div class="row" style="height: 300px">
			<pre id="prettyPrint"
				style="font-size: 14px; font-family: 'Courier New', monospace; margin-left: 15px"> ${json}</pre>
			<script>
				var pretty = document.getElementById("prettyPrint").innerHTML;
				var json = JSON.stringify(JSON.parse(pretty), null, 6);
				document.getElementById("prettyPrint").innerHTML = json;
			</script>
		</div>
	</div>
	<br>

	<!-- create link to go back to list-->
	<div class="row" style="margin-left: 15px; margin-top: 25px;">
		<h5 style="text-color: #ff6600;" class="card-title">
			<a href="${settingListLink}" class="text"> Back to List</a>
		</h5>
	</div>
</div>

<!-- based on result status display/don;t display warning message -->
<script>
	var result = document.getElementById("resultStatus").innerHTML;
	var expect = document.getElementById("expected").innerHTML;
	var expect2 = document.getElementById("expected2").innerHTML;
	var severity = document.getElementById("severity").innerHTML;

	<!-- display warning message -->
	if ((result == "false" && expect == "false")
			&& (severity == 3 || severity == 2)) {
		document.getElementById("expected2").style.display = "inline-block";
	}


	<!-- result ok so don;t display warning message-->
	if (result == "true" && expect == "false") {

		document.getElementById("advice").style.display = "none";
		document.getElementById("info").style.display = "none";
	}

	<!-- result ok so don;t display warning message-->
	if (result == "true" && expect == "true") {

		document.getElementById("advice").style.display = "none";
		document.getElementById("info").style.display = "none";
	}

	<!-- result not ok so display warning message-->
	if ((result == "false" && expect == "true")
			&& (severity == 3 || severity == 2)) {
		document.getElementById("expected2").style.display = "inline-block";

	}
</script> 
</main>