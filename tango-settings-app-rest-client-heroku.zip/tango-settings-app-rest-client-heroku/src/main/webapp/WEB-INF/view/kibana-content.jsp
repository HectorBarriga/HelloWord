<main style="background-color:#F7F9F9">
<meta http-equiv="refresh" content="120">
<div id="container-fluid" style="margin-left: 30px; margin-right: 30px">

<div class="row">
	
		<div class="col">
			<h2 class="mt-3" style="color: #404040">${kibana.dashboardName}</h2>
		</div>
	


</div>
<hr>
<div>
	<iframe src="${kibana.dashboardFrame}" height="3000" width="100%"></iframe>
	
</div>



</div>
</main>

