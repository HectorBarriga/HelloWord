
<main>
<div class="container-fluid">

	<!-- create links-->
	<c:url var="createLink" value="./form">
		<c:param name="cluster" value="${cluster.id}" />
		<c:param name="machine" value="${machine.id}" />
	</c:url>

	<c:url var="monitorLink" value="./showResults">
		<c:param name="cluster" value="${cluster.id}" />
		<c:param name="machine" value="${machine.id}" />
	</c:url>

	<c:url var="deleteLink" value="./delete">
		<c:param name="settingId" value="${tempSetting.id}" />
		<c:param name="cluster" value="${cluster.id}" />
		<c:param name="machine" value="${machine.id}" />
	</c:url>


	<div class="row" style="margin-bottom: 10px">
		<!-- display page title-->
		<div class="col-xl-6">
			<h2 class="mt-3" style="color: #404040">Test:
				${cluster.clusterName} ${machine.machineName} API</h2>
		</div>

		<!-- display create new test button-->
		<div class="col-xl-2.5">
			<div id="background" style="margin-left: 10px">
				<a id="pagelink" class="text" href="${createLink}">
					<h6 id="pagelink2" id="myBtn">
						<span id="pageLink3">&nbsp <i class="fas fa-plus"></i>&nbsp
						</span>&nbsp Create New Test
					</h6>
				</a>
			</div>
		</div>

		&nbsp

		<!-- display back to monitoring button-->
		<div class="col-xl-2.5">
			<div id="background" style="margin-left: 10px">
				<a id="pagelinkrev" class="text" href="${monitorLink}">
					<h6 id="pagelinkrev2" id="myBtn">
						<span id="pageLinkrev3">&nbsp <i class='fas fa-tv'></i>&nbsp
						</span>&nbsp API Monitoring
					</h6>
				</a>
			</div>
		</div>

	</div>

	<!-- breadcrumbs-->
	<ol class="breadcrumb mb-4">
		<li class="breadcrumb-item active">API Tests</li>
	</ol>


	<!-- display table of test settings-->
	<div class="row">
		<div class="col-md-8 col-sm-12 col-lg-12">

			<div class="card mb-4">
				<div class="card-header">
					<i class="fas fa-table mr-1" style="color: #ff6600"></i> Test
					Settings
				</div>
				<div class="card-body">
					<div class="table-responsive">
						<table class="table table-bordered" id="dataTable"
							style="width: 100%">
							<thead>
								<tr>
									<th>ID</th>
									<th>Name</th>
									<th>URL</th>
									<th>Last Updated</th>
									<th>Actions</th>
								</tr>
							</thead>

							<tbody>

								<c:forEach var="tempSetting" items="${settings}">
									<!-- create links -->
									<c:url var="updateLink" value="./showFormForUpdate">
										<c:param name="settingId" value="${tempSetting.id}" />
										<c:param name="cluster" value="${cluster.id}" />
										<c:param name="machine" value="${machine.id}" />
									</c:url>


									<c:url var="deleteLink" value="./delete">
										<c:param name="settingId" value="${tempSetting.id}" />
										<c:param name="cluster" value="${cluster.id}" />
										<c:param name="machine" value="${machine.id}" />
									</c:url>

									<c:url var="monitorLink" value="./showResult">
										<c:param name="settingId" value="${tempSetting.id}" />
										<c:param name="cluster" value="${cluster.id}" />
										<c:param name="machine" value="${machine.id}" />
									</c:url>

									<tr>
										<td>${tempSetting.id}</td>
										<td>${tempSetting.testName}</td>
										<td>${tempSetting.apiUrl}</td>
										<td>${tempSetting.modifyDate}</td>
										<td>
											<!-- display the update link --> <a href="${updateLink}">Update</a>
											| <a href="${monitorLink}">Monitor</a> | <a
											href="${deleteLink}"
											onclick="if (!(confirm('Are you sure you want to delete this test setting?'))) return false">Delete</a>
										</td>
									</tr>
								</c:forEach>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>

		<!-- display link to go back to machine montioring -->
		<div class="row">
			<c:url var="machineTestLink" value="./showMachinesTests">
				<c:param name="machine" value="${machine.id}" />
				<c:param name="cluster" value="${cluster.id}" />
			</c:url>
			<h5 style="margin: 20px">
				<a href="${machineTestLink}"><u>Back to
						${machine.machineName}</u> </a>
			</h5>
		</div>
	</div>
</div>
</main>
