<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>

<!DOCTYPE html>
<html lang="en">
    <head>
    	
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Settings Dashboard</title>
        <script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>
        <script src="${pageContext.request.contextPath}/resources/js/scripts.js"></script>
        <link href="${pageContext.request.contextPath}/resources/css/styles.css" rel="stylesheet" />
        <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
        <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" crossorigin="anonymous"></script>
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"/>
        <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
       <script src='https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.bundle.min.js'></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js" crossorigin="anonymous"></script>
       
<style>

:root {
  --tango-blue: #11466e;
  --tango-orange: #ff6600;
   --tango-grey: #F0F0F0;
   --tango-title: white;
   --tango-nav-title: black;
  
}

html {
  overflow-y: scroll; 
}
.modal1 {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 20;
  top: 0;
  width: 75%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content/Box */
.modal-content1 {
  background-color: #fefefe;
  margin: 15% auto; /* 15% from the top and centered */
  padding: 20px;
  border: 1px solid #888;
  width: 80%; /* Could be more or less, depending on screen size */
}

/* The Close Button */
#close {
  color: #aaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

#close:hover,
#close:focus {
  color: black;
  text-decoration: none;
  cursor: pointer;
}


@media all and (min-width: 992px) {
	
	#nav1:hover { data-toggle: collapse.show; }
	
	
}	

#pagelink{
color: white; 
display:block;
text-decoration:none;
}

#pagelink2 {
color:white ;
 background-color:#155484;
 box-shadow:3px 3px 3px #d3e8f8; 
 border: solid; 
 border-width:thin; 
 border-color: #d3e8f8;
 padding: 12px; 
 margin-top:15px;
}

#pageLink3{
 background-color:#155484 ;
 color: white}


#pagelinkrev{
color: #155484; 
display:block;
text-decoration:none;
}

#pagelinkrev2 {
color:#155484 ;
 background-color:white;
 box-shadow:3px 3px 3px #d3e8f8; 
 border: solid; 
 border-width:thin; 
 border-color: #d3e8f8;
 padding: 12px; 
 margin-top:15px;
}

#pageLinkrev3{
 background-color:white ;
 color: #155484}


</style>


</head>
    <body class="sb-nav-fixed" style="background-color:#F7F9F9">
        <nav class="sb-topnav navbar navbar-expand navbar-light" style= "background-color: var(--tango-blue); height:50px">
            <a class="navbar-brand" href="index.html" style="color:var(--tango-title)">System Diagnostics</a>
            <button class="btn btn-link btn-sm order-1 order-lg-0" id="sidebarToggle" href="#" style="color:white"><i class="fas fa-bars"></i></button>
            <!-- Navbar Search
            <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
                <div class="input-group">
                    <input class="form-control" type="text" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2" />
                    <div class="input-group-append">
                        <button class="btn btn-primary" type="button"><i class="fas fa-search"></i></button>
                    </div>
                </div>
            </form> -->
            <!-- Navbar-->
           <!-- <ul class="navbar-nav ml-auto ml-md-0 ">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" style="color:white; text-align:right" id="userDropdown" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-user fa-fw "></i> </a>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown"> 
                        <a class="dropdown-item" href="#">Settings</a>
                        <a class="dropdown-item" href="#">Activity Log</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="login.html">Logout</a>
                    </div>
                </li>
            </ul> -->
        </nav>