<main style="background-color:#F7F9F9">
<div id="container-fluid" style="margin-left: 30px; margin-top: 5px;">

	<!-- create links -->
	<c:url var="settingListLink" value="./list">
		<c:param name="machine" value="${machine.id}" />
		<c:param name="cluster" value="${cluster.id}" />
	</c:url>

	<c:url var="monitorLink" value="./showResults">
		<c:param name="cluster" value="${cluster.id}" />
		<c:param name="machine" value="${machine.id}" />
		<c:param name="test" value="${test}" />
	</c:url>

	<c:url var="settingListLink" value="./list">
		<c:param name="machine" value="${machine.id}" />
		<c:param name="cluster" value="${cluster.id}" />
		<c:param name="test" value="${test}" />
	</c:url>

	<!-- form for saving test setting -->
	
	<form:form action="saveSetting" modelAttribute="setting" method="POST">
	
		<div class="row" style="margin-bottom: 10px">
		
			
			<div class="col-xl-4">
				<h2 class="mt-4" style="color: #404040">Tests:
					${cluster.clusterName} ${machine.machineName}</h2>
			</div>


			<!-- display save button at top of page -->
			<div class="col-xl-2.5">
				<div id="background">

					<div id="pagelink">
						<button style="height: 46px; padding: 10px" id="pagelink2"
							class="btn" type="submit" class="save">Save Setting</button>
					</div>
				</div>
			</div>

			<!-- display cancel button -->
			<div class="col-xl-2.5" style="margin-left: 10px"">
				<div id="background">
					<a id="pagelinkrev" class="text" href="${settingListLink}">
						<h6 id="pagelinkrev2" id="myBtn">
							<span id="pageLinkrev3">&nbsp </span>&nbspCancel&nbsp&nbsp
						</h6>
					</a>
				</div>
			</div>

			<!-- display button to go to all tests -->
			<div class="col-xl-2.5" style="margin-left: 10px"">
				<div id="background">
					<a id="pagelinkrev" class="text" href="${settingListLink}">
						<h6 id="pagelinkrev2" id="myBtn">
							<span id="pageLinkrev3">&nbsp <i class="fas fa-list"></i>&nbsp
							</span>&nbsp ${test} Tests
						</h6>
					</a>
				</div>
			</div>

			<!-- display button to go back to monitoring -->
			<div class="col-xl-2.5">
				<div id="background" style="margin-left: 10px">
					<a id="pagelinkrev" class="text" href="${monitorLink}">
						<h6 id="pagelinkrev2" id="myBtn">
							<span id=pageLinkrev3">&nbsp <i class='fas fa-tv'></i>&nbsp
							</span>&nbsp ${test} Monitoring
						</h6>
					</a>
				</div>
			</div>
		</div>

		<!-- display breadcrumbs-->
		<ol class="breadcrumb mb-4">
			<li class="breadcrumb-item active"><a href="${settingListLink}" style="text-decoration:none"
				class="text"> <b> &nbsp ${test} Tests &nbsp </b></a> / Create New
				${test} Test</li>
		</ol>


		<h3>Create New ${test} Test</h3>
		<br>

		<!-- need to associate this data with setting id -->
		<form:hidden path="id" />

		<div class="form-group">
			<div class="form-group row">

				<div class="col-md-3">
					<label>Test Name:</label>
					<form:input type="text" maxlength="18"
						class="form-control form-control-md" path="testName"
						required="required" />
				</div>

				<div class="col-md-3">
					<label>Command:</label>
					<form:input class="form-control form-control-md"
						path="command.command" required="required" />
				</div>

				<div class="col-md-3">
					<label>Severity</label>
					<form:select class="form-control" id="select" path="severity">
						<option value=3 style="color: red">Warning</option>
						<option value=2 style="color: orange">Alert</option>
						<option value=1 style="color: green">Info</option>
					</form:select>
				</div>
				
			</div>
			<br>
			<hr>
			<div class="form-group row">

				<div class="col-md-3">
					<label>Search Term:</label>
					<form:input id="search_word" class="form-control form-control-md"
						path="searchWord" required="required" />
				</div>

				<div class="col-md-1">
					<br> <label>AND</label>
					<form:checkbox id="and" path="and" class="checkBox" />
				</div>

				<div class="col-md-1">
					<br> <label>OR</label>
					<form:checkbox id="or" path="or" class="checkBox" />
				</div>


				<div class="col-md-3">
					<label>Search Term 2:</label>
					<form:input id="search_word2" class="form-control form-control-md"
						path="searchWord2" />
				</div>


				<div class="col-md-2">
					<br> <label>Expected</label>
					<form:checkbox path="expected" class="checkBox" />
				</div>

			</div>
			<br>
			<hr>
			<div class="form-group row">
				<div class="col-md-2">
					<label>MIN Threshold:</label>
					<form:input id="min" type="number"
						class="form-control form-control-md" path="min"
						required="required" />
				</div>

				<div class="col-md-2">
					<label>MAX Threshold:</label>
					<form:input id="max" type="number"
						class="form-control form-control-md" path="max" disabled="false"
						required="required" />
				</div>

				<div class="col-md-4">
					<label>Warning Message:</label>
					<form:input class="form-control form-control-md"
						path="warningMessage" />
				</div>

				<script>
					var searchWord = document.getElementById("search_word");
					searchWord.oninput = function() {
						document.getElementById("min").disabled = this.value != "";
						document.getElementById("max").disabled = this.value != "";
					};

					var min = document.getElementById("min");
					min.oninput = function() {
						document.getElementById("search_word").disabled = this.value != "";
						document.getElementById("search_word2").disabled = this.value != "";

					};

					var max = document.getElementById("max");
					max.oninput = function() {
						document.getElementById("search_word").disabled = this.value != "";
						document.getElementById("search_word2").disabled = this.value != "";
					};
				</script>
			</div>
			<br>
			<hr>

			<div class="form-group row">
				<div class="col-md-9">
					<label>Advice:</label>
					<form:textarea path="info" class="form-control" rows="6" />
				</div>
			</div>

			<input type="hidden" id="cluster.id" name="cluster.id"
				value="${cluster.id}" /> <input type="hidden" id="machine.id"
				name="machine.id" value="${machine.id}" /> <br> <input
				type="hidden" id="test" name="test" value="${test}" />
			<div id="pagelink">
				<button style="height: 46px; padding: 10px" id="pagelink2"
					"class="btn" type="submit" class="save">Save Setting</button>
			</div>
			
		</div>
	</form:form>

</div>
</main>
