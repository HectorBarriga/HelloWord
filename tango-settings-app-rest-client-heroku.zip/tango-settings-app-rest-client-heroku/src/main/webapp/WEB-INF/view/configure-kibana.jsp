<main style="background-color:#F7F9F9">
<div id="container-fluid" style="margin-left: 30px; margin-right: 30px"">

	<!-- display title-->
	<div class="row" style="margin-bottom:10px">
		<div class="col-xl-7">
			<h2 class="mt-3" style="color: #404040">Add Kibana Reports</h2>
		</div>
		
		<!-- display add dashboard button-->
		<div class="col-xl-2.5">
			<div id="background">
				<p
					style="color: white; background-color: #155484; box-shadow: 2px 2px 2px #e6e6e6; border: solid; border-width: thin; border-color: #e6e6e6; padding: 12px; margin-top: 15px;"
					id="myBtn">
					<b><span id="pageLink3">&nbsp <i class="fas fa-plus"></i>&nbsp
					</span>&nbsp Add Dashboard</b>
				</p>
			</div>
		</div>
		
		<div class="col-xl-2.5">
			<div id="background" style="margin-left:20px">
				<p
					style="color:#155484 ; background-color: white; box-shadow: 2px 2px 2px #e6e6e6; border: solid; border-width: thin; border-color: #e6e6e6; padding: 12px; margin-top: 15px;"
					id="myBtn3">
					<b><span id="pageLink2">&nbsp <i class="fas fa-info"></i>&nbsp
					</span>&nbsp Help &nbsp</b>
				</p>
			</div>
		</div>
	</div>
	
<hr>

<!-- modal form for add dashboard-->
	<div id="myModal1" class="modal1">

		<!-- Modal content -->
		<div class="modal-content1">
			<span id="close" class="close1">&times;</span>
			<h4>Add Dashboard</h4>
			<form:form action="saveKibana" modelAttribute="kibana"
				method="POST">

				<div class="form-group row">
					<div class="col-md-10 col-lg-10" style="padding: 10px">
						<label style="color: black">Dashboard Name:</label>
						<form:input class="form-control form-control-md"
							path="dashboardName" />
					</div>
					<div class="col-md-10 col-lg-10" style="padding: 10px">
						<label style="color: black">Dashboard iFrame:</label>
						<form:input class="form-control form-control-md"
							path="dashboardFrame" />
					</div>
				</div>

				<div class="row">
					<div class="col-md-2">
						<button class="btn btn-primary" type="submit" class="save">
							Add</button>
					</div>
				</div>

			</form:form>
		</div>

	</div>
	<script>
		// Get the modal
		var modal = document.getElementById("myModal1");

		// Get the button that opens the modal
		var btn = document.getElementById("myBtn");

		// Get the <span> element that closes the modal
		var span = document.getElementsByClassName("close1")[0];

		// When the user clicks the button, open the modal 
		document.getElementById("myBtn").onclick = function() {
			document.getElementById("myModal1").style.display = "block";
		}

		// When the user clicks on <span> (x), close the modal
		document.getElementsByClassName("close1")[0].onclick = function() {
			document.getElementById("myModal1").style.display = "none";
		}

		// When the user clicks anywhere outside of the modal, close it
		window.onclick = function(event) {
			if (event.target == document.getElementById("myModal1")) {
				document.getElementById("myModal1").style.display = "none";
			}
		}
	</script>



	


<!-- modal form for add dashboard-->
	<div id="myModal3" class="modal1">

		<!-- Modal content -->
		<div class="modal-content1">
			<span id="close" class="close3">&times;</span>
			<h4>How to add an iFrame of a Kibana dashboard</h4><br>
			<ol>
			<li>Go to <i><b>Share</b></i> at top of Kibana Dashboard Screen and click <b><i>Embed Code</i></b></li><br>
			<img src="${pageContext.request.contextPath}/resources/assets/img/kibanaHelp1.jpg" alt="KIbana Help" style="margin-bottom:10px" "width="200" height="200">
			<br>
			<li>Choose <b><i>Saved Object</i></b> and <b><i>Copy iFrame</i></b></li><br>
			<img src="${pageContext.request.contextPath}/resources/assets/img/kibanaHelp2.jpg" alt="KIbana Help" width="200" height="200">
			<br>
			<li>Go to <b><i>Add Dashboard</i></b> and paste iFrame into <b><i>Dashboard Frame </i></b></li>
			<img src="${pageContext.request.contextPath}/resources/assets/img/dashboard.jpg" alt="KIbana Help" width="400" height="200">
			</ol>
			
		</div>

	</div>


	<script>
		// Get the modal
		var modal = document.getElementById("myModal3");

		// Get the button that opens the modal
		var btn = document.getElementById("myBtn3");

		// Get the <span> element that closes the modal
		var span = document.getElementsByClassName("close3")[0];

		// When the user clicks the button, open the modal 
		document.getElementById("myBtn3").onclick = function() {
			document.getElementById("myModal3").style.display = "block";
		}

		// When the user clicks on <span> (x), close the modal
		document.getElementsByClassName("close3")[0].onclick = function() {
			modal.style.display = "none";
		}

		// When the user clicks anywhere outside of the modal, close it
		window.onclick = function(event) {
			if (event.target == document.getElementById("myModal3")) {
				document.getElementById("myModal3").style.display = "none";
			}
		}
	</script>



	

<!-- display table to show all dashboards and actions-->
	<div class="row">
		<div class="col-md-8 col-sm-12 col-lg-12">

			<div class="card mb-4">
				<div class="card-header">
					<i class="fas fa-cogs" style="color:#ff6600"></i> Kibana Dashboards
				</div>
				<div class="card-body">
					<div class="table-responsive">
						<table class="table table-bordered" id="dataTable"
							style="width: 100%">
							<thead>
								<tr>
									<th>ID</th>
									<th>Name</th>
									<th>Actions</th>
								
								</tr>
							</thead>

							<tbody>
								<c:forEach var="tempDashboard" items="${dashboards}"
									varStatus="count">

									<!-- construct links  -->
									<c:url var="deleteLink" value="./deleteKibana">
										<c:param name="kibana" value="${tempDashboard.id}" />
									</c:url>

									
									<c:url var="showDashboardsLink" value="./showDashboards">
										<c:param name="kibana" value="${tempDashboard.id}" />
									</c:url>
									
									
								

									<!-- display dashboards-->
									<tr>
										<td id="dashboardValueId_${count.index}">${tempDashboard.id}</td>
										<td>${tempDashboard.dashboardName}</td>
										<td>
											<!-- display the update link -->
											<a href="#" id="myBtn2_${count.index}">Update</a>  | <a
											href="${deleteLink}"
											onclick="if (!(confirm('WARNING. Are you sure you want to DELETE this dashboard?'))) return false">Delete</a>
										</td>
									

									</tr>
									
										<!-- display modal form for changing dashboard name-->
										<div id="myModal2_${count.index}" class="modal1">
											<!-- Modal content -->
											<div class="modal-content1">
												<span id="close" class="close1_${count.index}">&times;</span>
												
												<h4> Update: ${tempDashboard.dashboardName}</h4>
												
												<form:form action="saveKibana" modelAttribute="kibana"
													method="POST">
													<!-- Associate cluster with ID for update -->
													<form:hidden path="id" id="idValue_${count.index}" value="" />

													<div class="form-group row">
														<div class="col-md-10 col-lg-10" style="padding: 10px">
															<label style="color: black">New Dashboard Name:</label>
															<form:input class="form-control form-control-md"
																path="dashboardName" />
														</div>
													</div>
													
													<div class="form-group row">
														<div class="col-md-10 col-lg-10" style="padding: 10px; margin-left:10px">
															<label style="color: black">New Dashboard iFrame:</label>
															<form:input class="form-control form-control-md"
																path="dashboardFrame" />
														</div>
													</div>

													<div class="row">
														<div class="col-md-2">
															<button class="btn btn-primary" type="submit"
																class="save">Update</button>
														</div>
													</div>

												</form:form>
											</div>

										</div>
			
										<!-- display modal form -->
										<script type="text/javascript">
											
											// Get the <span> element that closes the modal
											var span = document
													.getElementsByClassName("close1_${count.index}")[0];

											document
													.getElementById("idValue_${count.index}").value = document
													.getElementById("dashboardValueId_${count.index}").innerHTML;
											;

											// When the user clicks the button, open the modal 
											document
													.getElementById("myBtn2_${count.index}").onclick = function() {
												document
														.getElementById("myModal2_${count.index}").style.display = "block";
											}

											// When the user clicks on <span> (x), close the modal
											document
													.getElementsByClassName("close1_${count.index}")[0].onclick = function() {
												document
														.getElementById("myModal2_${count.index}").style.display = "none";
											}

											// When the user clicks anywhere outside of the modal, close it
											window.onclick = function(event) {
												if (event.target == document.getElementById("myModal2_${count.index}")) {
													document
															.getElementById("myModal2_${count.index}").style.display = "none";
												}
											}
										</script>
										
										
								</c:forEach>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>



</div>



</main>

