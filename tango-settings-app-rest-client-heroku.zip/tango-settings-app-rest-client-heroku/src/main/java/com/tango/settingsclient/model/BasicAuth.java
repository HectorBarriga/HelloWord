package com.tango.settingsclient.model;



public class BasicAuth {
	
	private int basicId;
	
	private Setting setting;
	
	private String username;
	
	private String password;

	public BasicAuth() {
		
	}

	
	public Setting getSetting() {
		return setting;
	}


	public void setSetting(Setting setting) {
		this.setting = setting;
	}


	public int getId() {
		return basicId;
	}

	public void setId(int id) {
		this.basicId = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}


	@Override
	public String toString() {
		return "BasicAuth [basicId=" + basicId + ", setting=" + setting + ", username=" + username + ", password="
				+ password + "]";
	}	

}
