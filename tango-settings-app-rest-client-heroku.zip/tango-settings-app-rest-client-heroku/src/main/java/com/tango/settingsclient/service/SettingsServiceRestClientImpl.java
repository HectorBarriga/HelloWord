package com.tango.settingsclient.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.tango.settingsclient.model.Cluster;
import com.tango.settingsclient.model.Result;
import com.tango.settingsclient.model.Setting;

@Service
public class SettingsServiceRestClientImpl implements SettingsService {

	private RestTemplate restTemplate;

	private String settingsRestUrl;
		
	private Logger logger = Logger.getLogger(getClass().getName());
	
	@Autowired
	public SettingsServiceRestClientImpl(RestTemplate theRestTemplate, 
										@Value("${settings.rest.url}") String theUrl ) {
		restTemplate = theRestTemplate;
		settingsRestUrl = theUrl;
	
				
		logger.info(" in SettingService : Loaded property:  settings.rest.url=" + settingsRestUrl);
	}
	
	//a method to get all api tests 
	@Override
	public List<Setting> getSettings() {
		
		logger.info("in SettingService getSettings(): Calling REST API " + settingsRestUrl);

		// make REST call
		ResponseEntity<List<Setting>> responseEntity = 
											restTemplate.exchange(settingsRestUrl, HttpMethod.GET, null, 
																  new ParameterizedTypeReference<List<Setting>>() {});

		List<Setting> settings = responseEntity.getBody();

		logger.info("in SettingService getSettings(): settings" + settings);

		
		return settings;
	}
	
	
	// a emthod to get all api test for a cluster
	@Override
	public List<Setting> getSettings(int cluster) {
		
		logger.info("in SettingService getSettings(): Calling REST API " + settingsRestUrl);

		// make REST call
		ResponseEntity<List<Setting>> responseEntity = 
											restTemplate.exchange(settingsRestUrl + "/" + cluster, HttpMethod.GET, null, 
																  new ParameterizedTypeReference<List<Setting>>() {});

		// get the list of customers from response
		List<Setting> settings = responseEntity.getBody();

		logger.info("in SettingService getSettings(): settings" + settings);

		
		return settings;
	}
	
	// a method to get all api test for a machine
	@Override
	public List<Setting> getSettingsMachine(int machine) {
		
		logger.info("in SettingService getSettings(): Calling REST API " + settingsRestUrl);

		// make REST call
		ResponseEntity<List<Setting>> responseEntity = 
											restTemplate.exchange(settingsRestUrl + "/machine/" + machine, HttpMethod.GET, null, 
																  new ParameterizedTypeReference<List<Setting>>() {});

		// get the list of customers from response
		List<Setting> settings = responseEntity.getBody();

		logger.info("in SettingService getSettings(): settings" + settings);

		
		return settings;
	}
	
	
	
	
	
	// a method to get the most recent api test
	@Override
	public int getRecentSetting() {

		logger.info("in SettingService  getSetting(): Calling REST API " + settingsRestUrl);

		// make REST call
		int theSetting = 
				restTemplate.getForObject(settingsRestUrl + "/get", Integer.class);

		logger.info("in SettingService  getRecentSetting(): theSetting=" + theSetting);
		
		return theSetting;
	}

	
	
	// a method to get test by id
	@Override
	public Setting getSetting(int theId) {

		logger.info("in SettingService  getSetting(id): Calling REST API " + settingsRestUrl);

		// make REST call
		Setting theSetting = 
				restTemplate.getForObject(settingsRestUrl + "/get/" + theId, 
										  Setting.class);

		logger.info("in SettingService getSetting(id): theSetting=" + theSetting);
		
		return theSetting;
	}
	
	//  mthod to save a test
	@Override
	public void saveSetting(Setting theSetting) {

		logger.info("in SettingService saveSetting(): Calling REST API " + settingsRestUrl);
		
		int settingId = theSetting.getId();

		// make REST call
		if (settingId == 0) {
			// add employee
			restTemplate.postForEntity(settingsRestUrl, theSetting, String.class);			
		
		} else {
			// update employee
			restTemplate.put(settingsRestUrl, theSetting);
		}

		logger.info("in SettingService saveSetting(): success");	
	}

	
	// a method to delete a test
	@Override
	public void deleteSetting(int theId) {

		logger.info("in SettingService deleteSetting(): Calling REST API " + settingsRestUrl + theId);

		// make REST call
		restTemplate.delete(settingsRestUrl + "/" + theId);

		logger.info("inSettingService  deleteSetting(): deleted setting theId=" + theId);
	}
	
	
	// a method to save the result of a test
	@Override
	public void saveResult(Result theResult, int theId) {

		logger.info("in SettingService saveResult(): Calling REST API " + settingsRestUrl);
		
		int settingId = theResult.getId();
		

		// make REST call
		if (settingId == 0) {
	
			restTemplate.postForEntity(settingsRestUrl + "/result" + "/" + theId, theResult, String.class);			
		
		} else {
			
			restTemplate.put(settingsRestUrl+ "/result" + "/" + theId, theResult);
		}

		logger.info("in SettingService saveResult(): success");	
	}

	

}
