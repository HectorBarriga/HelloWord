package com.tango.settingsclient.service;

import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.tango.settingsclient.model.Cluster;
import com.tango.settingsclient.model.Machine;
import com.tango.settingsclient.model.Setting;

@Service
public class MachineServiceImpl implements MachineService{
	
	private RestTemplate restTemplate;

	private String machinesRestUrl;
		
	private Logger logger = Logger.getLogger(getClass().getName());
	
	@Autowired
	public MachineServiceImpl(RestTemplate theRestTemplate, 
										@Value("${machines.rest.url}") String theUrl ) {
		restTemplate = theRestTemplate;
		machinesRestUrl = theUrl;
	
				
		logger.info("Loaded property:  clusters.rest.url=" + machinesRestUrl);
	}
	
	//a method to get all machines for a particular cluster
	@Override
	public List<Machine> getMachines(int clusterId) {
		
		logger.info("in machine service getSettings(): Calling REST API " + machinesRestUrl);

		// make REST call
		ResponseEntity<List<Machine>> responseEntity = 
											restTemplate.exchange(machinesRestUrl+ "/" + clusterId, HttpMethod.GET, null, 
																  new ParameterizedTypeReference<List<Machine>>() {});

	
		List<Machine> machines = responseEntity.getBody();

		logger.info("in  machine service getMachine(): machines" + machines);

		
		return machines;
	}
	
	
	// a method to get a machine by its id
	@Override
	public Machine getMachine(int theId) {

		logger.info("in  machine service getMachine(id): Calling REST API " + machinesRestUrl);

		// make REST call
		Machine theMachine = 
				restTemplate.getForObject(machinesRestUrl + "/get/" + theId, 
										  Machine.class);

		logger.info("in  machine service getMachine(): theMachine=" + theMachine);
		
		return theMachine;
	}

	
	//a  method to save a machine object
	@Override
	public void saveMachine(Machine theMachine) {

		logger.info("in  machine service saveMachine(): Calling REST API " + machinesRestUrl);
		
		int settingId = theMachine.getId();

		// make REST call
		if (settingId == 0) {
			
			restTemplate.postForEntity(machinesRestUrl, theMachine, Machine.class);			
		
		} else {
		
			restTemplate.put(machinesRestUrl, theMachine);
		}

		logger.info("in  machine service saveMachine(): success");	
	}

	
	//a method to delete machine object
	@Override
	public void deleteMachine(int theId) {

		logger.info("in deleteSetting(): Calling REST API " + machinesRestUrl + theId);

		// make REST call
		restTemplate.delete(machinesRestUrl + "/" + theId);

		logger.info("in  machine service deleteMachine(): deleted machine theId=" + theId);
	}

}
