package com.tango.settingsclient.controller;

import java.util.ArrayList;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.tango.settingsclient.model.Cluster;
import com.tango.settingsclient.model.HealthResult;
import com.tango.settingsclient.model.HealthSetting;
import com.tango.settingsclient.model.Kibana;
import com.tango.settingsclient.model.Header;
import com.tango.settingsclient.model.Machine;
import com.tango.settingsclient.model.Result;
import com.tango.settingsclient.model.Setting;

import com.tango.settingsclient.service.ApiService;
import com.tango.settingsclient.service.ClusterService;
import com.tango.settingsclient.service.CommandService;
import com.tango.settingsclient.service.HealthSettingsService;
import com.tango.settingsclient.service.KibanaService;
import com.tango.settingsclient.service.MachineService;
import com.tango.settingsclient.service.SettingsService;

@Controller
@RequestMapping("/setting")
public class SettingsClientController {

	// need to inject our services
	@Autowired
	private SettingsService settingService;
	@Autowired
	private ApiService apiService;

	@Autowired
	private ClusterService clusterService;

	@Autowired
	private MachineService machineService;

	@Autowired
	private HealthSettingsService commandSettingService;

	@Autowired
	private CommandService commandService;
	
	@Autowired
	private KibanaService kibanaService;
	
	
	// a method get the list of test for the particular machine and cluster 
	@GetMapping("/list")
	public String listSettingsMachine(@RequestParam("machine") int machine, @RequestParam("cluster") int cluster,
			Model theModel) {

		// get settings from the service for specific machine and cluster for api tests
		List<Setting> theSettings = settingService.getSettingsMachine(machine);

		//get the a machine and cluster to add to the model
		Machine theMachine = new Machine();
		theMachine = machineService.getMachine(machine);
		Cluster theCluster = clusterService.getCluster(cluster);
		
		//get clusters for sidenav
		List<Cluster> theClusters = clusterService.getClusters();
		
		List<Kibana> theDashboards = kibanaService.getDashboards();
		theModel.addAttribute("dashboards", theDashboards);

		
		//add attributes to the model
		theModel.addAttribute("clusters", theClusters);
		theModel.addAttribute("settings", theSettings);
		theModel.addAttribute("machine", theMachine);
		theModel.addAttribute("cluster", theCluster);

		return "list-dashboard";
	}

	
	
	//a method to display the input form for adding a new (api) test setting. Request cluster, machine for filtering and categorizing
	@GetMapping("/form")
	public String showFormForAdd(@RequestParam("machine") int machine, @RequestParam("cluster") int cluster,
			Model theModel) {

		//Create objects to put into the model
		Setting theSetting = new Setting();
		Machine theMachine = new Machine();
		theMachine = machineService.getMachine(machine);
		Cluster theCluster = clusterService.getCluster(cluster);
		
		//get list of clusters for the sidenav
		List<Cluster> theClusters = clusterService.getClusters();
		
		List<Kibana> theDashboards = kibanaService.getDashboards();
		theModel.addAttribute("dashboards", theDashboards);

		//add to the model
		theModel.addAttribute("clusters", theClusters);
		theModel.addAttribute("setting", theSetting);
		theModel.addAttribute("cluster", theCluster);
		theModel.addAttribute("machine", theMachine);

		return "form-all";
	}

	
	
	//a post request method to save new api test setting, redirect attributes

	@PostMapping("/saveSetting")
	public String saveSetting(RedirectAttributes redirectAttributes, @ModelAttribute("setting") Setting theSetting) {
		
		//generate the curl before saving
		theSetting.generateCurl();

		//save setting
		settingService.saveSetting(theSetting);
		
		//get ids to redirect 
		int clusterId = theSetting.getCluster().getId();
		int machineId = theSetting.getMachine().getId();

		redirectAttributes.addAttribute("machine", machineId);
		redirectAttributes.addAttribute("cluster", clusterId);

		return "redirect:/setting/showResultRecent";
	}

	
	/* 
	 * a mthod to show the form for when the settings are being updated
	 */
	@GetMapping("/showFormForUpdate")
	public String showFormForUpdate(@RequestParam("settingId") int theId, @RequestParam("machine") int machine,
			@RequestParam("cluster") int cluster, Model theModel) {

		// get the attributes for the model
		Setting theSetting = settingService.getSetting(theId);
		Machine theMachine = machineService.getMachine(machine);
		Cluster theCluster = clusterService.getCluster(cluster);
		
		//get clusters for sidenav
		List<Cluster> theClusters = clusterService.getClusters();
		
		List<Kibana> theDashboards = kibanaService.getDashboards();
		theModel.addAttribute("dashboards", theDashboards);

		//add attributes to model
		theModel.addAttribute("clusters", theClusters);
		theModel.addAttribute("setting", theSetting);
		theModel.addAttribute("machine", theMachine);
		theModel.addAttribute("cluster", theCluster);

		return "form-all";
	}

	/*
	 * a method to delete the test setting
	 */
	@GetMapping("/delete")
	public String deleteSetting(RedirectAttributes redirectAttributes, @RequestParam("machine") int machine,
			@RequestParam("cluster") int cluster, @RequestParam("settingId") int theId) {

		settingService.deleteSetting(theId);

		redirectAttributes.addAttribute("cluster", cluster);
		redirectAttributes.addAttribute("machine", machine);

		return "redirect:/setting/list";
	}

	
	//method to display result of a test with sepcific id
	@GetMapping("/showResult")
	public String showResult(@RequestParam("machine") int machine, @RequestParam("cluster") int cluster,
			@RequestParam("settingId") int theId, Model theModel) {

		//get clusters for sidenav
		List<Cluster> theClusters = clusterService.getClusters();
		
		//get setting, machine and cluster and rerun the test before saving most recent result to display
		Setting theSetting = settingService.getSetting(theId);
		Machine theMachine = machineService.getMachine(machine);
		Cluster theCluster = clusterService.getCluster(cluster);
		String theOutput = apiService.getJson(theSetting);
		Result result = apiService.getResult(theSetting, theOutput);

		settingService.saveResult(result, theId);

		theSetting = settingService.getSetting(theId);
		
		List<Kibana> theDashboards = kibanaService.getDashboards();
		theModel.addAttribute("dashboards", theDashboards);

		theModel.addAttribute("cluster", theCluster);
		theModel.addAttribute("clusters", theClusters);
		theModel.addAttribute("machine", theMachine);
		theModel.addAttribute("output", theOutput);
		theModel.addAttribute("setting", theSetting);

		return "results-boot-2";
	}

	/*
	 * a method to get the results of the most recently saved setting - so the
	 * setting can be saved and the ran and result saved simultaneously
	 */

	@GetMapping("/showResultRecent")
	public String showResultRecent(@RequestParam("machine") int machine, @RequestParam("cluster") int cluster,
			Model theModel) {

		// get the id of the most recent setting saved for an api test
		int recentSettingId = settingService.getRecentSetting();
		Setting theSetting = settingService.getSetting(recentSettingId);

		// run the test and get the response and status and save result
		String theOutput = apiService.getJson(theSetting);
		Result result = apiService.getResult(theSetting, theOutput);
		settingService.saveResult(result, recentSettingId);
		theSetting = settingService.getSetting(recentSettingId);
		
		
		// Get list of clusters for sidenav
		List<Cluster> theClusters = clusterService.getClusters();
		
		List<Kibana> theDashboards = kibanaService.getDashboards();
		theModel.addAttribute("dashboards", theDashboards);
		
		// Get the machine and cluster of test to display and for filtering
		Machine theMachine = machineService.getMachine(machine);
		Cluster theCluster = clusterService.getCluster(cluster);

		theModel.addAttribute("cluster", theCluster);
		theModel.addAttribute("clusters", theClusters);
		theModel.addAttribute("machine", theMachine);
		theModel.addAttribute("output", theOutput);
		theModel.addAttribute("setting", theSetting);

		return "results-boot-2";
	}

	
	/*
	 * a method to display all the results of a partuclar machine and cluster
	 */
	@GetMapping("/showResults")
	public String showResults(@RequestParam("cluster") int cluster, @RequestParam("machine") int machine,
			Model theModel) {

		//get the tests for that machine
		List<Setting> theSettings = settingService.getSettingsMachine(machine);

		//get cluster and machine for model
		Cluster theCluster = new Cluster();
		theCluster = clusterService.getCluster(cluster);
		Machine theMachine = new Machine();
		theMachine = machineService.getMachine(machine);

		
		//rerun all tests to make sure they are up-to-date
		for (Setting setting : theSettings) {
			String theJson = apiService.getJson(setting);
			Result result = apiService.getResult(setting, theJson);
			settingService.saveResult(result, setting.getId());
			setting = settingService.getSetting(setting.getId());
		}

		//get clusters for sidenav
		List<Cluster> theClusters = clusterService.getClusters();
		List<Kibana> theDashboards = kibanaService.getDashboards();
		theModel.addAttribute("dashboards", theDashboards);

		theModel.addAttribute("clusters", theClusters);
		theModel.addAttribute("settings", theSettings);
		theModel.addAttribute("cluster", theCluster);
		theModel.addAttribute("machine", theMachine);

		return "monitor-all";
	}

	
	/*
	 * a method to display all the clusters and up-to-date test results in pice charts
	 */
	@GetMapping("/showClusters")
	public String showClusters(@Value("${settings.rest.url}") String settingUrl,
			@Value("${commandSettings.rest.url}") String commandUrl, Model theModel) {

		
		//add api urls to model for javascript to use to get data for pie charts
		theModel.addAttribute("settingUrl", settingUrl);
		theModel.addAttribute("commandUrl", commandUrl);

		//get clusters for sidenav
		List<Cluster> theClusters = clusterService.getClusters();

		theModel.addAttribute("clusters", theClusters);

		//get cluster to add to model to be able to retrieve each cluster name
		Cluster cluster = new Cluster();
		theModel.addAttribute("cluster", cluster);
		
		List<Kibana> theDashboards = kibanaService.getDashboards();
		theModel.addAttribute("dashboards", theDashboards);

		//re run all tests for refresh to ensure up-to-date results.
		List<HealthSetting> theCommandSettings = commandSettingService.getSettings();
		for (HealthSetting setting : theCommandSettings) {
			String theJson = commandService.runCommand(setting.getCommand());
			HealthResult result = commandService.getResult(setting, theJson);
			commandSettingService.saveResult(result, setting.getId());

		}

		List<Setting> theSettings = settingService.getSettings();

		for (Setting setting : theSettings) {
			String theJson = apiService.getJson(setting);
			Result result = apiService.getResult(setting, theJson);
			settingService.saveResult(result, setting.getId());
		}

		return "cluster-all";
	}

	//a method to diplay data for the cluster configuration page
	@GetMapping("/configureClusters")
	public String configureClusters(Model theModel) {

		
		//get all clusters for sidenav
		List<Cluster> theClusters = clusterService.getClusters();
		theModel.addAttribute("clusters", theClusters);

		//add cluster and machine for model
		Cluster cluster = new Cluster();
		Machine machine = new Machine();
		
		List<Kibana> theDashboards = kibanaService.getDashboards();
		theModel.addAttribute("dashboards", theDashboards);
		
		theModel.addAttribute("machine", machine);
		theModel.addAttribute("cluster", cluster);

		return "configure-all";
	}

	/*
	 * a method to save the cluster
	 */
	@PostMapping("/saveCluster")
	public String saveCluster(RedirectAttributes redirectAttributes, @ModelAttribute("cluster") Cluster theCluster) {

		clusterService.saveCluster(theCluster);

		return "redirect:/setting/configureClusters";
	}

	
	/*
	 * method to update cluster
	 */
	@PutMapping("/updateCluster")
	public String updateCluster(@RequestParam("clusterId") int theId, Model theModel) {

		Cluster theCluster = clusterService.getCluster(theId);
		theModel.addAttribute("cluster", theCluster);

		return "redirect:/setting/configureClusters";
	}

	/*
	 * a method to delete cluster
	 */
	@GetMapping("/deleteCluster")
	public String deleteCluster(RedirectAttributes redirectAttributes, @RequestParam("clusterId") int theId) {

		// delete the cluster
		clusterService.deleteCluster(theId);

		return "redirect:/setting/configureClusters";
	}

	
	/*
	 * a mthod to display data of all machines for a given cluster
	 */
	@GetMapping("/showMachines")
	public String showMachine(@Value("${settings.rest.url}") String settingUrl,
			@Value("${commandSettings.rest.url}") String commandUrl, @RequestParam("cluster") int clusterId,
			Model theModel) {

		
		
		theModel.addAttribute("settingUrl", settingUrl);
		theModel.addAttribute("commandUrl", commandUrl);

		//get all machines for model
		List<Machine> theMachines = machineService.getMachines(clusterId);

		theModel.addAttribute("machines", theMachines);
		// create model attribute to bind form data

		Machine machine = new Machine();
		Cluster theCluster = new Cluster();

		
		//get specific cluster
		theCluster = clusterService.getCluster(clusterId);
		
		//get all clusters for sidenav
		List<Cluster> theClusters = clusterService.getClusters();
		
		List<Kibana> theDashboards = kibanaService.getDashboards();
		theModel.addAttribute("dashboards", theDashboards);

		
		//rerun all tests for refresh
		List<HealthSetting> theCommandSettings = commandSettingService.getSettings(clusterId);
		for (HealthSetting setting : theCommandSettings) {
			String theJson = commandService.runCommand(setting.getCommand());
			HealthResult result = commandService.getResult(setting, theJson);
			commandSettingService.saveResult(result, setting.getId());

		}

		List<Setting> theSettings = settingService.getSettings(clusterId);

		for (Setting setting : theSettings) {
			String theJson = apiService.getJson(setting);
			Result result = apiService.getResult(setting, theJson);
			settingService.saveResult(result, setting.getId());
		}

		theModel.addAttribute("clusters", theClusters);

		theModel.addAttribute("machine", machine);
		theModel.addAttribute("cluster", theCluster);
		return "machine-all";
	}

	
	//a get request method to show all the tests for a specific machine
	@GetMapping("/showMachinesTests")
	public String showMachineTests(@Value("${settings.rest.url}") String settingUrl,
			@Value("${commandSettings.rest.url}") String commandUrl, @RequestParam("machine") int machineId,
			@RequestParam("cluster") int clusterId, Model theModel) {

		// add api urls for javascript to retrieve the data for charts
		theModel.addAttribute("settingUrl", settingUrl);
		theModel.addAttribute("commandUrl", commandUrl);

		
		//get machine and cluster for filtering
		Machine theMachine = machineService.getMachine(machineId);
		Cluster theCluster = clusterService.getCluster(clusterId);

		//get clusters for sidenav
		List<Cluster> theClusters = clusterService.getClusters();
		
		List<Kibana> theDashboards = kibanaService.getDashboards();
		theModel.addAttribute("dashboards", theDashboards);

		theModel.addAttribute("clusters", theClusters);
		theModel.addAttribute("machine", theMachine);
		theModel.addAttribute("cluster", theCluster);

		
		//rerun alll tests for refresh
		List<HealthSetting> theCommandSettings = commandSettingService.getSettings(machineId);
		for (HealthSetting setting : theCommandSettings) {
			String theJson = commandService.runCommand(setting.getCommand());
			HealthResult result = commandService.getResult(setting, theJson);
			commandSettingService.saveResult(result, setting.getId());

		}

		List<Setting> theSettings = settingService.getSettings(machineId);

		for (Setting setting : theSettings) {
			String theJson = apiService.getJson(setting);
			Result result = apiService.getResult(setting, theJson);
			settingService.saveResult(result, setting.getId());
		}

		return "machine-test-all";
	}

	
	//a method to retrieve all machine to add to model for delete machine form
	@GetMapping("/deleteMachineForm")
	public String deleteMachineForm(@RequestParam("cluster") int cluster, Model theModel) {

		List<Machine> machines = machineService.getMachines(cluster);

		theModel.addAttribute("machines", machines);

		return "form-boot-2";
	}

	//a methofd to save a machine
	@PostMapping("/saveMachine")
	public String saveMachine(RedirectAttributes redirectAttributes, @ModelAttribute("machine") Machine theMachine) {

		machineService.saveMachine(theMachine);
		int clusterId = theMachine.getCluster().getId();
		redirectAttributes.addAttribute("cluster", clusterId);

		return "redirect:/setting/configureClusters";
	}


	//a thod to delete a machibe
	@GetMapping("/deleteMachine")
	public String deleteMachine(RedirectAttributes redirectAttributes, @RequestParam("machineId") int theId,
			@RequestParam("clusterId") int clusterId) {

		redirectAttributes.addAttribute("cluster", clusterId);

		machineService.deleteMachine(theId);

		return "redirect:/setting/configureClusters";
	}

	
	//a method to configure kibana graphs
	@GetMapping("/showConfigureKibana")
	public String showConfigureKibana(Model theModel) {
		
		Kibana theKibana = new Kibana();
		List<Cluster> theClusters = clusterService.getClusters();
		List<Kibana> theDashboards = kibanaService.getDashboards();
		
		theModel.addAttribute("clusters", theClusters);
		theModel.addAttribute("kibana", theKibana);
		theModel.addAttribute("dashboards", theDashboards);
		
		

		return "configure-all-kibana";
	}

	/*
	 * a method to save the dashboard
	 */
	@PostMapping("/saveKibana")
	public String saveKibana(RedirectAttributes redirectAttributes, @ModelAttribute("kibana") Kibana theKibana) {

		kibanaService.saveDashboard(theKibana);

		return "redirect:/setting/showConfigureKibana";
	}
	
	/*
	 * a method to delete dashboard
	 */
	@GetMapping("/deleteKibana")
	public String deleteKibana(RedirectAttributes redirectAttributes, @RequestParam("kibana") int theId) {

		// delete the cluster
		kibanaService.deleteDashboard(theId);

		return "redirect:/setting/showConfigureKibana";
	}
	
	//method to diplay kibana graphs
		@GetMapping("/showKibana")
		public String showKibana(Model theModel, @RequestParam("kibana") int theKibanaId) {
			
			//get clusters for sidenav
			List<Cluster> theClusters = clusterService.getClusters();
			
			List<Kibana> theDashboards = kibanaService.getDashboards();
			theModel.addAttribute("dashboards", theDashboards);
			
			Kibana theKibana = kibanaService.getDashboard(theKibanaId);
			
			theModel.addAttribute("kibana", theKibana);
			theModel.addAttribute("clusters", theClusters);

			return "kibana-all";
		}
}
