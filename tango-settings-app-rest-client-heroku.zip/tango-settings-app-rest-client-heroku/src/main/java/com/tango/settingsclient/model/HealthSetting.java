package com.tango.settingsclient.model;

import java.util.Date;

import java.util.List;


public class HealthSetting {
	
	private int id;
	
	private String testName;
	
	private HealthCommand command;
	
	private String searchWord;
	
	private boolean expected;
	
	private String info;
	
	private String searchWord2;

	private int min;
	
	private int max;
	
	private String test;
	
	private String warningMessage;
	
	private boolean and;

	private boolean or;
		
	private HealthResult result;
	
	private int severity;
	
	private Date modifyDate;
	
	private Cluster cluster;
	
	private Machine machine;

	public HealthSetting() {
		super();
	
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTestName() {
		return testName;
	}

	public void setTestName(String testName) {
		this.testName = testName;
	}

	public HealthCommand getCommand() {
		return command;
	}

	public void setCommand(HealthCommand command) {
		this.command = command;
	}

	public String getSearchWord() {
		return searchWord;
	}

	public void setSearchWord(String searchWord) {
		this.searchWord = searchWord;
	}

	public boolean isExpected() {
		return expected;
	}

	public void setExpected(boolean expected) {
		this.expected = expected;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public HealthResult getResult() {
		return result;
	}

	public void setResult(HealthResult result) {
		this.result = result;
	}

	public int getSeverity() {
		return severity;
	}

	public void setSeverity(int severity) {
		this.severity = severity;
	}

	public Date getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}

	public Cluster getCluster() {
		return cluster;
	}

	public void setCluster(Cluster cluster) {
		this.cluster = cluster;
	}

	public Machine getMachine() {
		return machine;
	}

	public void setMachine(Machine machine) {
		this.machine = machine;
	}

	
	public String getSearchWord2() {
		return searchWord2;
	}

	public void setSearchWord2(String searchWord2) {
		this.searchWord2 = searchWord2;
	}

	public int getMin() {
		return min;
	}

	public void setMin(int min) {
		this.min = min;
	}

	public int getMax() {
		return max;
	}

	public void setMax(int max) {
		this.max = max;
	}

	public boolean isAnd() {
		return and;
	}

	public void setAnd(boolean and) {
		this.and = and;
	}

	public boolean isOr() {
		return or;
	}

	public void setOr(boolean or) {
		this.or = or;
	}

	
	public String getTest() {
		return test;
	}

	public void setTest(String test) {
		this.test = test;
	}

	
	public String getWarningMessage() {
		return warningMessage;
	}

	public void setWarningMessage(String warningMessage) {
		this.warningMessage = warningMessage;
	}

	@Override
	public String toString() {
		return "HealthSetting [id=" + id + ", testName=" + testName + ", command=" + command + ", searchWord="
				+ searchWord + ", expected=" + expected + ", info=" + info + ", searchWord2=" + searchWord2 + ", min="
				+ min + ", max=" + max + ", test=" + test + ", warningMessage=" + warningMessage + ", and=" + and
				+ ", or=" + or + ", result=" + result + ", severity=" + severity + ", modifyDate=" + modifyDate
				+ ", cluster=" + cluster + ", machine=" + machine + "]";
	}
	
	}

	
	
	
	


