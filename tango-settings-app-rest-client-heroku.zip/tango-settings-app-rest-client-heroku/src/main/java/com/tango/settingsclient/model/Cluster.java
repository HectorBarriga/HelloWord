package com.tango.settingsclient.model;

import java.util.List;
import java.util.Set;


public class Cluster {

	private int id;
	
	private String clusterName;
	
	private Set <Setting> settings;
	
	private Set<Machine> machines;

	
	

	public Cluster() {
	
	}


	public String getClusterName() {
		return clusterName;
	}


	public void setClusterName(String clusterName) {
		this.clusterName = clusterName;
	}



	public Set<Setting> getSettings() {
		return settings;
	}


	public void setSettings(Set<Setting> settings) {
		this.settings = settings;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public Set<Machine> getMachines() {
		return machines;
	}


	public void setMachines(Set<Machine> machines) {
		this.machines = machines;
	}


	@Override
	public String toString() {
		return "Cluster [id=" + id + ", clusterName=" + clusterName + ", settings=" + settings + ", machines="
				+ machines + "]";
	}


}
