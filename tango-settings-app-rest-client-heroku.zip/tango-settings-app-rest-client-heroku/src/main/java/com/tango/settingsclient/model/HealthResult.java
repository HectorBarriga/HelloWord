package com.tango.settingsclient.model;

import java.sql.Date;

public class HealthResult {
	
	private int id;
	
	private String commandOutput;
	
	private boolean statusOk;
	

	
	private HealthSetting setting;
	
	private Date modifyDate;
	
	private int severity;
	
	public HealthResult() {
	
	}
	
	
	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}



	public boolean isStatusOk() {
		return statusOk;
	}

	public void setStatusOk(boolean statusOk) {
		this.statusOk = statusOk;
	}



	public HealthSetting getSetting() {
		return setting;
	}


	public void setSetting(HealthSetting setting) {
		this.setting = setting;
	}


	public Date getModifyDate() {
		return modifyDate;
	}


	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}

	

	public int getSeverity() {
		return severity;
	}


	public void setSeverity(int severity) {
		this.severity = severity;
	}


	public void setCommandOutput(String commandOutput) {
		this.commandOutput = commandOutput;
	}
	public String getCommandOutput() {
		return commandOutput;
	}


	@Override
	public String toString() {
		return "HealthResult [id=" + id + ", commandOutput=" + commandOutput + ", statusOk=" + statusOk + ", setting="
				+ setting + ", modifyDate=" + modifyDate + ", severity=" + severity + "]";
	}


}
