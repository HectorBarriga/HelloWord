package com.tango.settingsclient.service;

import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.tango.settingsclient.model.Cluster;
import com.tango.settingsclient.model.Setting;

@Service
public class ClusterServiceImpl implements ClusterService {

	private RestTemplate restTemplate;

	private String clustersRestUrl;

	private Logger logger = Logger.getLogger(getClass().getName());

	@Autowired
	public ClusterServiceImpl(RestTemplate theRestTemplate, @Value("${clusters.rest.url}") String theUrl) {
		restTemplate = theRestTemplate;
		clustersRestUrl = theUrl;

		logger.info("in Cluster service : Loaded property:  clusters.rest.url=" + clustersRestUrl);
	}

	@Override
	public List<Cluster> getClusters() {

		logger.info("in Cluster service : getClusters(): Calling REST API " + clustersRestUrl);

		// make REST call
		ResponseEntity<List<Cluster>> responseEntity = restTemplate.exchange(clustersRestUrl, HttpMethod.GET, null,
				new ParameterizedTypeReference<List<Cluster>>() {
				});

		List<Cluster> clusters = responseEntity.getBody();

		logger.info("in in Cluster service : getClusters(): clusters" + clusters);

		return clusters;
	}

	@Override
	public Cluster getCluster(int theId) {

		logger.info("in in Cluster service : getCluster(id): Calling REST API " + clustersRestUrl);

		// make REST call
		Cluster theCluster = restTemplate.getForObject(clustersRestUrl + "/" + theId, Cluster.class);

		logger.info("in saveSetting(): theSetting=" + theCluster);

		return theCluster;
	}

	@Override
	public void saveCluster(Cluster theCluster) {

		logger.info("in in Cluster service : saveCluster(): Calling REST API " + clustersRestUrl);

		int clusterId = theCluster.getId();
		System.out.print("the cluster Id is" + theCluster.getId());

		// make REST call
		if (clusterId == 0) {
			restTemplate.postForEntity(clustersRestUrl, theCluster, Cluster.class);

		} else {
			restTemplate.put(clustersRestUrl, theCluster);
		}

		logger.info("in in Cluster service : saveCluster(): success");
	}

	@Override
	public void deleteCluster(int theId) {

		logger.info("in in Cluster service : deleteCluster(): Calling REST API " + clustersRestUrl + theId);

		// make REST call
		restTemplate.delete(clustersRestUrl + "/" + theId);

		logger.info("in Cluster service :  deleteCluster(): deleted cluster theId=" + theId);
	}

}
