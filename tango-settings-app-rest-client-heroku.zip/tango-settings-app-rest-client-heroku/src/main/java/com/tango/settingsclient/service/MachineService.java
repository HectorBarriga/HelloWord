package com.tango.settingsclient.service;

import java.util.List;

import com.tango.settingsclient.model.Cluster;
import com.tango.settingsclient.model.Machine;

public interface MachineService {

	List<Machine> getMachines(int clusterId);

	Machine getMachine(int theId);

	void saveMachine(Machine theMachine);

	void deleteMachine(int theId);

}
