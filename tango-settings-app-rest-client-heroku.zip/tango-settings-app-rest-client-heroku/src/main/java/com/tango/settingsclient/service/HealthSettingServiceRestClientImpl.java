package com.tango.settingsclient.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.tango.settingsclient.model.Cluster;
import com.tango.settingsclient.model.HealthResult;
import com.tango.settingsclient.model.HealthSetting;
import com.tango.settingsclient.model.Result;
import com.tango.settingsclient.model.Setting;

@Service
public class HealthSettingServiceRestClientImpl implements HealthSettingsService {

	private RestTemplate restTemplate;

	private String commandSettingsRestUrl;
		
	private Logger logger = Logger.getLogger(getClass().getName());
	
	@Autowired
	public HealthSettingServiceRestClientImpl(RestTemplate theRestTemplate, 
										@Value("${commandSettings.rest.url}") String theUrl ) {
		restTemplate = theRestTemplate;
		commandSettingsRestUrl = theUrl;
	
				
		logger.info("Loaded: Health setting service, property: settings.rest.url=" + commandSettingsRestUrl);
	}
	
	@Override
	public List<HealthSetting> getSettings() {
		
		logger.info("in Health setting service getSettings(): Calling REST API " + commandSettingsRestUrl);

		// make REST call
		ResponseEntity<List<HealthSetting>> responseEntity = 
											restTemplate.exchange(commandSettingsRestUrl, HttpMethod.GET, null, 
																  new ParameterizedTypeReference<List<HealthSetting>>() {});

		List<HealthSetting> settings = responseEntity.getBody();

		logger.info("in Health setting service getSettings(): settings");

		
		return settings;
	}
	
	
	
	@Override
	public List<HealthSetting> getSettings(int cluster) {
		
		logger.info("in Health setting service getSettings(clusterId): Calling REST API " + commandSettingsRestUrl);

		// make REST call
		ResponseEntity<List<HealthSetting>> responseEntity = 
											restTemplate.exchange(commandSettingsRestUrl + "/" + cluster, HttpMethod.GET, null, 
																  new ParameterizedTypeReference<List<HealthSetting>>() {});

		List<HealthSetting> settings = responseEntity.getBody();

		logger.info("in health setting service getSettings(): success");

		
		return settings;
	}
	
	@Override
	public List<HealthSetting> getSettingsMachine(int machine) {
		
		logger.info("in health setting service service getSettingsMachine(): Calling REST API " + commandSettingsRestUrl);

		// make REST call
		ResponseEntity<List<HealthSetting>> responseEntity = 
											restTemplate.exchange(commandSettingsRestUrl + "/machine/" + machine, HttpMethod.GET, null, 
																  new ParameterizedTypeReference<List<HealthSetting>>() {});

		
		List<HealthSetting> settings = responseEntity.getBody();

		logger.info("in health setting service getSettingsMachine(): success");

		
		return settings;
	}
	
	@Override
	public List<HealthSetting> getSettingsMachineTest(int machine, String test) {
		
		logger.info("in healths etting service service getSettingsMachineTest(): Calling REST API " + commandSettingsRestUrl);

		// make REST call
		ResponseEntity<List<HealthSetting>> responseEntity = 
											restTemplate.exchange(commandSettingsRestUrl + "/machine/"+ test + "/" + machine , HttpMethod.GET, null, 
																  new ParameterizedTypeReference<List<HealthSetting>>() {});

	
		List<HealthSetting> settings = responseEntity.getBody();

		logger.info("in health setting service TEST getSettingsMachineTest(): success");

		
		return settings;
	}
	
	
	
	
	// a method to call settings api and get most recent setting for linux command line tests
	@Override
	public int getRecentSetting() {

		logger.info("in getSetting(): Calling REST API " + commandSettingsRestUrl);

		// make REST call
		int theSetting = 
				restTemplate.getForObject(commandSettingsRestUrl + "/get", Integer.class);

		logger.info("in healths setting service getREcentSetting(): theSetting=" + theSetting);
		
		return theSetting;
	}

	
	// a method to get test by id by calling api
	@Override
	public HealthSetting getSetting(int theId) {

		logger.info("in health setting service getSetting(id): Calling REST API " + commandSettingsRestUrl);

		// make REST call
		HealthSetting theSetting = 
				restTemplate.getForObject(commandSettingsRestUrl + "/get/" + theId, 
										 HealthSetting.class);

		logger.info("in  health setting service getSetting(id): theSetting=" + theSetting);
		
		return theSetting;
	}
	
	
	//a  method to save the new linux command test setting
	@Override
	public void saveSetting(HealthSetting theSetting) {

		logger.info("in health setting service saveSetting(): Calling REST API " + commandSettingsRestUrl);
		
		int settingId = theSetting.getId();

		// make REST call
		if (settingId == 0) {
			
			restTemplate.postForEntity(commandSettingsRestUrl, theSetting, String.class);			
		
		} else {
			
			restTemplate.put(commandSettingsRestUrl, theSetting);
		}

		logger.info("in health setting service saveSetting(): success");	
	}

	
	//a method to delete the linux command test setting
	@Override
	public void deleteSetting(int theId) {

		logger.info("in health setting service  deleteSetting(): Calling REST API " + commandSettingsRestUrl + theId);

		// make REST call
		restTemplate.delete(commandSettingsRestUrl + "/" + theId);

		logger.info("in health setting service deleteSetting(): deleted setting theId=" + theId);
	}
	
	
	// a method to save the result of a particular test setting by setting id
	
	@Override
	public void saveResult(HealthResult theResult, int theId) {

		logger.info("in health setting service saveResult(): Calling REST API " + commandSettingsRestUrl);
		
		int settingId = theResult.getId();
		System.out.print(theId);

		// make REST call
		if (settingId == 0) {

			restTemplate.postForEntity(commandSettingsRestUrl + "/result" + "/" + theId, theResult, String.class);			
		
		} else {
		
			restTemplate.put(commandSettingsRestUrl+ "/result" + "/" + theId, theResult);
		}

		logger.info("in health setting service saveResult(): success");	
	}



}
