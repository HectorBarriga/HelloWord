package com.tango.settingsclient.controller;

import java.util.ArrayList;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.tango.settingsclient.model.Cluster;
import com.tango.settingsclient.model.HealthResult;
import com.tango.settingsclient.model.HealthSetting;
import com.tango.settingsclient.model.Kibana;
import com.tango.settingsclient.model.Header;
import com.tango.settingsclient.model.Machine;
import com.tango.settingsclient.model.Result;
import com.tango.settingsclient.model.Setting;

import com.tango.settingsclient.service.ApiService;
import com.tango.settingsclient.service.ClusterService;
import com.tango.settingsclient.service.CommandService;
import com.tango.settingsclient.service.HealthSettingsService;
import com.tango.settingsclient.service.KibanaService;
import com.tango.settingsclient.service.MachineService;
import com.tango.settingsclient.service.SettingsService;

@Controller
@RequestMapping("/commandSetting")
public class HealthSettingsClientController {

	
	// inject services
	
	@Autowired
	private SettingsService settingsService;
	
	@Autowired
	private ApiService apiService;

	@Autowired
	private HealthSettingsService commandSettingService;
	
	@Autowired
	private CommandService commandService;

	@Autowired
	private ClusterService clusterService;

	@Autowired
	private MachineService machineService;

	@Autowired
	private KibanaService kibanaService;
	
	// a method get the list of test for the particular machine and cluster 
	@GetMapping("/list")
	public String listSettingsMachine(@RequestParam("machine") int machine, @RequestParam("cluster") int cluster,
			@RequestParam("test") String test, Model theModel) {

		//get the test settings calling get SettingsMachineTest method for specific machine, cluster and test type
		List<HealthSetting> theSettings = commandSettingService.getSettingsMachineTest(machine, test);
		//get the a machine and cluster to add to the model
		Machine theMachine = new Machine();
		theMachine = machineService.getMachine(machine);
		Cluster theCluster = clusterService.getCluster(cluster);
		
		//get list of clusters to add to model for dynamic sidenav
		List<Cluster> theClusters = clusterService.getClusters();
		
		List<Kibana> theDashboards = kibanaService.getDashboards();
		theModel.addAttribute("dashboards", theDashboards);

		//put all the attributes into the model including test type
		theModel.addAttribute("test", test);
		theModel.addAttribute("clusters", theClusters);
		theModel.addAttribute("settings", theSettings);
		theModel.addAttribute("machine", theMachine);
		theModel.addAttribute("cluster", theCluster);

		return "command-list-dashboard";
	}

	
	//a method to display the input form for adding a new (linux command) test setting. Request cluster, machine and test type for filtering and categorizing
	@GetMapping("/form")
	public String showFormForAdd(@RequestParam("machine") int machine, @RequestParam("cluster") int cluster,
			@RequestParam("test") String test, Model theModel) {

		//Create objects to put into the model
		HealthSetting theSetting = new HealthSetting();
		Machine theMachine = new Machine();
		theMachine = machineService.getMachine(machine);
		Cluster theCluster = clusterService.getCluster(cluster);
		
		//get list of clusters for the sidenav
		List<Cluster> theClusters = clusterService.getClusters();
		
		List<Kibana> theDashboards = kibanaService.getDashboards();
		theModel.addAttribute("dashboards", theDashboards);

		//ads to the model
		theModel.addAttribute("test", test);
		theModel.addAttribute("clusters", theClusters);
		theModel.addAttribute("setting", theSetting);
		theModel.addAttribute("cluster", theCluster);
		theModel.addAttribute("machine", theMachine);

		return "command-form-all";
	}

	
	//a post request method to  save the test setting, redirects some attributes to establish machine and cluster for filtering when displaying results.
	@PostMapping("/saveSetting")
	public String saveSetting(RedirectAttributes redirectAttributes, @RequestParam("test") String test,
			// bind the setting
			@ModelAttribute("setting") HealthSetting theSetting) {

		//save the setting
		commandSettingService.saveSetting(theSetting);

		// get the clusterId and machineId from the setting
		int clusterId = theSetting.getCluster().getId();
		int machineId = theSetting.getMachine().getId();
		
		

		//redirect attributes to display results page
		redirectAttributes.addAttribute("test", test);
		redirectAttributes.addAttribute("machine", machineId);
		redirectAttributes.addAttribute("cluster", clusterId);

		return "redirect:./showResultRecent";
	}

	@GetMapping("/showFormForUpdate")
	public String showFormForUpdate(@RequestParam("settingId") int theId, @RequestParam("machine") int machine,
			@RequestParam("test") String test, @RequestParam("cluster") int cluster, Model theModel) {

		HealthSetting theSetting = commandSettingService.getSetting(theId);
		Machine theMachine = machineService.getMachine(machine);
		Cluster theCluster = clusterService.getCluster(cluster);
		List<Cluster> theClusters = clusterService.getClusters();
		
		List<Kibana> theDashboards = kibanaService.getDashboards();
		theModel.addAttribute("dashboards", theDashboards);

		theModel.addAttribute("test", test);
		theModel.addAttribute("clusters", theClusters);
		theModel.addAttribute("setting", theSetting);
		theModel.addAttribute("machine", theMachine);
		theModel.addAttribute("cluster", theCluster);

		return "command-form-all";
	}

	@GetMapping("/delete")
	public String deleteSetting(RedirectAttributes redirectAttributes, @RequestParam("machine") int machine,
			@RequestParam("cluster") int cluster, @RequestParam("settingId") int theId,
			@RequestParam("test") String test) {

		commandSettingService.deleteSetting(theId);

		redirectAttributes.addAttribute("cluster", cluster);
		redirectAttributes.addAttribute("machine", machine);
		redirectAttributes.addAttribute("test", test);
		return "redirect:./list";
	}

	
	/*
	 * a method to show the result of a test using its id
	 */
	@GetMapping("/showResult")
	public String showResult(@RequestParam("machine") int machine, @RequestParam("cluster") int cluster,
			@RequestParam("settingId") int theId, @RequestParam("test") String test, Model theModel) {

		//get clusters for sidenav
		List<Cluster> theClusters = clusterService.getClusters();
		
		//get the setting 
		HealthSetting theSetting = commandSettingService.getSetting(theId);
		
		//rerun test, get output and save result
		String theOutput = commandService.runCommand(theSetting.getCommand());
		HealthResult result = commandService.getResult(theSetting, theOutput);
		commandSettingService.saveResult(result, theId);

		Machine theMachine = machineService.getMachine(machine);
		Cluster theCluster = clusterService.getCluster(cluster);

		//get updated setting to add to model
		theSetting = commandSettingService.getSetting(theId);
		
		List<Kibana> theDashboards = kibanaService.getDashboards();
		theModel.addAttribute("dashboards", theDashboards);

		theModel.addAttribute("test", test);
		theModel.addAttribute("cluster", theCluster);
		theModel.addAttribute("clusters", theClusters);
		theModel.addAttribute("machine", theMachine);
		theModel.addAttribute("json", theOutput);
		theModel.addAttribute("setting", theSetting);

		return "command-results-boot";
	}
	
	// a get request method to get and display the result of most recently saved test setting.  This provides ability to save then immeditaely run the test and see the result.
	@GetMapping("/showResultRecent")
	public String showResultRecent(@RequestParam("machine") int machine, @RequestParam("cluster") int cluster,
			@RequestParam("test") String test, Model theModel) {
		
		//get the most recent setting id from the commandSetting service.
		int recentSettingId = commandSettingService.getRecentSetting();

		//get the actual setting using this id
		HealthSetting theSetting = commandSettingService.getSetting(recentSettingId);
		
		// get the output of running the command running command service
		String theOutput = commandService.runCommand(theSetting.getCommand());
		//get the result status using commandservice
		HealthResult result = commandService.getResult(theSetting, theOutput);
		Machine theMachine = machineService.getMachine(machine);
		Cluster theCluster = clusterService.getCluster(cluster);
		
		//save most recent result
		commandSettingService.saveResult(result, recentSettingId);

		//get the setting to put into the model with updated result
		theSetting = commandSettingService.getSetting(recentSettingId);
		
		//get the clusters for sidenav
		List<Cluster> theClusters = clusterService.getClusters();
		
		List<Kibana> theDashboards = kibanaService.getDashboards();
		theModel.addAttribute("dashboards", theDashboards);

		
		//add attributes to the model
		theModel.addAttribute("cluster", theCluster);
		theModel.addAttribute("test", test);
		theModel.addAttribute("clusters", theClusters);
		theModel.addAttribute("machine", theMachine);
		theModel.addAttribute("output", theOutput);
		theModel.addAttribute("setting", theSetting);

		return "command-results-boot";
	}

	// a get request method to show all the results for a particular cluster and machine
	@GetMapping("/showResults")
	public String showResults(@RequestParam("cluster") int cluster, @RequestParam("machine") int machine,
			@RequestParam("test") String test, Model theModel) {

	
		//create cluster object to add to model
		Cluster theCluster = new Cluster();
		theCluster = clusterService.getCluster(cluster);
		
		//create machine object to add to model
		Machine theMachine = new Machine();
		theMachine = machineService.getMachine(machine);
		
		//iterate through all the settngs, run all test and save most recent results.
		List<HealthSetting> theSettings = commandSettingService.getSettingsMachineTest(machine, test);
		
		List<Kibana> theDashboards = kibanaService.getDashboards();
		theModel.addAttribute("dashboards", theDashboards);
		
		for (HealthSetting setting : theSettings) {
			String theJson = commandService.runCommand(setting.getCommand());
			HealthResult result = commandService.getResult(setting, theJson);
			commandSettingService.saveResult(result, setting.getId());
			setting = commandSettingService.getSetting(setting.getId());
		}

		//get clusters for sidenav
		List<Cluster> theClusters = clusterService.getClusters();

		theModel.addAttribute("test", test);
		theModel.addAttribute("clusters", theClusters);
		theModel.addAttribute("settings", theSettings);
		theModel.addAttribute("cluster", theCluster);
		theModel.addAttribute("machine", theMachine);

		return "command-monitor-all";
	}
	
	
	//a get request method to get and display results of running tests on all the clusters 

	@GetMapping("/showClusters")
	public String showClusters(@Value("${settings.rest.url}") String settingUrl,
			@Value("${commandSettings.rest.url}") String commandUrl, Model theModel) {
		// add urls for the commandSEttings and apisetting for javascript to use to provide data to show the results in chart.js piecharts.
		theModel.addAttribute("settingUrl", settingUrl);
		theModel.addAttribute("commandUrl", commandUrl);

		//get clusters for sidenav
		
		List<Cluster> theClusters = clusterService.getClusters();
		theModel.addAttribute("clusters", theClusters);
		
		//add cluster for model
		Cluster cluster = new Cluster();
		theModel.addAttribute("cluster", cluster);
		
		List<Kibana> theDashboards = kibanaService.getDashboards();
		theModel.addAttribute("dashboards", theDashboards);
		
		//rerun alll the test for that there is the most update results to display on main dashboard.

		List<HealthSetting> theCommandSettings = commandSettingService.getSettings();
		for (HealthSetting setting : theCommandSettings) {
			String theJson = commandService.runCommand(setting.getCommand());
			HealthResult result = commandService.getResult(setting, theJson);
			commandSettingService.saveResult(result, setting.getId());

		}

		List<Setting> theSettings = settingsService.getSettings();

		for (Setting setting : theSettings) {
			String theJson = apiService.getJson(setting);
			Result result = apiService.getResult(setting, theJson);
			settingsService.saveResult(result, setting.getId());
		}

		return "cluster-all";
	}

	
	//a method to display all the clusters saved and to add new clusters/machines
	
	@GetMapping("/configureClusters")
	public String configureClusters(Model theModel) {
		List<Cluster> theClusters = clusterService.getClusters();

		theModel.addAttribute("clusters", theClusters);

		Cluster cluster = new Cluster();
		Machine machine = new Machine();
		
		List<Kibana> theDashboards = kibanaService.getDashboards();
		theModel.addAttribute("dashboards", theDashboards);
		
		theModel.addAttribute("machine", machine);
		theModel.addAttribute("cluster", cluster);

		return "configure-all";
	}

	
	//a post reuqest method to add new cluster
	@PostMapping("/saveCluster")
	public String saveCluster(RedirectAttributes redirectAttributes, @ModelAttribute("cluster") Cluster theCluster) {

		clusterService.saveCluster(theCluster);

		return "redirect:./configureClusters";
	}

	


	@PutMapping("/updateCluster")
	public String updateCluster(@RequestParam("clusterId") int theId, Model theModel) {

		Cluster theCluster = clusterService.getCluster(theId);

		theModel.addAttribute("cluster", theCluster);

		return "redirect:./configureClusters";
	}

	
	// a mthod to delete cluster
	@GetMapping("/deleteCluster")
	public String deleteCluster(RedirectAttributes redirectAttributes, @RequestParam("clusterId") int theId) {

		clusterService.deleteCluster(theId);

		return "redirect:./configureClusters";
	}

	
	//a method to show most recent results of all tests for all machines in a cluster
	@GetMapping("/showMachines")
	public String showMachine(@Value("${settings.rest.url}") String settingUrl,
			@Value("${commandSettings.rest.url}") String commandUrl, @RequestParam("cluster") int clusterId,
			Model theModel) {

		//get all
		List<Machine> theMachines = machineService.getMachines(clusterId);
		Machine machine = new Machine();
		Cluster theCluster = new Cluster();
		theCluster = clusterService.getCluster(clusterId);
		List<Cluster> theClusters = clusterService.getClusters();
		
		List<HealthSetting> theCommandSettings = commandSettingService.getSettings(clusterId);
		
		List<Kibana> theDashboards = kibanaService.getDashboards();
		theModel.addAttribute("dashboards", theDashboards);
		
		// rerun tests for that cluster to display recent results. for refresh
		for (HealthSetting setting : theCommandSettings) {
			String theOutput = commandService.runCommand(setting.getCommand());
			HealthResult result = commandService.getResult(setting, theOutput);
			commandSettingService.saveResult(result, setting.getId());

		}

		List<Setting> theSettings = settingsService.getSettings(clusterId);

		for (Setting setting : theSettings) {
			String theOutput = apiService.getJson(setting);
			Result result = apiService.getResult(setting, theOutput);
			settingsService.saveResult(result, setting.getId());
		}
		
		//add attributes to model
		theModel.addAttribute("settingUrl", settingUrl);
		theModel.addAttribute("commandUrl", commandUrl);
		theModel.addAttribute("machines", theMachines);
		theModel.addAttribute("clusters", theClusters);
		theModel.addAttribute("machine", machine);
		theModel.addAttribute("cluster", theCluster);
		
		
		return "machine-all";
	}

	
	//a get request method to show all the tests for a specific machine
	@GetMapping("/showMachinesTests")
	public String showMachineTests(@Value("${settings.rest.url}") String settingUrl,
			@Value("${commandSettings.rest.url}") String commandUrl, @RequestParam("machine") int machineId,
			@RequestParam("cluster") int clusterId, Model theModel) {

		
		// add api urls for javascript to retrieve the data for charts
		theModel.addAttribute("settingUrl", settingUrl);
		theModel.addAttribute("commandUrl", commandUrl);

		
		//get machine and cluster for filtering
		Machine theMachine = machineService.getMachine(machineId);
		Cluster theCluster = clusterService.getCluster(clusterId);

		//get all clusters for sidenav
		List<Cluster> theClusters = clusterService.getClusters();
		
		List<Kibana> theDashboards = kibanaService.getDashboards();
		theModel.addAttribute("dashboards", theDashboards);

		
		//run tests and get most recent results for refresh
		List<HealthSetting> theCommandSettings = commandSettingService.getSettings(machineId);
		for (HealthSetting setting : theCommandSettings) {
			String theJson = commandService.runCommand(setting.getCommand());
			HealthResult result = commandService.getResult(setting, theJson);
			commandSettingService.saveResult(result, setting.getId());

		}

		List<Setting> theSettings = settingsService.getSettings(machineId);

		for (Setting setting : theSettings) {
			String theJson = apiService.getJson(setting);
			Result result = apiService.getResult(setting, theJson);
			settingsService.saveResult(result, setting.getId());
		}

		
		//add all attributes to the model
		theModel.addAttribute("clusters", theClusters);
		theModel.addAttribute("machine", theMachine);
		theModel.addAttribute("cluster", theCluster);

		return "machine-test-all";
	}

	
	// a method to get the machines to then display for delete form
	@GetMapping("/deleteMachineForm")
	public String deleteMachineForm(@RequestParam("cluster") int cluster, Model theModel) {

		List<Machine> machines = machineService.getMachines(cluster);

		theModel.addAttribute("machines", machines);

		return "form-boot-2";
	}

	
	//method to save machine in DB
	@PostMapping("/saveMachine")
	public String saveMachine(RedirectAttributes redirectAttributes, @ModelAttribute("machine") Machine theMachine) {

		machineService.saveMachine(theMachine);
		int clusterId = theMachine.getCluster().getId();
		redirectAttributes.addAttribute("cluster", clusterId);

		return "redirect:./configureClusters";
	}

	
	//method to delete a machine
	@GetMapping("/deleteMachine")
	public String deleteMachine(RedirectAttributes redirectAttributes, @RequestParam("machineId") int theId,
			@RequestParam("clusterId") int clusterId) {

		redirectAttributes.addAttribute("cluster", clusterId);
		machineService.deleteMachine(theId);

		return "redirect:./configureClusters";
	}

	
	
	//a method to configure kibana graphs
		@GetMapping("/showConfigureKibana")
		public String showConfigureKibana(Model theModel) {
			
			Kibana theKibana = new Kibana();
			List<Cluster> theClusters = clusterService.getClusters();
			List<Kibana> theDashboards = kibanaService.getDashboards();
			theModel.addAttribute("dashboards", theDashboards);
			
			theModel.addAttribute("clusters", theClusters);
			theModel.addAttribute("kibana", theKibana);
			theModel.addAttribute("dashboards", theDashboards);
			
			

			return "configure-all-kibana";
		}

		/*
		 * a method to save the dashboard
		 */
		@PostMapping("/saveKibana")
		public String saveKibana(RedirectAttributes redirectAttributes, @ModelAttribute("kibana") Kibana theKibana) {

			kibanaService.saveDashboard(theKibana);

			return "redirect:/setting/showConfigureKibana";
		}
		
		/*
		 * a method to delete dashboard
		 */
		@GetMapping("/deleteKibana")
		public String deleteKibana(RedirectAttributes redirectAttributes, @RequestParam("kibana") int theId) {

			// delete the cluster
			kibanaService.deleteDashboard(theId);

			return "redirect:/setting/showConfigureKibana";
		}
		
		//method to diplay kibana graphs
			@GetMapping("/showKibana")
			public String showKibana(Model theModel, @RequestParam("kibana") int theKibanaId) {
				
				//get clusters for sidenav
				List<Cluster> theClusters = clusterService.getClusters();
				Kibana theKibana = kibanaService.getDashboard(theKibanaId);
				List<Kibana> theDashboards = kibanaService.getDashboards();
				theModel.addAttribute("dashboards", theDashboards);
				
				theModel.addAttribute("kibana", theKibana);
				theModel.addAttribute("clusters", theClusters);

				return "kibana-all";
		
	}
}
