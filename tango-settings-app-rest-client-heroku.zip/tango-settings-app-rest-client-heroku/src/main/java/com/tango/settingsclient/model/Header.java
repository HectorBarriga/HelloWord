package com.tango.settingsclient.model;


import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonUnwrapped;


public class Header {
	

	private int headerId;
	

	private Setting setting;

	
	private String headerValue;
	

	private String headerKey;

	public Header() {
	
	}

	public int getHeaderId() {
		return headerId;
	}

	public void setHeaderId(int headerId) {
		this.headerId = headerId;
	}

	public Setting getSetting() {
		return setting;
	}

	public void setSetting(Setting setting) {
		this.setting = setting;
	}

	public String getHeaderValue() {
		return headerValue;
	}

	public void setHeaderValue(String headerValue) {
		this.headerValue = headerValue;
	}

	public String getHeaderKey() {
		return headerKey;
	}

	public void setHeaderKey(String headerKey) {
		this.headerKey = headerKey;
	}

	@Override
	public String toString() {
		return "Header [headerId=" + headerId + ", setting=" + setting + ", headerValue=" + headerValue + ", headerKey="
				+ headerKey + "]";
	}
	
	
}
