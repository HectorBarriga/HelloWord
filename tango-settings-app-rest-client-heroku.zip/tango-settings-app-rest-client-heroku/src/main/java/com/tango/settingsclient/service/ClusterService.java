package com.tango.settingsclient.service;

import java.util.List;

import com.tango.settingsclient.model.Cluster;

public interface ClusterService {

	List<Cluster> getClusters();

	Cluster getCluster(int theId);

	void saveCluster(Cluster theCluster);

	void deleteCluster(int theId);

}
