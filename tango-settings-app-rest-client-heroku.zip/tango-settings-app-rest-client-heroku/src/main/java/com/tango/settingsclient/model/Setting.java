package com.tango.settingsclient.model;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Iterator;
import java.util.List;



import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.tango.settingsclient.model.Header;

public class Setting {

	private int id;
	
	private String testName;
	
	private String apiUrl;
	
	private List<Header> headers;
	
	private String searchWord;
	
	private boolean expected;
	
	private String info;
	
	private String curl;
	
	private BasicAuth basicAuth;
	
	private Result result;
	
	private int severity;
	
	private Date modifyDate;
	
	private Cluster cluster;
	
	private Machine machine;
	
	private String warningMessage;
	
	public Setting() {
		
	}

	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTestName() {
		return testName;
	}

	public void setTestName(String testName) {
		this.testName = testName;
	}

	public String getApiUrl() {
		return apiUrl;
	}

	public void setApiUrl(String apiUrl) {
		this.apiUrl = apiUrl;
	}

	public List<Header> getHeaders() {
		return headers;
	}

	public void setHeaders(List<Header> headers) {
		this.headers = headers;
	}

	public String getSearchWord() {
		return searchWord;
	}

	public void setSearchWord(String searchWord) {
		this.searchWord = searchWord;
	}

	public boolean isExpected() {
		return expected;
	}

	public void setExpected(boolean expected) {
		this.expected = expected;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public String getCurl() {
		return curl;
	}

	public void setCurl(String curl) {
		this.curl = curl;
	}
	

	

	public Date getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}
	
	
	
	
	

	public Result getResult() {
		return result;
	}

	public void setResult(Result result) {
		this.result = result;
	}

	public BasicAuth getBasicAuth() {
		return basicAuth;
	}

	public void setBasicAuth(BasicAuth basicAuth) {
		this.basicAuth = basicAuth;
	}
	

	public int getSeverity() {
		return severity;
	}


	public void setSeverity(int severity) {
		this.severity = severity;
	}


	public Cluster getCluster() {
		return cluster;
	}


	public void setCluster(Cluster cluster) {
		this.cluster = cluster;
	}


	public Machine getMachine() {
		return machine;
	}


	public void setMachine(Machine machine) {
		this.machine = machine;
	}


	public String getWarningMessage() {
		return warningMessage;
	}


	public void setWarningMessage(String warningMessage) {
		this.warningMessage = warningMessage;
	}


	public void generateCurl() {
		
		System.out.print(this.headers.size());

		if (this.headers.get(0).getHeaderKey() == "") {

			this.curl = "curl -X GET " + this.apiUrl;

		} else {

			StringBuilder sb = new StringBuilder();
			Iterator<Header> it = this.headers.iterator();

			while (it.hasNext()) {
				Header tempHeader = it.next();
				sb.append(tempHeader.getHeaderKey());
				sb.append(":");
				sb.append(tempHeader.getHeaderValue());

				if (it.hasNext()) {
					sb.append(" ");
				}
			}

			this.curl = "curl -X GET -H \"" + sb + "\"" + " " + this.apiUrl;
		}
	}



	@Override
	public String toString() {
		return "Setting [id=" + id + ", testName=" + testName + ", apiUrl=" + apiUrl + ", headers=" + headers
				+ ", searchWord=" + searchWord + ", expected=" + expected + ", info=" + info + ", curl=" + curl
				+ ", basicAuth=" + basicAuth + ", result=" + result + ", severity=" + severity + ", modifyDate="
				+ modifyDate + ", cluster=" + cluster + ", machine=" + machine + ", warningMessage=" + warningMessage
				+ "]";
	}

	
	
}





