package com.tango.settingsclient.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@Configuration
@EnableWebMvc
@ComponentScan("com.tango.settingsclient")
@PropertySource({ "classpath:application.properties" })
public class SettingsClientAppConfig implements WebMvcConfigurer {

	// define a bean for ViewResolver

	@Bean
	public ViewResolver viewResolver() {
		
		InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
		
		viewResolver.setPrefix("/WEB-INF/view/");
		viewResolver.setSuffix(".jsp");
		
		return viewResolver;
	}
	
	// define bean for RestTemplate ... this is used to make client REST calls
	
	@Bean
	public RestTemplate restTemplate() {
		
	//	((HttpComponentClientHttpRequestFactory)restTemplate.getRequestFactory()).setConnectTimeout(5000);
		
	/*	  HttpComponentsClientHttpRequestFactory clientHttpRequestFactory
          = new HttpComponentsClientHttpRequestFactory();
		  //Connect timeout
		  clientHttpRequestFactory.setConnectTimeout(5000);
		  RestTemplate restTemplate = new RestTemplate(clientHttpRequestFactory);*/

		  
		return new RestTemplate();
	}
	
	// add resource handler for loading css, images, etc
	
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry
          .addResourceHandler("/resources/**")
          .addResourceLocations("/resources/"); 
    }	
}









