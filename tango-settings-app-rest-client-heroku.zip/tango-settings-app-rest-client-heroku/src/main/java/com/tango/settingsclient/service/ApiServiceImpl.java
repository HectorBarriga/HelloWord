package com.tango.settingsclient.service;

import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.annotation.JsonView;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tango.settingsclient.model.Header;
import com.tango.settingsclient.model.Result;
import com.tango.settingsclient.model.Setting;

@Service
public class ApiServiceImpl implements ApiService {

	private RestTemplate restTemplate;

	private String restUrl;

	private List<Header> headers;

	private Logger logger = Logger.getLogger(getClass().getName());

	@Autowired
	public ApiServiceImpl(RestTemplate theRestTemplate) {
		restTemplate = theRestTemplate;

		logger.info("Loaded property:  rest.url=" + restUrl);
	}

	
	/*
	 * a method to call api and get output
	 */
	@Override
	public String getJson(Setting setting) {

		logger.info("In Api servic  getJson(): Calling REST API " + restUrl);

		this.restUrl = setting.getApiUrl();
		this.headers = setting.getHeaders();

		String json = null;

		// create response entity
		ResponseEntity<String> responseEntity = new ResponseEntity<String>(HttpStatus.NO_CONTENT);

		// use set Headers method to set headers and basic auth
		HttpEntity<String> entity = setHeaders(setting.getBasicAuth().getUsername(),
				setting.getBasicAuth().getPassword());
		// make REST call and put it in a try catch block in case of exceptions
		try {

			responseEntity = restTemplate.exchange(restUrl, HttpMethod.GET, entity,
					new ParameterizedTypeReference<String>() {
					});

			// catch response and store error message in result object
		} catch (final HttpClientErrorException e) {
			json = (e.getResponseBodyAsString());

		} catch (Exception e) {
			json = "404 - Error wrong URL";
		}

		// if there is not exception retrieve json response and put it into string
		// object
		if (responseEntity.getBody() != null) {

			json = responseEntity.getBody();
		}

		logger.info("in getJson(): String json");

		return json;
	}

	public HttpEntity<String> setHeaders(String username, String password) {

		logger.info("in setHeaders()");

		HttpHeaders responseHeaders = new HttpHeaders();
		for (int i = 0; i < this.headers.size(); i++) {
			if (!this.headers.get(i).getHeaderKey().isEmpty()) {
				responseHeaders.set(this.headers.get(i).getHeaderKey(), this.headers.get(i).getHeaderValue());
			}
		}

		if (username != null && password != null) {
			responseHeaders.setBasicAuth(username, password);
		}

		HttpEntity<String> entity = new HttpEntity<>(responseHeaders);
		logger.info("in setHeaders(): success");

		return entity;

	}

	/* method to search response for key searchword */
	public Result getResult(Setting setting, String Json) {

		logger.info("in getResult()");

		Result result = new Result();

		// check is searchowrd is found/not found and is it matches expected result -
		// result will be ststusOK
		
		if ((Json.contains(setting.getSearchWord()) && setting.isExpected() == true)
				|| (Json.contains(setting.getSearchWord()) == false && setting.isExpected() == false)) {
			result.setStatusOk(true);
			result.setSeverity(setting.getSeverity());
		} else {
			result.setStatusOk(false);
			result.setSeverity(setting.getSeverity());

		}

		result.setSetting(setting);

		logger.info("in getResult(): success");

		return result;

	}

}
