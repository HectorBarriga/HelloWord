package com.tango.settingsclient.service;


import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.tango.settingsclient.model.Cluster;
import com.tango.settingsclient.model.Kibana;

@Service
public class KibanaServiceImpl implements KibanaService {


		private RestTemplate restTemplate;

		private String kibanaRestUrl;

		private Logger logger = Logger.getLogger(getClass().getName());

		@Autowired
		public KibanaServiceImpl(RestTemplate theRestTemplate, @Value("${kibana.rest.url}") String theUrl) {
			restTemplate = theRestTemplate;
			kibanaRestUrl = theUrl;

			logger.info("in Kibana service : Loaded property:  kibana.rest.url=" + kibanaRestUrl);
		}

		@Override
		public List<Kibana> getDashboards() {

			logger.info("in Kibana service : getDashboards(): Calling REST API " + kibanaRestUrl);

			// make REST call
			ResponseEntity<List<Kibana>> responseEntity = restTemplate.exchange(kibanaRestUrl, HttpMethod.GET, null,
					new ParameterizedTypeReference<List<Kibana>>() {
					});

			List<Kibana> dashboards = responseEntity.getBody();

			logger.info("in Kibana service : getDashboards(): dashboards" + dashboards);

			return dashboards;
		}

		@Override
		public Kibana getDashboard(int theId) {

			logger.info("in Kibana service : getDahsboard(id): Calling REST API " + kibanaRestUrl);

			// make REST call
			Kibana theDashboard = restTemplate.getForObject(kibanaRestUrl + "/" + theId, Kibana.class);

			logger.info("in getDashboard(): theDashboard=" + theDashboard);

			return theDashboard;
		}

		@Override
		public void saveDashboard(Kibana theDashboard) {

			logger.info("in Kibana service : saveDashBoard(): Calling REST API " + kibanaRestUrl);
			
			//cut the iframe string so that we can override/change the size of frame.
			String frame = theDashboard.getDashboardFrame().substring(0, (theDashboard.getDashboardFrame().indexOf("height"))- 2);
			
			//reset the iframe
			theDashboard.setDashboardFrame(frame);

			int kibanaId = theDashboard.getId();
		

			// make REST call
			if (kibanaId == 0) {
				restTemplate.postForEntity(kibanaRestUrl, theDashboard, Cluster.class);

			} else {
				restTemplate.put(kibanaRestUrl, theDashboard);
			}

			logger.info("in Kibana service : saveDashboard(): success");
		}

		@Override
		public void deleteDashboard(int theId) {

			logger.info("in Kibana service : deleteDashboard(): Calling REST API " + kibanaRestUrl + theId);

			// make REST call
			restTemplate.delete(kibanaRestUrl + "/" + theId);

			logger.info("in Kibana service :  deleteDashboard(): deleted kibana theId=" + theId);
		}

	}

