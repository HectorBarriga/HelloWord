package com.tango.settingsclient.service;

import java.io.BufferedReader;

import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.Logger;

import org.springframework.stereotype.Service;

import com.tango.settingsclient.model.HealthCommand;
import com.tango.settingsclient.model.HealthResult;
import com.tango.settingsclient.model.HealthSetting;
import com.tango.settingsclient.model.Result;
import com.tango.settingsclient.model.Setting;

@Service
public class CommandServiceImpl implements CommandService {

	private HealthCommand command;
	private Logger logger = Logger.getLogger(getClass().getName());

	public CommandServiceImpl() {

	}

	public String runCommand(HealthCommand command) {

		logger.info("In command service runCommand()  + command");
		this.command = command;
		// String[] cmd = {"/bin/sh", "-c", command.getCommand()};
		String output = "";
		try {
			Process process = Runtime.getRuntime().exec(command.getCommand());
			output = getOutput(process);
		} catch (IOException e) {
			e.printStackTrace();
		}
		logger.info("In command service runCommand()  + command + output");
		return output;

	}

	public String getOutput(Process process) throws IOException {
		logger.info("In command service getOutput()");
		HealthResult result = new HealthResult();
		BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
		String line = "";
		String line2 = "";
		try {
			while ((line2 = reader.readLine()) != null) {

				line = line + line2 + "\n";
				result.setCommandOutput(line);

			}

			process.waitFor();
			process.destroy();

		} catch (Exception e) {
			System.out.print("IO error");
			line = e.getMessage();
			result.setCommandOutput(line);

		}
		logger.info("In command service getOutput()");
		return line;
	}

	/* method to search response for key searchword */
	public HealthResult getResult(HealthSetting setting, String output) {
		logger.info("In command service getResult() ");

		HealthResult result = new HealthResult();
		boolean outputContainsResult;

		//if there is not searchword or an or or that means it is a threshhold test
		if ((setting.getSearchWord() == null || setting.getSearchWord().isEmpty()) && (setting.isAnd() == false)
				&& (setting.isOr() == false)) {
			logger.info("In command service getResult() Min Mix threshold check ");

			//this is a threshold test so output should be numeric
			try {
				
				//if the output as int is greater than min/max and max/min is set to 0 then compare only to min || if both are set then check if valu is between the max and min then status is ok.  We are not inlcuding test for negatives as not expected in any circumstance
				if ((Integer.parseInt(output.trim()) > setting.getMin()) && (setting.getMax() == 0)
						|| (Integer.parseInt(output.trim()) < setting.getMax()) && (setting.getMin() == 0)
						|| (Integer.parseInt(output.trim()) > setting.getMin())
								&& (Integer.parseInt(output.trim()) < setting.getMax())) {
					result.setStatusOk(true);
					result.setSeverity(setting.getSeverity());
				} else {
					result.setStatusOk(false);
					result.setSeverity(setting.getSeverity());

				}

			} catch (NumberFormatException e) {
				e.getMessage();
				result.setStatusOk(false);
				result.setCommandOutput("not a number");
				result.setSeverity(setting.getSeverity());

			}

			catch (NullPointerException e) {
				e.getMessage();
				result.setStatusOk(false);
				result.setCommandOutput("no output");
				result.setSeverity(setting.getSeverity());

			}

		}

		//if not threshold test then must be a searchword test
		//check to see if first searchword id filled in and no and or or are selected.
		else if ((!setting.getSearchWord().isEmpty()) && (setting.isAnd() == false) && (setting.isOr() == false)) {
			logger.info("In command service getResult() = single searchword ");

			//check if searchword is found and is it was expected then result is ok
			if (output.contains(setting.getSearchWord()) == setting.isExpected()) {
				result.setStatusOk(true);
				result.setSeverity(setting.getSeverity());

			} else {
				result.setStatusOk(false);
				result.setSeverity(setting.getSeverity());

			}

		//if it is not a single serahc and and was selected
		} else if (setting.isAnd() == true) {
			//check if both searchword were found and put into a boolean
			outputContainsResult = (output.contains(setting.getSearchWord())
					&& output.contains(setting.getSearchWord2()));

			logger.info("In command service getResult() + AND ");

			//check if result boolean matches expected result - if it does then status is ok
			if (setting.isExpected() == outputContainsResult) {
				result.setStatusOk(true);
				result.setSeverity(setting.getSeverity());
				//if result of check and expected result don't match then it is not ok
			} else {
				result.setStatusOk(false);
				result.setSeverity(setting.getSeverity());

			}
		}
		//else if both searchwords and or was selected
		else {
			//check if either serach word was found
			outputContainsResult = (output.contains(setting.getSearchWord())
					|| output.contains(setting.getSearchWord2()));

			logger.info("In command service getResult() OR  ");
			//if result of last boolean matches expected result then status of ok
			if (setting.isExpected() == outputContainsResult) {
				result.setStatusOk(true);
				result.setSeverity(setting.getSeverity());
				
				//if it doesn't then status is not ok
			} else {
				result.setStatusOk(false);
				result.setSeverity(setting.getSeverity());

			}

		}

		result.setSetting(setting);
		logger.info("In command service getResult() ");

		return result;

	}

}
