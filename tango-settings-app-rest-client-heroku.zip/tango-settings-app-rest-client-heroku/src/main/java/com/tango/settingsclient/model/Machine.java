package com.tango.settingsclient.model;

import java.util.Set;





public class Machine {
	
	private int id;
	
	private String machineName;
	
	private Cluster cluster;
	
	private Set<Setting> settings;

	public Machine() {
		super();
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMachineName() {
		return machineName;
	}

	public void setMachineName(String machineName) {
		this.machineName = machineName;
	}

	public Cluster getCluster() {
		return cluster;
	}

	public void setCluster(Cluster cluster) {
		this.cluster = cluster;
	}

	public Set<Setting> getSettings() {
		return settings;
	}

	public void setSettings(Set<Setting> settings) {
		this.settings = settings;
	}

	@Override
	public String toString() {
		return "Machine [id=" + id + ", machineName=" + machineName + ", cluster=" + cluster + ", settings=" + settings
				+ "]";
	}
	
}
