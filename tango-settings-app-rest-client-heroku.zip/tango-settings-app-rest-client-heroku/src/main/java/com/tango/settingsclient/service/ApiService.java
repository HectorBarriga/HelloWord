package com.tango.settingsclient.service;

import java.util.List;

import org.springframework.http.HttpEntity;

import com.tango.settingsclient.model.Result;
import com.tango.settingsclient.model.Setting;




public interface ApiService {


	public String getJson(Setting theSetting);
	
	public Result getResult(Setting theSetting, String json);
	
	public HttpEntity<String> setHeaders(String username, String password);
		
}
