package com.tango.settingsclient.service;

import java.util.List;
import java.util.Map;

import com.tango.settingsclient.model.Cluster;
import com.tango.settingsclient.model.Result;
import com.tango.settingsclient.model.Setting;

public interface SettingsService {

	public List<Setting>  getSettings();

	public void saveSetting (Setting theSetting);

	public Setting getSetting (int theId);

	public void deleteSetting(int theId);

	void saveResult(Result theResult, int theId);

	List<Setting> getSettings(int cluster);

	List<Setting> getSettingsMachine(int machine);

	int getRecentSetting();
	
}
