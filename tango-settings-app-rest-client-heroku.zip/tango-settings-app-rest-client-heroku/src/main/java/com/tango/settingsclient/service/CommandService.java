package com.tango.settingsclient.service;

import java.io.IOException;

import com.tango.settingsclient.model.HealthCommand;
import com.tango.settingsclient.model.HealthResult;
import com.tango.settingsclient.model.HealthSetting;




public interface CommandService {
	
	public String runCommand(HealthCommand command);
	
	public String getOutput(Process process) throws IOException;

	public HealthResult getResult(HealthSetting theSetting, String theJson);

}
