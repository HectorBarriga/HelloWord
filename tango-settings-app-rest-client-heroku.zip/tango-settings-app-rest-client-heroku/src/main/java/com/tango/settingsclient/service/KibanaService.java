package com.tango.settingsclient.service;

import java.util.List;

import com.tango.settingsclient.model.Kibana;



public interface KibanaService {
	
	List<Kibana> getDashboards();

	Kibana getDashboard(int theId);

	void saveDashboard(Kibana theKibana);

	void deleteDashboard(int theId);

}
