package com.tango.settingsclient.model;

public class HealthCommand {
	
	private int id;
	
	private String command;
	
	private String directory;
	
	private HealthSetting setting;
	
	
	public HealthCommand() {
		
	}


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}


	public String getCommand() {
		return command;
	}


	public void setCommand(String command) {
		this.command = command;
	}


	public String getDirectory() {
		return directory;
	}


	public void setDirectory(String directory) {
		this.directory = directory;
	}


	public HealthSetting getSetting() {
		return setting;
	}


	public void setSetting(HealthSetting setting) {
		this.setting = setting;
	}


	@Override
	public String toString() {
		return "HealthCommand [id=" + id + ", command=" + command + ", directory=" + directory + ", setting=" + setting
				+ "]";
	}
	

}
