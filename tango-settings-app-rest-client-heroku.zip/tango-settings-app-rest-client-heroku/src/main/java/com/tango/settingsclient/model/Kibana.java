package com.tango.settingsclient.model;




	public class Kibana {
		
		
		private int id;

	
		private String dashboardName;
		

		private String dashboardFrame;
		
		
		public Kibana() {
			
		}


		public int getId() {
			return id;
		}


		public void setId(int id) {
			this.id = id;
		}


		public String getDashboardName() {
			return dashboardName;
		}


		public void setDashboardName(String dashboardName) {
			this.dashboardName = dashboardName;
		}


		public String getDashboardFrame() {
			return dashboardFrame;
		}


		public void setDashboardFrame(String dashboardFrame) {
			this.dashboardFrame = dashboardFrame;
		}


		@Override
		public String toString() {
			return "Kibana [id=" + id + ", dashboardName=" + dashboardName + ", dashboardFrame=" + dashboardFrame + "]";
		}
		
		

	}


