package com.tango.settingsclient.model;

import java.sql.Date;

public class Result {
	
	private int id;
	
	private String json;
	
	private boolean statusOk;
	
	private Setting setting;
	
	private Date modifyDate;
	
	private int severity;
	
	public Result() {
	
	}
	
	
	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}

	public String getJson() {
		return json;
	}

	public void setJson(String json) {
		this.json = json;
	}

	public boolean isStatusOk() {
		return statusOk;
	}

	public void setStatusOk(boolean statusOk) {
		this.statusOk = statusOk;
	}

	
	public Setting getSetting() {
		return setting;
	}


	public void setSetting(Setting setting) {
		this.setting = setting;
	}


	public Date getModifyDate() {
		return modifyDate;
	}


	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}

	

	public int getSeverity() {
		return severity;
	}


	public void setSeverity(int severity) {
		this.severity = severity;
	}


	@Override
	public String toString() {
		return "Result [id=" + id + ", json=" + json + ", statusOk=" + statusOk + ", setting=" + setting
				+ ", modifyDate=" + modifyDate + ", severity=" + severity + "]";
	}


}
