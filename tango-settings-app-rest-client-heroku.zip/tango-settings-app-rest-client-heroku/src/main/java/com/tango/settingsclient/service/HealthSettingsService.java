package com.tango.settingsclient.service;

import java.util.List;
import java.util.Map;

import com.tango.settingsclient.model.Cluster;
import com.tango.settingsclient.model.HealthResult;
import com.tango.settingsclient.model.HealthSetting;
import com.tango.settingsclient.model.Result;
import com.tango.settingsclient.model.Setting;

public interface HealthSettingsService {

	public List<HealthSetting>  getSettings();

	public void saveSetting (HealthSetting theSetting);

	public HealthSetting getSetting (int theId);

	public void deleteSetting(int theId);

	void saveResult(HealthResult theResult, int theId);

	List<HealthSetting> getSettings(int cluster);

	List<HealthSetting> getSettingsMachine(int machine);

	int getRecentSetting();

	List<HealthSetting> getSettingsMachineTest(int machine, String test);
	
}
