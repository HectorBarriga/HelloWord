#!/usr/bin/perl

#for($idx=0; $idx <= $#ARGV; $idx++) {
#  print "\"", $ARGV[$idx], "\"\n";
#}

if($#ARGV<1) {
    &showUsage();
    exit 1;
}
elsif(-d $ARGV[$#ARGV]) {
    my $dest_Dir = $ARGV[$#ARGV];
#    print "move to directory \"$dest_Dir\"\n"; # DEBUG
    for($idx_FN=0; $idx_FN<$#ARGV; $idx_FN++){
      my $src_Filename = $ARGV[$idx_FN];
      my $dest_Filename = $src_Filename;
      if($dest_Filename =~ m/(\/|\\)([^\/\\]+)\s*$/) {
        $dest_Filename = $2;
      }
      $dest_Filename = $dest_Dir . '/' . $dest_Filename;
#      print "move \"$src_Filename\" to \"$dest_Filename\"\n"; # DEBUG
      &safeMoveFileToFile($src_Filename, $dest_Filename);
    }
}
elsif($#ARGV == 1) {
  &safeMoveFileToFile($ARGV[0], $ARGV[1]);
}
else {
  &showUsage();
  exit 1;
}

sub safeMoveFileToFile {
  my $src_FN = shift;
  my $dest_FN = shift;

  open(MYFILE_SRC, "+< $src_FN") || die "Cannot open source file \"$src_FN\"\n";
  flock(MYFILE_SRC, 1);

  open(MYFILE_DEST, ">> $dest_FN") || die "Cannot open destination file \"$dest_FN\"\n";
  flock(MYFILE_DEST, 2);
  # move to end of file and set its size to 0 (=> remove the content)
  seek(MYFILE_DEST, 0, 0); truncate(MYFILE_DEST, 0);

  while(<MYFILE_SRC>) {
   print MYFILE_DEST $_;
  }
  # move to end of file and set its size to 0 (=> remove the content)
  flock(MYFILE_SRC, 2);
  seek(MYFILE_SRC, 0, 0); truncate(MYFILE_SRC, 0);

  close(MYFILE_SRC);
  close(MYFILE_DEST);
}

sub showUsage {
  print STDERR "Perl safe move content file-to-file or file-to-directory (use flock for safe move)\n";
  print STDERR "Example 1:\n";
  print STDERR "  safeMove sourceFN destinationFN\n";
  print STDERR "Example 2:\n";
  print STDERR "  safeMove sourceFN1 sourceFN2 destinationDir\n";
}
