#!/bin/bash
{
if [ ! -d /tango/logs/thc/ ];then
	mkdir /tango/logs/thc/
fi
#------------------------------------------------------------------------------
# Display settings
#------------------------------------------------------------------------------
displaySettings() {
   echo "JAVA_HOME $JAVA_HOME" ;
   echo "JAVA_OPTS     $JAVA_OPTS" ;
   echo "THCS_HOME   $THCS_HOME" ;
}

#------------------------------------------------------------------------------
#
#------------------------------------------------------------------------------
# Find path to the jvm launch command (java)
if [ -z "$JAVA_HOME" ]; then
	JAVA_HOME=/usr/java/latest
fi

# Set standard command for invoking Java.
_RUNJAVA="$JAVA_HOME"/bin/java

# Set application home directory - default to /tango/bin
[ -z "$THCS_HOME" ] && {
        THCS_HOME=/tango/bin;
        export THCS_HOME;
}

PROG=$THCS_HOME/tangohealthcheck-scanner.jar

JAVA_OPTS="-Xms512m -Xmx512m"
port=8011


[ ! -f $PROG ] && {
   echo "Cannot find application $PROG" ;
   exit 2;
} || {

   displaySettings ;

$_RUNJAVA $JAVA_OPTS -jar $PROG -httpPort $port $*

}
} 2>&1 | tee /tango/logs/thc/tangohealthcheck-scanner.log

#------------------------------------------------------------------------------
# End of file
#------------------------------------------------------------------------------
