#!/usr/bin/bash
file=/tango/logs/thc/tangohealthcheck-scanner.log;  ext=`date '+%Y%m%d_%H%M%S'`; file2=tangohealthcheck-scanner_rotated.$ext.log; /usr/bin/perl /tango/scripts/Generic/houseKeeping/logrotate_tangohealthcheck-scanner.pl $file $file2; /usr/bin/mv $file2 /tango/logs/thc/;

