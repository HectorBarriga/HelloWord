#!/bin/bash
echo " =========================== START ===========================" >> /tango/scripts/Docker/configureAndStartMysqlNode.log

### Localize my.cnf
# Get Arguments
MYSQL_HOSTNAME=$(hostname)
echo "[`date '+%Y%m%d-%H%M%S'`] MYSQL_HOSTNAME=$MYSQL_HOSTNAME " >> /tango/scripts/Docker/configureAndStartMysqlNode.log
if [ $(echo "$1" | grep MYSQL_INIT | grep "=" | wc -l) -eq 1 ];then MYSQL_INIT=$(echo "$1" | cut -d"=" -f2)
elif [ $(echo "$2" | grep MYSQL_INIT | grep "=" | wc -l) -eq 1 ];then MYSQL_INIT=$(echo "$2" | cut -d"=" -f2)
elif [ $(echo "$3" | grep MYSQL_INIT | grep "=" | wc -l) -eq 1 ];then MYSQL_INIT=$(echo "$3" | cut -d"=" -f2)
elif [ $(echo "$4" | grep MYSQL_INIT | grep "=" | wc -l) -eq 1 ];then MYSQL_INIT=$(echo "$4" | cut -d"=" -f2)
elif [ $(echo "$5" | grep MYSQL_INIT | grep "=" | wc -l) -eq 1 ];then MYSQL_INIT=$(echo "$5" | cut -d"=" -f2)
else MYSQL_INIT=standalone;fi
if [ $(echo "$1" | grep MYSQL_PASSWORD | grep "=" | wc -l) -eq 1 ];then MYSQL_PASSWORD=$(echo "$1" | cut -d"=" -f2)
elif [ $(echo "$2" | grep MYSQL_PASSWORD | grep "=" | wc -l) -eq 1 ];then MYSQL_PASSWORD=$(echo "$2" | cut -d"=" -f2)
elif [ $(echo "$3" | grep MYSQL_PASSWORD | grep "=" | wc -l) -eq 1 ];then MYSQL_PASSWORD=$(echo "$3" | cut -d"=" -f2)
elif [ $(echo "$4" | grep MYSQL_PASSWORD | grep "=" | wc -l) -eq 1 ];then MYSQL_PASSWORD=$(echo "$4" | cut -d"=" -f2)
elif [ $(echo "$5" | grep MYSQL_PASSWORD | grep "=" | wc -l) -eq 1 ];then MYSQL_PASSWORD=$(echo "$5" | cut -d"=" -f2)
else MYSQL_PASSWORD=t3il3achum;fi
if [ $(echo "$1" | grep MYSQL_WSREP_CLUSTER_ADDRESS | grep "=" | wc -l) -eq 1 ];then MYSQL_WSREP_CLUSTER_ADDRESS=$(echo "$1" | cut -d"=" -f2)
elif [ $(echo "$2" | grep MYSQL_WSREP_CLUSTER_ADDRESS | grep "=" | wc -l) -eq 1 ];then MYSQL_WSREP_CLUSTER_ADDRESS=$(echo "$2" | cut -d"=" -f2)
elif [ $(echo "$3" | grep MYSQL_WSREP_CLUSTER_ADDRESS | grep "=" | wc -l) -eq 1 ];then MYSQL_WSREP_CLUSTER_ADDRESS=$(echo "$3" | cut -d"=" -f2)
elif [ $(echo "$4" | grep MYSQL_WSREP_CLUSTER_ADDRESS | grep "=" | wc -l) -eq 1 ];then MYSQL_WSREP_CLUSTER_ADDRESS=$(echo "$4" | cut -d"=" -f2)
elif [ $(echo "$5" | grep MYSQL_WSREP_CLUSTER_ADDRESS | grep "=" | wc -l) -eq 1 ];then MYSQL_WSREP_CLUSTER_ADDRESS=$(echo "$5" | cut -d"=" -f2)
else MYSQL_WSREP_CLUSTER_ADDRESS="";fi
if [ $(echo "$1" | grep MYSQL_WSREP_NODE_ADDRESS | grep "=" | wc -l) -eq 1 ];then MYSQL_WSREP_NODE_ADDRESS=$(echo "$1" | cut -d"=" -f2)
elif [ $(echo "$2" | grep MYSQL_WSREP_NODE_ADDRESS | grep "=" | wc -l) -eq 1 ];then MYSQL_WSREP_NODE_ADDRESS=$(echo "$2" | cut -d"=" -f2)
elif [ $(echo "$3" | grep MYSQL_WSREP_NODE_ADDRESS | grep "=" | wc -l) -eq 1 ];then MYSQL_WSREP_NODE_ADDRESS=$(echo "$3" | cut -d"=" -f2)
elif [ $(echo "$4" | grep MYSQL_WSREP_NODE_ADDRESS | grep "=" | wc -l) -eq 1 ];then MYSQL_WSREP_NODE_ADDRESS=$(echo "$4" | cut -d"=" -f2)
elif [ $(echo "$5" | grep MYSQL_WSREP_NODE_ADDRESS | grep "=" | wc -l) -eq 1 ];then MYSQL_WSREP_NODE_ADDRESS=$(echo "$5" | cut -d"=" -f2)
else MYSQL_WSREP_NODE_ADDRESS=127.0.0.1;fi
if [ $(echo "$1" | grep MYSQL_SERVER_ID | grep "=" | wc -l) -eq 1 ];then MYSQL_SERVER_ID=$(echo "$1" | cut -d"=" -f2)
elif [ $(echo "$2" | grep MYSQL_SERVER_ID | grep "=" | wc -l) -eq 1 ];then MYSQL_SERVER_ID=$(echo "$2" | cut -d"=" -f2)
elif [ $(echo "$3" | grep MYSQL_SERVER_ID | grep "=" | wc -l) -eq 1 ];then MYSQL_SERVER_ID=$(echo "$3" | cut -d"=" -f2)
elif [ $(echo "$4" | grep MYSQL_SERVER_ID | grep "=" | wc -l) -eq 1 ];then MYSQL_SERVER_ID=$(echo "$4" | cut -d"=" -f2)
elif [ $(echo "$5" | grep MYSQL_SERVER_ID | grep "=" | wc -l) -eq 1 ];then MYSQL_SERVER_ID=$(echo "$5" | cut -d"=" -f2)
else MYSQL_SERVER_ID=1;fi
echo "[`date '+%Y%m%d-%H%M%S'`] MYSQL_INIT=$MYSQL_INIT MYSQL_PASSWORD=$MYSQL_PASSWORD | MYSQL_WSREP_CLUSTER_ADDRESS=$MYSQL_WSREP_CLUSTER_ADDRESS MYSQL_WSREP_NODE_ADDRESS=$MYSQL_WSREP_NODE_ADDRESS MYSQL_SERVER_ID=$MYSQL_SERVER_ID" >> /tango/scripts/Docker/configureAndStartMysqlNode.log

# Configure my.cnf template
echo "[`date '+%Y%m%d-%H%M%S'`] Update /etc/my.cnf" >> /tango/scripts/Docker/configureAndStartMysqlNode.log
sed -i "s/mysqlpassword/$MYSQL_PASSWORD/g" /etc/my.cnf
sed -i "s/serverid/$MYSQL_SERVER_ID/g" /etc/my.cnf
sed -i "s/HOSTNAME/$MYSQL_HOSTNAME/g" /etc/my.cnf
sed -i "s/wsrepclusteraddress/$MYSQL_WSREP_CLUSTER_ADDRESS/g" /etc/my.cnf
sed -i "s/wsrepnodeaddress/$MYSQL_WSREP_NODE_ADDRESS/g" /etc/my.cnf

# Update /etc/hosts
echo "[`date '+%Y%m%d-%H%M%S'`] Update /etc/hosts " >> /tango/scripts/Docker/configureAndStartMysqlNode.log
cat /tango/scripts/Docker/hosts >> /etc/hosts

callSleep()
{
# Wait 5 mins to make sure mysql is initialized
chmod 775 /usr/bin/wall
echo "[`date '+%Y%m%d-%H%M%S'`] callSleep 5 mins" >> /tango/scripts/Docker/configureAndStartMysqlNode.log
for s in {1..300}
do
        sleep 1
        if [ "$s" == 30 ] || [ "$s" == 60 ] || [ "$s" == 90 ] || [ "$s" == 120 ] || [ "$s" == 150 ] || [ "$s" == 180 ] || [ "$s" == 210 ] || [ "$s" == 240 ] || [ "$s" == 270 ] || [ "$s" == 300 ];then wall "ATTENTION! MySQL might be getting installed still. If you cannot open MySQL yet, please loggin again again or run \"/bin/bash\" in 2-5 mins";fi
done
}

echo "[`date '+%Y%m%d-%H%M%S'`] systemctl daemon-reload" >> /tango/scripts/Docker/configureAndStartMysqlNode.log
systemctl daemon-reload
echo "[`date '+%Y%m%d-%H%M%S'`] Sleep 60 secs" >> /tango/scripts/Docker/configureAndStartMysqlNode.log
sleep 60

if [ "$MYSQL_INIT" == "bootstrap" ];then
        echo "[`date '+%Y%m%d-%H%M%S'`] MYSQL_INIT = bootstrap" >> /tango/scripts/Docker/configureAndStartMysqlNode.log
        echo "[`date '+%Y%m%d-%H%M%S'`] systemctl start mysql@bootstrap.service" >> /tango/scripts/Docker/configureAndStartMysqlNode.log
        systemctl start mysql@bootstrap.service
        callSleep
        echo "[`date '+%Y%m%d-%H%M%S'`] " >> /tango/scripts/Docker/configureAndStartMysqlNode.log
        getTemporalPassword=$(grep 'temporary password' /var/log/mysqld.log | awk '{print $11}')
        echo "ALTER USER 'root'@'localhost' IDENTIFIED BY 't3il3achum';" | mysql -u root -p"$getTemporalPassword" -h localhost --connect-expired-password
        echo "GRANT ALL PRIVILEGES ON *.* TO 'root'@'127.0.0.1' IDENTIFIED BY PASSWORD '*D7545526B9D2D0DC2D079CBBC0CC56E28B375EC7' WITH GRANT OPTION;" | mysql -u root
        echo "GRANT ALL PRIVILEGES ON *.* TO 'root'@'172.17.0.%' IDENTIFIED BY PASSWORD '*D7545526B9D2D0DC2D079CBBC0CC56E28B375EC7' WITH GRANT OPTION;" | mysql -u root
        echo "GRANT ALL PRIVILEGES ON *.* TO 'root'@'$MYSQL_HOSTNAME' IDENTIFIED BY PASSWORD '*D7545526B9D2D0DC2D079CBBC0CC56E28B375EC7' WITH GRANT OPTION;" | mysql -u root
        echo "CREATE USER 'sstuser'@'localhost' IDENTIFIED BY 't3l3com';" | mysql -u root
        echo "GRANT RELOAD, LOCK TABLES, PROCESS, REPLICATION CLIENT ON *.* TO 'sstuser'@'localhost';" | mysql -u root
        echo "CREATE USER 'sstuser'@'$MYSQL_HOSTNAME' IDENTIFIED BY 't3l3com';" | mysql -u root
        echo "GRANT RELOAD, LOCK TABLES, PROCESS, REPLICATION CLIENT ON *.* TO 'sstuser'@'$MYSQL_HOSTNAME';" | mysql -u root
        echo "CREATE USER 'sstuser'@'172.17.0.%' IDENTIFIED BY 't3l3com';" | mysql -u root
        echo "GRANT RELOAD, LOCK TABLES, PROCESS, REPLICATION CLIENT ON *.* TO 'sstuser'@'172.17.0.%';" | mysql -u root
        echo "CREATE USER 'sstuser'@'$MYSQL_WSREP_NODE_ADDRESS' IDENTIFIED BY 't3l3com';" | mysql -u root
        echo "GRANT RELOAD, LOCK TABLES, PROCESS, REPLICATION CLIENT ON *.* TO 'sstuser'@'$MYSQL_WSREP_NODE_ADDRESS';" | mysql -u root
        echo "CREATE USER 'repl'@'localhost' IDENTIFIED BY 'p4ssword';" | mysql -u root
        echo "GRANT RELOAD, LOCK TABLES, PROCESS, REPLICATION CLIENT ON *.* TO 'repl'@'localhost';" | mysql -u root
        echo "CREATE USER 'repl'@'$MYSQL_HOSTNAME' IDENTIFIED BY 'p4ssword';" | mysql -u root
        echo "GRANT RELOAD, LOCK TABLES, PROCESS, REPLICATION CLIENT ON *.* TO 'repl'@'$MYSQL_HOSTNAME';" | mysql -u root
        echo "CREATE USER 'repl'@'172.17.0.%' IDENTIFIED BY 'p4ssword';" | mysql -u root
        echo "GRANT RELOAD, LOCK TABLES, PROCESS, REPLICATION CLIENT ON *.* TO 'repl'@'172.17.0.%';" | mysql -u root
        echo "CREATE USER 'repl'@'$MYSQL_WSREP_NODE_ADDRESS' IDENTIFIED BY 't3l3com';" | mysql -u root
        echo "GRANT RELOAD, LOCK TABLES, PROCESS, REPLICATION CLIENT ON *.* TO 'repl'@'$MYSQL_WSREP_NODE_ADDRESS';" | mysql -u root
        echo "FLUSH PRIVILEGES;" | mysql -u root
        sed -i "s/-pt3il3achum/-h localhost/g" /home/tango/.bashrc
elif [ "$MYSQL_INIT" == "standalone" ];then
        echo "[`date '+%Y%m%d-%H%M%S'`] MYSQL_INIT = standalone" >> /tango/scripts/Docker/configureAndStartMysqlNode.log
        echo "[`date '+%Y%m%d-%H%M%S'`] systemctl start mysql" >> /tango/scripts/Docker/configureAndStartMysqlNode.log
        systemctl start mysql
        callSleep
        echo "[`date '+%Y%m%d-%H%M%S'`] Setup MySQL GRANTs" >> /tango/scripts/Docker/configureAndStartMysqlNode.log
        getTemporalPassword=$(grep 'temporary password' /var/log/mysqld.log | awk '{print $11}')
        echo "ALTER USER 'root'@'localhost' IDENTIFIED BY '$MYSQL_PASSWORD';" | mysql -u root -p"$getTemporalPassword" -h localhost --connect-expired-password
        echo "GRANT ALL PRIVILEGES ON *.* TO 'root'@'127.0.0.1' IDENTIFIED BY '$MYSQL_PASSWORD' WITH GRANT OPTION;" | mysql -u root
        echo "GRANT ALL PRIVILEGES ON *.* TO 'root'@'172.17.0.%' IDENTIFIED BY '$MYSQL_PASSWORD' WITH GRANT OPTION;" | mysql -u root
        echo "GRANT ALL PRIVILEGES ON *.* TO 'root'@'$MYSQL_HOSTNAME' IDENTIFIED BY '$MYSQL_PASSWORD' WITH GRANT OPTION;" | mysql -u root
        echo "FLUSH PRIVILEGES;" | mysql -u root
        sed -i "s/-pt3il3achum/-h localhost/g" /home/tango/.bashrc
elif [ "$MYSQL_INIT" == "master" ];then
        echo "[`date '+%Y%m%d-%H%M%S'`] systemctl start mysql.service" >> /tango/scripts/Docker/configureAndStartMysqlNode.log
        echo "[`date '+%Y%m%d-%H%M%S'`] MYSQL_INIT=master" >> /tango/scripts/Docker/configureAndStartMysqlNode.log
        systemctl start mysql.service
        callSleep
        echo "[`date '+%Y%m%d-%H%M%S'`] Setup MySQL GRANTs" >> /tango/scripts/Docker/configureAndStartMysqlNode.log
        echo "CREATE USER 'sstuser'@'localhost' IDENTIFIED BY 't3l3com';" | mysql -u root -p"$MYSQL_PASSWORD"
        echo "GRANT RELOAD, LOCK TABLES, PROCESS, REPLICATION CLIENT ON *.* TO 'sstuser'@'localhost';" | mysql -u root -p"$MYSQL_PASSWORD"
        echo "CREATE USER 'sstuser'@'$MYSQL_HOSTNAME' IDENTIFIED BY 't3l3com';" | mysql -u root -p"$MYSQL_PASSWORD"
        echo "GRANT RELOAD, LOCK TABLES, PROCESS, REPLICATION CLIENT ON *.* TO 'sstuser'@'$MYSQL_HOSTNAME';" | mysql -u root -p"$MYSQL_PASSWORD"
        echo "CREATE USER 'sstuser'@'172.17.0.%' IDENTIFIED BY 't3l3com';" | mysql -u root -p"$MYSQL_PASSWORD"
        echo "GRANT RELOAD, LOCK TABLES, PROCESS, REPLICATION CLIENT ON *.* TO 'sstuser'@'172.17.0.%';" | mysql -u root -p"$MYSQL_PASSWORD"
        echo "CREATE USER 'sstuser'@'$MYSQL_WSREP_NODE_ADDRESS' IDENTIFIED BY 't3l3com';" | mysql -u root -p"$MYSQL_PASSWORD"
        echo "GRANT RELOAD, LOCK TABLES, PROCESS, REPLICATION CLIENT ON *.* TO 'sstuser'@'$MYSQL_WSREP_NODE_ADDRESS';" | mysql -u root -p"$MYSQL_PASSWORD"
        echo "CREATE USER 'repl'@'localhost' IDENTIFIED BY 'p4ssword';" | mysql -u root -p"$MYSQL_PASSWORD"
        echo "GRANT RELOAD, LOCK TABLES, PROCESS, REPLICATION CLIENT ON *.* TO 'repl'@'localhost';" | mysql -u root -p"$MYSQL_PASSWORD"
        echo "CREATE USER 'repl'@'$MYSQL_HOSTNAME' IDENTIFIED BY 'p4ssword';" | mysql -u root -p"$MYSQL_PASSWORD"
        echo "GRANT RELOAD, LOCK TABLES, PROCESS, REPLICATION CLIENT ON *.* TO 'repl'@'$MYSQL_HOSTNAME';" | mysql -u root -p"$MYSQL_PASSWORD"
        echo "CREATE USER 'repl'@'172.17.0.%' IDENTIFIED BY 'p4ssword';" | mysql -u root -p"$MYSQL_PASSWORD"
        echo "GRANT RELOAD, LOCK TABLES, PROCESS, REPLICATION CLIENT ON *.* TO 'repl'@'172.17.0.%';" | mysql -u root -p"$MYSQL_PASSWORD"
        echo "CREATE USER 'repl'@'$MYSQL_WSREP_NODE_ADDRESS' IDENTIFIED BY 't3l3com';" | mysql -u root -p"$MYSQL_PASSWORD"
        echo "GRANT RELOAD, LOCK TABLES, PROCESS, REPLICATION CLIENT ON *.* TO 'repl'@'$MYSQL_WSREP_NODE_ADDRESS';" | mysql -u root -p"$MYSQL_PASSWORD"

fi
echo "[`date '+%Y%m%d-%H%M%S'`] ln -s /usr/lib/systemd/system/mysql.service /etc/systemd/system/multi-user.target.wants/mysql.service" >> /tango/scripts/Docker/configureAndStartMysqlNode.log
ln -s /usr/lib/systemd/system/mysql.service /etc/systemd/system/multi-user.target.wants/mysql.service
echo "[`date '+%Y%m%d-%H%M%S'`] systemctl enable mysql.service" >> /tango/scripts/Docker/configureAndStartMysqlNode.log
systemctl enable mysql.service
echo "[`date '+%Y%m%d-%H%M%S'`] setsid /tango/scripts/Docker/configureAndStartMysqlNodeWipe.sh" >> /tango/scripts/Docker/configureAndStartMysqlNode.log
setsid /tango/scripts/Docker/configureAndStartMysqlNodeWipe.sh &
echo " =========================== END ===========================" >> /tango/scripts/Docker/configureAndStartMysqlNode.log