#!/bin/bash

### INIT
echo "[`date '+%Y%m%d-%H%M%S'`] START" > /tango/scripts/Docker/configureAndStartMysqlSlaveNode.log
### Localize my.cnf
# Get Arguments
MYSQL_HOSTNAME=$(hostname)
if [ $(echo "$1" | grep MYSQL_MASTER_ADDRESS | grep "=" | wc -l) -eq 1 ];then MYSQL_MASTER_ADDRESS=$(echo "$1" | cut -d"=" -f2)
elif [ $(echo "$2" | grep MYSQL_MASTER_ADDRESS | grep "=" | wc -l) -eq 1 ];then MYSQL_MASTER_ADDRESS=$(echo "$2" | cut -d"=" -f2)
elif [ $(echo "$3" | grep MYSQL_MASTER_ADDRESS | grep "=" | wc -l) -eq 1 ];then MYSQL_MASTER_ADDRESS=$(echo "$3" | cut -d"=" -f2)
elif [ $(echo "$4" | grep MYSQL_MASTER_ADDRESS | grep "=" | wc -l) -eq 1 ];then MYSQL_MASTER_ADDRESS=$(echo "$4" | cut -d"=" -f2)
elif [ $(echo "$5" | grep MYSQL_MASTER_ADDRESS | grep "=" | wc -l) -eq 1 ];then MYSQL_MASTER_ADDRESS=$(echo "$5" | cut -d"=" -f2)
else MYSQL_MASTER_ADDRESS=127.0.0.1;fi
if [ $(echo "$1" | grep MYSQL_PASSWORD | grep "=" | wc -l) -eq 1 ];then MYSQL_PASSWORD=$(echo "$1" | cut -d"=" -f2)
elif [ $(echo "$2" | grep MYSQL_PASSWORD | grep "=" | wc -l) -eq 1 ];then MYSQL_PASSWORD=$(echo "$2" | cut -d"=" -f2)
elif [ $(echo "$3" | grep MYSQL_PASSWORD | grep "=" | wc -l) -eq 1 ];then MYSQL_PASSWORD=$(echo "$3" | cut -d"=" -f2)
elif [ $(echo "$4" | grep MYSQL_PASSWORD | grep "=" | wc -l) -eq 1 ];then MYSQL_PASSWORD=$(echo "$4" | cut -d"=" -f2)
elif [ $(echo "$5" | grep MYSQL_PASSWORD | grep "=" | wc -l) -eq 1 ];then MYSQL_PASSWORD=$(echo "$5" | cut -d"=" -f2)
else MYSQL_PASSWORD=t3il3achum;fi
if [ $(echo "$1" | grep MYSQL_BIND_ADDRESS | grep "=" | wc -l) -eq 1 ];then MYSQL_BIND_ADDRESS=$(echo "$1" | cut -d"=" -f2)
elif [ $(echo "$2" | grep MYSQL_BIND_ADDRESS | grep "=" | wc -l) -eq 1 ];then MYSQL_BIND_ADDRESS=$(echo "$2" | cut -d"=" -f2)
elif [ $(echo "$3" | grep MYSQL_BIND_ADDRESS | grep "=" | wc -l) -eq 1 ];then MYSQL_BIND_ADDRESS=$(echo "$3" | cut -d"=" -f2)
elif [ $(echo "$4" | grep MYSQL_BIND_ADDRESS | grep "=" | wc -l) -eq 1 ];then MYSQL_BIND_ADDRESS=$(echo "$4" | cut -d"=" -f2)
elif [ $(echo "$5" | grep MYSQL_BIND_ADDRESS | grep "=" | wc -l) -eq 1 ];then MYSQL_BIND_ADDRESS=$(echo "$5" | cut -d"=" -f2)
else MYSQL_BIND_ADDRESS=127.0.0.1;fi
if [ $(echo "$1" | grep MYSQL_SERVER_ID | grep "=" | wc -l) -eq 1 ];then MYSQL_SERVER_ID=$(echo "$1" | cut -d"=" -f2)
elif [ $(echo "$2" | grep MYSQL_SERVER_ID | grep "=" | wc -l) -eq 1 ];then MYSQL_SERVER_ID=$(echo "$2" | cut -d"=" -f2)
elif [ $(echo "$3" | grep MYSQL_SERVER_ID | grep "=" | wc -l) -eq 1 ];then MYSQL_SERVER_ID=$(echo "$3" | cut -d"=" -f2)
elif [ $(echo "$4" | grep MYSQL_SERVER_ID | grep "=" | wc -l) -eq 1 ];then MYSQL_SERVER_ID=$(echo "$4" | cut -d"=" -f2)
elif [ $(echo "$5" | grep MYSQL_SERVER_ID | grep "=" | wc -l) -eq 1 ];then MYSQL_SERVER_ID=$(echo "$5" | cut -d"=" -f2)
else MYSQL_SERVER_ID=4;fi
if [ $(echo "$1" | grep MYSQL_MASTER_ROOT_PASSWORD | grep "=" | wc -l) -eq 1 ];then MYSQL_MASTER_ROOT_PASSWORD=$(echo "$1" | cut -d"=" -f2)
elif [ $(echo "$2" | grep MYSQL_MASTER_ROOT_PASSWORD | grep "=" | wc -l) -eq 1 ];then MYSQL_MASTER_ROOT_PASSWORD=$(echo "$2" | cut -d"=" -f2)
elif [ $(echo "$3" | grep MYSQL_MASTER_ROOT_PASSWORD | grep "=" | wc -l) -eq 1 ];then MYSQL_MASTER_ROOT_PASSWORD=$(echo "$3" | cut -d"=" -f2)
elif [ $(echo "$4" | grep MYSQL_MASTER_ROOT_PASSWORD | grep "=" | wc -l) -eq 1 ];then MYSQL_MASTER_ROOT_PASSWORD=$(echo "$4" | cut -d"=" -f2)
elif [ $(echo "$5" | grep MYSQL_MASTER_ROOT_PASSWORD | grep "=" | wc -l) -eq 1 ];then MYSQL_MASTER_ROOT_PASSWORD=$(echo "$5" | cut -d"=" -f2)
else MYSQL_MASTER_ROOT_PASSWORD=t3l3com;fi

# Configure my.cnf template
sed -i "s/mysqlpassword/$MYSQL_PASSWORD/g" /etc/my.cnf
sed -i "s/serverid/$MYSQL_SERVER_ID/g" /etc/my.cnf
sed -i "s/HOSTNAME/$MYSQL_HOSTNAME/g" /etc/my.cnf
sed -i "s/bindaddress/$MYSQL_BIND_ADDRESS/g" /etc/my.cnf

# Update /etc/hosts
cat /tango/scripts/Docker/hosts >> /etc/hosts

callSleep()
{
chmod 775 /usr/bin/wall
# Wait 60 to make sure mysql is initialized
for s in {1..60}
do
        sleep 1
        if [ "$s" == 20 ] || [ "$s" == 40 ] || [ "$s" == 60 ] || [ "$s" == 120 ];then wall "ATTENTION! MySQL might be getting installed still. If you cannot open MySQL yet, please loggin again again or run \"/bin/bash\" in 2 mins";fi
done
}

callSleep
systemctl daemon-reload
echo "[`date '+%Y%m%d-%H%M%S'`] systemctl stop mysql" >> /tango/scripts/Docker/configureAndStartMysqlSlaveNode.log
systemctl stop mysql
chown 777 /tango/scripts/Docker/spawn_id_rsa_pub.sh
ssh-keygen -t rsa -f /root/.ssh/id_rsa -q -N """"
getSshKey=$(cat /root/.ssh/id_rsa.pub | grep ssh-rsa)
setsid /tango/scripts/Docker/spawn_id_rsa_pub.sh $MYSQL_MASTER_ROOT_PASSWORD $MYSQL_MASTER_ADDRESS root $getSshKey &
echo "[`date '+%Y%m%d-%H%M%S'`] setsid /tango/scripts/Docker/spawn_id_rsa_pub.sh $MYSQL_MASTER_ROOT_PASSWORD $MYSQL_MASTER_ADDRESS root $getSshKey &" >> /tango/scripts/Docker/configureAndStartMysqlSlaveNode.log
sleep 10
echo "[`date '+%Y%m%d-%H%M%S'`] Sleep 10secs finished. Now get hostname on $MYSQL_MASTER_ADDRESS" >> /tango/scripts/Docker/configureAndStartMysqlSlaveNode.log
ssh $MYSQL_MASTER_ADDRESS "hostname" >> /tango/scripts/Docker/configureAndStartMysqlSlaveNode.log
cd /tango/scripts/Docker/replicationrecovery/
echo "[`date '+%Y%m%d-%H%M%S'`] ssh root@$MYSQL_MASTER_ADDRESS \"mkdir /tango/scripts/Docker/replicationrecovery/;/usr/bin/innobackupex --user=root --password=$MYSQL_PASSWORD --slave-info /tango/scripts/Docker/replicationrecovery/\"" >> /tango/scripts/Docker/configureAndStartMysqlSlaveNode.log
ssh root@$MYSQL_MASTER_ADDRESS "mkdir /tango/scripts/Docker/replicationrecovery/;/usr/bin/innobackupex --user=root --password=$MYSQL_PASSWORD --slave-info /tango/scripts/Docker/replicationrecovery/"
TIMESTAMP=$(ssh root@$MYSQL_MASTER_ADDRESS "ls /tango/scripts/Docker/replicationrecovery/")
echo "[`date '+%Y%m%d-%H%M%S'`] ssh root@$MYSQL_MASTER_ADDRESS \"/usr/bin/innobackupex --apply-log --use-memory=2G /tango/scripts/Docker/replicationrecovery/$TIMESTAMP/\"" >> /tango/scripts/Docker/configureAndStartMysqlSlaveNode.log
ssh root@$MYSQL_MASTER_ADDRESS "/usr/bin/innobackupex --apply-log --use-memory=2G /tango/scripts/Docker/replicationrecovery/$TIMESTAMP/"
echo "[`date '+%Y%m%d-%H%M%S'`] ssh root@$MYSQL_MASTER_ADDRESS 'ssh-keygen -t rsa -f /root/.ssh/id_rsa -q -N \"\"\"\"'" >> /tango/scripts/Docker/configureAndStartMysqlSlaveNode.log
ssh root@$MYSQL_MASTER_ADDRESS 'ssh-keygen -t rsa -f /root/.ssh/id_rsa -q -N """"'
getMasterSshKey=$(ssh root@$MYSQL_MASTER_ADDRESS "cat /root/.ssh/id_rsa.pub | grep ssh-rsa")
echo "[`date '+%Y%m%d-%H%M%S'`] Master id_rsa.pub = $getMasterSshKey" >> /tango/scripts/Docker/configureAndStartMysqlSlaveNode.log
echo $getMasterSshKey >> /root/.ssh/authorized_keys
chmod 644 /root/.ssh/authorized_keys
mv /tango/data/mysql /tango/logs/COSTAFF/trash/
echo "[`date '+%Y%m%d-%H%M%S'`] ssh root@$MYSQL_MASTER_ADDRESS \"rsync -avprP -e 'ssh -o StrictHostKeyChecking=no'  /tango/scripts/Docker/replicationrecovery/$TIMESTAMP/ TESTBEDDOCKERDB4:/tango/data/mysql\"" >> /tango/scripts/Docker/configureAndStartMysqlSlaveNode.log
ssh root@$MYSQL_MASTER_ADDRESS "rsync -avprP -e 'ssh -o StrictHostKeyChecking=no' /tango/scripts/Docker/replicationrecovery/$TIMESTAMP/ $MYSQL_HOSTNAME:/tango/data/mysql"
callSleep
echo "[`date '+%Y%m%d-%H%M%S'`] Sleep 120secs finished. Now systemctl start mysql" >> /tango/scripts/Docker/configureAndStartMysqlSlaveNode.log
chmod 777 /tango/data/mysql
chown -R mysql:mysql /tango/data/mysql
systemctl start mysql.service
callSleep
echo "[`date '+%Y%m%d-%H%M%S'`] Sleep 10secs finished." >> /tango/scripts/Docker/configureAndStartMysqlSlaveNode.log
echo "[`date '+%Y%m%d-%H%M%S'`] ssh root@$MYSQL_MASTER_ADDRESS \"echo \\\"GRANT REPLICATION SLAVE, REPLICATION CLIENT ON *.* TO repl@'172.17.0.%' IDENTIFIED BY 'p4ssword';\\\" | mysql -u root\"" >> /tango/scripts/Docker/configureAndStartMysqlSlaveNode.log
ssh root@$MYSQL_MASTER_ADDRESS "echo \"GRANT REPLICATION SLAVE, REPLICATION CLIENT ON *.* TO repl@'172.17.0.%' IDENTIFIED BY 'p4ssword';\" | mysql -u root"
getGTID=$(cat /tango/data/mysql/xtrabackup_info | grep binlog_pos | cut -d"'" -f6)
echo "[`date '+%Y%m%d-%H%M%S'`] echo \"RESET MASTER; STOP SLAVE;CHANGE MASTER TO MASTER_HOST='$MYSQL_MASTER_ADDRESS', MASTER_USER='repl', MASTER_PASSWORD='p4ssword', MASTER_AUTO_POSITION = 1;SET @@global.gtid_purged='$getGTID';Start Slave;\" | mysql -u root" >> /tango/scripts/Docker/configureAndStartMysqlSlaveNode.log
echo "RESET MASTER; STOP SLAVE;CHANGE MASTER TO MASTER_HOST='$MYSQL_MASTER_ADDRESS', MASTER_USER='repl', MASTER_PASSWORD='p4ssword', MASTER_AUTO_POSITION = 1;SET @@global.gtid_purged='$getGTID';Start Slave;" | mysql -u root
echo "setsid /tango/scripts/Docker/configureAndStartMysqlSlaveNodeWipe.sh $1 &" >> /tango/scripts/Docker/configureAndStartMysqlSlaveNode.log
setsid /tango/scripts/Docker/configureAndStartMysqlSlaveNodeWipe.sh &