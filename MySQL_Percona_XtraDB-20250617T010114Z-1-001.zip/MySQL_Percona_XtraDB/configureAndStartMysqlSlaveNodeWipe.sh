#!/bin/bash
sleep 1500
echo "true" > /tango/scripts/Docker/configureAndStartMysqlSlaveNode.sh
