#!/bin/bash

# Sta
setsid /tango/scripts/Docker/configureAndStartMysqlNode.sh $1 &

# Start systemd
#exec /usr/sbin/init
/usr/lib/systemd/systemd --system

# Dont add more code below as the ywill not be run due to the previous exec
