#!/usr/bin/expect -f
set pass [lrange $argv 0 0]
set server [lrange $argv 1 1]
set name [lrange $argv 2 2]
set sshkey1 [lrange $argv 3 3]
set sshkey2 [lrange $argv 4 4]
set sshkey3 [lrange $argv 5 5]

spawn ssh -o StrictHostKeyChecking=no $name@$server
match_max 100000
expect "*?assword:*"
send -- "$pass\r"
send -- "\r"
expect "root@"
send -- "mkdir /root/.ssh/;chmod 700 /root/.ssh/;echo $sshkey1 $sshkey2 $sshkey3 >> /root/.ssh/authorized_keys;chmod 644 /root/.ssh/authorized_keys\r"
expect "root@"
send -- "exit\r"
interact
