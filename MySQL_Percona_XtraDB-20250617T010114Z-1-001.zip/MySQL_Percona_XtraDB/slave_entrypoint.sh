#!/bin/bash

# Sta
setsid /tango/scripts/Docker/configureAndStartMysqlSlaveNode.sh $1 &

# Start systemd
exec /usr/sbin/init

# Dont add more code below as the ywill not be run due to the previous exec
