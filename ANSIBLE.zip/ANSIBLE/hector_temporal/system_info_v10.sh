#!/bin/ksh
# COPYRIGHT 2017 CSG SYSTEMS INTERNATIONAL, INC. AND/OR ITS AFFILIATES (CSG). ALL RIGHTS RESERVED.
# THIS SOFTWARE AND RELATED INFORMATION IS CONFIDENTIAL AND PROPRIETARY TO CSG AND MAY NOT
# BE DISCLOSED, COPIED, MODIFIED, OR OTHERWISE USED EXCEPT IN ACCORDANCE WITH THE LICENSE
# AGREEMENT ENTERED INTO WITH CSG. THIS INFORMATION IS PROTECTED BY INTERNATIONAL COPYRIGHT
# LAWS AND ANY UNAUTHORIZED USE THEREOF MAY VIOLATE COPYRIGHT, TRADEMARK, AND OTHER LAWS.
# ANY UNAUTHORIZED USE OF THIS SOFTWARE AND/OR INFORMATION WILL AUTOMATICALLY TERMINATE
# YOUR RIGHT TO USE THIS SOFTWARE AND/OR INFORMATION.
#
# SOFTWARE AND DOCUMENTATION IS PROVIDED AND ACCEPTED BY LICENSEE “AS IS” WITHOUT ANY WARRANTY
# WHATSOEVER.  ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTIES OF TITLE,
# MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR PURPOSE, ARE SPECIFICALLY EXCLUDED AND
# DISCLAIMED. CSG DOES NOT WARRANT THAT THE SOFTWARE AND DOCUMENTATION WILL MEET LICENCEE’S
# REQUIREMENTS OR THAT THE OPERATION OF THE SOFTWARE WILL BE UNINTERRUPTED OR ERROR FREE.
# AS BETWEEN CSG AND LICENSEE, THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE
# SOFTWARE IS WITH LICENSEE. IN ADDITION ALL WARRANTIES OF NON-INFRINGEMENT OF THIRD PARTY
# RIGHTS ARE EXPRESSLY EXCLUDED.
#
#======================================================================
#
#    CSG International (CSG) internal use only 
#                            - not for use by other parties 
#                              unless specifically requested by CSG
#
#----------------------------------------------------------------------
#
#    Filename    : system_info_v10.sh
#
#
#    Description : Script used to document server configuration 
#
#@(#)Version     : 4.3 ( 15-Jul-2013 )
#
#    Notes       : Can take parameter for 3rd party software
#                  search. 
#                            n             = no search
#                            o             = oracle search
#                            j             = java search
#                            no parameter  = full search
#
#    Dependencies: awk, sort, uniq,...
#----------------------------------------------------------------------
#

#----------------------------------------------------------------------
# Functions
#----------------------------------------------------------------------

f_initialise()
{
  DATE=`date +%Y-%m-%d`
  thisuser=$(id | cut -f1 -d " " | cut -f2 -d "(" | cut -f1 -d ")")
  thisgroup=$(id | cut -f2 -d " " | cut -f2 -d "(" | cut -f1 -d ")")

  typeset -l host_name
  host_name=$(hostname)

  info_filename="./system_info_${host_name}.txt"
  if [ "use_tmp" = "yes" ]; then
      info_filename="/tmp/${info_filename}"
  fi
  temp_filename_1=./temporary_file_1.txt
  temp_filename_2=./temporary_file_2.txt
  temp_filename_3=./temporary_file_3.txt
  temp_filename_4=./temporary_file_4.txt
  touch ${info_filename}
  touch ${temp_filename_1}
  touch ${temp_filename_2}
  touch ${temp_filename_3}
  touch ${temp_filename_4}
  if [[ ! -f ${info_filename} ]]
  then
    print "Cannot write to ${info_filename} - aborting"
    exit 1
  fi
  if [[ ! -f ${temp_filename_1} ]] 
  then
    print "Cannot write to ${temp_filename_1} - aborting"
    exit 1
  fi
  if [[ ! -f ${temp_filename_2} ]]
  then
    print "Cannot write to ${temp_filename_2} - aborting"
    exit 1
  fi
  if [[ ! -f ${temp_filename_3} ]]
  then
    print "Cannot write to ${temp_filename_3} - aborting"
    exit 1
  fi
  if [[ ! -f ${temp_filename_4} ]]
  then
    print "Cannot write to ${temp_filename_4} - aborting"
    exit 1
  fi

  server_name=$(hostname)
  print "\nInformation from ${server_name} on ${DATE}\n" > ${info_filename}
  print "\nReport run by ${thisuser}:${thisgroup} (${SHELL})\n" >> ${info_filename}
} 

f_get_hostid() 
{
  # For Sun only
  # Output the host id, if possible
  echo HOSTID
  if [ -x /usr/bin/hostid ]; then
    /usr/bin/hostid 2>/dev/null
  elif [ -x /usr/ucb/hostid ]; then
    /usr/ucb/hostid 2>/dev/null
  fi
}

f_get_prominfo() 
{
  # For Sun only
  # Output the output of prtconf/devinfo -pv, if possible
  echo PROMINFO
  if [ "yes" = "$PROMINFO" ]; then
    if [ -x /usr/sbin/prtconf ]; then
      /usr/sbin/prtconf -pv 2>/dev/null
    elif [ -x /usr/etc/devinfo ]; then
      /usr/etc/devinfo -pv 2>/dev/null
    fi
  fi
}

f_hardware()
{
  print "\nHARDWARE Information" >> ${info_filename}
  print "======== ===========" >> ${info_filename}

  case ${op_sys} in
AIX)
    if [ -x /usr/sbin/prtconf ]
    then
      print "Running prtconf..."
      /usr/sbin/prtconf > ${temp_filename_4}
      mc_type=$(cat ${temp_filename_4} | grep 'System Model' | cut -d ':' -f2)
      mc_proc=$(cat ${temp_filename_4} | grep 'Processor Type' | cut -d ':' -f2)
      mc_num_proc=$(cat ${temp_filename_4} | grep 'Number Of Processors' | cut -d ':' -f2)
      mc_proc_spd=$(cat ${temp_filename_4} | grep 'Processor Clock Speed' | cut -d ':' -f2)
      mc_Word_size=$(cat ${temp_filename_4} | grep 'Kernel Type' | cut -d ':' -f2)
      mc_ram=$(cat ${temp_filename_4} | grep 'Memory Size' | grep -v 'Good' | cut -d ':' -f2)
      mc_swap=$(cat ${temp_filename_4} | grep 'Total Paging Space' | cut -d ':' -f2)

      print "\n\tModel\t\t${mc_type}" >> ${info_filename}
      print "\tProcessor\t${mc_proc}" >> ${info_filename}
      print "\tCores\t\t${mc_num_proc}" >> ${info_filename}
      print "\tSpeed\t\t${mc_proc_spd}" >> ${info_filename}
      print "\tWord Size\t${mc_Word_size}" >> ${info_filename}
      print "\tMemory\t\t${mc_ram}" >> ${info_filename}
      print "\tSwap space\t${mc_swap}" >> ${info_filename}
      unset mc_type mc_proc mc_num_proc mc_proc_spd mc_word_size mc_ram mc_swap
    else
      print "/usr/sbin/prtconf not found"
    fi
    ;;
  HP-UX)

    print "Running model..."
    hw_info=$(model)
    if [ `model | grep '/' | wc -l` -gt 0 ]
    then
      mc_type=$(model | cut -d '/' -f3)
    else
      mc_type=$(model | cut -d ' ' -f4)
    fi

    hw_info=$(echo "HP ${hw_info}")

# 
# Some output from model is incorrect
#

    case ${mc_type} in
    A400-44)
      mc_name=rp2400
      ;;
    A400-6X)
      mc_name=rp2430
      ;;
    A500-44)
      mc_name=rp2450
      ;;
    A500-5X)
      mc_name=rp2470
      ;;
    A500-6X)
      mc_name=rp2470
      ;;
    A500-7X)
      mc_name=rp2450
      ;;
    L1000-36)
      mc_name=rp5400
      ;;
    L1000-44)
      mc_name=rp5400
      ;;
    L1000-5X)
      mc_name=rp5400
      ;;
    L1500-5X)
      mc_name=rp5430
      ;;
    L1500-6X)
      mc_name=rp5430
      ;;
    L1500-7X)
      mc_name=rp5430
      ;;
    L1500-8X)
      mc_name=rp5430
      ;;
    L2000-36)
      mc_name=rp5450
      ;;
    L2000-44)
      mc_name=rp5450
      ;;
    L2000-5X)
      mc_name=rp5450
      ;;
    L3000-5X)
      mc_name=rp5470
      ;;
    L3000-6X)
      mc_name="rp5405/5470"
      ;;
    L3000-7X)
      mc_name=rp5470
      ;;
    L3000-8X)
      mc_name=rp5470
      ;;
    N4000-65)
      mc_name=rp7400
      ;;
    N4000-75)
      mc_name=rp7400
      ;;
    rp7410)
      mc_name="rp7405/rp7410"
      ;;
    S16K-A)
      mc_name=rp8400
      ;;
    *)
      mc_name=""
      ;;
    esac
    print "\n\tModel:\\t\t\t${hw_info} ${mc_name}" >> ${info_filename}
    unset mc_name

    if [[ -x /usr/sbin/ioscan ]]
    then
      print "Running ioscan on processor..."
      typeset i_count=$(/usr/sbin/ioscan -fnkC processor |wc -l)
      let i_count=i_count-2
      print "\n\tNumber of processors:\t${i_count}" >> ${info_filename}
      unset i_count
    else
      print "/usr/sbin/ioscan not found"
    fi

    if [[ -x /usr/sbin/cstm ]]
    then
      print "Running cstm on CPU - please wait..."
      hw_info=$(echo "selclass qualifier cpu;infolog" | /usr/sbin/cstm | grep "CPU Module" | uniq)
      hw_info=$(echo $hw_info | sed -e 's/Module/Revision/')
      if [[ "${hw_info}" = "" ]]
      then
        if [ `uname -m | grep ia64 | wc -l` -eq 0 ]
        then
          grep CPU /var/tombstones/ts99 | grep PA | uniq > ${temp_filename_4}
        fi
        os_ver=$(uname -r | cut -d '.' -f3)
      	case ${os_ver} in
      	00)
          cat ${temp_filename_4} | while read line
          do
            cpu_type=$(echo ${line} | cut -d ' ' -f2,3)
          done
          ;;
        11)
          cat ${temp_filename_4} | while read line
          do
            cpu_type=$(echo ${line} | cut -d ' ' -f2)
          done
          ;;
        23)
          if [ -x /usr/contrib/bin/machinfo ]
          then
            cpu_type=$(/usr/contrib/bin/machinfo | grep 'processor model:')
            cpu_type_maj=$(echo ${cpu_type} | cut -d ' ' -f5,6,7)
            cpu_type_num=$(echo ${cpu_type} | cut -d ' ' -f3)
            cpu_speed=$(/usr/contrib/bin/machinfo | grep 'Clock speed')
            cpu_mhz=$(echo ${cpu_speed} | cut -d ' ' -f4)
            cpu_type="${cpu_type_maj} (${cpu_type_num}) ${cpu_mhz} MHz"
            unset cpu_type_maj cpu_type_num cpu_speed cpu_mhz
          else
            print "cannot run /usr/contrib/bin/machinfo"
            cpu_type="unknown"
          fi
          ;;
        31)
          if [ -x /usr/contrib/bin/machinfo ]
          then
            cpu_type=""
            temp_str=""
            /usr/contrib/bin/machinfo > ${temp_filename_4}
            cat ${temp_filename_4} | while read line
            do
              str_7=$(echo ${line} | cut -c1-7)
              if [ "${str_7}" = "Memory:" ]
              then
                next_one="N"
              fi
              if [ "${next_one}" = "Y" ]
              then
                if [ "${cpu_type}x" = "x" ]
                then
                  cpu_type="${line}"
                else
                  temp_str=${cpu_type}
                  cpu_type="${temp_str}, ${line}"
                fi
              fi
              str_9=$(echo ${line} | cut -c1-9)
              if [ "${str_9}" = "CPU info:" ]
              then
                next_one="Y"
              fi
            done
            unset temp_str
          else
            print "cannot run /usr/contrib/bin/machinfo"
            cpu_type="unknown"
          fi
          ;;
        esac
        hw_info=${cpu_type}
        unset cpu_type
      fi
      print "\n\tType of processor:\t${hw_info}" >> ${info_filename}
      print "Running cstm on memory - please wait..."
      hw_info=$(echo 'selall;info;wait;infolog;view;done' | /usr/sbin/cstm |grep 'Total Configured Memory' | cut -d ':' -f2)
      print "\n\tMemory:\t\t\t${hw_info}" >> ${info_filename}
    else
      print "/usr/sbin/cstm not found"
    fi
    if [[ -x /usr/sbin/swapinfo ]]
    then
      swapsize=$(/usr/sbin/swapinfo -tam | grep total | grep -v /)
      swapmb=$(echo $swapsize | cut -d ' ' -f2)
      swapmbtxt=$(echo "${swapmb} MB") 
      unset swapsize swapmb
    else
      print "/usr/sbin/swapinfo cannot be executed by this user"
      swapmbtxt="cannot obtain swap information"
    fi

    case ${os_ver} in
    00)
      if [ -x /usr/sbin/kmtune ]
      then
        maxsctxt=$(/usr/sbin/kmtune -q maxswapchunks | grep maxswapchunks)
        typeset -i maxscnum=$(echo ${maxsctxt} | cut -d ' ' -f2)
        sctxt=$(/usr/sbin/kmtune -q swchunk | grep swchunk)
        typeset -i scnum=$(echo ${sctxt} | cut -d ' ' -f2)
        typeset -i maxswapmb=${maxscnum}*${scnum}/1024
        maxswaptxt=$(echo "maximum swap space is configured to ${maxswapmb} MB")
        unset sctxt maxsctxt
        unset maxswapmb maxscnum scnum
      else
        print "/usr/sbin/kmtune cannot be executed by this user"
        maxswaptxt="cannot obtain kernel information"
      fi
      ;;
    11)
      if [ -x /usr/sbin/kmtune ]
      then
        maxsctxt=$(/usr/sbin/kmtune -q maxswapchunks | grep maxswapchunks)
        typeset -i maxscnum=$(echo ${maxsctxt} | cut -d ' ' -f2)
        sctxt=$(/usr/sbin/kmtune -q swchunk | grep swchunk)
        typeset -i scnum=$(echo ${sctxt} | cut -d ' ' -f2)
        typeset -i maxswapmb=${maxscnum}*${scnum}/1024
        maxswaptxt=$(echo "maximum swap space is configured to ${maxswapmb} MB")
        unset sctxt maxsctxt
        unset maxswapmb maxscnum scnum
      else
        print "/usr/sbin/kmtune cannot be executed by this user"
        maxswaptxt="cannot obtain kernel information"
      fi
      ;;
    23)
      if [ -x /usr/sbin/kctune ]
      then
        sctxt=$(/usr/sbin/kctune -q swchunk | grep swchunk)
        typeset -i scnum=$(echo ${sctxt} | cut -d ' ' -f2)
        swapmbtxt=""
        maxswaptxt="Not known (swchunk = ${scnum})"
      fi
      ;;
    31)
      if [ -x /usr/sbin/swapinfo ]
      then
        sctxt=$(/usr/sbin/swapinfo -tam | grep total )
        typeset -i scnum=$(echo ${sctxt} | cut -d ' ' -f2)
        swapmbtxt="${scnum} MB"
        maxswaptxt=""
      else
        swapmbtxt=""
        maxswaptxt="Not known (swchunk = ${scnum})"
      fi
      ;;
    esac

    print "\n\tSwap space:\t\t${swapmbtxt}" >> ${info_filename}
    print "\t\t\t\t${maxswaptxt}" >> ${info_filename}
    unset swapmbtxt maxswaptxt 

    if [ -x /usr/sbin/parstatus ]
    then
      echo "Running /usr/sbin/parstatus..."
      typeset -i partition_status
      partition_status=$( /usr/sbin/parstatus 2>/dev/null | grep NOT_SUPPORTED | wc -l )
      if [ ${partition_status} -eq 0 ]
      then
        print "\n\tPartition Data\n" >> ${info_filename}
        /usr/sbin/parstatus 2>/dev/null >> ${info_filename}
      fi
      unset partition_status
    fi
    ;;
  Linux)

    model_str=$(lshal | grep system\.hardware | grep system.hardware.product)
    model_detail=$(echo ${model_str} | cut -d '=' -f2 | cut -d '(' -f1 )
    print  "\n\tModel:\\t\t\t\t${model_detail}" >> ${info_filename}
    unset model_str model_detail

    num_proc=$(grep processor /proc/cpuinfo | wc -l)
    print  "\n\tNumber of processor-threads:\\t\t${num_proc}" >> ${info_filename}
    unset num_proc

    core_str=$(grep 'model name' /proc/cpuinfo | sort | uniq)
    core_info=$(echo ${core_str} | cut -d ':' -f2)
    print  "\n\tType of core:\t\t\t${core_info}" >> ${info_filename}
    unset core_str core_info

    typeset -i mem_kb
    typeset -i mem_mb
    mem_kb_str=$(grep MemTotal /proc/meminfo) 
    mem_kb=$(echo ${mem_kb_str} | cut -d ' ' -f2)
    (( mem_mb = mem_kb / 1024 ))
    print  "\n\tMemory:\\t\t\t\t${mem_mb} MB" >> ${info_filename}

    mem_kb_str=$(grep SwapTotal /proc/meminfo) 
    mem_kb=$(echo ${mem_kb_str} | cut -d ' ' -f2)
    (( mem_mb = mem_kb / 1024 ))
    print  "\n\tSwap space:\\t\t\t${mem_mb} MB" >> ${info_filename}

    unset mem_kb mem_mb mem_kb_str

    ;;
  SunOS)

    cpu_type=""
    cpu_speed=""
    inst_cnt=""
    memory=""
    memsize=""
    memstrsize=""
    model_str=""
    sun_hostid=""
    zone_value=""

    typeset -i line_count=0
    typeset -i line_target=0
    typeset -i inst_cnt=0
    typeset -i memmb

    model_str=$(uname -i | cut -d ',' -f2)
    if [[ -x /usr/bin/kstat ]]
    then
      cpu_type=$(/usr/bin/kstat -m cpu_info | grep brand | sort | uniq | cut -c34-50)
      cpu_speed=$(/usr/bin/kstat -m cpu_info | grep clock_MHz | sort | uniq | cut -c34-50)
    else
      print "/usr/bin/kstat cannot be executed by this user"
    fi
    if [[ -x /usr/sbin/psrinfo ]]
    then
      core_num=$(/usr/sbin/psrinfo | wc -l)
      num_str=$(echo ${core_num})
    else
      print "/usr/sbin/psrinfo cannot be executed by this user"
    fi
    if [[ -x /usr/sbin/prtconf ]]
    then
      memory=$(/usr/sbin/prtconf 2> /dev/null | grep Memory | cut -d ' ' -f3)
    else
      print "/usr/sbin/prtconf cannot be executed by this user"
    fi
    if [[ -x /usr/bin/zonename ]]
    then
      zone_name=$(/usr/bin/zonename)
    else
      print "/usr/bin/zonename cannot be executed by this user"
    fi

    if [[ -x /usr/sbin/swap ]]
    then
      memsize=$(/usr/sbin/swap -s | cut -d ' ' -f11)
      memstrsize=${#memsize}
      (( memstrsize=${memstrsize}-1 ))
      memmb=$(echo ${memsize} | cut -c 1-${memstrsize})
      (( memmb=${memmb}/1024 ))
    else
      print "/usr/sbin/swap cannot be executed by this user"
    fi
    if [[ -x /usr/sbin/sysdef ]]
    then
      /usr/sbin/sysdef > ${temp_filename_1}
    else
      print "/usr/sbin/sysdef cannot be executed by this user"
    fi

    cat ${temp_filename_1} | while read line
    do
      ((line_count = line_count + 1 ))
      inst_cnt=$(echo ${line} | grep 'Hostid' | wc -l)
      if [[ ${inst_cnt} -eq 1 ]]
      then
        (( line_target = line_count + 2 ))
      fi
      if [[ ${line_count} -eq ${line_target} ]]
      then
        host_id=$(echo ${line})
      fi
    done

    if [[ "${zone_name}" != "" ]]
    then
      zone_value=" (zoned)"
    fi


    print  "\n\tModel:\\t\t\t\t${model_str}${zone_value}" >> ${info_filename}
    print  "\n\tNumber of processors:\\t\t${num_str}" >> ${info_filename}
    print  "\n\tCPU:\\t\t\t\t${cpu_type} (${cpu_speed} MHz)" >> ${info_filename}
    print  "\n\tMemory:\\t\t\t\t${memory} MB" >> ${info_filename}
    print  "\n\tSwap space:\\t\t\t${memmb} MB" >> ${info_filename}
 
    unset model_str zone_value
    unset num_str core_num
    unset cpu_type cpu_speed
    unset memmb memsize memstrsize

    ;;
  esac
}

f_operating_system()
{
  print "\n\nOPERATING SYSTEM Information" >> ${info_filename}
  print "========= ====== ===========" >> ${info_filename}

  case ${op_sys} in
  AIX)
    print "Running oslevel..."
    op_ver=$(oslevel)
    op_sp=$(oslevel -r | cut -d '-' -f2)
    print "\n\tOperating System:\t${op_sys} ${op_ver}-${op_sp}" >> ${info_filename}
    oslevel -q -s | sort > ${temp_filename_4}
    last_sp=$(tail -n 1 ${temp_filename_4})
    print "\n\tLast service pack:\t${last_sp}" >> ${info_filename}
    unset last_sp op_sp op_ver
    ;;
  HP-UX)
    print "Running uname..."
    opsys_info=$(uname -s)
    print "\n\tOperating System:\t${opsys_info}" >> ${info_filename}
    opsys_info=$(uname -r)
    print "\n\tRelease:\t\t${opsys_info}" >> ${info_filename}
    opsys_info=$(uname -v)
    print "\n\tVersion:\t\t${opsys_info}" >> ${info_filename}
    opsys_info=$(getconf KERNEL_BITS)
    print "\n\tWord size:\t\t${opsys_info} bits" >> ${info_filename}
    unset opsys_info

    if [[ -x /usr/sbin/swlist ]]
    then
      print "Running swlist to check patch bundle - please wait..."
      sw_info=$(/usr/sbin/swlist | grep -e QPK -e GOLD)
      sw_date=$(echo ${sw_info} | cut -d ',' -f2)
      sw_info=$(echo ${sw_info} | cut -d ' ' -f1)
      print "\n\tLatest patch bundle:\t${sw_date} ${sw_info}\n" >> ${info_filename}
      unset sw_info sw_date
    else
      print "/usr/sbin/swlist not found"
    fi

    if [[ -x /usr/contrib/bin/show_patches ]]
    then
      print "Running show_patches - please wait..."
      print "\nOutput from show_patches:\n" >> ${info_filename}
      /usr/contrib/bin/show_patches >> ${info_filename}
    else
      print "/usr/contrib/bin/show_patches not found"
    fi
  ;;
  Linux)
    opsys_info=$(uname -s)
    print "\n\tOperating System:\t\t${opsys_info}" >> ${info_filename}
    opsys_info=$(uname -r)
    print "\n\tKernel build:\t\t\t${opsys_info}" >> ${info_filename}
    typeset -i ver_rel
    typeset -i ver_pref
    typeset -i ver_ver
    typeset -i ver_last
    ver_rel=$(echo ${#opsys_info})
    (( ver_pref = ver_rel + 14 + 2 ))
    ver_str=$(cat /proc/version)
    ver_ver=${#ver_str}
    (( ver_last = ver_ver - ver_pref ))
    opsys_info=$(echo ${ver_str} | cut -c${ver_pref}-${ver_ver})
    print "\n\tVersion:\t\t\t${opsys_info}" >> ${info_filename}  
    opsys_info=$(cat /etc/redhat-release)
    print "\t\t\t\t\t${opsys_info}" >> ${info_filename}
    opsys_info=$(/usr/sbin/getenforce)
    print "\n\tSELinux:\t\t\t${opsys_info}" >> ${info_filename}
    unset opsys_info ver_rel ver_pref ver_ver var_last
    print "Getting RPM data..."
    print "\nPackages for Oracle:" >> ${info_filename}

    rpm -qa --queryformat "\t%{NAME}-%{VERSION}-%{RELEASE} (%{ARCH})\n" | sort > ${temp_filename_1}

    # RPMs required for Oracle
    echo "^binutils-" > ${temp_filename_2}
    echo "^compat-db-" >> ${temp_filename_2}
    echo "^compat-libstdc++-" >> ${temp_filename_2}
    echo "^control-center-" >> ${temp_filename_2}
    echo "^gcc-" >> ${temp_filename_2}
    echo "^glibc-" >> ${temp_filename_2}
    echo "^ksh-" >> ${temp_filename_2}
    echo "^libaio-" >> ${temp_filename_2}
    echo "^libgcc-" >> ${temp_filename_2}
    echo "^libgcc-" >> ${temp_filename_2}
    echo "^libgnome-" >> ${temp_filename_2}
    echo "^libgnomeui-" >> ${temp_filename_2}
    echo "^libgomp-" >> ${temp_filename_2}
    echo "^libstdc++-" >> ${temp_filename_2}
    echo "^libstdc++-" >> ${temp_filename_2}
    echo "^libXp-" >> ${temp_filename_2}
    echo "^make-" >> ${temp_filename_2}
    echo "^sysstat-" >> ${temp_filename_2}

    typeset -i str_found
    cat ${temp_filename_1} | while read line
      do
        str_found=$(echo ${line} | grep -f ${temp_filename_2} | wc -l)
        if [ ${str_found} -eq 1 ]
        then
          print "\t${line}" >> ${info_filename}
        fi
      done

    print "\nPackages for Ime:" >> ${info_filename}
    # Now get the list of installed packages again, in a more useful format
    rpm -qa --queryformat "%{NAME}.%{ARCH}: %{VERSION}-%{RELEASE}\n" > ${temp_filename_1}

    for i in $REQUIRED_RPMS
    do
        #print "i:${i}:"
        result=$(grep ^$i ${temp_filename_1})
        #print "result:${result}:"
        if [ "${result}" != "" ]
        then
            #print "Found.\n"
            print "\t${result}" >> ${info_filename}
        else
            #print "Missing.\n"
            print " *\t${i}: PACKAGE MISSING" >>${info_filename}
        fi
    done

  ;;
  SunOS)
    print "Running uname..."
    opsys_info=$(uname -s)
    print "\n\tOperating System:\t\t${opsys_info}" >> ${info_filename}
    opsys_info=$(uname -r)
    print "\n\tRelease:\t\t\t${opsys_info}" >> ${info_filename}
    opsys_info=$(uname -v)
    print "\n\tVersion:\t\t\t${opsys_info}" >> ${info_filename}
    unset opsys_info

    if [[ -x /usr/bin/isainfo ]]
    then
      word_size=$(/usr/bin/isainfo -kv | cut -c 1-2)
      print "\n\tWord size:\t\t\t${word_size} bits" >> ${info_filename}
      unset word_size
    else
      print "/usr/bin/isainfo cannot be executed by this user"
    fi

  ;;
  esac
}

f_kernel()
{
  print "\n\nKERNEL Information" >> ${info_filename}
  print "====== ===========" >> ${info_filename}

  case ${op_sys} in
  AIX)
    if [ -x /usr/sbin/lsattr ]
    then
      print "Running lsattr..."
      /usr/sbin/lsattr -El sys0  >> ${info_filename}
    fi
    if [ -x /usr/bin/lslpp ]
    then
      print "Running lslpp..."
      print "\n\nFilesets:" >> ${info_filename}
      lslpp -l bos.adt.base bos.adt.lib bos.adt.libm bos.perf.perfstat bos.perf.libperfstat bos.perf.proctools >> ${info_filename}
    fi

    if [ -x /usr/sbin/instfix ]
    then
      print "\n\nAPAR data:" >> ${info_filename}
      /usr/sbin/instfix -i >> ${info_filename}
    fi
    ;;
  HP-UX)
    os_ver=$(uname -r | cut -d '.' -f3)
    case ${os_ver} in
    00)
      if [ -x /usr/sbin/kmtune ]
      then
        print "Running  (selective)..."
        print "\nOutput from /usr/sbin/kmtune (selective):\n" >> ${info_filename}
        /usr/sbin/kmtune -q ksi_alloc_max -q max_thread_proc -q maxdsiz -q maxdsiz_64bit -q maxfiles -q maxfiles_lim -q maxssiz -q maxssiz_64bit -q maxswapchunks -q maxuprc -q maxusers -q msgmap -q msgmni -q msgseg -q msgtql -q ncallout > ${temp_filename_1}
        /usr/sbin/kmtune -q ncsize -q nfile -q nflocks -q ninode -q nkthread -q nproc -q semmap -q semmni -q semmns -q semmnu -q semvmx -q shmmax -q shmmni -q shmseg -q vps_ceiling -q vx_ncsize >> ${temp_filename_1}
        sed -e 's/===============================================================================//' ${temp_filename_1} > ${temp_filename_2}
        sed -e 's/Parameter            Value//' ${temp_filename_2} > ${temp_filename_1}
        cat ${temp_filename_1} | sort | uniq | sed -e '/^$/d' > ${temp_filename_2}
        /usr/sbin/kmtune -q bufpages > ${temp_filename_1}
        cat ${temp_filename_1} ${temp_filename_2} >> ${info_filename}

        print "Running /usr/sbin/kmtune (long listing)..."
        print "\nOutput from /usr/sbin/kmtune (long):\n" >> ${info_filename}
       /usr/sbin/kmtune -l >> ${info_filename}
      else
        print "/usr/sbin/kmtune not found"
      fi
      ;;
    11)
      if [ -x /usr/sbin/kmtune ]
      then
        print "Running  (selective)..."
        print "\nOutput from /usr/sbin/kmtune (selective):\n" >> ${info_filename}
        /usr/sbin/kmtune -q ksi_alloc_max -q max_thread_proc -q maxdsiz -q maxdsiz_64bit -q maxfiles -q maxfiles_lim -q maxssiz -q maxssiz_64bit -q maxswapchunks -q maxuprc -q maxusers -q msgmap -q msgmni -q msgseg -q msgtql -q ncallout > ${temp_filename_1}
        /usr/sbin/kmtune -q ncsize -q nfile -q nflocks -q ninode -q nkthread -q nproc -q semmap -q semmni -q semmns -q semmnu -q semvmx -q shmmax -q shmmni -q shmseg -q vps_ceiling -q vx_ncsize >> ${temp_filename_1}
        sed -e 's/===============================================================================//' ${temp_filename_1} > ${temp_filename_2}
        sed -e 's/Parameter            Value//' ${temp_filename_2} > ${temp_filename_1}
        cat ${temp_filename_1} | sort | uniq | sed -e '/^$/d' > ${temp_filename_2}
        /usr/sbin/kmtune -q bufpages > ${temp_filename_1}
        cat ${temp_filename_1} ${temp_filename_2} >> ${info_filename}

        print "Running /usr/sbin/kmtune (long listing)..."
        print "\nOutput from /usr/sbin/kmtune (long):\n" >> ${info_filename}
       /usr/sbin/kmtune -l >> ${info_filename}
      else
        print "/usr/sbin/kmtune not found"
      fi
      ;;
    23)
      if [ -x /usr/sbin/kctune ]
      then
        print "Running  (selective)..."
        print "\nOutput from /usr/sbin/kctune (selective):\n" >> ${info_filename}
        /usr/sbin/kctune ksi_alloc_max max_thread_proc maxdsiz maxdsiz_64bit maxfiles maxfiles_lim maxssiz maxssiz_64bit maxswapchunks maxuprc maxusers msgmap msgmni msgseg msgtql ncallout > ${temp_filename_1}
        /usr/sbin/kctune bufpages ncsize nfile nflocks ninode nkthread nproc semmap semmni semmns semmnu semvmx shmmax shmmni shmseg vps_ceiling vx_ncsize >> ${temp_filename_1}

        cat ${temp_filename_1} | sort | uniq > ${temp_filename_2}

        print "\tTunable\t\tValue" > ${temp_filename_1}
        print "\t=============== ===============" >> ${temp_filename_1}

        > ${temp_filename_1}

        cat ${temp_filename_2} | while read line
        do
          str_value_1=$(echo ${line} | cut -d ' ' -f1)
          str_value_2=$(echo ${line} | cut -d ' ' -f2)
          typeset -i str_len=${#str_value_1}

          if [ "${str_value_1}" != "Tunable" ]
          then
            if [ ${str_len} -lt 8 ]
            then
              print "\t${str_value_1}\t\t${str_value_2}" >> ${temp_filename_1}
            else
              print "\t${str_value_1}\t${str_value_2}" >> ${temp_filename_1}
            fi
          fi
        done

        print "\tTunable\t\tValue" > ${temp_filename_2}
        print "\t=============== ===============" >> ${temp_filename_2}

        cat ${temp_filename_2} ${temp_filename_1} >> ${info_filename}
        unset str_len str_value_1 str_value_2

        print "Running /usr/sbin/kctune (long listing)..."
        print "\nOutput from /usr/sbin/kctune (long):\n" >> ${info_filename}
       /usr/sbin/kctune -a -v >> ${info_filename}
      else
        print "/usr/sbin/kctune not found"
      fi
      ;;
    31)
      if [ -x /usr/sbin/kctune ]
      then
        print "Running  (selective)..."
        print "\nOutput from /usr/sbin/kctune (selective):\n" >> ${info_filename}
        /usr/sbin/kctune ksi_alloc_max max_thread_proc maxdsiz maxdsiz_64bit maxfiles maxfiles_lim maxssiz maxssiz_64bit maxswapchunks maxuprc maxusers msgmap msgmni msgseg msgtql ncallout > ${temp_filename_1}
        /usr/sbin/kctune bufpages ncsize nfile nflocks ninode nkthread nproc semmap semmni semmns semmnu semvmx shmmax shmmni shmseg vps_ceiling vx_ncsize >> ${temp_filename_1}

        cat ${temp_filename_1} | sort | uniq > ${temp_filename_2}

        print "\tTunable\t\tValue" > ${temp_filename_1}
        print "\t=============== ===============" >> ${temp_filename_1}

        > ${temp_filename_1}

        cat ${temp_filename_2} | while read line
        do
          str_value_1=$(echo ${line} | cut -d ' ' -f1)
          str_value_2=$(echo ${line} | cut -d ' ' -f2)
          typeset -i str_len=${#str_value_1}

          if [ "${str_value_1}" != "Tunable" ]
          then
            if [ ${str_len} -lt 8 ]
            then
              print "\t${str_value_1}\t\t${str_value_2}" >> ${temp_filename_1}
            else
              print "\t${str_value_1}\t${str_value_2}" >> ${temp_filename_1}
            fi
          fi
        done

        print "\tTunable\t\tValue" > ${temp_filename_2}
        print "\t=============== ===============" >> ${temp_filename_2}

        cat ${temp_filename_2} ${temp_filename_1} >> ${info_filename}
        unset str_len str_value_1 str_value_2

        print "Running /usr/sbin/kctune (long listing)..."
        print "\nOutput from /usr/sbin/kctune (long):\n" >> ${info_filename}
       /usr/sbin/kctune -a -v >> ${info_filename}
      else
        print "/usr/sbin/kctune not found"
      fi
      ;;
    esac
    ;;
  Linux)
    > ${temp_filename_1}
    sysctl $SYSCTL_PARAMS | while read line
    do
      typeset -i remark_ind
      typeset -i line_len
      remark_ind=$(echo ${line} | grep ^# | wc -l)
      line_len=${#line}
      if [[ ${remark_ind} -eq 0 && ${line_len} -gt 0 ]]
      then
        print "${line}" >> ${temp_filename_1}
      fi
    done
    cat ${temp_filename_1} | sort > ${temp_filename_2}
    cat ${temp_filename_2} | while read line
    do
      print "\t${line}" >> ${info_filename}
    done
    unset remark_ind line_len
    ;;
  SunOS)

    if [[ -f /etc/system ]]
    then
      print "Printing system information"

      if [[ -f /etc/project ]]
      then
        print "\n\tContent of /etc/project:\n" >> ${info_filename}
        cat /etc/project | while read line
        do
          print "\t\t${line}" >> ${info_filename}
        done
      fi

      print "\n\tSelected output from /etc/system:\n" >> ${info_filename}
      grep set /etc/system | grep -v '*' | grep -v mddb_bootlist1 | cut -d ' ' -f2 > ${temp_filename_1}
      cat ${temp_filename_1} | while read line
      do
        print "\t${line}" >> ${info_filename}
      done
      rm ${temp_filename_1}
    else  
      print "/etc/system cannot be found"
    fi
    print "\n" >> ${info_filename}

    if [[ -x /etc/sysdef ]]
    then
      print "Getting kernel information - please wait..."
      print "\tSelected output from sysdef:\n" >> ${info_filename}
      > ${temp_filename_1}
      /etc/sysdef -i |sed -e 's/*/#/g' |while read line
      do
        START=`echo "${line}" |grep 'Tunable Parameters'`
        if [[ "${START}" != "" ]]
        then
          WRITE="YES"
        fi
        if [[ "${WRITE}" = "YES" ]]
        then
          echo ${line} |while read first rest
          do
            if [[ "${first}" != "#" ]]
            then
              print "\t${rest}\t${first}" >> ${temp_filename_1}
            fi
          done
        fi
      done

      cat ${temp_filename_1} | grep -v '(' | sort > ${temp_filename_2}
      cat ${temp_filename_1} | grep '(' | sort > ${temp_filename_3}
      typeset -i strsize=0
      > ${temp_filename_4}
      cat ${temp_filename_3} | while read line
      do
        field1=$(print ${line} | cut -d '(' -f1)
        field2=$(print ${line} | cut -d '(' -f2 | cut -d ')' -f1)
        field3=$(print ${line} | cut -d '(' -f2 | cut -d ' ' -f2)
        strsize=${#field2}
        if [[ ${strsize} -gt 7 ]]
        then
          tabstr1=""
        else
          tabstr1="\t"
        fi
        strsize=${#field3}
        if [[ ${strsize} -gt 7 ]]
        then
          tabstr2=""
        else
          tabstr2="\t"
        fi
        if [[ ${strsize} -gt 14 ]]
        then
          tabstr3=""
        else
          tabstr3="\t"
        fi
        print "\t${field2}${tabstr1}\t${field3}${tabstr2}${tabstr3}\t${field1}" >> ${temp_filename_4}
      done
      cat ${temp_filename_2} >> ${info_filename}
      cat ${temp_filename_4} | sort >> ${info_filename}
      rm ${temp_filename_1} ${temp_filename_2} ${temp_filename_3} ${temp_filename_4}
      unset strsize field1 field2 field3 
    fi  

    if [[ -x /usr/bin/isainfo ]]
    then
      word_size=$(/usr/bin/isainfo -kv | cut -c 1-2)
      if [[ ${word_size} = "64" ]]
      then
        if [[ -x /usr/bin/showrev ]]
        then
          print "Running showrev..."
          print "\nOutput from showrev -p:\n" >> ${info_filename}
          /usr/bin/showrev -p >> ${info_filename}
        else
          print "/usr/bin/showrev cannot be executed by this user"
        fi
      else
        if [[ -x /usr/bin/pkginfo ]]
        then
          print "Running pkginfo..."
          print "\nOutput from pkginfo -i package name:\n" >> ${info_filename}
          /usr/bin/pkginfo -i package name >> ${info_filename}
        else
          print "/usr/bin/pkginfo cannot be executed by this user"
        fi
      fi
    else
      print "/usr/bin/isainfo cannot be executed by this user"
    fi

    ;;
  esac
}

f_limits()
{
    print "\n\nLimits" >> ${info_filename}
    print     "======" >> ${info_filename}

    print "Checking limits..."

    ulimit -a | awk ' { printf "\t%s\n", $0 } ' >> ${info_filename}

}

f_running_processes()
{
  print "\n\nProcess Sample" >> ${info_filename}
  print "======= ======" >> ${info_filename}

  print "Counting processes..."

  ps -ef | cut -c1-9 | sort | uniq | grep -v UID > ${temp_filename_1}

  cat ${temp_filename_1} | while read line
  do
    ps_count=$(ps -ef | grep ${line} | wc -l)
    print "\t${line} running \t${ps_count} processes" >> ${info_filename}
  done
  rm ${temp_filename_1}
}

f_network()
{
	print "\n\nNETWORK Information" >> ${info_filename}
	print "======= ===========" >> ${info_filename}

	case ${op_sys} in
        AIX)
          if [ -x /usr/sbin/prtconf ]
          then
            print "Running prtconf..."
            /usr/sbin/prtconf > ${temp_filename_4}
            net_ip=$(cat ${temp_filename_4} | grep 'IP Address' | cut -d ':' -f2)
            net_sub=$(cat ${temp_filename_4} | grep 'Sub Netmask' | cut -d ':' -f2)
            net_gate=$(cat ${temp_filename_4} | grep 'Gateway' | cut -d ':' -f2)
            net_name_svr=$(cat ${temp_filename_4} | grep 'Name Server' | cut -d ':' -f2)
            net_domain=$(cat ${temp_filename_4} | grep 'Domain Name' | cut -d ':' -f2)

            print "\n\tIP Address\t${net_ip}" >> ${info_filename}
            print "\tSub Netmask\t${net_sub}" >> ${info_filename}
            print "\tGateway\t\t${net_gate}" >> ${info_filename}
            print "\tName Server\t${net_name_svr}" >> ${info_filename}
            print "\tDomain Name\t${net_domain}" >> ${info_filename}
            unset net_ip net_sub net_gate net_name net_domain
          else
            print "/usr/sbin/prtconf not found"
          fi
          ;;
	HP-UX)
		print "Obtaining IP address..."
		srvr_name=$(uname -n)
		IPADDRESS=`/usr/sbin/ping ${srvr_name} -n 1|grep ^64 |sed -e 's/(/ /g' -e 's/)/ /g' -e 's/:/ /g' |awk '{print $4}'`
		if [ "${IPADDRESS}" = "" ]; then
   			IPADDRESS="Unknown"
		fi
		print "\n\tIP Address:\t\t${IPADDRESS}\n" >> ${info_filename}
		unset srvr_name 

		f_hosts_file

		if [[ -f /usr/bin/ndd ]]
		then
			print "Running ndd..."
			print "\nOutput from ndd on tcp_conn_request_max:\n" >> ${info_filename}
			/usr/bin/ndd -get /dev/tcp tcp_conn_request_max >> ${info_filename}
		else
			print "/usr/bin/ndd not found"
		fi
		;;
        Linux)
		print "Obtaining IP address..."
		srvr_name=$(uname -n)
		ip_str=$(/bin/ping ${srvr_name} -c 1|grep ^64)
                ip_addr=$(echo ${ip_str} | cut -d '(' -f2 | cut -d ')' -f1 )
		if [ "${ip_addr}" = "" ]; then
   			ip_addr="Unknown"
		fi
		print "\n\tIP Address:\t\t${ip_addr}\n" >> ${info_filename}
		unset srvr_name 

		f_hosts_file

                ;;
	SunOS)

		print "Obtaining IP address..."
		srvr_name=$(uname -n)
		ipadd=$(/usr/sbin/ping -s ${srvr_name} 56 1|grep 64 | cut -d ' ' -f5)
		typeset -i ipaddstrsize=${#ipadd}
		(( ipaddstrsize = ${ipaddstrsize} - 2 ))
		dispipadd=$(echo ${ipadd} | cut -c 2-${ipaddstrsize})
		if [[ "${dispipadd}" = "" ]]
		then
	   		dispipadd="Unknown"
		fi
		print "\n\tIP Address:\t\t\t${dispipadd}\n" >> ${info_filename}
		unset srvr_name ipadd ipaddstrsize dispipadd

		f_hosts_file

		;;
	esac
}

f_hosts_file()
{
  if [[ -f /etc/hosts ]]
  then
    print "\n\t/etc/hosts file contents:" >> ${info_filename}
    print "\n\t\tIP Address\tHostname\tExtra information" >> ${info_filename}
    print "\t\t----------\t--------\t-----------------" >> ${info_filename}
    grep '^[0-9]' /etc/hosts |awk '{print "                "$1"\t"$2"\t"$3"\t"$4"\t"$5}' >> ${info_filename}
  else
    print "/etc/hosts not found"
  fi
}

f_filesystem()
{
  print "\n\nDATA STORAGE Information" >> ${info_filename}
  print "==== ======= ===========\n" >> ${info_filename}

  case ${op_sys} in
        AIX)
          if [[ -x /usr/sbin/lspv ]]
          then
            print "Running lspv..."
            print "\n\n\tPhysical volume information:\n" >> ${info_filename}
            /usr/sbin/lspv > ${temp_filename_1}
            cat ${temp_filename_1} | while read line
            do
              print "\t\t${line}" >> ${info_filename}
            done

            print "\n\n\tFile system types:\n" >> ${info_filename}

            typeset -i linelen=120
            typeset -i strlen 
            typeset -i maxlen=0 
            typeset -i tabcnt 
            > ${temp_filename_2}
            cat ${temp_filename_1} | while read line
            do
              objstat=$(echo $line | cut -d ' ' -f2)
              if [ "${objstat}" != "none" ]
              then
                physvol=$(echo ${line} | cut -d ' ' -f1)
                /usr/sbin/lspv -p ${physvol} >> ${temp_filename_2}
              fi
            done
            cat ${temp_filename_2} | sort | uniq | grep -v ':' | grep -v 'N/A' | grep -v 'MOUNT POINT' > ${temp_filename_3}
            cat ${temp_filename_3} | cut -c53-${linelen} | sort | uniq > ${temp_filename_2}

            cat ${temp_filename_2} | while read line
            do
              mpoint=$( echo ${line} | cut -d ' ' -f2)
              strlen=${#mpoint}
              if [ ${strlen} -gt ${maxlen} ]
              then
                maxlen=${strlen}
              fi
            done

            cat ${temp_filename_2} | while read line
            do

              fsys=$( echo ${line} | cut -d ' ' -f1)
              mpoint=$( echo ${line} | cut -d ' ' -f2)
              strlen=${#mpoint}
              tabcnt=$( echo "scale=0; ${strlen}/8" | bc )
              case ${tabcnt} in
              0)
                tabstr="\t\t\t\t"
                ;;
              1)
                tabstr="\t\t\t"
                ;;
              2)
                tabstr="\t\t"
                ;;
              *)
                tabstr="\t"
                ;;
              esac
              if [ "${mpoint}" != "" ]
              then
                echo "\t\t${mpoint}${tabstr}${fsys}" >> ${info_filename}
              fi  
            done

            unset linelen strlen maxlen tabcnt objstat physvol mpoint tabstr fsys
            rm ${temp_filename_1} 

          else
            print "/usr/sbin/lspv not executable by this user"
          fi
 
          if [[ -x /usr/bin/df ]]
          then
            print "Running df -k..."
            print "\n\n\tMounted Filesystem information:\n" >> ${info_filename}
            /usr/bin/df -k > ${temp_filename_1}
            cat ${temp_filename_1} | while read line
            do
              print "\t\t${line}" >> ${info_filename}
            done
            rm ${temp_filename_1} 
            f_free_disk_space
          else
            print "/usr/bin/df not executable by this user"
          fi
          if [ -d /var/.intec ]
          then
            varintec=$(ls -ld /var/.intec)
            ovarintec=$(echo ${varintec} | cut -d ' ' -f3)
            gvarintec=$(echo ${varintec} | cut -d ' ' -f4)
            print "\n\tDirectory /var/.intec exists, owned by ${ovarintec}:${gvarintec}\n" >> ${info_filename}
            unset varintec ovarintec gvarintec
          else
            print "\n\n\tDirectory /var/.intec does not exist or is not readable\n" >> ${info_filename}
          fi
          ;;
  HP-UX)
    if [[ -f /etc/fstab ]]
    then
      print "Getting contents of fstab..."
      print "\n\t/etc/fstab file contents:\n" >> ${info_filename}
      print "\n\t\tRaw device\tMount Point\tType\tOptions\tDump\tFSCK" >> ${info_filename}
      print "\t\t----------\t-----------\t----\t-------\t----\t----" >> ${info_filename}
      egrep '^/|^[a-z]' /etc/fstab |sed -e 's/,/;/g' |awk '{print "\t\t"$1"\t"$2"\t"$3"\t"$4"\t"$5"\t"$6}' >> ${info_filename}
    else
      print "/etc/fstab not found"
    fi

    if [[ -f /usr/bin/bdf ]]
    then
      print "Running bdf..."
      print "\n\n\tMounted Filesystem information:\n" >> ${info_filename}
      /usr/bin/bdf |awk '{if ( NF == 1 ) {printf("\t\t%s\t",$1)} else {for (i = 1; i <= NF-1; i++) {printf("\t\t%s\t",$i)} i++; print $NF } }' >> ${info_filename}
      f_free_disk_space
    else
      print "/usr/bin/bdf not found"
    fi
    if [ -d /var/.intec ]
    then
      varintec=$(ls -l /var/.intec)
      ovarintec=$(echo ${varintec} | cut -d ' ' -f5)
      gvarintec=$(echo ${varintec} | cut -d ' ' -f6)
      print "\n\tDirectory /var/.intec exists, owned by ${ovarintec}:${gvarintec}\n" >> ${info_filename}
      unset varintec ovarintec gvarintec
    else
      print "\n\n\tDirectory /var/.intec does not exist or is not readable\n" >> ${info_filename}
    fi
  ;;
  Linux)
    if [[ -f /etc/fstab ]]
    then
      print "Getting contents of fstab..."
      print "\n\t/etc/fstab file contents:\n" >> ${info_filename}
      print "\n\t\tRaw device\tMount Point\tType\tOptions\tDump\tFSCK" >> ${info_filename}
      print "\t\t----------\t-----------\t----\t-------\t----\t----" >> ${info_filename}
      egrep '^/|^[a-z]' /etc/fstab |sed -e 's/,/;/g' |awk '{print "\t\t"$1"\t"$2"\t"$3"\t"$4"\t"$5"\t"$6}' >> ${info_filename}
    else
      print "/etc/fstab not found"
    fi

    if [[ -x /bin/df ]]
    then
      print "Running df -k..."
      print "\n\n\tMounted Filesystem information:\n" >> ${info_filename}
      /bin/df -k > ${temp_filename_1}
      cat ${temp_filename_1} | while read line
      do
        print "\t\t${line}" >> ${info_filename}
      done
      rm ${temp_filename_1} 
      f_free_disk_space
    else
      print "/bin/df not executable by this user"
    fi
    if [ -d /var/.intec ]
    then
      varintec=$(ls -ld /var/.intec)
      ovarintec=$(echo ${varintec} | cut -d ' ' -f3)
      gvarintec=$(echo ${varintec} | cut -d ' ' -f4)
      print "\n\tDirectory /var/.intec exists, owned by ${ovarintec}:${gvarintec}\n" >> ${info_filename}
      unset varintec ovarintec gvarintec
    else
      print "\n\n\tDirectory /var/.intec does not exist or is not readable\n" >> ${info_filename}
    fi

  ;;
  SunOS)
    if [[ -f /etc/vfstab ]]
    then
      print "Getting contents of vfstab..."
      print "\n\t/etc/vfstab file contents:\n" >> ${info_filename}
      print "\n\t\tRaw device\tMount Point\tType\tOptions\tDump\tFSCK" >> ${info_filename}
      print "\t\t----------\t-----------\t----\t-------\t----\t----" >> ${info_filename}
      egrep '^/|^[a-z]' /etc/vfstab |sed -e 's/,/;/g' |awk '{print "\t\t"$1"\t"$2"\t"$3"\t"$4"\t"$5"\t"$6}' >> ${info_filename}
    else
      print "/etc/vfstab not found"
    fi

    if [[ -x /usr/bin/df ]]
    then
      print "Running df -k..."
      print "\n\n\tMounted Filesystem information:\n" >> ${info_filename}
      /usr/bin/df -k > ${temp_filename_1}
      cat ${temp_filename_1} | while read line
      do
        print "\t\t${line}" >> ${info_filename}
      done
      rm ${temp_filename_1} 
      f_free_disk_space
    else
      print "/usr/bin/df not executable by this user"
    fi
    if [ -d /var/.intec ]
    then
      varintec=$(ls -ld /var/.intec)
      ovarintec=$(echo ${varintec} | cut -d ' ' -f3)
      gvarintec=$(echo ${varintec} | cut -d ' ' -f4)
      print "\n\tDirectory /var/.intec exists, owned by ${ovarintec}:${gvarintec}\n" >> ${info_filename}
      unset varintec ovarintec gvarintec
    else
      print "\n\n\tDirectory /var/.intec does not exist or is not readable\n" >> ${info_filename}
    fi
  ;;
  esac
}

f_free_disk_space()
{

  line_count=""
  typeset -i count
  typeset -i size_field
  typeset -i available_field
  typeset -i kb_to_mb_factor=1024
  typeset -i mb_size
  typeset -i gb_size
  typeset -L1 left_one
  df_executable=""
  df_command=""
  df_parameter="-k"
  op_sys=$(uname -s)
 
  print "\n\tFree Disk Space:\n" >> ${info_filename}

  case ${op_sys} in
  HP-UX)
    df_executable="/usr/bin/bdf"
    df_command="${df_executable}"
    ;;
  Linux)
    df_executable="/bin/df"
    df_command="${df_executable} ${df_parameter}"
    ;;
  *)
    df_executable="/usr/bin/df"
    df_command="${df_executable} ${df_parameter}"
    ;;
  esac

  ${df_command} > ${temp_filename_1}

  cat ${temp_filename_1} | while read line
  do
    left_one=${line}
    if [ "${left_one}" = "/" ]
    then
      mount_point=$(echo ${line} | cut -d ' ' -f1)
      ${df_command} ${mount_point} > ${temp_filename_2}
      line_string=$(wc -l ${temp_filename_2})
      line_count=$(echo ${line_string} | cut -d ' ' -f1)
      case ${line_count} in
      2)
        count=0
        cat ${temp_filename_2} | while read df_line
        do
          (( count = count + 1 ))
          if [ ${count} -eq 2 ]
          then
            filesystem=$(echo ${line} | cut -d ' ' -f1)
            size_field=$(echo ${df_line} | cut -d ' ' -f2)
            available_field=$(echo ${df_line} | cut -d ' ' -f4)
            directory_name=$(echo ${df_line} | cut -d ' ' -f6)
            (( mb_size = size_field / kb_to_mb_factor ))
            (( gb_size = size_field / kb_to_mb_factor / kb_to_mb_factor ))
            print "\t${filesystem} (${directory_name})" >> ${info_filename}
            (( mb_size = size_field / kb_to_mb_factor ))
            (( gb_size = size_field / kb_to_mb_factor / kb_to_mb_factor ))
            print "\t\tSize            = ${size_field} KB \t${mb_size} MB \t${gb_size} GB" >> ${info_filename}
            (( mb_size = available_field / kb_to_mb_factor ))
            (( gb_size = available_field / kb_to_mb_factor / kb_to_mb_factor ))
            print "\t\tAvailable space = ${available_field} KB \t${mb_size} MB \t${gb_size} GB\n" >> ${info_filename}
          fi
        done
        ;;
      3)
        count=0
        cat ${temp_filename_2} | while read df_line
        do
          (( count = count + 1 ))
          if [ ${count} -eq 3 ]
          then
            size_field=$(echo ${df_line} | cut -d ' ' -f1)
            available_field=$(echo ${df_line} | cut -d ' ' -f3)
            directory_name=$(echo ${df_line} | cut -d ' ' -f5)
            (( mb_size = size_field / kb_to_mb_factor ))
            (( gb_size = size_field / kb_to_mb_factor / kb_to_mb_factor ))
            (( available_field = available_field / kb_to_mb_factor ))
            print "\t${line} (${directory_name})" >> ${info_filename}
            print "\t\tSize            = ${size_field} KB \t${mb_size} MB \t${gb_size} GB" >> ${info_filename}
            (( mb_size = available_field / kb_to_mb_factor ))
            (( gb_size = available_field / kb_to_mb_factor / kb_to_mb_factor ))
            print "\t\tAvailable space = ${available_field} KB \t${mb_size} MB \t${gb_size} GB\n" >> ${info_filename}
          fi
        done
        ;;
      esac
    fi
  done
  rm ${temp_filename_1} ${temp_filename_2}
}

f_logons()
{
  print "Obtaining account information..."
  print "\n\nUser Accounts" >> ${info_filename}
  print "==== ========\n" >> ${info_filename}

  cat /etc/passwd | cut -d ':' -f1,3,4,6,7 > ${temp_filename_1}
  cat ${temp_filename_1} | while read line
  do
    print "\t\t${line}" >> ${info_filename}
  done
  rm ${temp_filename_1} 

}

f_get_parent()
{
 pathname=$( ls -la ${1} | cut -d '>' -f2)
 print ${pathname} > ${temp_filename_1}
}

f_ksh()
{
  print "Obtaining ksh information..."
  print "\n\nKorn shell" >> ${info_filename}
  print "==== =====\n" >> ${info_filename}

  typeset -i i_count
  which ksh > ${temp_filename_1}
  pathname=$(which ksh)
  i_count=$(print ${pathname} | grep 'no ksh in' | wc -l)
  if [ ${i_count} -eq 1 ]
  then
    print "\tksh was not found\n" >> ${info_filename}
  else
    print "\tksh path is ${pathname}" >> ${info_filename}
    case ${op_sys} in
    Linux)
      ksh --version > ${temp_filename_2} 2>&1
      ksh_ver=$(cat ${temp_filename_2})
      print "\tksh version is ${ksh_ver}" >> ${info_filename}
    ;;
    *)
      seconds_string=${SECONDS}
      typeset -i count_dot
      count_dot=$(print ${seconds_string} | grep '\.' | wc -l)
      if [ ${count_dot} -eq 1 ]
      then
        ksh_ver="ksh93"
      else
        ksh_ver="ksh88"
      fi
      print "\tksh version is ${ksh_ver}" >> ${info_filename}
      unset count_dot seconds_string
    ;;
    esac
  fi
  i_count=$(ls -la ${pathname} | grep '>' | wc -l)

  while [ ${i_count} -ne 0 ]
  do
    f_get_parent ${pathname}
    pathname=$(cat ${temp_filename_1})
    print "\twhich points to ${pathname}" >> ${info_filename}
    i_count=$(ls -la ${pathname} | grep '>' | wc -l)
  done

  if [ -f /usr/bin/ksh ]
  then
    usr_bin_ksh=$(ls -l /usr/bin/ksh)
    usr_bin_ksh_owner=$(echo ${usr_bin_ksh} | cut -d ' ' -f3)
    usr_bin_ksh_group=$(echo ${usr_bin_ksh} | cut -d ' ' -f4)
    usr_bin_ksh_perms=$(echo ${usr_bin_ksh} | cut -d ' ' -f1)

    usr_bin_ksh_ur=$(echo ${usr_bin_ksh_perms} | cut -c2 )
    usr_bin_ksh_uw=$(echo ${usr_bin_ksh_perms} | cut -c3 )
    usr_bin_ksh_ux=$(echo ${usr_bin_ksh_perms} | cut -c4 )

    usr_bin_ksh_gr=$(echo ${usr_bin_ksh_perms} | cut -c5 )
    usr_bin_ksh_gw=$(echo ${usr_bin_ksh_perms} | cut -c6 )
    usr_bin_ksh_gx=$(echo ${usr_bin_ksh_perms} | cut -c7 )

    usr_bin_ksh_or=$(echo ${usr_bin_ksh_perms} | cut -c8 )
    usr_bin_ksh_ow=$(echo ${usr_bin_ksh_perms} | cut -c9 )
    usr_bin_ksh_ox=$(echo ${usr_bin_ksh_perms} | cut -c10 )
    
    typeset -i user_read=0
    typeset -i user_write=0
    typeset -i user_execute=0
    typeset -i user_perms=0

    typeset -i group_read=0
    typeset -i group_write=0
    typeset -i group_execute=0
    typeset -i group_perms=0

    typeset -i other_read=0
    typeset -i other_write=0
    typeset -i other_execute=0
    typeset -i other_perms=0
 
    if [ "${usr_bin_ksh_ur}" = "r" ]
    then
      user_read=4      
    fi

    if [ "${usr_bin_ksh_uw}" = "w" ]
    then
      user_write=2      
    fi

    if [ "${usr_bin_ksh_ux}" = "x" ]
    then
      user_execute=1      
    fi

    (( user_perms = user_read + user_write + user_execute ))

    if [ "${usr_bin_ksh_gr}" = "r" ]
    then
      group_read=4      
    fi

    if [ "${usr_bin_ksh_gw}" = "w" ]
    then
      group_write=2      
    fi

    if [ "${usr_bin_ksh_gx}" = "x" ]
    then
      group_execute=1      
    fi

    (( group_perms = group_read + group_write + group_execute ))

    if [ "${usr_bin_ksh_or}" = "r" ]
    then
      other_read=4      
    fi

    if [ "${usr_bin_ksh_ow}" = "w" ]
    then
      other_write=2      
    fi

    if [ "${usr_bin_ksh_ox}" = "x" ]
    then
      other_execute=1      
    fi

    (( other_perms = other_read + other_write + other_execute ))

    print "\n\t/usr/bin/ksh is owned by ${usr_bin_ksh_owner}:${usr_bin_ksh_group} with permissions of ${user_perms}${group_perms}${other_perms}">> ${info_filename}

    usr_bin_ksh_fb=$(echo ${usr_bin_ksh_perms} | cut -c1 )
    if [ "${usr_bin_ksh_fb}" = "l" ]
    then
      f_get_parent "/usr/bin/ksh"
      pathname=$(cat ${temp_filename_1})
      print "\tit points to ${pathname}" >> ${info_filename}
    fi 
  else
    print "\n\t/usr/bin/ksh not found or not readable" >> ${info_filename}
  fi
  unset pathname i_count ksh_ver

  unset usr_bin_ksh usr_bin_ksh_owner usr_bin_ksh_group usr_bin_ksh_perms
  unset usr_bin_ksh_ur usr_bin_ksh_uw usr_bin_ksh_ux
  unset usr_bin_ksh_gr usr_bin_ksh_gw usr_bin_ksh_gx
  unset usr_bin_ksh_or usr_bin_ksh_ow usr_bin_ksh_ox
  unset user_read user_write user_execute
  unset group_read group_write group_execute
  unset other_read other_write other_execute
  unset user_perms group group_perms other_perms
}

f_etcservices()
{
  print "\n\nCONFIGURED PORT Information" >> ${info_filename}
  print     "========== ==== ===========" >> ${info_filename}

  if [[ -f /etc/services ]]
  then
    print "Capturing /etc/services"
    print "\n\n\t/etc/services information:\n" >> ${info_filename}
    cat /etc/services > ${temp_filename_1}
    cat ${temp_filename_1} | while read line
    do
      print "\t\t${line}" >> ${info_filename}
    done
    rm ${temp_filename_1} 
  else
    print "/etc/services was not found"
  fi
}

f_3rd_party()
{
  case ${third_party_option} in
  0)
    # Do nothing 
    ;;
  1)
    # Search for Java
    print "\n\n3RD PARTY SOFTWARE Information" >> ${info_filename}
    print "=== ===== ======== ===========\n" >> ${info_filename}
    f_find_java
    ;;
  2)
    # Search for Oracle
    print "\n\n3RD PARTY SOFTWARE Information" >> ${info_filename}
    print "=== ===== ======== ===========\n" >> ${info_filename}
    f_find_oracle
    ;;
  3)
    # Search for Java and Oracle
    print "\n\n3RD PARTY SOFTWARE Information" >> ${info_filename}
    print "=== ===== ======== ===========\n" >> ${info_filename}
    f_find_oracle
    f_find_java
    ;;
  esac
}

f_find_java()
{
  if [[ "${JAVA_HOME}" != "" ]]
  then
    > ${temp_filename_1}
    java -version 2>&1 | tee ${temp_filename_1}
    java_version=$(grep version ${temp_filename_1})
    disp_java=$(print ${java_version} | cut -c 6-${#java_version})
    print "\n\tJava installed is ${disp_java}\n" >> ${info_filename}
    unset disp_java
  else
    print "Trying to find Java - please wait..."
    > ${temp_filename_1}
    print "#! /bin/ksh" > ${temp_filename_4}
    print "find / -name java -print > ${temp_filename_1} 2>/dev/null" >> ${temp_filename_4}
    chmod 750 ${temp_filename_4}
    ./${temp_filename_4} |&
    sleep 2
    ps_line=$(ps -ef|grep find | grep java)
    the_pid=$(echo ${ps_line} | cut -d ' ' -f2)
    unset ps_line
    while true
    do
      print -n -- .
      sleep 1
      if [ "${the_pid}" = "" ]
      then
        the_pid="##dummy##"
      fi
      if [ `ps -ef | grep ${the_pid} | grep java | wc -l` -eq 0 ]
      then
        print
        break
      fi
    done
    cat ${temp_filename_1} | grep jre | grep bin | grep -v oracle | grep -v openv | grep -v PA_RISC > ${temp_filename_2}

    poss_dirs=$(wc -l ${temp_filename_2})
    typeset -i file_count=0
    file_count=$(echo ${poss_dirs} | cut -d ' ' -f1)
    if [ ${file_count} -gt 0 ]
    then
      print "\n\tJava found at:" >> ${info_filename}
      cat ${temp_filename_2} | while read line
      do
        if [ -x ${line} ]
        then
          ${line} -version 2>&1 | tee ${temp_filename_3} 
          if [ `grep 'java version' ${temp_filename_3} | wc -l ` -gt 0 ]
          then
            java_version=$(grep 'java version' ${temp_filename_3} | cut -d '"' -f2)
          else
            java_version=""
          fi
        else
            java_version="non-executable"
        fi
        print "\t\t${line} (${java_version})" >> ${info_filename}
      done
    else
      print "\n\tNo versions of Java were found" >> ${info_filename}
    fi
    unset file_count
    unset the_pid
    unset java_version
  fi
}

f_find_oracle()
{
  if [[ "${ORACLE_HOME}" != "" ]]
  then
    > ${temp_filename_1}
    sqlplus -version > ${temp_filename_1}
    disp_ora=$(grep '[0-9]' ${temp_filename_1} | cut -d ' ' -f3)
    print "\n\tOracle installed is version ${disp_ora}\n" >> ${info_filename}
    unset disp_ora
    if [ `ps -ef | grep tnslsnr | grep -v grep | wc -l` -eq 1 ]
    then
      if [ -x ${ORACLE_HOME}/bin/lsnrctl ]
      then
        print "\n\t\tListener status:\n" >> ${info_filename}
        ${ORACLE_HOME}/bin/lsnrctl status > ${temp_filename_4}
        cat ${temp_filename_4} | grep Instance | grep READY | uniq | sort | sed -e 's/Instance/                    Instance/' | sed -e 's/for this service...//' >> ${info_filename} 
        cat ${temp_filename_4} | grep Instance | grep UNKNOWN | uniq | sort | sed -e 's/Instance/                    Instance/' | sed -e 's/for this service...//' >> ${info_filename} 
      fi
    fi
  else
    print "Trying to find Oracle - please wait"
    > ${temp_filename_1}
    print "#! /bin/ksh" > ${temp_filename_4}
    print "find / -name oracle -print > ${temp_filename_1} 2>/dev/null" >> ${temp_filename_4}
    chmod 750 ${temp_filename_4}
    ./${temp_filename_4} |&
    ps_line=$(ps -ef|grep find | grep oracle)
    if [ "${ps_line}" = "" ]
    then
      sleep 2
      ps_line=$(ps -ef|grep find | grep oracle)
    fi
    the_pid=$(echo ${ps_line} | cut -d ' ' -f2)
    unset ps_line
    while true
    do
      print -n -- .
      sleep 1
      if [ `ps -ef | grep ${the_pid} | grep oracle | wc -l` -eq 0 ]
      then
        print
        break
      fi
    done
    cat ${temp_filename_1} | grep bin | grep -v java | grep -v ultrasearch > ${temp_filename_2}
    poss_dirs=$(wc -l ${temp_filename_2})
    typeset -i file_count=0
    file_count=$(echo ${poss_dirs} | cut -d ' ' -f1)
    if [ ${file_count} -gt 0 ]
    then
      print "\n\tOracle found at:" >> ${info_filename}
      cat ${temp_filename_2} | while read line
      do
        typeset -i oracle_path_len=${#line}
        let oracle_path_len=${oracle_path_len}-7
        oracle_path=$(echo ${line} | cut -c1-${oracle_path_len})
        let oracle_path_len=${oracle_path_len}-4
        oracle_home=$(echo ${line} | cut -c1-${oracle_path_len})
        if [ -x ${oracle_home}/bin/sqlplus ]
        then
          export ORACLE_HOME=${oracle_home}
          ${ORACLE_HOME}/bin/sqlplus -version > ${temp_filename_3} 
          if [ `cat ${temp_filename_3} | grep 'Release' | wc -l` -gt 0 ]
          then
            sql_version=$(cat ${temp_filename_3} | grep 'Release' | cut -d ' ' -f3 )
          else
            sql_version=""
          fi
        else
          sql_version="non-executable"
        fi 
        print "\t\t${oracle_home} (${sql_version})" >> ${info_filename}
      done
    else
    #
    # Using "find" no suitable strings were discovered
    # This can happen because UNIX file permissions are wrong
    # (especially Oracle bug 4516865) or because of odd links
    #
    # Will now look using "ls -R"
    #
      print "\nCarrying out detailed search for Oracle, please wait..."
      ls -R / > ${temp_filename_1} 2>/dev/null
      grep oracle ${temp_filename_1} | grep bin | grep -v java | grep -v java | grep -v jdbc | grep -v jdk | grep -v jre | grep -v network | grep -v oui | grep -v perl | grep -v ultrasearch > ${temp_filename_2}
      poss_dirs=$(wc -l ${temp_filename_2})
      typeset -i file_count=0
      file_count=$(echo ${poss_dirs} | cut -d ' ' -f1)
      if [ ${file_count} -eq 0 ]
      then
        print "\n\tNo versions of Oracle were found" >> ${info_filename}
      else
      #
      # File contains strings with training colon
      #
        valid_string="N"
        print "\n\tOracle files found:" >> ${info_filename}

        cat ${temp_filename_2} | while read line
        do
          oracle_string=$(echo ${line} | cut -d ':' -f1 )
          if [ -f ${oracle_string}/sqlplus ]
          then
            valid_string="Y"
            typeset -i oracle_path_len=${#oracle_string}
            let oracle_path_len=${oracle_path_len}-4
            oracle_home=$(echo ${oracle_string} | cut -c1-${oracle_path_len})
            if [ -x ${oracle_home}/sqlplus ]
            then
              export ORACLE_HOME=${oracle_home}
              ${oracle_home}/sqlplus -version > ${temp_filename_3} 
              if [ `cat ${temp_filename_3} | grep 'Release' | wc -l` -gt 0 ]
              then
                sql_version=$(cat ${temp_filename_3} | grep 'Release' | cut -d ' ' -f3 )
              else
                sql_version="(non-executable)"
              fi
              print "\t\t${oracle_home}/sqlplus ${sql_version}" >> ${info_filename}
             else
              print "\t\t${oracle_home}/sqlplus (non-executable)" >> ${info_filename}
            fi
          fi
          if [ -f ${oracle_string}/imp ]
          then
            valid_string="Y"
            if [ -x ${oracle_string}/imp ]
            then
              print "\t\t${oracle_home}/imp (executable)" >> ${info_filename}
            else
              print "\t\t${oracle_home}/imp (non-executable)" >> ${info_filename}
            fi
          fi
        done
        if [ "${valid_string}" = "N" ]
        then
          print "\t\tFiles icluding the 'oracle' string were found,\n\t\tbut none had paths containing strings\n\t\t'sqlplus' or 'imp'" >> ${info_filename}
        fi
        unset oracle_string valid_string
      fi
    fi
    unset the_pid poss_dirs
    unset file_count
    unset ORACLE_HOME oracle_home oracle_path_len oracle_path
  fi
}

f_terminate()
{
  print "\n\n\t\t\t\t############"
  print "\t\t\t\t# FINISHED #"
  print "\t\t\t\t############\n"
  XX=`date "+%a %d %b %Y %X %Z"`
  print "\n${XX}" >> ${info_filename}
  print "\n\tFile is \t${info_filename}\n"

  rm -f ${temp_filename_1}
  rm -f ${temp_filename_2}
  rm -f ${temp_filename_3}
  rm -f ${temp_filename_4}
}

#----------------------------------------------------------------------
# Main
#----------------------------------------------------------------------
op_sys=$(uname -s)
case ${op_sys} in
AIX)
  ;;
HP-UX)
  ;;
Linux)
# RPMs required for CSG Intermediate
# Note this list should match the list in
# install_imev7.1_root.bash
REQUIRED_RPMS="\
atk.i686 \
atk.x86_64 \
audit-libs.i686 \
audit-libs.x86_64 \
binutils.x86_64 \
bzip2-libs.x86_64 \
cairo.i686 \
cairo.x86_64 \
compat-db43.x86_64 \
compat-expat1.x86_64 \
compat-libstdc++-296.i686 \
compat-libtermcap.i686 \
compat-libtermcap.x86_64 \
compat-openldap.x86_64 \
cpp.x86_64 \
cyrus-sasl-lib.x86_64 \
ed.x86_64 \
expat.i686 \
expat.x86_64 \
fontconfig.i686 \
fontconfig.x86_64 \
freetype.i686 \
freetype.x86_64 \
ftp.x86_64 \
gcc-c++.x86_64 \
gdbm.i686 \
gdbm.x86_64 \
gdk-pixbuf2.i686 \
gdk-pixbuf2.x86_64 \
glib2.i686 \
glib2.x86_64 \
glibc-devel.i686 \
glibc-devel.x86_64 \
glibc.i686 \
glibc.x86_64 \
gpm-libs.x86_64 \
gtk2.i686 \
gtk2.x86_64 \
kernel-devel.x86_64 \
keyutils-libs.i686 \
keyutils-libs.x86_64 \
krb5-libs.i686 \
krb5-libs.x86_64 \
ksh.x86_64 \
lcms-libs.i686 \
libICE.i686 \
libICE.x86_64 \
libSM.i686 \
libSM.x86_64 \
libX11.i686 \
libX11.x86_64 \
libXau.i686 \
libXau.x86_64 \
libXcomposite.i686 \
libXcomposite.x86_64 \
libXcursor.i686 \
libXcursor.x86_64 \
libXdamage.i686 \
libXdamage.x86_64 \
libXext.i686 \
libXext.x86_64 \
libXfixes.i686 \
libXfixes.x86_64 \
libXft.i686 \
libXft.x86_64 \
libXi.i686 \
libXi.x86_64 \
libXinerama.i686 \
libXinerama.x86_64 \
libXmu.i686 \
libXmu.x86_64 \
libXp.i686 \
libXp.x86_64 \
libXpm.i686 \
libXpm.x86_64 \
libXrandr.i686 \
libXrandr.x86_64 \
libXrender.i686 \
libXrender.x86_64 \
libXt.i686 \
libXt.x86_64 \
libacl.x86_64 \
libaio.x86_64 \
libart_lgpl.i686 \
libattr.x86_64 \
libcom_err.i686 \
libcom_err.x86_64 \
libgcc.i686 \
libidn.x86_64 \
libjpeg-turbo.i686 \
libjpeg-turbo.x86_64 \
libmng.i686 \
libpcap.x86_64 \
libpng.i686 \
libpng.x86_64 \
libselinux.i686 \
libselinux.x86_64 \
libstdc++.i686 \
libstdc++.x86_64 \
libutempter.i686 \
libuuid.i686 \
libuuid.x86_64 \
libxcb.i686 \
libxcb.x86_64 \
lksctp-tools.i686 \
lksctp-tools.x86_64 \
lsof.x86_64 \
lsscsi.x86_64 \
mlocate.x86_64 \
ncurses-devel.i686 \
ncurses-libs.i686 \
ncurses-libs.x86_64 \
nspr.x86_64 \
nss-softokn-freebl.i686 \
nss-softokn-freebl.x86_64 \
nss-util.x86_64 \
nss.x86_64 \
ntp.x86_64 \
ntpdate.x86_64 \
openldap.x86_64 \
openmotif.x86_64 \
openmotif22.i686 \
openssh-clients.x86_64 \
openssl-devel.i686 \
openssl.x86_64 \
pam.i686 \
pam.x86_64 \
pango.i686 \
pango.x86_64 \
perl.x86_64 \
pixman.i686 \
pixman.x86_64 \
postgresql-libs.x86_64 \
popt.i686 \
popt.x86_64 \
qt3.i686 \
redhat-lsb.x86_64 \
rpcbind.x86_64 \
screen.x86_64 \
sg3_utils-libs.x86_64 \
sg3_utils.x86_64 \
sqlite.x86_64 \
tar.x86_64 \
strace.x86_64 \
vsftpd.x86_64 \
wget.x86_64 \
xinetd.x86_64 \
xterm.x86_64 \
zlib.i686 \
"
SYSCTL_PARAMS="fs.file-max kernel.core_uses_pid kernel.panic kernel.panic_on_oops kernel.sem kernel.shmall kernel.shmmax kernel.shmmni kernel.threads-max net.core.netdev_max_backlog net.core.rmem_default net.core.rmem_max net.core.somaxconn net.core.wmem_default net.core.wmem_max net.ipv4.ip_local_port_range net.ipv4.tcp_mem net.ipv4.tcp_rmem net.ipv4.tcp_wmem net.ipv4.tcp_tw_recycle net.ipv4.tcp_window_scaling net.ipv4.udp_rmem_min net.ipv4.udp_wmem_min vm.dirty_background_ratio vm.dirty_ratio"
  ;;
SunOS)
  ;;
*)
  print "Unsupported Operating system"
  exit 1
  ;;
esac

java_only=""
oracle_only=""
no_third_party=""
typeset -i third_party_option
third_party_option=0
use_tmp=""

if [ ${#} -gt 0 ]
then
  while getopts :jonht switch
  do
    case ${switch} in
    j)
      (( third_party_option = third_party_option + 1 ))
      if [ -z "${no_third_party}" ]
      then
	java_only=Y
      else
	echo "Can not use switches 'j' and 'n' together"
	exit
      fi
      ;;
    o)
      (( third_party_option = third_party_option + 2 ))
      if [ -z "${no_third_party}" ]
      then
	oracle_only=Y
      else
	echo "Can not use switches 'o' and 'n' together"
	exit
      fi
      ;;
    n)
      if [[ -z "${java_only}" && -z "${oracle_only}" ]]
      then
	no_third_party=Y
      else
	echo "Can not use switch 'n' with other options"
	exit
      fi
      ;;
    ?|h)
       print "Usage: ${0}: [-n (no 3rd party software) | -j (java) -o (oracle) ] [ -h (this message)]\n"
       exit 0
      ;;
    t)
       use_tmp=yes
       print "Creating results file in /tmp\n"
      ;;
    esac
  done
else 
  third_party_option=3
fi

f_initialise
f_hardware
f_operating_system
f_kernel
f_limits
f_running_processes
f_network
#f_etcservices
f_filesystem
f_logons
f_ksh
f_3rd_party
f_terminate

exit 0