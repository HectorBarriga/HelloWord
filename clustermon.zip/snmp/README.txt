This directory contains all of the snmp files
that may be needed on the Tango system.

snmp.guide and snmpd.conf files are from kay, see email.

snmp.tango can be renamed as snmpd.conf either.

This software should be installed as per the Tango SX-5
Platform Installation Guide.

File Permissions for snmpd.conf:
-rw-r--r--   1 root     other       2113 May  1  2000 snmpd.conf

File Permissions for MIB Files:
-rwxr-xr-x   1 root     other      17455 Feb 12  2003 AGENTX-MIB.txt
-rwxr-xr-x   1 root     other      24613 Feb 12  2003 DISMAN-SCHEDULE-MIB.txt
-rwxr-xr-x   1 root     other      64311 Feb 12  2003 DISMAN-SCRIPT-MIB.txt
-rwxr-xr-x   1 root     other      50054 Feb 12  2003 EtherLike-MIB.txt
-rwxr-xr-x   1 root     other       4660 Feb 12  2003 HCNUM-TC.txt
-rwxr-xr-x   1 root     other      52544 Feb 12  2003 HOST-RESOURCES-MIB.txt
-rwxr-xr-x   1 root     other      10583 Feb 12  2003 HOST-RESOURCES-TYPES.txt
-rwxr-xr-x   1 root     other       4743 Feb 12  2003 IANA-ADDRESS-FAMILY-NUMBERS-MIB.txt
-rwxr-xr-x   1 root     other       4299 Feb 12  2003 IANA-LANGUAGE-MIB.txt
-rwxr-xr-x   1 root     other      18588 Feb 12  2003 IANAifType-MIB.txt
-rw-r--r--   1 root     other        229 May  1  2000 ianalist
-rwxr-xr-x   1 root     other       5066 Feb 12  2003 IF-INVERTED-STACK-MIB.txt
-rwxr-xr-x   1 root     other      71691 Feb 12  2003 IF-MIB.txt
-rwxr-xr-x   1 root     other      12517 Feb 12  2003 INET-ADDRESS-MIB.txt
-rwxr-xr-x   1 root     other      26781 Feb 12  2003 IP-FORWARD-MIB.txt
-rwxr-xr-x   1 root     other      23499 Feb 12  2003 IP-MIB.txt
-rwxr-xr-x   1 root     other      15936 Feb 12  2003 IPV6-ICMP-MIB.txt
-rwxr-xr-x   1 root     other      48703 Feb 12  2003 IPV6-MIB.txt
-rwxr-xr-x   1 root     other       2367 Feb 12  2003 IPV6-TC.txt
-rwxr-xr-x   1 root     other       7257 Feb 12  2003 IPV6-TCP-MIB.txt
-rwxr-xr-x   1 root     other       4400 Feb 12  2003 IPV6-UDP-MIB.txt
-rw-r--r--   1 root     other       3000 May  1  2000 Makefile
-rw-r--r--   1 root     other       1313 May  1  2000 Makefile.in
-rw-r--r--   1 root     other       4363 May  1  2000 Makefile.mib
-rwxr-xr-x   1 root     other        881 May  1  2000 mibfetch
-rw-r--r--   1 root     other      42375 May  1  2000 MTA-MIB.txt
-rwxr-xr-x   1 root     other       6523 Feb 12  2003 NET-SNMP-AGENT-MIB.txt
-rwxr-xr-x   1 root     other       4583 Feb 12  2003 NET-SNMP-EXAMPLES-MIB.txt
-rwxr-xr-x   1 root     other       1681 Feb 12  2003 NET-SNMP-MIB.txt
-rw-r--r--   1 root     other      21006 May  1  2000 NETWORK-SERVICES-MIB.txt
-rwxr-xr-x   1 root     other      24723 Feb 12  2003 NOTIFICATION-LOG-MIB.txt
-rw-r--r--   1 root     other       1916 May  1  2000 README.mibs
-rwxr-xr-x   1 root     other       1174 Feb 12  2003 RFC-1215.txt
-rwxr-xr-x   1 root     other       3067 Feb 12  2003 RFC1155-SMI.txt
-rwxr-xr-x   1 root     other      79667 Feb 12  2003 RFC1213-MIB.txt
-rw-r--r--   1 root     other       2901 May  1  2000 rfclist
-rw-r--r--   1 root     other      20940 May  1  2000 rfcmibs.diff
-rwxr-xr-x   1 root     other     147822 Feb 12  2003 RMON-MIB.txt
-rwxr-xr-x   1 root     other       3240 May  1  2000 smistrip
-rwxr-xr-x   1 root     other       4628 Feb 12  2003 SMUX-MIB.txt
-rwxr-xr-x   1 root     other      15490 Feb 12  2003 SNMP-COMMUNITY-MIB.txt
-rwxr-xr-x   1 root     other      22342 Feb 12  2003 SNMP-FRAMEWORK-MIB.txt
-rwxr-xr-x   1 root     other       5496 Feb 12  2003 SNMP-MPD-MIB.txt
-rwxr-xr-x   1 root     other      20014 Feb 12  2003 SNMP-NOTIFICATION-MIB.txt
-rwxr-xr-x   1 root     other       9106 Feb 12  2003 SNMP-PROXY-MIB.txt
-rwxr-xr-x   1 root     other      22769 Feb 12  2003 SNMP-TARGET-MIB.txt
-rwxr-xr-x   1 root     other      39201 Feb 12  2003 SNMP-USER-BASED-SM-MIB.txt
-rwxr-xr-x   1 root     other      34162 Feb 12  2003 SNMP-VIEW-BASED-ACM-MIB.txt
-rwxr-xr-x   1 root     other       8263 Feb 12  2003 SNMPv2-CONF.txt
-rwxr-xr-x   1 root     other      29305 Feb 12  2003 SNMPv2-MIB.txt
-rwxr-xr-x   1 root     other       8924 Feb 12  2003 SNMPv2-SMI.txt
-rwxr-xr-x   1 root     other      38034 Feb 12  2003 SNMPv2-TC.txt
-rwxr-xr-x   1 root     other       5775 Feb 12  2003 SNMPv2-TM.txt
-rw-r--r--   1 root     other       4353 May  1  2000 TANGO-MIB.txt
-rwxr-xr-x   1 root     other      10765 Feb 12  2003 TCP-MIB.txt
-rw-r--r--   1 root     other      12907 May  1  2000 TUNNEL-MIB.txt
-rw-r--r--   1 root     other        264 May  1  2000 UCD-DEMO-MIB.inc
-rwxr-xr-x   1 root     other       2163 Feb 12  2003 UCD-DEMO-MIB.txt
-rw-r--r--   1 root     other        266 May  1  2000 UCD-DISKIO-MIB.inc
-rwxr-xr-x   1 root     other       3198 Feb 12  2003 UCD-DISKIO-MIB.txt
-rw-r--r--   1 root     other        229 May  1  2000 UCD-DLMOD-MIB.inc
-rwxr-xr-x   1 root     other       3010 Feb 12  2003 UCD-DLMOD-MIB.txt
-rw-r--r--   1 root     other        232 May  1  2000 UCD-IPFILTER-MIB.inc
-rw-r--r--   1 root     other       6399 May  1  2000 UCD-IPFILTER-MIB.txt
-rw-r--r--   1 root     other        267 May  1  2000 UCD-IPFWACC-MIB.inc
-rwxr-xr-x   1 root     other       8118 Feb 12  2003 UCD-IPFWACC-MIB.txt
-rw-r--r--   1 root     other      18274 May  1  2000 UCD-SNMP-MIB-OLD.txt
-rw-r--r--   1 root     other        231 May  1  2000 UCD-SNMP-MIB.inc
-rwxr-xr-x   1 root     other      34561 Feb 12  2003 UCD-SNMP-MIB.txt
-rwxr-xr-x   1 root     other       4076 Feb 12  2003 UDP-MIB.txt