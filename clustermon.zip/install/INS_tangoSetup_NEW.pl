#!/usr/bin/perl -w
use strict;
#****************************************************************************
#  Filename:    INS_tangoSetup.pl
#  Revision:    $Revision: 1.0 $
#  Author:      Mario Hacker from Jack Downey
#  Updates:     1.0   Perl version
# 
# This script creates the tango user along with the
# tango, operator and readonly groups. It then creates the /tango directory
# hierarchy. The user can specify the number of database processes that are
# expected to run.
#
# Note 1: This script must be run as root.
# Note 2: Passwords can't be set from the script. Please use the passwd
#         program to assign the initial passwords for tango, operator and
#         monitor.
#
# Copyright (c) Tango Telecom 2015, all rights reserved.
# This file contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or in
# part is expressly prohibited, except as may be specifically authorized
# by prior written agreement or permission of Tango Telecom.
# 
#***************************************************************************

# Check the argument

my $linux = 0;
my $uname = `/bin/uname -a`;
$linux = ($uname =~ /Linux/i );

# It would be safer to use /home/tango for tango home directory going forward

my $tangoHomeDir = "/home/tango";


my $whoamiCmd     = "/usr/ucb/whoami";
my $groupAddCmd   = "/usr/sbin/groupadd";
my $userAddCmd   	= "/usr/sbin/useradd";
my $mkdirCmd   	= "/bin/mkdir -p";
my $chownCmd   	= "/bin/chown";
my $chmodCmd	   = "/bin/chmod";
my $cdCmd		   = "cd";
my $passwdCmd   	= "/bin/passwd"; 
my $lnCmd         = "/bin/ln -s ";

if ($linux)
{
   $passwdCmd   	= "/usr/bin/passwd" ;
   $whoamiCmd     = "/usr/bin/whoami";
}   


my $whoami = `$whoamiCmd`;
$whoami =~ s/\n//g;

if ($whoami ne "root" )
{
   print "\nYou have to be root to run this script !\n\n";
   exit(-1);
}

my $groupFile = "/etc/group";
my $passwdFile =  "/etc/passwd"; 

my %GroupIdByName;
my %GroupNameById;
my %UserIdByName;
my %GroupIdByUsername;
my %UsernameById;  
my %UserLine;

my $result = "";
print "###########################################################################\n";
print "#    1. Checking /etc/group file                                          #\n";
print "###########################################################################\n";

open (GROUP, "$groupFile");
while (<GROUP>)
{
   my ($group,$ignore,$gid,$users) = split (/:/, $_);
   $GroupIdByName{$group} = $gid;
   $GroupNameById{$gid} = $group;  
}
close (GROUP);

open (PASSWD, "$passwdFile");
while (<PASSWD>)
{
   my ($username,$ignore,$uid,$gid,$description,$homeDir,$shell) = split (/:/, $_);
   $UserIdByName{$username} = $uid;
   $GroupIdByUsername{$username} = $gid;
   $UsernameById{$uid} = $username;  
   $UserLine{$username} = $_; 
}

close (PASSWD);


# The Rule is : the group id tango has to be 500 , operator 501, readonly 502
my $causeToExit = 0;
if  ((defined ($GroupNameById{"500"})) || (defined ($GroupNameById{"501"})) || (defined ($GroupNameById{"502"})) )
{
   if  ($GroupNameById{"500"} ne "tango")
   {
      print "Group with id:500 is already defined as : ".$GroupNameById{"500"} . "!\n";
      print "It is recomended that the group: tango has the ID: 500 ! \n";
      print "If you are aware of the consequences change your group id using the command : \n";
      print "\n\$ groupmod -g <newid> " .$GroupNameById{"500"} ."\n\n";
      print "Then you can rerun this script again...\n\n";
      $causeToExit = 1;
   }
   if  ($GroupNameById{"501"} ne "operator")
   {
      print "Group with id:501 is already defined as : ".$GroupNameById{"501"} . "!\n";
      print "It is recomended that the group: operator has the ID: 501 ! \n";
      print "If you are aware of the consequences change your group id using the command : \n";
      print "\n\$ groupmod -g <newid> " .$GroupNameById{"501"} ."\n\n";
      print "Then you can rerun this script again...\n\n";
      $causeToExit = 1;
   }
   if  ($GroupNameById{"502"} ne "readonly")
   {
      print "Group with id:502 is already defined as : ".$GroupNameById{"502"} . "!\n";
      print "It is recomended that the group: readonly has the ID: 502 ! \n";
      print "If you are aware of the consequences change your group id using the command : \n";
      print "\n\$ groupmod -g <newid> " .$GroupNameById{"502"} ."\n\n";
      print "Then you can rerun this script again...\n\n";
      $causeToExit = 1;
   }
   exit(-1) if ($causeToExit);
}
# Continue only  when the IDs:500,501,502 are not already defined
my $tangoGroupDone = 0;
my $opearatorGroupDone = 0;
my $readonlyGroupDone = 0;
my $tangoUserDone = 0;

if  (defined ($GroupIdByName{"tango"})) 
{
   if ($GroupIdByName{"tango"} ne "500")
   {
      print "Group with name:tango is already defined with id: ".$GroupIdByName{"tango"} . "!\n";
      print "It is recomended that the group: tango has the id: 500 ! \n";
      
      print "Please change the group: tango to use the id:500 using the command: \n";
      print "\n\$ groupmod -g 500 tango\n\n";
      print "Then you can rerun this script again...\n\n";
      $causeToExit = 1;      
   }
   else
   {
      print "Group: tango already created with id: 500\n";
      $tangoGroupDone = 1;
   }

}

if  ( defined ($GroupIdByName{"operator"})) 
{
   if ($GroupIdByName{"operator"} ne "501")
   {
      print "Group with name:operator is already defined with id: ".$GroupIdByName{"operator"} . "!\n";
      print "It is recomended that the group: operator has the id: 501 ! \n";
      
      print "Please change the group: operator to use the id: 501 using the command: \n";
      print "\n\$ groupmod -g 501 operator\n\n";
      print "Then you can rerun this script again...\n\n";
      $causeToExit = 1;      
   }
   else
   {
      print "Group: operator already created with id: 501\n";
      $opearatorGroupDone = 1;
   }
}

if  ( defined ($GroupIdByName{"readonly"})) 
{
   if ($GroupIdByName{"readonly"} ne "502")
   {
      print "Group with name:readonly is already defined with id: ".$GroupIdByName{"readonly"} . "!\n";
      print "It is recomended that the group: readonly has the id: 502 ! \n";
      
      print "Please change the group:readonly to use the id: 502 using the command : \n";
      print "\n\$ groupmod -g 502 readonly\n\n";
      print "Then you can rerun this script again...\n\n";
      $causeToExit = 1;      
   }
   else
   {
      print "Group: readonly already created with id: 502\n";
      $readonlyGroupDone  = 1;
   }
}
exit(-1) if ($causeToExit);
# Now we can safely create the groups :tango with id:500 , operator with id:501 and readonly with id:502
if (! $tangoGroupDone)
{
   print "Creating group: tango using command: $groupAddCmd -g 500 tango \n ";
   &doSystemCall("$groupAddCmd -g 500 tango");
}
if (! $opearatorGroupDone)
{
   print "Creating group: operator using command: $groupAddCmd -g 501 operator \n ";
   &doSystemCall("$groupAddCmd -g 501 operator") ;
}
if (! $readonlyGroupDone)
{
   print "Creating group: readonly using command: $groupAddCmd -g 502 readonly \n ";
   &doSystemCall("$groupAddCmd -g 502 readonly");   
}


# if (! ( -d $tangoHomeDir))      # this is done by useradd
# {
#     &doSystemCall("$mkdirCmd  $tangoHomeDir");
#     &doSystemCall("$chmodCmd 0770 $tangoHomeDir");
# }

print "###########################################################################\n";
print "#    2. Checking /etc/passwd file                                         #\n";
print "###########################################################################\n";

if ((defined ($UserIdByName{"tango"})) )
{
    if ($UserIdByName{"tango"} ne "500")
    {
       print "User: tango already exists , but the uid is now: ".$UserIdByName{"tango"}. "\n";
       print "It is recomended that the tango uid is 500 ! \n";
       if (defined ($UsernameById{"500"}))
       {
          print "Another account: ".$UsernameById{"500"}." is using uid 500 !\n";
          print "If you are aware of the consequences change the uid of this account using the command : \n";
          print "\n\$ usermod -u <newid> " .$UsernameById{"500"} ."\n\n";
          print "Then you will be able to change the tango user to use the uid: 500 using command : \n";
          print "\n\$ usermod -u 500 tango\n\n";
          print "Then you will probably not need to run this script again ...\n\n";
          exit(-1);
       }
       else  # tango user is defined but not with uid = 500, there is nobody else with uid 500 
       {
          print "You will be able to change the tango user to use the uid: 500 using command : \n";
          print "\n\$ usermod -u 500 tango\n\n";
          print "Then you will probably not need to run this script again ...\n\n";
          exit(-1);
       }
    }
    else   # tango user already created with uid:500
    {
        print "User: tango already created with this record: \n";
        my ($username,$ignore,$uid,$gid,$description,$homeDir,$shell) = split (/:/, $UserLine{"tango"});
        print "name:        tango\n";
        print "uid:         $uid\n";
        print "gid:         $gid\n";
        print "description: $description\n";
        print "homedir:     $homeDir\n";
        print "shell:       $shell\n";
        print "\n\nYou can change the password with the command : passwd tango\n";
        $tangoUserDone = 1;
    }   
}
else # tango user not yet defined
{
       if (defined ($UsernameById{"500"}))
       {
          print "Another account: ".$UsernameById{"500"}." is using uid 500 !\n";
          print "If you are aware of the consequences change the uid of this account using the command : \n";
          print "\n\$ usermod -u <newid> " .$UsernameById{"500"} ."\n\n";
          print "Then you can rerun this script again...\n\n";
          exit(-1);
       }
}      

if (! $tangoUserDone)
{
   &doSystemCall("$userAddCmd -c \"Tango Maintenance Account\" -d $tangoHomeDir -g tango -G operator,readonly -s /bin/bash -u 500 tango");
   &doSystemCall("$chownCmd -R tango:tango $tangoHomeDir");     # this is prob not neccessary
   print "\n\n[INS_tangoSetup] Please set the password for user: tango. Use command: passwd tango\n\n";
}

# Set the home directory ownerships 

&doSystemCall ("$chownCmd tango:readonly  /tango");

print "###########################################################################\n";
print "#    3. Creating directories                                              #\n";
print "###########################################################################\n";

my @logDirs   = ("/tango/logs", "/tango/logs/aeh", "/tango/logs/stats", "/tango/logs/process");

my @dataDirs  = ("/tango/data","/tango/data/cdr", "/tango/data/scripts");

my $dir = "";
foreach $dir (@logDirs)
{
   &doSystemCall ("$mkdirCmd $dir");
	&doSystemCall ("$chmodCmd 0770 $dir");
	&doSystemCall ("$chownCmd tango:readonly $dir");
   
}

foreach $dir (@dataDirs)
{
   &doSystemCall ("$mkdirCmd $dir");
	&doSystemCall ("$chmodCmd 0770 $dir");
	&doSystemCall ("$chownCmd tango:operator $dir");
   
}
# I am not sure here, but as the scripts are often generating the reports it is better to move them to /tango/data partition
if (! (-d "/tango/scripts")) 
{
   &doSystemCall ("$lnCmd /tango/data/scripts /tango/scripts");                                                     
}

# Add the install directory. The installation scripts must be added to this
# by hand.

&doSystemCall ("$mkdirCmd /tango/data/install");
&doSystemCall ("$chownCmd tango:tango /tango/data/install");
&doSystemCall ("$chmodCmd 0770 /tango/data/install");
if (! (-d "/tango/install")) 
{
   &doSystemCall ("$lnCmd /tango/data/install /tango/install");                                                     
}




exit (0); 


sub doSystemCall
{
    my $systemCommand = shift;
    print "Exec: $systemCommand\n";
    my $returnCode = system( $systemCommand );
    if ( $returnCode != 0 ) 
    { 
        die "Failed executing [$systemCommand]\n"; 
    }
}
