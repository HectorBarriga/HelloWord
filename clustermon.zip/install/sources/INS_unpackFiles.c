/****************************************************************************
 * Filename:    INS_unpackFiles.c
 * Revision:    $Revision: 1.2 $
 * Author:      Jack Downey
 *
 * This "C" program calls a script to un-tar the distribution files and
 * make sure the permissions on these files are correct. The reason that
 * a "C" program is required is to allow us set the effective user ID to
 * "root". This is required because it is planned to invoke this remotely
 * using "rsh".
 *
 * (c) Tango Telecom 2002
 * The information contained in this file is Confidential and Proprietary
 * and is not to be disclosed to any third party without the prior written
 * agreement of Tango Telecom.
 *
 ****************************************************************************
 */


/*
 * Standard includes
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <errno.h>
#include <string.h>

/*
 * Local includes
 */
#include "tango.h"

/****************************************************************************
 * #defines, enums and typedefs
 ****************************************************************************
 */

#define COMMAND_LENGTH		80

/****************************************************************************
 * Prototypes for private functions
 ****************************************************************************
 */


/****************************************************************************
 * Private data
 ****************************************************************************
 */

static const char * version =
       "Tango Telecom: INS_unpackFiles; "__FILE__
       "; $Revision: 1.2 $; "__TIME__", "__DATE__;



/****************************************************************************
 * Public functions
 ****************************************************************************
 */

/**
 *---------------------------------------------------------------------------
 * main
 *
 * This checks to see if our effective user ID is root (UID == 0). If it is,
 * we invoke the script that actually does the work.
 *
 * Returns:     T_OK on success
 *		T_FAIL on error
 *
 *---------------------------------------------------------------------------
 */

int	main	(int	argc,
		 char	**argv)
	{
	char	command [COMMAND_LENGTH];


	/* Make sure we get the names of the bin & config tar files */

	if (argc != 3)
		{
		fprintf (stderr, 
			 "usage : INS_unpackFiles bin-tar-file-name "
			 "config-tar-file-name\n");
		return T_FAIL;
		}


# ifdef DEBUG

	printf ("[INS_unpackFiles] Called\n\n");
	printf ("\tBin tar file \t\t: %s\n", argv [1]);
	printf ("\tConfig tar file \t: %s\n\n", argv [2]);

# endif


	/* Is our effective user ID root? */

	if (geteuid () != 0)
		{
		fprintf (stderr,
			 "[INS_unpackFiles] Must have root permission\n");
		return T_FAIL;
		}


	/* We have to adopt root as our real user ID */

	if (setuid (0) != 0)
		{
		fprintf (stderr,
			 "[INS_unpackFiles] Failed to set root permission\n");
		return T_FAIL;
		}


	/* As root, we may now invoke the unpacking script */

	sprintf (command,
		 "/tango/install/INS_unpackScript %s %s",
		 argv [1],
		 argv [2]);

	if (system (command) == -1)
		{
		fprintf (stderr,
			 "[INS_unpackFiles] Can't run the unpacking script\n");
		return T_FAIL;
		}


# ifdef DEBUG
	printf ("[INS_unpackFiles] Returning\n\n");
# endif

	return T_OK;
	}
