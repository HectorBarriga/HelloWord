/****************************************************************************
 * Filename:    INS_unpackSMI.c
 * Revision:    $Revision: 1.2 $
 * Author:      Jack Downey
 *
 * This "C" program calls a script to un-tar the SMI files and
 * copy the CGI files to their correct location. The reason that
 * a "C" program is required is to allow us set the effective user ID to
 * "root". This is required because it is planned to invoke this remotely
 * using "rsh".
 *
 * (c) Tango Telecom 2002
 * The information contained in this file is Confidential and Proprietary
 * and is not to be disclosed to any third party without the prior written
 * agreement of Tango Telecom.
 *
 ****************************************************************************
 */


/*
 * Standard includes
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <errno.h>
#include <string.h>

/*
 * Local includes
 */
#include "tango.h"

/****************************************************************************
 * #defines, enums and typedefs
 ****************************************************************************
 */

#define COMMAND_LENGTH		80

/****************************************************************************
 * Prototypes for private functions
 ****************************************************************************
 */


/****************************************************************************
 * Private data
 ****************************************************************************
 */

static const char * version =
       "Tango Telecom: INS_unpackSMI; "__FILE__
       "; $Revision: 1.2 $; "__TIME__", "__DATE__;



/****************************************************************************
 * Public functions
 ****************************************************************************
 */

/**
 *---------------------------------------------------------------------------
 * main
 *
 * This checks to see if our effective user ID is root (UID == 0). If it is,
 * we invoke the script that actually does the work.
 *
 * Returns:     T_OK on success
 *		T_FAIL on error
 *
 *---------------------------------------------------------------------------
 */

int	main	(int	argc,
		 char	**argv)
	{
	char	command [COMMAND_LENGTH];


	/* Make sure we get the names of the bin & config tar files */

	if (argc != 3)
		{
		fprintf (stderr, 
			 "usage : INS_unpackFiles SMI-support-tar-file-name "
			 "bin-directory-name\n");
		return T_FAIL;
		}


# ifdef DEBUG

	printf ("[INS_unpackSMI] Called\n\n");
	printf ("\tBin directory name \t: %s\n",     argv [1]);
	printf ("\tSMI support tar file \t: %s\n\n", argv [2]);

# endif


	/* Is our effective user ID root? */

	if (geteuid () != 0)
		{
		fprintf (stderr,
			 "[INS_unpackSMI] Must have root permission\n");
		return T_FAIL;
		}


	if (setuid (0) != 0)
		{
		fprintf (stderr,
			 "[INS_unpackSMI] Failed to set root permission\n");
		return T_FAIL;
		}


	/* As root, we may now invoke the unpacking script */

	sprintf (command,
		 "/tango/install/INS_unpackSmiScript %s %s",
		 argv [1],
		 argv [2]);

	if (system (command) == -1)
		{
		fprintf (stderr,
			 "[INS_unpackSMI] Can't run the unpacking script\n");
		return T_FAIL;
		}


# ifdef DEBUG
	printf ("[INS_unpackSMI] Returning\n\n");
# endif

	return T_OK;
	}
