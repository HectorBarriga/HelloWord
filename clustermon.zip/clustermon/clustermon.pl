#!/usr/bin/perl
##############################################################################
# Filename:    clustermon.pl
# Revision:    $Revision: 3.10
# Author:      MH
#
# This perl script monitors the system cpu usage.
#
# Copyright (c) Tango Telecom 2007
#
# All rights reserved.
# This document contains confidential and proprietary information of
# Tango Telecom and any reproduction, disclosure, or use in whole or
# in part is expressly prohibited, except as may be specifically
# authorized by prior written agreement or permission of Tango Telecom.
# History
# 1.5  with percentage of link usage and change on links
# 1.6  Total Memory of tango processes added
# 1.7  Added apm_ps recognizing number of SPs
# 1.8  with checking previous processes (restarts, mem leaks)
# 1.9  modification of remote copy
# 1.10 adding headers into csv files, comparing old state on links added into changed
# 2.1  remote get, local calculation
# 3.1  modification with ssh and scp
# 3.2  config moved to new file clusterconf.pl , tango mem percent
# 3.3  sshcmdsplit and more stuff added and changed
# 3.4  time handling change (now one timestamp for all nodes)
# 3.5  mps -nr of processes running <4 means Tango restart
# 3.6  config changed into tango config format not perl script
# 3.7  top improve to 1 sec with NrOfToprun=2,  mps command error output to /dev/null
# 3.8  Secure flag, cpu swap, cpu iowait
# 3.9  If one tango process (PM.cfg) restarts (Not the PM) it will tar the pm.logs into $outputdir
# 3.10 Check if the destination folder is not full ; fixed bug with (nodename ne $process[$i][0])
##############################################################################

setpriority(0, 0, 19);
 my $nice = getpriority(0,0);
 if ($nice != 19)
 {
   die "\nFATAL: new nice level: $nice is not the desired one";
 }

use Getopt::Std;
use Sys::Hostname;
use Time::Local;
#use Expect;

# require '/tango/scripts/clusterconf.pl';
$SaveTime = 1;   # If you want to save time choose the Solaris wersion , otherwise comment the next line
$Sol8 = 0; $Sol10 = 0; $LinuxOS = 1;
$Secure = 0;
$WholeTangoRestart = 0;
$AtLeastOneRestarted = 0;
$tarcmd ="/bin/tar";
$gzipcmd="/bin/gzip";
$allowedDiskUsage = 89;

# ===========================================================================
# Main flow...
# ===========================================================================
if ( 0 == getopts( "uhc:f:o:r:n:s:d" ) )
{
    usage();
    exit 0;
}

if ( defined( $opt_u) )
{
    usage();
    exit 0;
}

if ( defined( $opt_h) )
{
    help();
    exit 0;
}

if ( defined( $opt_c ) )
{
    $cfgfile = $opt_c;
}
else   { $cfgfile = "/tango/scripts/monitor.cfg" ;}

$debug = $opt_d if ( defined( $opt_d) );


&loadcfg();
$outputdir  = "/tango/logs/stats/monitor";
$outputdir  = $cfg{"GENERAL"}{"CSVSTOREDIR"} if (defined ($cfg{"GENERAL"}{"CSVSTOREDIR"}));
@RemNodes   = split /,/ , $cfg{"GENERAL"}{"HOSTS"} ;
$passwd     = $cfg{"GENERAL"}{"SSHPASSWD"} ;
$port       = $cfg{"GENERAL"}{"SSHPORT"} ;
$packHour   = $cfg{"GENERAL"}{"PACKAGEHOUR"} ;
$packMin    = $cfg{"GENERAL"}{"PACKAGEMINUTE"} ;
$Days2Keep  = $cfg{"GENERAL"}{"DAYSTOKEEP"} ;


if (defined( $opt_n))
{
   @RemNodes   = split /,/ , $opt_n ;
}

my $s  = ",";
my $rmode   = 0;
$s     = $opt_s if ( defined( $opt_s) );
$rmode   = int($opt_r) if ( defined( $opt_r) );
if ( defined( $opt_f) )
{
   $outputdir = $opt_f;
}
$outputdir =~ s/\/$//;  # remove trailing slash
$CPUHeader = "#___Date$s"."Time$s"."CPUidle$s"."AllTangoUserCPU$s"."AllTangoUserMemory$s"."CPUuser$s"."CPUkernel$s".
             "TotalMemory$s"."FreeMemory$s"."FreeMemoryPercent$s"."SwapTotal$s"."SwapUsed$s"."SwapFree$s"."SwapUsedPercent$s".
             "SwapFreePercent$s"."AllTangoMemoryPercent$s"."AllTangoProcessesFromPMcfgCPU$s"."AllTangoProcessesFromPMcfgMemory$s".
             "CPUiowait$s"."CPUswap$s\n";

$DISKUSAGEHeader = "#___Date$s"."Time$s"."root_kbytes_used_avail$s"."usr_kbytes_used_avail$s"."tmp_kbytes_used_avail$s".
                   "tangodata_kbytes_used_avail$s"."tangologs_kbytes_used_avail$s\n";

$TANGOPROCHeader = "#___Date$s"."Time$s"."ProcessNr$s"."RunningOnNode$s"."UnixId$s"."SEPortNr$s"."ProcessMemory$s"."ProcessCPU$s".
                   "ProcessBinary$s"."ProcessDescription$s"."ProcessState$s"."RestartFlag$s"."MemoryEvolution$s"."CPUEvolution$s".
                   "PMinstance$s\n";

$LNKHeader = "#___Date$s"."Time$s"."MML$s"."LinkName$s"."LinkSet$s"."SLC$s"."ACT$s"."LOADED$s"."AVL$s"."State$s"."TxOctets$s"."RxOctets$s".
             "TxLoadPercent$s"."RxLoadPercent$s"."Changed$s\n";

$pendingPercent = 99;
@duArr = `/bin/df -k $outputdir`;

$lastLine = $duArr[@duArr -1];
if ($lastLine =~ /(\d+)\%/)
{
 $pendingPercent = int ($1);
}

if ( $pendingPercent > $allowedDiskUsage)
{
   print "Error: Cannot create files: Disk at $pendingDir is ocupied with $pendingPercent\% and is more then allowed: $allowedDiskUsage\% !!!\n";
}
else
{
   &main();
}




exit(0);

sub main()
{
  $diskcmd    = "/bin/df -k";
  `mkdir -p $outputdir`;
#  $hostname=`cat /etc/nodename`;
  $hostname=`/bin/hostname`;
  $hostname =~ s/\n//g;

  @dates = getTime(0);
  $date = "$dates[3]/$dates[4]/$dates[5]$s$dates[2]:$dates[1]:$dates[0]";
  my $thishour= int($dates[2]);
  my $thismin = int($dates[1]);
  $willdohousekeeping = 0;

  if (($thishour == $packHour) && ($thismin == $packMin))
  {
      $willdohousekeeping = 1;
      `rm -rf $outputdir/FTPtemp/* `;
  }

  foreach $nodename (@RemNodes)
  {
      $nrOfTopRun = 2;           # we need more runs to see the node cpu idle total
      $cpufile    = "$outputdir/cpumon_";
      $procfile   = "$outputdir/prcmon_";
      $dskfile    = "$outputdir/dskmon_";
      $linksfile  = "$outputdir/lnkmon_";

      @TempA = split /_/, $nodename;
      $nodename = $TempA[0];
      $ss7node =  ($TempA[1] eq "ss7" );
      $LocalNode = 0;
      if ($hostname eq $nodename) {$LocalNode = 1;}
      print "================================\nWorking on node :$nodename \n" if ($debug);
      if (! $SaveTime)
      {
          my $OSVersion = "";
          if ($LocalNode) {  $OSVersion=`uname -a`;}
          else            {  $OSVersion= &sshcmd("uname -a");}
          if($OSVersion =~ m/^linux/i) {
            $LinuxOS = 1;
          }
          if ($LocalNode) {  $SolVersion=`uname -r`;}
          else            {  $SolVersion= &sshcmd("uname -r");}
          if ($SolVersion =~ /5.10/) { $Sol8 = 0; $Sol10 = 1;}
          if ($SolVersion =~ /5.8/)  { $Sol8 = 1; $Sol10 = 0;}
      }
      if ($Sol8) { $topcommand = "/usr/local/bin/top";}
      if ($Sol10){ $topcommand = "/opt/sfw/bin/top";  }
#      if ($LinuxOS) { $topcommand = "/usr/bin/top"; }
      if ($LinuxOS) { $topcommand = "/usr/local/bin/top"; }
      if ((! $Sol8 ) && (! $Sol10) && (! $LinuxOS )) {die "Error : Unsupported system $SolVersion\n";}
      if ($LocalNode)
      {
         $topVersion = `$topcommand \-v 2>\&1 `;
      }
      else
      {
         $topVersion = &sshcmd("$topcommand \-v 2>\&1 ");
      }
      if($topVersion =~ m/top: .*version(\s+)([0-9\.]+)/i)
      {
        $topVersion = $2;
      }
      $topVersion =~ s/\n//g;
      $topVersion =~ s/\s//g;
      print "top version is : $topVersion ####\n" if ($debug);
      if ($topVersion eq "" ) { die "Error : Cannot recognize top version \! n";}
      if( $LinuxOS && ($topVersion eq "3.2.8") ) {
#        print STDERR "topVersion = $topVersion\n"; exit 1;
        $topcommand = $topcommand . " -n $nrOfTopRun -b";
#        print STDERR "topcommand = $topcommand\n"; exit 1;
      }
      else {
        if  ( ($topVersion ne "3.5beta12.5") && ($topVersion ne "3.5.1") && ($topVersion ne "3.5")  )
       {
          die "Error : Not supported top version : $topVersion \! \n";
        }
        $topcommand = $topcommand . " -d $nrOfTopRun -s 1 -b 1000";
      }
#print STDERR "topcommand = $topcommand\n";#&&&&&
  #    @dates = getTime(0);
  #    $date = "$dates[3]/$dates[4]/$dates[5]$s$dates[2]:$dates[1]:$dates[0]";

      if ($rmode > 0) {returnProcessesNcpu();}
      if ($rmode > 1) {returnDiskUsage();}
      if ($willdohousekeeping) {  &HouseKeepingClean(); }
  }

}


sub returnDiskUsage
{

   if ($LocalNode) {  @dsktango=`$diskcmd`;}
   else            {  @dsktango= &sshcmdsplit("$diskcmd");}

   foreach (@dsktango)
   {
      $_ .=  " ";
      if (/([a-zA-Z0-9\/]+)(\s*)(\d+)(\s+)(\d+)(\s+)(\d+)(\s+)(\d+)%(\s+)\/(\s+)/)
      {
         $root = "root\_$3\_$5\_$7\_$9";
      }
      if (/([a-zA-Z0-9\/]+)(\s*)(\d+)(\s+)(\d+)(\s+)(\d+)(\s+)(\d+)%(\s+)\/usr(\s+)/)
      {
         $usr = "usr\_$3\_$5\_$7\_$9";
      }
      if (/([a-zA-Z0-9\/]+)(\s*)(\d+)(\s+)(\d+)(\s+)(\d+)(\s+)(\d+)%(\s+)\/tmp(\s+)/)
      {
         $tmp = "tmp\_$3\_$5\_$7\_$9";
      }
      if (/([a-zA-Z0-9\/]+)(\s*)(\d+)(\s+)(\d+)(\s+)(\d+)(\s+)(\d+)%(\s+)\/tango\/data(\s+)/)
      {
         $tdata = "tangodata\_$3\_$5\_$7\_$9";
      }
      if (/([a-zA-Z0-9\/]+)(\s*)(\d+)(\s+)(\d+)(\s+)(\d+)(\s+)(\d+)%(\s+)\/tango\/logs(\s+)/)
      {
         $tlogs = "tangologs\_$3\_$5\_$7\_$9";
      }

   }

#   my @dates = getTime(0);
#   my $date = "$dates[3]/$dates[4]/$dates[5],$dates[2]:$dates[1]:$dates[0]";


   $dskfile .= "$nodename\_$dates[5]$dates[4]$dates[3].csv";
   if($debug)
   {
      print "$date,$root,$usr,$tmp,$tdata,$tlogs,\n";
   }
   else
   {
      if(open(FILEDSK,"$dskfile"))
      {
         close(FILEDSK);
         open(FILEDSK,">>$dskfile");
         print FILEDSK "$date,$root,$usr,$tmp,$tdata,$tlogs,\n";
         close(FILEDSK);
      }
      else
      {
         open(FILEDSK,">>$dskfile");
         print FILEDSK "$DISKUSAGEHeader";
         print FILEDSK "$date,$root,$usr,$tmp,$tdata,$tlogs,\n";
         close(FILEDSK);
      }
   }
}

sub returnProcessesNcpu
{
   my $nr = 0;
   my $PMrunning = 0;
   my @process = ();
   $#process = -1;

   $timestampNOW = "$dates[5]$dates[4]$dates[3]$dates[2]$dates[1]$dates[0]";
   $procfile .= "$nodename\_" ;

   $lastPrcFile = `ls $procfile*.csv 2>/dev/null | tail -1`;
   $lastPrcFile =~ s /\n//;
   if ($lastPrcFile ne "")
   {
       $tl = `tail -1 $lastPrcFile 2>/dev/null | cut -c1-19`;
       $tl =~ s /\n//;
   }
   if ($tl ne "")
   {
       @oldProcesses = `/bin/grep \"$tl\" $lastPrcFile`;
       foreach $oprc (@oldProcesses)
       {
#09/02/2007,00:00:00,3,smslinkA,445,11000,0K,0.00,/tango/bin/DB_server,SMI Database Server (Active),Running,
#09/02/2007,00:00:00,4,smslinkB,435,12010,9792K,0.00,/tango/bin/SMI_systemStatus,System Status,Running,

           @OP = split /,/, $oprc;
           $OProcs{$OP[2]}{1} = $OP[4];   # unix id
           $OProcs{$OP[2]}{2} = $OP[5];   # tango port
           $OProcs{$OP[2]}{3} = &KiloMegaGigaDecode($OP[6]);   # memory
           $OProcs{$OP[2]}{4} = $OP[7];   # cpu
       }
       #27/01/2007,16:40:01
       $tl =~ s/(\d)(\d)\/(\d)(\d)\/(\d)(\d)(\d)(\d),(\d)(\d):(\d)(\d):(\d)(\d)/$5$6$7$8$3$4$1$2$9$10$11$12$13$14/;
       $dfsec = &diffSeconds($tl,$timestampNOW);
   }
   else
   {
       $dfsec = 0;
   }
   print "Proceses: Last run was before : $dfsec seconds.\n" if ($debug);

   $nrToDelete = 0;
   $#mymps = -1;
   $#toptango = -1;
   $#PMfile = -1;
#print STDERR "LocalNode=$LocalNode\n";#&&&&&
#print STDERR "topcommand=$topcommand\n";#&&&&&
   if ($LocalNode)
   {
      @mymps=`/tango/bin/mps 2>>/dev/null`;
      @toptango=`$topcommand`;
      @PMfile = `cat /tango/config/PM.cfg`;
   }
   else
   {
      @mymps= &sshcmdsplit("/tango/bin/mps 2>>/dev/null");
 #     $temp1 = &sshcmd("$topcommand");
      @toptango= &sshcmdsplit("$topcommand");
      @PMfile = &sshcmdsplit("cat /tango/config/PM.cfg");
   }
   foreach (@toptango)
   {
      if (/load average(s)?:/)
      {
         $nrOfTopRun = $nrOfTopRun -1;
      }
      if ($nrOfTopRun > 0)
      {
        $nrToDelete++;
      }
   }
#print "#toptango = $#toptango\n"; #&&&&&
#print "nrToDelete = $nrToDelete\n";#&&&&&
   for ($i=0; $i<$nrToDelete; $i++)
   {
      shift (@toptango);
   }
   $lastnr = 0;

#Index   Status          Host    PID     Port    Program
#--------------------------------------------------------------------------------
#1.      Running         gtangoD 435     10111   Cluster Resource Manager
#2.      Running         gtangoD 436     10112   Host Resource Manager

   $chr9 = chr(9);
   foreach $mpsLineStr (@mymps)
   {
      @mpsArr = split /$chr9/, $mpsLineStr;
      if ( @mpsArr != 6)
      {
         next;
      }
      $mpsArr[0] =~ s/(\d+)\./$1/;
      $nr = int ($1);
      if ($nr <= 0)
      {
         next;
      }
      $process[$nr][0] = $mpsArr[2] ;
      $process[$nr][1] = $mpsArr[3] ;
      $process[$nr][7] = $mpsArr[1] ;
   }
   $lastnr= $nr;
   if ($lastnr == 0) {$WholeTangoRestart = 1;}
   $inprocess = 0;
   foreach (@PMfile)
   {
      if (/^\[Process(\s+)(\d+)\]/i)
      {  $inprocess = 1;
         $pmnr = $2;
      }
      if (($inprocess) && (/Description(\s*)=(\s*)(.*)/i))
      {
         $process[$pmnr][6] = $3;
         $process[$pmnr][6] =~ s/,/;/g;
      }
      if (($inprocess) && (/Class Name(\s*)=(\s*)(.*)/i))
      {
         $tempinst = $3;
         @instArr = split /\// , $tempinst;
         $instIsNr = ($instArr[1] =~ /(\d+)/);
         if ($instIsNr)
         {
            $process[$pmnr][8] = int ($instArr[1]);
         }
         else
         {
            $process[$pmnr][8] = -1;
         }
      }
      if (($inprocess) && (/Process(\s+)Path(\s*)=(\s*)(.*)/i))
      {
         $process[$pmnr][5] = $4;
      }
      if (($inprocess) && (/Port(\s*)=(\s*)(\d+)/i))
      {
         $process[$pmnr][2] = $3;
         $inprocess = 0;
      }
   }
   my $ALLTANGOCPUcal2  = 0;
   my $ALLTANGOMEMcal2  = 0;
#print "#toptango: \"", $#toptango, "\"\n"; #&&&&&
   foreach (@toptango)
   {
      if(($LinuxOS) &&
      (/^(\s*)(\d+)(\s+)(\w+)(\s+)(\d+)(\s+)(\d+)(\s+)([a-zA-Z0-9\.]+)(\s+)([a-zA-Z0-9\.]+)(\s+)([a-zA-Z0-9\.]+)(\s+)([a-zA-Z0-9\.]+)(\s+)([a-zA-Z0-9\.]+)(\s+)([a-zA-Z0-9\.]+)(\s+)([a-zA-Z0-9\.\:]+)(\s+)(.*)/)
        )
      {
#         PID USER      PR  NI  VIRT  RES  SHR S %CPU %MEM    TIME+  COMMAND
#       63110 tango     20   0 15692 1896  836 R  7.3  0.0   0:00.08 top
# RES  --  Resident size (kb)
#          The non-swapped physical memory a task has used.
#          RES = CODE + DATA.
# VIRT  --  Virtual Image (kb)
#          The  total  amount  of  virtual memory used by the task.  It includes all code, data and shared libraries plus pages that have been
#          swapped out. (Note: you can define the STATSIZE=1 environment variable and the VIRT  will  be  calculated  from  the  /proc/#/state
#          VmSize field.)
#          VIRT = SWAP + RES
# SHR  --  Shared Mem size (kb)
#          The amount of shared memory used by a task.  It simply reflects memory that could be potentially shared with other processes.
# CODE  --  Code size (kb)
#          The amount of physical memory devoted to executable code, also known as the .text resident set. size or TRS.
# DATA  --  Data+Stack size (kb)
#          The amount of physical memory devoted to other than executable code, also known as the .data resident set. size or DRS.
# SWAP  --  Swapped size (kb)
#          The swapped out portion of a task.s total virtual memory image.
         $pid = $2;
         $username = $4;
         $mem = $10; # $12;
         $cpu = $18; # $22;
         $cmd = $24;
         $cmd =~ s/(\s|\n)+$//;
         if ($username eq "tango")
         {
             $ALLTANGOCPUcal2  += $cpu;
             $ALLTANGOMEMcal2  += &KiloMegaGigaDecode($mem);
         }
         for ($i=1;$i <= $lastnr; $i++)
         {
                   if ($process[$i][1] eq $pid )
             {
                $process[$i][3] = $mem;
                $process[$i][4] = $cpu;
             }
         }
         # Special handling for pm process
#         if ($cmd eq "pm")
         if(($username eq "tango")&&($cmd =~ m/^\s*pm/))
         {
                  $process[0][0] = $nodename;
            $process[0][1] = $pid;
            $process[0][2] = 10100;
            $process[0][3] = $mem;
            $process[0][4] = $cpu;
            $process[0][5] = "/tango/bin/pm";
            $process[0][6] = "Tango Process Manager";
            $process[0][7] = "Running";
            $process[0][8] = "0";
            $PMrunning     = 1;
         }

      }
      if  (($topVersion eq "3.5beta12.5") &&
      (/(\s*)(\d+)(\s+)(\w+)(\s+)(\d+)(\s+)(\d+)(\s+)(\d+)(\s+)([A-Z0-9\.]+)(\s+)([A-Z0-9\.]+)(\s+)([a-zA-Z0-9\/]+)(\s+)([A-Z0-9\.\:]+)(\s+)(\d+)(\s+)([0-9\.]+)%(\s+)(.*)/)
          )
      {
         $pid = $2;
         $username = $4;
         $mem = $12;
         $cpu = $22; $cmd = $24;
         if ($username eq "tango")
         {
             $ALLTANGOCPUcal2  += $cpu;
             $ALLTANGOMEMcal2  += &KiloMegaGigaDecode($mem);
         }
         for ($i=1;$i <= $lastnr; $i++)
         {   if ($process[$i][1] eq $pid )
             {
                $process[$i][3] = $mem;
                $process[$i][4] = $cpu;
             }
         }
         # Special handling for pm process
         if ($cmd eq "pm")
         {  $process[0][0] = $nodename;
            $process[0][1] = $pid;
            $process[0][2] = 10100;
            $process[0][3] = $mem;
            $process[0][4] = $cpu;
            $process[0][5] = "/tango/bin/pm";
            $process[0][6] = "Tango Process Manager";
            $process[0][7] = "Running";
            $process[0][8] = "0";
            $PMrunning     = 1;
         }
      }
      if ( (($topVersion eq "3.5.1") || ($topVersion eq "3.5")) &&
      (/(\s*)(\d+)(\s+)(\w+)(\s+)(\d+)(\s+)(\d+)(\s+)(\d+)(\s+)([A-Z0-9\.]+)(\s+)([A-Z0-9\.]+)(\s+)([a-zA-Z0-9\/]+)(\s+)([A-Z0-9\.\:]+)(\s+)([0-9\.]+)%(\s+)(.*)/)
         )
      {
         $pid = $2;
         $username = $4;
         $mem = $12;
         $cpu = $20; $cmd = $22;
         if ($username eq "tango")
         {
             $ALLTANGOCPUcal2  += $cpu;
             $ALLTANGOMEMcal2  += &KiloMegaGigaDecode($mem);
         }
         for ($i=1;$i <= $lastnr; $i++)
         {   if ($process[$i][1] eq $pid )
             {
                $process[$i][3] = $mem;
                $process[$i][4] = $cpu;
             }
         }
         # Special handling for pm process
         if ($cmd eq "pm")
         {  $process[0][0] = $nodename;
            $process[0][1] = $pid;
            $process[0][2] = 10100;
            $process[0][3] = $mem;
            $process[0][4] = $cpu;
            $process[0][5] = "/tango/bin/pm";
            $process[0][6] = "Tango Process Manager";
            $process[0][7] = "Running";
            $process[0][8] = "0";
            $PMrunning     = 1;
         }
      }
   }
   if (!($PMrunning ))
   {
      $process[0][0] = $nodename;
      $process[0][1] = "0";
      $process[0][2] = 10100;
      $process[0][3] = "0K";
      $process[0][4] = "0.00";
      $process[0][5] = "/tango/bin/pm";
      $process[0][6] = "Tango Process Manager";
      $process[0][7] = "Not running";
      $process[0][8] = "-1";
   }
   for ($i=1;$i <= $lastnr; $i++)
   {   if (uc($process[$i][0]) ne uc($nodename))
       {
          $process[$i][3] = "0K";
          $process[$i][4] = "0.00";
       }
   }

   my $ALLTANGOCPU  = 0;
   my $ALLTANGOMEM  = 0;
   $procfile  .= "$dates[5]$dates[4]$dates[3].csv";
   if (! $debug)
   {
      if (open(FILEPRC,"$procfile"))
      {
         close(FILEPRC);
         open(FILEPRC,">>$procfile") || die "Error adding a line into $procfile\n";
      }
      else
      {
         open(FILEPRC,">>$procfile") || die "Error adding a line into $procfile\n";
         print FILEPRC "$TANGOPROCHeader";
      }
   }
   if ($WholeTangoRestart)
   {
       $output = "$date$s$i,";
       for ($j=0;$j<8;$j++)
       {
          $output .= "$process[0][$j]$s";
       }
       $output .= "1$s" ;     #restart flag
       $output .= "0.00$s" ;  #percent memory change
       $output .= "0.00$s" ;  #percent cpu  change
       $output .= "-1$s\n" ;  #PM instance
       if($debug) { print $output ;}
       else
       {
          print FILEPRC $output;
       }
   }
   else
   {
       for ($i=0;$i <= $lastnr; $i++)
       {
             $output = "$date$s$i,";
             for ($j=0;$j<8;$j++)
             {
                $output .= "$process[$i][$j]$s";
             }
             $decmem = &KiloMegaGigaDecode($process[$i][3]);
             if (($process[$i][2]) == ($OProcs{$i}{2}))
             {
                if ($process[$i][1] eq $OProcs{$i}{1})
                {
                    $output .= "0$s";  # 1 for process restart, 0 for no change
                }
                else
                {
                    $output .= "1$s";  # 1 for process restart, 0 for no change
                    if ($i != 0) {$AtLeastOneRestarted = 1;}
                }
                if ($OProcs{$i}{3} != 0)
                {
                   $permemch  = ($decmem - $OProcs{$i}{3}) / ($OProcs{$i}{3} / 100);
                   $permemch = sprintf("%.2f",$permemch );
                }
                else
                {
                   $permemch = 0;
                }
                $output .= "$permemch$s";
                $percpuch = $process[$i][4] - $OProcs{$i}{4};
                $percpuch = sprintf("%.2f",$percpuch);
                $output .= "$percpuch$s";
             }
             else  # if the number of tango process is the same, but not the port => are not the same process
             {
                $output .= "0$s"."0$s"."0$s";

             }
             $output .= "$process[$i][8]$s\n";
             if($debug) { print $output ;}
             else
             {
                print FILEPRC $output;
             }
             $ALLTANGOCPU += $process[$i][4];
             $ALLTANGOMEM += $decmem;
       }
   }
   close(PM);
   close(FILEPRC);

   print " --------------------------- TOTALS ------------------------- \n" if ($debug);

   my @CPUstates = ();
   my @mem = ();
   my @swapSpace = ();
   if($LinuxOS) {
     @CPUstates = split /,/,$toptango[2];
     # Cpu(s):  0.3%us,  0.1%sy,  0.0%ni, 99.6%id,  0.0%wa,  0.0%hi,  0.0%si,  0.0%st
     # us: user cpu time
                 # sy: system cpu time
     # ni: user nice cpu time
     # id: idle cpu time
     # wa: io wait cpu time
     # hi: hardware irq (servicing hardware interrupts)
     # si: software irq (servicing software interrupts)
     # st: steal time (time in involuntary wait by virtual cpu while hypervisor is servicing another processor)
     $CPUstates[3] =~ s/^\s*([0-9\.]+)\%\s*id/$1/;
     $cpuidle = $CPUstates[3];
     @mem = split /,/,$toptango[3];
     $CPUstates[0] =~ s/^[^\:]*\:\s*([0-9\.]+)\%\s*us/$1/;
     $cpuuser = $1;
     $CPUstates[1] =~ s/^\s*([0-9\.]+)\%\s*sy/$1/;
     $cpukernel = $1;
     $CPUstates[4] =~ s/^\s*([0-9\.]+)\%\s*wa/$1/;
     $cpuiowait=$1;
     $CPUstates[4] =~ s/^\s*([0-9\.]+)\%\s*hi/$1/;
     $cpuswap=$1;

     @mem = split /,/,$toptango[3];
     # Mem:  65937196k total, 14754032k used, 51183164k free,   674900k buffers
     $mem[0] =~ s/Mem\:(\s+)([0-9\.]+)(M|K|G)(\s+)total/$2$3/i;
     $mem[0] = uc $mem[0];
     $totalmem = $mem[0];
     $mem[2] =~ s/(\s+)([0-9\.]+)(M|K|G)(\s+)free/$2$3/i;
     $mem[2] = uc $mem[2];
     $freemem = $mem[2];
     $totalmemdec = &KiloMegaGigaDecode($totalmem);
     $freememdec  = &KiloMegaGigaDecode($freemem);

     # apply alternative memory command as the "top" command under Linux does not provide adequate results for process oriented monitoring
     my $alternateMemCmd = `free -m`; # see also "vmstat -s -S M | egrep 'mem|swap'"
     if($alternateMemCmd =~ m/cache\:\s*(\d+)/) {
         my $usedMem = $1; # in MBytes
         my $usedMemDec = &KiloMegaGigaDecode($usedMem . 'M');
         $freememdec = $totalmemdec - $usedMemDec;
         $freemem = int($freememdec / 1048576) . 'M';
     }


     @swapSpace = split /,/,$toptango[4];
     # Swap: 32767992k total,        0k used, 32767992k free,  4934260k cached
     $swapSpace[1]=~ s/(\s+)([0-9\.]+)(M|K|G)(\s+)used/$2$3/i;
     $swapSpace[1] = uc $swapSpace[1];
     $swapinuse = $swapSpace[1];
     $swapinusedec = &KiloMegaGigaDecode($swapinuse);
     $swapSpace[2]=~ s/(\s+)([0-9\.]+)(M|K|G)(\s+)free/$2$3/i;
     $swapSpace[2]=~ s/\n//g;
     $swapSpace[2] = uc $swapSpace[2];
     $swapfree=$swapSpace[2];
     $swapfreedec = &KiloMegaGigaDecode($swapfree);
     $swaptotal = $swapinusedec + $swapfreedec;
   }
   else {
     @CPUstates = split /,/,$toptango[2];
     @mem = split /,/,$toptango[3];
     #CPU states: 48.3% idle, 50.4% user,  1.3% kernel,  0.0% iowait,  0.0% swap
     $CPUstates[0] =~ s/CPU states:(\s+)([0-9\.]+)\%(\s+)idle/$2/;
     $cpuidle = $CPUstates[0];
     $CPUstates[1] =~ s/(\s+)([0-9\.]+)\%(\s+)user/$2/;
     $cpuuser = $CPUstates[1];
     $CPUstates[2] =~ s/(\s+)([0-9\.]+)\%(\s+)kernel/$2/;
     $cpukernel = $CPUstates[2];
     $CPUstates[3]=~ s/(\d+.\d)/$1/;
     $cpuiowait=$1;
     $CPUstates[4]=~ s/(\d+.\d)/$1/;
     $cpuswap=$1;
     $mem[0] =~ s/Memory:(\s+)([0-9\.]+)(M|K|G)(\s+)real/$2$3/;
     $totalmem = $mem[0];
     $mem[1] =~ s/(\s+)([0-9\.]+)(M|K|G)(\s+)free/$2$3/;
     $freemem = $mem[1];
     $totalmemdec = &KiloMegaGigaDecode($totalmem);
     $freememdec  = &KiloMegaGigaDecode($freemem);
     $mem[2]=~ s/(\s+)([0-9\.]+)(M|K|G)(\s+)swap in use/$2$3/;
     $swapinuse = $mem[2];
     $swapinusedec = &KiloMegaGigaDecode($swapinuse);
     $mem[3]=~ s/(\s+)([0-9\.]+)(M|K|G)(\s+)swap free/$2$3/;
     $mem[3]=~ s/\n//g;
     $swapfree=$mem[3];
     $swapfreedec = &KiloMegaGigaDecode($swapfree);
     $swaptotal = $swapinusedec + $swapfreedec;
   }
   if ($totalmemdec > 0)
   {
      if ($freememdec > 0)      {  $freememper = $freememdec / ($totalmemdec /100);}
      if ($ALLTANGOMEMcal2 > 0) {  $tangomemper = $ALLTANGOMEMcal2 / ($totalmemdec /100);}
   }
   else
   {
      $freememper = 0;
      $tangomemper = 0;
   }
   $tangomemper = sprintf("%.2f",$tangomemper);
   $freememper =  sprintf("%.2f",$freememper);
   if (($swapfreedec > 0) && ($swaptotal >0))
   {
      $swapfreeper = $swapfreedec / ($swaptotal /100);
      $swapusedper = 100 - $swapfreeper;
   }
   else
   {
      $swapfreeper = 0;
      $swapusedper = 100;
   }
   $swaptotal = &Encode2Giga ($swaptotal);
   $swapfreeper = sprintf("%.2f",$swapfreeper);
   $swapusedper = sprintf("%.2f",$swapusedper);

   $cpufile .= "$nodename\_$dates[5]$dates[4]$dates[3].csv";
   $ALLTANGOMEM = &Encode2Mega($ALLTANGOMEM);
   $ALLTANGOMEMcal2 = &Encode2Mega($ALLTANGOMEMcal2);
#25/03/2007,02:06:12,95.1,    1.95,  543.0M,       2.3,   2.6,          2048M,         964M,         47.07,
# 5.4G,   625M,    4885M,   11.34,   88.66,   26.513671875,   2.08,609.2M,
#25/03/2007,02:35:18,87.4,    10.09, 1717.3M,      7.3,   5.4,         2048M,           60M,      2.93 ,
# 5.3G,  1815M,    3646M,   33.24,   66.76,   83.85,           9.08,   1309.0M,
   $cpumemstr = "$date$s$cpuidle$s$ALLTANGOCPUcal2$s$ALLTANGOMEMcal2$s$cpuuser$s$cpukernel$s$totalmem$s$freemem$s$freememper$s".
            "$swaptotal$s$swapinuse$s$swapfree$s$swapusedper$s$swapfreeper$s$tangomemper$s$ALLTANGOCPU$s$ALLTANGOMEM$s".
            "$cpuiowait$s$cpuswap$s\n";
   if ($debug)
   {
      print "$cpumemstr";
   }
   else
   {
      if (open(FILECPU,"$cpufile"))
      {
         close(FILECPU);
         open(FILECPU,">>$cpufile") || die "Error adding a line into $cpufile\n";
         print FILECPU "$cpumemstr";
         close(FILECPU);
      }
      else
      {
         open(FILECPU,">>$cpufile")  || die "Error adding a line into $cpufile\n";
         print FILECPU "$CPUHeader";
         print FILECPU "$cpumemstr";
         close(FILECPU);
      }
   }
#   if ($AtLeastOneRestarted)
#   {
#      `$tarcmd cvf $outputdir/pm_logs_$timestampNOW\.tar /tango/logs/process/pm.*`;
#   }
}

sub HouseKeepingClean
{

  my $thishour= int($dates[2]);
  my $thismin = int($dates[1]);
  my @ydates = getTime(86400);
  my $prevday = "$ydates[5]$ydates[4]$ydates[3]";

  $preparecmd = "mkdir -p $outputdir/FTPtemp/; mkdir -p $outputdir/zip/; cp $outputdir/*$nodename\_$prevday.csv $outputdir/FTPtemp/";
  $tarandzip = "cd $outputdir/FTPtemp/; $tarcmd cvf clustermon\_$nodename\_$prevday.tar *.csv ;$gzipcmd clustermon\_$nodename\_$prevday.tar";
  $postproccmd = "cp $outputdir/FTPtemp/*$prevday.tar.gz $outputdir/zip/; rm -rf $outputdir/FTPtemp/*.csv";
  $cleancmd="/bin/find $outputdir -type f -mtime +$Days2Keep -exec /bin/rm -f {} \\;";

  `$preparecmd`;
  `$tarandzip`;
  `$postproccmd`;
  `$cleancmd`;


}

sub KiloMegaGigaDecode
{
   my $lstr = $_[0];
   my $last = (length($lstr)) - 1;
   my $number = substr ($lstr,0,$last);
   my $lch    = substr ($lstr,$last,1);
   $notDecoded = 1;
   if ($lch eq "G")
   {
      $number = 1073741824 * $number;
      $notDecoded = 0;
   }
   if ($lch eq "M")
   {
      $number = 1048576 * $number;
      $notDecoded = 0;
   }
   if ($lch eq "K")
   {
      $number = 1024 * $number;
      $notDecoded = 0;
   }
   if ($notDecoded)
   {
      return $lstr;
   }
   else
   {
      return $number;
   }
}

sub Encode2Mega
{
   my $nr = 0;
   $nr = $_[0] / 1048576;
   $nrstr = sprintf ("%.1f" , $nr);
   $nrstr = $nrstr . "M";
   return $nrstr;
}
sub Encode2Giga
{
   my $nr = $_[0];
   if ($nr >0)
   {
      $nr = $_[0] / 1073741824;
   }
   else {  $nr = 0;}

   $nrstr = sprintf ("%.1f" , $nr);
   $nrstr = $nrstr . "G";
   return $nrstr;
}
sub diffSeconds
{
   my $Aval = $_[0];
   my $Bval = $_[1];
   $Ayear= int (substr ($Aval,0,4));
   $Ayear= $Ayear - 1900;
   $Amon = int (substr ($Aval,4,2)) ;
   $Amon = $Amon -1;
   $Aday = int (substr ($Aval,6,2));
   $Ahour= int (substr ($Aval,8,2));
   $Amin = int (substr ($Aval,10,2));
   $Asec = int (substr ($Aval,12,2));

   $Byear= int (substr ($Bval,0,4));
   $Byear= $Byear - 1900;
   $Bmon = int (substr ($Bval,4,2));
   $Bmon = $Bmon -1;
   $Bday = int (substr ($Bval,6,2));
   $Bhour= int (substr ($Bval,8,2));
   $Bmin = int (substr ($Bval,10,2));
   $Bsec = int (substr ($Bval,12,2));

   $Atime = timelocal($Asec,$Amin,$Ahour,$Aday,$Amon,$Ayear);
   $Btime = timelocal($Bsec,$Bmin,$Bhour,$Bday,$Bmon,$Byear);
   return ($Btime - $Atime);
}

sub previousValue
{
   $cval = $_[0];
   $mindiffer = $_[1];

   $cyear= int (substr ($cval,0,4));
   $cmon = int (substr ($cval,4,2));
   $cday = int (substr ($cval,6,2));
   $chour= int (substr ($cval,8,2));
   $cmin = int (substr ($cval,10,2));

   $pyear=$cyear;
   $pmon=$cmon;
   $pday=$cday;
   $phour=$chour;
   if ($cmin == 0)
   {
      $pmin = 60 - $mindiffer;
      if ($chour == 0)
      {
         $phour = 23;
         if ($cday == 1)
         {
            if ($cmon == 1)  {$pmon = 12; $pday = 31; $pyear = $cyear -1;}
            if ($cmon == 2)  {$pmon = 1;  $pday = 31;}
            if ($cmon == 3)
            {
               $pmon = 2;
               if (( $cyear == 2008 ) || ( $cyear == 2012 ) || ( $cyear == 2016 ) || ( $cyear == 2020 ) || ( $cyear == 2024 )  ||
                   ( $cyear == 2028 ) || ( $cyear == 2032 ) || ( $cyear == 2036 ) || ( $cyear == 2040 ) || ( $cyear == 2044 ))
               {
                  $pday = 29;
               }
               else {$pday = 28;}
            }
            if ($cmon == 4)  {$pmon = 3;  $pday = 31;}
            if ($cmon == 5)  {$pmon = 4;  $pday = 30;}
            if ($cmon == 6)  {$pmon = 5;  $pday = 31;}
            if ($cmon == 7)  {$pmon = 6;  $pday = 30;}
            if ($cmon == 8)  {$pmon = 7;  $pday = 31;}
            if ($cmon == 9)  {$pmon = 8;  $pday = 31;}
            if ($cmon == 10) {$pmon = 9;  $pday = 30;}
            if ($cmon == 11)  {$pmon = 10;$pday = 31;}
            if ($cmon == 12)  {$pmon = 11;$pday = 30;}
         }
         else
         {
            $pday = $cday -1;
         }
      }
      else
      {
         $phour = $chour - 1;
      }
   }
   else
   {
      $pmin = $cmin - $mindiffer;
   }
   $pmonstr = "$pmon";
   if ($pmon < 10)
   {
      $pmonstr = "0$pmon";
   }
   $pdaystr = "$pday";
   if ($pday <10)
   {
      $pdaystr = "0$pday";
   }
   $phourstr = "$phour";
   if ($phour<10)
   {
      $phourstr = "0$phour";
   }
   $pminstr = "$pmin";
   if ($pmin<10)
   {
      $pminstr = "0$pmin";
   }
   $outstr = "$pyear$pmonstr$pdaystr$phourstr$pminstr";
   return ($outstr);
}

#----------------------------------------- DISPLAY HELP FUNCTIONS
sub help
{
print <<EO_HELP;

Help for script cpumon.pl (c) Tango Telecom 2005

This scripts logs the cpu load generating stats in csv format
and logs the disk usage generating stats in csv format.

EO_HELP

    usage();
}
sub usage()
{
 print <<EO_USAGE;

 OPTIONS:

 To diplay the lines only on screen:
 -d

To define the separator:
 -s <,>

Write the files to specific directory
 -f <directory>

Running mode
 -r <mode>
where mode =1 - cpu usage,tango proc info
      mode =2 - cpu usage,tango proc info,disk usage
EO_USAGE
}
sub getTime
{
  $deductSeconds = $_[0];
 ($Second, $Minute, $Hour, $Day, $Month, $Year, $WeekDay, $DayOfYear, $IsDST) = localtime(time - $deductSeconds);

 if($Hour < 10)   {  $Hour = "0" . $Hour ; }
 if($Minute < 10) {  $Minute = "0" . $Minute ; }
 if($Second < 10) {  $Second = "0" . $Second ; }
 my $Month = $Month + 1 ;
 if($Month < 10)
 {
 $Month = "0" .
 $Month ;
 }
 if($Day < 10)
 {
  $Day = "0" . $Day ;
 }
 if($Year >= 100)
 {
  $Year = $Year - 100 ;
  $Year = $Year + 2000;
 }
 return  ($Second, $Minute, $Hour, $Day, $Month, $Year, $WeekDay, $DayOfYear, $IsDST);
}


sub scpcmd
{
   my $result = "";
   my $passwordPrompt = "Password:";
   $localFile = $_[0];
   $remoteFile = $_[1];
   if ($Secure)
   {
       print "Doing scp -oPort=$port $localFile $remoteFile"  if ($debug);
       $command = Expect->spawn("/usr/bin/scp -oPort=$port $localFile $remoteFile") or die "Couldn't start program: !$\n";
       $command->log_stdout(0);
       if ($command->expect(15, "$passwordPrompt"))
       {
          $command->send("$passwd" . "\n");
          if ($command->expect(100,"100\%"))
          {
            $result = $command->exp_before();
          }
       }
       else
       {
          print "Timeout \n"  if ($debug);
          $result = "Password not accepted or timeout !\n";
       }
    }
    else
    {
        `rcp $localFile $remoteFile`;
    }
}


sub sshcmd
{
   my $result = "";
   my $passwordPrompt = "Password:";
   $remoteCmd = $_[0];

   if ($Secure)
   {
      print "Doing /usr/bin/ssh -oPort=$port tango\@$nodename $remoteCmd\n" if ($debug);
      $command = Expect->spawn("/usr/bin/ssh -oPort=$port tango\@$nodename \"$remoteCmd ; echo FINISHINGCOMMAND\" ") or die "Couldn't start program: !$\n";
      $command->log_stdout(0);
      if ($command->expect(15, "$passwordPrompt"))
      {
         $command->send("$passwd" . "\n");
         if ($command->expect(15,"FINISHINGCOMMAND"))
         {
           $result = $command->exp_before();
         }
      }
      else
      {
         print "Timeout \n" if ($debug);
         $result = "Password not accepted or timeout !\n";
      }
      $chr13 = chr(13);
      $result =~ s/$chr13//g;
   }
   else
   {
      $result = `rsh $nodename \"$remoteCmd\"`;
   }
   return $result;
}


sub sshcmdsplit
{
  $cmd = $_[0];
  my $result = &sshcmd("$cmd");
  my @resultArr =  split /\n/, $result;
  return @resultArr;
}

sub loadcfg()
{

    if (! (open(CFG,  "$cfgfile"))) { usage(); exit 0;}
    while ( <CFG> )
    {
       chop;
       if ( /^#/ )
       {
          next;
       }
       if ( /\[[\w\s\/]+\]/ )
       {
          $section = $_;
          $section =~ s/\[([\w\s\/]+)\]/$1/;
       }
       if ( /=/ )
       {
          ( $var, @values ) = split( "=", $_ );
          $val = join( "=", @values );
          $var =~ s/^\s*//;
          $var =~ s/\s*$//;
          $val =~ s/(.*)\#(.*)/$1/;
          $val =~ s/^\s*//;
          $val =~ s/\s*$//;

          $section =~ s/\s//g;   # to remove spaces from section
          $var     =~ s/\s//g;   # to remove spaces from var

          $section = uc($section);
          $var     = uc($var);
          $cfg{$section}{$var} = $val;
          print "<$section><$var> = <$val>\n" if ($debug);
       }
    }
    close( CFG );

}
