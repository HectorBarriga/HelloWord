#!/usr/local/bin/perl
use Net::SCP qw(scp);
use Net::SCP::Expect;
use Expect;
my $scpe = Net::SCP::Expect->new;

$scpe->login('tango', 'comcel123');

$scpe->scp('/tango/scripts/Generic/Others/cpumonGraph/reports/cpu_BCOVENBE1A_y.png','192.168.170.201:/var/apache/htdocs/clustermonGraphs/');
$scpe->scp('/tango/scripts/Generic/Others/cpumonGraph/reports/cpu_BCOVENBE1A_t.png','192.168.170.201:/var/apache/htdocs/clustermonGraphs/');
$scpe->scp('/tango/scripts/Generic/Others/cpumonGraph/reports/cpu_UCOVENBE1A_y.png','192.168.170.201:/var/apache/htdocs/clustermonGraphs/');
$scpe->scp('/tango/scripts/Generic/Others/cpumonGraph/reports/cpu_UCOVENBE1A_t.png','192.168.170.201:/var/apache/htdocs/clustermonGraphs/');
$scpe->scp('/tango/scripts/Generic/Others/cpumonGraph/reports/cpu_UCOVENBE2B_y.png','192.168.170.201:/var/apache/htdocs/clustermonGraphs/');
$scpe->scp('/tango/scripts/Generic/Others/cpumonGraph/reports/cpu_UCOVENBE2B_t.png','192.168.170.201:/var/apache/htdocs/clustermonGraphs/');
$scpe->scp('/tango/scripts/Generic/Others/cpumonGraph/reports/cpu_UCOVENBE3C_y.png','192.168.170.201:/var/apache/htdocs/clustermonGraphs/');
$scpe->scp('/tango/scripts/Generic/Others/cpumonGraph/reports/cpu_UCOVENBE3C_t.png','192.168.170.201:/var/apache/htdocs/clustermonGraphs/');
