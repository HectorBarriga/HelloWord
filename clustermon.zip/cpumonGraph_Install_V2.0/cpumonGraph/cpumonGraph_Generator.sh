#!/bin/bash

while(true)
do
	/bin/nice /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports.sh;
        /usr/local/bin/perl /tango/scripts/Generic/Others/cpumonGraph/Dailycpumon_graph_tangoA_y.pl;
        /usr/local/bin/perl /tango/scripts/Generic/Others/cpumonGraph/Dailycpumon_graph_tangoA_t.pl;
        /usr/local/bin/perl /tango/scripts/Generic/Others/cpumonGraph/Dailycpumon_graph_tangoB_y.pl;
        /usr/local/bin/perl /tango/scripts/Generic/Others/cpumonGraph/Dailycpumon_graph_tangoB_t.pl;
        /usr/local/bin/perl /tango/scripts/Generic/Others/cpumonGraph/Dailycpumon_graph_tangoC_y.pl;
        /usr/local/bin/perl /tango/scripts/Generic/Others/cpumonGraph/Dailycpumon_graph_tangoC_t.pl;
        /usr/local/bin/perl /tango/scripts/Generic/Others/cpumonGraph/Dailycpumon_graph_tangoD_y.pl;
        /usr/local/bin/perl /tango/scripts/Generic/Others/cpumonGraph/Dailycpumon_graph_tangoD_t.pl;
#        /usr/local/bin/perl /tango/scripts/Generic/Others/cpumonGraph/send_ALL_pictures_to_tangoA.pl;
#	/bin/cp /tango/scripts/Generic/Others/cpumonGraph/reports/* /var/apache/htdocs/clustermonGraphs/;
	/bin/cp /tango/scripts/Generic/Others/cpumonGraph/reports/* /var/www/html/cpumonGraphs/;
        sleep 300;
done
