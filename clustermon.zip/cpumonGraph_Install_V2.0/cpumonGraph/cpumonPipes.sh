#!/bin/bash
hostname=$(hostname)

datetime=$( perl -e '@d=localtime time(); printf "%4d%02d%02d%02d%02d%02d\n", $d[5]+1900,$d[4]+1,$d[3],$d[2],$d[1],$d[0]')
now=$( perl -e '@d=localtime time(); printf "%02d:%02d\n", $d[2],$d[1]')
today=$(perl -e '@d=localtime time(); printf "%4d%02d%02d\n", $d[5]+1900,$d[4]+1,$d[3]')
cpumonGraphFile="/tango/logs/stats/monitor/cpumonPipes/cpumonPipes_$hostname""_""$today.txt"
cpumonFixedFile="/tango/logs/stats/monitor/cpumonPipes/cpumonFixed_$today.csv"
if [ "$now" == "00:00" ];then
        cat /tango/logs/stats/monitor/cpumon_*_$today.csv | head -2 > $cpumonFixedFile
else
        cat /tango/logs/stats/monitor/cpumon_*_$today.csv | tail -1 >> $cpumonFixedFile
fi

# ----------CPUidle-----------------
echo "" > $cpumonGraphFile
echo -n "Time  ---------" >> $cpumonGraphFile
for ((i=6;i<=95;i++));do if [ "$i" -eq "45" ];then echo -n " CPU Usage " >> $cpumonGraphFile ;else echo -n "-" >> $cpumonGraphFile;fi;done
echo " 100%" >> $cpumonGraphFile
HHMM=$(cat $cpumonFixedFile | cut -d, -f2 | egrep -v Time | head -1 | awk 'BEGIN{FS=":"}{print $1":"$2}')
cat $cpumonFixedFile | cut -d, -f3 | egrep -v CPUidle | cut -d"." -f1 | while read in
do
        echo -e -n "$HHMM [\e[33m CPU  \e[0m] " >> $cpumonGraphFile
        HHMM=$(date -d "$HHMM 5 minutes" +'%H:%M')
        let CPUidle=100-$in
for ((i=0;i<=$CPUidle;i++));do if [ "$i" -gt "80" ];then echo -e -n "\e[31m+\e[0m" >> $cpumonGraphFile;else echo -e -n "\e[32m|\e[0m" >> $cpumonGraphFile;fi;done
        echo " $CPUidle%" >> $cpumonGraphFile
done
for ((i=0;i<=114;i++));do echo -n "-" >> $cpumonGraphFile;done
echo " 100%" >> $cpumonGraphFile

# ------------FreeMemory---------------
echo "" >> $cpumonGraphFile
echo "" >> $cpumonGraphFile
echo -n "Time  ---------" >> $cpumonGraphFile
for ((i=6;i<=92;i++));do if [ "$i" -eq "44" ];then echo -n " Memory Usage " >> $cpumonGraphFile ;else echo -n "-" >> $cpumonGraphFile;fi;done
echo " 100%" >> $cpumonGraphFile
HHMM=$(cat $cpumonFixedFile | cut -d, -f2 | egrep -v Time | head -1 | awk 'BEGIN{FS=":"}{print $1":"$2}')
cat $cpumonFixedFile | cut -d, -f10 | egrep -v FreeMemory | cut -d"." -f1 | while read in
do
        echo -e -n "$HHMM [\e[33mMEMORY\e[0m] " >> $cpumonGraphFile
        HHMM=$(date -d "$HHMM 5 minutes" +'%H:%M')
        let Memoryidle=100-$in
for ((i=0;i<=$Memoryidle;i++));do if [ "$i" -gt "80" ];then echo -e -n "\e[31m+\e[0m" >> $cpumonGraphFile;else echo -e -n "\e[32m|\e[0m" >> $cpumonGraphFile;fi;done
        echo " $Memoryidle%" >> $cpumonGraphFile
done
for ((i=0;i<=114;i++));do echo -n "-" >> $cpumonGraphFile;done
echo " 100%" >> $cpumonGraphFile