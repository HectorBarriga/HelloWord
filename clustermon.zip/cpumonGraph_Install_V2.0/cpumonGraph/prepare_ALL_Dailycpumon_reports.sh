#!/bin/bash

ext_t=`date +%y%m%d`
ext_y=$((ext_t-1));

#################### Gather clustermon cpudmon reports ####################
/bin/rm -f /tango/scripts/Generic/Others/cpumonGraph/ALL_Dailycpumon_Remote_reports/*.csv

/bin/cp /tango/logs/stats/monitor/*$ext_t*.csv /tango/scripts/Generic/Others/cpumonGraph/ALL_Dailycpumon_Remote_reports/
/bin/cp /tango/logs/stats/monitor/*$ext_y*.csv /tango/scripts/Generic/Others/cpumonGraph/ALL_Dailycpumon_Remote_reports/
/bin/scp tango@tangoB:/tango/logs/stats/monitor/*$ext_t*.csv /tango/scripts/Generic/Others/cpumonGraph/ALL_Dailycpumon_Remote_reports/;
/bin/scp tango@tangoB:/tango/logs/stats/monitor/*$ext_y*.csv /tango/scripts/Generic/Others/cpumonGraph/ALL_Dailycpumon_Remote_reports/;
/bin/scp tango@tangoC:/tango/logs/stats/monitor/*$ext_t*.csv /tango/scripts/Generic/Others/cpumonGraph/ALL_Dailycpumon_Remote_reports/;
/bin/scp tango@tangoC:/tango/logs/stats/monitor/*$ext_y*.csv /tango/scripts/Generic/Others/cpumonGraph/ALL_Dailycpumon_Remote_reports/;
/bin/scp tango@tangoD:/tango/logs/stats/monitor/*$ext_t*.csv /tango/scripts/Generic/Others/cpumonGraph/ALL_Dailycpumon_Remote_reports/;
/bin/scp tango@tangoD:/tango/logs/stats/monitor/*$ext_y*.csv /tango/scripts/Generic/Others/cpumonGraph/ALL_Dailycpumon_Remote_reports/;

############tangoA yesterday################

/bin/rm -f /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3sub.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10sub.txt

/bin/sed '1d' /tango/scripts/Generic/Others/cpumonGraph/ALL_Dailycpumon_Remote_reports/cpumon_tangoA_20$ext_y.csv | cut -d, -f3 > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3.txt
/bin/sed '1d' /tango/scripts/Generic/Others/cpumonGraph/ALL_Dailycpumon_Remote_reports/cpumon_tangoA_20$ext_y.csv | cut -d, -f10 > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10.txt
perl /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/scalarSubsf3.pl > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3sub.txt
perl /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/scalarSubsf10.pl > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10sub.txt
paste -d","  /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/time.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3sub.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10sub.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/threshold.txt > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/cpumon_tangoA_prepared_y.txt


############tangoA today####################

/bin/rm -f /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3sub.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10sub.txt

/bin/sed '1d' /tango/scripts/Generic/Others/cpumonGraph/ALL_Dailycpumon_Remote_reports/cpumon_tangoA_20$ext_t.csv | cut -d, -f3 > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3.txt
/bin/sed '1d' /tango/scripts/Generic/Others/cpumonGraph/ALL_Dailycpumon_Remote_reports/cpumon_tangoA_20$ext_t.csv | cut -d, -f10 > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10.txt
perl /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/scalarSubsf3.pl > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3sub.txt
perl /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/scalarSubsf10.pl > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10sub.txt
paste -d","  /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/time.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3sub.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10sub.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/threshold.txt > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/cpumon_tangoA_prepared_t.txt

############tangoB yesterday################

/bin/rm -f /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3sub.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10sub.txt

/bin/sed '1d' /tango/scripts/Generic/Others/cpumonGraph/ALL_Dailycpumon_Remote_reports/cpumon_tangoB_20$ext_y.csv | cut -d, -f3 > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3.txt
/bin/sed '1d' /tango/scripts/Generic/Others/cpumonGraph/ALL_Dailycpumon_Remote_reports/cpumon_tangoB_20$ext_y.csv | cut -d, -f10 > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10.txt
perl /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/scalarSubsf3.pl > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3sub.txt
perl /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/scalarSubsf10.pl > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10sub.txt
paste -d","  /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/time.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3sub.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10sub.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/threshold.txt > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/cpumon_tangoB_prepared_y.txt


############tangoB today####################

/bin/rm -f /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3sub.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10sub.txt

/bin/sed '1d' /tango/scripts/Generic/Others/cpumonGraph/ALL_Dailycpumon_Remote_reports/cpumon_tangoB_20$ext_t.csv | cut -d, -f3 > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3.txt
/bin/sed '1d' /tango/scripts/Generic/Others/cpumonGraph/ALL_Dailycpumon_Remote_reports/cpumon_tangoB_20$ext_t.csv | cut -d, -f10 > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10.txt
perl /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/scalarSubsf3.pl > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3sub.txt
perl /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/scalarSubsf10.pl > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10sub.txt
paste -d","  /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/time.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3sub.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10sub.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/threshold.txt > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/cpumon_tangoB_prepared_t.txt


############tangoC yesterday################

/bin/rm -f /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3sub.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10sub.txt

/bin/sed '1d' /tango/scripts/Generic/Others/cpumonGraph/ALL_Dailycpumon_Remote_reports/cpumon_tangoC_20$ext_y.csv | cut -d, -f3 > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3.txt
/bin/sed '1d' /tango/scripts/Generic/Others/cpumonGraph/ALL_Dailycpumon_Remote_reports/cpumon_tangoC_20$ext_y.csv | cut -d, -f10 > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10.txt
perl /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/scalarSubsf3.pl > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3sub.txt
perl /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/scalarSubsf10.pl > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10sub.txt
paste -d","  /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/time.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3sub.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10sub.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/threshold.txt > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/cpumon_tangoC_prepared_y.txt


############tangoC today####################

/bin/rm -f /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3sub.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10sub.txt

/bin/sed '1d' /tango/scripts/Generic/Others/cpumonGraph/ALL_Dailycpumon_Remote_reports/cpumon_tangoC_20$ext_t.csv | cut -d, -f3 > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3.txt
/bin/sed '1d' /tango/scripts/Generic/Others/cpumonGraph/ALL_Dailycpumon_Remote_reports/cpumon_tangoC_20$ext_t.csv | cut -d, -f10 > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10.txt
perl /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/scalarSubsf3.pl > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3sub.txt
perl /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/scalarSubsf10.pl > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10sub.txt
paste -d","  /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/time.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3sub.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10sub.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/threshold.txt > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/cpumon_tangoC_prepared_t.txt


############tangoD yesterday################

/bin/rm -f /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3sub.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10sub.txt

/bin/sed '1d' /tango/scripts/Generic/Others/cpumonGraph/ALL_Dailycpumon_Remote_reports/cpumon_tangoD_20$ext_y.csv | cut -d, -f3 > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3.txt
/bin/sed '1d' /tango/scripts/Generic/Others/cpumonGraph/ALL_Dailycpumon_Remote_reports/cpumon_tangoD_20$ext_y.csv | cut -d, -f10 > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10.txt
perl /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/scalarSubsf3.pl > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3sub.txt
perl /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/scalarSubsf10.pl > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10sub.txt
paste -d","  /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/time.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3sub.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10sub.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/threshold.txt > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/cpumon_tangoD_prepared_y.txt


############tangoD today####################

/bin/rm -f /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3sub.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10sub.txt

/bin/sed '1d' /tango/scripts/Generic/Others/cpumonGraph/ALL_Dailycpumon_Remote_reports/cpumon_tangoD_20$ext_t.csv | cut -d, -f3 > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3.txt
/bin/sed '1d' /tango/scripts/Generic/Others/cpumonGraph/ALL_Dailycpumon_Remote_reports/cpumon_tangoD_20$ext_t.csv | cut -d, -f10 > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10.txt
perl /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/scalarSubsf3.pl > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3sub.txt
perl /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/scalarSubsf10.pl > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10sub.txt
paste -d","  /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/time.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f3sub.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10sub.txt /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/threshold.txt > /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/cpumon_tangoD_prepared_t.txt
