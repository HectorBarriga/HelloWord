#!/usr/local/bin/perl

use strict;
use warnings;
use CGI qw( :standard );
use GD::Graph::lines;


#my $ext=`date '+%y%m%d_%H%M%S'`;

open my $fh, '<', '/tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/cpumon_tangoD_prepared_t.txt' or die $!;
my (@w, @x, @y, @z);
while (<$fh>) {
   next if $. == 1;            # skip header line
   push @w, (split /,/)[0];   # push 'Time every 5 mins' into @w array
   push @x, (split /,/)[1];   # push 'Memory Usage' into @x array
   push @y, (split /,/)[2];   # push 'Threshold' into @y array
   push @z, (split /,/)[3];   # push 'Threshold' into @z array
}
close $fh;



# Read in the data from a file

my $mygraph = GD::Graph::lines->new(600, 300);
$mygraph->set(
    x_label     => 'TIME EVERY 5 Minutes',
    y_label     => '% USAGE',
    title       => "CLUSTERMON CPU USAGE",
    # Draw datasets in 'solid', 'dashed' and 'dotted-dashed' lines
    line_types  => [1, 1, 2],
    # Set the thickness of line
    line_width  => 4,
    # Set colors for datasets
    dclrs       => ['blue', 'purple', 'red'],
) or warn $mygraph->error;

$mygraph->set_legend_font(GD::gdMediumBoldFont);
$mygraph->set_legend('CPU','Memory', 'Threshold 80%');
my @data = (\@w, \@x, \@y, \@z);
my $myimage = $mygraph->plot(\@data) or die $mygraph->error();


# Open a file for writing
open(PICTURE, ">/tango/scripts/Generic/Others/cpumonGraph/reports/cpu_tangoD_t.png") or die("Cannot open file for writing");
#open(PICTURE, ">/tango/scripts/Generic/Others/cpumonGraph/reports/archive/cpu_tangoD_t.png_$ext") or die("Cannot open file for writing");

# Make sure we are writing to a binary stream
binmode PICTURE;

# Add .png to filename
print PICTURE $myimage->png;
close PICTURE;
