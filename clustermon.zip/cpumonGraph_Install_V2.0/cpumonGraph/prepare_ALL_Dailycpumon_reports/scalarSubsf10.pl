@allFile = `cat /tango/scripts/Generic/Others/cpumonGraph/prepare_ALL_Dailycpumon_reports/f10.txt`;
my $scalar= 100;
foreach(@allFile){
my $num = eval sprintf('%.3f', 100-$_);
print $num . "\n";
}
