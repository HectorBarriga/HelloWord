CREATE DATABASE  IF NOT EXISTS `settings_database` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `setting_database`;
-- MySQL dump 10.13  Distrib 5.6.13, for osx10.6 (i386)
--
-- Host: 127.0.0.1    Database: web_customer_tracker
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer`
--

I





-- Dumping data for table `customer`
--

/*LOCK TABLES `customer` WRITE;*/
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;



CREATE DATABASE  IF NOT EXISTS `settings_database` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `settings_database`;

DROP TABLE IF EXISTS `command_setting`;
CREATE TABLE `command_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `test_name` varchar(255) NOT NULL,
  `search_word` varchar(45) DEFAULT NULL,
   `expected` boolean DEFAULT NULL,
    `info`varchar(255)DEFAULT NULL,
      `modify_date` TIMESTAMP default Now(),
       `severity` int (11) DEFAULT NULL,
         `cluster_id` int(11) NOT NULL,
         `machine_id` int(11) NOT NULL,
     PRIMARY KEY (`id`),
     FOREIGN KEY (cluster_id) REFERENCES cluster(id) ON DELETE CASCADE ON UPDATE CASCADE,
      FOREIGN KEY (machine_id) REFERENCES machine(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS command_setting;
CREATE TABLE command_setting (
  id serial NOT NULL,
  test_name varchar(255) NOT NULL,
  search_word varchar(45) DEFAULT NULL,
   expected boolean DEFAULT NULL,
    info varchar(255)DEFAULT NULL,
      modify_date TIMESTAMP default Now(),
       severity integer DEFAULT NULL,
         cluster_id integer NOT NULL,
         machine_id integer NOT NULL,
     PRIMARY KEY (id),
     FOREIGN KEY (cluster_id) REFERENCES cluster(id) ON DELETE CASCADE ON UPDATE CASCADE,
      FOREIGN KEY (machine_id) REFERENCES machine(id) ON DELETE CASCADE ON UPDATE CASCADE
); AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;
DROP TABLE IF EXISTS `command_result`;
	CREATE TABLE `command_result` (
	`id` int (11) NOT NULL AUTO_INCREMENT,
	 `command_setting_id` int(11) NOT NULL,
	`command_output` varchar (800) DEFAULT NULL,
	`status_ok` boolean DEFAULT NULL,
	 `modify_date` TIMESTAMP default Now(),
	`severity` int(11) DEFAULT NULL,
	PRIMARY KEY (`id`),
	FOREIGN KEY (command_setting_id) REFERENCES command_setting(id) ON DELETE CASCADE ON UPDATE CASCADE
	) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `setting`;
CREATE TABLE `setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `test_name` varchar(255) NOT NULL,
  `api_url` varchar(255) NOT NULL,
  `search_word` varchar(45) DEFAULT NULL,
   `expected` boolean DEFAULT NULL,
    `info`varchar(255)DEFAULT NULL,
     `curl` varchar(255) NOT NULL,
      `modify_date` TIMESTAMP default Now(),
       `severity` int (11) DEFAULT NULL,
         `cluster_id` int(11) NOT NULL,
     PRIMARY KEY (`id`),
     FOREIGN KEY (cluster_id) REFERENCES cluster(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;
   


CREATE TABLE `cluster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cluster_name` varchar(45) NOT NULL,
     PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

CREATE TABLE cluster (
  id serial NOT NULL,
  cluster_name varchar(45) NOT NULL,
     PRIMARY KEY (id)
); ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

CREATE TABLE `machine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(45) NOT NULL,
  `cluster_id` int(11) NOT NULL,
     PRIMARY KEY (`id`),
       FOREIGN KEY (cluster_id) REFERENCES cluster(id) ON DELETE CASCADE ON UPDATE CASCADE
     
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

CREATE TABLE machine (
  id serial NOT NULL,
  machine_name varchar(45) NOT NULL,
  cluster_id integer NOT NULL,
     PRIMARY KEY (id),
       FOREIGN KEY (cluster_id) REFERENCES cluster(id) ON DELETE CASCADE ON UPDATE CASCADE
     
); ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;
CREATE TABLE `kibana` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dashboard_name` varchar(100) NOT NULL,
  `dashboard_frame` varchar(1000),
     PRIMARY KEY (`id`)    
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;




DROP TABLE IF EXISTS `severity`;
CREATE TABLE `severity` (
	`id` int (11) NOT NULL AUTO_INCREMENT,
	`severity` varchar (35) NOT NULL,
	PRIMARY KEY (`id`)
	) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;
	
DROP TABLE IF EXISTS `command`;
CREATE TABLE `command` (
	`id` int (11) NOT NULL AUTO_INCREMENT,
	 `command_setting_id` int(11) NOT NULL,
	 `command` varchar (500),
	 `directory` varchar (100),
	PRIMARY KEY (`id`),
	FOREIGN KEY (command_setting_id) REFERENCES command_setting(id) ON DELETE CASCADE
	) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `basic_auth`;
CREATE TABLE `basic_auth` (
	`id` int (11) NOT NULL AUTO_INCREMENT,
	 `setting_id` int(11) NOT NULL,
	`username_` varchar (35) NOT NULL,
	`password_` varchar (35) NOT NULL,
	PRIMARY KEY (`id`),
	FOREIGN KEY (setting_id) REFERENCES setting(id) ON DELETE CASCADE
	) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;
	
	DROP TABLE IF EXISTS `result`;
	CREATE TABLE `result` (
	`id` int (11) NOT NULL AUTO_INCREMENT,
	 `setting_id` int(11) NOT NULL,
	`json` varchar (800) DEFAULT NULL,
	`status_ok` boolean DEFAULT NULL,
	 `modify_date` TIMESTAMP default Now(),
	`severity` int(11) DEFAULT NULL,
	PRIMARY KEY (`id`),
	FOREIGN KEY (setting_id) REFERENCES setting(id) ON DELETE CASCADE ON UPDATE CASCADE
	) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;
    
DROP TABLE IF EXISTS `header`;
CREATE TABLE `header` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_id` int(11) NOT NULL,
  `header_key` varchar(45) NOT NULL,
  `header_value` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
    FOREIGN KEY (setting_id) REFERENCES setting(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;






SELECT CONSTRAINT_NAME FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
    -> WHERE TABLE_NAME='header';
ALTER TABLE `setting`
ADD FOREIGN KEY (result_id) REFERENCES Result(id);  
	

/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-09-24 21:50:59
