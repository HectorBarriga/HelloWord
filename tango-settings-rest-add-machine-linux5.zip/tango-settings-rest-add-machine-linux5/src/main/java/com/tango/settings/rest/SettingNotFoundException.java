package com.tango.settings.rest;

public class SettingNotFoundException extends RuntimeException {

	public SettingNotFoundException() {
	}

	public SettingNotFoundException(String message) {
		super(message);
	}

	public SettingNotFoundException(Throwable cause) {
		super(cause);
	}

	public SettingNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}

	public SettingNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
