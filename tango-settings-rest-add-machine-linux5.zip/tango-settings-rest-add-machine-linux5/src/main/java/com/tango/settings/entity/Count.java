package com.tango.settings.entity;

public class Count {

	private long countOK;

	private long countWarning;

	private long countAlert;

	private long info;

	public Count() {
		super();
	}

	public long getCountOK() {
		return countOK;
	}

	public void setCountOK(long countOK) {
		this.countOK = countOK;
	}

	public long getCountWarning() {
		return countWarning;
	}

	public void setCountWarning(long countWarning) {
		this.countWarning = countWarning;
	}

	public long getCountAlert() {
		return countAlert;
	}

	public void setCountAlert(long countAlert) {
		this.countAlert = countAlert;
	}

	public long getInfo() {
		return info;
	}

	public void setInfo(long info) {
		this.info = info;
	}

}
