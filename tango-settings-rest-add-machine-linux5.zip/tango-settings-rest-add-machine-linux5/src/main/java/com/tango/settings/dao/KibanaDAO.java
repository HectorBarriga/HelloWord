package com.tango.settings.dao;

import java.util.List;
import java.util.Set;

import com.tango.settings.entity.Cluster;
import com.tango.settings.entity.Kibana;
import com.tango.settings.entity.Setting;

public interface KibanaDAO {
	
	public List<Kibana> getDashboards();

	public void saveDashboard(Kibana theKibana);

	public Kibana getDashboard(int theId);

	public void deleteDashboard(int theId);
	
	public void updateDashboard(Kibana theDashboard);

	
}
