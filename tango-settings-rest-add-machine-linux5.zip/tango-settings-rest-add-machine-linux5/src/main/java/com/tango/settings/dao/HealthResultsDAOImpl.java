package com.tango.settings.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tango.settings.entity.HealthResult;
import com.tango.settings.entity.Count;
import com.tango.settings.entity.Result;
import com.tango.settings.entity.Setting;

@Repository
public class HealthResultsDAOImpl implements HealthResultsDAO {
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void saveResult(HealthResult theResult) {
		Session currentSession = sessionFactory.getCurrentSession();

		currentSession.saveOrUpdate(theResult);

	}

	@Override
	public void updateResult(HealthResult theResult, int theId) {

		// get current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();

		Query theQuery = currentSession.createQuery("delete from HealthResult where health_setting_id=:settingId");

		theQuery.setParameter("settingId", theId);

		theQuery.executeUpdate();

		currentSession.saveOrUpdate(theResult);

	}

	@Override
	public Count countOk() {

		Count count = new Count();

		Session currentSession = sessionFactory.getCurrentSession();

		long countOk = (long) currentSession.createQuery("SELECT COUNT(*) FROM HealthResult where status_ok=true")
				.getSingleResult();

		long countWarning = (long) currentSession
				.createQuery("SELECT COUNT(*) FROM HealthResult where status_ok=false AND severity=3")
				.getSingleResult();

		long countAlert = (long) currentSession
				.createQuery("SELECT COUNT(*) FROM HealthResult where status_ok=false AND severity=2")
				.getSingleResult();

		long countInfo = (long) currentSession
				.createQuery("SELECT COUNT(*) FROM HealthResult where status_ok=false AND severity=1")
				.getSingleResult();

		count.setCountOK(countOk);
		count.setCountWarning(countWarning);
		count.setCountAlert(countAlert);
		count.setInfo(countInfo);

		return count;

	}

}
