package com.tango.settings.dao;

import java.util.List;
import java.util.Set;

import com.tango.settings.entity.Cluster;
import com.tango.settings.entity.Count;
import com.tango.settings.entity.Header;
import com.tango.settings.entity.Setting;

public interface SettingDAO {

//	public List<Setting> getSettings(int clusterId);

	public void saveSetting(Setting theCustomer);

	public Setting getSetting(int theId);

	public void deleteSetting(int theId);
	
	public void updateSetting(Setting theCustomer);

	List<Setting> getSettings(Cluster cluster);

	List<Setting> getSettings();

	List<Setting> getSettings(int cluster);

	Count getSettingsCount(int cluster);

	List<Setting> getSettingsMachine(int machine);

	Count getSettingsCountCluster(int cluster);

	int getRecentSetting();
}
