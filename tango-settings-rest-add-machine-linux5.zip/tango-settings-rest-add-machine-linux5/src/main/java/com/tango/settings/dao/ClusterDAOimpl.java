package com.tango.settings.dao;

import java.util.List;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tango.settings.entity.Cluster;
import com.tango.settings.entity.Setting;


@Repository
public class ClusterDAOimpl implements ClusterDAO{
	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public List<Cluster> getClusters() {
		// get the current hibernate session
				Session currentSession = sessionFactory.getCurrentSession();
						
				// create a query
				Query<Cluster> theQuery = 
						currentSession.createQuery("from Cluster",
													Cluster.class);
				
				// execute query and get result list
				List<Cluster> clusters = theQuery.getResultList();
						
				// return the results		
				return clusters;
	}

	@Override
	public void saveCluster(Cluster theCluster) {
		// get current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();
	
		currentSession.saveOrUpdate(theCluster);
		
	}

	@Override
	public Cluster getCluster(int theId) {
		// get the current hibernate session
				Session currentSession = sessionFactory.getCurrentSession();
				
				// now retrieve/read from database using the primary key
				Cluster theCluster = currentSession.get(Cluster.class, theId);
				
				return theCluster;
	}

	@Override
	public void deleteCluster(int theId) {
		// get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();
		
		// delete object
		Query theQuery = 
				currentSession.createQuery("delete from Cluster where id=:clusterId");
		theQuery.setParameter("clusterId", theId);
		theQuery.executeUpdate();	
	
	}

	@Override
	public void updateCluster(Cluster theCluster) {
		// get current hibernate session
				Session currentSession = sessionFactory.getCurrentSession();
				int theId = theCluster.getId();
				currentSession.saveOrUpdate(theCluster);
				currentSession.persist(theCluster);
		
	}
	
	@Override
	public Cluster getClusterCount(int theId) {
		// get the current hibernate session
				Session currentSession = sessionFactory.getCurrentSession();
				// now retrieve/read from database using the primary key
				Cluster theCluster = currentSession.get(Cluster.class, theId);
				
				return theCluster;
	}

}
