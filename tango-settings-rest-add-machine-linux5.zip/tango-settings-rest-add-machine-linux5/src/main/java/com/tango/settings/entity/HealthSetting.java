package com.tango.settings.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.UpdateTimestamp;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "health_setting")
public class HealthSetting {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "test_name")
	private String testName;

	@JsonManagedReference
	@OneToOne(fetch = FetchType.EAGER, mappedBy = "setting", cascade = { CascadeType.PERSIST, CascadeType.MERGE,
			CascadeType.DETACH, CascadeType.REFRESH })
	private HealthCommand command;

	@Column(name = "search_word")
	private String searchWord;

	@Column(name = "test")
	private String test;

	@Column(name = "expected")
	private boolean expected;

	@Column(name = "info")
	private String info;

	@Column(name = "search_word2")
	private String searchWord2;

	@Column(name = "min")
	private int min;

	@Column(name = "max")
	private int max;

	@Column(name = "and_operator")
	private boolean and;

	@Column(name = "or_operator")
	private boolean or;

	@JsonManagedReference
	@OneToOne(fetch = FetchType.EAGER, mappedBy = "setting", cascade = { CascadeType.PERSIST, CascadeType.MERGE,
			CascadeType.DETACH, CascadeType.REFRESH })
	private HealthResult result;

	@Column(name = "severity")
	private int severity;

	@UpdateTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modify_date")
	private Date modifyDate;

	@JsonBackReference(value = "cluster-commandsetting")
	@ManyToOne
	@JoinColumn(name = "cluster_id")
	private Cluster cluster;

	@JsonBackReference(value = "machine-commandsetting")
	@ManyToOne
	@JoinColumn(name = "machine_id")
	private Machine machine;

	@Column(name = "warning_message")
	private String warningMessage;

	public HealthSetting() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTestName() {
		return testName;
	}

	public void setTestName(String testName) {
		this.testName = testName;
	}

	public HealthCommand getCommand() {
		return command;
	}

	public void setCommand(HealthCommand command) {
		this.command = command;
	}

	public String getSearchWord() {
		return searchWord;
	}

	public void setSearchWord(String searchWord) {
		this.searchWord = searchWord;
	}

	public boolean isExpected() {
		return expected;
	}

	public void setExpected(boolean expected) {
		this.expected = expected;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public HealthResult getResult() {
		return result;
	}

	public void setResult(HealthResult result) {
		this.result = result;
	}

	public int getSeverity() {
		return severity;
	}

	public void setSeverity(int severity) {
		this.severity = severity;
	}

	public Date getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}

	public Cluster getCluster() {
		return cluster;
	}

	public void setCluster(Cluster cluster) {
		this.cluster = cluster;
	}

	public Machine getMachine() {
		return machine;
	}

	public void setMachine(Machine machine) {
		this.machine = machine;
	}

	public String getSearchWord2() {
		return searchWord2;
	}

	public void setSearchWord2(String searchWord2) {
		this.searchWord2 = searchWord2;
	}

	public int getMin() {
		return min;
	}

	public void setMin(int min) {
		this.min = min;
	}

	public int getMax() {
		return max;
	}

	public void setMax(int max) {
		this.max = max;
	}

	public boolean isAnd() {
		return and;
	}

	public void setAnd(boolean and) {
		this.and = and;
	}

	public boolean isOr() {
		return or;
	}

	public void setOr(boolean or) {
		this.or = or;
	}

	public String getTest() {
		return test;
	}

	public void setTest(String test) {
		this.test = test;
	}

	public String getWarningMessage() {
		return warningMessage;
	}

	public void setWarningMessage(String warningMessage) {
		this.warningMessage = warningMessage;
	}

	@Override
	public String toString() {
		return "HealthSetting [id=" + id + ", testName=" + testName + ", command=" + command + ", searchWord="
				+ searchWord + ", expected=" + expected + ", info=" + info + ", searchWord2=" + searchWord2 + ", min="
				+ min + ", max=" + max + ", and=" + and + ", or=" + or + ", result=" + result + ", severity=" + severity
				+ ", modifyDate=" + modifyDate + ", cluster=" + cluster + ", machine=" + machine + "]";
	}

}
	


