package com.tango.settings.rest;

import java.util.ArrayList;


import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tango.settings.entity.Cluster;
import com.tango.settings.entity.Count;
import com.tango.settings.entity.Header;
import com.tango.settings.entity.Result;
import com.tango.settings.entity.Setting;
import com.tango.settings.service.ClusterService;
import com.tango.settings.service.ResultService;
import com.tango.settings.service.SettingService;


@RestController
@RequestMapping("/api")
public class ClusterRestController {
		
		@Autowired
		private ClusterService clusterService;
	
	
		@GetMapping("/clusters")
		public List<Cluster> getClusterss()  {
			
			return clusterService.getClusters();
			
		}
		
		
		@GetMapping("/clusters/{clusterId}")
		public Cluster getClusterById(@PathVariable int clusterId) {
			
			
		Cluster theCluster = clusterService.getCluster(clusterId);
				
		if (theCluster == null) {
			throw new SettingNotFoundException("Cluster id not found - " + clusterId); 
		}
				return theCluster;
			
		}

		
	
		
		@PostMapping("/clusters")
		public Cluster addCluster(@RequestBody Cluster theCluster) {
			
			theCluster.setId(0);
			
			clusterService.saveCluster(theCluster);
		
			return theCluster;
		}
		
		
		@PutMapping("/clusters")
		public Cluster updateCluster(@RequestBody Cluster theCluster) {
		
			clusterService.updateCluster(theCluster);
			
			return theCluster;
		
		
		}
		
		
		@DeleteMapping("/clusters/{clusterId}")
		public void deleteCluster(@PathVariable int clusterId) {
		
			clusterService.deleteCluster(clusterId);
		}
		
		
}


