package com.tango.settings.service;

import java.util.List;
import java.util.Set;

import com.tango.settings.entity.Cluster;
import com.tango.settings.entity.HealthSetting;
import com.tango.settings.entity.Count;
import com.tango.settings.entity.Header;
import com.tango.settings.entity.Setting;

public interface HealthSettingService {

	public List<HealthSetting> getSettings();

	public void saveSetting(HealthSetting theSetting);

	public HealthSetting getSetting(int theId);

	public void deleteSetting(int theId);
	
	public void updateSetting(HealthSetting theSetting);

	HealthSetting getSetting(Cluster cluster);

	List<HealthSetting> getSettings(Cluster cluster);

	List<HealthSetting> getSettings(int cluster);

	Count getSettingCount(int clusterId);

	List<HealthSetting> getSettingsMachine(int machineId);

	Count getSettingCountCluster(int clusterId);

	int getRecentSetting();

	List<HealthSetting> getSettingsMachineTest(int machineId, String test);

	Count getSettingCountTest(int machineId, String test);
	
}
