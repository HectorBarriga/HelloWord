package com.tango.settings.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tango.settings.dao.HealthResultsDAO;
import com.tango.settings.dao.ResultsDAO;
import com.tango.settings.dao.SettingDAO;
import com.tango.settings.entity.HealthResult;
import com.tango.settings.entity.Count;
import com.tango.settings.entity.Header;
import com.tango.settings.entity.Result;
import com.tango.settings.entity.Setting;

@Service
public class HealthResultServiceImpl implements HealthResultService {

	
	@Autowired
	private HealthResultsDAO resultDAO;

	@Override
	@Transactional
	public void saveResult(HealthResult theSetting) {

		resultDAO.saveResult(theSetting);

	}

	@Override
	@Transactional
	public void updateResult(HealthResult theResult, int settingId) {
		resultDAO.updateResult(theResult, settingId);

	}

	@Override
	@Transactional
	public Count getOkCount() {
		return resultDAO.countOk();
	}

}
