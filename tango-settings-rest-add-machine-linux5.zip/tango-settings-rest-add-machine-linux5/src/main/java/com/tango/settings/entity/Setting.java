package com.tango.settings.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "setting")
public class Setting {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "test_name")
	private String testName;

	@Column(name = "api_url")
	private String apiUrl;

	// @JsonIgnore
	@JsonManagedReference
	@OneToMany(fetch = FetchType.EAGER, mappedBy = "setting", cascade = { CascadeType.PERSIST, CascadeType.MERGE,
			CascadeType.DETACH, CascadeType.REFRESH })
	// @Column(name="headers")
	private List<Header> headers;

	@Column(name = "search_word")
	private String searchWord;

	@Column(name = "expected")
	private boolean expected;

	@Column(name = "severity")
	private int severity;

	@Column(name = "info")
	private String info;

	@Column(name = "curl")
	private String curl;

	@JsonManagedReference
	@OneToOne(fetch = FetchType.EAGER, mappedBy = "setting", cascade = { CascadeType.PERSIST, CascadeType.MERGE,
			CascadeType.DETACH, CascadeType.REFRESH })
	private BasicAuth basicAuth;

	@JsonManagedReference
	@OneToOne(fetch = FetchType.EAGER, mappedBy = "setting", cascade = { CascadeType.PERSIST, CascadeType.MERGE,
			CascadeType.DETACH, CascadeType.REFRESH })
	private Result result;

	@JsonBackReference(value = "machine-setting")
	@ManyToOne
	@JoinColumn(name = "machine_id")
	private Machine machine;

	@JsonBackReference(value = "cluster-setting")
	@ManyToOne
	@JoinColumn(name = "cluster_id")
	private Cluster cluster;

	@UpdateTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modify_date")
	private Date modifyDate;

	@Column(name = "warning_message")
	private String warningMessage;

	/*
	 * @OneToOne(cascade=CascadeType.ALL)
	 * 
	 * @JoinColumn(name="result_id") private Result result;
	 */

	///////////////////////////////////////////////////////////////////////////////////////////////

	public Setting() {

	}
	////////////////////////////////////////////////////////////////////////////////////////////////

	public int getId() {
		return id;
	}

	public Cluster getCluster() {
		return cluster;
	}

	public void setCluster(Cluster cluster) {
		this.cluster = cluster;
	}

	public Machine getMachine() {
		return machine;
	}

	public void setMachine(Machine machine) {
		this.machine = machine;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTestName() {
		return testName;
	}

	public void setTestName(String testName) {
		this.testName = testName;
	}

	public String getApiUrl() {
		return apiUrl;
	}

	public void setApiUrl(String apiUrl) {
		this.apiUrl = apiUrl;
	}

	public List<Header> getHeaders() {
		return headers;
	}

	public void setHeaders(List<Header> headers) {
		this.headers = headers;
	}

	public String getSearchWord() {
		return searchWord;
	}

	public void setSearchWord(String searchWord) {
		this.searchWord = searchWord;
	}

	public boolean getExpected() {
		return expected;
	}

	public void setExpected(Boolean expected) {
		this.expected = expected;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public String getCurl() {
		return curl;
	}

	public void setCurl(String curl) {
		this.curl = curl;
	}

	public Date getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}

	public BasicAuth getBasic() {
		return basicAuth;
	}

	public void setBasic(BasicAuth basic) {
		this.basicAuth = basic;
	}

	public void setExpected(boolean expected) {
		this.expected = expected;
	}

	public int getSeverity() {
		return severity;
	}

	public void setSeverity(int severity) {
		this.severity = severity;
	}

	public BasicAuth getBasicAuth() {
		return basicAuth;
	}

	public void setBasicAuth(BasicAuth basicAuth) {
		this.basicAuth = basicAuth;
	}

	public Result getResult() {
		return result;
	}

	public void setResult(Result result) {
		this.result = result;
	}

	public void add(Header tempHeader) {

		if (headers == null) {
			headers = new ArrayList<>();
		}

		headers.add(tempHeader);

		tempHeader.setSetting(this);
	}

	public String getWarningMessage() {
		return warningMessage;
	}

	public void setWarningMessage(String warningMessage) {
		this.warningMessage = warningMessage;
	}

	public void generateCurl() {

		if (this.headers.size() == 0) {

			this.curl = "curl -X GET " + this.apiUrl;

		} else {

			String headers = "";
			for (Header tempHeader : this.headers) {

				headers = tempHeader.getHeaderKey() + ":" + tempHeader.getHeaderValue() + " ";

			}

			this.curl = "curl -X GET -H \"" + headers + "\"" + this.apiUrl;
		}

	}

	@Override
	public String toString() {
		return "Setting [id=" + id + ", testName=" + testName + ", apiUrl=" + apiUrl + ", headers=" + headers
				+ ", searchWord=" + searchWord + ", expected=" + expected + ", info=" + info + ", curl=" + curl + "]";
	}

}
