package com.tango.settings.service;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tango.settings.dao.ClusterDAO;
import com.tango.settings.dao.KibanaDAO;
import com.tango.settings.dao.SettingDAO;
import com.tango.settings.entity.Cluster;
import com.tango.settings.entity.Kibana;
import com.tango.settings.entity.Setting;

@Service
public class KibanaServiceImpl implements KibanaService {

	
	@Autowired
	private KibanaDAO kibanaDAO;

	@Override
	@Transactional
	public List<Kibana> getDashboards() {
		return kibanaDAO.getDashboards();
	}

	@Override
	@Transactional
	public void saveDashboard(Kibana theKibana) {

		kibanaDAO.saveDashboard(theKibana);
	}

	@Override
	@Transactional
	public Kibana getDashboard(int theId) {

		return kibanaDAO.getDashboard(theId);
	}

	@Override
	@Transactional
	public void deleteDashboard(int theId) {

		kibanaDAO.deleteDashboard(theId);
	}

	@Override
	@Transactional
	public void updateDashboard(Kibana theDashboard) {

		kibanaDAO.updateDashboard(theDashboard);
	}

}
