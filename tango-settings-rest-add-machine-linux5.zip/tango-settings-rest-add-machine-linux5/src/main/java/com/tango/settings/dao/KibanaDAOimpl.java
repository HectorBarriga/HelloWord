package com.tango.settings.dao;

import java.util.List;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tango.settings.entity.Cluster;
import com.tango.settings.entity.Kibana;
import com.tango.settings.entity.Setting;


@Repository
public class KibanaDAOimpl implements KibanaDAO{
	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public List<Kibana> getDashboards() {
		// get the current hibernate session
				Session currentSession = sessionFactory.getCurrentSession();
						
				// create a query
				Query<Kibana> theQuery = 
						currentSession.createQuery("from Kibana",
													Kibana.class);
				
				// execute query and get result list
				List<Kibana> dashboards = theQuery.getResultList();
						
				// return the results		
				return dashboards;
	}

	@Override
	public void saveDashboard(Kibana theKibana) {
		// get current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();
	
		currentSession.saveOrUpdate(theKibana);
		
	}

	@Override
	public Kibana getDashboard(int theId) {
		// get the current hibernate session
				Session currentSession = sessionFactory.getCurrentSession();
				
				// now retrieve/read from database using the primary key
				Kibana theKibana = currentSession.get(Kibana.class, theId);
				
				return theKibana;
	}

	@Override
	public void deleteDashboard(int theId) {
		// get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();
		
		// delete object
		Query theQuery = 
				currentSession.createQuery("delete from Kibana where id=:kibanaId");
		theQuery.setParameter("kibanaId", theId);
		theQuery.executeUpdate();	
	
	}

	@Override
	public void updateDashboard(Kibana theKibana) {
		// get current hibernate session
				Session currentSession = sessionFactory.getCurrentSession();
				int theId = theKibana.getId();
				currentSession.saveOrUpdate(theKibana);
				currentSession.persist(theKibana);
		
	}
	
	
}
