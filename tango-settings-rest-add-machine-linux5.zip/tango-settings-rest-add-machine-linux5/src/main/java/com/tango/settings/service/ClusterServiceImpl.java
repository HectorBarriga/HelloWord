package com.tango.settings.service;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tango.settings.dao.ClusterDAO;
import com.tango.settings.dao.SettingDAO;
import com.tango.settings.entity.Cluster;
import com.tango.settings.entity.Setting;

@Service
public class ClusterServiceImpl implements ClusterService {

	
	@Autowired
	private ClusterDAO clusterDAO;

	@Override
	@Transactional
	public List<Cluster> getClusters() {
		return clusterDAO.getClusters();
	}

	@Override
	@Transactional
	public void saveCluster(Cluster theCluster) {

		clusterDAO.saveCluster(theCluster);
	}

	@Override
	@Transactional
	public Cluster getCluster(int theId) {

		return clusterDAO.getCluster(theId);
	}

	@Override
	@Transactional
	public void deleteCluster(int theId) {

		clusterDAO.deleteCluster(theId);
	}

	@Override
	@Transactional
	public void updateCluster(Cluster theCluster) {

		clusterDAO.updateCluster(theCluster);
	}

}
