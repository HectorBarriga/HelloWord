package com.tango.settings.dao;

import java.util.List;

import com.tango.settings.entity.Count;
import com.tango.settings.entity.Result;

public interface ResultsDAO {

	void saveResult(Result theResult);
	
	void updateResult(Result theResult, int theId);

	Count countOk();
	
	

}
