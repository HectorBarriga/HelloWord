package com.tango.settings.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.hibernate.type.IntegerType;
import org.hibernate.type.LongType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tango.settings.entity.Cluster;
import com.tango.settings.entity.HealthSetting;
import com.tango.settings.entity.Count;
import com.tango.settings.entity.Header;
import com.tango.settings.entity.Setting;

@Repository
public class HealthSettingDAOImpl2 implements HealthSettingDAO {

	// need to inject the session factory
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public List<HealthSetting> getSettings() {

		// get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();

		// create a query ... sort by last name
		Query<HealthSetting> theQuery = currentSession.createQuery("from HealthSetting", HealthSetting.class);

		// execute query and get result list
		List<HealthSetting> settings = theQuery.getResultList();

		// return the results
		return settings;
	}

	@Override
	public List<HealthSetting> getSettings(int cluster) {

		// get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();

		// create a query ... sort by last name
		Query<HealthSetting> theQuery = currentSession.createQuery("from HealthSetting where cluster_id=:cluster",
				HealthSetting.class);
		theQuery.setParameter("cluster", cluster);

		// execute query and get result list
		List<HealthSetting> settings = theQuery.getResultList();

		// return the results
		return settings;
	}

	@Override
	public List<HealthSetting> getSettingsMachine(int machine) {

		// get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();

		Query<HealthSetting> theQuery = currentSession.createQuery("from HealthSetting where machine_id=:machine",
				HealthSetting.class);
		theQuery.setParameter("machine", machine);

		// execute query and get result list
		List<HealthSetting> settings = theQuery.getResultList();

		// return the results
		return settings;
	}

	@Override
	public List<HealthSetting> getSettingsMachineTest(int machine, String test) {

		// get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();

		Query<HealthSetting> theQuery = currentSession
				.createQuery("from HealthSetting where machine_id=:machine and test=:test", HealthSetting.class);
		theQuery.setParameter("machine", machine);
		theQuery.setParameter("test", test);

		// execute query and get result list
		List<HealthSetting> settings = theQuery.getResultList();

		// return the results
		return settings;
	}

	@Override
	public Count getSettingsCount(int machine) {

		// create an instance of count object
		Count count = new Count();

		// get current session
		Session currentSession = sessionFactory.getCurrentSession();

		Query query = currentSession.createSQLQuery(
				"select COUNT(*) as count from health_setting where machine_id=:machine AND id IN (Select health_setting_id from health_result where status_ok=true)")
				.addScalar("count", LongType.INSTANCE);

		query.setParameter("machine", machine);

		Query query2 = currentSession.createSQLQuery(
				"select COUNT(*) as count from health_setting where machine_id=:machine AND id IN (Select health_setting_id from health_result where status_ok=false AND severity=3)")
				.addScalar("count", LongType.INSTANCE);

		query2.setParameter("machine", machine);

		Query query3 = currentSession.createSQLQuery(
				"select COUNT(*) as count from health_setting where machine_id=:machine AND id IN (Select health_setting_id from health_result where status_ok=false AND severity=2)")
				.addScalar("count", LongType.INSTANCE);

		query3.setParameter("machine", machine);

		Query query4 = currentSession.createSQLQuery(
				"select COUNT(*) as count from health_setting where machine_id=:machine AND id IN (Select health_setting_id from health_result where status_ok=false AND severity=1)")
				.addScalar("count", LongType.INSTANCE);

		query4.setParameter("machine", machine);

		long countOk = (long) query.getSingleResult();

		long countWarning = (long) query2.getSingleResult();

		long countAlert = (long) query3.getSingleResult();

		long countInfo = (long) query4.getSingleResult();

	
		count.setCountWarning(countWarning);
		count.setCountAlert(countAlert);
		count.setInfo(countInfo);
		count.setCountOK(countOk);

		// return the results
		return count;
	}

	@Override
	public Count getSettingsCountCluster(int cluster) {

		// create an instance of count object
		Count count = new Count();

		// get current session
		Session currentSession = sessionFactory.getCurrentSession();



		Query query = currentSession.createSQLQuery(
				"select COUNT(*) as count from health_setting where cluster_id=:cluster AND id IN (Select health_setting_id from health_result where status_ok=true)")
				.addScalar("count", LongType.INSTANCE);

		query.setParameter("cluster", cluster);

		Query query2 = currentSession.createSQLQuery(
				"select COUNT(*) as count from health_setting where cluster_id=:cluster AND id IN (Select health_setting_id from health_result where status_ok=false AND severity=3)")
				.addScalar("count", LongType.INSTANCE);

		query2.setParameter("cluster", cluster);

		Query query3 = currentSession.createSQLQuery(
				"select COUNT(*) as count from health_setting where cluster_id=:cluster AND id IN (Select health_setting_id from health_result where status_ok=false AND severity=2)")
				.addScalar("count", LongType.INSTANCE);

		query3.setParameter("cluster", cluster);

		Query query4 = currentSession.createSQLQuery(
				"select COUNT(*) as count from health_setting where cluster_id=:cluster AND id IN (Select health_setting_id from health_result where status_ok=false AND severity=1)")
				.addScalar("count", LongType.INSTANCE);

		query4.setParameter("cluster", cluster);

	

		long countOk = (long) query.getSingleResult();

		long countWarning = (long) query2.getSingleResult();

		long countAlert = (long) query3.getSingleResult();

		long countInfo = (long) query4.getSingleResult();

	
		count.setCountWarning(countWarning);
		count.setCountAlert(countAlert);
		count.setInfo(countInfo);
		count.setCountOK(countOk);

		// return the results
		return count;
	}

	@Override
	public List<HealthSetting> getSettings(Cluster cluster) {

		// get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();

		// create a query ... sort by last name
		Query<HealthSetting> theQuery = currentSession.createQuery("from HealthSetting where cluster=:cluster",
				HealthSetting.class);
		theQuery.setParameter("cluster", cluster);

		// execute query and get result list
		List<HealthSetting> settings = theQuery.getResultList();

		// return the results
		return settings;
	}

	@Override
	public void saveSetting(HealthSetting theSetting) {

		// get current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();

		currentSession.saveOrUpdate(theSetting);
		currentSession.persist(theSetting);
	}

	@Override
	public HealthSetting getSetting(int theId) {

		// get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();

		// now retrieve/read from database using the primary key
		HealthSetting theSetting = currentSession.get(HealthSetting.class, theId);

		return theSetting;
	}

	@Override
	public int getRecentSetting() {

		// get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();

		Query theQuery = (currentSession.createSQLQuery(
				" select id from health_setting where modify_date IN (select MAX(modify_date) from health_setting)")
				.addScalar("id", IntegerType.INSTANCE));

		// now retrieve/read from database using the primary key
		int theSetting = (int) theQuery.getSingleResult();

		return theSetting;
	}

	@Override
	public void deleteSetting(int theId) {

		// get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();

		// delete object with primary key
		Query<Long> theQuery = currentSession.createQuery("delete from HealthSetting where id=:settingId");
		theQuery.setParameter("settingId", theId);

		theQuery.executeUpdate();
	
	}

	@Override
	public void updateSetting(HealthSetting theSetting) {

		// get current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();
		int theId = theSetting.getId();
		Query<Long> theQuery = currentSession
				.createQuery("delete from HealthCommand where health_setting_id=:settingId");
		theQuery.setParameter("settingId", theId);
		theQuery.executeUpdate();

		currentSession.saveOrUpdate(theSetting);
		currentSession.persist(theSetting);
	}

	@Override
	public Count getSettingsCountTest(int machine, String test) {

		// create an instance of count object
		Count count = new Count();

		// get current session
		Session currentSession = sessionFactory.getCurrentSession();

		Query query = currentSession.createSQLQuery(
				"select COUNT(*) as count from health_setting where machine_id=:machine AND test=:test AND id IN (Select health_setting_id from health_result where status_ok=true)")
				.addScalar("count", LongType.INSTANCE);

		query.setParameter("machine", machine);
		query.setParameter("test", test);

		Query query2 = currentSession.createSQLQuery(
				"select COUNT(*) as count from health_setting where machine_id=:machine AND test=:test AND id IN (Select health_setting_id from health_result where status_ok=false AND severity=3)")
				.addScalar("count", LongType.INSTANCE);

		query2.setParameter("machine", machine);
		query2.setParameter("test", test);

		Query query3 = currentSession.createSQLQuery(
				"select COUNT(*) as count from health_setting where machine_id=:machine AND test=:test AND id IN (Select health_setting_id from health_result where status_ok=false AND severity=2)")
				.addScalar("count", LongType.INSTANCE);

		query3.setParameter("machine", machine);
		query3.setParameter("test", test);

		Query query4 = currentSession.createSQLQuery(
				"select COUNT(*) as count from health_setting where machine_id=:machine AND test=:test AND id IN (Select health_setting_id from health_result where status_ok=false AND severity=1)")
				.addScalar("count", LongType.INSTANCE);

		query4.setParameter("machine", machine);
		query4.setParameter("test", test);

		long countOk = (long) query.getSingleResult();

		long countWarning = (long) query2.getSingleResult();

		long countAlert = (long) query3.getSingleResult();

		long countInfo = (long) query4.getSingleResult();

	
		count.setCountWarning(countWarning);
		count.setCountAlert(countAlert);
		count.setInfo(countInfo);
		count.setCountOK(countOk);

		// return the results
		return count;
	}

}
