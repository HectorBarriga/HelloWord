package com.tango.settings.service;

import java.util.List;

import com.tango.settings.entity.HealthResult;
import com.tango.settings.entity.Count;
import com.tango.settings.entity.Header;
import com.tango.settings.entity.Result;
import com.tango.settings.entity.Setting;

public interface HealthResultService {


	void updateResult(HealthResult theResult, int settingId);

	void saveResult(HealthResult theSetting);

	Count getOkCount();

	


	
	
}
