package com.tango.settings.rest;

import java.util.ArrayList;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tango.settings.entity.Cluster;
import com.tango.settings.entity.Count;
import com.tango.settings.entity.Header;
import com.tango.settings.entity.Machine;
import com.tango.settings.entity.Result;
import com.tango.settings.entity.Setting;
import com.tango.settings.service.ClusterService;
import com.tango.settings.service.MachineService;
import com.tango.settings.service.ResultService;
import com.tango.settings.service.SettingService;
//import com.tango.settings.entity.Setting;;


@RestController
@RequestMapping("/api")
public class MachineRestController {
	
		@Autowired
		private ClusterService clusterService;
		
		@Autowired
		private MachineService machineService;
		
	
		@GetMapping("/machines/{clusterId}")
	
		public List<Machine> getMachines(@PathVariable int clusterId)  {
			return machineService.getMachines(clusterId);
			
		}
		
		
		@GetMapping("/machines/get/{machineId}")
		public  Machine getMachineById(@PathVariable int machineId) {
			
			
		Machine theMachine = machineService.getMachine(machineId);
				
		if (theMachine == null) {
			throw new SettingNotFoundException("Machine id not found - " + machineId); 
		}
				return theMachine;
			
		}
		
		@PostMapping("/machines")
		public Machine addmachine(@RequestBody Machine theMachine) {
			
			theMachine.setId(0);
			machineService.saveMachine(theMachine);
		
			return theMachine;
		
		
		}
		
		@PutMapping("/machines")
		public Machine updateSetting(@RequestBody Machine theMachine) {
		
			machineService.updateMachine(theMachine);
			
			return theMachine;
		
		}
		
		
		@DeleteMapping("/machines/{machineId}")
		public void deleteCluster(@PathVariable int machineId) {
			
			// delete 
			machineService.deleteMachine(machineId);
			
		
		}
		
		
}


