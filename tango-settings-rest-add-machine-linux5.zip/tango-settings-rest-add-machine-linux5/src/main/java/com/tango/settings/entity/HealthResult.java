package com.tango.settings.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.UpdateTimestamp;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "health_result")
public class HealthResult {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "command_output")
	private String commandOutput;

	@Column(name = "status_ok")
	private boolean statusOk;

	@JsonBackReference
	@ManyToOne
	@JoinColumn(name = "health_setting_id")
	private HealthSetting setting;

	@UpdateTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modify_date")
	private Date modifyDate;

	@Column(name = "severity")
	private int severity;

	public HealthResult() {

	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public boolean isStatusOk() {
		return statusOk;
	}

	public void setStatusOk(boolean statusOk) {
		this.statusOk = statusOk;
	}

	public HealthSetting getSetting() {
		return setting;
	}

	public void setSetting(HealthSetting setting) {
		this.setting = setting;
	}

	public Date getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}

	public int getSeverity() {
		return severity;
	}

	public void setSeverity(int severity) {
		this.severity = severity;
	}

	public void setCommandOutput(String commandOutput) {
		this.commandOutput = commandOutput;
	}

	public String getCommandOutput() {
		return commandOutput;
	}

	@Override
	public String toString() {
		return "CommandResult [id=" + id + ", commandOutput=" + commandOutput + ", statusOk=" + statusOk + ", setting="
				+ setting + ", modifyDate=" + modifyDate + ", severity=" + severity + "]";
	}

}
