package com.tango.settings.dao;

import java.util.List;
import java.util.Set;

import com.tango.settings.entity.Cluster;
import com.tango.settings.entity.HealthSetting;
import com.tango.settings.entity.Count;
import com.tango.settings.entity.Header;
import com.tango.settings.entity.Setting;

public interface HealthSettingDAO {

//	public List<Setting> getSettings(int clusterId);

	public void saveSetting(HealthSetting theCustomer);

	public HealthSetting getSetting(int theId);

	public void deleteSetting(int theId);
	
	public void updateSetting(HealthSetting theCustomer);

	List<HealthSetting> getSettings(Cluster cluster);

	List<HealthSetting> getSettings();

	List<HealthSetting> getSettings(int cluster);

	Count getSettingsCount(int cluster);

	List<HealthSetting> getSettingsMachine(int machine);

	Count getSettingsCountCluster(int cluster);

	int getRecentSetting();

	List<HealthSetting> getSettingsMachineTest(int machine, String test);

	Count getSettingsCountTest(int machine, String Test);
}
