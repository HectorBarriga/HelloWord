package com.tango.settings.dao;

import java.util.List;
import java.util.Set;

import com.tango.settings.entity.Cluster;
import com.tango.settings.entity.Setting;

public interface ClusterDAO {
	
	public List<Cluster> getClusters();

	public void saveCluster(Cluster theCluster);

	public Cluster getCluster(int theId);

	public void deleteCluster(int theId);
	
	public void updateCluster(Cluster theCluster);

	Cluster getClusterCount(int theId);

}
