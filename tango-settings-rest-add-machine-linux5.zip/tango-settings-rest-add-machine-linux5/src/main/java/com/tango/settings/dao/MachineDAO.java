package com.tango.settings.dao;

import java.util.List;
import java.util.Set;

import com.tango.settings.entity.Cluster;
import com.tango.settings.entity.Machine;
import com.tango.settings.entity.Setting;

public interface MachineDAO {
	
	public List<Machine> getMachines(int clusterId);

	public void saveMachine(Machine theMachine);

	public Machine getMachine(int theId);

	public void deleteMachine(int theId);
	
	public void updateMachine(Machine theMachine);

	Cluster getMachineCount(int theId);

	

}
