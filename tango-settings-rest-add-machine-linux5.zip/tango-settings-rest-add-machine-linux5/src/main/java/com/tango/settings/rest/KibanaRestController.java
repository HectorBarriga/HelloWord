package com.tango.settings.rest;

import java.util.ArrayList;


import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tango.settings.entity.Cluster;
import com.tango.settings.entity.Count;
import com.tango.settings.entity.Header;
import com.tango.settings.entity.Kibana;
import com.tango.settings.entity.Result;
import com.tango.settings.entity.Setting;
import com.tango.settings.service.ClusterService;
import com.tango.settings.service.KibanaService;
import com.tango.settings.service.ResultService;
import com.tango.settings.service.SettingService;


@RestController
@RequestMapping("/kibana")
public class KibanaRestController {
		
		@Autowired
		private KibanaService kibanaService;
	
	
		@GetMapping("/dashboards")
		public List<Kibana> getDashboards()  {
			
			return kibanaService.getDashboards();
			
		}
		
		
		@GetMapping("/dashboards/{dashboardId}")
		public Kibana getDashboardById(@PathVariable int dashboardId) {
			
			
		Kibana theDashboard = kibanaService.getDashboard(dashboardId);
				
		if (theDashboard == null) {
			throw new SettingNotFoundException("DashBoard id not found - " + dashboardId); 
		}
				return theDashboard;
			
		}

		
	
		
		@PostMapping("/dashboards")
		public Kibana addDashboard(@RequestBody Kibana theKibana) {
			
			theKibana.setId(0);
			
			kibanaService.saveDashboard(theKibana);
		
			return theKibana;
		}
		
		
		@PutMapping("/dashboards")
		public Kibana updateCluster(@RequestBody Kibana theKibana) {
		
			kibanaService.updateDashboard(theKibana);
			
			return theKibana;
		
		
		}
		
		
		@DeleteMapping("/dashboards/{kibanaId}")
		public void deleteDashboard(@PathVariable int kibanaId) {
		
			kibanaService.deleteDashboard(kibanaId);
		}
		
		
}


