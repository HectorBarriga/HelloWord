package com.tango.settings.dao;

import java.util.List;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tango.settings.entity.Cluster;
import com.tango.settings.entity.Machine;
import com.tango.settings.entity.Setting;

@Repository
public class MachineDAOImpl implements MachineDAO {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public List<Machine> getMachines(int clusterId) {
		// get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();

		Query<Machine> theQuery = currentSession.createQuery("from Machine where cluster_id=:cluster", Machine.class);

		theQuery.setParameter("cluster", clusterId);

		List<Machine> machines = theQuery.getResultList();

		// return the results
		return machines;
	}

	@Override
	public void saveMachine(Machine theMachine) {
		// get current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();

		currentSession.saveOrUpdate(theMachine);

	}

	@Override
	public Machine getMachine(int theId) {
		// get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();

		Machine theMachine = currentSession.get(Machine.class, theId);

		return theMachine;
	}

	@Override
	public void deleteMachine(int theId) {
		// get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();

		// delete object with primary key
		Query theQuery = currentSession.createQuery("delete from Machine where id=:machineId");
		theQuery.setParameter("machineId", theId);
		theQuery.executeUpdate();

	}

	@Override
	public void updateMachine(Machine theMachine) {
		// get current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();
		int theId = theMachine.getId();

		currentSession.saveOrUpdate(theMachine);
		currentSession.persist(theMachine);

	}

	@Override
	public Cluster getMachineCount(int theId) {
		// get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();
		Cluster theCluster = currentSession.get(Cluster.class, theId);

		return theCluster;
	}

}
