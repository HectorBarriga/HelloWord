package com.tango.settings.service;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tango.settings.dao.HealthSettingDAO;
import com.tango.settings.dao.SettingDAO;
import com.tango.settings.entity.Cluster;
import com.tango.settings.entity.HealthSetting;
import com.tango.settings.entity.Count;
import com.tango.settings.entity.Header;
import com.tango.settings.entity.Setting;

@Service
public class HealthSettingServiceImpl implements HealthSettingService {


	@Autowired
	private HealthSettingDAO settingDAO;

	@Override
	@Transactional
	public List<HealthSetting> getSettings() {
		return settingDAO.getSettings();
	}

	@Override
	@Transactional
	public List<HealthSetting> getSettings(Cluster cluster) {
		return settingDAO.getSettings(cluster);
	}

	@Override
	@Transactional
	public List<HealthSetting> getSettings(int cluster) {
		return settingDAO.getSettings(cluster);
	}

	@Override
	@Transactional
	public List<HealthSetting> getSettingsMachine(int machineId) {
		return settingDAO.getSettingsMachine(machineId);
	}

	@Override
	@Transactional
	public List<HealthSetting> getSettingsMachineTest(int machineId, String test) {
		return settingDAO.getSettingsMachineTest(machineId, test);
	}

	@Override
	@Transactional
	public void saveSetting(HealthSetting theSetting) {

		settingDAO.saveSetting(theSetting);
	}

	@Override
	@Transactional
	public HealthSetting getSetting(int theId) {

		return settingDAO.getSetting(theId);
	}

	@Override
	@Transactional
	public int getRecentSetting() {

		return settingDAO.getRecentSetting();
	}

	@Override
	@Transactional
	public void deleteSetting(int theId) {

		settingDAO.deleteSetting(theId);
	}

	@Override
	@Transactional
	public void updateSetting(HealthSetting theSetting) {

		settingDAO.updateSetting(theSetting);
	}

	@Override
	public HealthSetting getSetting(Cluster cluster) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	@Transactional
	public Count getSettingCount(int machineId) {
		return settingDAO.getSettingsCount(machineId);
	}

	@Override
	@Transactional
	public Count getSettingCountTest(int machineId, String test) {
		return settingDAO.getSettingsCountTest(machineId, test);
	}

	@Override
	@Transactional
	public Count getSettingCountCluster(int clusterId) {
		return settingDAO.getSettingsCountCluster(clusterId);
	}

}







