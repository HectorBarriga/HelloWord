package com.tango.settings.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name="health_command")
public class HealthCommand {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="command")
	private String command;
	
	@Column(name="directory")
	private String directory;
	
	@JsonBackReference
	@OneToOne
	@JoinColumn(name="health_setting_id")
	private HealthSetting setting;
	
	
	public HealthCommand() {
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCommand() {
		return command;
	}

	public void setCommand(String command) {
		this.command = command;
	}

	public String getDirectory() {
		return directory;
	}

	public void setDirectory(String directory) {
		this.directory = directory;
	}

	public HealthSetting getSetting() {
		return setting;
	}

	public void setSetting(HealthSetting setting) {
		this.setting = setting;
	}

	@Override
	public String toString() {
		return "HealthCommand [id=" + id + ", command=" + command + ", directory=" + directory + ", setting=" + setting
				+ "]";
	}
	
	
	
}
