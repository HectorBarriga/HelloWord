package com.tango.settings.rest;

import java.util.ArrayList;


import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tango.settings.entity.Cluster;
import com.tango.settings.entity.HealthResult;
import com.tango.settings.entity.HealthSetting;
import com.tango.settings.entity.Count;
import com.tango.settings.entity.Header;
import com.tango.settings.entity.Result;
import com.tango.settings.entity.Setting;
import com.tango.settings.service.HealthResultService;
import com.tango.settings.service.HealthSettingService;
import com.tango.settings.service.ResultService;




@RestController
@RequestMapping("/command")
public class HealthSettingRestController {

	@Autowired
	private HealthResultService resultService;

	@Autowired
	private HealthSettingService healthService;

	@GetMapping("/settings")
	public List<HealthSetting> getSettings() {

		return healthService.getSettings();

	}
		
	@GetMapping("/settings/{clusterId}")
	public List<HealthSetting> getSettings(@PathVariable int clusterId) {

		return healthService.getSettings(clusterId);

	}
		
	
	@GetMapping("/settings/machine/{machineId}")
	public List<HealthSetting> getSettingsMachine(@PathVariable int machineId) {

		return healthService.getSettingsMachine(machineId);

	}

	
	@GetMapping("/settings/machine/{test}/{machineId}")
	public List<HealthSetting> getSettingsMachineTest(@PathVariable int machineId, @PathVariable String test) {

		return healthService.getSettingsMachineTest(machineId, test);

	}

	
	@GetMapping("/settings/get/{settingId}")
	public HealthSetting getSettingById(@PathVariable int settingId) {

		HealthSetting theSetting = healthService.getSetting(settingId);

		if (theSetting == null) {
			throw new SettingNotFoundException("Setting id not found - " + settingId);
		}
		return theSetting;

	}

	@GetMapping("/settings/get")
	public int getSettingById() {

		int theSetting = healthService.getRecentSetting();

		return theSetting;

	}

	// add mapping for post customers

	@PostMapping("/settings")
	public HealthSetting addSetting(@RequestBody HealthSetting theSetting) {
		// just in case they pass in id of json
		// force a save of new item

		theSetting.setId(0);
		// theSetting.generateCurl();

		healthService.saveSetting(theSetting);

		return theSetting;

	}

	@PostMapping("/settings/result")
	public HealthResult addResult(@RequestBody HealthResult theSetting) {
		
		theSetting.setId(0);

		resultService.saveResult(theSetting);

		return theSetting;

	}

	@PostMapping("/settings/result/{settingId}")
	public HealthResult updateResult(@RequestBody HealthResult theResult, @PathVariable int settingId) {
		theResult.setId(0);
		resultService.updateResult(theResult, settingId);

		return theResult;
	}

	@PutMapping("/settings")
	public HealthSetting updateSetting(@RequestBody HealthSetting theSetting) {

		healthService.updateSetting(theSetting);

		return theSetting;

	}

	@DeleteMapping("/settings/{settingId}")
	public void deleteSetting(@PathVariable int settingId) {

		healthService.deleteSetting(settingId);

	}

	@GetMapping("/settings/count")
	public Count getResultCount() {

		Count okCount = resultService.getOkCount();

		return okCount;

	}

	@GetMapping("/settings/count/{machineId}")
	public Count getSettingCount(@PathVariable int machineId) {

		Count okCount = healthService.getSettingCount(machineId);

		return okCount;

	}
	
	@GetMapping("/settings/count/{test}/{machineId}")
	public Count getSettingCount(@PathVariable int machineId, @PathVariable String test) {

		Count okCount = healthService.getSettingCountTest(machineId, test);

		return okCount;

	}

	@GetMapping("/settings/count/cluster/{clusterId}")
	public Count getSettingCountCluster(@PathVariable int clusterId) {

		Count okCount = healthService.getSettingCountCluster(clusterId);

		return okCount;

	}
}
