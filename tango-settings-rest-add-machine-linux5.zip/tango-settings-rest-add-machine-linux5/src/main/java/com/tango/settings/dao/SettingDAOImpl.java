package com.tango.settings.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.hibernate.type.IntegerType;
import org.hibernate.type.LongType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tango.settings.entity.Cluster;
import com.tango.settings.entity.Count;
import com.tango.settings.entity.Header;
import com.tango.settings.entity.Setting;

@Repository
public class SettingDAOImpl implements SettingDAO {

	// need to inject the session factory
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public List<Setting> getSettings() {

		// get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();

		Query<Setting> theQuery = currentSession.createQuery("from Setting", Setting.class);

		List<Setting> settings = theQuery.getResultList();

		return settings;
	}

	@Override
	public List<Setting> getSettings(int cluster) {

		// get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();

		Query<Setting> theQuery = currentSession.createQuery("from Setting where cluster_id=:cluster", Setting.class);
		theQuery.setParameter("cluster", cluster);

		// execute query and get result list
		List<Setting> settings = theQuery.getResultList();

		// return the results
		return settings;
	}

	@Override
	public List<Setting> getSettingsMachine(int machine) {

		// get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();

		Query<Setting> theQuery = currentSession.createQuery("from Setting where machine_id=:machine", Setting.class);
		theQuery.setParameter("machine", machine);

		List<Setting> settings = theQuery.getResultList();

		// return the results
		return settings;
	}

	@Override
	public Count getSettingsCount(int machine) {

		// create an instance of count object
		Count count = new Count();

		// get current session
		Session currentSession = sessionFactory.getCurrentSession();

		Query query = currentSession.createSQLQuery(
				"select COUNT(*) as count from setting where machine_id=:machine AND id IN (Select setting_id from result where status_ok=true)")
				.addScalar("count", LongType.INSTANCE);

		query.setParameter("machine", machine);

		Query query2 = currentSession.createSQLQuery(
				"select COUNT(*) as count from setting where machine_id=:machine AND id IN (Select setting_id from result where status_ok=false AND severity=3)")
				.addScalar("count", LongType.INSTANCE);

		query2.setParameter("machine", machine);

		Query query3 = currentSession.createSQLQuery(
				"select COUNT(*) as count from setting where machine_id=:machine AND id IN (Select setting_id from result where status_ok=false AND severity=2)")
				.addScalar("count", LongType.INSTANCE);

		query3.setParameter("machine", machine);

		Query query4 = currentSession.createSQLQuery(
				"select COUNT(*) as count from setting where machine_id=:machine AND id IN (Select setting_id from result where status_ok=false AND severity=1)")
				.addScalar("count", LongType.INSTANCE);

		query4.setParameter("machine", machine);

		long countOk = (long) query.getSingleResult();

		long countWarning = (long) query2.getSingleResult();

		long countAlert = (long) query3.getSingleResult();

		long countInfo = (long) query4.getSingleResult();

		count.setCountWarning(countWarning);
		count.setCountAlert(countAlert);
		count.setInfo(countInfo);
		count.setCountOK(countOk);

		return count;
	}

	@Override
	public Count getSettingsCountCluster(int cluster) {

		// create an instance of count object
		Count count = new Count();

		// get current session
		Session currentSession = sessionFactory.getCurrentSession();

		Query query = currentSession.createSQLQuery(
				"select COUNT(*) as count from setting where cluster_id=:cluster AND id IN (Select setting_id from result where status_ok=true)")
				.addScalar("count", LongType.INSTANCE);

		query.setParameter("cluster", cluster);

		Query query2 = currentSession.createSQLQuery(
				"select COUNT(*) as count from setting where cluster_id=:cluster AND id IN (Select setting_id from result where status_ok=false AND severity=3)")
				.addScalar("count", LongType.INSTANCE);

		query2.setParameter("cluster", cluster);

		Query query3 = currentSession.createSQLQuery(
				"select COUNT(*) as count from setting where cluster_id=:cluster AND id IN (Select setting_id from result where status_ok=false AND severity=2)")
				.addScalar("count", LongType.INSTANCE);

		query3.setParameter("cluster", cluster);

		Query query4 = currentSession.createSQLQuery(
				"select COUNT(*) as count from setting where cluster_id=:cluster AND id IN (Select setting_id from result where status_ok=false AND severity=1)")
				.addScalar("count", LongType.INSTANCE);

		query4.setParameter("cluster", cluster);

		long countOk = (long) query.getSingleResult();

		long countWarning = (long) query2.getSingleResult();

		long countAlert = (long) query3.getSingleResult();

		long countInfo = (long) query4.getSingleResult();

		count.setCountWarning(countWarning);
		count.setCountAlert(countAlert);
		count.setInfo(countInfo);

		count.setCountOK(countOk);

		// return the results
		return count;
	}

	@Override
	public List<Setting> getSettings(Cluster cluster) {

		// get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();

		Query<Setting> theQuery = currentSession.createQuery("from Setting where cluster=:cluster", Setting.class);
		theQuery.setParameter("cluster", cluster);

		List<Setting> settings = theQuery.getResultList();

		// return the results
		return settings;
	}

	@Override
	public void saveSetting(Setting theSetting) {

		// get current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();
		currentSession.saveOrUpdate(theSetting);
		currentSession.persist(theSetting);
	}

	@Override
	public Setting getSetting(int theId) {

		// get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();
		// now retrieve/read from database using the primary key
		Setting theCustomer = currentSession.get(Setting.class, theId);

		return theCustomer;
	}

	@Override
	public int getRecentSetting() {

		// get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();

		Query theQuery = (currentSession
				.createSQLQuery(" select id from setting where modify_date IN (select MAX(modify_date) from setting)")
				.addScalar("id", IntegerType.INSTANCE));
		// now retrieve/read from database using the primary key
		int theSetting = (int) theQuery.getSingleResult();

		return theSetting;
	}

	@Override
	public void deleteSetting(int theId) {

		// get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();

		// delete object with primary key
		Query<Long> theQuery = currentSession.createQuery("delete from Setting where id=:settingId");
		theQuery.setParameter("settingId", theId);

		theQuery.executeUpdate();
	}

	@Override
	public void updateSetting(Setting theSetting) {

		// get current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();
		int theId = theSetting.getId();
		Query<Long> theQuery = currentSession.createQuery("delete from Header where setting_id=:settingId");
		Query<Long> theQuery2 = currentSession.createQuery("delete from BasicAuth where setting_id=:settingId");
		theQuery.setParameter("settingId", theId);
		theQuery2.setParameter("settingId", theId);
		theQuery.executeUpdate();
		theQuery2.executeUpdate();
		currentSession.saveOrUpdate(theSetting);
		currentSession.persist(theSetting);
	}

}
