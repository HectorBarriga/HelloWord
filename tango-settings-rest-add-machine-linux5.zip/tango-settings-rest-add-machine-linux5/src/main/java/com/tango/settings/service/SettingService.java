package com.tango.settings.service;

import java.util.List;
import java.util.Set;

import com.tango.settings.entity.Cluster;
import com.tango.settings.entity.Count;
import com.tango.settings.entity.Header;
import com.tango.settings.entity.Setting;

public interface SettingService {

	public List<Setting> getSettings();

	public void saveSetting(Setting theSetting);

	public Setting getSetting(int theId);

	public void deleteSetting(int theId);
	
	public void updateSetting(Setting theSetting);

	Setting getSetting(Cluster cluster);

	List<Setting> getSettings(Cluster cluster);

	List<Setting> getSettings(int cluster);

	Count getSettingCount(int clusterId);

	List<Setting> getSettingsMachine(int machineId);

	Count getSettingCountCluster(int clusterId);

	int getRecentSetting();
	
}
