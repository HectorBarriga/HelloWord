package com.tango.settings.service;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tango.settings.dao.ClusterDAO;
import com.tango.settings.dao.MachineDAO;
import com.tango.settings.dao.SettingDAO;
import com.tango.settings.entity.Cluster;
import com.tango.settings.entity.Machine;
import com.tango.settings.entity.Setting;

@Service
public class MachineServiceImpl implements MachineService {


	@Autowired
	private MachineDAO machineDAO;

	@Override
	@Transactional
	public List<Machine> getMachines(int clusterId) {
		return machineDAO.getMachines(clusterId);
	}

	@Override
	@Transactional
	public void saveMachine(Machine theMachine) {

		machineDAO.saveMachine(theMachine);
	}

	@Override
	@Transactional
	public Machine getMachine(int theId) {

		return machineDAO.getMachine(theId);
	}

	@Override
	@Transactional
	public void deleteMachine(int theId) {

		machineDAO.deleteMachine(theId);
	}

	@Override
	@Transactional
	public void updateMachine(Machine theMachine) {

		machineDAO.updateMachine(theMachine);
	}

}
