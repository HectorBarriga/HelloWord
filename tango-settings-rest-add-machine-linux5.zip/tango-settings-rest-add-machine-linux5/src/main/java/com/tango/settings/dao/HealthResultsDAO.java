package com.tango.settings.dao;

import java.util.List;

import com.tango.settings.entity.HealthResult;
import com.tango.settings.entity.Count;
import com.tango.settings.entity.Result;

public interface HealthResultsDAO {

	void saveResult(HealthResult theResult);
	
	void updateResult(HealthResult theResult, int theId);

	Count countOk();
	
	

}
