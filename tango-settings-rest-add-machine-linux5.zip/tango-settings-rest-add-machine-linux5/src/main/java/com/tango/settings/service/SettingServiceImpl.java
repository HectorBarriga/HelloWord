package com.tango.settings.service;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tango.settings.dao.SettingDAO;
import com.tango.settings.entity.Cluster;
import com.tango.settings.entity.Count;
import com.tango.settings.entity.Header;
import com.tango.settings.entity.Setting;

@Service
public class SettingServiceImpl implements SettingService {


	@Autowired
	private SettingDAO settingDAO;

	@Override
	@Transactional
	public List<Setting> getSettings() {
		return settingDAO.getSettings();
	}

	@Override
	@Transactional
	public List<Setting> getSettings(Cluster cluster) {
		return settingDAO.getSettings(cluster);
	}

	@Override
	@Transactional
	public List<Setting> getSettings(int cluster) {
		return settingDAO.getSettings(cluster);
	}

	@Override
	@Transactional
	public List<Setting> getSettingsMachine(int machineId) {
		return settingDAO.getSettingsMachine(machineId);
	}

	@Override
	@Transactional
	public void saveSetting(Setting theSetting) {

		settingDAO.saveSetting(theSetting);
	}

	@Override
	@Transactional
	public Setting getSetting(int theId) {

		return settingDAO.getSetting(theId);
	}

	@Override
	@Transactional
	public int getRecentSetting() {

		return settingDAO.getRecentSetting();
	}

	@Override
	@Transactional
	public void deleteSetting(int theId) {

		settingDAO.deleteSetting(theId);
	}

	@Override
	@Transactional
	public void updateSetting(Setting theSetting) {

		settingDAO.updateSetting(theSetting);
	}

	@Override
	public Setting getSetting(Cluster cluster) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	@Transactional
	public Count getSettingCount(int machineId) {
		return settingDAO.getSettingsCount(machineId);
	}

	@Override
	@Transactional
	public Count getSettingCountCluster(int clusterId) {
		return settingDAO.getSettingsCountCluster(clusterId);
	}

}






