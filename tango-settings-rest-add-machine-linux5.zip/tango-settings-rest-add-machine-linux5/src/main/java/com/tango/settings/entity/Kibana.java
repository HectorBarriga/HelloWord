package com.tango.settings.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "kibana")
public class Kibana {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "dashboard_name")
	private String dashboardName;
	
	@Column(name = "dashboard_frame")
	private String dashboardFrame;
	
	
	public Kibana() {
		
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getDashboardName() {
		return dashboardName;
	}


	public void setDashboardName(String dashboardName) {
		this.dashboardName = dashboardName;
	}


	public String getDashboardFrame() {
		return dashboardFrame;
	}


	public void setDashboardFrame(String dashboardFrame) {
		this.dashboardFrame = dashboardFrame;
	}


	@Override
	public String toString() {
		return "Kibana [id=" + id + ", dashboardName=" + dashboardName + ", dashboardFrame=" + dashboardFrame + "]";
	}
	
	

}
