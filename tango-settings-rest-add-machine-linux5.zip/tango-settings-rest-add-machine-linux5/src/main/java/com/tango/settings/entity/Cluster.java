package com.tango.settings.entity;

import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "cluster")
public class Cluster {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "cluster_name")
	private String clusterName;

	@JsonManagedReference(value = "cluster-setting")
	@OneToMany(fetch = FetchType.EAGER, mappedBy = "cluster", cascade = { CascadeType.PERSIST, CascadeType.MERGE,
			CascadeType.DETACH, CascadeType.REFRESH })
	// @Column(name="settings")
	private Set<Setting> settings;

	@JsonManagedReference(value = "cluster-machine")
	@OneToMany(fetch = FetchType.EAGER, mappedBy = "cluster", cascade = { CascadeType.PERSIST, CascadeType.MERGE,
			CascadeType.DETACH, CascadeType.REFRESH })

	private Set<Machine> machines;

	@JsonManagedReference(value = "cluster-commandsetting")
	@OneToMany(fetch = FetchType.EAGER, mappedBy = "machine", cascade = { CascadeType.PERSIST, CascadeType.MERGE,
			CascadeType.DETACH, CascadeType.REFRESH })
	// @Column(name="settings")
	private Set<HealthSetting> commandSettings;

	public Cluster() {

		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Set<Setting> getSettings() {
		return settings;
	}

	public void setSettings(Set<Setting> settings) {
		this.settings = settings;
	}

	public String getClusterName() {
		return clusterName;
	}

	public void setClusterName(String clusterName) {
		this.clusterName = clusterName;
	}

	public Set<Machine> getMachines() {
		return machines;
	}

	public void setMachines(Set<Machine> machines) {
		this.machines = machines;
	}

	public Set<HealthSetting> getCommandSettings() {
		return commandSettings;
	}

	public void setCommandSettings(Set<HealthSetting> commandSettings) {
		this.commandSettings = commandSettings;
	}

}
