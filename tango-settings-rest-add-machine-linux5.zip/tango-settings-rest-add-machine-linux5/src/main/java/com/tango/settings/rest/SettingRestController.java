package com.tango.settings.rest;

import java.util.ArrayList;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tango.settings.entity.Cluster;
import com.tango.settings.entity.Count;
import com.tango.settings.entity.Header;
import com.tango.settings.entity.Result;
import com.tango.settings.entity.Setting;
import com.tango.settings.service.ResultService;
import com.tango.settings.service.SettingService;
//import com.tango.settings.entity.Setting;;

@RestController
@RequestMapping("/api")
public class SettingRestController {

	@Autowired
	private SettingService settingService;

	@Autowired
	private ResultService resultService;

	@GetMapping("/settings")
	public List<Setting> getSettings() {

		return settingService.getSettings();

	}

	@GetMapping("/settings/{clusterId}")
	public List<Setting> getSettings(@PathVariable int clusterId) {

		return settingService.getSettings(clusterId);

	}

	@GetMapping("/settings/machine/{machineId}")
	public List<Setting> getSettingsMachine(@PathVariable int machineId) {

		return settingService.getSettingsMachine(machineId);

	}

	@GetMapping("/settings/get/{settingId}")
	public Setting getSettingById(@PathVariable int settingId) {

		Setting theSetting = settingService.getSetting(settingId);

		if (theSetting == null) {
			throw new SettingNotFoundException("Setting id not found - " + settingId);
		}
		return theSetting;

	}

	@GetMapping("/settings/get")
	public int getSettingById() {

		int theSetting = settingService.getRecentSetting();

		return theSetting;

	}

	@PostMapping("/settings")
	public Setting addSetting(@RequestBody Setting theSetting) {

		theSetting.setId(0);

		settingService.saveSetting(theSetting);

		return theSetting;

	}

	@PostMapping("/settings/result")
	public Result addResult(@RequestBody Result theSetting) {

		theSetting.setResultId(0);

		resultService.saveResult(theSetting);

		return theSetting;

	}

	@PostMapping("/settings/result/{settingId}")
	public Result updateResult(@RequestBody Result theResult, @PathVariable int settingId) {

		theResult.setResultId(0);

		resultService.updateResult(theResult, settingId);

		return theResult;
	}

	@PutMapping("/settings")
	public Setting updateSetting(@RequestBody Setting theSetting) {

		settingService.updateSetting(theSetting);

		return theSetting;

	}

	@DeleteMapping("/settings/{settingId}")
	public void deleteSetting(@PathVariable int settingId) {

		settingService.deleteSetting(settingId);

	}

	@GetMapping("/settings/count")
	public Count getResultCount() {

		Count okCount = resultService.getOkCount();

		return okCount;

	}

	@GetMapping("/settings/count/{machineId}")
	public Count getSettingCount(@PathVariable int machineId) {

		Count okCount = settingService.getSettingCount(machineId);

		return okCount;

	}

	@GetMapping("/settings/count/cluster/{clusterId}")
	public Count getSettingCountCluster(@PathVariable int clusterId) {

		Count okCount = settingService.getSettingCountCluster(clusterId);

		return okCount;

	}
}
