package com.tango.settings.service;

import java.util.List;

import com.tango.settings.entity.Count;
import com.tango.settings.entity.Header;
import com.tango.settings.entity.Result;
import com.tango.settings.entity.Setting;

public interface ResultService {


	void updateResult(Result theResult, int settingId);

	void saveResult(Result theSetting);

	Count getOkCount();

	


	
	
}
