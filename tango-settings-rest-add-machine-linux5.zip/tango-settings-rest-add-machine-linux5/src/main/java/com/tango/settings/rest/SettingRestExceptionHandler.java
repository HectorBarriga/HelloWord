package com.tango.settings.rest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class SettingRestExceptionHandler {

	
	//Add an exception handler 
	
	@ExceptionHandler
	public ResponseEntity<SettingErrorResponse> handleException(SettingNotFoundException exc){
		
	//create SettingErrorResponse
		SettingErrorResponse error = new SettingErrorResponse(
										HttpStatus.NOT_FOUND.value(),
										exc.getMessage(), 
										System.currentTimeMillis());
	//return ResponseEntity
	return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
	
	}
	
	
	
	//Add another to catch for any exception
	@ExceptionHandler
	public ResponseEntity<SettingErrorResponse> handleException(Exception exc){
		
		//create SettingErrorResponse
			SettingErrorResponse error = new SettingErrorResponse(
											HttpStatus.BAD_REQUEST.value(),
											exc.getMessage(), 
											System.currentTimeMillis());
		//return ResponseEntity
		return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
	
	
	}
}
