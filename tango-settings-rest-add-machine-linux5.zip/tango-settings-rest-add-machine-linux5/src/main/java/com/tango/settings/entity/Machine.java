package com.tango.settings.entity;

import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "machine")
public class Machine {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "machine_name")
	private String machineName;

	@JsonBackReference(value = "cluster-machine")
	@ManyToOne
	@JoinColumn(name = "cluster_id")
	private Cluster cluster;

	@JsonManagedReference(value = "machine-setting")
	@OneToMany(fetch = FetchType.EAGER, mappedBy = "machine", cascade = { CascadeType.PERSIST, CascadeType.MERGE,
			CascadeType.DETACH, CascadeType.REFRESH })
	// @Column(name="settings")
	private Set<Setting> settings;

	@JsonManagedReference(value = "machine-commandsetting")
	@OneToMany(fetch = FetchType.EAGER, mappedBy = "machine", cascade = { CascadeType.PERSIST, CascadeType.MERGE,
			CascadeType.DETACH, CascadeType.REFRESH })
	// @Column(name="settings")
	private Set<HealthSetting> commandSettings;

	public Machine() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMachineName() {
		return machineName;
	}

	public void setMachineName(String machineName) {
		this.machineName = machineName;
	}

	public Cluster getCluster() {
		return cluster;
	}

	public void setCluster(Cluster cluster) {
		this.cluster = cluster;
	}

	public Set<Setting> getSettings() {
		return settings;
	}

	public void setSettings(Set<Setting> settings) {
		this.settings = settings;
	}

	public Set<HealthSetting> getCommandSettings() {
		return commandSettings;
	}

	public void setCommandSettings(Set<HealthSetting> commandSettings) {
		this.commandSettings = commandSettings;
	}

	@Override
	public String toString() {
		return "Machine [id=" + id + ", machineName=" + machineName + ", cluster=" + cluster + ", settings=" + settings
				+ ", commandSettings=" + commandSettings + "]";
	}

	
}
