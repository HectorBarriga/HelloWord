package com.tango.settings.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "basic_auth")
public class BasicAuth {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int basicId;

	@JsonBackReference
	@OneToOne
	@JoinColumn(name = "setting_id")
	private Setting setting;

	@Column(name = "username_")
	private String username;

	@Column(name = "password_")
	private String password;

	public BasicAuth() {

	}

	public int getId() {
		return basicId;
	}

	public void setId(int id) {
		this.basicId = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "BasicAuth [id=" + basicId + ", username=" + username + ", password=" + password + "]";
	}

}
